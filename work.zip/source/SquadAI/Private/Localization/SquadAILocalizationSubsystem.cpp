// SquadAILocalizationSubsystem.cpp — External Notepad-editable text loader
#include "Localization/SquadAILocalizationSubsystem.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "HAL/PlatformFileManager.h"
#include "HAL/FileManager.h" // S14-ARAB: IFileManager for append writes
#include "Kismet/GameplayStatics.h"
#include "Engine/World.h"
#include "Engine/Engine.h"
#include "HAL/IConsoleManager.h"
#include "Internationalization/Internationalization.h"

namespace
{
	FString SquadAINormalizeLang(const FString& LangCode)
	{
		FString Lang = LangCode.TrimStartAndEnd().ToLower();
		if (Lang.StartsWith(TEXT("en"))) return TEXT("en");
		if (Lang.StartsWith(TEXT("ar"))) return TEXT("ar"); // P7-L4: Arabic support
		if (Lang.StartsWith(TEXT("fa")) || Lang.StartsWith(TEXT("fa-ir")) || Lang.StartsWith(TEXT("ir"))) return TEXT("fa");
		return Lang.IsEmpty() ? TEXT("fa") : Lang;
	}

	bool SquadAIEnglishFallback(const FString& Section, const FString& Key, FString& Out)
	{
		const FString S = Section.ToLower();
		const FString K = Key.ToLower();
		if (S == TEXT("mainmenu"))
		{
			if (K == TEXT("gametitle")) { Out = TEXT("Sacred Defense: Dehlavieh Fire Line"); return true; }
			if (K == TEXT("gamesubtitle") || K == TEXT("subtitle")) { Out = TEXT("Open-world tactical squad shooter — Sacred Defense, 1980"); return true; }
			if (K == TEXT("buttonnewgame") || K == TEXT("btnstartgame")) { Out = TEXT("Start New Operation"); return true; }
			if (K == TEXT("buttonmapselect") || K == TEXT("btnmapselect")) { Out = TEXT("Operations Map"); return true; }
			if (K == TEXT("buttonarmory") || K == TEXT("btnarmory")) { Out = TEXT("Armory and Equipment"); return true; }
			if (K == TEXT("buttonprogression")) { Out = TEXT("Progression and Skills"); return true; }
			if (K == TEXT("buttonplayerprofile") || K == TEXT("btnprofile")) { Out = TEXT("Combat Profile"); return true; }
			if (K == TEXT("buttonachievements")) { Out = TEXT("Medals and Achievements"); return true; }
			if (K == TEXT("buttoncontinue")) { Out = TEXT("Continue Operation"); return true; }
			if (K == TEXT("buttonloadgame")) { Out = TEXT("Load Save"); return true; }
			if (K == TEXT("buttonreliccollection")) { Out = TEXT("Fallen Comrades' Relics"); return true; }
			if (K == TEXT("buttonsettings") || K == TEXT("btnsettings")) { Out = TEXT("Settings and Graphics"); return true; }
			if (K == TEXT("buttonbriefing")) { Out = TEXT("Operational Intel File"); return true; }
			if (K == TEXT("buttonquit") || K == TEXT("btnexit")) { Out = TEXT("Exit Game"); return true; }
			if (K == TEXT("buttonback")) { Out = TEXT("Back"); return true; }
			if (K == TEXT("difficultytitle")) { Out = TEXT("Select Combat Difficulty"); return true; }
			if (K == TEXT("diffrecruit")) { Out = TEXT("Recruit — Easy"); return true; }
			if (K == TEXT("diffregular")) { Out = TEXT("Fighter — Normal"); return true; }
			if (K == TEXT("diffhardened")) { Out = TEXT("Veteran — Hard"); return true; }
			if (K == TEXT("diffveteran")) { Out = TEXT("Legendary Commander — Brutal"); return true; }
			if (K == TEXT("watermark")) { Out = TEXT("Irregular Warfare Operations Command — Major Shahid Iraj Rostami"); return true; }
		}
		if (S == TEXT("mapselection"))
		{
			if (K == TEXT("headertitle")) { Out = TEXT("Choose Operation Sector"); return true; }
			if (K == TEXT("map1_title")) { Out = TEXT("Dehlavieh and Karkheh River Axis"); return true; }
			if (K == TEXT("map1_status")) { Out = TEXT("Ready for Battle"); return true; }
			if (K == TEXT("map1_briefing")) { Out = TEXT("Advance through the Dehlavieh forward trenches, destroy enemy heavy machine-gun positions, and stabilize the defensive line beside Major Shahid Iraj Rostami."); return true; }
			if (K == TEXT("map2_title")) { Out = TEXT("Bostan and Chazabeh Pass Axis"); return true; }
			if (K == TEXT("map2_status") || K == TEXT("map3_status")) { Out = TEXT("In Preparation"); return true; }
			if (K == TEXT("map2_briefing")) { Out = TEXT("Liberate Bostan and close the Chazabeh infiltration route against the invading armored units in the dunes."); return true; }
			if (K == TEXT("map3_title")) { Out = TEXT("Khorramshahr and Arvand River"); return true; }
			if (K == TEXT("map3_briefing")) { Out = TEXT("Urban combat around alleys, the Grand Mosque, and the port approaches, blocking enemy mechanized advances."); return true; }
		}
		if (S == TEXT("armory"))
		{
			if (K == TEXT("headertitle")) { Out = TEXT("Personal Weapons and Ammunition"); return true; }
			if (K == TEXT("weapon1_name")) { Out = TEXT("Kalashnikov AK-47"); return true; }
			if (K == TEXT("weapon1_desc")) { Out = TEXT("7.62 mm assault rifle with excellent reliability in desert dust and harsh field conditions."); return true; }
			if (K == TEXT("weapon2_name")) { Out = TEXT("G3A3 Rifle"); return true; }
			if (K == TEXT("weapon2_desc")) { Out = TEXT("7.62 NATO service rifle with strong penetration and accurate long-range fire."); return true; }
			if (K == TEXT("weapon3_name")) { Out = TEXT("RPG-7 Launcher"); return true; }
			if (K == TEXT("weapon3_desc")) { Out = TEXT("Infantry anti-armor weapon for destroying T-55/T-62 tanks and fortified bunkers."); return true; }
			if (K == TEXT("weapon4_name")) { Out = TEXT("Goryunov / MG3 Machine Gun"); return true; }
			if (K == TEXT("weapon4_desc")) { Out = TEXT("Automatic machine gun for heavy suppressive fire against enemy positions."); return true; }
			if (K == TEXT("weapon5_name")) { Out = TEXT("SVD Dragunov"); return true; }
			if (K == TEXT("weapon5_desc")) { Out = TEXT("Scoped precision rifle for neutralizing snipers and machine-gunners at range."); return true; }
				if (K == TEXT("weapon6_name")) { Out = TEXT("Combat Knife / Bayonet"); return true; }
				if (K == TEXT("weapon6_desc")) { Out = TEXT("Close-combat blade for silent takedowns and emergency melee fighting."); return true; }
			if (K == TEXT("stat_damage")) { Out = TEXT("Firepower"); return true; }
			if (K == TEXT("stat_accuracy")) { Out = TEXT("Accuracy"); return true; }
			if (K == TEXT("stat_firerate")) { Out = TEXT("Fire Rate"); return true; }
			if (K == TEXT("stat_range")) { Out = TEXT("Effective Range"); return true; }
			if (K == TEXT("stat_reliability")) { Out = TEXT("Reliability"); return true; }
		}
		if (S == TEXT("traits"))
		{
			if (K == TEXT("trait1_name")) { Out = TEXT("Area Suppression"); return true; }
			if (K == TEXT("trait1_desc")) { Out = TEXT("Heavy sustained fire reduces enemy accuracy and forces them back into cover."); return true; }
			if (K == TEXT("trait2_name")) { Out = TEXT("Desert Resilience"); return true; }
			if (K == TEXT("trait2_desc")) { Out = TEXT("Weapon cycles reliably through sandstorms, dust, and marsh mud."); return true; }
			if (K == TEXT("trait3_name")) { Out = TEXT("Heavy Caliber"); return true; }
			if (K == TEXT("trait3_desc")) { Out = TEXT("High penetration through mud-brick walls and sandbagged positions."); return true; }
			if (K == TEXT("trait4_name")) { Out = TEXT("Tank Hunter"); return true; }
			if (K == TEXT("trait4_desc")) { Out = TEXT("Rapid destruction of armored vehicles advancing across open desert ground."); return true; }
			if (K == TEXT("trait5_name")) { Out = TEXT("Silent Marksman"); return true; }
			if (K == TEXT("trait5_desc")) { Out = TEXT("Precise long-range shots against vulnerable enemy targets."); return true; }
		}
		if (S == TEXT("profile"))
		{
			if (K == TEXT("headertitle")) { Out = TEXT("Combat Record and Command Rank"); return true; }
			if (K == TEXT("callsignlabel")) { Out = TEXT("Callsign / ID:"); return true; }
			if (K == TEXT("ranklabel")) { Out = TEXT("Military Rank:"); return true; }
			if (K == TEXT("rankvalue")) { Out = TEXT("First Sergeant Fighter"); return true; }
			if (K == TEXT("scorelabel")) { Out = TEXT("Courage Score:"); return true; }
			if (K == TEXT("killslabel")) { Out = TEXT("Enemies Defeated:"); return true; }
			if (K == TEXT("tankslabel")) { Out = TEXT("Tanks Destroyed:"); return true; }
			if (K == TEXT("reviveslabel")) { Out = TEXT("Squad Revives:"); return true; }
			if (K == TEXT("timelabel")) { Out = TEXT("Time on the Front:"); return true; }
			if (K == TEXT("btncyclecallsign")) { Out = TEXT("Change callsign [Click]"); return true; }
		}
		if (S == TEXT("loading"))
		{
			if (K == TEXT("loadingtitle")) { Out = TEXT("Khuzestan Operational Sector — Dehlavieh Front Line"); return true; }
			if (K == TEXT("loadingdesc")) { Out = TEXT("Loading equipment, stabilizing radio frequency, and coordinating the squad..."); return true; }
			if (K == TEXT("pressenterprompt")) { Out = TEXT("Press [Enter] or [Space] to enter the battlefield"); return true; }
			if (K == TEXT("tip1")) { Out = TEXT("Tactical tip: suppressive fire heavily reduces enemy accuracy and forces them into cover."); return true; }
			if (K == TEXT("tip2")) { Out = TEXT("Tactical tip: smoke grenades create a visual screen against machine-gunners."); return true; }
			if (K == TEXT("tip3")) { Out = TEXT("Tactical tip: hold [E] near wounded squadmates to revive and assist them."); return true; }
			if (K == TEXT("tip4")) { Out = TEXT("Tactical tip: ammo boxes and first-aid kits are inside trenches — equip before advancing."); return true; }
			if (K == TEXT("tip5")) { Out = TEXT("Tactical tip: hold [V] to reveal the safest illuminated route toward the objective."); return true; }
		}
		if (S == TEXT("hud"))
		{
			if (K == TEXT("squadleadername")) { Out = TEXT("Major Shahid Iraj Rostami"); return true; }
			if (K == TEXT("allynameprefix")) { Out = TEXT("Fighter"); return true; }
			if (K == TEXT("allystatuswounded")) { Out = TEXT("Wounded - needs aid"); return true; }
			if (K == TEXT("grenadeslabel")) { Out = TEXT("Grenade [G]: %d  |  Smoke [H]: %d"); return true; }
			if (K == TEXT("mortarprompt")) { Out = TEXT("Artillery [Middle Mouse]"); return true; }
			if (K == TEXT("guidanceprompt")) { Out = TEXT("Path Guidance [V]"); return true; }
			if (K == TEXT("reviveprompt")) { Out = TEXT("Hold [E] to revive and assist"); return true; }
			// S19-ELITE: the commander layer's banners. Without these, any non-Persian
			// language fell through to the Persian master text.
			if (K == TEXT("commanderonfield")) { Out = TEXT("COMMANDER ON THE FIELD"); return true; }
			if (K == TEXT("reinforcementsinbound")) { Out = TEXT("REINFORCEMENTS INBOUND!"); return true; }
			if (K == TEXT("commanderlaststand")) { Out = TEXT("COMMANDER CORNERED!"); return true; }
			if (K == TEXT("commanderkilled")) { Out = TEXT("COMMANDER ELIMINATED - ENEMY MORALE BROKEN"); return true; }
			if (K == TEXT("commanderhealing")) { Out = TEXT("THE ASSISTANT IS HEALING THE COMMANDER - SHOOT HIM!"); return true; }
		}
		if (S == TEXT("pausemenu"))
		{
			if (K == TEXT("headertitle")) { Out = TEXT("Tactical Operation Paused"); return true; }
			if (K == TEXT("subheader")) { Out = TEXT("Dehlavieh Operational Sector — Irregular Warfare HQ"); return true; }
			if (K == TEXT("btnresume")) { Out = TEXT("Resume Battle [Esc]"); return true; }
			if (K == TEXT("btnsave")) { Out = TEXT("Save Operation State"); return true; }
			if (K == TEXT("btnrestart")) { Out = TEXT("Restart Operation"); return true; }
			if (K == TEXT("btnquitmenu")) { Out = TEXT("Exit to Main Menu"); return true; }
			if (K == TEXT("btnquitdesktop")) { Out = TEXT("Exit to Desktop"); return true; }
			if (K == TEXT("savesuccessmessage")) { Out = TEXT("Operation state and squad position saved successfully."); return true; }
			if (K == TEXT("savefailedmessage")) { Out = TEXT("Failed to save operation state."); return true; }
		}
		if (S == TEXT("inventory"))
		{
			if (K == TEXT("headertitle")) { Out = TEXT("Backpack and Personal Equipment"); return true; }
			if (K == TEXT("subheader")) { Out = TEXT("Irregular Warfare HQ — Khuzestan Front"); return true; }
		}
		if (S == TEXT("fallentroopnotes"))
		{
			if (K == TEXT("notecount")) { Out = TEXT("6"); return true; }
			if (K.Contains(TEXT("_title"))) { Out = TEXT("Fallen Comrade Field Note"); return true; }
			if (K.Contains(TEXT("_body"))) { Out = TEXT("Hold the line, protect the homeland, and bring every comrade home."); return true; }
		}
		if (S == TEXT("radiostations"))
		{
			if (K == TEXT("stationcount")) { Out = TEXT("5"); return true; }
			if (K.Contains(TEXT("_name"))) { Out = TEXT("Sacred Defense Field Radio"); return true; }
		}
		if (S == TEXT("quranverses"))
		{
			if (K == TEXT("versecount")) { Out = TEXT("4"); return true; }
			if (K.Contains(TEXT("translation"))) { Out = TEXT("Victory belongs to God, the Mighty and Wise."); return true; }
		}
		return false;
	}

	/**
	 * P6-3: legacy alias resolution. The v1 shipped template used key names the code never
	 * queried (SubTitle, BtnStartGame, BtnExit, ...), so players' edits silently did nothing.
	 * If the canonical (code-queried) key is absent, its v1 alias is tried — and vice versa —
	 * so personalized v1 files keep working without forcing anyone to rename their keys.
	 */
	FString SquadAILegacyKeyAlias(const FString& Section, const FString& Key)
	{
		const FString S = Section.ToLower();
		const FString K = Key.ToLower();

		struct FAliasPair { const TCHAR* A; const TCHAR* B; };
		auto MatchAlias = [&K](const FAliasPair* Pairs, int32 Count) -> FString
		{
			for (int32 i = 0; i < Count; ++i)
			{
				if (K.Equals(FString(Pairs[i].A), ESearchCase::IgnoreCase)) return FString(Pairs[i].B);
				if (K.Equals(FString(Pairs[i].B), ESearchCase::IgnoreCase)) return FString(Pairs[i].A);
			}
			return FString();
		};

		static const FAliasPair MainMenuPairs[] =
		{
			{ TEXT("GameSubtitle"),       TEXT("SubTitle")    },
			{ TEXT("ButtonNewGame"),      TEXT("BtnStartGame") },
			{ TEXT("ButtonMapSelect"),    TEXT("BtnMapSelect") },
			{ TEXT("ButtonArmory"),       TEXT("BtnArmory")    },
			{ TEXT("ButtonPlayerProfile"),TEXT("BtnProfile")   },
			{ TEXT("ButtonSettings"),     TEXT("BtnSettings")  },
			{ TEXT("ButtonQuit"),         TEXT("BtnExit")      },
		};
		static const FAliasPair InventoryPairs[] =
		{
			{ TEXT("EquipWeaponButton"), TEXT("BtnEquipWeapon") },
			{ TEXT("NextNoteButton"),    TEXT("BtnNextNote")    },
		};
		static const FAliasPair HudPairs[] =
		{
			{ TEXT("ReviveHoldPrompt"), TEXT("RevivePrompt")   },
			{ TEXT("PickupFirstAid"),   TEXT("FirstAidPrompt") },
		};

		if (S == TEXT("mainmenu"))  return MatchAlias(MainMenuPairs, UE_ARRAY_COUNT(MainMenuPairs));
		if (S == TEXT("inventory")) return MatchAlias(InventoryPairs, UE_ARRAY_COUNT(InventoryPairs));
		if (S == TEXT("hud"))       return MatchAlias(HudPairs, UE_ARRAY_COUNT(HudPairs));
		return FString();
	}
}

void USquadAILocalizationSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
	LoadOrCreateDefaultFile();

	// P6-8: register the console command the INI header has always advertised
	// ("type SquadAI.ReloadText") — until now no such command actually existed.
	{
		IConsoleManager& CMan = IConsoleManager::Get();   // S9-FIX: Get() returns a reference
		if (!CMan.FindConsoleObject(TEXT("SquadAI.ReloadText")))
		{
			CMan.RegisterConsoleCommand(
				TEXT("SquadAI.ReloadText"),
				TEXT("Hot-reload every in-game text from SquadAILocalization.ini without restarting the game."),
				FConsoleCommandDelegate::CreateWeakLambda(this, [this]()
				{
					const bool bOk = ReloadFromDisk();
					UE_LOG(LogTemp, Log, TEXT("[SquadAILocalization] SquadAI.ReloadText -> %s (file: %s)"),
						bOk ? TEXT("OK") : TEXT("FAILED — file not found"), *ActiveFilePath);
				}),
				ECVF_Default);
		}
	}
}

void USquadAILocalizationSubsystem::Deinitialize()
{
	{
		IConsoleManager& CMan = IConsoleManager::Get();   // S9-FIX: Get() returns a reference
		if (IConsoleObject* Cmd = CMan.FindConsoleObject(TEXT("SquadAI.ReloadText")))
		{
			CMan.UnregisterConsoleObject(Cmd);
		}
	}
	StringDatabase.Empty();
	Super::Deinitialize();
}

USquadAILocalizationSubsystem* USquadAILocalizationSubsystem::Get(const UObject* WorldContextObject)
{
	if (!WorldContextObject) return nullptr;
	UGameInstance* GI = UGameplayStatics::GetGameInstance(WorldContextObject);
	return GI ? GI->GetSubsystem<USquadAILocalizationSubsystem>() : nullptr;
}

void USquadAILocalizationSubsystem::SetCurrentLanguage(const FString& LangCode)
{
	const FString NormalizedLanguage = SquadAINormalizeLang(LangCode);
	// Change-check doubles as re-entrancy guard: preset re-applies call back into here.
	if (CurrentLanguage.Equals(NormalizedLanguage, ESearchCase::IgnoreCase))
	{
		FInternationalization::Get().SetCurrentCulture(CurrentLanguage);
		return;
	}
	CurrentLanguage = NormalizedLanguage;
	FInternationalization::Get().SetCurrentCulture(CurrentLanguage);
	UE_LOG(LogTemp, Log, TEXT("[SquadAILocalization] Language -> '%s'"), *CurrentLanguage);
	OnLanguageChangedNative.Broadcast(CurrentLanguage);
	OnLanguageChanged.Broadcast(CurrentLanguage);
}

void USquadAILocalizationSubsystem::LoadOrCreateDefaultFile()
{
	// Candidate paths to search for SquadAILocalization.ini (first match wins).
	// P6-4: ProjectSavedDir() is searched FIRST — it stays writable in installed/shipping
	// builds, unlike ProjectDir/ContentDir which may be read-only or not staged at all.
	TArray<FString> SearchPaths;
	SearchPaths.Add(FPaths::ProjectSavedDir() / TEXT("SquadAILocalization.ini"));
	SearchPaths.Add(FPaths::ProjectDir() / TEXT("SquadAILocalization.ini"));
	SearchPaths.Add(FPaths::ProjectConfigDir() / TEXT("SquadAILocalization.ini"));
	SearchPaths.Add(FPaths::ProjectContentDir() / TEXT("Localization/SquadAILocalization.ini"));
	SearchPaths.Add(FPaths::ProjectDir() / TEXT("SquadAILocalization.txt"));
	SearchPaths.Add(FPaths::ProjectSavedDir() / TEXT("SquadAILocalization.txt"));

	bool bFound = false;
	FString LoadedContent;

	for (const FString& Path : SearchPaths)
	{
		if (FPlatformFileManager::Get().GetPlatformFile().FileExists(*Path))
		{
			if (FFileHelper::LoadFileToString(LoadedContent, *Path))
			{
				ActiveFilePath = Path;
				ParseIniContent(LoadedContent);
				MergeMissingFromTemplate(); // S14-ARAB: upgrade old files (Arabic etc.)
				bFound = true;
				UE_LOG(LogTemp, Log, TEXT("[SquadAILocalization] Loaded external text database from: %s (%d sections)"),
					*Path, StringDatabase.Num());
				break;
			}
		}
	}

	if (!bFound)
	{
		// Auto-generate the full master template into the writable Saved folder (P6-4).
		ActiveFilePath = FPaths::ProjectSavedDir() / TEXT("SquadAILocalization.ini");
		const FString DefaultContent = GetDefaultIniTemplate();
		FFileHelper::SaveStringToFile(DefaultContent, *ActiveFilePath, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
		ParseIniContent(DefaultContent);
		UE_LOG(LogTemp, Warning, TEXT("[SquadAILocalization] Created default editable text file at: %s"), *ActiveFilePath);
	}
}

void USquadAILocalizationSubsystem::ParseIniContent(const FString& FileContent)
{
	StringDatabase.Empty();
	ParseIniContentInto(FileContent, StringDatabase); // S14-ARAB: shared core
}

void USquadAILocalizationSubsystem::ParseIniContentInto(const FString& FileContent, TMap<FString, TMap<FString, FString>>& OutDB)
{
	TArray<FString> Lines;
	FileContent.ParseIntoArrayLines(Lines);

	FString CurrentSection = TEXT("Default");

	for (FString Line : Lines)
	{
		Line.TrimStartAndEndInline();

		// Skip comments and empty lines
		if (Line.IsEmpty() || Line.StartsWith(TEXT(";")) || Line.StartsWith(TEXT("#")) || Line.StartsWith(TEXT("//")))
		{
			continue;
		}

		// Section header [SectionName]
		if (Line.StartsWith(TEXT("[")) && Line.EndsWith(TEXT("]")))
		{
			CurrentSection = Line.Mid(1, Line.Len() - 2).TrimStartAndEnd();
			continue;
		}

		// Key=Value pair
		int32 EqualsIdx = INDEX_NONE;
		if (Line.FindChar(TEXT('='), EqualsIdx) && EqualsIdx > 0)
		{
			const FString Key = Line.Left(EqualsIdx).TrimStartAndEnd();
			const FString Value = Line.RightChop(EqualsIdx + 1).TrimStartAndEnd();

			if (!Key.IsEmpty())
			{
				OutDB.FindOrAdd(CurrentSection).Add(Key, Value);
			}
		}
	}
}

void USquadAILocalizationSubsystem::MergeMissingFromTemplate()
{
	// S14-ARAB: users who created their SquadAILocalization.ini with an OLDER
	// build never receive sections added later — most visibly ALL the [*.ar]
	// Arabic blocks, so switching to Arabic silently fell back to English
	// ("the arabic language in the game is not setup"). Merge every
	// section/key the user file is missing from the built-in master template.
	// USER VALUES ALWAYS WIN — only absent keys are added. The added keys are
	// also appended to the ini on disk so they stay Notepad-editable.
	TMap<FString, TMap<FString, FString>> TemplateDB;
	ParseIniContentInto(GetDefaultIniTemplate(), TemplateDB);

	FString AppendBlock;
	int32 AddedKeys = 0;
	int32 AddedSections = 0;

	for (const TPair<FString, TMap<FString, FString>>& SecPair : TemplateDB)
	{
		const TMap<FString, FString>* UserSec = StringDatabase.Find(SecPair.Key);
		if (!UserSec) { AddedSections++; }

		FString SectionAppend;
		for (const TPair<FString, FString>& KV : SecPair.Value)
		{
			if (UserSec && UserSec->Contains(KV.Key)) continue;
			StringDatabase.FindOrAdd(SecPair.Key).Add(KV.Key, KV.Value);
			SectionAppend += FString::Printf(TEXT("%s=%s\n"), *KV.Key, *KV.Value);
			AddedKeys++;
		}

		if (!SectionAppend.IsEmpty())
		{
			AppendBlock += FString::Printf(TEXT("\n[%s]\n%s"), *SecPair.Key, *SectionAppend);
		}
	}

	if (AddedKeys > 0)
	{
		UE_LOG(LogTemp, Warning, TEXT("[SquadAILocalization] S14-ARAB: user file was missing %d key(s) in %d new section(s) (e.g. Arabic) — merged from built-in template."),
			AddedKeys, AddedSections);

		if (!AppendBlock.IsEmpty() && !ActiveFilePath.IsEmpty())
		{
			const FString Header = TEXT("\n; ===================================================================================================\n")
				TEXT("; AUTO-ADDED BY GAME UPDATE (S14-ARAB): keys introduced by a newer build that were missing from\n")
				TEXT("; this file (e.g. Arabic [*.ar] sections). Edit them freely — your existing lines were NOT touched.\n")
				TEXT("; ===================================================================================================\n");
			if (FFileHelper::SaveStringToFile(Header + AppendBlock, *ActiveFilePath,
				FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM, &IFileManager::Get(), FILEWRITE_Append))
			{
				UE_LOG(LogTemp, Warning, TEXT("[SquadAILocalization] S14-ARAB: appended the missing keys to '%s'."), *ActiveFilePath);
			}
		}
	}
}

FString USquadAILocalizationSubsystem::GetStringForLanguage(const FString& Section, const FString& Key, const FString& LangCode, const FString& DefaultValue) const
{
	const FString Lang = SquadAINormalizeLang(LangCode);
	const FString AliasKey = SquadAILegacyKeyAlias(Section, Key);

	// [Section.Lang] Key
	const FString LocalizedSection = Section + TEXT(".") + Lang;
	if (const TMap<FString, FString>* SecLangMap = StringDatabase.Find(LocalizedSection))
	{
		if (const FString* Val = SecLangMap->Find(Key)) { return *Val; }
		if (!AliasKey.IsEmpty()) { if (const FString* Val = SecLangMap->Find(AliasKey)) { return *Val; } }
	}
	// [Section] Key_Lang (and alias_lang)
	if (const TMap<FString, FString>* SecMap = StringDatabase.Find(Section))
	{
		const FString KeyLang = Key + TEXT("_") + Lang;
		if (const FString* Val = SecMap->Find(KeyLang)) { return *Val; }
		if (!AliasKey.IsEmpty()) { const FString AliasLang = AliasKey + TEXT("_") + Lang; if (const FString* ValA = SecMap->Find(AliasLang)) { return *ValA; } }
		// Persian base convention: unprefixed keys hold the fa master text.
		if (Lang == TEXT("fa"))
		{
			if (const FString* Val = SecMap->Find(Key)) { return *Val; }
			if (!AliasKey.IsEmpty()) { if (const FString* Val = SecMap->Find(AliasKey)) { return *Val; } }
		}
	}
	return DefaultValue;
}

FString USquadAILocalizationSubsystem::GetString(const FString& Section, const FString& Key, const FString& DefaultValue) const
{
	const FString Lang = SquadAINormalizeLang(CurrentLanguage);
	// P6-3: fall back to the legacy v1 alias (empty when the key has none) so old edited
	// INI files keep driving the game after the key names were aligned with the code.
	const FString AliasKey = SquadAILegacyKeyAlias(Section, Key);

	if (!Lang.Equals(TEXT("fa"), ESearchCase::IgnoreCase))
	{
		// Optional external override styles: [HUD.en] Key=... or [HUD] Key_en=...
		const FString LocalizedSection = Section + TEXT(".") + Lang;
		const FString KeyLang = Key + TEXT("_") + Lang;
		const FString AliasKeyLang = AliasKey.IsEmpty() ? FString() : (AliasKey + TEXT("_") + Lang);
		if (const TMap<FString, FString>* SecLangMap = StringDatabase.Find(LocalizedSection))
		{
			if (const FString* Val = SecLangMap->Find(Key)) { return *Val; }
			if (!AliasKey.IsEmpty()) { if (const FString* Val = SecLangMap->Find(AliasKey)) { return *Val; } }
		}
		if (const TMap<FString, FString>* SecMap = StringDatabase.Find(Section))
		{
			if (const FString* Val = SecMap->Find(KeyLang)) { return *Val; }
			if (!AliasKeyLang.IsEmpty()) { if (const FString* Val = SecMap->Find(AliasKeyLang)) { return *Val; } }
		}
		// P7-L4: the built-in English table is the fallback for ALL non-Persian languages
		// (was en-only). With language=ar an Arabic player never sees Persian strings:
		// their [Section.ar] / Key_ar overrides win, then English, never the Persian base
		// unless even English has no entry.
		{
			FString BuiltIn;
			if (SquadAIEnglishFallback(Section, Key, BuiltIn))
			{
				return BuiltIn;
			}
		}
	}

	if (const TMap<FString, FString>* SecMap = StringDatabase.Find(Section))
	{
		if (const FString* Val = SecMap->Find(Key)) { return *Val; }
		if (!AliasKey.IsEmpty()) { if (const FString* Val = SecMap->Find(AliasKey)) { return *Val; } }
	}
	return DefaultValue;
}

FText USquadAILocalizationSubsystem::GetText(const FString& Section, const FString& Key, const FText& DefaultValue) const
{
	const FString Str = GetString(Section, Key, TEXT(""));
	if (!Str.IsEmpty())
	{
		return FText::FromString(Str);
	}
	return DefaultValue;
}

bool USquadAILocalizationSubsystem::ReloadFromDisk()
{
	if (ActiveFilePath.IsEmpty())
	{
		ActiveFilePath = FPaths::ProjectSavedDir() / TEXT("SquadAILocalization.ini"); // P6-4
	}

	FString Content;
	if (FFileHelper::LoadFileToString(Content, *ActiveFilePath))
	{
		ParseIniContent(Content);
		MergeMissingFromTemplate(); // S14-ARAB: hot-reload keeps new-build keys too
		UE_LOG(LogTemp, Log, TEXT("[SquadAILocalization] Hot-reloaded localization from '%s' (%d sections)"),
			*ActiveFilePath, StringDatabase.Num());
		// P1-L2: reloaded strings re-skin live holders too.
		OnLanguageChangedNative.Broadcast(CurrentLanguage);
		OnLanguageChanged.Broadcast(CurrentLanguage);
		return true;
	}

	return false;
}

FString USquadAILocalizationSubsystem::GetDefaultIniTemplate() const
{
	return TEXT("; ===================================================================================================\n")
	TEXT("; SQUAD AI & SACRED DEFENSE (دفاع مقدس) — MASTER EXTERNAL LOCALIZATION & ASSET CONFIGURATION (v2)\n")
	TEXT("; Project: Lidar Rostami / Iran-Iraq War (1980-1981) Khuzestan Front (دهلاویه و سوسنگرد)\n")
	TEXT("; Encoding: UTF-8 (Supports all Persian/Farsi & Arabic characters with full ligatures)\n")
	TEXT(";\n")
	TEXT("; ===================================================================================================\n")
	TEXT("; ✅ v2 STATUS: EVERY KEY BELOW IS LIVE — it is read by the game code and hot-reloads at runtime.\n")
	TEXT(";    (v1 had many \"decoy\" keys that edited nothing. This v2 matches the code 1:1 — verified by audit.)\n")
	TEXT(";\n")
	TEXT("; 📁 WHERE THE GAME LOOKS FOR THIS FILE (first match wins):\n")
	TEXT(";    1. <Project>/Saved/SquadAILocalization.ini          <- recommended master copy (writable, packaged-safe)\n")
	TEXT(";    2. <ProjectRoot>/SquadAILocalization.ini            <- legacy/dev convenience (source-tree copy)\n")
	TEXT(";\n")
	TEXT("; 📋 HOW TO EDIT & HOT-RELOAD IN REAL-TIME:\n")
	TEXT(";    1. Edit any value below in Notepad / VS Code and save (keep UTF-8 encoding).\n")
	TEXT(";    2. In the editor or running game, open console (~) and enter:  SquadAI.ReloadText\n")
	TEXT(";    3. All HUD menus, inventory tabs, prompts and tooltips update instantly without restarting!\n")
	TEXT(";\n")
	TEXT("; 🌐 OPTIONAL ENGLISH OVERRIDES:\n")
	TEXT(";    Persian (fa) is the master language of this file. To override for English players, add a\n")
	TEXT(";    parallel section e.g. [HUD.en] ReviveHoldPrompt=Hold [E] to revive   — or use inline\n")
	TEXT(";    suffix keys inside the master section:  ReviveHoldPrompt_en=Hold [E] to revive\n")
	TEXT(";    (Main-menu button English is currently baked into code; HUD/pause/loading/inventory honor this.)\n")
	TEXT(";\n")
	TEXT("; 🔁 LEGACY ALIASES: the old key names (SubTitle, BtnStartGame, BtnExit, BtnEquipWeapon,\n")
	TEXT(";    BtnNextNote, RevivePrompt, FirstAidPrompt) are still accepted as automatic aliases — old\n")
	TEXT(";    backup copies of this file keep working.\n")
	TEXT(";\n")
	TEXT("; 🖼️ OPTIONAL IMAGE OVERRIDES: in [FallenTroopNotes], Note1_Image=MyScan selects\n")
	TEXT(";    Content/Textures/MyScan.png (or .jpg) as that note's scan. Default stem is \"Note<N>\".\n")
	TEXT(";\n")
	TEXT("; ===================================================================================================\n")
	TEXT("; 🖼️ COMPLETE ASSET REPLACEMENT GUIDE (Content/Textures/):\n")
	TEXT("; You can replace any artwork simply by dropping your custom PNG (or cooked UTexture2D) into:\n")
	TEXT(";   📁 [ProjectRoot]/Content/Textures/\n")
	TEXT(";\n")
	TEXT("; 1. KEY ART & BACKGROUNDS:\n")
	TEXT(";    • MainMenu_KeyArt.png      (1920x1080) -> Main Menu Background (Major Rostami, desert dunes, G3)\n")
	TEXT(";    • LoadingScreen_Bg.png     (1920x1080) -> Loading Transition Screen with Dehlavieh sunset backdrop\n")
	TEXT(";    • UI_SacredDefense_Watermark.png (512x512) -> Translucent HQ Command Emblems & Geometric Insignia\n")
	TEXT(";\n")
	TEXT("; 2. SOLDIER PORTRAITS & AVATARS:\n")
	TEXT(";    • Avatar_IrajRostami.png   (512x512)   -> Major Shahid Iraj Rostami (Heroic Commander, Invulnerable)\n")
	TEXT(";    • Avatar_Ally1.png         (512x512)   -> Mehdi (RPG-7 Specialist, Full Beard & Red Headband)\n")
	TEXT(";    • Avatar_Ally2.png         (512x512)   -> Ali (G3 Marksman, Desert Chafiyeh & Green Headband)\n")
	TEXT(";    • Avatar_Ally3.png         (512x512)   -> Reza (Combat Medic, Chafiyeh & Medical Armband)\n")
	TEXT(";\n")
	TEXT("; 3. WEAPON SHOWCASE ARTWORK:\n")
	TEXT(";    • Weapon_AK47.png          (512x256)   -> Kalashnikov AK-47 Assault Rifle Showcase\n")
	TEXT(";    • Weapon_G3A3.png          (512x256)   -> Heckler & Koch G3A3 Battle Rifle Showcase\n")
	TEXT(";    • Weapon_RPG7.png          (512x256)   -> RPG-7 Anti-Tank Rocket Launcher Showcase\n")
	TEXT(";    • Weapon_MG3.png           (512x256)   -> MG3 / Goryunov Heavy Machine Gun Showcase\n")
	TEXT(";    • Weapon_SVD.png           (512x256)   -> SVD Dragunov Sniper Rifle Showcase\n")
	TEXT(";    • Weapon_Knife.png         (512x256)   -> Combat Trench Knife Showcase\n")
	TEXT(";\n")
	TEXT("; 4. SATELLITE TACTICAL MAPS:\n")
	TEXT(";    • Map_Dehlavieh.png        (512x288)   -> Sector 1: Dehlavieh Front & Karkheh River\n")
	TEXT(";    • Map_Bostan.png           (512x288)   -> Sector 2: Bostan Dunes & Chazabeh Pass\n")
	TEXT(";    • Map_Khorramshahr.png     (512x288)   -> Sector 3: Khorramshahr Port & Karun River\n")
	TEXT(";\n")
	TEXT("; 5. TACTICAL FRAMES & UI BUTTONS:\n")
	TEXT(";    • Frame_Tactical_Default.png (512x128) -> Obsidian Matte Chiseled Button Frame (1px Laser Accent)\n")
	TEXT(";    • Frame_Tactical_Hover.png   (512x128) -> Amber Gold Chamfered Hover Frame\n")
	TEXT(";    • Frame_Tactical_Active.png  (512x128) -> High-Contrast Ivory Active Button Frame\n")
	TEXT(";    • Frame_Border_SacredDefense.png (512x512) -> Geometric Border with Chafiyeh Pattern Trim\n")
	TEXT(";\n")
	TEXT("; 6. SPECIALTY TRAIT BADGES:\n")
	TEXT(";    • Trait_Suppression.png    (256x256)   -> Area Suppression Trait Icon\n")
	TEXT(";    • Trait_SandResistance.png (256x256)   -> Desert Fortitude Trait Icon\n")
	TEXT(";    • Trait_HeavyCaliber.png   (256x256)   -> Heavy Penetration Caliber Trait Icon\n")
	TEXT(";    • Trait_TankHunter.png     (256x256)   -> Armor Annihilator Trait Icon\n")
	TEXT(";    • Trait_SilentSniper.png   (256x256)   -> Covert Recon Trait Icon\n")
	TEXT(";\n")
	TEXT("; 7. INVENTORY SUPPLIES & GEAR:\n")
	TEXT(";    • Item_FirstAid.png        (256x256)   -> Combat Medical Dressing & Morphine Kit\n")
	TEXT(";    • Item_Canteen.png         (256x256)   -> Khuzestan Metal Canteen\n")
	TEXT(";    • Item_Grenade_Frag.png    (256x256)   -> Defensive Fragmentation Grenade\n")
	TEXT(";    • Item_Grenade_Smoke.png   (256x256)   -> Tactical Concealment Smoke Grenade\n")
	TEXT(";    • Item_Radio.png           (256x256)   -> Frontline Portable Radio Transceiver\n")
	TEXT(";    • Item_Quran.png           (256x256)   -> Gold-Embossed Pocket Holy Quran & Dua Book\n")
	TEXT(";    • Item_DogTag.png          (256x256)   -> Embossed Stainless Steel Military Dog Tag\n")
	TEXT(";\n")
	TEXT("; ===================================================================================================\n")
	TEXT("\n")
	TEXT("[MainMenu]\n")
	TEXT("GameTitle=دفاع مقدس: خط آتش دهلاویه\n")
	TEXT("GameSubtitle=تاکتیک، شجاعت و نبرد نامتقارن رزمندگان در جبهه خوزستان\n")
	TEXT("ButtonNewGame=ورود به عملیات\n")
	TEXT("ButtonMapSelect=انتخاب منطقه عملیاتی\n")
	TEXT("ButtonArmory=تسلیحات و تجهیزات\n")
	TEXT("ButtonProgression=ارتقای توانمندی‌ها و سطح رزمنده\n")
	TEXT("ButtonPlayerProfile=پرونده رزمی و مشخصات\n")
	TEXT("ButtonAchievements=مدال‌ها و دستاوردهای جنگی\n")
	TEXT("ButtonContinue=ادامه عملیات\n")
	TEXT("ButtonLoadGame=بارگذاری ذخیره\n")
	TEXT("ButtonRelicCollection=یادگاری‌های همرزمان شهید\n")
	TEXT("ButtonSettings=تنظیمات عملیاتی\n")
	TEXT("ButtonBriefing=پرونده اطلاعات عملیاتی\n")
	TEXT("ButtonQuit=خروج به دسکتاپ\n")
	TEXT("ButtonBack=← بازگشت\n")
	TEXT("DifficultyTitle=انتخاب سطح دشواری نبرد\n")
	TEXT("DiffRecruit=سرباز تازه‌کار (آسان)\n")
	TEXT("DiffRegular=سرباز رزمنده (متوسط)\n")
	TEXT("DiffHardened=کهنه‌سرباز (دشوار)\n")
	TEXT("DiffVeteran=فرمانده افسانه‌ای (بسیار سنگین)\n")
	TEXT("\n")
	TEXT("[PauseMenu]\n")
	TEXT("HeaderTitle=توقف عملیات تاکتیکی\n")
	TEXT("SubHeader=منطقه عملیاتی دهلاویه — ستاد جنگ‌های نامنظم\n")
	TEXT("BtnResume=ادامه نبرد [Esc]\n")
	TEXT("BtnSave=ذخیره وضعیت عملیات\n")
	TEXT("BtnRestart=شروع مجدد عملیات\n")
	TEXT("BtnQuitMenu=خروج به منوی اصلی\n")
	TEXT("BtnQuitDesktop=خروج به دسکتاپ\n")
	TEXT("SaveSuccessMessage=وضعیت عملیات و موقعیت جوخه با موفقیت ذخیره شد.\n")
	TEXT("SaveFailedMessage=خطا در ذخیره‌سازی وضعیت عملیات.\n")
	TEXT("\n")
	TEXT("[Loading]\n")
	TEXT("LoadingTitle=منطقه عملیاتی خوزستان — خط مقدم دهلاویه\n")
	TEXT("LoadingDesc=در حال بارگذاری تجهیزات، تثبیت فرکانس بی‌سیم و هماهنگی جوخه...\n")
	TEXT("PressEnterPrompt=برای ورود به میدان نبرد کلید [Enter] یا [Space] را فشار دهید\n")
	TEXT("DeploymentVeil=در حال استقرار نیروها و هماهنگی بی‌سیم...\n")
	TEXT("\n")
	TEXT("[HUD]\n")
	TEXT("AmmoCratePrompt=جعبه مهمات [E]\n")
	TEXT("PickupFirstAid=بسته امدادی [F]\n")
	TEXT("ReviveHoldPrompt=برای احیا و امداد کلید [E] را نگه دارید\n")
	TEXT("ReviveProgress=در حال پانسمان و مداوا...\n")
	TEXT("DownedAllyAidMarker=همرزم مجروح - امدادرسانی\n")
	TEXT("ExplosionDanger=خطر انفجار!\n")
	TEXT("MedicalStationPrompt=ایستگاه امداد\n")
		// S19-ELITE: the commander layer's banners (editable here like every other HUD string)
		TEXT("CommanderOnField=فرمانده در میدان است — او را از پای درآورید\n")
		TEXT("ReinforcementsInbound=نیروی کمکی می‌رسد!\n")
		TEXT("CommanderLastStand=فرمانده در تنگناست — او را تمام کنید!\n")
		TEXT("CommanderKilled=فرمانده از پای درآمد — دشمنان روحیه‌شان را باختند\n")
		TEXT("CommanderHealing=کمکیار در حال درمان فرمانده است — او را بزنید!\n")
	TEXT("MedicalStationPreparing=ایستگاه امداد (آماده‌سازی...)\n")
	TEXT("MountedTurretEnter=تیربار\n")
	TEXT("MountedTurretExit=مستقر پشت تیربار [E] ترک | آتش: کلیک چپ\n")
	TEXT("MortarReleasePrompt=[رها کردن کلید وسط] شلیک آتشبار پشتیبانی\n")
	TEXT("ObjectiveGoalDefault=نقطه هدف عملیاتی\n")
	TEXT("ObjectiveLeader=فرمانده سرگرد رستمی\n")
	TEXT("ObjectivePosition=موضع عملیاتی\n")
	TEXT("RadioHeader=بیسیم تاکتیکی // ستاد جنگ‌های نامنظم\n")
	TEXT("\n")
	TEXT("[Inventory]\n")
	TEXT("HeaderTitle=کوله‌پشتی و تجهیزات انفرادی رزمنده\n")
	TEXT("SubHeader=ستاد جنگ‌های نامنظم — جبهه خوزستان\n")
	TEXT("BallisticsHeader=مشخصات بالستیک و وضعیت مهمات\n")
	TEXT("ClosePrompt=[I / Esc] بستن کوله‌پشتی\n")
	TEXT("EquipWeaponButton=تجهیز و آماده‌سازی سلاح\n")
	TEXT("NextNoteButton=مطالعه دست‌نوشته دیگر [کلیک]\n")
	TEXT("NextVerseButton=آیه و دعای دیگر [کلیک]\n")
	TEXT("PreviousFrequency=◄ فرکانس قبلی\n")
	TEXT("NextFrequency=فرکانس بعدی ►\n")
	TEXT("RadioTitle=رادیو و بی‌سیم جیبی گراندیک (گیرنده امواج حماسی جبهه)\n")
	TEXT("QuranTitle=قرآن جیبی رزمنده و ادعیه نصر و آرامش دل‌ها\n")
	TEXT("\n")
	TEXT("[Armory]\n")
	TEXT("Weapon1_Name=کلاشینکف AK-47\n")
	TEXT("Weapon1_Desc=سلاح هجومی ۷.۶۲ میلی‌متری، اطمینان‌پذیری فوق‌العاده در شرایط سخت کویری و گردوغبار خوزستان.\n")
	TEXT("Weapon2_Name=تفنگ ژ۳ G3A3\n")
	TEXT("Weapon2_Desc=سلاح سازمانی کالیبر ۷.۶۲ ناتو با برد موثر بالا، قدرت نفوذ سنگین و دقت تیراندازی در فواصل دور.\n")
	TEXT("Weapon3_Name=راکت‌انداز RPG-7\n")
	TEXT("Weapon3_Desc=سلاح ضدزره پیاده‌نظام موثر در انهدام تانک‌های T-55 و T-62 و انهدام سنگرهای بتنی دشمن.\n")
	TEXT("Weapon4_Name=تیربار گرینوف / MG3\n")
	TEXT("Weapon4_Desc=تیربار اتوماتیک با نواخت تیر بسیار سریع جهت اجرای آتش سرکوبگر بر روی مواضع هجومی دشمن.\n")
	TEXT("Weapon5_Name=دراگونوف SVD\n")
	TEXT("Weapon5_Desc=تفنگ تک‌تیرانداز دقیق مجهز به دوربین اپتیک جهت خنثی‌سازی تک‌تیراندازان و تیربارچی‌های میدان.\n")
	TEXT("Weapon6_Name=خنجر رزمی / سرنیزه\n")
	TEXT("Weapon6_Desc=سلاح سرد نبرد تن‌به‌تن جهت غافلگیری و خنثی‌سازی بی‌صدای نگهبانان در سنگرهای مقدم.\n")
	TEXT("\n")
	TEXT("[FallenTroopNotes]\n")
	TEXT("NoteCount=6\n")
	TEXT("; Optional scanned-note artwork: Note1_Image=Note1  (file stem of Content/Textures/<stem>.png)\n")
	TEXT("Note1_Title=دست‌نوشته شهید مهدی (سنگر دهلاویه - ساعت ۰۳:۳۰ بامداد)\n")
	TEXT("Note1_Body=برادرانم! اگر در این شب تاریک و زیر آتش سنگین توپخانه بعثی‌ها به دیدار معبود شتافتم، سلاحم را بر زمین نگذارید. به مادرم بگویید فرزندت تا آخرین قطره خون پای خاک وطن و شرف مردم مظلوم خوزستان ایستاد. کارون و کرخه همیشه جاری خواهند ماند.\n")
	TEXT("Note2_Title=نامه خط مقدم همرزم علی‌اصغر به خانواده\n")
	TEXT("Note2_Body=سلام بر مادر صبور و پدر زحمت‌کشم. نگران من نباشید، در کنار سرگرد رستمی سنگر گرفته‌ایم و روحیه بچه‌ها بی‌نظیر است. عطر چفیه‌ها و صدای یا مهدی بچه‌ها تمام دشت را پر کرده است. دعا کنید در دفاع از ناموس و این آب و خاک روسفید شویم.\n")
	TEXT("Note3_Title=وصیت‌نامه رزمنده نوجوان محمدحسین (گردان خط‌شکن)\n")
	TEXT("Note3_Body=ای امت دلاور! قدر این برادری و ایستادگی را بدانید. ما برای خاک نجنگیدیم، برای حق و انسانیت و آزادگی ایستادیم. راه را برای رزمندگان پس از ما باز نگه دارید و هرگز در برابر ظلم سر فرود نیاورید.\n")
	TEXT("Note4_Title=خاطره کوتاه از دیده‌بان سنگر پل سابله\n")
	TEXT("Note4_Body=امروز تانک‌های دشمن با دود غلیظ به سمت معبر هجوم آوردند، ولی بچه‌های آرپی‌جی‌زن با فریاد یا زهرا دو تانک را به آتش کشیدند. وقتی ایمان باشد، آهن و زره هیچ معنایی ندارد.\n")
	TEXT("Note5_Title=پیام بیسیم‌چی گردان در شبی پر از آتش\n")
	TEXT("Note5_Body=فرکانس‌ها قطع و وصل می‌شود ولی امید هرگز قطع نمی‌شود. اگر صدای مرا می‌شنوید، به اهواز بگویید ما تا نفس داریم خط دهلاویه را حفظ می‌کنیم. سلام مرا به آفتاب برسانید.\n")
	TEXT("Note6_Title=نوشته پشت عکس یادگاری رزمندگان در نخلستان\n")
	TEXT("Note6_Body=این عکس یادگاری از یاران باوفای خوزستان است. شاید فردا میان شما نباشیم، اما نام ایران و یاد شهادت تا ابد بر تارک آسمان خواهد درخشید.\n")
	TEXT("\n")
	TEXT("[RadioStations]\n")
	TEXT("StationCount=5\n")
	TEXT("Station1_Freq=88.5\n")
	TEXT("Station1_Name=مارش پیروزی و نوای حماسی دفاع مقدس\n")
	TEXT("Station2_Freq=92.0\n")
	TEXT("Station2_Name=آهنگ ای لشکر صاحب زمان (نوای کاروان)\n")
	TEXT("Station3_Freq=96.5\n")
	TEXT("Station3_Name=موسیقی بی‌کلام حماسی خوزستان و کارون\n")
	TEXT("Station4_Freq=102.0\n")
	TEXT("Station4_Name=سرود کجایید ای شهیدان خدایی\n")
	TEXT("Station5_Freq=107.5\n")
	TEXT("Station5_Name=پیام‌های رادیویی خط مقدم و مارش حمله\n")
	TEXT("\n")
	TEXT("[QuranVerses]\n")
	TEXT("VerseCount=4\n")
	TEXT("Verse1_Arabic=وَمَا النَّصْرُ إِلَّا مِنْ عِنْدِ اللَّهِ الْعَزِيزِ الْحَكِيمِ\n")
	TEXT("Verse1_Translation=و پیروزی جز از جانب خدای پیروزمند حکیم نیست. (آل عمران - ۱۲۶)\n")
	TEXT("Verse2_Arabic=نَصْرٌ مِّنَ اللَّهِ وَفَتْحٌ قَرِيبٌ وَبَشِّرْ الْمُؤْمِنِينَ\n")
	TEXT("Verse2_Translation=یاری از جانب خدا و پیروزی نزدیک است؛ و مؤمنان را بشارت ده. (الصف - ۱۳)\n")
	TEXT("Verse3_Arabic=إِنْ يَنْصُرْكُمُ اللَّهُ فَلَا غَالِبَ لَكُمْ\n")
	TEXT("Verse3_Translation=اگر خدا شما را یاری کند، هیچ کس بر شما پیروز نخواهد شد. (آل عمران - ۱۶۰)\n")
	TEXT("Verse4_Arabic=أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ\n")
	TEXT("Verse4_Translation=آگاه باشید که با یاد خدا دل‌ها آرامش می‌یابد. (الرعد - ۲۸)\n")
	TEXT("\n")
	TEXT("; ===================================================================================================\n")
	TEXT("; ⏸ RESERVED — YOUR WORDING IS KEPT HERE AS BACKUP, BUT THESE SURFACES ARE NOT YET WIRED TO THE FILE.\n")
	TEXT(";   Today the game draws these texts from hardcoded bilingual pairs inside the module.\n")
	TEXT(";   The \"L2 full-wiring\" patch will make them editable here (same key names, hot-reload included).\n")
	TEXT(";   Editing them now causes NO harm — they are safely ignored until wiring lands.\n")
	TEXT("; ===================================================================================================\n")
	TEXT("\n")
	TEXT("[MapSelection]\n")
	TEXT("HeaderTitle=انتخاب منطقه و محور عملیاتی\n")
	TEXT("Map1_Title=محور دهلاویه و رودخانه کرخه\n")
	TEXT("Map1_Status=آماده نبرد\n")
	TEXT("Map1_Briefing=پیشروی در سنگرهای خط مقدم دهلاویه، انهدام مواضع تیربار سنگین دشمن بعثی و تثبیت خط پدافندی با همراهی شهید سرگرد ایرج رستمی.\n")
	TEXT("Map2_Title=محور بستان و تنگه چزابه\n")
	TEXT("Map2_Status=در دست آماده‌سازی\n")
	TEXT("Map2_Briefing=عملیات آزادسازی بستان و بستن معبر نفوذی تنگه چزابه از چنگ نیروهای زرهی متجاوز در میان تپه‌های رملی.\n")
	TEXT("Map3_Title=خرمشهر و اروندرود\n")
	TEXT("Map3_Status=در دست آماده‌سازی\n")
	TEXT("Map3_Briefing=نبرد شهری در کوچه‌ها، مسجد جامع و گمرک خرمشهر و سد معبر پیشروی یگان‌های مکانیزه ارتش بعث.\n")
	TEXT("\n")
	TEXT("[Traits]\n")
	TEXT("Trait1_Name=سرکوب منطقه‌ای\n")
	TEXT("Trait1_Desc=کاهش شدید دقت تیراندازی دشمنان و وادار کردن آن‌ها به عقب‌نشینی در سنگرها با آتش ممتد.\n")
	TEXT("Trait2_Name=استحکام کویری\n")
	TEXT("Trait2_Desc=شلیک روان و بدون وقفه سلاح در میان توفان شن و گل‌ولای تالاب‌های خوزستان.\n")
	TEXT("Trait3_Name=کالیبر سنگین\n")
	TEXT("Trait3_Desc=قدرت نفوذ بالا در دیوارهای خشتی و سنگرهای تقویت‌شده با گونی‌های شن.\n")
	TEXT("Trait4_Name=شکارچی تانک\n")
	TEXT("Trait4_Desc=تخریب سریع زره‌پوش‌ها و تانک‌های پیشروی‌کننده دشمن در دشت‌های باز دهلاویه.\n")
	TEXT("Trait5_Name=تک‌تیرانداز خاموش\n")
	TEXT("Trait5_Desc=شلیک‌های مرگبار و بی‌صدا با حداکثر آسیب به نقاط حساس دشمن از فواصل دور.\n")
	TEXT("\n")
	TEXT("[Profile]\n")
	TEXT("HeaderTitle=پرونده رزمی و رتبه فرماندهی\n")
	TEXT("CallsignLabel=نام مستعار / کد شناسایی:\n")
	TEXT("RankLabel=درجه نظامی:\n")
	TEXT("RankValue=ستوان‌یار یکم رزمنده\n")
	TEXT("ScoreLabel=امتیاز شجاعت:\n")
	TEXT("KillsLabel=تعداد شکار دشمن:\n")
	TEXT("TanksLabel=تانک‌های منهدم‌شده:\n")
	TEXT("RevivesLabel=امداد و احیای همرزمان:\n")
	TEXT("TimeLabel=مدت زمان حضور در خط:\n")
	TEXT("BtnCycleCallsign=تغییر نام و کد رزمی [کلیک]\n")
	TEXT("\n")
	TEXT("[Armory]\n")
	TEXT("HeaderTitle=تسلیحات و مهمات انفرادی\n")
	TEXT("Stat_Damage=قدرت آتش\n")
	TEXT("Stat_Accuracy=دقت هدف‌گیری\n")
	TEXT("Stat_FireRate=نواخت تیر\n")
	TEXT("Stat_Range=برد موثر\n")
	TEXT("Stat_Reliability=قابلیت اطمینان\n")
	TEXT("\n")
	TEXT("[Loading]\n")
	TEXT("Tip1=نکته تاکتیکی: آتش سرکوبگر دقت دشمن را به شدت کاهش داده و آن‌ها را مجبور به پناه گرفتن می‌کند.\n")
	TEXT("Tip2=نکته تاکتیکی: نارنجک‌های دودزا یک پرده دید غیرقابل نفوذ در برابر تیربارچی‌ها ایجاد می‌کنند.\n")
	TEXT("Tip3=نکته تاکتیکی: برای امدادرسانی و احیای همرزمان مجروح جوخه، کلید [E] را در نزدیکی آن‌ها نگه دارید.\n")
	TEXT("Tip4=نکته تاکتیکی: جعبه‌های مهمات و بسته‌های امدادی در سنگرها قرار دارند — پیش از پیشروی تجهیز شوید.\n")
	TEXT("Tip5=نکته تاکتیکی: با نگه‌داشتن کلید [V]، مسیر نورانی امن‌ترین راه به سمت نقطه هدف را نشان می‌دهد.\n")
	TEXT("Tip6=نکته تاکتیکی: با فشردن کلید [G] نارنجک ترکش‌زا و با کلید [H] نارنجک دودزا پرتاب کنید.\n")
	TEXT("Tip7=نکته تاکتیکی: با کلیک وسط ماوس، مختصات آتش پشتیبانی خمپاره را روی مواضع دشمن مشخص نمایید.\n")
	TEXT("\n")
	TEXT("[HUD]\n")
	TEXT("SquadLeaderName=سرگرد شهید ایرج رستمی\n")
	TEXT("AllyNamePrefix=رزمنده\n")
	TEXT("AllyStatusWounded=⚠️ [مجروح - نیاز به امداد]\n")
	TEXT("GrenadesLabel=نارنجک [G]: %d  |  دودزا [H]: %d\n")
	TEXT("MortarPrompt=خمپاره [کلیک وسط ماوس]\n")
	TEXT("GuidancePrompt=هدایت مسیر [V]\n")
	TEXT("\n")
	TEXT("[Inventory]\n")
	TEXT("TabWeapons=زرادخانه و تسلیحات\n")
	TEXT("TabSupplies=اقلام و تدارکات\n")
	TEXT("TabNotes=دست‌نوشته همرزمان\n")
	TEXT("TabRadio=بی‌سیم و رادیو جیبی\n")
	TEXT("TabQuran=قرآن و ادعیه متبرک\n")
	TEXT("TabWallet=کیف مدارک و پلاک\n")
	TEXT("AmmoLabel=مهمات آماده: %d | ذخیره کوله: %d\n")
	TEXT("RadioTunerLabel=موج فرکانس: %.1f MHz\n")
	TEXT("RadioVolumeLabel=حجم صدا: %d%%\n")
	TEXT("WalletOwner=رزمنده ستوان‌یار یکم\n")
	TEXT("WalletBloodGroup=گروه خونی: O+\n")
	TEXT("WalletDogTag=پلاک هویت: ۹۵۸/۱۳۵۹-خ\n")
	TEXT("\n")
	TEXT("[MainMenu]\n")
	TEXT("Watermark=قرارگاه فرماندهی عملیات جنگ‌های نامنظم — شهید سرگرد ایرج رستمی\n")
	TEXT("CopyrightNotice=تقدیم به روح پرفتوح شهدای ستاد جنگ‌های نامنظم و سرگرد شهید ایرج رستمی\n")
	TEXT("BtnSaveGame=ذخیره پیشرفت\n")
	TEXT("ResumeHint=جهت بازگشت سریع به نبرد کلید [Esc] را فشار دهید.\n")
	TEXT("; ===================================================================================================\n")
	TEXT("; ARABIC (العربية) ADD-ON for SquadAILocalization.ini — P7-L4\n")
	TEXT("; Paste these sections into your master SquadAILocalization.ini (anywhere — order does not matter).\n")
	TEXT("; They only take effect when the game language is set to العربية (Settings -> Language cycles\n")
	TEXT("; فارسی -> English -> العربية). Missing Arabic keys fall back to the built-in English strings,\n")
	TEXT("; never to Persian. Edit freely + hot-reload with:  SquadAI.ReloadText\n")
	TEXT("; (QuranVerses needs no Arabic section: its master strings are Arabic already and serve all languages.)\n")
	TEXT("; ===================================================================================================\n")
	TEXT("\n")
	TEXT("[MainMenu.ar]\n")
	TEXT("GameTitle=الدفاع المقدس: خط النار دهلاوية\n")
	TEXT("GameSubtitle=لعبة تكتيكية بعالم مفتوح لقيادة الفصيل — الدفاع المقدس (١٩٨٠)\n")
	TEXT("ButtonNewGame=بدء عملية جديدة\n")
	TEXT("ButtonMapSelect=اختيار منطقة العمليات\n")
	TEXT("ButtonArmory=التسليح وفتح الأسلحة\n")
	TEXT("ButtonProgression=ترقية القدرات ومستوى المقاتل\n")
	TEXT("ButtonPlayerProfile=السجل القتالي وإحصاءات المقاتل\n")
	TEXT("ButtonAchievements=الأوسمة والإنجازات الحربية\n")
	TEXT("ButtonContinue=متابعة العملية\n")
	TEXT("ButtonLoadGame=تحميل حفظ\n")
	TEXT("ButtonRelicCollection=تذكارات الرفاق الشهداء\n")
	TEXT("ButtonSettings=الإعدادات والرسومات\n")
	TEXT("ButtonBriefing=ملف المعلومات العملياتي\n")
	TEXT("ButtonQuit=الخروج من اللعبة\n")
	TEXT("ButtonBack=← رجوع\n")
	TEXT("DifficultyTitle=اختيار مستوى صعوبة المعركة\n")
	TEXT("DiffRecruit=مجند جديد (سهل)\n")
	TEXT("DiffRegular=مقاتل (متوسط)\n")
	TEXT("DiffHardened=محارب قديم (صعب)\n")
	TEXT("DiffVeteran=قائد أسطوري (قاسٍ جداً)\n")
	TEXT("\n")
	TEXT("[PauseMenu.ar]\n")
	TEXT("HeaderTitle=توقف العملية التكتيكية\n")
	TEXT("SubHeader=منطقة عمليات دهلاوية — قيادة المعارك غير النظامية\n")
	TEXT("BtnResume=استئناف المعركة [Esc]\n")
	TEXT("BtnSave=حفظ حالة العملية\n")
	TEXT("BtnRestart=إعادة بدء العملية\n")
	TEXT("BtnQuitMenu=الخروج إلى القائمة الرئيسية\n")
	TEXT("BtnQuitDesktop=الخروج إلى سطح المكتب\n")
	TEXT("SaveSuccessMessage=تم حفظ حالة العملية وموقع الفصيل بنجاح.\n")
	TEXT("SaveFailedMessage=فشل في حفظ حالة العملية.\n")
	TEXT("\n")
	TEXT("[Loading.ar]\n")
	TEXT("LoadingTitle=منطقة عمليات خوزستان — خط المواجهة في دهلاوية\n")
	TEXT("LoadingDesc=جاري تحميل المعدات وضبط تردد اللاسلكي والتنسيق مع الفصيل...\n")
	TEXT("PressEnterPrompt=اضغط [Enter] أو [Space] للدخول إلى ساحة المعركة\n")
	TEXT("DeploymentVeil=جاري نشر القوات والتنسيق عبر اللاسلكي...\n")
	TEXT("\n")
	TEXT("[HUD.ar]\n")
	TEXT("AmmoCratePrompt=صندوق ذخيرة [E]\n")
	TEXT("PickupFirstAid=حزمة إسعاف [F]\n")
	TEXT("ReviveHoldPrompt=اضغط مطولاً على [E] لإسعاف وإحياء الرفيق\n")
	TEXT("ReviveProgress=جاري تضميد الجروح وإسعافه...\n")
	TEXT("DownedAllyAidMarker=رفيق جريح - إسعاف\n")
	TEXT("ExplosionDanger=خطر انفجار!\n")
	TEXT("MedicalStationPrompt=محطة إسعاف\n")
	TEXT("MedicalStationPreparing=محطة إسعاف (جاري التحضير...)\n")
	TEXT("MountedTurretEnter=رشاش ثقيل\n")
	TEXT("MountedTurretExit=على الرشاش [E] للمغادرة | إطلاق: زر أيسر\n")
	TEXT("MortarReleasePrompt=[حرر زر الفأرة الأوسط] لإطلاق نيران الإسناد\n")
	TEXT("ObjectiveGoalDefault=نقطة الهدف العملياتي\n")
	TEXT("ObjectiveLeader=القائد الرائد رستمي\n")
	TEXT("ObjectivePosition=موقع عملياتي\n")
	TEXT("RadioHeader=لاسلكي تكتيكي // قيادة المعارك غير النظامية\n")
	TEXT("\n")
	TEXT("[Inventory.ar]\n")
	TEXT("HeaderTitle=حقيبة الظهر والمعدات الشخصية للمقاتل\n")
	TEXT("SubHeader=قيادة المعارك غير النظامية — جبهة خوزستان\n")
	TEXT("BallisticsHeader=المواصفات الباليستية وحالة الذخيرة\n")
	TEXT("ClosePrompt=[I / Esc] إغلاق الحقيبة\n")
	TEXT("EquipWeaponButton=تجهيز السلاح وإعداده\n")
	TEXT("NextNoteButton=قراءة مذكرة أخرى [نقرة]\n")
	TEXT("NextVerseButton=آية ودعاء آخر [نقرة]\n")
	TEXT("PreviousFrequency=◄ التردد السابق\n")
	TEXT("NextFrequency=التردد التالي ►\n")
	TEXT("RadioTitle=راديو جرونديق المحمول ولاسلكي تكتيكي (مستقبل موجات الجبهة الحماسية)\n")
	TEXT("QuranTitle=مصحف المقاتل الجيبي وأدعية النصر وطمأنينة القلوب\n")
	TEXT("\n")
	TEXT("[Armory.ar]\n")
	TEXT("Weapon1_Name=كلاشنكوف AK-47\n")
	TEXT("Weapon1_Desc=بندقية هجومية 7.62 ملم بموثوقية عالية في غبار الصحراء وظروف خوزستان القاسية.\n")
	TEXT("Weapon2_Name=بندقية G3A3\n")
	TEXT("Weapon2_Desc=بندقية نظامية بعيار 7.62 ناتو، بمدى فعال عالٍ وقدرة اختراق قوية ودقة للمسافات البعيدة.\n")
	TEXT("Weapon3_Name=قاذف RPG-7\n")
	TEXT("Weapon3_Desc=سلاح مشاة مضاد للدروع فعال ضد دبابات T-55 وT-62 وتحصينات العدو الخرسانية.\n")
	TEXT("Weapon4_Name=رشاش غوريونوف / MG3\n")
	TEXT("Weapon4_Desc=رشاش آلي بمعدل رمي سريع جداً لتنفيذ نيران الإخماد على مواقع العدو.\n")
	TEXT("Weapon5_Name=دراغونوف SVD\n")
	TEXT("Weapon5_Desc=بندقية قنص دقيقة مزودة بمنظار لتحييد القناصة والرشاشين في الميدان.\n")
	TEXT("Weapon6_Name=سكين قتال / حربة\n")
	TEXT("Weapon6_Desc=سلاح أبيض للقتال وجهاً لوجه وللتحييد الصامت لحراس المواقع الأمامية.\n")
	TEXT("\n")
	TEXT("; ===================================================================================================\n")
	TEXT("; L2-INI WIRING ADDITIONS — these keys are now LIVE in the code (HUD / inventory / wallet / radio).\n")
	TEXT("; ===================================================================================================\n")
	TEXT("[HUD]\n")
	TEXT("SquadPanelHeader=وضعیت رزمندگان جوخه\n")
	TEXT("UnitsMeterShort=متر\n")
	TEXT("SquadLeaderRole=فرمانده\n")
	TEXT("DistanceLabel=فاصله\n")
	TEXT("BadgeAdvance=پیشروی\n")
	TEXT("BadgeClear=پاکسازی\n")
	TEXT("BadgeDefend=پدافند\n")
	TEXT("MortarTargetHeaderFmt=هدف‌گیری خمپاره‌انداز ۱۲۰ میلی‌متری (%.0f متر)\n")
	TEXT("AllyDownedBannerFmt=⚠️ همرزم جوخه (%s) مجروح شد! سریعاً برای امداد اقدام کنید [E]\n")
	TEXT("HealthLabel=سلامت: %d%%\n")
	TEXT("SuppliesReadoutFmt=[G] نارنجک: %d   [H] دود: %d   [+] امداد: %d\n")
	TEXT("MissionStageFmt=مرحله %d از %d\n")
	TEXT("MeleeWeaponName=نبرد تن‌به‌تن (بدون سلاح)\n")
	TEXT("NoAmmoText=بدون مهمات\n")
	TEXT("FallbackG3Name=ژ-۳ (G3A3)\n")
	TEXT("FallbackG3Ammo=۲۰ / ۱۲۰\n")
	TEXT("\n")
	TEXT("[Inventory]\n")
	TEXT("WalletFighterNameFmt=نام رزمنده: %s\n")
	TEXT("WalletCardTitle=کارت شناسایی رزمنده ستاد جنگ‌های نامنظم\n")
	TEXT("WalletUnit=یگان: ستاد جنگ‌های نامنظم (شهید چمران / رستمی)\n")
	TEXT("WalletAxis=محور عملیاتی: دهلاویه، سوسنگرد و کرخه\n")
	TEXT("WalletCommander=فرمانده مستقیم: سرگرد شهید ایرج رستمی\n")
	TEXT("WalletMedicalCardTitle=کارت سلامت و پلاک هویت فلزی\n")
	TEXT("WalletMedicalStatus=وضعیت امدادی: کاملاً آماده رزم و مجهز\n")
	TEXT("WalletPhysicalReadiness=آمادگی جسمانی: عالی (استقامت رزم کویری)\n")
	TEXT("RadioStatusPlaying=● وضعیت: در حال پخش نوای جبهه\n")
	TEXT("RadioStatusOff=○ وضعیت: خاموش\n")
	TEXT("SupplyStockFmt=موجودی: %d عدد\n")
	TEXT("SupplyWaterFmt=میزان آب: %d%%\n")
	TEXT("SupplyFirstAidName=بسته امدادی انفرادی\n")
	TEXT("SupplyFirstAidDesc=درمان جراحت و بازیابی سلامت سریع در سنگر\n")
	TEXT("SupplyFragName=نارنجک ترکش‌زا [G]\n")
	TEXT("SupplyFragDesc=انهدام تجمعات دشمن و سنگرهای تیربار\n")
	TEXT("SupplySmokeName=نارنجک دودزا [H]\n")
	TEXT("SupplySmokeDesc=ایجاد پرده دید ۱۸ ثانیه‌ای در برابر تک‌تیراندازان\n")
	TEXT("SupplyCanteenName=قمقمه آب فلزی\n")
	TEXT("SupplyCanteenDesc=رفع عطش و خستگی در گرمای طاقت‌فرسای خوزستان\n")
	TEXT("SupplyKeffiyehName=چفیه و سربند متبرک\n")
	TEXT("SupplyKeffiyehCount=تعداد: ۱ عدد\n")
	TEXT("SupplyKeffiyehDesc=محافظت در برابر گردوغبار و نشانه شجاعت و ایمان\n")
	TEXT("SupplyCompassName=قطب‌نما و نقشه تاکتیکی\n")
	TEXT("SupplyCompassStatus=وضعیت: فعال [V]\n")
	TEXT("SupplyCompassDesc=راهنمای مسیر و تشخیص معابر مین‌گذاری شده\n")
	TEXT("\n")
	TEXT("; ===================================================================================================\n")
	TEXT("; ARABIC COMPLETION — fallen-comrade notes + radio stations (the remaining Arabic gaps),\n")
	TEXT("; plus Arabic for the L2-wired HUD/inventory keys and the now-live MapSelection/Traits/Profile sections.\n")
	TEXT("; ===================================================================================================\n")
	TEXT("[FallenTroopNotes.ar]\n")
	TEXT("Note1_Title=مذكرة ميدانية للرفيق الشهيد ١\n")
	TEXT("Note1_Body=إخوتي، لا تتركوا السلاح على الأرض. واصلوا الدفاع عن تراب الوطن الطاهر حتى آخر نَفَس.\n")
	TEXT("Note2_Title=مذكرة ميدانية للرفيق الشهيد ٢\n")
	TEXT("Note2_Body=الشهادة فن رجال الله، ودماء الشهداء أمانة بين أيديكم.\n")
	TEXT("Note3_Title=مذكرة ميدانية للرفيق الشهيد ٣\n")
	TEXT("Note3_Body=دافعوا عن أهلنا وأرضنا، ولا تمنحوا المعتدي خطوة واحدة إلى الأمام.\n")
	TEXT("Note4_Title=مذكرة ميدانية للرفيق الشهيد ٤\n")
	TEXT("Note4_Body=قلبي مطمئن؛ فلقاء الشهداء خير من حياة بلا كرامة.\n")
	TEXT("Note5_Title=مذكرة ميدانية للرفيق الشهيد ٥\n")
	TEXT("Note5_Body=اثبتوا على الموضع؛ العتاد كافٍ والروح أعلى من كل حصار.\n")
	TEXT("Note6_Title=مذكرة ميدانية للرفيق الشهيد ٦\n")
	TEXT("Note6_Body=إن غبت عنكم فأنا مع الشهداء. واصلوا الدرب بذات العهد واليقين.\n")
	TEXT("\n")
	TEXT("[RadioStations.ar]\n")
	TEXT("Station1_Name=إذاعة طهران – أناشيد الدفاع المقدس\n")
	TEXT("Station2_Name=نشرة أخبار جبهات المقاومة\n")
	TEXT("Station3_Name=اتصالات ميدانية من المواقع الأمامية\n")
	TEXT("Station4_Name=تلاوات قرآنية في خنادق الليل\n")
	TEXT("Station5_Name=أناشيد النصر والموسيقى العسكرية الحماسية\n")
	TEXT("\n")
	TEXT("[HUD.ar]\n")
	TEXT("SquadPanelHeader=حالة مقاتلي الفصيل\n")
	TEXT("UnitsMeterShort=م\n")
	TEXT("SquadLeaderRole=القائد\n")
	TEXT("GuidancePrompt=توجيه الطريق [V]\n")
	TEXT("DistanceLabel=المسافة\n")
	TEXT("BadgeAdvance=تقدّم\n")
	TEXT("BadgeClear=تطهير\n")
	TEXT("BadgeDefend=دفاع\n")
	TEXT("MortarTargetHeaderFmt=تصويب هاون 120 ملم (%.0f متر)\n")
	TEXT("AllyDownedBannerFmt=رفيق الفصيل (%s) جريح! تحرك للإسعاف [E]\n")
	TEXT("HealthLabel=الصحة: %d%%\n")
	TEXT("SuppliesReadoutFmt=[G] قنبلة: %d   [H] دخان: %d   [+] إسعاف: %d\n")
	TEXT("MissionStageFmt=المرحلة %d من %d\n")
	TEXT("MeleeWeaponName=قتال يدوي (بدون سلاح)\n")
	TEXT("NoAmmoText=لا ذخيرة\n")
	TEXT("\n")
	TEXT("[Inventory.ar]\n")
	TEXT("TabWeapons=التسليح والأسلحة\n")
	TEXT("TabNotes=مذكرات الرفاق\n")
	TEXT("TabRadio=الراديو المحمول\n")
	TEXT("TabQuran=القرآن والأدعية\n")
	TEXT("TabWallet=محفظة الوثائق وبطاقة الهوية\n")
	TEXT("TabSupplies=الإمدادات والتجهيز\n")
	TEXT("AmmoLabel=ذخيرة المخزن: %d | مخزون الحقيبة: %d\n")
	TEXT("SupplyStockFmt=المخزون: %d\n")
	TEXT("SupplyWaterFmt=كمية الماء: %d%%\n")
	TEXT("\n")
	TEXT("[MapSelection.ar]\n")
	TEXT("HeaderTitle=اختيار منطقة ومحور العمليات\n")
	TEXT("Map1_Title=محور دهلاوية ونهر كرخة\n")
	TEXT("Map1_Status=جاهز للقتال\n")
	TEXT("Map2_Title=محور بستان وممرّ تشازبه\n")
	TEXT("Map2_Status=جارٍ التحضير\n")
	TEXT("Map3_Title=خرمشهر وشاطئ أروند\n")
	TEXT("Map3_Status=جارٍ التحضير\n")
	TEXT("; Map1..3_Briefing= — translate the one-line mission briefings here if desired.\n")
	TEXT("\n")
	TEXT("[Traits.ar]\n")
	TEXT("Trait1_Name=إخماد مناطقي\n")
	TEXT("Trait2_Name=الثبات في الصحراء\n")
	TEXT("Trait3_Name=العيار الثقيل\n")
	TEXT("Trait4_Name=صياد الدبابات\n")
	TEXT("Trait5_Name=القناص الصامت\n")
	TEXT("; Trait1..5_Desc= — translate trait descriptions here if desired.\n")
	TEXT("\n")
	TEXT("[Profile.ar]\n")
	TEXT("HeaderTitle=ملف المقاتل العسكري والرتبة\n")
	TEXT("CallsignLabel=الاسم الحركي / رمز التعريف:\n")
	TEXT("KillsLabel=عدد عمليات تحييد العدو:\n")
	TEXT("TanksLabel=الدبابات المدمَّرة:\n")
	TEXT("RevivesLabel=إسعاف وإحياء الرفاق:\n")
	TEXT("TimeLabel=مدة الحضور في الجبهة:\n")
	TEXT("ScoreLabel=نقاط الشجاعة:\n")
	TEXT("HeadshotsLabel=طلقات الرأس:\n");
}

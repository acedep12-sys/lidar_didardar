// LeaderCharacter.cpp — Squad leader with waypoints, player pacing
#include "Characters/LeaderCharacter.h"
#include "Diagnostics/SquadAISituationLog.h"   // S19-LOGGER
#include "Components/HealthComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Kismet/GameplayStatics.h"
#include "SquadAITuning.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "Quest/QuestDirector.h"
#include "Quest/QuestMission.h"
#include "Quest/QuestObjective.h"
#include "Performance/SoldierRegistrySubsystem.h"
#include "AI/SoldierAIController.h"
#include "Components/AimComponent.h"

ALeaderCharacter::ALeaderCharacter()
{
	Faction = ESquadFaction::Ally;
	TeamId = FGenericTeamId(0);
	AccuracyMultiplier = 0.55f; 
	bCanBeDowned = false; // Heroic squad leader cannot be downed / never shows revive prompt
	if (HealthComp)
	{
		HealthComp->bInvincible = true;
		HealthComp->MaxHealth = 180.f;
		HealthComp->CurrentHealth = HealthComp->MaxHealth;
		HealthComp->InvincibleMinHealth = HealthComp->MaxHealth;
	}
	CharacterDisplayName = FText::FromString(TEXT("سرگرد شهید ایرج رستمی"));

	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.bStartWithTickEnabled = true;
	PrimaryActorTick.TickInterval = 0.25f; 
}

void ALeaderCharacter::BeginPlay()
{
	Super::BeginPlay();

	const USquadAITuning* T = USquadAITuning::Get();

	if (HealthComp)
	{
		HealthComp->bInvincible = true;
		HealthComp->MaxHealth = 180.f;
		HealthComp->CurrentHealth = HealthComp->MaxHealth;
		HealthComp->InvincibleMinHealth = HealthComp->MaxHealth;
	}

	WaitForPlayerRadius = T->LeaderWaitForPlayerRadius;
	FullSpeedRadius = T->LeaderFullSpeedRadius;
	NormalSpeed = T->LeaderNormalSpeed;
	WaitingSpeed = T->LeaderWaitingSpeed;
	UpdatePresentationState();
}

void ALeaderCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	// Squad Commander (Major Shahid Iraj Rostami) is heroic and immortal — never downed, never dead
	bIsDowned = false;
	bCanBeDowned = false;
	if (HealthComp)
	{
		HealthComp->bInvincible = true;
		HealthComp->bIsDead = false;
		HealthComp->InvincibleMinHealth = HealthComp->MaxHealth;
		HealthComp->CurrentHealth = HealthComp->MaxHealth;
	}

	UpdatePacing();
	UpdateWaypointState(DeltaTime);

	// S19-LOGGER: second host for the situation log (the player combat bridge is the
	// first). The snapshot throttle is shared, so only one of the two writes per period.
	SquadAISituation::Tick(GetWorld(), DeltaTime);

	PresentationUpdateAccumulator += DeltaTime;
	if (PresentationUpdateAccumulator >= GetPresentationUpdateInterval())
	{
		PresentationUpdateAccumulator = 0.f;
		UpdatePresentationState();
	}
}

void ALeaderCharacter::UpdatePacing()
{
	UCharacterMovementComponent* CMC = GetCharacterMovement();
	if (!CMC) return;

	APawn* Player = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	if (!Player) 
	{
		CMC->MaxWalkSpeed = NormalSpeed;
		return;
	}

	const float PlayerDist = GetPlayerDistance();

	// S19-LEADWAIT: this used to zero MaxWalkSpeed for ANY distance above
	// WaitForPlayerRadius. That is right when the player has fallen BEHIND (the
	// leader waits for him), but it is exactly backwards when the player has run
	// AHEAD: the leader then froze on the spot instead of following the player to
	// the quest zone - "leave him for a while and he stops going to the objective".
	// Distance alone cannot tell those two apart, so compare who is closer to the
	// current objective.
	const bool bPlayerAhead = (PlayerDist > WaitForPlayerRadius) && IsPlayerAheadOnRoute(Player);

	if (ShouldHaltForPlayer(PlayerDist))
	{
		CMC->MaxWalkSpeed = 0.f;
	}
	else if (bForceSprintThroughHazard || (bPlayerAhead && PlayerDist > FullSpeedRadius))
	{
		CMC->MaxWalkSpeed = SprintSpeed;
	}
	else
	{
		float Walk = NormalSpeed;
		if (const ASoldierAIController* AIC = Cast<ASoldierAIController>(GetController()))
		{
			Walk *= FMath::Clamp(AIC->PathSpeedScale, 0.45f, 1.f);
		}
		if (PlayerDist > FullSpeedRadius)
		{
			const float Alpha = FMath::Clamp((PlayerDist - FullSpeedRadius) / FMath::Max(1.f, WaitForPlayerRadius - FullSpeedRadius), 0.f, 1.f);
			CMC->MaxWalkSpeed = FMath::Lerp(Walk, WaitingSpeed, Alpha);
		}
		else CMC->MaxWalkSpeed = Walk;
	}
}

// S19-LEADWAIT: "is the player between me and the objective?" - the question the
// pacing code actually needs. Distance alone cannot distinguish "player is slow,
// wait for him" from "player ran off to the objective, catch up", and treating
// the second one as the first is what pinned the leader in place.
bool ALeaderCharacter::ShouldHaltForPlayer(float PlayerDist)
{
	const float Now = GetWorld() ? GetWorld()->GetTimeSeconds() : 0.f;

	// S19-LOGGER: report every change of the pacing decision, with the reason, so the
	// log shows "leader stopped / leader resumed" instead of an unexplained standstill.
	auto SetDecision = [this, Now](bool bHalt, const TCHAR* Reason, float Dist)
	{
		if (bLastPacingHalt == bHalt) return;
		const TCHAR* From = bLastPacingHalt ? TEXT("HALT") : TEXT("MOVE");
		const TCHAR* To   = bHalt ? TEXT("HALT") : TEXT("MOVE");
		bLastPacingHalt = bHalt;
		SquadAISituation::Note(FString::Printf(
			TEXT("LEADER-PACING %s -> %s (%s, playerDist=%.0f, t=%.1f)"),
			From, To, Reason, Dist, Now));
	};

	// Inside the leash radius the squad is coherent: nothing to wait for.
	const float Radius = FMath::Max(400.f, WaitForPlayerRadius);
	// S19-LEASHHYST: while already halted, demand a real catch-up before resuming or the
	// leader flaps HALT/MOVE at the boundary (live log: 1459..1559 around a 1500 radius).
	const float ResumeRadius = bLastPacingHalt
		? Radius * FMath::Clamp(WaitForPlayerResumeFraction, 0.4f, 0.95f)
		: Radius;
	if (PlayerDist <= ResumeRadius)
	{
		PacingWaitStartTime = -1.f;
		SetDecision(false, (bLastPacingHalt && ResumeRadius < Radius)
			? TEXT("player caught up properly inside the resumed leash radius")
			: TEXT("player inside the leash radius"), PlayerDist);
		return false;
	}

	// Player is AHEAD of us on the route: he is not waiting for the squad, he is
	// racing it (or already at the objective). Follow him instead of freezing.
	if (const APawn* Player = UGameplayStatics::GetPlayerPawn(GetWorld(), 0))
	{
		if (IsPlayerAheadOnRoute(Player))
		{
			PacingWaitStartTime = -1.f;
			SetDecision(false, TEXT("player is ahead of us on the route"), PlayerDist);
			return false;
		}
	}

	if (PacingWaitStartTime < 0.f)
	{
		PacingWaitStartTime = Now;
		SetDecision(true, TEXT("player is behind and outside the leash radius"), PlayerDist);
	}

	// Bounded wait: after MaxWaitForPlayerSeconds the squad advances regardless.
	// Without this, a player who parks somewhere (or dies out of range) leaves the
	// leader standing at the leash edge for the rest of the mission.
	if ((Now - PacingWaitStartTime) > MaxWaitForPlayerSeconds)
	{
		if ((Now - LastPacingResumeLogTime) > 5.f)
		{
			LastPacingResumeLogTime = Now;
			UE_LOG(LogTemp, Warning, TEXT("[S19-LEADWAIT] %s: waited %.0fs for the player at dist=%.0f - resuming mission travel"),
				*GetName(), Now - PacingWaitStartTime, PlayerDist);
		}
		SetDecision(false, TEXT("bounded wait expired - the squad advances"), PlayerDist);
		return false;
	}

	return true;
}

float ALeaderCharacter::GetPacingWaitSeconds() const
{
	if (PacingWaitStartTime < 0.f) return 0.f;
	const float Now = GetWorld() ? GetWorld()->GetTimeSeconds() : 0.f;
	return FMath::Max(0.f, Now - PacingWaitStartTime);
}

bool ALeaderCharacter::IsPlayerAheadOnRoute(const APawn* Player) const
{
	if (!Player) return false;

	FVector Goal = FVector::ZeroVector;
	if (const ASoldierAIController* AIC = Cast<ASoldierAIController>(GetController()))
	{
		Goal = AIC->GetEffectiveMoveGoal();
	}
	if (Goal.IsNearlyZero()) return false; // no objective: keep the classic wait

	const float MeToGoal = FVector::Dist2D(GetActorLocation(), Goal);
	const float PlayerToGoal = FVector::Dist2D(Player->GetActorLocation(), Goal);
	// Margin so two pawns walking side by side do not flip the mode every tick.
	return (PlayerToGoal + 300.f) < MeToGoal;
}

void ALeaderCharacter::UpdateWaypointState(float DeltaTime)
{
	if (IsQuestComplete() || QuestWaypoints.Num() == 0) return;

	switch (WaypointState)
	{
	case ELeaderWaypointState::NotReached:
	case ELeaderWaypointState::Moving:
		if (HasReachedCurrentWaypoint())
		{
			WaypointState = ELeaderWaypointState::Arrived;
			LingerTimer = 0.f;
		}
		break;
	case ELeaderWaypointState::Arrived:
	{
		const FQuestWaypoint& WP = QuestWaypoints[CurrentWaypointIndex];
		if (WP.bRequireAreaClear) WaypointState = ELeaderWaypointState::WaitingForClear;
		else { LingerTimer += DeltaTime; if (LingerTimer >= WP.LingerSeconds) AdvanceToNextWaypoint(); }
		break;
	}
	case ELeaderWaypointState::WaitingForClear:
		if (IsCurrentAreaClear()) { const FQuestWaypoint& WP = QuestWaypoints[CurrentWaypointIndex]; LingerTimer += DeltaTime; if (LingerTimer >= WP.LingerSeconds) AdvanceToNextWaypoint(); }
		else LingerTimer = 0.f;
		break;
	}
}

void ALeaderCharacter::SetQuestWaypoints(const TArray<FQuestWaypoint>& Waypoints)
{
	QuestWaypoints = Waypoints;
	CurrentWaypointIndex = 0;
	WaypointState = QuestWaypoints.Num() > 0 ? ELeaderWaypointState::NotReached : ELeaderWaypointState::Completed;
	LingerTimer = 0.f;
	UpdatePresentationState();
}

void ALeaderCharacter::BeginQuest()
{
	if (QuestWaypoints.Num() > 0)
	{
		WaypointState = ELeaderWaypointState::Moving;
		LingerTimer = 0.f;
		UpdatePresentationState();
	}
}

bool ALeaderCharacter::AdvanceToNextWaypoint()
{
	CurrentWaypointIndex++;
	LingerTimer = 0.f;
	if (CurrentWaypointIndex >= QuestWaypoints.Num()) { WaypointState = ELeaderWaypointState::Completed; return false; }
	WaypointState = ELeaderWaypointState::Moving;
	return true;
}

bool ALeaderCharacter::HasReachedCurrentWaypoint() const
{
	if (CurrentWaypointIndex >= QuestWaypoints.Num()) return false;
	const FVector WPLoc = QuestWaypoints[CurrentWaypointIndex].Location;
	return FVector::Dist(GetActorLocation(), WPLoc) <= QuestWaypoints[CurrentWaypointIndex].AcceptanceRadius;
}

bool ALeaderCharacter::IsCurrentAreaClear() const
{
	if (CurrentWaypointIndex >= QuestWaypoints.Num()) return true;
	const FQuestWaypoint& WP = QuestWaypoints[CurrentWaypointIndex];
	USoldierRegistrySubsystem* Reg = GetWorld()->GetSubsystem<USoldierRegistrySubsystem>();
	if (!Reg) return true;
	return Reg->CountHostilesNear(WP.Location, WP.AreaClearRadius, GetGenericTeamId().GetId()) == 0;
}

FVector ALeaderCharacter::GetCurrentWaypointLocation() const
{
	if (CurrentWaypointIndex >= QuestWaypoints.Num()) return GetActorLocation();
	return QuestWaypoints[CurrentWaypointIndex].Location;
}

float ALeaderCharacter::GetPlayerDistance() const
{
	APawn* Player = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	return Player ? FVector::Dist(GetActorLocation(), Player->GetActorLocation()) : 0.f;
}

bool ALeaderCharacter::IsWaitingForPlayer() const
{
	return GetPlayerDistance() > WaitForPlayerRadius;
}

bool ALeaderCharacter::IsQuestComplete() const { return WaypointState == ELeaderWaypointState::Completed; }

bool ALeaderCharacter::HasPresentationMoveGoal() const
{
	return bPresentationHasQuest && !PresentationMoveGoal.IsNearlyZero();
}

bool ALeaderCharacter::HasPresentationWaypointIndex() const
{
	return PresentationWaypointIndex != INDEX_NONE && QuestWaypoints.IsValidIndex(PresentationWaypointIndex);
}

bool ALeaderCharacter::IsPresentationFollowingMissionPath() const
{
	return bPresentationHasQuest && !bPresentationWaitingForPlayer && !bPresentationReachedWaypoint && !bPresentationCombatReady && !bPresentationAiming && !bPresentationFiring;
}

bool ALeaderCharacter::IsPresentationHoldingForCombat() const
{
	return bPresentationCombatReady || bPresentationAiming || bPresentationFiring;
}

bool ALeaderCharacter::IsPresentationAtMissionEnd() const
{
	return QuestWaypoints.Num() > 0 && IsQuestComplete();
}

FText ALeaderCharacter::GetPresentationDebugStateText() const
{
	if (!IsAlive())
	{
		return FText::FromString(TEXT("Dead"));
	}
	if (IsPresentationHoldingForCombat())
	{
		return FText::FromString(TEXT("Combat"));
	}
	if (bPresentationWaitingForPlayer)
	{
		return FText::FromString(TEXT("WaitingForPlayer"));
	}
	if (QuestWaypoints.Num() > 0)
	{
		if (IsQuestComplete())
		{
			return FText::FromString(TEXT("QuestComplete"));
		}
		if (bPresentationReachedWaypoint)
		{
			return bPresentationAreaClear ? FText::FromString(TEXT("WaypointClear")) : FText::FromString(TEXT("WaypointContested"));
		}
		return FText::FromString(TEXT("FollowingWaypoint"));
	}
	return FText::FromString(TEXT("Idle"));
}

FLeaderQuestProgressSnapshot ALeaderCharacter::GetQuestProgressSnapshot() const
{
	FLeaderQuestProgressSnapshot Snapshot;
	Snapshot.bQuestActive = QuestWaypoints.Num() > 0 && WaypointState != ELeaderWaypointState::Completed;
	Snapshot.bReachedCurrentWaypoint = HasReachedCurrentWaypoint();
	Snapshot.bCurrentAreaClear = IsCurrentAreaClear();
	Snapshot.bQuestComplete = IsQuestComplete();
	Snapshot.CurrentWaypointIndex = CurrentWaypointIndex;
	Snapshot.CurrentWaypointLocation = GetCurrentWaypointLocation();
	return Snapshot;
}

float ALeaderCharacter::GetPresentationUpdateInterval() const
{
	if (const ASoldierAIController* AIC = Cast<ASoldierAIController>(GetController()))
	{
		switch (AIC->CurrentLODBucket)
		{
		case 0:
		case 1:
			return 0.1f;
		case 2:
			return 0.2f;
		case 3:
			return 0.35f;
		case 4:
			return 0.5f;
		default:
			return 0.75f;
		}
	}

	return 0.2f;
}

void ALeaderCharacter::UpdatePresentationState()
{
	bPresentationHasQuest = QuestWaypoints.Num() > 0 && !IsQuestComplete();
	PresentationMoveGoal = GetCurrentWaypointLocation();
	PresentationPlayerDistance = GetPlayerDistance();
	bPresentationWaitingForPlayer = IsWaitingForPlayer();
	bPresentationReachedWaypoint = HasReachedCurrentWaypoint();
	bPresentationAreaClear = IsCurrentAreaClear();
	PresentationWaypointIndex = CurrentWaypointIndex;
	bPresentationFiring = bWantsToFire;
	bPresentationAiming = AimComp && AimComp->bHasTarget;
	bPresentationCombatReady = false;
	if (const ASoldierAIController* AIC = Cast<ASoldierAIController>(GetController()))
	{
		bPresentationCombatReady = AIC->HasCombatThreat(0.25f);
	}

	if (!IsAlive())
	{
		PresentationState = ESquadCombatPresentationState::Dead;
	}
	else if (bPresentationFiring)
	{
		PresentationState = ESquadCombatPresentationState::Firing;
	}
	else if (bPresentationAiming || bPresentationCombatReady)
	{
		PresentationState = ESquadCombatPresentationState::Aiming;
	}
	else if (GetVelocity().SizeSquared2D() > FMath::Square(10.f))
	{
		PresentationState = ESquadCombatPresentationState::Moving;
	}
	else
	{
		PresentationState = ESquadCombatPresentationState::Idle;
	}
}

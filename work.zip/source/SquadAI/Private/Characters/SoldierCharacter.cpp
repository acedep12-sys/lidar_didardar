// SoldierCharacter.cpp — Base soldier with components, faction, cover state
#include "Characters/SoldierCharacter.h"
#include "Performance/SquadAIRecovery.h"   // S19-DEATHPOSE/S19-PACKALIVE
#include "Diagnostics/SquadAISituationLog.h"   // S19-LOGGER
#include "Characters/SquadAIGripRetarget.h" // S18-GRIP
#include "AI/SoldierAIController.h"
#include "Performance/DifficultySubsystem.h"
#include "Components/AimComponent.h"
#include "Components/WeaponComponent.h"
#include "Components/HealthComponent.h"
#include "Components/TacticalGrenadeComponent.h"
#include "Components/SquadAIAdapterComponent.h"
#include "Characters/SquadLeaderTypes.h"
#include "Performance/AISignificanceManager.h"
#include "Performance/SoldierRegistrySubsystem.h"
#include "Perception/AIPerceptionStimuliSourceComponent.h"
#include "Perception/AISense_Sight.h"
#include "Perception/AISense_Hearing.h"
#include "Perception/AISense_Damage.h"
#include "Components/CapsuleComponent.h"
#include "Components/StateTreeAIComponent.h"
#include "Components/MeshComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "NavigationInvokerComponent.h"
#include "NavigationSystem.h"
#include "Animation/AnimInstance.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/SkeletalMesh.h"
#include "Engine/SkeletalMeshSocket.h" // S17-GRIP2
#include "Animation/Skeleton.h" // S17-GRIP3
#include "Engine/DamageEvents.h"
#include "TimerManager.h"
#include "GameFramework/SquadAIProgressionSubsystem.h"
#include "Performance/SquadAICinematicCombatSubsystem.h"
#include "SquadAITuning.h"
#include "Performance/SquadAIAudioSubsystem.h"
#include "HUD/QuestNativeHUD.h"
#include "Characters/LeaderCharacter.h"
#include "Engine/World.h"
#include "UObject/UnrealType.h"

ASoldierCharacter::ASoldierCharacter()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.bStartWithTickEnabled = false;
	PrimaryActorTick.TickInterval = 0.5f;

	AIControllerClass = ASoldierAIController::StaticClass();
	AutoPossessAI = EAutoPossessAI::PlacedInWorldOrSpawned;

	AimComp = CreateDefaultSubobject<UAimComponent>(TEXT("AimComp"));
	WeaponComp = CreateDefaultSubobject<UWeaponComponent>(TEXT("WeaponComp"));
	HealthComp = CreateDefaultSubobject<UHealthComponent>(TEXT("HealthComp"));
	GrenadeComp = CreateDefaultSubobject<UTacticalGrenadeComponent>(TEXT("GrenadeComp"));
	AIAdapterComp = CreateDefaultSubobject<USquadAIAdapterComponent>(TEXT("SquadAIAdapter"));

	bUseControllerRotationYaw = false;
	if (UCharacterMovementComponent* CMC = GetCharacterMovement())
	{
		CMC->bOrientRotationToMovement = true;
		CMC->bUseControllerDesiredRotation = true;
		CMC->RotationRate = FRotator(0.f, 720.f, 0.f);
		CMC->bRequestedMoveUseAcceleration = true;
		CMC->MaxWalkSpeed = 400.f;
		CMC->MaxStepHeight = 40.f;
		CMC->GetNavAgentPropertiesRef().bCanCrouch = true;
		CMC->SetCrouchedHalfHeight(44.f);
	}

	PerceptionStimuli = CreateDefaultSubobject<UAIPerceptionStimuliSourceComponent>(TEXT("PerceptionStimuli"));
	PerceptionStimuli->bAutoRegister = true;
	PerceptionStimuli->RegisterForSense(UAISense_Sight::StaticClass());
	PerceptionStimuli->RegisterForSense(UAISense_Hearing::StaticClass());
	PerceptionStimuli->RegisterForSense(UAISense_Damage::StaticClass());

	// Navigation Invoker — generates NavMesh dynamically around this character.
	NavInvoker = CreateDefaultSubobject<UNavigationInvokerComponent>(TEXT("NavInvoker"));

	TeamId = FGenericTeamId(1);
}

void ASoldierCharacter::BeginPlay()
{
	Super::BeginPlay();

	// Heroic squad leader (Shahid Rostami) and enemies cannot be downed
	if (IsSquadLeader() || Faction == ESquadFaction::Enemy)
	{
		bCanBeDowned = false;
	}
	else if (Faction == ESquadFaction::Ally)
	{
		bCanBeDowned = true;
	}

	// G-1: normalize leader recognition so name/tag checks work even if the level
	// designer forgot the tag (pack BPs are otherwise indistinguishable).
	if (bIsSquadLeaderOverride || IsA<ALeaderCharacter>() || GetName().Contains(TEXT("Rostami")))
	{
		Tags.AddUnique(TEXT("Leader"));
	}

	// Pack damage uses a timer, not actor Tick. Leader/Ally enable their own tick.
	// Do not force a tick on every wave enemy.

	// Initial combat grace period (4.5s) to allow player/squad assessment upon level start/respawn
	ResetSpawnGracePeriod(4.5f);

	// S18-GRIP: pack Blueprints often swap the body mesh (your V3 swap) or spawn
	// the weapon AFTER BeginPlay, and the attachment was only applied when
	// SetEquippedWeaponMesh happened to be called. Re-apply on the next tick so
	// the grip is correct no matter which order things initialise in.
	if (UWorld* W = GetWorld())
	{
		FTimerHandle GripReapplyHandle;
		W->GetTimerManager().SetTimer(GripReapplyHandle, FTimerDelegate::CreateWeakLambda(this, [this]()
		{
			ApplyEquippedWeaponAttachment();
		}), 0.1f, false);
	}

	// Pack damage bridge: use timer instead of Tick (Blueprints override Tick)
	if (bUsePackPresentationMode && HealthComp)
	{
		bPackHealthSearchFailed = false;
		// Heroes poll faster so a one-shot pack kill is clamped before the pack plays death.
		const float BridgeInterval = (IsSquadLeader() || IsAlly()) ? 0.15f : 0.5f;
		GetWorldTimerManager().SetTimer(PackDamageBridgeTimerHandle, this,

			&ASoldierCharacter::SyncPackHealthToSquadAI, BridgeInterval, true);
		UE_LOG(LogTemp, Warning, TEXT("[DamageBridge] %s: Started pack damage bridge timer (0.5s)"), *GetName());
	}

	// Custom damage system: bind to OnTakeAnyDamage to catch ALL damage sources
	if (bUsePackPresentationMode)
	{
		OnTakeAnyDamage.AddDynamic(this, &ASoldierCharacter::OnAnyDamageReceived);
		UE_LOG(LogTemp, Warning, TEXT("[DamageSystem] %s: Bound OnTakeAnyDamage"), *GetName());
	}

	// Override NavInvoker radii
	if (NavInvoker && GetWorld())
	{
		if (UNavigationSystemV1* NavSys = FNavigationSystem::GetCurrent<UNavigationSystemV1>(GetWorld()))
		{
			// Step2 residual: Tuning-owned radii (were hardcoded 20000/30000 tile-gen spam).
			const USquadAITuning* NavTune = USquadAITuning::Get();
			NavSys->RegisterNavigationInvoker(*this, NavTune->NavInvokerRadius, NavTune->NavInvokerRemovalRadius);
		}
	}

	// CRITICAL: Disable navigation affecting on ALL components.
	// Any component with bCanEverAffectNavigation = true corrupts NavMesh.
	{
		TArray<UActorComponent*> AllComps;
		GetComponents(AllComps);
		for (UActorComponent* Comp : AllComps)
		{
			if (UPrimitiveComponent* Prim = Cast<UPrimitiveComponent>(Comp))
			{
				Prim->SetCanEverAffectNavigation(false);
			}
		}
	}

	if (UCharacterMovementComponent* CMC = GetCharacterMovement())
	{
		CMC->GetNavAgentPropertiesRef().bCanCrouch = true;
		CMC->SetCrouchedHalfHeight(44.f);
	}

	TeamId = (Faction == ESquadFaction::Enemy) ? FGenericTeamId(1) : FGenericTeamId(0);

	if (AIAdapterComp)
	{
		AIAdapterComp->InitializeForOwner();
		AIAdapterComp->EnablePackSafeMode(bUsePackPresentationMode);
	}

	if (bUsePackPresentationMode)
	{
		if (UCapsuleComponent* Cap = GetCapsuleComponent())
		{
			Cap->ComponentTags.AddUnique(TEXT("TPWCS_RagdollCapsule"));
		}
		if (UMeshComponent* WMesh = GetEquippedWeaponVisual())
		{
			WMesh->ComponentTags.AddUnique(TEXT("TPWCS_WeaponMesh"));
		}
	}

	if (ASoldierAIController* AIC = Cast<ASoldierAIController>(GetController()))
	{
		AIC->SetGenericTeamId(TeamId);
	}

	RegisterWithSystems();
	if (WeaponComp) WeaponComp->AccuracyMultiplier = AccuracyMultiplier;
	if (HealthComp) HealthComp->OnDeath.AddDynamic(this, &ASoldierCharacter::OnHealthDied);

	// Apply Player Progression Upgrades (Speed, Health, Recoil) if Player Controlled
	if (IsPlayerControlled())
	{
		if (USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(this))
		{
			if (UCharacterMovementComponent* CMC = GetCharacterMovement())
			{
				CMC->MaxWalkSpeed *= Prog->GetSpeedMultiplier();
			}
			if (HealthComp)
			{
				const float BonusHP = Prog->GetMaxHealthBonus();
				HealthComp->MaxHealth += BonusHP;
				HealthComp->CurrentHealth += BonusHP;
			}
			if (WeaponComp)
			{
				WeaponComp->AccuracyMultiplier *= (2.0f - Prog->GetRecoilMultiplier());
			}
		}
	}

	// Lyra/City Sample: URO on by default for wave enemies so the first 0.25s
	// before significance eval is not full-rate anim+bones.
	if (Faction == ESquadFaction::Enemy)
	{
		if (USkeletalMeshComponent* Skel = GetMesh())
		{
			Skel->bEnableUpdateRateOptimizations = true;
			Skel->bComponentUseFixedSkelBounds = true;
			Skel->VisibilityBasedAnimTickOption = EVisibilityBasedAnimTickOption::AlwaysTickPose;
		}
	}
}

// DamageBridgeMethods.inc — Add to SoldierCharacter.cpp after RegisterWithSystems()
// These methods bridge TPWCS pack damage to SquadAI HealthComponent


void ASoldierCharacter::InitPackHealthBridge()
{
	if (bPackDamageDelegateBound) return;

	// Find pack health component
	if (!CachedPackHealthComp)
	{
		TArray<UActorComponent*> Comps;
		GetComponents(Comps);
		for (UActorComponent* C : Comps)
		{
			if (!C) continue;
			const FString N = C->GetName();
			if (N.Contains(TEXT("BPC_Health")))
			{
				CachedPackHealthComp = C;
				break;
			}
		}
	}
	if (!CachedPackHealthComp) return;

	// Initialize last known health
	if (LastPackHealth < 0.f)
	{
		for (const FName& N : { FName(TEXT("currentHealth")), FName(TEXT("CurrentHealth")), FName(TEXT("Current Health")), FName(TEXT("Health")) })
		{
			// Pack uses double, not float
			if (FDoubleProperty* DP = FindFProperty<FDoubleProperty>(CachedPackHealthComp->GetClass(), N))
			{
				LastPackHealth = static_cast<float>(DP->GetPropertyValue_InContainer(CachedPackHealthComp));
				break;
			}
			if (FFloatProperty* P = FindFProperty<FFloatProperty>(CachedPackHealthComp->GetClass(), N))
			{
				LastPackHealth = P->GetPropertyValue_InContainer(CachedPackHealthComp);
				break;
			}
		}
	}

	// Try to bind to OnDamaged delegate via reflection
	for (const FName& DelegateName : { FName(TEXT("OnDamaged")), FName(TEXT("OnHealthChanged")), FName(TEXT("OnHit")) })
	{
		FMulticastDelegateProperty* DelegateProp = FindFProperty<FMulticastDelegateProperty>(
			CachedPackHealthComp->GetClass(), DelegateName);
		if (DelegateProp)
		{
			UE_LOG(LogTemp, Warning, TEXT("[DamageBridge] %s: Found pack delegate '%s' on %s — binding via TakeDamage override"),
				*GetName(), *DelegateName.ToString(), *CachedPackHealthComp->GetName());
			bPackDamageDelegateBound = true;
			break;
		}
	}

	// Fallback: just mark as bound (TakeDamage override handles the rest)
	bPackDamageDelegateBound = true;
}

void ASoldierCharacter::SyncPackHealthToSquadAI()
{
	if (!HealthComp) return;
	if (bPackHealthSearchFailed) return;  // Already searched and failed — stop trying

	// Find pack health component
	if (!CachedPackHealthComp)
	{
		TArray<UActorComponent*> Comps;
		GetComponents(Comps);
		for (UActorComponent* C : Comps)
		{
			if (!C) continue;
			const FString N = C->GetName();
			const FString CN = C->GetClass() ? C->GetClass()->GetName() : FString();
			// Prioritize pack health (BPC_Health) over SquadAI health (HealthComp)
			if (N.Contains(TEXT("BPC_Health")))
			{
				CachedPackHealthComp = C;
				UE_LOG(LogTemp, Warning, TEXT("[DamageBridge] %s: Found pack health: %s (%s)"), *GetName(), *N, *CN);
				break;
			}
		}
		// Fallback: look for ANY health component that is NOT HealthComp
		if (!CachedPackHealthComp)
		{
			for (UActorComponent* C : Comps)
			{
				if (!C) continue;
				const FString N2 = C->GetName();
				const FString CN2 = C->GetClass() ? C->GetClass()->GetName() : FString();
				if ((N2.Contains(TEXT("Health")) || CN2.Contains(TEXT("Health"))) && !N2.Contains(TEXT("HealthComp")))
				{
					CachedPackHealthComp = C;
					UE_LOG(LogTemp, Warning, TEXT("[DamageBridge] %s: Fallback health: %s (%s)"), *GetName(), *N2, *CN2);
					break;
				}
			}
		}
		if (!CachedPackHealthComp)
		{
			// Never permanently disable: pack components can register late (level streaming,
			// possession changes) and the HUD health bar depends on this sync. Keep polling.
			static int32 WarnCount = 0;
			if (WarnCount < 5)
			{
				++WarnCount;
				UE_LOG(LogTemp, Warning, TEXT("[DamageBridge] %s: pack health component not found yet, will keep retrying."), *GetName());
			}
		}
	}

	if (!CachedPackHealthComp) return;

	// Read pack health via reflection
	float PackHealth = -1.f;
	bool bFoundProp = false;
	for (const FName& N : {
		FName(TEXT("currentHealth")), FName(TEXT("CurrentHealth")), FName(TEXT("Current Health")),
		FName(TEXT("Health")), FName(TEXT("health")), FName(TEXT("HP")),
		FName(TEXT("currentHP")), FName(TEXT("CurrentHP"))
	})
	{
		// FIX: Check FDoubleProperty (pack uses double, not float)
		if (FDoubleProperty* DP = FindFProperty<FDoubleProperty>(CachedPackHealthComp->GetClass(), N))
		{
			PackHealth = static_cast<float>(DP->GetPropertyValue_InContainer(CachedPackHealthComp));
			bFoundProp = true;
			break;
		}
		if (FFloatProperty* P = FindFProperty<FFloatProperty>(CachedPackHealthComp->GetClass(), N))
		{
			PackHealth = P->GetPropertyValue_InContainer(CachedPackHealthComp);
			bFoundProp = true;
			break;
		}
		if (FIntProperty* IP = FindFProperty<FIntProperty>(CachedPackHealthComp->GetClass(), N))
		{
			PackHealth = static_cast<float>(IP->GetPropertyValue_InContainer(CachedPackHealthComp));
			bFoundProp = true;
			break;
		}
	}

	if (!bFoundProp)
	{
		static bool bDumped = false;
		if (!bDumped)
		{
			bDumped = true;
			UE_LOG(LogTemp, Error, TEXT("[DamageBridge] %s: NO health prop on %s (%s). ALL properties:"),
				*GetName(), *CachedPackHealthComp->GetName(), *CachedPackHealthComp->GetClass()->GetName());
			for (TFieldIterator<FProperty> It(CachedPackHealthComp->GetClass()); It; ++It)
			{
				FProperty* P = *It;
				if (!P) continue;
				FString Val;
				const void* Ptr = P->ContainerPtrToValuePtr<void>(CachedPackHealthComp);
				P->ExportTextItem_Direct(Val, Ptr, nullptr, nullptr, PPF_None);
				UE_LOG(LogTemp, Warning, TEXT("[DamageBridge]   %s %s = %s"), *P->GetCPPType(), *P->GetName(), *Val);
			}
		}
		return;
	}

	// First read
	if (LastPackHealth < 0.f)
	{
		LastPackHealth = PackHealth;
		if (HealthComp)
		{
			HealthComp->MaxHealth = FMath::Max(PackHealth, HealthComp->MaxHealth);
			HealthComp->CurrentHealth = PackHealth;
		}
		UE_LOG(LogTemp, Warning, TEXT("[DamageBridge] %s: Init health=%.1f squadai=%.1f"),
			*GetName(), PackHealth, HealthComp ? HealthComp->CurrentHealth : 0.f);
		return;
	}

	// Damage detected
	if (PackHealth < LastPackHealth)
	{
		float Damage = LastPackHealth - PackHealth;
		UE_LOG(LogTemp, Verbose, TEXT("[DamageBridge] %s: HIT %.1f (pack %.1f->%.1f, squad %.1f)"),
			*GetName(), Damage, LastPackHealth, PackHealth, HealthComp ? HealthComp->CurrentHealth : 0.f);

		if (HasSpawnGracePeriod() && !IsEnemy())
		{
			// Spawn grace: forgive pack-side too so both layers stay in sync (ApplyDamage
			// below already ignores SquadAI-side damage during grace).
			RestorePackHealth(LastPackHealth);
			PackHealth = LastPackHealth;
		}
		else
		{
			// Clamp pack-side health for heroes so the TPWCS pack never plays its own death
			// sequence (mesh hide/ragdoll) while SquadAI still considers them alive/downable.
			// The missing ally clamp was the "revived ally vanishes" mechanism.
			if (IsSquadLeader())
			{
				// G-1: pack-side death bypass — a one-shot can zero pack HP between 0.15s
				// polls. Resurrect the pack side (veto twin), then clamp.
				const float LeaderFloor = USquadAITuning::Get()->LeaderPackHealthFloor;
				if (PackHealth <= 0.f)
				{
					RestorePackHealth(LeaderFloor);
					ResetPackDeathFlags(false);
					PackHealth = LeaderFloor;
					UE_LOG(LogTemp, Warning, TEXT("[DamageBridge] %s: leader pack-side veto (one-shot bypass)"), *GetName());
				}
				ClampPackHealthMinimum(LeaderFloor);
			}
			else if (IsAlly())
			{
				ClampPackHealthMinimum(USquadAITuning::Get()->AllyPackHealthFloor);
			}
		}

		if (HealthComp && HealthComp->IsAlive())
		{
			// Route through the damage chokepoint so downed/death rules, grace, leader
			// immortality, damage events and AI stimuli all behave. This used to set bIsDead
			// by hand, bypassing ApplyDamage and sticking allies permanently dead.
			HealthComp->ApplyDamage(Damage, nullptr);
		}
	}
	else if (PackHealth > LastPackHealth)
	{
		// Pack health increased (healed/revived)
		if (HealthComp)
		{
			HealthComp->CurrentHealth = FMath::Max(HealthComp->CurrentHealth, PackHealth);
			HealthComp->bIsDead = false;
		}
	}
	LastPackHealth = PackHealth;
}
void ASoldierCharacter::ClampPackHealthMinimum(float MinHealth)
{
	if (!CachedPackHealthComp)
	{
		// G-1: silent no-op hid "leader dies" configs — say it once.
		static bool bG1WarnedNullPack = false;
		if (!bG1WarnedNullPack)
		{
			bG1WarnedNullPack = true;
			UE_LOG(LogTemp, Error, TEXT("[DamageBridge] %s: ClampPackHealthMinimum with NO pack health component (hero unprotected pack-side)."), *GetName());
		}
		return;
	}
	if (MinHealth <= 0.f) return;
	for (const FName& N : { FName(TEXT("currentHealth")), FName(TEXT("CurrentHealth")), FName(TEXT("Current Health")), FName(TEXT("Health")), FName(TEXT("health")), FName(TEXT("HP")), FName(TEXT("currentHP")), FName(TEXT("CurrentHP")) })
	{
		if (FDoubleProperty* DP = FindFProperty<FDoubleProperty>(CachedPackHealthComp->GetClass(), N))
		{
			const double Cur = DP->GetPropertyValue_InContainer(CachedPackHealthComp);
			if (Cur < static_cast<double>(MinHealth))
			{
				DP->SetPropertyValue_InContainer(CachedPackHealthComp, static_cast<double>(MinHealth));
			}
			return;
		}
		if (FFloatProperty* FP = FindFProperty<FFloatProperty>(CachedPackHealthComp->GetClass(), N))
		{
			const float Cur = FP->GetPropertyValue_InContainer(CachedPackHealthComp);
			if (Cur < MinHealth)
			{
				FP->SetPropertyValue_InContainer(CachedPackHealthComp, MinHealth);
			}
			return;
		}
		if (FIntProperty* IP = FindFProperty<FIntProperty>(CachedPackHealthComp->GetClass(), N))
		{
			const int32 Cur = IP->GetPropertyValue_InContainer(CachedPackHealthComp);
			if (Cur < FMath::CeilToInt(MinHealth))
			{
				IP->SetPropertyValue_InContainer(CachedPackHealthComp, FMath::CeilToInt(MinHealth));
			}
			return;
		}
	}
}

// P1-1: re-baseline the pack bridge after mirrored SquadAI->pack damage. The poll keys
// hero clamps off pack deltas; since we pre-sync (no delta), enforce floors here and
// keep the baseline consistent with the clamp (avoids a phantom "heal" next poll).
void ASoldierCharacter::PostMirroredPackDamage(float NewPackHealth)
{
	float Floor = 0.f;
	if (IsSquadLeader()) Floor = USquadAITuning::Get()->LeaderPackHealthFloor;
	else if (IsAlly()) Floor = USquadAITuning::Get()->AllyPackHealthFloor;
	if (Floor > 0.f)
	{
		ClampPackHealthMinimum(Floor);
	}
	LastPackHealth = FMath::Max(NewPackHealth, Floor);
}

void ASoldierCharacter::RestorePackHealth(float HealthValue)
{
	if (!CachedPackHealthComp) return;
	for (const FName& N : { FName(TEXT("currentHealth")), FName(TEXT("CurrentHealth")), FName(TEXT("Current Health")), FName(TEXT("Health")), FName(TEXT("health")), FName(TEXT("HP")), FName(TEXT("currentHP")), FName(TEXT("CurrentHP")) })
	{
		if (FDoubleProperty* DP = FindFProperty<FDoubleProperty>(CachedPackHealthComp->GetClass(), N))
		{
			DP->SetPropertyValue_InContainer(CachedPackHealthComp, static_cast<double>(HealthValue));
			return;
		}
		if (FFloatProperty* FP = FindFProperty<FFloatProperty>(CachedPackHealthComp->GetClass(), N))
		{
			FP->SetPropertyValue_InContainer(CachedPackHealthComp, HealthValue);
			return;
		}
		if (FIntProperty* IP = FindFProperty<FIntProperty>(CachedPackHealthComp->GetClass(), N))
		{
			IP->SetPropertyValue_InContainer(CachedPackHealthComp, FMath::RoundToInt(HealthValue));
			return;
		}
	}
}

float ASoldierCharacter::GetPackMaxHealth(float DefaultValue) const
{
	if (!CachedPackHealthComp) return DefaultValue;
	for (const FName& N : { FName(TEXT("maxHealth")), FName(TEXT("MaxHealth")), FName(TEXT("Max Health")), FName(TEXT("MaxHP")) })
	{
		if (FDoubleProperty* DP = FindFProperty<FDoubleProperty>(CachedPackHealthComp->GetClass(), N))
		{
			return static_cast<float>(DP->GetPropertyValue_InContainer(CachedPackHealthComp));
		}
		if (FFloatProperty* FP = FindFProperty<FFloatProperty>(CachedPackHealthComp->GetClass(), N))
		{
			return FP->GetPropertyValue_InContainer(CachedPackHealthComp);
		}
		if (FIntProperty* IP = FindFProperty<FIntProperty>(CachedPackHealthComp->GetClass(), N))
		{
			return static_cast<float>(IP->GetPropertyValue_InContainer(CachedPackHealthComp));
		}
	}
	return DefaultValue;
}

void ASoldierCharacter::ResetPackDeathFlags(bool bDead)
{
	TArray<UActorComponent*> Comps;
	GetComponents(Comps);
	for (UActorComponent* C : Comps)
	{
		if (!C) continue;
		for (const FName& N : { FName(TEXT("bIsDead?")), FName(TEXT("bIsDead")), FName(TEXT("bDead")), FName(TEXT("IsDead")) })
		{
			if (FBoolProperty* BP = FindFProperty<FBoolProperty>(C->GetClass(), N))
			{
				BP->SetPropertyValue_InContainer(C, bDead);
			}
		}
	}

	// S19-PACKALIVE: clearing our copy of the flag is not enough - the pack's own
	// dead state (BPC_Health*), its HUD and its AnimBP read the pack's structure,
	// not ours. Run the pack's own "alive again" entry points after clearing.
	if (!bDead)
	{
		FString ReviveWhy;
		if (SquadAIRecovery::RevivePackActor(this, &ReviveWhy))
		{
			UE_LOG(LogTemp, Log, TEXT("[DamageBridge] S19-PACKALIVE %s"), *ReviveWhy);
		}
	}
}

void ASoldierCharacter::OnAnyDamageReceived(AActor* DamagedActor, float Damage, const UDamageType* DamageType, AController* InstigatedBy, AActor* DamageCauser)
{
	if (!HealthComp || !HealthComp->IsAlive() || Damage <= 0.f) return;

	UE_LOG(LogTemp, Verbose, TEXT("[DamageSystem] %s: Received %.1f damage from %s"),
		*GetName(), Damage, DamageCauser ? *DamageCauser->GetName() : TEXT("unknown"));

	HealthComp->ApplyDamage(Damage, DamageCauser);

	// Same-frame pack clamp for heroes: the bridge poll cannot catch a one-shot that zeroes
	// pack health between polls (the pack would play its death sequence instantly).
	if (IsSquadLeader())
	{
		ClampPackHealthMinimum(USquadAITuning::Get()->LeaderPackHealthFloor);
	}
	else if (IsAlly())
	{
		ClampPackHealthMinimum(USquadAITuning::Get()->AllyPackHealthFloor);
	}
}

void ASoldierCharacter::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	// Clear the pack damage bridge timer
	GetWorldTimerManager().ClearTimer(PackDamageBridgeTimerHandle);

	// Unbind damage delegate to prevent stale callbacks during destruction
	OnTakeAnyDamage.RemoveDynamic(this, &ASoldierCharacter::OnAnyDamageReceived);

	// Unbind death delegate
	if (HealthComp)
	{
		HealthComp->OnDeath.RemoveDynamic(this, &ASoldierCharacter::OnHealthDied);
	}

	UnregisterFromSystems();
	Super::EndPlay(EndPlayReason);
}

float ASoldierCharacter::TakeDamage(float DamageAmount, const FDamageEvent& DamageEvent, AController* EventInstigator, AActor* DamageCauser)
{
	// P1-4: record the hit bone for kill-time headshot detection (stale-guarded by time).
	if (DamageEvent.GetTypeID() == FPointDamageEvent::ClassID)
	{
		const FPointDamageEvent& Point = static_cast<const FPointDamageEvent&>(DamageEvent);
		LastHitBoneName = Point.HitInfo.BoneName;
		LastHitTime = GetWorld() ? GetWorld()->GetTimeSeconds() : 0.f;
	}
	if (IsSquadLeader())
	{
		// AAA-MW-22: leader is fully immortal — no chip damage, no HP loss.
		if (HealthComp)
		{
			HealthComp->bInvincible = true;
			HealthComp->bIsDead = false;
			HealthComp->CurrentHealth = HealthComp->MaxHealth;
			HealthComp->OnHealthChanged.Broadcast(HealthComp->GetHealthPercent());
		}
		const USquadAITuning* LT = USquadAITuning::Get();
		ClampPackHealthMinimum(LT ? LT->LeaderPackHealthFloor : 9999.f);
		ResetPackDeathFlags(false);
		return 0.f;
	}

	if (HealthComp && HealthComp->IsAlive())
	{
		HealthComp->ApplyDamage(DamageAmount, DamageCauser);
		if (HealthComp->IsAlive())
		{
			UAnimMontage* ReactMontage = HitReactMontage;
			if (HitReactMontages.Num() > 0)
			{
				ReactMontage = HitReactMontages[FMath::RandRange(0, HitReactMontages.Num() - 1)];
			}
			if (ReactMontage)
			{
				if (UAnimInstance* AnimInst = GetMesh()->GetAnimInstance())
				{
					if (!AnimInst->Montage_IsPlaying(ReactMontage))
					{
						AnimInst->Montage_Play(ReactMontage, 1.f);
					}
				}
			}
		}
		UAISense_Damage::ReportDamageEvent(GetWorld(), this, DamageCauser, DamageAmount, GetActorLocation(), DamageCauser ? DamageCauser->GetActorLocation() : GetActorLocation());
	}

	return DamageAmount;
}

void ASoldierCharacter::NotifyPackDamage(float DamageAmount, AActor* DamageCauser, AController* InstigatorController, TSubclassOf<UDamageType> DamageTypeClass)
{
	if (!HealthComp || !HealthComp->IsAlive())
	{
		return;
	}

	HealthComp->ApplyExternalDamage(DamageAmount, DamageCauser, InstigatorController, DamageTypeClass);
	UAISense_Damage::ReportDamageEvent(GetWorld(), this, DamageCauser, DamageAmount, GetActorLocation(), DamageCauser ? DamageCauser->GetActorLocation() : GetActorLocation());
}

void ASoldierCharacter::SetUsePackPresentationMode(bool bEnabled)
{
	bUsePackPresentationMode = bEnabled;
	if (bUsePackPresentationMode)
	{
		bAutoAttachEquippedWeaponToMesh = false;
		bEnableLeftHandWeaponIK = false;
	}
}

void ASoldierCharacter::OnHealthDied(AActor* OwnerActor)
{
	HandleDeath();
}

void ASoldierCharacter::EnterDownedState()
{
	if (!bCanBeDowned || bIsDowned) return;

	bIsDowned = true;
	CurrentReviveProgress = 0.0f;
	BleedoutTimeRemaining = MaxBleedoutTime;

	if (WeaponComp) WeaponComp->StopFiring();
	if (AimComp) AimComp->ClearAimTarget();

	if (ASoldierAIController* AIC = Cast<ASoldierAIController>(GetController()))
	{
		AIC->StopMovement();
		AIC->StopCombatPresentation();
	}

	if (GetCharacterMovement())
	{
		// Revive restores the cached speed (was hardcoded 450 — ignored progression/ctor values).
		DownedSavedWalkSpeed = GetCharacterMovement()->MaxWalkSpeed;
		GetCharacterMovement()->StopMovementImmediately();
		GetCharacterMovement()->DisableMovement();
		GetCharacterMovement()->MaxWalkSpeed = 0.f;
	}

	// Disable capsule collision against other pawns
	if (UCapsuleComponent* Capsule = GetCapsuleComponent())
	{
		Capsule->SetCollisionResponseToChannel(ECC_Pawn, ECR_Ignore);
		Capsule->SetCollisionResponseToChannel(ECC_Vehicle, ECR_Ignore);
	}

	// Realistically collapse to ground in wounded prone state via physics simulation
	if (USkeletalMeshComponent* SkelMesh = GetMesh())
	{
		// S14-STAB: CompleteRevive() disables mesh gravity — a re-downed ally
		// ragdolled with gravity OFF and drifted slowly through the sky after
		// any explosion impulse. Always restore gravity before simulating.
		SkelMesh->SetEnableGravity(true);
		SkelMesh->SetCollisionProfileName(TEXT("Ragdoll"));
		SkelMesh->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
		SkelMesh->SetAllBodiesSimulatePhysics(true);
		SkelMesh->SetSimulatePhysics(true);
		SkelMesh->WakeAllRigidBodies();
		SkelMesh->AddImpulse(FVector(0.f, 0.f, -1500.f), NAME_None, true);
	}

	// S12-DOWN v2: the capsule is deliberately NOT dragged onto the ragdoll.
	// See GetBodyLocation() - the UI reads the body position instead.

	if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
	{
		AudioSys->PlayTacticalVoiceline(ETacticalVoicelineType::Ally_ManDown, this);
	}

	// Dispatch tactical alert banner to player HUD
	if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this))
	{
		HUD->NotifyAllyDowned(GetActorLocation(), CharacterDisplayName.IsEmpty() ? FText::FromString(TEXT("رزمنده جوخه")) : CharacterDisplayName);
	}

	UE_LOG(LogTemp, Warning, TEXT("[SquadAI] %s ENTERED DOWNED / INCAPACITATED STATE (Bleedout: %.1fs)"), *GetName(), MaxBleedoutTime);
}

FVector ASoldierCharacter::GetBodyLocation() const
{
	// S12-DOWN v2: where the soldier's BODY visually is.
	//
	// While downed the mesh simulates physics, so it is driven in world space and
	// no longer follows the capsule - GetActorLocation() stays where the soldier
	// was standing. v1 tried to drag the capsule onto the ragdoll every frame with
	// SetActorLocation + SetWorldTransform. That fought the simulation and could
	// fling the body somewhere else entirely (reported in testing as the injured
	// ally simply vanishing), so it has been reverted.
	//
	// Nothing about the physics needs to move: only the UI was ever wrong. This
	// reports the real body position for prompts and range checks and touches no
	// transforms at all.
	if (bIsDowned)
	{
		if (const USkeletalMeshComponent* SkelMesh = GetMesh())
		{
			if (SkelMesh->IsSimulatingPhysics())
			{
				FVector Loc = (RagdollSyncBone != NAME_None && SkelMesh->DoesSocketExist(RagdollSyncBone))
					? SkelMesh->GetSocketLocation(RagdollSyncBone)
					: SkelMesh->Bounds.Origin;

				// Never trust a physics/bounds read blindly: a detached or
				// exploded ragdoll can report a wild value, and a prompt drawn
				// 500 m away is worse than one slightly off.
				if (!Loc.ContainsNaN() &&
					FVector::DistSquared(Loc, GetActorLocation()) < FMath::Square(1500.f))
				{
					return Loc;
				}
			}
		}
	}
	return GetActorLocation();
}

void ASoldierCharacter::ApplyReviveProgress(float DeltaProgress, AActor* Reviver)
{
	if (!bIsDowned) return;

	CurrentReviveProgress += DeltaProgress;
	if (CurrentReviveProgress >= RequiredReviveTime)
	{
		CompleteRevive(Reviver);
	}
}

void ASoldierCharacter::CompleteRevive(AActor* Reviver)
{
	if (!bIsDowned) return;

	// S19-LOGGER: capture the downed/death state so the log shows what the revive fixed.
	const FString PoseBeforeRevive = SquadAISituation::DescribePose(this);
	const FString HealthBeforeRevive = SquadAISituation::DescribeHealth(this);

	bIsDowned = false;
	CurrentReviveProgress = 0.0f;
	BleedoutTimeRemaining = MaxBleedoutTime;

	SetLifeSpan(0.0f); // Cancel any pending destruction!

	if (HealthComp)
	{
		HealthComp->Revive();
	}

	// Restore the pack to its own max (never a hardcoded guess) and clear any pack-side
	// death flags set while we were down, so the bridge stays consistent next poll.
	LastPackHealth = GetPackMaxHealth(100.f);
	RestorePackHealth(LastPackHealth);
	ResetPackDeathFlags(false);

	// Restore Capsule Component
	if (UCapsuleComponent* Capsule = GetCapsuleComponent())
	{
		Capsule->SetCapsuleHalfHeight(88.0f, false);
		Capsule->SetCollisionProfileName(TEXT("Pawn"));
		Capsule->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
		Capsule->SetCollisionResponseToChannel(ECC_Pawn, ECR_Block);
		Capsule->SetCollisionResponseToChannel(ECC_Vehicle, ECR_Block);
	}

	// Restore SkeletalMesh from ragdoll to animated character pose with full physics deactivation
	if (USkeletalMeshComponent* SkelMesh = GetMesh())
	{
		// The pack ragdoll master may still own these bodies: kill all motion first so the
		// re-attach below never moves a simulating body (the "use the Teleport flag" error).
		SkelMesh->SetAllPhysicsLinearVelocity(FVector::ZeroVector);
		SkelMesh->SetAllPhysicsAngularVelocityInDegrees(FVector::ZeroVector);
		SkelMesh->PutAllRigidBodiesToSleep();
		SkelMesh->SetAllBodiesSimulatePhysics(false);
		SkelMesh->SetAllBodiesBelowSimulatePhysics(NAME_None, false, false);
		SkelMesh->SetSimulatePhysics(false);
		SkelMesh->SetEnableGravity(false);
		// The pack death sequence hides the mesh; revived allies stayed invisible without this.
		SkelMesh->SetVisibility(true);
		SkelMesh->SetHiddenInGame(false);
		SkelMesh->SetCollisionProfileName(TEXT("CharacterMesh"));
		SkelMesh->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
		SkelMesh->AttachToComponent(GetCapsuleComponent(), FAttachmentTransformRules::SnapToTargetNotIncludingScale);
		SkelMesh->SetRelativeLocationAndRotation(FVector(0.f, 0.f, -88.f), FRotator(0.f, -90.f, 0.f), false, nullptr, ETeleportType::TeleportPhysics);

		// S19-DEATHPOSE: turning simulation off is not enough. The physics blend
		// weight (set to 1 when the death ragdoll was switched on) keeps the
		// component rendering its last ragdoll pose, and a death sequence may also
		// have paused the component / disabled its skeleton update / switched the
		// animation mode. Restore all of that or the revived soldier comes back as
		// a body frozen in its death pose with no animation at all.
		SquadAIRecovery::RestoreAnimatedPose(SkelMesh, /*bReinitializeAnim=*/false, /*bForceAnimMode=*/true);

		if (UAnimInstance* AnimInst = SkelMesh->GetAnimInstance())
		{
			AnimInst->InitializeAnimation();
		}
	}

	// G-2: the pack owns extra simulating meshes (e.g. CharacterMesh0 on pack BPs).
	// They must be frozen + re-shown too: untouched, they keep simulating through the
	// move (the "use the Teleport flag" error) and stay hidden by the pack death
	// sequence (revived ally still invisible). Sim/visibility only — the pack keeps
	// owning attachment, collision and animation.
	{
		TArray<USkeletalMeshComponent*> AllMeshes;
		GetComponents<USkeletalMeshComponent>(AllMeshes);
		for (USkeletalMeshComponent* ExtraMesh : AllMeshes)
		{
			if (!ExtraMesh || ExtraMesh == GetMesh()) continue;
			// S19-DEATHPOSE: includes the physics blend-weight reset (see above) --
			// a secondary ragdoll mesh otherwise stays frozen in its death pose.
			SquadAIRecovery::RestoreAnimatedPose(ExtraMesh, /*bReinitializeAnim=*/false, /*bForceAnimMode=*/false);
		}
	}

	if (GetCharacterMovement())
	{
		GetCharacterMovement()->SetMovementMode(MOVE_Walking);
		// Cached at EnterDownedState (ctor default 400 if never downed).
		GetCharacterMovement()->MaxWalkSpeed = (DownedSavedWalkSpeed > 0.f) ? DownedSavedWalkSpeed : 400.f;
	}

	if (ASoldierAIController* AIC = Cast<ASoldierAIController>(GetController()))
	{
		AIC->RestartStateTree();
	}

	// MEGA-5 (G-5): revived soldiers re-enter combat with zero protection — the grace
	// timer only ever ran at BeginPlay. Reset it so the revivee survives the first burst.
	ResetSpawnGracePeriod();

	RegisterWithSystems();

	// S18-GRIP: the revive path re-attaches the skeletal mesh to the capsule but
	// never re-applied the weapon attachment — a revived soldier could end up
	// holding the rifle at the wrong transform (or at his feet) until respawn.
	ApplyEquippedWeaponAttachment();

	UE_LOG(LogTemp, Warning, TEXT("[SquadAI] %s SUCCESSFULLY REVIVED by %s! (Immunity/Despawn prevented)"), *GetName(), *GetNameSafe(Reviver));

	// S19-LOGGER: before -> after. "SQUAD-REVIVE after ... pose{rag=1 blend=1.00 ...}" would
	// mean the frozen-death-pose bug is back, and this line names the mesh + flag.
	SquadAISituation::Note(FString::Printf(TEXT("SQUAD-REVIVE (CompleteRevive) %s by %s"),
		*GetName(), *GetNameSafe(Reviver)));
	SquadAISituation::Note(FString::Printf(TEXT("SQUAD-REVIVE before hp{%s} pose{%s}"),
		*HealthBeforeRevive, *PoseBeforeRevive));
	SquadAISituation::Note(FString::Printf(TEXT("SQUAD-REVIVE after  hp{%s} pose{%s}"),
		*SquadAISituation::DescribeHealth(this), *SquadAISituation::DescribePose(this)));
}

// S19-PLAYERDEATH: Handle player death before faction downing, since the possessed pawn can have Ally faction.
void ASoldierCharacter::HandleDeath()
{
	if (IsSquadLeader())
	{
		// Squad Leader never dies
		if (HealthComp)
		{
			HealthComp->CurrentHealth = USquadAITuning::Get()->LeaderVetoHealth;
			HealthComp->bIsDead = false;
		}
		// G-1: the veto must also revive the PACK side, or TPWCS keeps playing death
		// (hidden mesh/ragdoll) while SquadAI considers Rostami alive.
		RestorePackHealth(GetPackMaxHealth(100.f));
		ResetPackDeathFlags(false);
		ClampPackHealthMinimum(USquadAITuning::Get()->LeaderPackHealthFloor);
		SquadAISituation::Note(FString::Printf(TEXT("DEATH %s: leader veto - health restored | hp{%s} pose{%s}"),
			*GetName(), *SquadAISituation::DescribeHealth(this), *SquadAISituation::DescribePose(this)));
		return;
	}

	// Player death restarts the current mission. Do not route a possessed ally into
	// incapacitation or ragdoll destruction; MissionZone owns recovery.
	if (IsPlayerControlled())
	{
		if (WeaponComp) WeaponComp->StopFiring();
		if (AimComp) AimComp->ClearAimTarget();
		if (GetCharacterMovement())
		{
			GetCharacterMovement()->StopMovementImmediately();
		}
		// S19-LOGGER: this branch deliberately does NOT mark the pawn dead - recovery
		// belongs to MissionZone. Logged so the log shows which path a death took.
		SquadAISituation::Note(FString::Printf(TEXT("DEATH %s: player-controlled soldier -> MissionZone owns recovery | hp{%s} pose{%s}"),
			*GetName(), *SquadAISituation::DescribeHealth(this), *SquadAISituation::DescribePose(this)));
		return;
	}

	if (IsAlly())
	{
		// AI allies enter downed state instead of permanent death.
		if (!bIsDowned)
		{
			EnterDownedState();
			SquadAISituation::Note(FString::Printf(TEXT("DEATH %s: ally -> downed state | hp{%s} pose{%s}"),
				*GetName(), *SquadAISituation::DescribeHealth(this), *SquadAISituation::DescribePose(this)));
		}
		return;
	}

	// Other non-player downable characters enter incapacitation. Enemies normally
	// have bCanBeDowned=false and continue through full death handling below.
	if (bCanBeDowned && !bIsDowned)
	{
		EnterDownedState();
		return;
	}

	UnregisterFromSystems();
	if (WeaponComp) WeaponComp->StopFiring();
	if (AimComp) AimComp->ClearAimTarget();

	// B7-3: last-kill slow-mo hookup. NotifyEnemyEliminated previously had zero callers,
	// so the cinematic system never learned about kills.
	if (IsEnemy())
	{
		// P1-4: real headshot flag (TakeDamage bone + 1s freshness; bridge kills read false).
		const float NowSec = GetWorld() ? GetWorld()->GetTimeSeconds() : 0.f;
		const FString BoneStr = LastHitBoneName.ToString();
		const bool bHeadshot = (NowSec - LastHitTime < 1.0f)
			&& (BoneStr.Contains(TEXT("head"), ESearchCase::IgnoreCase)
				|| BoneStr.Contains(TEXT("skull"), ESearchCase::IgnoreCase)
				|| BoneStr.Contains(TEXT("neck"), ESearchCase::IgnoreCase));
		if (USquadAICinematicCombatSubsystem* CineSys = USquadAICinematicCombatSubsystem::Get(this))
		{
			// bWasLastEnemyInArea stays zone-owned (MissionZone passes nullptr+true).
			CineSys->NotifyEnemyEliminated(this, bHeadshot, false);
		}
		// 0-XP kills: single choke — counters + XP + headshot stat/bonus.
		if (USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(this))
		{
			Prog->RecordEnemyEliminated();
			if (bHeadshot) { Prog->RegisterHeadshot(); }
		}
	}

	if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
	{
		if (IsAlly())
		{
			AudioSys->PlayTacticalVoiceline(ETacticalVoicelineType::Ally_ManDown, this);
		}
		else if (IsEnemy())
		{
			AudioSys->PlayTacticalVoiceline(ETacticalVoicelineType::Ally_KillConfirmed, this);
		}
	}

	if (ASoldierAIController* AIC = Cast<ASoldierAIController>(GetController()))
	{
		AIC->StopMovement();
		if (AIC->StateTreeComp)
		{
			AIC->StateTreeComp->StopLogic(TEXT("Dead"));
		}
	}

	if (GetCharacterMovement())
	{
		GetCharacterMovement()->StopMovementImmediately();
		GetCharacterMovement()->DisableMovement();
	}
	if (UCapsuleComponent* Capsule = GetCapsuleComponent())
	{
		Capsule->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	}

	float PlayedLength = 0.f;
	UAnimMontage* SelectedDeathMontage = DeathMontage;
	if (DeathMontages.Num() > 0)
	{
		SelectedDeathMontage = DeathMontages[FMath::RandRange(0, DeathMontages.Num() - 1)];
	}

	if (SelectedDeathMontage && GetMesh())
	{
		if (UAnimInstance* AnimInst = GetMesh()->GetAnimInstance())
		{
			PlayedLength = AnimInst->Montage_Play(SelectedDeathMontage, 1.f);
			UE_LOG(LogTemp, Warning, TEXT("DeathAnim: %s Montage_Play(%s) on AnimBP=%s returned %.3f"),
				*GetNameSafe(this), *GetNameSafe(SelectedDeathMontage), *GetNameSafe(AnimInst->GetClass()), PlayedLength);
		}
		else
		{
			UE_LOG(LogTemp, Warning, TEXT("DeathAnim: %s has DeathMontage %s but mesh has no AnimInstance."),
				*GetNameSafe(this), *GetNameSafe(SelectedDeathMontage));
		}
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("DeathAnim: %s has no DeathMontage assigned; using ragdoll fallback."), *GetNameSafe(this));
	}

	if (USkeletalMeshComponent* Skel = GetMesh())
	{
		if (PlayedLength > 0.f)
		{
			const float RagdollDelay = FMath::Max(DeathMontageToRagdollDelay, PlayedLength * 0.90f);
			TWeakObjectPtr<ASoldierCharacter> WeakSelf(this);
			FTimerHandle RagdollTimer;
			GetWorldTimerManager().SetTimer(RagdollTimer, [WeakSelf]()
			{
				if (!WeakSelf.IsValid() || !WeakSelf->GetMesh()) return;
				USkeletalMeshComponent* Mesh = WeakSelf->GetMesh();
				Mesh->SetEnableGravity(true); // S14-STAB: revive may have disabled it
				Mesh->SetCollisionProfileName(TEXT("Ragdoll"));
				Mesh->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
				Mesh->SetAllBodiesSimulatePhysics(true);
				Mesh->SetSimulatePhysics(true);
				Mesh->WakeAllRigidBodies();
			}, RagdollDelay, false);
		}
		else
		{
			Skel->SetEnableGravity(true); // S14-STAB: revive may have disabled it
			Skel->SetCollisionProfileName(TEXT("Ragdoll"));
			Skel->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
			Skel->SetAllBodiesSimulatePhysics(true);
			Skel->SetSimulatePhysics(true);
			Skel->WakeAllRigidBodies();
			Skel->AddImpulse(FVector(0.f, 0.f, -1500.f), NAME_None, true);
		}
	}

	// Propagate death state to TPWCS pack components if present
	for (UActorComponent* Comp : GetComponents())
	{
		if (!Comp) continue;
		if (FBoolProperty* BP = FindFProperty<FBoolProperty>(Comp->GetClass(), FName(TEXT("bIsDead?"))))
		{
			BP->SetPropertyValue_InContainer(Comp, true);
		}
		if (FBoolProperty* BP2 = FindFProperty<FBoolProperty>(Comp->GetClass(), FName(TEXT("bIsDead"))))
		{
			BP2->SetPropertyValue_InContainer(Comp, true);
		}
	}

	DetachFromControllerPendingDestroy();
	SetLifeSpan(10.f);
}

void ASoldierCharacter::ApplyDeathImpulse(const FVector& Direction, float Force, FName HitBoneName)
{
	if (USkeletalMeshComponent* Skel = GetMesh())
	{
		if (!Skel->IsSimulatingPhysics())
		{
			Skel->SetCollisionProfileName(TEXT("Ragdoll"));
			Skel->SetSimulatePhysics(true);
		}
		const FVector Impulse = Direction.GetSafeNormal() * Force;
		if (!HitBoneName.IsNone())
		{
			Skel->AddImpulse(Impulse, HitBoneName, true);
		}
		else
		{
			Skel->AddImpulse(Impulse, FName(TEXT("pelvis")), true);
		}
	}
}

void ASoldierCharacter::RegisterWithSystems()
{
	if (UWorld* World = GetWorld())
	{
		if (UAISignificanceManager* SM = World->GetSubsystem<UAISignificanceManager>()) SM->RegisterSoldier(this);
		if (USoldierRegistrySubsystem* Reg = World->GetSubsystem<USoldierRegistrySubsystem>()) Reg->RegisterSoldier(this);
	}
	// P1-3: spawn/registration hook — fresh spawns, wave members, revives and post-travel
	// soldiers pick up the CURRENT difficulty (SetDifficulty only ever walked live soldiers).
	if (UDifficultySubsystem* Diff = UDifficultySubsystem::Get(this))
	{
		Diff->ApplyToSoldier(this);
	}
}

void ASoldierCharacter::UnregisterFromSystems()
{
	if (UWorld* World = GetWorld())
	{
		if (UAISignificanceManager* SM = World->GetSubsystem<UAISignificanceManager>()) SM->UnregisterSoldier(this);
		if (USoldierRegistrySubsystem* Reg = World->GetSubsystem<USoldierRegistrySubsystem>()) Reg->UnregisterSoldier(this);
	}
	// Free any held cover reservation so the point returns to the pool.
	if (ASoldierAIController* AIC = Cast<ASoldierAIController>(GetController()))
	{
		AIC->ReleaseHeldCoverReservation();
	}
}

void ASoldierCharacter::SetCoverState(bool bInCover, bool bCrouching)
{
	bIsInCover = bInCover;
	bIsCrouchingInCover = bCrouching;
	if (bCrouching && !bIsCrouched) Crouch(); else if (!bCrouching && bIsCrouched) UnCrouch();
}

void ASoldierCharacter::SetCurrentCover(const FCoverPoint& Cover)
{
	CurrentCoverPoint = Cover;

	if (EnumHasAnyFlags(Cover.AvailableLeans, ELeanSide::Right))
	{
		CoverSide = ESoldierCoverSide::Right;
	}
	else if (EnumHasAnyFlags(Cover.AvailableLeans, ELeanSide::Left))
	{
		CoverSide = ESoldierCoverSide::Left;
	}
	else
	{
		CoverSide = ESoldierCoverSide::Right;
	}

	if (Cover.Height == ECoverHeight::Low && EnumHasAnyFlags(Cover.AvailableLeans, ELeanSide::Over))
	{
		CoverPeekType = ESoldierCoverPeekType::Over;
	}
	else
	{
		CoverPeekType = ESoldierCoverPeekType::Side;
	}
}

void ASoldierCharacter::ClearCover()
{
	bIsInCover = false;
	bIsCrouchingInCover = false;
	if (bIsCrouched) UnCrouch();
}

bool ASoldierCharacter::IsAlive() const { return HealthComp ? HealthComp->IsAlive() : true; }
bool ASoldierCharacter::IsSquadLeader() const
{
	// G-1: data-driven override first (pack Rostami BPs are indistinguishable by class/name).
	if (bIsSquadLeaderOverride) return true;
	return IsA<ALeaderCharacter>() || ActorHasTag(TEXT("Leader")) || GetName().Contains(TEXT("Leader")) || GetName().Contains(TEXT("Rostami"))
		|| (GetClass() && GetClass()->GetName().Contains(TEXT("Rostami")));
}
float ASoldierCharacter::GetHealthPercent() const { return HealthComp ? HealthComp->GetHealthPercent() : 1.f; }

float ASoldierCharacter::GetGroundSpeed() const
{
	return GetVelocity().Size2D();
}

bool ASoldierCharacter::IsMovingInCover(float SpeedThreshold) const
{
	return bIsInCover && GetGroundSpeed() > SpeedThreshold;
}

bool ASoldierCharacter::IsCurrentCoverLow() const
{
	return CurrentCoverPoint.Height == ECoverHeight::Low;
}

UAnimMontage* ASoldierCharacter::SelectFireMontage() const
{
	if (bIsInCover)
	{
		if (IsCurrentCoverLow())
		{
			if (CoverPeekType == ESoldierCoverPeekType::Over && FireMontage_CoverLowOver) return FireMontage_CoverLowOver;
			if (CoverSide == ESoldierCoverSide::Left && FireMontage_CoverLowLeft) return FireMontage_CoverLowLeft;
			if (FireMontage_CoverLowRight) return FireMontage_CoverLowRight;
		}
		else
		{
			if (CoverSide == ESoldierCoverSide::Left && FireMontage_CoverHighLeft) return FireMontage_CoverHighLeft;
			if (FireMontage_CoverHighRight) return FireMontage_CoverHighRight;
		}
	}

	if (bIsCrouched && FireMontage_Crouch) return FireMontage_Crouch;
	return FireMontage;
}

UAnimMontage* ASoldierCharacter::SelectReloadMontage() const
{
	if (bIsInCover)
	{
		if (IsCurrentCoverLow())
		{
			if (CoverPeekType == ESoldierCoverPeekType::Over && ReloadMontage_CoverLowOver) return ReloadMontage_CoverLowOver;
			if (CoverSide == ESoldierCoverSide::Left && ReloadMontage_CoverLowLeft) return ReloadMontage_CoverLowLeft;
			if (ReloadMontage_CoverLowRight) return ReloadMontage_CoverLowRight;
		}
		else
		{
			if (CoverSide == ESoldierCoverSide::Left && ReloadMontage_CoverHighLeft) return ReloadMontage_CoverHighLeft;
			if (ReloadMontage_CoverHighRight) return ReloadMontage_CoverHighRight;
		}
	}

	if (bIsCrouched && ReloadMontage_Crouch) return ReloadMontage_Crouch;
	return ReloadMontage;
}

void ASoldierCharacter::SetEquippedWeaponMesh(UMeshComponent* InWeaponMesh)
{
	EquippedWeaponMesh = InWeaponMesh;
	ApplyEquippedWeaponAttachment();
}

void ASoldierCharacter::ApplyEquippedWeaponAttachment()
{
	if (!EquippedWeaponMesh || !GetMesh() || !bAutoAttachEquippedWeaponToMesh || bUsePackPresentationMode)
	{
		return;
	}

	// S17-GRIP: custom character meshes often lack the mannequin's 'RifleSocket'.
	// Attaching to a missing socket silently snaps the weapon to the MESH ROOT
	// (between the feet, following root motion). Resolve a real socket/bone
	// first: configured name, then common weapon sockets, then right-hand bones
	// (UE, Mixamo, Biped namings). DoesSocketExist covers bones too.
	FName ResolvedSocket = WeaponAttachSocketName;
	bool bEmulateSocket = false;
	FTransform EmulatedSocketTransform = FTransform::Identity;
	if (!GetMesh()->DoesSocketExist(ResolvedSocket))
	{
		// S17-GRIP2: clone the grip socket from the ORIGINAL mannequin mesh at
		// runtime (bone + relative transform). Assets are never modified: we
		// attach to the matching bone and reproduce the socket's offset math.
		// Template = GripSocketTemplateMesh if set, else the mesh this Blueprint
		// (or its parent classes) originally shipped with in class defaults.
		const USkeletalMesh* TemplateMesh = nullptr;
		const USkeletalMeshSocket* TemplateSocket = FindGripSocketTemplate(TemplateMesh);
			// S19-GRIPFALLBACK: the grip-bone resolution used to be nested inside
			// `if (TemplateSocket)`. On a V3 / CC4 rig whose Blueprint lineage carries
			// no mannequin grip socket, FindGripSocketTemplate() returns null, so the
			// WHOLE block was skipped - including ResolveGripBone(), which finds the
			// hand bone perfectly well on its own - and the weapon fell through to
			// the mesh root, i.e. between the feet. Resolve the bone FIRST; the
			// template only refines the offset, and is optional.
			const FName GripBone = ResolveGripBone(TemplateSocket);
			if (!GripBone.IsNone())
			{
				ResolvedSocket = GripBone;
				bEmulateSocket = true;
				EmulatedSocketTransform = FTransform::Identity;

				if (TemplateSocket)
				{
					EmulatedSocketTransform = FTransform(TemplateSocket->RelativeRotation, TemplateSocket->RelativeLocation, TemplateSocket->RelativeScale);
					// S18-GRIP: the verbatim clone above assumes both rigs share hand-bone
					// axes and size. The mannequin vs. a V3/CC hand do not - that is the
					// twisted, oversized rifle. Retarget into THIS skeleton's hand frame.
					if (bRetargetGripToOwnSkeleton)
					{
						const USkeletalMesh* OwnMesh = GetMesh() ? GetMesh()->GetSkeletalMeshAsset() : nullptr;
						FVector RLoc; FRotator RRot; FVector RScale; FString Why;
						if (SquadAIGrip::RetargetSocketTransform(TemplateMesh, TemplateSocket, OwnMesh, GripBone,
							bAutoScaleWeaponToGrip, WeaponGripScaleMultiplier, RLoc, RRot, RScale, Why))
						{
							EmulatedSocketTransform = FTransform(RRot, RLoc, RScale);
							UE_LOG(LogTemp, Warning, TEXT("[WeaponAttach] S18-GRIP %s: %s"), *GetName(), *Why);
						}
					}
					UE_LOG(LogTemp, Warning, TEXT("[WeaponAttach] %s: socket '%s' missing on this skeleton - grip CLONED from template '%s' onto bone '%s' (runtime only, no asset touched)."),
						*GetName(), *WeaponAttachSocketName.ToString(), *GetNameSafe(TemplateMesh), *GripBone.ToString());
				}
				else
				{
					// S19-GRIPFALLBACK: no template socket anywhere in this Blueprint's
					// lineage, but we DO have a hand bone. Grip it directly - in the hand
					// beats under the feet. Tune WeaponAttachLocation/RotationOffset.
					UE_LOG(LogTemp, Warning, TEXT("[WeaponAttach] %s: no template grip socket found and socket '%s' is missing - gripping right-hand bone '%s' directly. Tune WeaponAttachLocation/RotationOffset for a clean grip."),
						*GetName(), *WeaponAttachSocketName.ToString(), *GripBone.ToString());
				}
			}
	}
	if (!bEmulateSocket && !GetMesh()->DoesSocketExist(ResolvedSocket))
	{
		static const FName FallbackSockets[] = {
			FName(TEXT("RifleSocket")), FName(TEXT("WeaponSocket")), FName(TEXT("GunSocket")),
			FName(TEXT("weapon_r")), FName(TEXT("weapon_r_socket")), FName(TEXT("hand_rSocket")),
			FName(TEXT("hand_r")), FName(TEXT("Hand_R")), FName(TEXT("R_Hand")),
			FName(TEXT("RightHand")), FName(TEXT("mixamorig:RightHand")), FName(TEXT("Bip001-R-Hand")) };
		ResolvedSocket = NAME_None;
		for (const FName& Candidate : FallbackSockets)
		{
			if (GetMesh()->DoesSocketExist(Candidate))
			{
				ResolvedSocket = Candidate;
				break;
			}
		}
		if (ResolvedSocket != NAME_None)
		{
			UE_LOG(LogTemp, Warning, TEXT("[WeaponAttach] %s: socket '%s' not found on skeleton — falling back to '%s'. Add a '%s' socket to this skeleton (or set WeaponAttachSocketName) and tune WeaponAttachLocation/RotationOffset for a clean grip."),
				*GetName(), *WeaponAttachSocketName.ToString(), *ResolvedSocket.ToString(), *WeaponAttachSocketName.ToString());
		}
		else
		{
			// Nothing matched — list this skeleton's hand-ish bones so the fix is obvious.
			FString HandBones;
			const int32 NumBones = GetMesh()->GetNumBones();
			for (int32 b = 0; b < NumBones; b++)
			{
				const FString BoneStr = GetMesh()->GetBoneName(b).ToString();
				if (BoneStr.Contains(TEXT("hand"), ESearchCase::IgnoreCase) || BoneStr.Contains(TEXT("wrist"), ESearchCase::IgnoreCase))
				{
					HandBones += BoneStr + TEXT("  ");
				}
			}
			UE_LOG(LogTemp, Error, TEXT("[WeaponAttach] %s: socket '%s' missing and NO fallback matched — weapon would sit at the feet. Set WeaponAttachSocketName to one of this skeleton's hand bones: %s"),
				*GetName(), *WeaponAttachSocketName.ToString(), HandBones.IsEmpty() ? TEXT("(no hand/wrist bones found?)") : *HandBones);
			ResolvedSocket = WeaponAttachSocketName; // keep legacy behavior, loudly
		}
	}

	EquippedWeaponMesh->AttachToComponent(GetMesh(), FAttachmentTransformRules::SnapToTargetNotIncludingScale, ResolvedSocket);
	if (bEmulateSocket)
	{
		// Bone attach + cloned socket transform + the usual designer offsets
		// (offsets act in socket space, exactly as on the original mannequin).
		const FTransform OffsetT(WeaponAttachRotationOffset, WeaponAttachLocationOffset, FVector::OneVector);
		EquippedWeaponMesh->SetRelativeTransform(OffsetT * EmulatedSocketTransform);
	}
	else
	{
		EquippedWeaponMesh->SetRelativeLocation(WeaponAttachLocationOffset);
		EquippedWeaponMesh->SetRelativeRotation(WeaponAttachRotationOffset);
	}
	// S19-SCALE: AttachToComponent() above uses SnapToTargetNotIncludingScale,
	// which deliberately DROPS the socket's own scale. That silently discarded
	// the size compensation: the clone station bakes the rig ratio into the
	// grip socket's RelativeScale, but the branch that runs when the socket
	// EXISTS (i.e. every successful bake) never looked at it, so the weapon
	// came out mannequin-sized even when the V3 rig's hands were bigger.
	//
	// Read the socket's scale back and apply it. Every hand-authored socket is
	// scaled (1,1,1), so for anything already working this is a strict no-op:
	// both pre-existing branches below are left exactly as they were.
	FVector SocketScale = FVector::OneVector;
	bool bHasSocketScale = false;
	if (!bEmulateSocket && bAutoScaleWeaponToGrip)
	{
		if (const USkeletalMesh* OwnMesh = GetMesh() ? GetMesh()->GetSkeletalMeshAsset() : nullptr)
		{
			// FindSocket() checks mesh-level sockets first, then the skeleton.
			if (const USkeletalMeshSocket* Socket = OwnMesh->FindSocket(ResolvedSocket))
			{
				SocketScale = Socket->RelativeScale;
				bHasSocketScale = !SocketScale.Equals(FVector::OneVector)
					&& SocketScale.GetAbsMax() > KINDA_SMALL_NUMBER;
				if (bHasSocketScale)
				{
					UE_LOG(LogTemp, Log, TEXT("[WeaponAttach] %s: applying socket '%s' scale %s to match this rig's hand size."),
						*GetName(), *ResolvedSocket.ToString(), *SocketScale.ToString());
				}
			}
		}
	}

	if (bOverrideWeaponAttachScale)
	{
		// S18-GRIP: this used to overwrite the retargeted socket scale outright,
		// silently cancelling the hand-size match. Fold the rig ratio in.
		FVector FinalScale = WeaponAttachScale;
		if (bEmulateSocket)
		{
			const FVector EmulatedScale = EmulatedSocketTransform.GetScale3D();
			if (bAutoScaleWeaponToGrip && EmulatedScale.GetAbsMax() > KINDA_SMALL_NUMBER)
			{
				FinalScale *= EmulatedScale;
			}
		}
		else if (bHasSocketScale)
		{
			FinalScale *= SocketScale; // S19-SCALE
		}
		EquippedWeaponMesh->SetRelativeScale3D(FinalScale);
	}
	else if (bHasSocketScale)
	{
		// No designer override: the socket's own ratio is the only scale there is.
		EquippedWeaponMesh->SetRelativeScale3D(SocketScale); // S19-SCALE
	}
	EquippedWeaponMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
}

// ===== S17-GRIP2/3 =====
const USkeletalMeshSocket* ASoldierCharacter::FindGripSocketTemplate(const USkeletalMesh*& OutTemplateMesh) const
{
	OutTemplateMesh = GripSocketTemplateMesh;
	const USkeletalMeshSocket* TemplateSocket = OutTemplateMesh ? OutTemplateMesh->FindSocket(WeaponAttachSocketName) : nullptr;
	const USkeletalMesh* OwnMesh = GetMesh() ? GetMesh()->GetSkeletalMeshAsset() : nullptr;
	for (UClass* Cls = GetClass(); !TemplateSocket && Cls && Cls->IsChildOf(ASoldierCharacter::StaticClass()); Cls = Cls->GetSuperClass())
	{
		const ASoldierCharacter* CDO = Cls->GetDefaultObject<ASoldierCharacter>();
		const USkeletalMesh* CDOMesh = (CDO && CDO->GetMesh()) ? CDO->GetMesh()->GetSkeletalMeshAsset() : nullptr;
		if (CDOMesh && CDOMesh != OwnMesh)
		{
			TemplateSocket = CDOMesh->FindSocket(WeaponAttachSocketName);
			if (TemplateSocket) OutTemplateMesh = CDOMesh;
		}
	}
	return TemplateSocket;
}

FName ASoldierCharacter::ResolveGripBone(const USkeletalMeshSocket* TemplateSocket) const
{
	if (!GetMesh()) return NAME_None;
	if (TemplateSocket && GetMesh()->GetBoneIndex(TemplateSocket->BoneName) != INDEX_NONE)
	{
		return TemplateSocket->BoneName;
	}
	// S18-GRIP: this fixed list knew only UE/Mixamo names, so on a CC4 / DAZ /
	// V3 rig it returned None and the weapon fell to the floor. Use the shared
	// resolver (fixed names + scored name scan), same one the clone station uses.
	if (const USkeletalMesh* OwnMesh = GetMesh()->GetSkeletalMeshAsset())
	{
		const FName Scanned = SquadAIGrip::ResolveRightHandBone(OwnMesh, TemplateSocket, TEXT("WeaponAttach"));
		if (!Scanned.IsNone()) return Scanned;
	}
	static const FName HandBones[] = {
		FName(TEXT("hand_r")), FName(TEXT("Hand_R")), FName(TEXT("R_Hand")),
		FName(TEXT("RightHand")), FName(TEXT("mixamorig:RightHand")), FName(TEXT("Bip001-R-Hand")) };
	for (const FName& B : HandBones)
	{
		if (GetMesh()->GetBoneIndex(B) != INDEX_NONE) return B;
	}
	return NAME_None;
}

void ASoldierCharacter::CreateGripSocketOnSkeleton()
{
	USkeletalMeshComponent* MeshComp = GetMesh();
	USkeletalMesh* MeshAsset = MeshComp ? MeshComp->GetSkeletalMeshAsset() : nullptr;
	USkeleton* Skeleton = MeshAsset ? MeshAsset->GetSkeleton() : nullptr;
	if (!Skeleton)
	{
		UE_LOG(LogTemp, Error, TEXT("[GripSocket] %s: no skeletal mesh/skeleton assigned."), *GetName());
		return;
	}
	if (MeshComp->DoesSocketExist(WeaponAttachSocketName))
	{
		UE_LOG(LogTemp, Warning, TEXT("[GripSocket] %s: '%s' already exists on '%s' — nothing to do."),
			*GetName(), *WeaponAttachSocketName.ToString(), *Skeleton->GetName());
		return;
	}
	const USkeletalMesh* TemplateMesh = nullptr;
	const USkeletalMeshSocket* TemplateSocket = FindGripSocketTemplate(TemplateMesh);
	if (!TemplateSocket)
	{
		UE_LOG(LogTemp, Error, TEXT("[GripSocket] %s: no template socket '%s' found — set GripSocketTemplateMesh to the mannequin mesh and retry."),
			*GetName(), *WeaponAttachSocketName.ToString());
		return;
	}
	const FName GripBone = ResolveGripBone(TemplateSocket);
	if (GripBone.IsNone())
	{
		UE_LOG(LogTemp, Error, TEXT("[GripSocket] %s: no matching hand bone on skeleton '%s' (template bone '%s')."),
			*GetName(), *Skeleton->GetName(), *TemplateSocket->BoneName.ToString());
		return;
	}

	USkeletalMeshSocket* NewSocket = NewObject<USkeletalMeshSocket>(Skeleton);
	NewSocket->SocketName = WeaponAttachSocketName;
	NewSocket->BoneName = GripBone;
	NewSocket->RelativeLocation = TemplateSocket->RelativeLocation;
	NewSocket->RelativeRotation = TemplateSocket->RelativeRotation;
	NewSocket->RelativeScale = TemplateSocket->RelativeScale;
	// S18-GRIP: third verbatim-copy site — retarget here too, otherwise the
	// "Create Grip Socket On Skeleton" button bakes the twisted transform.
	if (bRetargetGripToOwnSkeleton)
	{
		FVector RLoc; FRotator RRot; FVector RScale; FString Why;
		if (SquadAIGrip::RetargetSocketTransform(TemplateMesh, TemplateSocket, MeshAsset, GripBone,
			bAutoScaleWeaponToGrip, WeaponGripScaleMultiplier, RLoc, RRot, RScale, Why))
		{
			NewSocket->RelativeLocation = RLoc;
			NewSocket->RelativeRotation = RRot;
			NewSocket->RelativeScale = RScale;
			UE_LOG(LogTemp, Warning, TEXT("[GripSocket] S18-GRIP %s: %s"), *GetName(), *Why);
		}
	}
	Skeleton->Modify();
	Skeleton->Sockets.Add(NewSocket);
	Skeleton->MarkPackageDirty();

	UE_LOG(LogTemp, Warning, TEXT("[GripSocket] %s: created socket '%s' on skeleton '%s' (bone '%s', cloned from '%s'). NOW SAVE the skeleton asset (Save All / Ctrl+Shift+S) to make it permanent."),
		*GetName(), *WeaponAttachSocketName.ToString(), *Skeleton->GetName(), *GripBone.ToString(), *GetNameSafe(TemplateMesh));

	// Re-attach immediately so the result is visible right away.
	ApplyEquippedWeaponAttachment();
}

bool ASoldierCharacter::GetEquippedWeaponSocketTransform(FName SocketName, FTransform& OutTransform) const
{
	OutTransform = FTransform::Identity;
	if (!EquippedWeaponMesh || SocketName.IsNone()) return false;
	if (!EquippedWeaponMesh->DoesSocketExist(SocketName)) return false;
	OutTransform = EquippedWeaponMesh->GetSocketTransform(SocketName, RTS_World);
	return true;
}

bool ASoldierCharacter::GetEquippedWeaponSocketTransformInMeshSpace(FName SocketName, FTransform& OutTransform) const
{
	OutTransform = FTransform::Identity;
	FTransform SocketWorld;
	if (!GetEquippedWeaponSocketTransform(SocketName, SocketWorld)) return false;
	USkeletalMeshComponent* MeshComp = GetMesh();
	if (!MeshComp) return false;
	OutTransform = SocketWorld.GetRelativeTransform(MeshComp->GetComponentTransform());
	return true;
}

bool ASoldierCharacter::GetLeftHandIKWorldTransform(FTransform& OutTransform) const
{
	return GetEquippedWeaponSocketTransform(WeaponLeftHandIKSocketName, OutTransform);
}

bool ASoldierCharacter::GetLeftHandIKMeshSpaceTransform(FTransform& OutTransform) const
{
	return GetEquippedWeaponSocketTransformInMeshSpace(WeaponLeftHandIKSocketName, OutTransform);
}

bool ASoldierCharacter::GetLeftHandIKTransformRelativeToRightHand(FTransform& OutTransform) const
{
	OutTransform = FTransform::Identity;
	FTransform LeftHandWorld;
	if (!GetLeftHandIKWorldTransform(LeftHandWorld)) return false;
	USkeletalMeshComponent* MeshComp = GetMesh();
	if (!MeshComp) return false;

	// S19-GRIPORDER: this used to ask for a literal 'hand_r'. That socket/bone
	// does not exist on a V3 / CC4 / Mixamo rig, and GetSocketTransform() on an
	// unknown name answers with the MESH COMPONENT's transform -- i.e. the feet
	// -- so this returned a plausible-looking pose built from the wrong frame,
	// with no warning. Resolve the right hand on THIS skeleton instead, with the
	// same shared resolver the grip path uses.
	FName RightHandName = ResolveGripBone(nullptr);
	if (RightHandName.IsNone() && !WeaponAttachSocketName.IsNone()
		&& MeshComp->DoesSocketExist(WeaponAttachSocketName))
	{
		RightHandName = WeaponAttachSocketName;
	}
	if (RightHandName.IsNone() || !MeshComp->DoesSocketExist(RightHandName))
	{
		// Better to report "no right hand" than to hand back a pose measured
		// from the mesh root.
		UE_LOG(LogTemp, Warning, TEXT("[WeaponIK] %s: no right-hand bone/socket found on this skeleton — "
			"left-hand IK relative to the right hand is unavailable (check WeaponAttachSocketName)."), *GetName());
		return false;
	}

	const FTransform RightHandWorld = MeshComp->GetSocketTransform(RightHandName, RTS_World);
	OutTransform = LeftHandWorld.GetRelativeTransform(RightHandWorld);
	return true;
}

bool ASoldierCharacter::GetMuzzleWorldTransform(FTransform& OutTransform) const
{
	return GetEquippedWeaponSocketTransform(WeaponMuzzleSocketName, OutTransform);
}

FWeaponIKRuntimeData ASoldierCharacter::GetWeaponIKRuntimeData() const
{
	FWeaponIKRuntimeData Data;
	Data.bEnabled = false;
	Data.Alpha = 0.f;
	Data.LeftElbowJointTargetBS = LeftElbowJointTarget_BoneSpace;

	if (!bEnableLeftHandWeaponIK || !IsAlive()) return Data;

	FTransform LeftHandMeshSpace;
	if (!GetLeftHandIKMeshSpaceTransform(LeftHandMeshSpace)) return Data;

	Data.bEnabled = true;
	Data.Alpha = LeftHandWeaponIKAlpha;
	Data.LeftHandEffectorLocationCS = LeftHandMeshSpace.GetLocation() + LeftHandIKEffectorLocationOffset_CS;
	Data.LeftHandEffectorRotationCS = (LeftHandMeshSpace.GetRotation().Rotator() + LeftHandIKRotationOffset).GetNormalized();
	Data.LeftElbowJointTargetBS = LeftElbowJointTarget_BoneSpace;

	if (bUseDynamicLeftElbowTarget)
	{
		if (USkeletalMeshComponent* MeshComp = GetMesh())
		{
			const bool bHasRefBone = MeshComp->GetBoneIndex(LeftElbowReferenceBoneName) != INDEX_NONE || MeshComp->DoesSocketExist(LeftElbowReferenceBoneName);
			if (bHasRefBone)
			{
				const FTransform RefCS = MeshComp->GetSocketTransform(LeftElbowReferenceBoneName, RTS_Component);
				Data.LeftElbowJointTargetCS = bLeftElbowOffsetInReferenceBoneSpace ? RefCS.TransformPosition(LeftElbowDynamicOffset) : RefCS.GetLocation() + LeftElbowDynamicOffset;
				Data.bUseDynamicElbowTarget = true;
			}
		}
	}

	Data.bUseLeftHandRotation = bUseLeftHandIKRotation;
	Data.LeftHandRotationAlpha = bUseLeftHandIKRotation ? LeftHandIKRotationAlpha : 0.f;
	Data.bUseLeftForearmAdditiveRotation = bUseLeftForearmAdditiveRotation;
	Data.LeftForearmAdditiveRotation = LeftForearmAdditiveRotationOffset;
	Data.LeftForearmAdditiveRotationAlpha = bUseLeftForearmAdditiveRotation ? LeftForearmAdditiveRotationAlpha : 0.f;
	Data.bUseLeftHandAdditiveRotation = bUseLeftHandAdditiveRotation;
	Data.LeftHandAdditiveRotation = LeftHandAdditiveRotationOffset;
	Data.LeftHandAdditiveRotationAlpha = bUseLeftHandAdditiveRotation ? LeftHandAdditiveRotationAlpha : 0.f;
	Data.bUseWeaponGripPose = bEnableWeaponGripPose;
	Data.LeftHandGripAlpha = bEnableWeaponGripPose ? LeftHandGripAlpha : 0.f;
	Data.RightHandGripAlpha = bEnableWeaponGripPose ? RightHandGripAlpha : 0.f;
	return Data;
}

FSoldierAnimRuntimeData ASoldierCharacter::GetSoldierAnimRuntimeData(float CoverMoveSpeedThreshold, float CoverAdjustDirectionThreshold, float CombatThreatConfidence) const
{
	FSoldierAnimRuntimeData Data;

	const FVector Velocity = GetVelocity();
	const FVector Velocity2D(Velocity.X, Velocity.Y, 0.f);
	Data.Speed = Velocity2D.Size();
	Data.Direction = 0.f;
	if (Data.Speed > KINDA_SMALL_NUMBER)
	{
		const FVector MoveDir = Velocity2D.GetSafeNormal();
		const FVector Forward = GetActorForwardVector().GetSafeNormal2D();
		const FVector Right = GetActorRightVector().GetSafeNormal2D();
		const float ForwardDot = FVector::DotProduct(MoveDir, Forward);
		const float RightDot = FVector::DotProduct(MoveDir, Right);
		Data.Direction = FMath::RadiansToDegrees(FMath::Atan2(RightDot, ForwardDot));
	}

	Data.bIsAlive = IsAlive();
	Data.bIsCrouched = bIsCrouched;
	Data.bWantsToFire = bWantsToFire;
	Data.bIsInCover = bIsInCover;
	Data.bIsCrouchingInCover = bIsCrouchingInCover;
	Data.bIsPeekingFromCover = bIsInCover && !bIsCrouchingInCover;
	Data.bCoverIsLow = IsCurrentCoverLow();
	Data.bCoverSideIsLeft = CoverSide == ESoldierCoverSide::Left;
	Data.bCoverPeekIsOver = CoverPeekType == ESoldierCoverPeekType::Over;
	Data.bIsMovingInCover = bIsInCover && Data.Speed > CoverMoveSpeedThreshold;

	const FVector MoveDir = Data.Speed > KINDA_SMALL_NUMBER ? Velocity2D.GetSafeNormal() : FVector::ZeroVector;
	Data.CoverMoveDirection = Data.Speed > KINDA_SMALL_NUMBER ? FVector::DotProduct(MoveDir, GetActorRightVector().GetSafeNormal2D()) : 0.f;
	Data.bIsAdjustingCover = Data.bIsMovingInCover && FMath::Abs(Data.CoverMoveDirection) < CoverAdjustDirectionThreshold;

	if (AimComp)
	{
		const FRotator AimOffset = AimComp->GetSpineAimOffset();
		Data.AimYaw = FMath::Clamp(AimOffset.Yaw, -90.f, 90.f);
		Data.AimPitch = FMath::Clamp(AimOffset.Pitch, -90.f, 90.f);
	}

	if (const ASoldierAIController* AIC = Cast<ASoldierAIController>(GetController()))
	{
		Data.bCombatReady = AIC->HasCombatThreat(CombatThreatConfidence);
	}
	else
	{
		Data.bCombatReady = false;
	}

	Data.WeaponIK = GetWeaponIKRuntimeData();
	return Data;
}

void ASoldierCharacter::PlayFireAnimation()
{
	bWantsToFire = true;
	LastFireAnimTime = GetWorld() ? GetWorld()->GetTimeSeconds() : 0.f;

	if (bUsePackPresentationMode)
	{
		return;
	}

	UAnimMontage* MontageToPlay = SelectFireMontage();
	if (!MontageToPlay)
	{
		UE_LOG(LogTemp, Verbose, TEXT("FireAnim: %s wants to fire but no suitable FireMontage is assigned. InCover=%d Low=%d Side=%s Peek=%s Crouched=%d"),
			*GetNameSafe(this), bIsInCover ? 1 : 0, IsCurrentCoverLow() ? 1 : 0,
			CoverSide == ESoldierCoverSide::Left ? TEXT("Left") : TEXT("Right"),
			CoverPeekType == ESoldierCoverPeekType::Over ? TEXT("Over") : TEXT("Side"),
			bIsCrouched ? 1 : 0);
		return;
	}

	USkeletalMeshComponent* MeshComp = GetMesh();
	if (!MeshComp)
	{
		UE_LOG(LogTemp, Warning, TEXT("FireAnim: %s has montage %s but GetMesh() is null."), *GetNameSafe(this), *GetNameSafe(MontageToPlay));
		return;
	}

	UAnimInstance* AnimInst = MeshComp->GetAnimInstance();
	if (!AnimInst)
	{
		UE_LOG(LogTemp, Warning, TEXT("FireAnim: %s has montage %s but mesh %s has no AnimInstance. Check Anim Class on Mesh."),
			*GetNameSafe(this), *GetNameSafe(MontageToPlay), *GetNameSafe(MeshComp->GetSkeletalMeshAsset()));
		return;
	}

	const float PlayedLength = AnimInst->Montage_Play(MontageToPlay, 1.f);
	UE_LOG(LogTemp, Verbose, TEXT("FireAnim: %s Montage_Play(%s) on AnimBP=%s returned %.3f. Mesh=%s InCover=%d Low=%d Side=%s Peek=%s"),
		*GetNameSafe(this), *GetNameSafe(MontageToPlay), *GetNameSafe(AnimInst->GetClass()), PlayedLength,
		*GetNameSafe(MeshComp->GetSkeletalMeshAsset()), bIsInCover ? 1 : 0, IsCurrentCoverLow() ? 1 : 0,
		CoverSide == ESoldierCoverSide::Left ? TEXT("Left") : TEXT("Right"),
		CoverPeekType == ESoldierCoverPeekType::Over ? TEXT("Over") : TEXT("Side"));

	if (PlayedLength <= 0.f)
	{
		UE_LOG(LogTemp, Warning, TEXT("FireAnim: Montage did not start. Usually skeleton mismatch, bad slot setup, or montage incompatible with this AnimInstance."));
	}
}

void ASoldierCharacter::PlayReloadAnimation()
{
	UAnimMontage* MontageToPlay = SelectReloadMontage();
	if (!MontageToPlay)
	{
		UE_LOG(LogTemp, Verbose, TEXT("ReloadAnim: %s requested reload but no suitable ReloadMontage is assigned."), *GetNameSafe(this));
		return;
	}

	USkeletalMeshComponent* MeshComp = GetMesh();
	UAnimInstance* AnimInst = MeshComp ? MeshComp->GetAnimInstance() : nullptr;
	if (!AnimInst)
	{
		UE_LOG(LogTemp, Warning, TEXT("ReloadAnim: %s has montage %s but no AnimInstance."), *GetNameSafe(this), *GetNameSafe(MontageToPlay));
		return;
	}

	const float PlayedLength = AnimInst->Montage_Play(MontageToPlay, 1.f);
	UE_LOG(LogTemp, Verbose, TEXT("ReloadAnim: %s Montage_Play(%s) returned %.3f InCover=%d Low=%d Side=%s Peek=%s"),
		*GetNameSafe(this), *GetNameSafe(MontageToPlay), PlayedLength,
		bIsInCover ? 1 : 0, IsCurrentCoverLow() ? 1 : 0,
		CoverSide == ESoldierCoverSide::Left ? TEXT("Left") : TEXT("Right"),
		CoverPeekType == ESoldierCoverPeekType::Over ? TEXT("Over") : TEXT("Side"));
}

void ASoldierCharacter::ResetSpawnGracePeriod(float Duration)
{
	InitialCombatGraceTimer = FMath::Max(Duration, 0.0f);
	if (GetWorld() && InitialCombatGraceTimer > 0.0f)
	{
		GetWorld()->GetTimerManager().ClearTimer(CombatGraceTimerHandle);
		GetWorld()->GetTimerManager().SetTimer(CombatGraceTimerHandle, this, &ASoldierCharacter::EndCombatGracePeriod, InitialCombatGraceTimer, false);
	}
}

#include "SoldierCharacter_PresentationHelpers.inc"

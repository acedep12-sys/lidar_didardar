// EnemyCommanderAssistant.cpp - S19-ELITE
#include "Characters/EnemyCommanderAssistant.h"
#include "Characters/EnemyCommander.h"
#include "Characters/SoldierCharacter.h"
#include "Components/HealthComponent.h"
#include "Components/WeaponComponent.h"
#include "HUD/QuestNativeHUD.h"
#include "Diagnostics/SquadAISituationLog.h"
#include "Engine/World.h"
#include "EngineUtils.h"                 // TActorIterator (commander auto-find)
#include "CollisionQueryParams.h"

AEnemyCommanderAssistant::AEnemyCommanderAssistant()
{
	Faction = ESquadFaction::Enemy;
	bCanBeDowned = false;                // downed-and-revived is for allies, not the escort
	CharacterDisplayName = FText::FromString(TEXT("کمکیار فرمانده"));

	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 0.1f;   // escort distance + heal channel, twice a second
}

void AEnemyCommanderAssistant::BeginPlay()
{
	Super::BeginPlay();

	// Rules first (Details panel wins over the model defaults).
	Tuning.HealthMultiplier = HealthMultiplier;
	Tuning.EscortRadius = EscortRadius;
	Tuning.HealBelowHealthFraction = HealBelowHealthFraction;
	Tuning.HealRange = HealRange;
	Tuning.HealPerSecond = HealPerSecond;
	Tuning.HealMaxChannelSeconds = HealMaxChannelSeconds;
	Tuning.HealCooldownSeconds = HealCooldownSeconds;
	Tuning.EnrageSeconds = EnrageSeconds;
	Tuning.MoraleBreakSeconds = MoraleBreakSeconds;

	if (HealthComp)
	{
		HealthComp->MaxHealth = SquadAIEliteSquad::EliteMaxHealth(HealthComp->MaxHealth, HealthMultiplier);
		HealthComp->CurrentHealth = HealthComp->MaxHealth;

		if (!bBindingsDone)
		{
			HealthComp->OnDeath.AddDynamic(this, &AEnemyCommanderAssistant::HandleOwnerDeath);
			bBindingsDone = true;
		}
	}

	AccuracyMultiplier = AccuracyMultiplierOverride;
	if (WeaponComp)
	{
		WeaponComp->AccuracyMultiplier = AccuracyMultiplierOverride;
		WeaponComp->DamageMultiplier = DamageMultiplierOverride;
	}

	// The spawner calls SetCommander() immediately after spawning an escort, which is
	// AFTER this BeginPlay - so an auto-find here could grab a different commander and
	// leave the wrong one counting this assistant in his relay. Binding is therefore lazy:
	// TickCommanderBind looks for a commander only if nothing has assigned one.
	if (Commander)
	{
		Commander->RegisterAssistant(this);
	}

	SquadAISituation::Note(FString::Printf(
		TEXT("ELITE assistant %s ready: hp %.0f/%.0f (x%.1f), commander %s, escort leash %.0f m, heals %.0f hp/s below %.0f%%"),
		*GetName(), HealthComp ? HealthComp->CurrentHealth : -1.f, HealthComp ? HealthComp->MaxHealth : -1.f,
		HealthMultiplier, *GetNameSafe(Commander), EscortRadius / 100.f,
		HealPerSecond, HealBelowHealthFraction * 100.f));
}

void AEnemyCommanderAssistant::SetCommander(AEnemyCommander* InCommander)
{
	Commander = InCommander;
	bCommanderAssignedExplicitly = true;   // an explicit assignment always wins
	if (Commander)
	{
		Commander->RegisterAssistant(this);
	}
}

void AEnemyCommanderAssistant::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	TickCommanderBind(DeltaSeconds);
	TickEscort(DeltaSeconds);
	TickMedic(DeltaSeconds);
	TickMorale(DeltaSeconds);
}

// =========================================================================
//  Binding
// =========================================================================
void AEnemyCommanderAssistant::TickCommanderBind(float DeltaSeconds)
{
	// Hand-placed assistants (no spawner to introduce them) find their commander here,
	// once a second, and stop looking the moment one is assigned.
	if (Commander || bCommanderAssignedExplicitly)
	{
		return;
	}
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}
	RetryBindCooldown -= DeltaSeconds;
	if (RetryBindCooldown > 0.f)
	{
		return;
	}
	RetryBindCooldown = 1.0f;

	float BestDist = TNumericLimits<float>::Max();
	AEnemyCommander* Best = nullptr;
	for (TActorIterator<AEnemyCommander> It(World); It; ++It)
	{
		if (!It->IsAlive())
		{
			continue;
		}
		const float D = FVector::Dist(GetActorLocation(), It->GetActorLocation());
		if (D < BestDist)
		{
			BestDist = D;
			Best = *It;
		}
	}
	if (Best)
	{
		SetCommander(Best);
		SquadAISituation::Note(FString::Printf(TEXT("ELITE assistant %s: bound to commander %s at %.0f m (hand-placed, no spawner introduction)"),
			*GetName(), *Best->GetName(), BestDist / 100.f));
	}
}

// =========================================================================
//  Escort
// =========================================================================
void AEnemyCommanderAssistant::TickEscort(float DeltaSeconds)
{
	if (!Commander || !Commander->IsAlive())
	{
		// The commander is gone: the escort leash is meaningless, and the morale tick
		// below owns his aggression from here on.
		bReturningToCommander = false;
		return;
	}

	const float Dist = FVector::Dist(GetActorLocation(), Commander->GetActorLocation());

	// Hysteresis, so he does not flap between "go back" and "advance" on the boundary.
	if (!bReturningToCommander)
	{
		if (SquadAIEliteSquad::NeedsEscortReturn(Tuning, Dist))
		{
			bReturningToCommander = true;
			SquadAISituation::Note(FString::Printf(
				TEXT("ELITE assistant %s: %.0f m from the commander (leash %.0f m) - returning to him"),
				*GetName(), Dist / 100.f, EscortRadius / 100.f));
		}
	}
	else if (SquadAIEliteSquad::EscortReturnFinished(Tuning, Dist))
	{
		bReturningToCommander = false;
	}

	if (bReturningToCommander && bEscortOverridesAttackPoint)
	{
		// The attack point is what this codebase's enemy AI walks toward; pointing it at
		// the commander is exactly "go back to him" without inventing a second movement
		// system that would fight the state tree.
		AssignedAttackPoint = Commander->GetActorLocation();
	}
}

// =========================================================================
//  Medic
// =========================================================================
void AEnemyCommanderAssistant::TickMedic(float DeltaSeconds)
{
	if (HealCooldownRemaining > 0.f)
	{
		HealCooldownRemaining = FMath::Max(0.f, HealCooldownRemaining - DeltaSeconds);
	}

	// ---- already channeling ----
	if (bHealingCommander)
	{
		const bool bStillValid = Commander && Commander->IsAlive() && Commander->HealthComp && IsAlive()
			&& FVector::Dist(GetActorLocation(), Commander->GetActorLocation()) <= HealRange;
		if (!bStillValid)
		{
			bHealingCommander = false;
			ChannelSeconds = 0.f;
			HealCooldownRemaining = HealCooldownSeconds;
			if (Commander)
			{
				Commander->NoteHealChannel(this, false);
			}
			return;
		}

		const float Before = Commander->HealthComp->CurrentHealth;
		const float After = SquadAIEliteSquad::HealStep(Tuning, Before,
			Commander->HealthComp->MaxHealth, DeltaSeconds, true);
		if (After > Before)
		{
			// Through the component's own Heal(), so its OnHealthChanged broadcast (and
			// therefore the HUD's health bars) sees the healing.
			Commander->HealthComp->Heal(After - Before);
		}

		ChannelSeconds += DeltaSeconds;
		if (SquadAIEliteSquad::HealChannelExpired(Tuning, ChannelSeconds))
		{
			bHealingCommander = false;
			ChannelSeconds = 0.f;
			HealCooldownRemaining = HealCooldownSeconds;
			Commander->NoteHealChannel(this, false);
			SquadAISituation::Note(FString::Printf(
				TEXT("ELITE assistant %s: heal channel finished (commander at %.0f/%.0f) - cooldown %.0fs"),
				*GetName(), Commander->HealthComp->CurrentHealth, Commander->HealthComp->MaxHealth,
				HealCooldownSeconds));
		}
		return;
	}

	// ---- start a channel? ----
	if (!Commander || !Commander->IsAlive() || !Commander->HealthComp || !IsAlive())
	{
		return;
	}
	const float Dist = FVector::Dist(GetActorLocation(), Commander->GetActorLocation());
	const float Frac = Commander->HealthComp->GetHealthPercent();
	if (!SquadAIEliteSquad::ShouldBeginHeal(Tuning, Frac, Dist, HealCooldownRemaining, true))
	{
		return;
	}

	// Line of sight: a wall between them stops the medic. (The escort leash gets him
	// close; this stops him healing through a building once he is there.)
	if (bHealRequiresLineOfSight && GetWorld())
	{
		FHitResult Hit;
		FCollisionQueryParams Params(SCENE_QUERY_STAT(EliteHealLOS), false, this);
		Params.AddIgnoredActor(Commander);
		const FVector From = GetActorLocation() + FVector(0.f, 0.f, 60.f);
		const FVector To = Commander->GetActorLocation() + FVector(0.f, 0.f, 60.f);
		if (GetWorld()->LineTraceSingleByChannel(Hit, From, To, ECC_Visibility, Params))
		{
			return;   // blocked
		}
	}

	bHealingCommander = true;
	ChannelSeconds = 0.f;
	Commander->NoteHealChannel(this, true);
	SquadAISituation::Note(FString::Printf(
		TEXT("ELITE assistant %s: HEALING the commander (%.0f%%, %.0f m away, %.0f hp/s for up to %.1fs)"),
		*GetName(), Frac * 100.f, Dist / 100.f, HealPerSecond, HealMaxChannelSeconds));

	if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this))
	{
		HUD->ShowAlertBanner(
			AQuestNativeHUD::LocalizeHUDText(this, TEXT("HUD"), TEXT("CommanderHealing"),
				TEXT("کمکیار در حال درمان فرمانده است — او را بزنید!"),
				TEXT("THE ASSISTANT IS HEALING THE COMMANDER - SHOOT HIM!")),
			FLinearColor(0.30f, 0.85f, 0.45f), 4.f);
	}
}

// =========================================================================
//  Morale
// =========================================================================
void AEnemyCommanderAssistant::BeginEnrage(float Seconds)
{
	if (!IsAlive())
	{
		return;
	}
	bMoraleBroken = false;
	bEnraged = true;
	EnrageEndsAt = GetWorld() ? (GetWorld()->GetTimeSeconds() + FMath::Max(Seconds, 0.1f)) : -1.f;
	BreakEndsAt = -1.f;

	// The aggression itself is owned by the commander's aura while the net is up (it
	// composes this flag in); this is the fallback for when there is no aura writer left.
	if (!Commander || !Commander->IsAuraActive())
	{
		Aggression = SquadAIEliteSquad::AssistantAggression(Tuning, true, false, Aggression);
		if (HealthComp)
		{
			HealthComp->IncomingDamageMultiplier = FMath::Clamp(1.f - Tuning.EnrageResistBonus, 0.05f, 1.f);
		}
	}

	SquadAISituation::Note(FString::Printf(TEXT("ELITE assistant %s: ENRAGED for %.0fs (aggression -> %.2f)"),
		*GetName(), Seconds, Aggression));
}

void AEnemyCommanderAssistant::OnCommanderDied()
{
	if (!IsAlive())
	{
		return;
	}
	BeginEnrage(EnrageSeconds);

	// After the rage burns out they break: no more pushing, they cower in cover.
	BreakEndsAt = GetWorld() ? (GetWorld()->GetTimeSeconds() + EnrageSeconds + MoraleBreakSeconds) : -1.f;
	EnrageEndsAt = GetWorld() ? (GetWorld()->GetTimeSeconds() + EnrageSeconds) : -1.f;

	SquadAISituation::Note(FString::Printf(
		TEXT("ELITE assistant %s: commander is down - berserk for %.0fs, then morale breaks for %.0fs"),
		*GetName(), EnrageSeconds, MoraleBreakSeconds));
}

void AEnemyCommanderAssistant::TickMorale(float DeltaSeconds)
{
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}
	const float Now = World->GetTimeSeconds();

	// The aura composes these flags itself for everyone inside the net; this tick is the
	// writer for everyone the net does not reach - no commander, the relay lapsed, or
	// simply being out of aura range. Without the range test an assistant who chased the
	// player out of the net would keep neutral numbers through his own berserk.
	const bool bAuraWrites = Commander && Commander->IsInsideAura(this);

	if (bEnraged && EnrageEndsAt > 0.f && Now >= EnrageEndsAt)
	{
		bEnraged = false;
		EnrageEndsAt = -1.f;
		SquadAISituation::Note(FString::Printf(TEXT("ELITE assistant %s: rage burned out"), *GetName()));
	}

	// "The commander is gone" covers both: he died (weak ptr still valid) and he was
	// destroyed (weak ptr null). Checking only IsAlive() left the break permanently
	// armed in the second case.
	const bool bCommanderGone = !Commander || !Commander->IsAlive();
	if (!bMoraleBroken && bCommanderGone && !bEnraged && BreakEndsAt > 0.f && Now >= BreakEndsAt)
	{
		bMoraleBroken = true;
		BreakEndsAt = -1.f;
		SquadAISituation::Note(FString::Printf(TEXT("ELITE assistant %s: MORALE BROKEN - stops pushing, stays in cover"),
			*GetName()));
	}

	if (!bAuraWrites)
	{
		Aggression = SquadAIEliteSquad::AssistantAggression(Tuning, bEnraged, bMoraleBroken, Aggression);
		if (HealthComp)
		{
			const float Resist = bEnraged ? Tuning.EnrageResistBonus : 0.f;
			HealthComp->IncomingDamageMultiplier = FMath::Clamp(1.f - Resist, 0.05f, 1.f);
		}
	}
}

void AEnemyCommanderAssistant::HandleOwnerDeath(AActor* OwnerActor)
{
	SquadAISituation::Note(FString::Printf(
		TEXT("ELITE assistant %s DOWN - %s"),
		*GetName(),
		(Commander && Commander->IsAlive()) ? TEXT("the relay now runs on the assistants who are left") : TEXT("he outlived his commander")));

	if (bHealingCommander && Commander)
	{
		Commander->NoteHealChannel(this, false);
		bHealingCommander = false;
	}
}

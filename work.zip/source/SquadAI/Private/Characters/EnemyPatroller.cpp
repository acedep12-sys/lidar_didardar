// EnemyPatroller.cpp - S19-PATROL
#include "Characters/EnemyPatroller.h"
#include "Actors/EnemyPatrolRoute.h"
#include "AI/EnemyPatrolAIController.h"
#include "AI/SoldierAIController.h"
#include "Components/HealthComponent.h"
#include "Performance/SoldierRegistrySubsystem.h"
#include "Diagnostics/SquadAISituationLog.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Navigation/PathFollowingComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/World.h"
#include "EngineUtils.h"                 // TActorIterator (route auto-bind)
#include "DrawDebugHelpers.h"

AEnemyPatroller::AEnemyPatroller()
{
	Faction = ESquadFaction::Enemy;
	bCanBeDowned = false;                // a patrol casualty stays a casualty

	// His own controller: the one that makes the patrol point the movement goal while calm.
	AIControllerClass = AEnemyPatrolAIController::StaticClass();

	// 10 Hz is plenty for "which point am I walking to" and a short-range attention test; the
	// actual movement is executed by the controller, which still ticks every frame.
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 0.1f;

	if (HealthComp)
	{
		// A patroller is a normal enemy - no elite armour. Set explicitly so a Blueprint that
		// re-parents an elite by accident does not inherit a boss's numbers.
		HealthComp->MaxSingleHitFraction = 0.f;
		HealthComp->IncomingDamageMultiplier = 1.f;
	}
}

// =========================================================================
//  Life
// =========================================================================
void AEnemyPatroller::BeginPlay()
{
	Super::BeginPlay();

	SyncTuning();
	ConfigureController();

	if (HealthComp && !bBindingsDone)
	{
		HealthComp->OnDamaged.AddDynamic(this, &AEnemyPatroller::HandlePatrollerDamaged);
		bBindingsDone = true;
	}

	// He is not an assault enemy. Aggression drives the tactical layer (advance vs hold).
	Aggression = FMath::Clamp(PatrolAggression, 0.f, 1.f);

	if (PatrolRoute)
	{
		SetPatrolRoute(PatrolRoute, bStartAtNearestPoint);
	}
	else
	{
		AcquireRoute();
	}

	ApplyWalkSpeed();

	// Seed the teleport detector with where he actually starts (the pool spawns patrollers
	// parked below the world), so the first tick after a wake sees the jump.
	LastTickLocation = GetActorLocation();

	SquadAISituation::Note(FString::Printf(
		TEXT("S19-PATROL %s: on duty - route=%s points=%d mode=%d walk=%.0f spot=%.0f m (hear %.0f m) leash=%.0f m"),
		*GetName(),
		PatrolRoute ? *PatrolRoute->RouteName : TEXT("<none bound yet>"),
		PatrolRoute ? PatrolRoute->GetPointCount() : 0,
		static_cast<int32>(PatrolMode),
		PatrolWalkSpeed, Tuning.SpotRange / 100.f, Tuning.SpotHearRange / 100.f, Tuning.RouteLeashRadius / 100.f));
}

void AEnemyPatroller::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);
	if (!IsAlive())
	{
		return;
	}

	// The controller can arrive after BeginPlay (spawners call SpawnDefaultController after the
	// actor exists), so this retries until it lands.
	if (!bControllerConfigured)
	{
		ConfigureController();
	}

	// Did he TELEPORT between ticks? At 10 Hz he covers under half a metre per tick, so a jump of
	// 20 m is not walking: the enemy pool parks pawns 100 m below the world and wakes them at the
	// spawn point, and a designer may teleport one. Treated as a fresh start - a stale alert from
	// a previous life must not follow him to the new spot (and he must not sprint at a player he
	// last saw before the jump), and the route is re-picked immediately rather than in 2 s.
	const FVector Here = GetActorLocation();
	if (!LastTickLocation.IsNearlyZero()
		&& FVector::DistSquared(Here, LastTickLocation) > FMath::Square(2000.f))
	{
		HandleTeleportWake(Here);
	}
	LastTickLocation = Here;

	UpdateAlert(DeltaSeconds);

	// While he is engaged with a hostile the controller owns his movement (advance, take
	// cover, fire). Otherwise the beat is his - including while he is merely ON the alert
	// (a shout, a scripted alert): he keeps walking his route, faster, looking for the
	// intruder, and hands movement over the moment he finds one.
	if (!IsEngaged())
	{
		UpdatePatrol(DeltaSeconds);
	}

	if (bDrawPatrolDebug)
	{
		DrawPatrolDebug();
	}
}

void AEnemyPatroller::SyncTuning()
{
	// Only the fields the model actually owns. The arrive radius and the per-point pause are
	// arguments/route data, not tuning (a wrong field here is a C2039 - caught by audit
	// check 10, which exists because this line was wrong on the first write).
	Tuning.SpotRange = SpotRange;
	Tuning.SpotHearRange = SpotHearRange;
	Tuning.AlertLingerSeconds = AlertLingerSeconds;
	Tuning.AlertVisibleRangeScale = AlertVisibleRangeScale;
	Tuning.RouteLeashRadius = RouteLeashRadius;
}

void AEnemyPatroller::ConfigureController()
{
	ASoldierAIController* AI = Cast<ASoldierAIController>(GetController());
	if (!AI)
	{
		return;
	}

	// "If they see me or allies in SHORT range, they will attack" - and, just as important,
	// that they ignore you past it. The base enemy AI perceives hostiles and shoots them out
	// to DirectCombatRange (90 m) and advances on the player from 120 m. A patrol's envelopes
	// are therefore capped to his own spot range, on HIS controller only: every other enemy in
	// the level keeps the long reach it had.
	//
	// This first application is immediate (so there is no window before the first tick), and the
	// patrol controller re-applies it every tick - see ApplyPatrolEnvelope: the base controller's
	// own BeginPlay writes these three fields from the global tuning and, for a LEVEL-PLACED
	// pawn, that BeginPlay runs after this one, which reverted a one-shot clamp.
	AEnemyPatrolAIController::ApplyPatrolEnvelope(AI, Tuning.SpotRange, Tuning.SpotHearRange);

	bControllerConfigured = true;

	SquadAISituation::Note(FString::Printf(
		TEXT("S19-PATROL %s: attention capped - engages from %.0f m, ignores beyond it (hearing %.0f m)"),
		*GetName(), Tuning.SpotRange / 100.f, Tuning.SpotHearRange / 100.f));
}

// =========================================================================
//  The route
// =========================================================================
void AEnemyPatroller::AcquireRoute()
{
	if (PatrolRoute || !GetWorld())
	{
		return;
	}

	if (AutoBindRouteRadius <= 0.f)
	{
		// 0 is the conventional off switch. (It used to mean "no limit", which could bind a pawn
		// to a route on the other side of the map - and did, for a pawn the pool parks at the
		// world origin.)
		if (!bNoRouteLogged)
		{
			bNoRouteLogged = true;
			SquadAISituation::Note(FString::Printf(
				TEXT("S19-PATROL %s: auto-bind is off (Auto Bind Route Radius = 0) - set his Patrol Route ")
				TEXT("field, or raise the radius if he is meant to find a route by himself."),
				*GetName()));
		}
		return;
	}

	AEnemyPatrolRoute* Best = nullptr;
	float BestDist = TNumericLimits<float>::Max();
	for (TActorIterator<AEnemyPatrolRoute> It(GetWorld()); It; ++It)
	{
		AEnemyPatrolRoute* Candidate = *It;
		if (!Candidate || Candidate->GetPointCount() == 0)
		{
			continue;
		}
		// Distance to the route LINE (not to its actor origin): a route whose actor sits at one
		// end of the beat still binds to a patroller standing at the other end. Measured in 3D,
		// so the pool's parking spot (100 m below the world) binds to nothing at all.
		const float D = Candidate->DistanceToRoute3D(GetActorLocation());
		if (D < BestDist)
		{
			BestDist = D;
			Best = Candidate;
		}
	}

	if (Best && BestDist <= AutoBindRouteRadius)
	{
		SetPatrolRoute(Best, bStartAtNearestPoint);
		bRouteAutoBound = true;
		return;
	}

	// The enemy pool prewarms and parks pawns at (0, 0, -10000) before waking them somewhere
	// real, so "no route in range" is expected there and must not look like a setup mistake.
	const bool bParkedBelowWorld = GetActorLocation().Z <= -9000.f;

	if (!bNoRouteLogged && !bParkedBelowWorld)
	{
		bNoRouteLogged = true;
		SquadAISituation::Note(FString::Printf(
			TEXT("S19-PATROL %s: WARNING - no patrol route with points within %.0f m (nearest is %.0f m). ")
			TEXT("He will stand his ground and fight like a normal enemy. Place an Enemy Patrol Route ")
			TEXT("actor near him, or point his Patrol Route field at one."),
			*GetName(), AutoBindRouteRadius / 100.f, BestDist == TNumericLimits<float>::Max() ? -1.f : BestDist / 100.f));
	}
}

void AEnemyPatroller::SetPatrolRoute(AEnemyPatrolRoute* NewRoute, bool bSnapToNearestPoint)
{
	PatrolRoute = NewRoute;
	bRouteAutoBound = false;   // an explicit route is never re-picked; AcquireRoute sets this

	if (!PatrolRoute)
	{
		CurrentPatrolPoint = FVector::ZeroVector;
		return;
	}

	const int32 Count = PatrolRoute->GetPointCount();
	if (Count <= 0)
	{
		// A route actor with no points yet (nobody has pressed Add, or the route was cleared).
		// Leave the goal empty so his controller falls back to normal enemy behaviour instead of
		// walking him to the route actor's origin - and note the cursor: the model's
		// MakeStartCursor(0, ...) returns a FINISHED cursor, and a finished cursor never moves
		// again, so a route that got its points a moment later would never start. A plain cursor
		// means the beat begins by itself the moment there is a point (UpdatePatrol re-reads the
		// count and the point every tick).
		Cursor = FPatrolCursor();
		CurrentPointIndex = 0;
		CurrentPatrolPoint = FVector::ZeroVector;
		LastMoveGoal = FVector::ZeroVector;
		SquadAISituation::Note(FString::Printf(
			TEXT("S19-PATROL %s: route '%s' has no points yet - select the route actor and press Add"),
			*GetName(), *PatrolRoute->RouteName));
		return;
	}

	const int32 Preferred = (bSnapToNearestPoint || bStartAtNearestPoint)
		? PatrolRoute->FindNearestPointIndex(GetActorLocation())
		: StartPointIndex;

	Cursor = SquadAIPatrol::MakeStartCursor(Count, Preferred, PatrolMode == EPatrolMode::PingPong);
	bWaiting = false;
	WaitRemaining = 0.f;
	CurrentPointIndex = SquadAIPatrol::ClampIndex(Cursor.Index, Count);
	CurrentPatrolPoint = PatrolRoute->GetPointLocation(CurrentPointIndex);
	LastMoveGoal = FVector::ZeroVector;

	SquadAISituation::Note(FString::Printf(
		TEXT("S19-PATROL %s: bound to route '%s' (%d point(s), %.0f m of beat). Starting on point %d."),
		*GetName(), *PatrolRoute->RouteName, Count, PatrolRoute->GetRouteLength2D() / 100.f, CurrentPointIndex + 1));
}

FPatrolCursor AEnemyPatroller::AdvanceCursorForMode(const FPatrolCursor& In, int32 Count) const
{
	switch (PatrolMode)
	{
	case EPatrolMode::PingPong:
		return SquadAIPatrol::AdvancePingPong(In, Count);
	case EPatrolMode::Once:
		return SquadAIPatrol::AdvanceOnce(In, Count);
	case EPatrolMode::Loop:
	default:
		return SquadAIPatrol::AdvanceLoop(In, Count);
	}
}

void AEnemyPatroller::HandleTeleportWake(const FVector& Where)
{
	if (bAlerted)
	{
		ExitAlert(TEXT("moved a long way in one tick - woken or teleported"));
	}
	LastSpottedActor = nullptr;
	// Spend the linger window now, so he does not re-alert the moment he is put down somewhere.
	SecondsSinceSpotted = FMath::Max(SecondsSinceSpotted, Tuning.AlertLingerSeconds);
	NextRouteScanTime = -1.f;   // re-pick the route on the next tick, not in two seconds
	bWaiting = false;
	WaitRemaining = 0.f;

	SquadAISituation::Note(FString::Printf(
		TEXT("S19-PATROL %s: placed at %s - fresh start (alert cleared, route re-picked)"),
		*GetName(), *Where.ToCompactString()));
}

void AEnemyPatroller::UpdatePatrol(float DeltaSeconds)
{
	// Re-picking the route covers two cases: no route yet (nobody has bound him), and a
	// re-used pawn that woke up somewhere else - the enemy pool parks pawns 100 m below the
	// world and wakes them at a new spawn point, so a route bound in a previous life would
	// otherwise be the wrong one forever. Either way, not on every tick: a full TActorIterator
	// at 10 Hz per pawn is wasted work, and the answer can only change when a route actor
	// appears or the pawn moves. Two seconds is fast enough to pick one up live.
	const float DriftLimit = (AutoBindRouteRadius > 0.f) ? (AutoBindRouteRadius * 1.5f) : 9000.f;
	const float Dist3D = PatrolRoute ? PatrolRoute->DistanceToRoute3D(GetActorLocation())
	                                 : TNumericLimits<float>::Max();
	const bool bDrifted = PatrolRoute && bRouteAutoBound && Dist3D > DriftLimit;

	if (!PatrolRoute || bDrifted)
	{
		UWorld* ScanWorld = GetWorld();
		const float ScanNow = ScanWorld ? ScanWorld->GetTimeSeconds() : 0.f;
		if (NextRouteScanTime < 0.f || ScanNow >= NextRouteScanTime)
		{
			NextRouteScanTime = ScanNow + 2.f;
			if (bDrifted)
			{
				SquadAISituation::Note(FString::Printf(
					TEXT("S19-PATROL %s: %.0f m away from auto-bound route '%s' - looking for the nearest route again"),
					*GetName(), Dist3D / 100.f, *PatrolRoute->RouteName));
				PatrolRoute = nullptr;
				bRouteAutoBound = false;
			}
			AcquireRoute();
		}
		if (!PatrolRoute)
		{
			return;
		}
	}

	const int32 Count = PatrolRoute->GetPointCount();
	if (!SquadAIPatrol::HasPoints(Count))
	{
		return;
	}

	// Walking back after a chase: he is inside the leash again, so his beat resumes normally.
	if (bReturningToRoute && SquadAIPatrol::LeashReturnFinished(
		PatrolRoute->DistanceToRoute2D(GetActorLocation()), Tuning))
	{
		bReturningToRoute = false;
		SquadAISituation::Note(FString::Printf(TEXT("S19-PATROL %s: back on the route - resuming the beat"),
			*GetName()));
	}

	CurrentPointIndex = SquadAIPatrol::ClampIndex(Cursor.Index, Count);
	CurrentPatrolPoint = PatrolRoute->GetPointLocation(CurrentPointIndex);

	if (Cursor.bFinished)
	{
		return;   // Once mode: he has reached the end and holds there
	}

	const float DistToPoint = FVector::Dist2D(GetActorLocation(), CurrentPatrolPoint);
	if (!SquadAIPatrol::ArrivedAtPoint(DistToPoint, ArriveRadius))
	{
		DrivePatrolMovement();
		return;
	}

	// At the point: pause, then take the next step.
	if (!bWaiting)
	{
		bWaiting = true;
		const FEnemyPatrolPoint& Point = PatrolRoute->Points[CurrentPointIndex];
		WaitRemaining = SquadAIPatrol::PointWaitSeconds(Point.WaitSeconds, PatrolRoute->DefaultPointWaitSeconds);
		if (AController* C = GetController())
		{
			C->StopMovement();   // stand still while he looks around, do not shuffle on the spot
		}
	}

	WaitRemaining = SquadAIPatrol::TickWaitRemaining(WaitRemaining, DeltaSeconds);
	if (!SquadAIPatrol::WaitFinished(WaitRemaining))
	{
		return;
	}

	bWaiting = false;
	const FPatrolCursor Before = Cursor;
	Cursor = AdvanceCursorForMode(Cursor, Count);

	if (Cursor.bFinished && !Before.bFinished)
	{
		SquadAISituation::Note(FString::Printf(
			TEXT("S19-PATROL %s: end of route '%s' reached - holding point %d (Once mode)"),
			*GetName(), *PatrolRoute->RouteName, Cursor.Index + 1));
	}
}

void AEnemyPatroller::DrivePatrolMovement()
{
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}
	const float Now = World->GetTimeSeconds();

	AAIController* AI = Cast<AAIController>(GetController());
	if (!AI)
	{
		return;   // not possessed yet; Tick retries the next frame
	}
	UPathFollowingComponent* PFC = AI->GetPathFollowingComponent();
	const bool bMoving = PFC && PFC->GetStatus() == EPathFollowingStatus::Moving;

	const bool bGoalMoved = !LastMoveGoal.IsNearlyZero()
		&& FVector::DistSquared(LastMoveGoal, CurrentPatrolPoint) > FMath::Square(100.f);

	// Same discipline as the base AI: never rebuild a path that is already running, unless the
	// destination actually moved (a designer dragging the point in the editor).
	if (bMoving && !bGoalMoved && (Now - LastRepathTime) < 2.5f)
	{
		return;
	}

	AI->MoveToLocation(CurrentPatrolPoint, SquadAIPatrol::EffectiveArriveRadius(ArriveRadius),
		true, true, true, false, nullptr, true);

	LastRepathTime = Now;
	LastMoveGoal = CurrentPatrolPoint;
}

// =========================================================================
//  Attention
// =========================================================================
void AEnemyPatroller::UpdateAlert(float DeltaSeconds)
{
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}
	const float Now = World->GetTimeSeconds();

	// Hostility is asked of the CONTROLLER, never of the pawn: ASoldierAIController is the
	// implementation that knows the pack player pawn (it does not implement the team
	// interface, so it reads Neutral at pawn level) is an enemy, and it is also where the
	// tutorial's player protection lives. Asking the pawn made the patrol blind to the
	// player - the one thing a patrolling enemy must never be. QuestZone reads attitudes
	// the same way.
	ASoldierAIController* AI = Cast<ASoldierAIController>(GetController());

	// The closest hostile he could possibly perceive this frame. The envelopes are short by
	// design (SpotRange / SpotHearRange), which is what "short range" means here.
	const float MaxSense = FMath::Max(Tuning.SpotRange, Tuning.SpotHearRange);
	float BestDist = TNumericLimits<float>::Max();
	AActor* Best = nullptr;

	auto Consider = [&](AActor* Other)
	{
		if (!Other || Other == this)
		{
			return;
		}
		// No pawn-level fallback on purpose: AActor::GetTeamAttitudeTowards answers Neutral
		// for the pack player pawn, which is exactly the bug this check exists for. With no
		// controller yet he simply has nobody to judge (Tick retries ConfigureController).
		if (!AI || AI->GetTeamAttitudeTowards(*Other) != ETeamAttitude::Hostile)
		{
			return;
		}
		if (const ASoldierCharacter* S = Cast<ASoldierCharacter>(Other))
		{
			if (!S->IsAlive() || S->HasSpawnGracePeriod())
			{
				return;
			}
		}
		const float D = FVector::Dist(GetActorLocation(), Other->GetActorLocation());
		if (D > MaxSense)
		{
			return;
		}
		if (D < BestDist)
		{
			BestDist = D;
			Best = Other;
		}
	};

	if (USoldierRegistrySubsystem* Registry = World->GetSubsystem<USoldierRegistrySubsystem>())
	{
		for (const TWeakObjectPtr<ASoldierCharacter>& WeakSoldier : Registry->GetAllSoldiers())
		{
			Consider(WeakSoldier.Get());
		}
		for (const TWeakObjectPtr<APawn>& WeakPawn : Registry->GetBroadPawns())
		{
			Consider(WeakPawn.Get());
		}
	}
	Consider(UGameplayStatics::GetPlayerPawn(World, 0));

	const bool bHasLOS = (Best != nullptr) && AI && AI->HasLineOfSightTo(Best);
	const bool bSpotted = (Best != nullptr) && SquadAIPatrol::ShouldSpotTarget(BestDist, bHasLOS, Tuning);

	if (bSpotted)
	{
		SecondsSinceSpotted = 0.f;
		LastSpottedActor = Best;
	}
	else
	{
		SecondsSinceSpotted = SquadAIPatrol::TickSinceSpotted(SecondsSinceSpotted, DeltaSeconds);
	}

	// Being shot is the loudest possible notice - no range test, no line of sight needed.
	const bool bRecentlyDamaged = (Now - LastDamagedTime) <= FMath::Max(2.f, Tuning.AlertLingerSeconds);

	bool bKeepAlert = false;
	if (bAlerted)
	{
		if (AActor* Target = LastSpottedActor.Get())
		{
			const float D = FVector::Dist(GetActorLocation(), Target->GetActorLocation());
			const bool bVisible = AI && AI->HasLineOfSightTo(Target);
			bKeepAlert = SquadAIPatrol::ShouldKeepAlert(D, bVisible, SecondsSinceSpotted, Tuning);
		}
		else
		{
			// Alerted by a shout or by script, with no hostile of his own yet: hold the alert
			// for the linger window (the model's time limb) instead of standing down on the
			// very next tick - which is what used to happen, making the shout pointless.
			bKeepAlert = SquadAIPatrol::ShouldKeepAlert(
				TNumericLimits<float>::Max(), /*bTargetVisible=*/false, SecondsSinceSpotted, Tuning);
		}
	}

	// The leash: a patrol does not chase across the map. Past the leash he breaks off, walks
	// back to his beat and only then becomes interested in the world again.
	if (bAlerted && PatrolRoute && SquadAIPatrol::BeyondRouteLeash(
		PatrolRoute->DistanceToRoute2D(GetActorLocation()), Tuning))
	{
		ExitAlert(FString::Printf(TEXT("strayed %.0f m from route '%s' - breaking off the chase"),
			PatrolRoute->DistanceToRoute2D(GetActorLocation()) / 100.f, *PatrolRoute->RouteName));
		bReturningToRoute = true;
		return;
	}

	const bool bWantsAlert = bSpotted || bKeepAlert || bRecentlyDamaged;
	if (SquadAIPatrol::IsNewlyAlerted(bAlerted, bWantsAlert))
	{
		EnterAlert(bSpotted
			? FString::Printf(TEXT("saw %s at %.0f m%s"), *GetNameSafe(Best), BestDist / 100.f,
				bHasLOS ? TEXT("") : TEXT(" (heard him through cover)"))
			: FString::Printf(TEXT("took damage from %s"), *GetNameSafe(LastSpottedActor.Get())),
			/*bBroadcast=*/true);
	}
	else if (bAlerted && !bWantsAlert)
	{
		ExitAlert(FString::Printf(TEXT("lost him (%.0f s since last contact)"), SecondsSinceSpotted));
	}
}

void AEnemyPatroller::EnterAlert(const FString& Reason, bool bBroadcast)
{
	if (bAlerted)
	{
		return;
	}

	bAlerted = true;
	bReturningToRoute = false;
	SecondsSinceSpotted = 0.f;
	ApplyWalkSpeed();

	FString Where;
	if (PatrolRoute)
	{
		Where = FString::Printf(TEXT(" (point %d of route '%s')"), CurrentPointIndex + 1, *PatrolRoute->RouteName);
	}
	SquadAISituation::Note(FString::Printf(TEXT("S19-PATROL %s: SPOTTED - %s. Attacking.%s"),
		*GetName(), *Reason, *Where));

	if (bBroadcast)
	{
		AlertNearbyPatrols();
	}
}

void AEnemyPatroller::ExitAlert(const FString& Reason)
{
	if (!bAlerted)
	{
		return;
	}

	bAlerted = false;
	ApplyWalkSpeed();

	SquadAISituation::Note(FString::Printf(TEXT("S19-PATROL %s: standing down - %s. Back to the beat."),
		*GetName(), *Reason));
}

void AEnemyPatroller::AlertNearbyPatrols()
{
	if (!bAlertNearbyPatrols || !GetWorld())
	{
		return;
	}

	USoldierRegistrySubsystem* Registry = GetWorld()->GetSubsystem<USoldierRegistrySubsystem>();
	if (!Registry)
	{
		return;
	}

	const float RadiusSq = FMath::Square(PatrolShoutRadius);
	int32 Warned = 0;
	for (const TWeakObjectPtr<ASoldierCharacter>& WeakSoldier : Registry->GetAllSoldiers())
	{
		AEnemyPatroller* Other = Cast<AEnemyPatroller>(WeakSoldier.Get());
		if (!Other || Other == this || !Other->IsAlive())
		{
			continue;
		}
		if (FVector::DistSquared(GetActorLocation(), Other->GetActorLocation()) > RadiusSq)
		{
			continue;
		}
		Other->ReceivePatrolAlert(GetActorLocation());
		++Warned;
	}

	if (Warned > 0)
	{
		SquadAISituation::Note(FString::Printf(TEXT("S19-PATROL %s: called it out - %d nearby patrol(s) alerted (%.0f m)"),
			*GetName(), Warned, PatrolShoutRadius / 100.f));
	}
}

void AEnemyPatroller::ReceivePatrolAlert(const FVector& FromLocation)
{
	if (bAlerted || !IsAlive())
	{
		return;
	}
	// No broadcast: a shout must not chain across the whole level through relays.
	EnterAlert(FString::Printf(TEXT("a nearby patrol called it out (%.0f m away)"),
		FVector::Dist(GetActorLocation(), FromLocation) / 100.f), /*bBroadcast=*/false);
}

void AEnemyPatroller::ForceAlert(const FString& Reason)
{
	EnterAlert(Reason.IsEmpty() ? TEXT("forced alert") : Reason, /*bBroadcast=*/true);
}

void AEnemyPatroller::ReturnToRoute()
{
	if (bAlerted)
	{
		ExitAlert(TEXT("ordered back to the route"));
	}
	bReturningToRoute = true;
}

void AEnemyPatroller::HandlePatrollerDamaged(float Damage, AActor* DamageCauser, float NewHealth)
{
	LastDamagedTime = GetWorld() ? GetWorld()->GetTimeSeconds() : 0.f;
	SecondsSinceSpotted = 0.f;

	// Shot at: whoever did it is now known. The alert is immediate and loud - this is the one
	// notification a patrol gets without seeing anything.
	if (!bAlerted)
	{
		LastSpottedActor = DamageCauser;
		// NewHealth is part of the delegate signature; printing it also keeps the parameter
		// referenced (MSVC C4100 hygiene) and says something useful in the log.
		EnterAlert(FString::Printf(TEXT("shot for %.0f damage by %s (now %.0f hp)"),
			Damage, *GetNameSafe(DamageCauser), NewHealth),
			/*bBroadcast=*/true);
	}
}

// =========================================================================
//  Presentation
// =========================================================================
void AEnemyPatroller::ApplyWalkSpeed()
{
	if (UCharacterMovementComponent* CMC = GetCharacterMovement())
	{
		const float Want = bAlerted ? AlertWalkSpeed : PatrolWalkSpeed;
		if (Want > 0.f && !FMath::IsNearlyEqual(CMC->MaxWalkSpeed, Want))
		{
			CMC->MaxWalkSpeed = Want;
		}
	}
}

void AEnemyPatroller::DrawPatrolDebug() const
{
	UWorld* World = GetWorld();
	if (!World || !PatrolRoute)
	{
		return;
	}

	const int32 Count = PatrolRoute->GetPointCount();
	for (int32 i = 0; i < Count; ++i)
	{
		const FVector A = PatrolRoute->GetPointLocation(i);
		DrawDebugSphere(World, A + FVector(0.f, 0.f, 40.f), 60.f, 10, FColor::Yellow, false, -1.f, 0, 2.f);

		const bool bHasNext = (i + 1 < Count) || PatrolRoute->IsClosedLoop();
		if (bHasNext)
		{
			const FVector B = PatrolRoute->GetPointLocation((i + 1) % Count);
			DrawDebugLine(World, A + FVector(0.f, 0.f, 40.f), B + FVector(0.f, 0.f, 40.f),
				FColor::Yellow, false, -1.f, 0, 3.f);
		}
	}

	if (!CurrentPatrolPoint.IsNearlyZero())
	{
		DrawDebugLine(World, GetActorLocation() + FVector(0.f, 0.f, 100.f),
			CurrentPatrolPoint + FVector(0.f, 0.f, 40.f),
			bAlerted ? FColor::Red : FColor::Green, false, -1.f, 0, 4.f);
	}
}

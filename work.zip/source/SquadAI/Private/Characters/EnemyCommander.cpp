// EnemyCommander.cpp - S19-ELITE
#include "Characters/EnemyCommander.h"
#include "Characters/EnemyCommanderAssistant.h"
#include "Characters/SoldierCharacter.h"
#include "Components/HealthComponent.h"
#include "Components/WeaponComponent.h"
#include "Quest/EnemyWaveSpawner.h"
#include "AI/SoldierAIController.h"
#include "Performance/SoldierRegistrySubsystem.h"
#include "HUD/QuestNativeHUD.h"
#include "Diagnostics/SquadAISituationLog.h"
#include "Actors/FirstAidKitActor.h"
#include "Actors/AmmoCrateActor.h"
#include "Engine/World.h"
#include "EngineUtils.h"                 // TActorIterator (spawner auto-find)
#include "Kismet/GameplayStatics.h"

AEnemyCommander::AEnemyCommander()
{
	Faction = ESquadFaction::Enemy;
	bCanBeDowned = false;                // the boss dies when he dies - no downed/revive loop
	CharacterDisplayName = FText::FromString(TEXT("فرمانده بخش"));

	// The aura refresh is the only thing that needs to be live, and it is a distance test
	// over ~30 soldiers twice a second. 0.1 s is plenty and stays off the frame budget.
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 0.1f;
}

void AEnemyCommander::BeginPlay()
{
	Super::BeginPlay();

	// Rule set first: the Details-panel values win over the model defaults, and everything
	// below (aura, calls, last stand) reads the rule set, never the raw properties.
	Tuning.HealthMultiplier = HealthMultiplier;
	Tuning.AccuracyMultiplier = AccuracyMultiplierOverride;
	Tuning.DamageMultiplier = DamageMultiplierOverride;
	Tuning.MaxSingleHitFraction = MaxSingleHitFraction;
	Tuning.AuraRadius = AuraRadius;
	Tuning.AuraResist = AuraResist;
	Tuning.AuraRelayResistBonus = AuraRelayResistBonus;
	Tuning.AuraAggressionBonus = AuraAggressionBonus;
	Tuning.AuraPersistAfterDeathSeconds = AuraPersistAfterDeathSeconds;
	Tuning.AuraRadiusLastStandScale = AuraRadiusLastStandScale;
	Tuning.MaxReinforcementCalls = MaxReinforcementCalls;
	Tuning.ReinforcementsPerCall = ReinforcementsPerCall;
	Tuning.ReinforcementCooldownSeconds = ReinforcementCooldownSeconds;
	Tuning.ReinforcementGroupThreshold = ReinforcementGroupThreshold;
	Tuning.ReinforcementDelayAfterContactSeconds = ReinforcementDelayAfterContactSeconds;
	Tuning.LastStandHealthFraction = LastStandHealthFraction;
	Tuning.LastStandResistBonus = LastStandResistBonus;
	Tuning.LastStandSeconds = LastStandSeconds;

	// Super (AEnemySoldier) applied the tier tuning; the elite stats go on top of it. The
	// order matters: the multiplier applies to whatever max health the tier gave us.
	if (HealthComp)
	{
		HealthComp->MaxHealth = SquadAIEliteSquad::EliteMaxHealth(HealthComp->MaxHealth, HealthMultiplier);
		HealthComp->CurrentHealth = HealthComp->MaxHealth;
		HealthComp->MaxSingleHitFraction = MaxSingleHitFraction;

		if (!bBindingsDone)
		{
			HealthComp->OnDeath.AddDynamic(this, &AEnemyCommander::HandleOwnerDeath);
			HealthComp->OnDamaged.AddDynamic(this, &AEnemyCommander::HandleDamaged);
			bBindingsDone = true;
		}
	}

	AccuracyMultiplier = AccuracyMultiplierOverride;
	if (WeaponComp)
	{
		WeaponComp->AccuracyMultiplier = AccuracyMultiplierOverride;
		WeaponComp->DamageMultiplier = DamageMultiplierOverride;
	}
	Aggression = Tuning.Aggression;
	SuppressionThreshold = Tuning.SuppressionThreshold;

	// A spawner to call for help: the closest one. A commander placed in a level beside his
	// own spawner should call that one, not the far side of the map.
	if (!BoundSpawner && GetWorld())
	{
		float BestDist = TNumericLimits<float>::Max();
		for (TActorIterator<AEnemyWaveSpawner> It(GetWorld()); It; ++It)
		{
			const float D = FVector::Dist(GetActorLocation(), It->GetActorLocation());
			if (D < BestDist)
			{
				BestDist = D;
				BoundSpawner = *It;
			}
		}
	}

	SquadAISituation::Note(FString::Printf(
		TEXT("ELITE commander %s spawned: hp %.0f/%.0f (x%.1f), aura %.0f m (resist %.0f%% + %.0f%% relay), single hits capped at %.0f%% of max, spawner %s"),
		*GetName(), HealthComp ? HealthComp->CurrentHealth : -1.f, HealthComp ? HealthComp->MaxHealth : -1.f,
		HealthMultiplier, AuraRadius / 100.f, AuraResist * 100.f, AuraRelayResistBonus * 100.f,
		MaxSingleHitFraction * 100.f, *GetNameSafe(BoundSpawner)));

	if (bAnnounceSpawnAndDeath)
	{
		if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this))
		{
			HUD->ShowAlertBanner(
				AQuestNativeHUD::LocalizeHUDText(this, TEXT("HUD"), TEXT("CommanderOnField"),
					TEXT("فرمانده در میدان است — او را از پای درآورید"),
					TEXT("COMMANDER ON THE FIELD")),
				FLinearColor(0.95f, 0.35f, 0.12f), 5.f);
		}
	}
}

void AEnemyCommander::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	// Never leave a buff running on a dead level.
	ReleaseAura();
	Super::EndPlay(EndPlayReason);
}

void AEnemyCommander::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}

	if (bDead)
	{
		// The relay: his assistants hold the command net together for a few more seconds.
		SecondsSinceDeath += DeltaSeconds;
		const bool bStillActive = SquadAIEliteSquad::IsAuraActive(
			false, SecondsSinceDeath, HasAliveAssistant(), Tuning);

		if (!bStillActive)
		{
			ReleaseAura();
		}
		else if (bAuraApplied)
		{
			// Keep the relay's numbers fresh (an assistant may have just moved in or died).
			RefreshAura();
		}
		return;
	}

	BeginCombatIfNeeded();

	// ---- the aura ----
	AuraActiveSeconds += DeltaSeconds;
	if (!bAuraApplied || AuraActiveSeconds >= FMath::Max(0.1f, Tuning.AuraRefreshSeconds))
	{
		AuraActiveSeconds = 0.f;
		RefreshAura();
	}

	// ---- last stand ----
	if (HealthComp)
	{
		const float Frac = HealthComp->GetHealthPercent();
		if (SquadAIEliteSquad::ShouldBeginLastStand(Tuning, Frac, bLastStandActive))
		{
			EnterLastStand();
		}
	}
	if (bLastStandActive && LastStandEndTime > 0.f && World->GetTimeSeconds() >= LastStandEndTime)
	{
		bLastStandActive = false;
		LastStandEndTime = -1.f;
		SquadAISituation::Note(FString::Printf(TEXT("ELITE %s: last stand over, back to normal armour"), *GetName()));
	}

	// ---- reinforcements ----
	{
		const bool bInCombat = (CombatStartedTime >= 0.f);
		const float SecondsSinceCombat = bInCombat ? (World->GetTimeSeconds() - CombatStartedTime) : 0.f;
		const float SecondsSinceCall = World->GetTimeSeconds() - LastReinforcementTime;
		const int32 AliveCommandSize = 1 + GetAliveAssistantCount();

		const EEliteReinforcementReason Reason = SquadAIEliteSquad::EvaluateReinforcements(
			Tuning, bInCombat, SecondsSinceCombat, AliveCommandSize,
			ReinforcementCallsUsed, SecondsSinceCall, bLastStandActive);

		if (Reason != EEliteReinforcementReason::None)
		{
			const int32 Spawned = CallReinforcements();
			SquadAISituation::Note(FString::Printf(
				TEXT("ELITE %s: reinforcement call %d/%d (%s) - asked for %d, %d came (combat %.1fs, command size %d)"),
				*GetName(), ReinforcementCallsUsed, MaxReinforcementCalls,
				Reason == EEliteReinforcementReason::LastStand ? TEXT("last stand") :
				(Reason == EEliteReinforcementReason::GroupThinned ? TEXT("command thinned") : TEXT("first contact")),
				ReinforcementsPerCall, Spawned, SecondsSinceCombat, AliveCommandSize));
		}
	}
}

void AEnemyCommander::BeginCombatIfNeeded()
{
	if (bCombatSeen || !GetWorld())
	{
		return;
	}
	// "In combat" = the player is close enough to be a threat. Being shot at also counts
	// (HandleDamaged sets the same flag), so a long-range duel still escalates.
	if (APawn* Player = UGameplayStatics::GetPlayerPawn(GetWorld(), 0))
	{
		const float Dist = FVector::Dist(GetActorLocation(), Player->GetActorLocation());
		if (Dist <= FMath::Max(AuraRadius * 2.5f, 4500.f))
		{
			bCombatSeen = true;
			CombatStartedTime = GetWorld()->GetTimeSeconds();
			SquadAISituation::Note(FString::Printf(TEXT("ELITE %s: combat started (player %.0f m away) - reinforcement delay begins"),
				*GetName(), Dist / 100.f));
		}
	}
}

// =========================================================================
//  Aura
// =========================================================================
void AEnemyCommander::RefreshAura()
{
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}

	if (!SquadAIEliteSquad::IsAuraActive(!bDead, SecondsSinceDeath, HasAliveAssistant(), Tuning))
	{
		ReleaseAura();
		return;
	}

	const float Radius = GetCurrentAuraRadius();
	const float Resist = GetAuraResist();
	const float Now = World->GetTimeSeconds();

	// Everyone with a health component inside the net. These are native soldiers: the aura
	// works on ASoldierCharacter, i.e. the enemies SquadAI itself runs - which includes
	// every enemy spawned from the native classes and any Blueprint built on them. Pack
	// pawns (a Blueprint state tree of their own, not ASoldierCharacter) cannot be buffed
	// this way, which is why the death shock below uses a path they DO share.
	if (USoldierRegistrySubsystem* Registry = World->GetSubsystem<USoldierRegistrySubsystem>())
	{
		for (const TWeakObjectPtr<ASoldierCharacter>& Weak : Registry->GetAllSoldiers())
		{
			ASoldierCharacter* S = Weak.Get();
			if (!S || S == this || !S->IsEnemy() || !S->IsAlive() || !S->HealthComp)
			{
				continue;
			}
			if (FVector::Dist(GetActorLocation(), S->GetActorLocation()) > Radius)
			{
				continue;
			}

			// Bookkeeping entry; its base aggression is captured once, the first time the
			// net touches him, so releasing the aura restores what he started with.
			FAuraTarget* Entry = AuraTargets.FindByPredicate(
				[S](const FAuraTarget& T) { return T.Soldier.Get() == S; });
			if (!Entry)
			{
				FAuraTarget NewEntry;
				NewEntry.Soldier = S;
				const AEnemySoldier* AsEnemy = Cast<AEnemySoldier>(S);
				NewEntry.BaseAggression = AsEnemy ? AsEnemy->Aggression : 0.4f;
				AuraTargets.Add(NewEntry);
				Entry = &AuraTargets.Last();
			}

			Entry->LastTouched = Now;

			// The aura is the single writer of resistance and aggression for everyone in
			// the net, and it composes the assistants' morale flags in. (The assistant
			// only writes those numbers itself when there is no aura left to compose
			// them - see TickMorale. Two writers would fight at 10 Hz.)
			const AEnemyCommanderAssistant* AsAssistant = Cast<AEnemyCommanderAssistant>(S);
			const bool bEnraged = AsAssistant && AsAssistant->IsEnraged();
			const bool bBroken = AsAssistant && !bEnraged && AsAssistant->IsMoraleBroken();

			float TargetResist = Resist + (bEnraged ? Tuning.EnrageResistBonus : 0.f);
			TargetResist = FMath::Clamp(TargetResist, 0.f, Tuning.AuraMaxResist);
			S->HealthComp->IncomingDamageMultiplier = FMath::Clamp(1.f - TargetResist, 0.05f, 1.f);

			if (AEnemySoldier* Enemy = Cast<AEnemySoldier>(S))
			{
				float TargetAggression = Entry->BaseAggression + Tuning.AuraAggressionBonus;
				if (bEnraged)
				{
					TargetAggression = FMath::Max(TargetAggression, Tuning.EnrageAggression);
				}
				else if (bBroken)
				{
					TargetAggression = FMath::Min(TargetAggression, Tuning.MoraleBreakAggression);
				}
				Enemy->Aggression = FMath::Clamp(TargetAggression, 0.f, 1.f);
			}
		}
	}

	// Anything buffed that has left the net, died, or not been refreshed gets its numbers
	// back. (2.5 refresh periods of slack: the aura tick is 0.1 s, the aura period 0.5 s.)
	for (int32 i = AuraTargets.Num() - 1; i >= 0; --i)
	{
		ASoldierCharacter* S = AuraTargets[i].Soldier.Get();
		const bool bInsideNow = S && S->IsAlive()
			&& FVector::Dist(GetActorLocation(), S->GetActorLocation()) <= Radius
			&& (Now - AuraTargets[i].LastTouched) <= FMath::Max(0.5f, Tuning.AuraRefreshSeconds) * 2.5f;
		if (!bInsideNow)
		{
			if (S && S->HealthComp)
			{
				S->HealthComp->IncomingDamageMultiplier = 1.f;
			}
			if (AEnemySoldier* Enemy = Cast<AEnemySoldier>(S))
			{
				Enemy->Aggression = AuraTargets[i].BaseAggression;
			}
			AuraTargets.RemoveAt(i);
		}
	}

	bAuraApplied = true;
}

void AEnemyCommander::ReleaseAura()
{
	if (!bAuraApplied && AuraTargets.Num() == 0)
	{
		return;
	}
	for (FAuraTarget& Entry : AuraTargets)
	{
		if (ASoldierCharacter* S = Entry.Soldier.Get())
		{
			if (S->HealthComp)
			{
				S->HealthComp->IncomingDamageMultiplier = 1.f;
			}
			if (AEnemySoldier* Enemy = Cast<AEnemySoldier>(S))
			{
				Enemy->Aggression = Entry.BaseAggression;
			}
		}
	}
	AuraTargets.Reset();
	bAuraApplied = false;
}

float AEnemyCommander::GetCurrentAuraRadius() const
{
	// The property, not the cached rule set: a designer can retune the radius from the
	// Details panel during PIE and the ring should follow immediately.
	const float Scale = bLastStandActive ? FMath::Max(1.f, AuraRadiusLastStandScale) : 1.f;
	return FMath::Max(0.f, AuraRadius * Scale);
}

bool AEnemyCommander::IsAuraActive() const
{
	return SquadAIEliteSquad::IsAuraActive(!bDead, SecondsSinceDeath, HasAliveAssistant(), Tuning);
}

float AEnemyCommander::GetAuraResist() const
{
	return SquadAIEliteSquad::AuraResist(Tuning, HasAliveAssistant());
}

FEliteSquadTuning AEnemyCommander::GetEliteTuning() const
{
	return Tuning;
}

bool AEnemyCommander::IsInsideAura(const AActor* Other) const
{
	if (!Other || !IsAuraActive())
	{
		return false;
	}
	return FVector::Dist(GetActorLocation(), Other->GetActorLocation()) <= GetCurrentAuraRadius();
}

// =========================================================================
//  Helpers / API
// =========================================================================
void AEnemyCommander::RegisterAssistant(AEnemyCommanderAssistant* Assistant)
{
	if (!Assistant)
	{
		return;
	}
	for (const TWeakObjectPtr<AEnemyCommanderAssistant>& Existing : Assistants)
	{
		if (Existing.Get() == Assistant)
		{
			return;
		}
	}
	Assistants.Add(Assistant);
	SquadAISituation::Note(FString::Printf(TEXT("ELITE %s: assistant %s joined the command (%d assistant(s) registered)"),
		*GetName(), *Assistant->GetName(), Assistants.Num()));
}

int32 AEnemyCommander::GetAliveAssistantCount() const
{
	int32 Count = 0;
	for (const TWeakObjectPtr<AEnemyCommanderAssistant>& Weak : Assistants)
	{
		const AEnemyCommanderAssistant* A = Weak.Get();
		if (A && A->IsAlive())
		{
			++Count;
		}
	}
	return Count;
}

bool AEnemyCommander::HasAliveAssistant() const
{
	return GetAliveAssistantCount() > 0;
}

void AEnemyCommander::FindBoundSpawner(UWorld* World)
{
	if (BoundSpawner || !World)
	{
		return;
	}
	float BestDist = TNumericLimits<float>::Max();
	for (TActorIterator<AEnemyWaveSpawner> It(World); It; ++It)
	{
		const float D = FVector::Dist(GetActorLocation(), It->GetActorLocation());
		if (D < BestDist)
		{
			BestDist = D;
			BoundSpawner = *It;
		}
	}
}

int32 AEnemyCommander::CallReinforcements()
{
	if (ReinforcementCallsUsed >= MaxReinforcementCalls)
	{
		return 0;
	}

	UWorld* World = GetWorld();
	if (!World)
	{
		return 0;
	}

	// A spawner may have been placed after BeginPlay, or the bound one destroyed: look
	// again before giving up, then report honestly if there is still nothing to call.
	FindBoundSpawner(World);

	if (!BoundSpawner)
	{
		SquadAISituation::Note(FString::Printf(
			TEXT("ELITE %s: wanted to call reinforcements but no spawner is bound and none is in the level"), *GetName()));
		return 0;
	}

	const int32 Spawned = BoundSpawner->SpawnReinforcementSquad(ReinforcementsPerCall, GetActorLocation());
	++ReinforcementCallsUsed;
	LastReinforcementTime = World->GetTimeSeconds();

	if (Spawned > 0)
	{
		if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this))
		{
			HUD->ShowAlertBanner(
				AQuestNativeHUD::LocalizeHUDText(this, TEXT("HUD"), TEXT("ReinforcementsInbound"),
					TEXT("نیروی کمکی می‌رسد!"),
					TEXT("REINFORCEMENTS INBOUND!")),
				FLinearColor(0.95f, 0.20f, 0.14f), 4.f);
		}
	}
	return Spawned;
}

void AEnemyCommander::NoteHealChannel(AEnemyCommanderAssistant* Assistant, bool bActive)
{
	HealingAssistant = bActive ? TWeakObjectPtr<AEnemyCommanderAssistant>(Assistant) : nullptr;
}

AEnemyCommanderAssistant* AEnemyCommander::GetHealingAssistant() const
{
	return HealingAssistant.Get();
}

// =========================================================================
//  Last stand
// =========================================================================
void AEnemyCommander::EnterLastStand()
{
	bLastStandActive = true;
	LastStandEndTime = GetWorld() ? (GetWorld()->GetTimeSeconds() + LastStandSeconds) : -1.f;

	// Wounded and cornered: the net widens, he gets more armour of his own, and his escorts
	// lose their heads. The HUD bar flashes while this is on.
	RefreshAura();

	for (const TWeakObjectPtr<AEnemyCommanderAssistant>& Weak : Assistants)
	{
		if (AEnemyCommanderAssistant* A = Weak.Get())
		{
			A->BeginEnrage(LastStandSeconds);
		}
	}

	SquadAISituation::Note(FString::Printf(
		TEXT("ELITE %s: LAST STAND at %.0f%% health - aura widened to %.0f m, +%.0f%% resist, assistants enraged, %.0fs"),
		*GetName(), HealthComp ? HealthComp->GetHealthPercent() * 100.f : -1.f,
		GetCurrentAuraRadius() / 100.f, LastStandResistBonus * 100.f, LastStandSeconds));

	if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this))
	{
		HUD->ShowAlertBanner(
			AQuestNativeHUD::LocalizeHUDText(this, TEXT("HUD"), TEXT("CommanderLastStand"),
				TEXT("فرمانده در تنگناست — او را تمام کنید!"),
				TEXT("COMMANDER CORNERED!")),
			FLinearColor(1.f, 0.15f, 0.10f), 4.f);
	}
}

// =========================================================================
//  Damage / death
// =========================================================================
void AEnemyCommander::HandleDamaged(float Damage, AActor* DamageCauser, float NewHealth)
{
	// Being shot at counts as combat even if the player is not close yet (a long duel).
	if (!bCombatSeen && GetWorld())
	{
		bCombatSeen = true;
		CombatStartedTime = GetWorld()->GetTimeSeconds();
		SquadAISituation::Note(FString::Printf(TEXT("ELITE %s: combat started (took %.1f damage from %s)"),
			*GetName(), Damage, *GetNameSafe(DamageCauser)));
	}
}

void AEnemyCommander::HandleOwnerDeath(AActor* OwnerActor)
{
	if (bDead)
	{
		return;
	}
	bDead = true;
	SecondsSinceDeath = 0.f;

	SquadAISituation::Note(FString::Printf(
		TEXT("ELITE %s: COMMANDER DOWN - %d assistant(s) left, aura %s (relay %.1fs)"),
		*GetName(), GetAliveAssistantCount(),
		HasAliveAssistant() ? TEXT("held by the relay") : TEXT("ending now"),
		Tuning.AuraPersistAfterDeathSeconds));

	// ---- morale shock ----------------------------------------------------
	// Every enemy soldier inside the shock radius loses their nerve. This walks the
	// registry directly instead of ApplySuppressionAlongPath: that helper suppresses
	// EVERYONE near its path - including allies and the player's tunnel vision - which is
	// the opposite of what a commander's death should do.
	if (UWorld* World = GetWorld())
	{
		if (const USoldierRegistrySubsystem* Registry = World->GetSubsystem<USoldierRegistrySubsystem>())
		{
			int32 Shocked = 0;
			for (const TWeakObjectPtr<ASoldierCharacter>& Weak : Registry->GetAllSoldiers())
			{
				ASoldierCharacter* S = Weak.Get();
				if (!S || S == this || !S->IsEnemy() || !S->IsAlive())
				{
					continue;
				}
				if (FVector::Dist(GetActorLocation(), S->GetActorLocation()) > DeathShockRadius)
				{
					continue;
				}
				if (ASoldierAIController* AI = Cast<ASoldierAIController>(S->GetController()))
				{
					AI->AddSuppression(DeathSuppressionShock);
					++Shocked;
				}
			}
			SquadAISituation::Note(FString::Printf(TEXT("ELITE %s: morale shock hit %d enemy soldier(s) within %.0f m"),
				*GetName(), Shocked, DeathShockRadius / 100.f));
		}
	}

	// ---- his assistants: berserk first, broken afterwards ----
	for (const TWeakObjectPtr<AEnemyCommanderAssistant>& Weak : Assistants)
	{
		if (AEnemyCommanderAssistant* A = Weak.Get())
		{
			A->OnCommanderDied();
		}
	}

	// ---- drop ----
	if (UWorld* World = GetWorld())
	{
		FActorSpawnParameters SpawnParams;
		SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
		const FVector DropLoc = GetActorLocation() + FVector(0.f, 0.f, 30.f);
		if (DropFirstAidClass)
		{
			World->SpawnActor<AFirstAidKitActor>(DropFirstAidClass, DropLoc, FRotator::ZeroRotator, SpawnParams);
		}
		if (DropAmmoClass)
		{
			World->SpawnActor<AAmmoCrateActor>(DropAmmoClass, DropLoc + FVector(120.f, 0.f, 0.f), FRotator::ZeroRotator, SpawnParams);
		}
	}

	if (bAnnounceSpawnAndDeath)
	{
		if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this))
		{
			HUD->ShowAlertBanner(
				AQuestNativeHUD::LocalizeHUDText(this, TEXT("HUD"), TEXT("CommanderKilled"),
					TEXT("فرمانده از پای درآمد — دشمنان روحیه‌شان را باختند"),
					TEXT("COMMANDER ELIMINATED - ENEMY MORALE BROKEN")),
				FLinearColor(0.30f, 0.85f, 0.35f), 5.f);
		}
	}
}

// ==== S19-LOGGER ====
// SquadAISituationLog.cpp — implementation of the one-line-per-change situation logger.
// See SquadAISituationLog.h for what it is for and how to drive it.
#include "Diagnostics/SquadAISituationLog.h"

#include "Characters/SoldierCharacter.h"
#include "Characters/LeaderCharacter.h"
#include "AI/SoldierAIController.h"
#include "Performance/SoldierRegistrySubsystem.h"
#include "Components/HealthComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/SkeletalMesh.h"          // S19-GRIPHUNT: read grip sockets off the asset
#include "Engine/SkeletalMeshSocket.h"    // S19-GRIPHUNT
#include "Animation/Skeleton.h"           // S19-GRIPHUNT: skeleton-level sockets
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/Pawn.h"
#include "GenericTeamAgentInterface.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "UObject/UnrealType.h"
#include "HAL/IConsoleManager.h"

DEFINE_LOG_CATEGORY(LogSquadAISituation);

// ---------------------------------------------------------------------------
//  Tunables
// ---------------------------------------------------------------------------
static TAutoConsoleVariable<int32> CVarSituationLog(
	TEXT("SquadAI.SituationLog"),
	1,
	TEXT("1 = write the situation log (one line per tracked pawn per state CHANGE, "
		 "plus event lines). 0 = off. See SquadAISituationLog.h."),
	ECVF_Cheat);

static TAutoConsoleVariable<float> CVarSituationPeriod(
	TEXT("SquadAI.SituationLog.Period"),
	1.0f,
	TEXT("Seconds between situation snapshots (clamped to 0.1 .. 30)."),
	ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarSituationForce(
	TEXT("SquadAI.SituationLog.Force"),
	0,
	TEXT("1 = write a snapshot every period, not only when the state changed. "
		 "Use this to prove the pawns are alive and idle; leave it off for readable logs."),
	ECVF_Cheat);

static TAutoConsoleVariable<float> CVarSituationHeartbeat(
	TEXT("SquadAI.SituationLog.Heartbeat"),
	30.0f,
	TEXT("Seconds of 'nothing changed' after which one heartbeat line is written "
		 "(0 = never). Proves the logger is running."),
	ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarSituationMaxLines(
	TEXT("SquadAI.SituationLog.MaxLines"),
	5000,
	TEXT("Hard cap on situation lines for one run; protects against a runaway "
		 "state change flooding the log. 0 = unlimited."),
	ECVF_Cheat);

// ---------------------------------------------------------------------------
//  Logging state (one instance, shared by every host that calls Tick)
// ---------------------------------------------------------------------------
namespace SquadAISituationLog_Private
{
	TWeakObjectPtr<UWorld> CachedWorld;

	float LastSnapshotTime    = -1000.f;
	float LastChangeTime      = -1000.f;
	int32 LinesWritten        = 0;
	bool  bCapReported        = false;
	bool  bNextSnapshotForced = false;

	TArray<FString> LastSnapshot;
	TArray<FString> OnceKeys;

	// S19-HPDROP: pack-side damage (explosive, falling, collision) is applied INSIDE the
	// pack, so SquadAI never sees it - the health bar just drops and the log says nothing.
	// That is exactly how a 38 m respawn fall read as "weird health". Compare each tracked
	// pawn against the previous snapshot and report a drop that no SquadAI damage event
	// explains.
	struct FTrackedHealth
	{
		FString Name;
		double  Health = -1.0;
	};
	TArray<FTrackedHealth> LastTrackedHealth;
	int32 PackDamageEventsSinceSnapshot = 0;

	bool PassesGate()
	{
		if (CVarSituationLog.GetValueOnGameThread() == 0) return false;

		const int32 Cap = CVarSituationMaxLines.GetValueOnGameThread();
		if (Cap > 0 && LinesWritten >= Cap)
		{
			if (!bCapReported)
			{
				bCapReported = true;
				UE_LOG(LogSquadAISituation, Log,
					TEXT("[SAI] line cap reached (%d) - situation logging stops for this run. "
						 "Raise SquadAI.SituationLog.MaxLines to keep going."),
					Cap);
			}
			return false;
		}
		return true;
	}

	void Write(const TCHAR* Prefix, const FString& Msg)
	{
		if (CachedWorld.IsValid())
		{
			++LinesWritten;
			UE_LOG(LogSquadAISituation, Log, TEXT("[%s] t=%.2f %s"),
				Prefix, CachedWorld->GetTimeSeconds(), *Msg);
		}
		else
		{
			++LinesWritten;
			UE_LOG(LogSquadAISituation, Log, TEXT("[%s] %s"), Prefix, *Msg);
		}
	}

	// ---- reflection helpers (self-contained: this file compiles on its own) ----

	FProperty* FindPropByName(UObject* Obj, const TCHAR* Name)
	{
		return (Obj && Obj->GetClass()) ? FindFProperty<FProperty>(Obj->GetClass(), FName(Name)) : nullptr;
	}

	/** The pack spells these differently between versions, so try the usual suspects. */
	FProperty* FindPropAny(UObject* Obj, std::initializer_list<const TCHAR*> Names)
	{
		for (const TCHAR* N : Names)
		{
			if (FProperty* P = FindPropByName(Obj, N))
			{
				return P;
			}
		}
		return nullptr;
	}

	bool ReadNumber(UObject* Obj, std::initializer_list<const TCHAR*> Names, double& OutValue)
	{
		if (!Obj) return false;
		FProperty* P = FindPropAny(Obj, Names);
		if (!P) return false;
		if (const FDoubleProperty* D = CastField<FDoubleProperty>(P)) { OutValue = D->GetPropertyValue_InContainer(Obj); return true; }
		if (const FFloatProperty* F = CastField<FFloatProperty>(P))   { OutValue = F->GetPropertyValue_InContainer(Obj); return true; }
		if (const FIntProperty* I = CastField<FIntProperty>(P))       { OutValue = I->GetPropertyValue_InContainer(Obj); return true; }
		return false;
	}

	bool ReadFlag(UObject* Obj, std::initializer_list<const TCHAR*> Names, bool& OutValue)
	{
		if (!Obj || !Obj->GetClass()) return false;
		for (const TCHAR* N : Names)
		{
			if (const FBoolProperty* B = FindFProperty<FBoolProperty>(Obj->GetClass(), FName(N)))
			{
				OutValue = B->GetPropertyValue_InContainer(Obj);
				return true;
			}
		}
		return false;
	}

	bool IsDeadFlagged(UObject* Obj)
	{
		bool bFlag = false;
		if (!ReadFlag(Obj, { TEXT("bIsDead?"), TEXT("bIsDead"), TEXT("bDead?"), TEXT("bDead"), TEXT("IsDead"), TEXT("isDead?") }, bFlag))
		{
			return false;
		}
		return bFlag;
	}

	bool IsHealthComponentName(const FString& CompName, const FString& ClassName)
	{
		return CompName.Contains(TEXT("BPC_Health")) || ClassName.Contains(TEXT("Health"));
	}

	FString PropValueToString(FProperty* P, const void* Container)
	{
		if (!P || !Container) return FString();
		if (const FDoubleProperty* D = CastField<FDoubleProperty>(P)) return FString::Printf(TEXT("%.4f"), D->GetPropertyValue_InContainer(Container));
		if (const FFloatProperty* F = CastField<FFloatProperty>(P))   return FString::Printf(TEXT("%.4f"), F->GetPropertyValue_InContainer(Container));
		if (const FIntProperty* I = CastField<FIntProperty>(P))       return FString::Printf(TEXT("%d"), I->GetPropertyValue_InContainer(Container));
		if (const FInt64Property* I64 = CastField<FInt64Property>(P)) return FString::Printf(TEXT("%lld"), I64->GetPropertyValue_InContainer(Container));
		if (const FBoolProperty* B = CastField<FBoolProperty>(P))     return B->GetPropertyValue_InContainer(Container) ? TEXT("1") : TEXT("0");
		if (const FStrProperty* S = CastField<FStrProperty>(P))       return S->GetPropertyValue_InContainer(Container);
		if (const FNameProperty* N = CastField<FNameProperty>(P))     return N->GetPropertyValue_InContainer(Container).ToString();
		if (const FObjectPropertyBase* O = CastField<FObjectPropertyBase>(P))
		{
			return GetNameSafe(O->GetObjectPropertyValue_InContainer(Container));
		}
		if (const FEnumProperty* E = CastField<FEnumProperty>(P))
		{
			const FNumericProperty* Under = E->GetUnderlyingProperty();
			return Under ? FString::Printf(TEXT("%lld"), Under->GetSignedIntPropertyValue(Container)) : FString();
		}
		return FString(); // structs/arrays are not worth printing here
	}

	/** Properties whose name hints at something we debug. Keeps the dump short. */
	bool IsInterestingPropName(const FString& Name)
	{
		static const TCHAR* Tokens[] = {
			TEXT("health"), TEXT("dead"), TEXT("death"), TEXT("damage"), TEXT("armor"), TEXT("armour"),
			TEXT("invuln"), TEXT("ragdoll"), TEXT("simulate"), TEXT("gravity"), TEXT("pause"),
			TEXT("blend"), TEXT("anim"), TEXT("scale"), TEXT("visib"), TEXT("hidden"), TEXT("downed"),
			TEXT("stamina"), TEXT("bleed"), TEXT("suppress"), TEXT("revive")
		};
		for (const TCHAR* Token : Tokens)
		{
			if (Name.Contains(Token)) return true;
		}
		return false;
	}

	/** "ABP" / "SingleNode" / "Custom". Compares the enum instead of naming its type:
	 *  EAnimationMode is a namespaced enum on some engine versions and an enum class on
	 *  others, and this file must compile on both without a version check. */
	FString AnimModeToString(USkeletalMeshComponent* Mesh)
	{
		if (!Mesh) return TEXT("?");
		const auto Mode = Mesh->GetAnimationMode();
		if (Mode == EAnimationMode::AnimationBlueprint)  return TEXT("ABP");
		if (Mode == EAnimationMode::AnimationSingleNode) return TEXT("SingleNode");
		if (Mode == EAnimationMode::AnimationCustomMode) return TEXT("Custom");
		return TEXT("?");
	}
}

using namespace SquadAISituationLog_Private;

// ---------------------------------------------------------------------------
//  State readers
// ---------------------------------------------------------------------------
FString SquadAISituation::DescribeHealth(AActor* Actor)
{
	if (!Actor) return TEXT("health=<none>");

	FString Result;

	// Native HealthComponent (our soldiers, and any pawn that has one)
	if (const UHealthComponent* HC = Actor->FindComponentByClass<UHealthComponent>())
	{
		Result += FString::Printf(TEXT("HC %s %.1f/%.1f%s%s"),
			*HC->GetName(),
			HC->CurrentHealth,
			HC->MaxHealth,
			HC->IsAlive() ? TEXT("") : TEXT(" DEAD"),
			HC->bInvincible ? TEXT(" invuln") : TEXT(""));
	}

	// Pack health components (BP_PlayerCharacter, BP_Enemy_*, BP_Leader_* ...)
	TArray<FString> Bits;
	TArray<UActorComponent*> Comps;
	Actor->GetComponents(Comps);
	for (UActorComponent* C : Comps)
	{
		if (!C || !C->GetClass()) continue;
		const FString CompName = C->GetName();
		const FString ClassName = C->GetClass()->GetName();
		if (!IsHealthComponentName(CompName, ClassName)) continue;

		double Cur = 0.0, Max = 0.0;
		const bool bHasCur = ReadNumber(C, { TEXT("currentHealth"), TEXT("CurrentHealth"), TEXT("Current Health"),
			TEXT("Health"), TEXT("HP"), TEXT("currentHP"), TEXT("CurrentHP") }, Cur);
		const bool bHasMax = ReadNumber(C, { TEXT("maxHealth"), TEXT("MaxHealth"), TEXT("Max Health"),
			TEXT("MaxHP"), TEXT("maxHP") }, Max);
		if (!bHasCur && !bHasMax) continue;

		FString Piece;
		if (bHasCur && bHasMax)
		{
			Piece = FString::Printf(TEXT("%s %.1f/%.1f"), *CompName, Cur, Max);
			if (Max > 0.0)
			{
				Piece += FString::Printf(TEXT("(%.0f%%)"), (Cur / Max) * 100.0);
			}
			// Above max health = every hit is invisible. This is the "the first enemy
			// shot does nothing" fingerprint: flag it in the line itself.
			if (Cur > Max + 1.e-4)
			{
				Piece += TEXT(" OVERMAX!");
			}
		}
		else
		{
			const FString CurStr = bHasCur ? FString::Printf(TEXT("%.1f"), Cur) : FString(TEXT("n/a"));
			const FString MaxStr = bHasMax ? FString::Printf(TEXT("%.1f"), Max) : FString(TEXT("n/a"));
			Piece = FString::Printf(TEXT("%s cur=%s max=%s"), *CompName, *CurStr, *MaxStr);
		}

		if (IsDeadFlagged(C))
		{
			Piece += TEXT(" deadFlag=1");
		}
		Bits.Add(Piece);
	}

	if (Bits.Num() > 0)
	{
		if (!Result.IsEmpty()) Result += TEXT(" | ");
		Result += FString::Join(Bits, TEXT("; "));
	}

	if (Result.IsEmpty())
	{
		bool bActorDead = false;
		Result = ReadFlag(Actor, { TEXT("bIsDead?"), TEXT("bIsDead"), TEXT("bDead"), TEXT("IsDead") }, bActorDead)
			? FString::Printf(TEXT("actorDeadFlag=%d (no health component)"), bActorDead ? 1 : 0)
			: TEXT("no health component");
	}
	return Result;
}

namespace SquadAISituationLog_Private
{
	/** The first pack health component's current value, as a number (for the drop detector). */
	bool ReadFirstPackHealth(AActor* Actor, double& OutCurrent, FString& OutCompName)
	{
		if (!Actor) return false;
		TArray<UActorComponent*> Comps;
		Actor->GetComponents(Comps);
		for (UActorComponent* C : Comps)
		{
			if (!C || !C->GetClass()) continue;
			if (!IsHealthComponentName(C->GetName(), C->GetClass()->GetName())) continue;
			if (!ReadNumber(C, { TEXT("currentHealth"), TEXT("CurrentHealth"), TEXT("Current Health"),
				TEXT("Health"), TEXT("HP"), TEXT("currentHP"), TEXT("CurrentHP") }, OutCurrent))
			{
				continue;
			}
			OutCompName = C->GetName();
			return true;
		}
		return false;
	}
}

FString SquadAISituation::DescribePose(AActor* Actor)
{
	if (!Actor) return TEXT("pose=<none>");

	TArray<USkeletalMeshComponent*> Meshes;
	Actor->GetComponents<USkeletalMeshComponent>(Meshes);
	if (Meshes.Num() == 0) return TEXT("no skeletal meshes");

	TArray<FString> Bits;
	for (USkeletalMeshComponent* M : Meshes)
	{
		if (!M) continue;

		// Read the blend weight through reflection: UE 5.7 has no
		// USkeletalMeshComponent::GetPhysicsBlendWeight (the accessor names move between
		// engine versions), but the UPROPERTY name has been stable for years. -1 means
		// "engine does not expose it", never "0".
		double BlendWeight = -1.0;
		ReadNumber(M, { TEXT("PhysicsBlendWeight") }, BlendWeight);

		// S19-GRIPHUNT: the mesh ASSET and what this component is attached to are the two
		// facts that answer "the weapon looks wrong" without a screenshot:
		//   * which mesh is the character actually wearing (is it the READY mesh, or the
		//     original one with no baked socket?),
		//   * is the weapon mesh parented to a real socket (exists=1) or dangling off the
		//     mesh root (socket=(none) / exists=0)?
		const USkeletalMesh* Asset = M->GetSkeletalMeshAsset();
		const FName AttachSocket = M->GetAttachSocketName();
		int32 SocketExists = -1;   // -1 = nothing to check
		if (USkeletalMeshComponent* ParentMesh = Cast<USkeletalMeshComponent>(M->GetAttachParent()))
		{
			SocketExists = AttachSocket.IsNone() ? 0 : (ParentMesh->DoesSocketExist(AttachSocket) ? 1 : 0);
		}
		const FString MeshAsset = Asset ? Asset->GetName() : FString(TEXT("(NO ASSET)"));

		Bits.Add(FString::Printf(TEXT("%s(rag=%d blend=%.2f anim=%s paused=%d vis=%d tick=%d hid=%d mesh=%s parent=%s socket=%s exists=%s)"),
			*M->GetName(),
			M->IsSimulatingPhysics() ? 1 : 0,
			BlendWeight,
			*AnimModeToString(M),
			M->bPauseAnims ? 1 : 0,
			M->IsVisible() ? 1 : 0,
			M->IsComponentTickEnabled() ? 1 : 0,
			M->bHiddenInGame ? 1 : 0,
			*MeshAsset,
			*GetNameSafe(M->GetAttachParent()),
			AttachSocket.IsNone() ? TEXT("(none)") : *AttachSocket.ToString(),
			SocketExists < 0 ? TEXT("n/a") : (SocketExists ? TEXT("1") : TEXT("0"))));
	}
	return FString::Join(Bits, TEXT(" "));
}

FString SquadAISituation::DescribeActor(AActor* Actor)
{
	if (!Actor) return TEXT("<null>");

	FString Line = FString::Printf(TEXT("[%s] hp: %s | pose: %s"),
		*GetNameSafe(Actor), *DescribeHealth(Actor), *DescribePose(Actor));

	if (const ACharacter* Ch = Cast<ACharacter>(Actor))
	{
		if (const UCharacterMovementComponent* CMC = Ch->GetCharacterMovement())
		{
			// Gravity flag by reflection: ACharacter::bEnableGravity is not a public
			// member on every engine version (UE 5.7: not accessible at all). -1 = unknown.
			// Read off Actor, not Ch: the readers take UObject*, and Cast() hands back a
			// const pointer that will not convert (C2664).
			bool bGravity = true;
			const bool bGravityKnown = ReadFlag(Actor, { TEXT("bEnableGravity") }, bGravity);

			// mm = EMovementMode as a number: 0 None, 1 Walking, 2 NavWalking, 3 Falling,
			// 4 Swimming, 5 Flying, 6 Custom (printed numerically so nothing depends on
			// an enum-to-string helper existing in this engine version).
			Line += FString::Printf(TEXT(" | move: mm=%d spd=%.0f/%.0f v=%.0f grav=%d crouch=%d"),
				static_cast<int32>(CMC->MovementMode.GetValue()),
				CMC->Velocity.Size2D(),
				CMC->MaxWalkSpeed,
				CMC->Velocity.Size(),
				bGravityKnown ? (bGravity ? 1 : 0) : -1,
				Ch->bIsCrouched ? 1 : 0);
		}
	}

	const FVector Loc = Actor->GetActorLocation();
	Line += FString::Printf(TEXT(" | loc=(%.0f,%.0f,%.0f)"), Loc.X, Loc.Y, Loc.Z);
	return Line;
}

FString SquadAISituation::DescribeWeapon(AActor* Actor)
{
	if (!Actor) return TEXT("weapon=<none>");

	TArray<FString> Bits;

	// ---- 1. actors attached to the pawn (pack weapons are separate actors) --------
	TArray<AActor*> Attached;
	Actor->GetAttachedActors(Attached);
	for (AActor* A : Attached)
	{
		if (!A) continue;
		USceneComponent* Root = A->GetRootComponent();
		USceneComponent* Parent = Root ? Root->GetAttachParent() : nullptr;
		const FName SocketName = Root ? Root->GetAttachSocketName() : NAME_None;

		// Does the socket this actor is attached to actually EXIST on its parent mesh?
		// A miss here is the classic "weapon hangs off the mesh root / under the feet".
		int32 bSocketExists = -1;   // -1 = not a skeletal parent, nothing to check
		if (USkeletalMeshComponent* ParentMesh = Cast<USkeletalMeshComponent>(Parent))
		{
			bSocketExists = SocketName.IsNone() ? 0 : (ParentMesh->DoesSocketExist(SocketName) ? 1 : 0);
		}

		Bits.Add(FString::Printf(TEXT("attached '%s' parent=%s socket=%s exists=%s relLoc=%s relRot=%s"),
			*GetNameSafe(A),
			*GetNameSafe(Parent),
			SocketName.IsNone() ? TEXT("(none)") : *SocketName.ToString(),
			bSocketExists < 0 ? TEXT("n/a") : (bSocketExists ? TEXT("1") : TEXT("0")),
			Root ? *Root->GetRelativeLocation().ToString() : TEXT("-"),
			Root ? *Root->GetRelativeRotation().ToString() : TEXT("-")));
	}

	// ---- 2. weapon-ish mesh components on the pawn --------------------------------
	TArray<USkeletalMeshComponent*> Meshes;
	Actor->GetComponents<USkeletalMeshComponent>(Meshes);
	for (USkeletalMeshComponent* M : Meshes)
	{
		if (!M) continue;
		const FString N = M->GetName();
		if (!N.Contains(TEXT("Weapon")) && !N.Contains(TEXT("Gun")) && !N.Contains(TEXT("Rifle"))) continue;

		Bits.Add(FString::Printf(TEXT("mesh %s asset=%s parent=%s socket=%s"),
			*N,
			M->GetSkeletalMeshAsset() ? *M->GetSkeletalMeshAsset()->GetName() : TEXT("(NO ASSET)"),
			*GetNameSafe(M->GetAttachParent()),
			M->GetAttachSocketName().IsNone() ? TEXT("(none)") : *M->GetAttachSocketName().ToString()));
	}

	// ---- 3. the grip sockets that exist on the character mesh ---------------------
	// Read straight off the ASSET (mesh-level sockets first, then the skeleton's) - the
	// same two-step the clone station uses. That keeps this report on APIs the project
	// already compiles (USkeletalMesh::FindSocket + USkeleton::Sockets) instead of
	// component-level socket accessors.
	if (ACharacter* Ch = Cast<ACharacter>(Actor))
	{
		// Non-const receivers: USkeletalMesh::FindSocket / GetSkeletalMeshAsset are const
		// in every version this project has built against, but keeping the locals
		// non-const costs nothing and removes the question entirely.
		if (USkeletalMeshComponent* Mesh = Ch->GetMesh())
		{
			if (USkeletalMesh* Asset = Mesh->GetSkeletalMeshAsset())
			{
				const USkeleton* Skel = Asset->GetSkeleton();
				static const TCHAR* ProbeNames[] = {
					TEXT("RifleSocket"), TEXT("weapon_r"), TEXT("Weapon_R"), TEXT("WeaponSocket"),
					TEXT("GripPoint"), TEXT("RightHandSocket"), TEXT("hand_rSocket") };

				TArray<FString> Found;
				for (const TCHAR* Probe : ProbeNames)
				{
					const FName SN(Probe);
					const USkeletalMeshSocket* S = Asset->FindSocket(SN);
					if (!S && Skel)
					{
						for (const TObjectPtr<USkeletalMeshSocket>& SkelSocket : Skel->Sockets)
						{
							if (SkelSocket && SkelSocket->SocketName == SN) { S = SkelSocket; break; }
						}
					}
					if (!S) continue;
					Found.Add(FString::Printf(TEXT("%s(bone=%s loc=%s rot=%s)"),
						Probe, *S->BoneName.ToString(),
						*S->RelativeLocation.ToCompactString(), *S->RelativeRotation.ToString()));   // FRotator has ToString(), not ToCompactString()
				}
				Bits.Add(Found.Num() > 0
					? FString::Printf(TEXT("character mesh %s sockets: %s"), *Asset->GetName(), *FString::Join(Found, TEXT(" ")))
					: FString::Printf(TEXT("character mesh %s: NONE of the known grip socket names exist"), *Asset->GetName()));
			}
		}
	}

	// ---- 3b. S19-GRIPDELTA: does the socket the weapon hangs from agree with the WORKING grip?
	// The player's mesh is what the pack's weapon was authored against. If the same socket NAME
	// carries a different rotation on this pawn's mesh, the weapon sits at the wrong angle even
	// though every name exists - which is exactly what the previous log showed: 'hand_rSocket'
	// rot Y=95.0 on the leader's baked mesh vs Y=185.0 on the player's. One line, no guesswork.
	if (ACharacter* GripCh = Cast<ACharacter>(Actor))
	{
		if (USkeletalMeshComponent* GripMesh = GripCh->GetMesh())
		{
			FName AttachSocket = NAME_None;
			USkeletalMeshComponent* AttachParent = nullptr;
			TArray<USkeletalMeshComponent*> WeaponComps;
			Actor->GetComponents<USkeletalMeshComponent>(WeaponComps);
			for (USkeletalMeshComponent* WC : WeaponComps)
			{
				if (!WC) continue;
				const FString WN = WC->GetName();
				if (!WN.Contains(TEXT("Weapon")) && !WN.Contains(TEXT("Gun")) && !WN.Contains(TEXT("Rifle"))) continue;
				if (WC->GetAttachSocketName().IsNone()) continue;
				AttachSocket = WC->GetAttachSocketName();
				AttachParent = Cast<USkeletalMeshComponent>(WC->GetAttachParent());
				break;
			}

			auto FindSocketByName = [](USkeletalMesh* Asset, FName Name) -> const USkeletalMeshSocket*
			{
				if (!Asset || Name.IsNone()) return nullptr;
				if (const USkeletalMeshSocket* Found = Asset->FindSocket(Name)) return Found;
				if (const USkeleton* Skel = Asset->GetSkeleton())
				{
					for (const TObjectPtr<USkeletalMeshSocket>& SkelSocket : Skel->Sockets)
					{
						if (SkelSocket && SkelSocket->SocketName == Name) return SkelSocket;
					}
				}
				return nullptr;
			};

			USkeletalMesh* OwnAsset = AttachParent ? AttachParent->GetSkeletalMeshAsset() : GripMesh->GetSkeletalMeshAsset();
			if (OwnAsset && !AttachSocket.IsNone())
			{
				const USkeletalMeshSocket* OwnSock = FindSocketByName(OwnAsset, AttachSocket);
				if (OwnSock)
				{
					FString GripLine = FString::Printf(TEXT("grip socket '%s' on %s: loc=%s rot=%s"),
						*AttachSocket.ToString(), *OwnAsset->GetName(),
						*OwnSock->RelativeLocation.ToCompactString(), *OwnSock->RelativeRotation.ToString());

					// The same-named socket on the PLAYER's mesh, when this pawn is not the player.
					APawn* RefPawn = UGameplayStatics::GetPlayerPawn(Actor, 0);
					if (RefPawn && RefPawn != Actor)
					{
						if (ACharacter* RefCh = Cast<ACharacter>(RefPawn))
						{
							if (USkeletalMeshComponent* RefComp = RefCh->GetMesh())
							{
								USkeletalMesh* RefAsset = RefComp->GetSkeletalMeshAsset();
								const USkeletalMeshSocket* RefSock = FindSocketByName(RefAsset, AttachSocket);
								if (OwnAsset != RefAsset && RefSock)
								{
									const float Dot = FMath::Clamp(
										FMath::Abs(FQuat(OwnSock->RelativeRotation) | FQuat(RefSock->RelativeRotation)), 0.f, 1.f);
									const float Deg = FMath::RadiansToDegrees(FMath::Acos(Dot));
									GripLine += FString::Printf(TEXT(" | WORKING grip %s '%s': loc=%s rot=%s -> %.1f deg apart%s"),
										*RefAsset->GetName(), *AttachSocket.ToString(),
										*RefSock->RelativeLocation.ToCompactString(), *RefSock->RelativeRotation.ToString(),
										Deg, Deg > 25.f ? TEXT("  << GRIP MISMATCH (weapon at the wrong angle)") : TEXT("  (grips agree)"));
								}
							}
						}
					}
					Bits.Add(GripLine);
				}
			}
		}
	}

	// ---- 4. native soldiers: is our own attach even armed? -------------------------
	if (const ASoldierCharacter* S = Cast<ASoldierCharacter>(Actor))
	{
		Bits.Add(FString::Printf(TEXT("native: attachSocket=%s autoAttachToMesh=%d packPresentation=%d"),
			*S->GetWeaponAttachSocketName().ToString(),
			S->bAutoAttachEquippedWeaponToMesh ? 1 : 0,
			S->bUsePackPresentationMode ? 1 : 0));
	}

	return FString::Join(Bits, TEXT(" | "));
}

void SquadAISituation::DumpActor(AActor* Actor, const TCHAR* Label)
{
	if (!Actor || !Actor->GetClass()) return;
	if (!PassesGate()) return;

	UE_LOG(LogSquadAISituation, Log, TEXT("[SAI-DUMP] ---- %s %s class=%s ----"),
		Label ? Label : TEXT(""), *GetNameSafe(Actor), *Actor->GetClass()->GetName());
	UE_LOG(LogSquadAISituation, Log, TEXT("[SAI-DUMP]   state: %s"), *DescribeActor(Actor));
	UE_LOG(LogSquadAISituation, Log, TEXT("[SAI-DUMP]   weapon: %s"), *DescribeWeapon(Actor));

	// Class hierarchy - finds the pack's C++ base class at a glance.
	int32 Depth = 0;
	for (UClass* C = Actor->GetClass(); C && Depth < 8; C = C->GetSuperClass(), ++Depth)
	{
		UE_LOG(LogSquadAISituation, Log, TEXT("[SAI-DUMP]   hierarchy[%d] %s"), Depth, *C->GetName());
	}

	// Interesting actor-level properties (including inherited ones)
	for (TFieldIterator<FProperty> It(Actor->GetClass(), EFieldIteratorFlags::IncludeSuper); It; ++It)
	{
		FProperty* P = *It;
		if (!P || !IsInterestingPropName(P->GetName())) continue;
		const FString V = PropValueToString(P, Actor);
		if (!V.IsEmpty())
		{
			UE_LOG(LogSquadAISituation, Log, TEXT("[SAI-DUMP]   actor prop %s %s=%s"),
				*P->GetCPPType(), *P->GetName(), *V);
		}
	}

	TArray<UActorComponent*> Comps;
	Actor->GetComponents(Comps);
	UE_LOG(LogSquadAISituation, Log, TEXT("[SAI-DUMP]   %d components"), Comps.Num());
	for (UActorComponent* C : Comps)
	{
		if (!C || !C->GetClass()) continue;
		const FString CompName = C->GetName();
		const FString ClassName = C->GetClass()->GetName();
		const bool bHealth = IsHealthComponentName(CompName, ClassName);

		UE_LOG(LogSquadAISituation, Log, TEXT("[SAI-DUMP]   comp %s class=%s%s"),
			*CompName, *ClassName, bHealth ? TEXT("  <-- HEALTH") : TEXT(""));

		int32 Printed = 0;
		for (TFieldIterator<FProperty> It(C->GetClass(), EFieldIteratorFlags::IncludeSuper); It && Printed < 20; ++It)
		{
			FProperty* P = *It;
			if (!P) continue;
			// For a health component everything is interesting (that is the whole point of
			// dumping it); for other components only the names we usually debug.
			if (!bHealth && !IsInterestingPropName(P->GetName())) continue;
			const FString V = PropValueToString(P, C);
			if (V.IsEmpty()) continue;
			UE_LOG(LogSquadAISituation, Log, TEXT("[SAI-DUMP]       %s %s=%s"), *P->GetCPPType(), *P->GetName(), *V);
			++Printed;
		}
	}
}

// ---------------------------------------------------------------------------
//  Event lines
// ---------------------------------------------------------------------------
bool SquadAISituation::IsEnabled()
{
	return CVarSituationLog.GetValueOnGameThread() != 0;
}

void SquadAISituation::Note(const FString& Msg)
{
	if (!PassesGate()) return;
	if (Msg.StartsWith(TEXT("PLAYER-DMG")))
	{
		++PackDamageEventsSinceSnapshot;
	}
	bNextSnapshotForced = true;
	Write(TEXT("SAI-EVT"), Msg);
}

void SquadAISituation::NoteOnce(const FString& Key, const FString& Msg)
{
	if (!IsEnabled()) return;
	if (OnceKeys.Contains(Key)) return;
	if (OnceKeys.Num() > 256)
	{
		OnceKeys.Empty(); // bounded: keys are only used to de-duplicate, never read back
	}
	OnceKeys.Add(Key);
	Note(Msg);
}

// ---------------------------------------------------------------------------
//  Snapshot
// ---------------------------------------------------------------------------
namespace
{
	void AddTracked(AActor* Actor, TArray<AActor*>& Out, TSet<AActor*>& Seen)
	{
		if (!Actor || !Actor->GetClass() || Seen.Contains(Actor)) return;
		Seen.Add(Actor);
		Out.Add(Actor);
	}

	/** Up to three squad mates near the player, so the log shows the whole squad
	 *  without turning into a wall of text. */
	void AddNearbySquad(UWorld* World, AActor* PlayerPawn, ALeaderCharacter* Leader,
		TArray<AActor*>& Out, TSet<AActor*>& Seen)
	{
		USoldierRegistrySubsystem* Registry = World->GetSubsystem<USoldierRegistrySubsystem>();
		if (!Registry) return;

		const FVector Origin = PlayerPawn ? PlayerPawn->GetActorLocation()
										  : (Leader ? Leader->GetActorLocation() : FVector::ZeroVector);
		TArray<ASoldierCharacter*> Nearby = Registry->QueryRadius(Origin, 8000.f);

		// Pick the nearest three by hand instead of TArray::Sort(). Sort wraps the
		// predicate in TDereferenceWrapper, which calls it with *dereferenced* elements
		// ("bool operator()(T* A, T* B) { return Predicate(*A, *B); }") - so a predicate
		// written for pointer elements does not compile. A selection loop has no such
		// trap and is trivially small at four candidates.
		const int32 LeaderTeam = Leader ? Leader->GetGenericTeamId().GetId() : 0;
		const int32 MaxTracked = 3;
		for (int32 Pick = 0; Pick < MaxTracked; ++Pick)
		{
			ASoldierCharacter* Best = nullptr;
			float BestDistSq = -1.f;

			for (ASoldierCharacter* Candidate : Nearby)
			{
				if (!Candidate || Candidate == Leader) continue;
				if (Seen.Contains(Candidate)) continue;                                 // already tracked
				if (Candidate->GetGenericTeamId().GetId() != LeaderTeam) continue;      // squad only, not enemies

				const float DistSq = FVector::DistSquared(Candidate->GetActorLocation(), Origin);
				if (BestDistSq < 0.f || DistSq < BestDistSq)
				{
					BestDistSq = DistSq;
					Best = Candidate;
				}
			}

			if (!Best) break;   // no more candidates
			AddTracked(Best, Out, Seen);
		}
	}
}

void SquadAISituation::Tick(UWorld* World, float DeltaTime)
{
	if (!World || World->IsNetMode(NM_DedicatedServer)) return;
	if (!IsEnabled()) return;

	CachedWorld = World;

	const float Now = World->GetTimeSeconds();
	const float Period = FMath::Clamp(CVarSituationPeriod.GetValueOnGameThread(), 0.1f, 30.f);

	// Two hosts drive this (the player bridge and the leader's tick); whichever gets
	// here first in a period does the work, the other returns immediately.
	if (!bNextSnapshotForced && LastSnapshotTime >= 0.f && (Now - LastSnapshotTime) < Period)
	{
		return;
	}
	LastSnapshotTime = Now;
	bNextSnapshotForced = false;

	if (!PassesGate()) return;

	// ---- who do we describe? player, leader, up to 3 squad mates ----------
	TArray<AActor*> Tracked;
	TSet<AActor*> Seen;

	APawn* PlayerPawn = UGameplayStatics::GetPlayerPawn(World, 0);
	ALeaderCharacter* Leader = nullptr;
	for (TActorIterator<ALeaderCharacter> It(World); It; ++It)
	{
		Leader = *It;
		break;
	}

	AddTracked(PlayerPawn, Tracked, Seen);
	AddTracked(Leader, Tracked, Seen);
	AddNearbySquad(World, PlayerPawn, Leader, Tracked, Seen);

	// ---- build the snapshot ----------------------------------------------
	TArray<FString> Lines;
	for (AActor* A : Tracked)
	{
		Lines.Add(DescribeActor(A));

		// S19-GRIPHUNT: report where the weapon actually is, once per pawn per run.
		// "The weapon is in the wrong position" is otherwise unanswerable from a log.
		SquadAISituation::NoteOnce(
			FString::Printf(TEXT("weapon-report:%s"), *GetNameSafe(A)),
			FString::Printf(TEXT("WEAPON %s: %s"), *GetNameSafe(A), *DescribeWeapon(A)));

		// S19-HPDROP: unexplained health drop (see the state block at the top).
		{
			double Cur = 0.0;
			FString CompName;
			if (ReadFirstPackHealth(A, Cur, CompName))
			{
				const FString Name = GetNameSafe(A);
				const FTrackedHealth* Prev = LastTrackedHealth.FindByPredicate(
					[&Name](const FTrackedHealth& E) { return E.Name == Name; });
				if (Prev && Prev->Health >= 0.0 && Cur < Prev->Health - 0.5
					&& PackDamageEventsSinceSnapshot == 0)
				{
					// Not forced through Note(): this happens inside the snapshot, and
					// Note() would schedule a second snapshot on the next tick.
					Write(TEXT("SAI-EVT"), FString::Printf(
						TEXT("HP-DROP %s: %s %.1f -> %.1f (-%.1f) with no SquadAI damage event in between - ")
						TEXT("this is pack-side damage (explosive/falling/collision) or a health reset"),
						*Name, *CompName, Prev->Health, Cur, Prev->Health - Cur));
				}

				if (FTrackedHealth* Slot = LastTrackedHealth.FindByPredicate(
						[&Name](const FTrackedHealth& E) { return E.Name == Name; }))
				{
					Slot->Health = Cur;
				}
				else
				{
					LastTrackedHealth.Add({ Name, Cur });
				}
			}
		}

		if (A == Leader)
		{
			// The leader gets an extra pacing line: this is where "he stopped walking
			// to the quest zone" becomes visible (decision, speed, how long he has
			// been waiting, and how far the objective still is).
			FString Pace = FString::Printf(TEXT("mode=%s"),
				Leader->IsHoldingForPlayer() ? TEXT("HALT-FOR-PLAYER") : TEXT("MOVE"));
			if (Leader->IsHoldingForPlayer())
			{
				Pace += FString::Printf(TEXT("(waited %.1fs of %.0fs)"),
					Leader->GetPacingWaitSeconds(), Leader->MaxWaitForPlayerSeconds);
			}

			if (const ASoldierAIController* AIC = Cast<ASoldierAIController>(Leader->GetController()))
			{
				const FVector Goal = AIC->GetEffectiveMoveGoal();
				Pace += FString::Printf(TEXT(" taskDriving=%d goalDist=%.0f goal=(%.0f,%.0f,%.0f) pathSpeedScale=%.2f"),
					AIC->IsLeaderPathTaskDriving() ? 1 : 0,
					FVector::Dist2D(Leader->GetActorLocation(), Goal),
					Goal.X, Goal.Y, Goal.Z,
					AIC->PathSpeedScale);
			}
			Pace += FString::Printf(TEXT(" playerDist=%.0f"), Leader->GetPlayerDistance());

			Lines.Add(FString::Printf(TEXT("[%s] pacing: %s"), *GetNameSafe(Leader), *Pace));
		}
	}

	// ---- write it, but only when it changed (or on demand) ----------------
	bool bChanged = (Lines.Num() != LastSnapshot.Num());
	if (!bChanged)
	{
		for (int32 i = 0; i < Lines.Num(); ++i)
		{
			if (Lines[i] != LastSnapshot[i]) { bChanged = true; break; }
		}
	}

	if (bChanged || CVarSituationForce.GetValueOnGameThread() != 0)
	{
		LastSnapshot = Lines;
		LastChangeTime = Now;
		for (const FString& L : Lines)
		{
			Write(TEXT("SAI"), L);
		}
	}
	else
	{
		const float Heartbeat = CVarSituationHeartbeat.GetValueOnGameThread();
		if (Heartbeat > 0.f && (Now - LastChangeTime) >= Heartbeat)
		{
			LastChangeTime = Now;
			Write(TEXT("SAI"), FString::Printf(TEXT("heartbeat - no state change for %.0fs (%d tracked pawns)"),
				Heartbeat, Tracked.Num()));
		}
	}

	PackDamageEventsSinceSnapshot = 0;

	// DeltaTime is intentionally unused: the throttle is wall-clock based, so an
	// uncapped or very low frame rate cannot change how often snapshots appear.
	(void)DeltaTime;
}

// ---------------------------------------------------------------------------
//  Console commands - capture the full state on demand, without waiting for a change
// ---------------------------------------------------------------------------
namespace
{
	void DumpEverything(UWorld* World, const FString& NameFilter)
	{
		if (!World) return;
		CachedWorld = World;
		bNextSnapshotForced = true;

		UE_LOG(LogSquadAISituation, Log, TEXT("[SAI-DUMP] ==== requested dump (t=%.2f) filter='%s' ===="),
			World->GetTimeSeconds(), *NameFilter);

		int32 Dumped = 0;
		TSet<AActor*> Seen;

		if (APawn* PlayerPawn = UGameplayStatics::GetPlayerPawn(World, 0))
		{
			Seen.Add(PlayerPawn);
			UE_LOG(LogSquadAISituation, Log, TEXT("[SAI-DUMP] player  %s"), *SquadAISituation::DescribeActor(PlayerPawn));
			if (NameFilter.IsEmpty() || GetNameSafe(PlayerPawn).Contains(NameFilter))
			{
				SquadAISituation::DumpActor(PlayerPawn, TEXT("player"));
				++Dumped;
			}
		}

		for (TActorIterator<ASoldierCharacter> It(World); It; ++It)
		{
			ASoldierCharacter* S = *It;
			if (!S || Seen.Contains(S)) continue;
			Seen.Add(S);
			UE_LOG(LogSquadAISituation, Log, TEXT("[SAI-DUMP] soldier %s"), *SquadAISituation::DescribeActor(S));
			if (NameFilter.IsEmpty() || GetNameSafe(S).Contains(NameFilter))
			{
				SquadAISituation::DumpActor(S, TEXT("soldier"));
				++Dumped;
			}
		}

		UE_LOG(LogSquadAISituation, Log, TEXT("[SAI-DUMP] ==== %d actor(s) dumped in full ===="), Dumped);
	}

	void CmdDump(const TArray<FString>& Args, UWorld* World)
	{
		DumpEverything(World, Args.Num() > 0 ? Args[0] : FString());
	}

	void CmdForceSnapshot(const TArray<FString>& /*Args*/, UWorld* World)
	{
		if (World)
		{
			CachedWorld = World;
			bNextSnapshotForced = true;
		}
	}

	FAutoConsoleCommandWithWorldAndArgs CmdSituationDump(
		TEXT("SquadAI.SituationLog.Dump"),
		TEXT("Print the full state (health / pose / movement / interesting component properties) of the "
			 "player, the leader and the squad right now. Optional argument filters by actor name, e.g. "
			 "SquadAI.SituationLog.Dump PlayerCharacter"),
		FConsoleCommandWithWorldAndArgsDelegate::CreateStatic(&CmdDump),
		ECVF_Cheat);

	FAutoConsoleCommandWithWorldAndArgs CmdSituationNow(
		TEXT("SquadAI.SituationLog.Now"),
		TEXT("Force the next situation snapshot to be written even if nothing changed."),
		FConsoleCommandWithWorldAndArgsDelegate::CreateStatic(&CmdForceSnapshot),
		ECVF_Cheat);
}

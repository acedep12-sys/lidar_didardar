#include "Performance/SquadAIAssetCacheSubsystem.h"
#include "Engine/StaticMesh.h"
#include "Materials/MaterialInterface.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Materials/MaterialInstanceConstant.h"   // S26-KEEP: saved per-prop instances
#include "Materials/Material.h"                       // S26-MAT: authoring M_SquadAIProp
#include "Materials/MaterialExpressionTextureSampleParameter2D.h"   // S26-MAT
#include "Materials/MaterialExpressionVectorParameter.h"            // S26-MAT
#include "Materials/MaterialExpressionMultiply.h"                   // S26-MAT
#include "Materials/MaterialExpressionTextureCoordinate.h"           // S26-SURF: grime UV tiling
#include "Materials/MaterialExpressionConstant.h"                    // S26-BUMP: matte roughness
#include "Materials/MaterialExpressionScalarParameter.h"           // S26-TEX3: UVScale + Metal params
#include "Materials/MaterialExpressionSubtract.h"                 // S27-COMPILEFIX: minimap mask chain
#include "Materials/MaterialExpressionLength.h"                   // S27-COMPILEFIX
#include "Materials/MaterialExpressionAdd.h"                      // S27-COMPILEFIX
#include "Materials/MaterialExpressionSaturate.h"                 // S27-COMPILEFIX
#include "Utilities/SquadAIAssetHelper.h"             // S26-MAT: texture asset/PNG loader
#include "Engine/World.h"
#include "Engine/Engine.h"
// S27-COMPILEFIX: these three are used on the material-authoring paths that
// run in every build configuration (the editor-only guard on the include
// compiled fine in the editor and broke packaged builds).
#include "AssetRegistry/AssetRegistryModule.h"        // S26-MAT: AssetCreated
#include "UObject/SavePackage.h"                      // S26-MAT: persist M_SquadAIProp
#include "Misc/PackageName.h"                         // S26-MAT: /Game path -> filename

void USquadAIAssetCacheSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
	PrewarmCanonicalAssets();
	UE_LOG(LogTemp, Log, TEXT("[SquadAIAssetCache] Initialized centralized asset flyweight registry"));
}

void USquadAIAssetCacheSubsystem::Deinitialize()
{
	FlushDynamicCache();
	Super::Deinitialize();
}

USquadAIAssetCacheSubsystem* USquadAIAssetCacheSubsystem::Get(const UObject* WorldContextObject)
{
	if (!WorldContextObject) return nullptr;
	UWorld* World = GEngine ? GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::ReturnNull) : nullptr;
	return World ? World->GetSubsystem<USquadAIAssetCacheSubsystem>() : nullptr;
}

void USquadAIAssetCacheSubsystem::PrewarmCanonicalAssets()
{
	CachedCubeMesh = LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cube.Cube"));
	CachedCylinderMesh = LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cylinder.Cylinder"));
	CachedSphereMesh = LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Sphere.Sphere"));
	CachedPlaneMesh = LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Plane.Plane"));

	CachedDefaultMaterial = LoadObject<UMaterialInterface>(nullptr, TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"));
	if (!CachedDefaultMaterial)
	{
		CachedDefaultMaterial = LoadObject<UMaterialInterface>(nullptr, TEXT("/Engine/EngineMaterials/DefaultMaterial.DefaultMaterial"));
	}

	if (CachedCubeMesh) LoadedMeshCache.Add(TEXT("/Engine/BasicShapes/Cube.Cube"), CachedCubeMesh);
	if (CachedCylinderMesh) LoadedMeshCache.Add(TEXT("/Engine/BasicShapes/Cylinder.Cylinder"), CachedCylinderMesh);
	if (CachedSphereMesh) LoadedMeshCache.Add(TEXT("/Engine/BasicShapes/Sphere.Sphere"), CachedSphereMesh);
	if (CachedPlaneMesh) LoadedMeshCache.Add(TEXT("/Engine/BasicShapes/Plane.Plane"), CachedPlaneMesh);
	if (CachedDefaultMaterial) LoadedMaterialCache.Add(TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"), CachedDefaultMaterial);
}

UStaticMesh* USquadAIAssetCacheSubsystem::GetCubeMesh()
{
	if (!CachedCubeMesh)
	{
		CachedCubeMesh = LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cube.Cube"));
	}
	return CachedCubeMesh;
}

UStaticMesh* USquadAIAssetCacheSubsystem::GetCylinderMesh()
{
	if (!CachedCylinderMesh)
	{
		CachedCylinderMesh = LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cylinder.Cylinder"));
	}
	return CachedCylinderMesh;
}

UStaticMesh* USquadAIAssetCacheSubsystem::GetSphereMesh()
{
	if (!CachedSphereMesh)
	{
		CachedSphereMesh = LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Sphere.Sphere"));
	}
	return CachedSphereMesh;
}

UStaticMesh* USquadAIAssetCacheSubsystem::GetPlaneMesh()
{
	if (!CachedPlaneMesh)
	{
		CachedPlaneMesh = LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Plane.Plane"));
	}
	return CachedPlaneMesh;
}

UStaticMesh* USquadAIAssetCacheSubsystem::GetOrLoadMesh(const FString& Path)
{
	if (Path.IsEmpty()) return nullptr;

	if (TObjectPtr<UStaticMesh>* Found = LoadedMeshCache.Find(Path))
	{
		if (Found->Get()) return Found->Get();
	}

	UStaticMesh* LoadedMesh = LoadObject<UStaticMesh>(nullptr, *Path);
	if (LoadedMesh)
	{
		LoadedMeshCache.Add(Path, LoadedMesh);
	}
	return LoadedMesh;
}

UMaterialInterface* USquadAIAssetCacheSubsystem::GetDefaultBasicMaterial()
{
	if (!CachedDefaultMaterial)
	{
		CachedDefaultMaterial = LoadObject<UMaterialInterface>(nullptr, TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"));
		if (!CachedDefaultMaterial)
		{
			CachedDefaultMaterial = LoadObject<UMaterialInterface>(nullptr, TEXT("/Engine/EngineMaterials/DefaultMaterial.DefaultMaterial"));
		}
	}
	return CachedDefaultMaterial;
}

UMaterialInterface* USquadAIAssetCacheSubsystem::GetOrLoadMaterial(const FString& Path)
{
	if (Path.IsEmpty()) return nullptr;

	if (TObjectPtr<UMaterialInterface>* Found = LoadedMaterialCache.Find(Path))
	{
		if (Found->Get()) return Found->Get();
	}

	UMaterialInterface* LoadedMat = LoadObject<UMaterialInterface>(nullptr, *Path);
	if (LoadedMat)
	{
		LoadedMaterialCache.Add(Path, LoadedMat);
	}
	return LoadedMat;
}

UMaterialInterface* USquadAIAssetCacheSubsystem::GetSharedDynamicMaterial(UMaterialInterface* BaseMaterial, FName ParameterName, FLinearColor Value)
{
	if (!BaseMaterial) return nullptr;

	const FString CacheKey = FString::Printf(TEXT("%s_%s_%s"), *BaseMaterial->GetName(), *ParameterName.ToString(), *Value.ToString());
	if (TObjectPtr<UMaterialInterface>* Found = LoadedMaterialCache.Find(CacheKey))
	{
		if (Found->Get()) return Found->Get();
	}

	UMaterialInstanceDynamic* MID = UMaterialInstanceDynamic::Create(BaseMaterial, this);
	if (MID)
	{
		MID->SetVectorParameterValue(ParameterName, Value);
		LoadedMaterialCache.Add(CacheKey, MID);
		return MID;
	}

	return BaseMaterial;
}

void USquadAIAssetCacheSubsystem::FlushDynamicCache()
{
	LoadedMeshCache.Empty();
	LoadedMaterialCache.Empty();
	CachedPropMaterials.Empty();   // S26-MAT: MIDs are rebuilt on demand; the parent stays
	PrewarmCanonicalAssets();
}

// ============================ S26-MAT =======================================
// S26-BUMP: find a named texture parameter expression on a material (or null)
static UMaterialExpressionTextureSampleParameter2D* FindTexParam(UMaterial* Mat, const TCHAR* Name)
{
#if WITH_EDITOR   // S26-FIX: the expression array only exists in editor builds
	if (!Mat) return nullptr;
	const FName Wanted = FName(Name);
	// S26-FIX: GetExpressions() was removed from FMaterialExpressionCollection -
	// the public Expressions array is the API (AddExpression is still there)
	for (UMaterialExpression* E : Mat->GetExpressionCollection().Expressions)
	{
		if (UMaterialExpressionTextureSampleParameter2D* P = Cast<UMaterialExpressionTextureSampleParameter2D>(E))
		{
			if (P->ParameterName == Wanted) { return P; }
		}
	}
#endif
	return nullptr;
}

UMaterial* USquadAIAssetCacheSubsystem::EnsurePropBaseMaterial()
{
	if (CachedPropBaseMaterial && IsValid(CachedPropBaseMaterial))
	{
		return Cast<UMaterial>(CachedPropBaseMaterial);
	}
	// already in the project (a previous press authored + saved it)?
	if (FPackageName::DoesPackageExist(TEXT("/Game/Materials/M_SquadAIProp")))
	{
		if (UMaterial* Existing = LoadObject<UMaterial>(nullptr, TEXT("/Game/Materials/M_SquadAIProp.M_SquadAIProp")))
		{
			CachedPropBaseMaterial = Existing;
			return Existing;
		}
	}
#if WITH_EDITOR
	// Author it in transient memory so PIE / StreamingPauseRendering never creates or saves dirty asset packages.
	UPackage* Pkg = GetTransientPackage();
	if (!Pkg)
	{
		return nullptr;
	}
	UMaterial* M = NewObject<UMaterial>(Pkg, NAME_None, RF_Transient);
	if (!M)
	{
		return nullptr;
	}
	UMaterialExpressionTextureSampleParameter2D* TexP = NewObject<UMaterialExpressionTextureSampleParameter2D>(M);
	TexP->SetParameterName(TEXT("Tex"));
	// SamplerType left at its default (Color) - the enum's value names moved around
	// across engine versions and the default is exactly what a color texture wants.
	// S26-TEX3: base UV tiling - TexCoord x UVScale (default 1) into the sample
	UMaterialExpressionTextureCoordinate* BaseUV = NewObject<UMaterialExpressionTextureCoordinate>(M);
	UMaterialExpressionScalarParameter* UVScaleP = NewObject<UMaterialExpressionScalarParameter>(M);
	UVScaleP->SetParameterName(TEXT("UVScale"));
	UVScaleP->DefaultValue = 1.f;
	UMaterialExpressionMultiply* UVMul = NewObject<UMaterialExpressionMultiply>(M);
	BaseUV->ConnectExpression(&UVMul->A, 0);
	UVScaleP->ConnectExpression(&UVMul->B, 0);
	UVMul->ConnectExpression(&TexP->Coordinates, 0);
	M->GetExpressionCollection().AddExpression(BaseUV);
	M->GetExpressionCollection().AddExpression(UVScaleP);
	M->GetExpressionCollection().AddExpression(UVMul);
	// S26-TEX3: metallic as a parameter so painted steel can shine a little
	UMaterialExpressionScalarParameter* MetalP = NewObject<UMaterialExpressionScalarParameter>(M);
	MetalP->SetParameterName(TEXT("Metal"));
	MetalP->DefaultValue = 0.f;
	M->GetExpressionCollection().AddExpression(MetalP);
	if (FExpressionInput* MetalInput = M->GetExpressionInputForProperty(EMaterialProperty::MP_Metallic))
	{
		MetalP->ConnectExpression(MetalInput, 0);
	}
	UMaterialExpressionVectorParameter* TintP = NewObject<UMaterialExpressionVectorParameter>(M);
	TintP->SetParameterName(TEXT("Tint"));
	UMaterialExpressionMultiply* Mul = NewObject<UMaterialExpressionMultiply>(M);
	TexP->ConnectExpression(&Mul->A, 0);
	TintP->ConnectExpression(&Mul->B, 0);
	M->GetExpressionCollection().AddExpression(TexP);
	M->GetExpressionCollection().AddExpression(TintP);
	M->GetExpressionCollection().AddExpression(Mul);
	// S26-SURF: grime overlay - a mottled wear texture sampled at a different UV
	// scale than the base and multiplied over the color, so no two faces wear
	// the same dirt. Missing texture = chain unchanged.
	UMaterialExpression* ColorChain = Mul;
	if (UTexture2D* GrimeTex = FSquadAIAssetHelper::LoadTextureSafe(
		TEXT("/Game/Textures/SquadAI/Grime.Grime"), TEXT("Textures/SquadAI/Grime.png")))
	{
		UMaterialExpressionTextureSampleParameter2D* GrimeP = NewObject<UMaterialExpressionTextureSampleParameter2D>(M);
		GrimeP->SetParameterName(TEXT("GrimeTex"));
		GrimeP->Texture = GrimeTex;
		UMaterialExpressionTextureCoordinate* GrimeUV = NewObject<UMaterialExpressionTextureCoordinate>(M);
		GrimeUV->UTiling = 0.37f;
		GrimeUV->VTiling = 0.41f;   // different per axis: the wear never lines up with the base
		GrimeUV->ConnectExpression(&GrimeP->Coordinates, 0);
		UMaterialExpressionMultiply* Mul2 = NewObject<UMaterialExpressionMultiply>(M);
		Mul->ConnectExpression(&Mul2->A, 0);
		GrimeP->ConnectExpression(&Mul2->B, 0);
		M->GetExpressionCollection().AddExpression(GrimeP);
		M->GetExpressionCollection().AddExpression(GrimeUV);
		M->GetExpressionCollection().AddExpression(Mul2);
		ColorChain = Mul2;
		// S26-BUMP: the dirt patch IS the occluded patch - one sample, two jobs
		if (FExpressionInput* AOInput = M->GetExpressionInputForProperty(EMaterialProperty::MP_AmbientOcclusion))
		{
			GrimeP->ConnectExpression(AOInput, 0);
		}
	}
	// S26-BUMP: the relief layer - a normal map parameter, flat by default, so a
	// prop without a specific bump map shades exactly as it did before.
	UMaterialExpressionTextureSampleParameter2D* NormP = NewObject<UMaterialExpressionTextureSampleParameter2D>(M);
	NormP->SetParameterName(TEXT("NormalTex"));
	if (UTexture2D* FlatN = FSquadAIAssetHelper::LoadNormalTextureSafe(
		TEXT("/Game/Textures/SquadAI/FlatNormal.FlatNormal"), TEXT("Textures/SquadAI/FlatNormal.png")))
	{
		NormP->Texture = FlatN;
	}
	M->GetExpressionCollection().AddExpression(NormP);
	if (FExpressionInput* NormalInput = M->GetExpressionInputForProperty(EMaterialProperty::MP_Normal))
	{
		NormP->ConnectExpression(NormalInput, 0);
	}
	// S26-TEX2: roughness is a MAP now, not one constant - FlatRough.png is a
	// flat 0.85 (the old constant look), each key overrides with <Key>_R.png
	UMaterialExpressionTextureSampleParameter2D* RoughP = NewObject<UMaterialExpressionTextureSampleParameter2D>(M);
	RoughP->SetParameterName(TEXT("RoughTex"));
	if (UTexture2D* FlatR = FSquadAIAssetHelper::LoadLinearTextureSafe(
		TEXT("/Game/Textures/SquadAI/FlatRough.FlatRough"), TEXT("Textures/SquadAI/FlatRough.png")))
	{
		RoughP->Texture = FlatR;
	}
	M->GetExpressionCollection().AddExpression(RoughP);
	if (FExpressionInput* RoughInput = M->GetExpressionInputForProperty(EMaterialProperty::MP_Roughness))
	{
		RoughP->ConnectExpression(RoughInput, 0);
	}
	// S26-MAT2: UMaterial::BaseColor stopped being a public member - the engine
	// accessor is GetExpressionInputForProperty(EMaterialProperty::MP_BaseColor).
	if (FExpressionInput* BaseColorInput = M->GetExpressionInputForProperty(EMaterialProperty::MP_BaseColor))
	{
		ColorChain->ConnectExpression(BaseColorInput, 0);
	}
	M->PreEditChange(nullptr);
	M->PostEditChange();
	CachedPropBaseMaterial = M;
	return M;
#else
	return nullptr;
#endif
}

UMaterial* USquadAIAssetCacheSubsystem::EnsureMinimapMaterial()
{
	if (CachedMinimapMaterial && IsValid(CachedMinimapMaterial))
	{
		return Cast<UMaterial>(CachedMinimapMaterial);
	}
	if (FPackageName::DoesPackageExist(TEXT("/Game/Materials/M_SquadAIMinimap")))
	{
		if (UMaterial* Existing = LoadObject<UMaterial>(nullptr, TEXT("/Game/Materials/M_SquadAIMinimap.M_SquadAIMinimap")))
		{
			CachedMinimapMaterial = Existing;
			return Existing;
		}
	}
#if WITH_EDITOR
	// S26-MMAT / S27-CRASHFIX: keep the authored material in transient memory during PIE
	// instead of calling UPackage::SavePackage inside DrawHUD / StreamingPauseRendering.
	UPackage* Pkg = GetTransientPackage();
	if (!Pkg)
	{
		return nullptr;
	}
	UMaterial* M = NewObject<UMaterial>(Pkg, NAME_None, RF_Transient);
	if (!M)
	{
		return nullptr;
	}
	// S27-COMPILEFIX: ShadingModel is private in UE 5.7 - the setter is the
	// supported API on every version.
	M->SetShadingModel(EMaterialShadingModel::MSM_Unlit);
	M->BlendMode = EBlendMode::BLEND_Translucent;
	// the capture itself - the MID sets this parameter every frame
	UMaterialExpressionTextureSampleParameter2D* TexP = NewObject<UMaterialExpressionTextureSampleParameter2D>(M);
	TexP->SetParameterName(TEXT("MinimapTexture"));
	M->GetExpressionCollection().AddExpression(TexP);
	if (FExpressionInput* EmissiveInput = M->GetExpressionInputForProperty(EMaterialProperty::MP_EmissiveColor))
	{
		TexP->ConnectExpression(EmissiveInput, 0);
	}
	// the circular mask: UV - 0.5 -> length -> (0.5 - D) * 50 -> saturate
	UMaterialExpressionTextureCoordinate* UV = NewObject<UMaterialExpressionTextureCoordinate>(M);
	UMaterialExpressionConstant* Half = NewObject<UMaterialExpressionConstant>(M);
	Half->R = 0.5f;
	UMaterialExpressionSubtract* Center = NewObject<UMaterialExpressionSubtract>(M);
	UV->ConnectExpression(&Center->A, 0);
	Half->ConnectExpression(&Center->B, 0);
	UMaterialExpressionLength* Dist = NewObject<UMaterialExpressionLength>(M);
	Center->ConnectExpression(&Dist->Input, 0);
	UMaterialExpressionConstant* Slope = NewObject<UMaterialExpressionConstant>(M);
	Slope->R = -50.f;
	UMaterialExpressionMultiply* Scaled = NewObject<UMaterialExpressionMultiply>(M);
	Dist->ConnectExpression(&Scaled->A, 0);
	Slope->ConnectExpression(&Scaled->B, 0);
	UMaterialExpressionConstant* Offset = NewObject<UMaterialExpressionConstant>(M);
	Offset->R = 25.f;
	UMaterialExpressionAdd* Shaped = NewObject<UMaterialExpressionAdd>(M);
	Scaled->ConnectExpression(&Shaped->A, 0);
	Offset->ConnectExpression(&Shaped->B, 0);
	UMaterialExpressionSaturate* Mask = NewObject<UMaterialExpressionSaturate>(M);
	Shaped->ConnectExpression(&Mask->Input, 0);
	for (UMaterialExpression* E : { (UMaterialExpression*)UV, (UMaterialExpression*)Half, (UMaterialExpression*)Center,
		(UMaterialExpression*)Dist, (UMaterialExpression*)Slope, (UMaterialExpression*)Scaled,
		(UMaterialExpression*)Offset, (UMaterialExpression*)Shaped, (UMaterialExpression*)Mask })
	{
		M->GetExpressionCollection().AddExpression(E);
	}
	if (FExpressionInput* OpacityInput = M->GetExpressionInputForProperty(EMaterialProperty::MP_Opacity))
	{
		Mask->ConnectExpression(OpacityInput, 0);
	}
	M->PreEditChange(nullptr);
	M->PostEditChange();
	CachedMinimapMaterial = M;
	return M;
#else
	return nullptr;
#endif
}

UMaterial* USquadAIAssetCacheSubsystem::EnsureHUDFrostedBlurMaterial()
{
	if (CachedHUDBlurMaterial && IsValid(CachedHUDBlurMaterial))
	{
		return Cast<UMaterial>(CachedHUDBlurMaterial);
	}
	if (FPackageName::DoesPackageExist(TEXT("/Game/Materials/M_SquadAIHUDBlur")))
	{
		if (UMaterial* Existing = LoadObject<UMaterial>(nullptr, TEXT("/Game/Materials/M_SquadAIHUDBlur.M_SquadAIHUDBlur")))
		{
			CachedHUDBlurMaterial = Existing;
			return Existing;
		}
	}
#if WITH_EDITOR
	UPackage* Pkg = GetTransientPackage();
	if (!Pkg)
	{
		return nullptr;
	}
	UMaterial* M = NewObject<UMaterial>(Pkg, NAME_None, RF_Transient);
	if (!M)
	{
		return nullptr;
	}
	M->SetShadingModel(EMaterialShadingModel::MSM_Unlit);
	M->BlendMode = EBlendMode::BLEND_Translucent;

	// S27-BLUR: 5-tap diagonal Gaussian blur kernel in material shader.
	// Uses Pin 0 (RGB) of each TextureSampleParameter2D ("BlurTexture") and a scalar
	// "BlurOpacity" parameter for MP_Opacity so it completely ignores SceneCapture's
	// inverse/zero alpha channel!
	UMaterialExpressionTextureCoordinate* BaseUV = NewObject<UMaterialExpressionTextureCoordinate>(M);
	M->GetExpressionCollection().AddExpression(BaseUV);

	const float Offsets[5] = { 0.0f, 0.0042f, -0.0042f, 0.0088f, -0.0088f };
	const float Weights[5] = { 0.28f, 0.22f, 0.22f, 0.14f, 0.14f };

	UMaterialExpression* SumChain = nullptr;
	for (int32 i = 0; i < 5; ++i)
	{
		UMaterialExpressionTextureSampleParameter2D* TapTex = NewObject<UMaterialExpressionTextureSampleParameter2D>(M);
		TapTex->SetParameterName(TEXT("BlurTexture"));
		M->GetExpressionCollection().AddExpression(TapTex);

		if (FMath::Abs(Offsets[i]) > KINDA_SMALL_NUMBER)
		{
			UMaterialExpressionConstant* OffConst = NewObject<UMaterialExpressionConstant>(M);
			OffConst->R = Offsets[i];
			UMaterialExpressionAdd* OffUV = NewObject<UMaterialExpressionAdd>(M);
			BaseUV->ConnectExpression(&OffUV->A, 0);
			OffConst->ConnectExpression(&OffUV->B, 0);
			OffUV->ConnectExpression(&TapTex->Coordinates, 0);
			M->GetExpressionCollection().AddExpression(OffConst);
			M->GetExpressionCollection().AddExpression(OffUV);
		}
		else
		{
			BaseUV->ConnectExpression(&TapTex->Coordinates, 0);
		}

		UMaterialExpressionConstant* WConst = NewObject<UMaterialExpressionConstant>(M);
		WConst->R = Weights[i];
		UMaterialExpressionMultiply* WeightedTap = NewObject<UMaterialExpressionMultiply>(M);
		TapTex->ConnectExpression(&WeightedTap->A, 0);
		WConst->ConnectExpression(&WeightedTap->B, 0);
		M->GetExpressionCollection().AddExpression(WConst);
		M->GetExpressionCollection().AddExpression(WeightedTap);

		if (!SumChain)
		{
			SumChain = WeightedTap;
		}
		else
		{
			UMaterialExpressionAdd* NextSum = NewObject<UMaterialExpressionAdd>(M);
			SumChain->ConnectExpression(&NextSum->A, 0);
			WeightedTap->ConnectExpression(&NextSum->B, 0);
			M->GetExpressionCollection().AddExpression(NextSum);
			SumChain = NextSum;
		}
	}

	UMaterialExpressionVectorParameter* TintP = NewObject<UMaterialExpressionVectorParameter>(M);
	TintP->SetParameterName(TEXT("BlurTint"));
	TintP->DefaultValue = FLinearColor(0.82f, 0.84f, 0.82f, 1.0f);
	UMaterialExpressionMultiply* TintedOut = NewObject<UMaterialExpressionMultiply>(M);
	SumChain->ConnectExpression(&TintedOut->A, 0);
	TintP->ConnectExpression(&TintedOut->B, 0);
	M->GetExpressionCollection().AddExpression(TintP);
	M->GetExpressionCollection().AddExpression(TintedOut);

	if (FExpressionInput* EmissiveInput = M->GetExpressionInputForProperty(EMaterialProperty::MP_EmissiveColor))
	{
		TintedOut->ConnectExpression(EmissiveInput, 0);
	}

	UMaterialExpressionScalarParameter* OpacityP = NewObject<UMaterialExpressionScalarParameter>(M);
	OpacityP->SetParameterName(TEXT("BlurOpacity"));
	OpacityP->DefaultValue = 0.48f;
	M->GetExpressionCollection().AddExpression(OpacityP);

	if (FExpressionInput* OpacityInput = M->GetExpressionInputForProperty(EMaterialProperty::MP_Opacity))
	{
		OpacityP->ConnectExpression(OpacityInput, 0);
	}

	M->PreEditChange(nullptr);
	M->PostEditChange();
	CachedHUDBlurMaterial = M;
	return M;
#else
	return nullptr;
#endif
}

UMaterialInterface* USquadAIAssetCacheSubsystem::GetPropMaterial(const FString& TextureKey, FLinearColor Tint, float UVScale)
{
	const FString CacheKey = TextureKey
		+ FString::Printf(TEXT("|%.3f,%.3f,%.3f|uv%.2f"), Tint.R, Tint.G, Tint.B, UVScale);   // S26-TEX3: scale is part of the identity
	// S26-TEX3: bare-metal keys shine a little; paint, cloth and rust do not
	static const auto PropMetallic = [](const FString& K) -> float
	{
		if (K == TEXT("MetalPlate") || K == TEXT("CommsPanel")) { return 0.30f; }
		if (K == TEXT("ScorchedMetal")) { return 0.35f; }
		if (K == TEXT("OliveArmor"))    { return 0.15f; }
		if (K == TEXT("RustyBarrel"))   { return 0.10f; }
		return 0.f;
	};
	// S26-MAT2: the map's value type is TObjectPtr<UMaterialInterface> - Find()
	// returns TObjectPtr<UMaterialInterface>*, not UMaterialInterface**.
	if (TObjectPtr<UMaterialInterface>* Found = CachedPropMaterials.Find(CacheKey))
	{
		return *Found;
	}
	UMaterialInterface* Result = nullptr;
	if (UMaterial* Base = EnsurePropBaseMaterial())
	{
		// the texture: the imported asset first, the PNG in Content/Textures second
		UTexture2D* Tex = FSquadAIAssetHelper::LoadTextureSafe(
			*FString::Printf(TEXT("/Game/Textures/SquadAI/%s.%s"), *TextureKey, *TextureKey),
			*FString::Printf(TEXT("Textures/SquadAI/%s.png"), *TextureKey));
		UTexture2D* GrimeTex = FSquadAIAssetHelper::LoadTextureSafe(
			TEXT("/Game/Textures/SquadAI/Grime.Grime"), TEXT("Textures/SquadAI/Grime.png"));   // S26-SURF
		UTexture2D* Norm = FSquadAIAssetHelper::LoadNormalTextureSafe(
			*FString::Printf(TEXT("/Game/Textures/SquadAI/%s_N.%s_N"), *TextureKey, *TextureKey),
			*FString::Printf(TEXT("Textures/SquadAI/%s_N.png"), *TextureKey));   // S26-BUMP
		if (!Norm)
		{
			Norm = FSquadAIAssetHelper::LoadNormalTextureSafe(
				TEXT("/Game/Textures/SquadAI/FlatNormal.FlatNormal"), TEXT("Textures/SquadAI/FlatNormal.png"));
		}
		UTexture2D* Rough = FSquadAIAssetHelper::LoadLinearTextureSafe(
			*FString::Printf(TEXT("/Game/Textures/SquadAI/%s_R.%s_R"), *TextureKey, *TextureKey),
			*FString::Printf(TEXT("Textures/SquadAI/%s_R.png"), *TextureKey));   // S26-TEX2
		if (!Rough)
		{
			Rough = FSquadAIAssetHelper::LoadLinearTextureSafe(
				TEXT("/Game/Textures/SquadAI/FlatRough.FlatRough"), TEXT("Textures/SquadAI/FlatRough.png"));
		}

		// S26-FIXALL: no more GRAY props, ever. The base material's Tex slot has
		// no default, so a null albedo sample reads as flat 0.5 gray and drowns
		// the tint. When the key's albedo is missing from the project, fall
		// back to the flat near-white roughness sheet (0.85) - the tint still
		// reads as paint instead of a dead gray slab. Warn ONCE per key.
		if (!Tex)
		{
			UE_LOG(LogTemp, Warning,
				TEXT("[SquadAIAssetCache] albedo '%s' NOT FOUND - looked for /Game/Textures/SquadAI/%s and Content/Textures/SquadAI/%s.png. Falling back to the flat white sheet; copy the SquadAI texture pack into the project for full detail."),
				*TextureKey, *TextureKey, *TextureKey);
			Tex = Rough;   // FlatRough (flat 0.85) = near-white albedo
			if (!Tex)
				{
					// even the flat sheet is missing: the ENGINE's own white square,
					// so a project with no SquadAI textures at all still reads tints
					// instead of dead gray
					Tex = LoadObject<UTexture2D>(nullptr, TEXT("/Engine/EngineResources/WhiteSquareTexture.WhiteSquareTexture"));
				}
		}

#if WITH_EDITOR
		// S26-KEEP: in the EDITOR the per-prop material is a SAVED ASSET, not a
		// MID. A MID lives only in memory - press AutoScatter, save the level,
		// reload, and every stamped prop showed "no material set" with the gray
		// checkerboard; a packaged build cooked the same hole. A material
		// instance constant on disk survives save, reload, AND cooking.
		if (GetWorld() && !GetWorld()->IsGameWorld())
		{
			const FString ObjName = FString::Printf(TEXT("MI_SquadAI_%s_%08X"), *TextureKey, GetTypeHash(CacheKey));
			const FString PkgPath = FString::Printf(TEXT("/Game/Materials/SquadAI_Inst/%s"), *ObjName);
			if (UMaterialInstanceConstant* Found = LoadObject<UMaterialInstanceConstant>(nullptr, *(PkgPath + TEXT(".") + ObjName)))
			{
				Result = Found;   // an earlier press authored + saved it
			}
			else
			{
				UPackage* Pkg = CreatePackage(*PkgPath);
				if (UMaterialInstanceConstant* MIC = NewObject<UMaterialInstanceConstant>(Pkg, *ObjName,
					RF_Public | RF_Standalone | RF_Transactional))
				{
					MIC->Parent = Base;
					// S26-COMPILE: UMaterialInstanceConstant has NO Set*ParameterValue
					// members (those are MID-only) - write the serialized parameter
					// arrays directly. This IS the on-disk format; a fresh MIC with
					// filled arrays + PostEditChange renders and saves correctly.
					// S26-COMPILE2: UE 5.7 renamed the name field - these parameter
					// structs carry FMaterialParameterInfo ParameterInfo now;
					// ParameterName is gone (C2039). Same arrays, new member.
					auto SetScalar = [&MIC](const TCHAR* N, float V)
					{
						FMaterialParameterInfo Info; Info.Name = N;
						for (FScalarParameterValue& P : MIC->ScalarParameterValues)
						{
							if (P.ParameterInfo.Name == Info.Name) { P.ParameterValue = V; return; }
						}
						FScalarParameterValue P; P.ParameterInfo = Info; P.ParameterValue = V;
						MIC->ScalarParameterValues.Add(P);
					};
					auto SetVector = [&MIC](const TCHAR* N, const FLinearColor& V)
					{
						FMaterialParameterInfo Info; Info.Name = N;
						for (FVectorParameterValue& P : MIC->VectorParameterValues)
						{
							if (P.ParameterInfo.Name == Info.Name) { P.ParameterValue = V; return; }
						}
						FVectorParameterValue P; P.ParameterInfo = Info; P.ParameterValue = V;
						MIC->VectorParameterValues.Add(P);
					};
					auto SetTexture = [&MIC](const TCHAR* N, UTexture* V)
					{
						FMaterialParameterInfo Info; Info.Name = N;
						if (!V) { return; }
						for (FTextureParameterValue& P : MIC->TextureParameterValues)
						{
							if (P.ParameterInfo.Name == Info.Name) { P.ParameterValue = V; return; }
						}
						FTextureParameterValue P; P.ParameterInfo = Info; P.ParameterValue = V;
						MIC->TextureParameterValues.Add(P);
					};
					SetTexture(TEXT("Tex"), Tex);
					SetTexture(TEXT("GrimeTex"), GrimeTex);
					SetTexture(TEXT("NormalTex"), Norm);
					SetTexture(TEXT("RoughTex"), Rough);
					SetVector(TEXT("Tint"), Tint);
					SetScalar(TEXT("UVScale"), FMath::Max(UVScale, 0.01f));
					SetScalar(TEXT("Metal"), PropMetallic(TextureKey));
					MIC->PostEditChange();   // bake the overrides into the render proxy now
					FAssetRegistryModule::AssetCreated(MIC);
					const FString FileName = FPackageName::LongPackageNameToFilename(
						PkgPath, FPackageName::GetAssetPackageExtension());
					if (UPackage::SavePackage(Pkg, MIC, *FileName, FSavePackageArgs()))
					{
						UE_LOG(LogTemp, Log, TEXT("[SquadAIAssetCache] S26-KEEP: saved %s (survives level save + reload)."), *PkgPath);
					}
					Result = MIC;
				}
			}
		}
		else
#endif
		if (UMaterialInstanceDynamic* MID = UMaterialInstanceDynamic::Create(Base, this))
		{
			if (Tex)      { MID->SetTextureParameterValue(TEXT("Tex"), Tex); }
			if (GrimeTex) { MID->SetTextureParameterValue(TEXT("GrimeTex"), GrimeTex); }
			if (Norm)     { MID->SetTextureParameterValue(TEXT("NormalTex"), Norm); }
			if (Rough)    { MID->SetTextureParameterValue(TEXT("RoughTex"), Rough); }
			MID->SetVectorParameterValue(TEXT("Tint"), Tint);
			// S26-TEX3: tiling for big surfaces + the key's metallic
			MID->SetScalarParameterValue(TEXT("UVScale"), FMath::Max(UVScale, 0.01f));
			MID->SetScalarParameterValue(TEXT("Metal"), PropMetallic(TextureKey));
			Result = MID;
		}
	}
	if (!Result)
	{
		UE_LOG(LogTemp, Verbose, TEXT("[SquadAIAssetCache] S26-MAT: no prop material for '%s' - caller falls back to its tint."), *TextureKey);
	}
	CachedPropMaterials.Add(CacheKey, Result);
	return Result;
}

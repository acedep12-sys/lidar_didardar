// SquadAIPlayerDiagnosticSubsystem.cpp — Player setup: wall-check fix + combat bridge (always); weapon diagnostic (dev only)
// PERFORMANCE: After setup is complete, only ticks every 5s to reapply wall-check fix.
#include "Performance/SquadAIPlayerDiagnosticSubsystem.h"
#include "Performance/SquadAIPlayerWeaponDiagnostic.h"
#include "Performance/SquadAIPlayerCombatBridge.h"
// S27-FP
#include "Components/SquadAIFirstPersonComponent.h"
#include "GameFramework/Pawn.h"
#include "GameFramework/PlayerController.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/World.h"
#include "TimerManager.h"
#include "UObject/UnrealType.h"
// S14-NAVDIAG
#include "NavigationSystem.h"
#include "NavMesh/RecastNavMesh.h"
#include "EngineUtils.h"
// S14-GHOST
#include "Characters/SoldierCharacter.h"
#include "AI/SoldierAIController.h"
#include "Components/HealthComponent.h"
#include "Components/StateTreeAIComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "GameFramework/CharacterMovementComponent.h"

void USquadAIPlayerDiagnosticSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
	bFixApplied = false;
	bDiagnosticAttached = false;
	bCombatBridgeAttached = false;
	bFirstPersonAttached = false; // S27-FP
	bSetupComplete = false;
	FixReapplyTimer = 0.f;
	TickThrottleTimer = 0.f;
#if !(UE_BUILD_DEBUG || UE_BUILD_DEVELOPMENT)
	// P1-2: no diagnostic component in Test/Shipping — mark done so setup can complete.
	bDiagnosticAttached = true;
#endif
}

void USquadAIPlayerDiagnosticSubsystem::Deinitialize()
{
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(WallFixTimer);
	}
	Super::Deinitialize();
}

bool USquadAIPlayerDiagnosticSubsystem::IsTickable() const
{
	return bAutoAttachDiagnostic && !bSetupComplete;
}

// Find the TPWCS weapon component on the player
static UObject* FindPlayerWeaponComp(AActor* Owner)
{
	if (!Owner) return nullptr;
	TArray<UActorComponent*> Comps;
	Owner->GetComponents(Comps);
	for (UActorComponent* C : Comps)
	{
		if (!C) continue;
		const FString N = C->GetName();
		const FString CN = C->GetClass() ? C->GetClass()->GetName() : FString();
		if (N.Contains(TEXT("BPC_WeaponCharacterPlayer")) || CN.Contains(TEXT("BPC_WeaponCharacterPlayer")) ||
			N.Contains(TEXT("BPC_WeaponCharacter")) || CN.Contains(TEXT("BPC_WeaponCharacter")))
		{
			return C;
		}
	}
	return nullptr;
}

// Force-set a bool property on the weapon component, trying multiple name candidates
static bool ForceSetBoolProperty(UObject* Obj, const TArray<FName>& Names, bool bValue, const TCHAR* DebugReason)
{
	if (!Obj) return false;
	for (const FName& N : Names)
	{
		if (FBoolProperty* P = FindFProperty<FBoolProperty>(Obj->GetClass(), N))
		{
			const bool bCurrent = P->GetPropertyValue_InContainer(Obj);
			if (bCurrent != bValue)
			{
				P->SetPropertyValue_InContainer(Obj, bValue);
				UE_LOG(LogTemp, Warning, TEXT("[PlayerWeaponFix] %s::%s: %d -> %d (%s)"),
					*GetNameSafe(Obj), *N.ToString(), bCurrent ? 1 : 0, bValue ? 1 : 0, DebugReason);
			}
			return true;
		}
	}
	return false;
}

void USquadAIPlayerDiagnosticSubsystem::ReapplyWallFix()
{
	APawn* PlayerPawn = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	if (!PlayerPawn) return;

	UObject* WeaponComp = FindPlayerWeaponComp(PlayerPawn);
	if (!WeaponComp) return;

	const bool bFoundIgnore = ForceSetBoolProperty(WeaponComp, {
		TEXT("bIgnoreCloseWallCheck?"),
		TEXT("Ignore Close Wall Check"),
		TEXT("IgnoreCloseWallCheck"),
		TEXT("bIgnoreCloseWallCheck")
	}, true, TEXT("Open World wall-check fix"));

	ForceSetBoolProperty(WeaponComp, {
		TEXT("bIsTooCloseToWall?"),
		TEXT("Is Too Close To Wall?"),
		TEXT("IsTooCloseToWall"),
		TEXT("bIsTooCloseToWall"),
		TEXT("TooCloseToWall"),
		TEXT("bTooCloseToWall")
	}, false, TEXT("Clear blocking flag"));

	if (bFoundIgnore) bFixApplied = true;
}

void USquadAIPlayerDiagnosticSubsystem::StartWallFixTimer()
{
	UWorld* World = GetWorld();
	if (!World || WallFixTimer.IsValid())
	{
		return;
	}
	World->GetTimerManager().SetTimer(WallFixTimer, this, &USquadAIPlayerDiagnosticSubsystem::ReapplyWallFix, 5.f, true);
}

// S19-PIECOMBATGATE: the menu's generic DefaultPawn is not a combat player.
void USquadAIPlayerDiagnosticSubsystem::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (!bAutoAttachDiagnostic) return;
	if (!GetWorld()) return;

	// This setup only needs a small number of checks per second while waiting for
	// the real gameplay pawn to appear; avoid a per-frame scan in menu PIE.
	TickThrottleTimer += FMath::Max(0.f, DeltaTime);
	if (TickThrottleTimer < 0.25f) return;
	TickThrottleTimer = 0.f;

	APawn* PlayerPawn = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	if (!PlayerPawn) return;

	const bool bNativeSoldier = Cast<ASoldierCharacter>(PlayerPawn) != nullptr;
	if (!bNativeSoldier && !FindPlayerWeaponComp(PlayerPawn))
	{
		// DefaultPawn_0 / spectator pawns in menu PIE have neither a soldier
		// health model nor the pack player's weapon component. Do not bolt combat
		// and development diagnostics onto them.
		return;
	}

	// S14-NAVDIAG: schedule the runtime navmesh census - first shot at 12 s
	// (dynamic generation has had time to produce tiles), then every 60 s so
	// growth/loss over a session is visible in the log.
	if (!bNavCensusScheduled)
	{
		bNavCensusScheduled = true;
		GetWorld()->GetTimerManager().SetTimer(NavCensusTimer, this,
			&USquadAIPlayerDiagnosticSubsystem::LogNavmeshCensus, 60.f, true, 12.f);
		// S14-GHOST: hostile census every 20 s — pinpoints "phantom" HUD
		// hostiles (count climbs, map looks empty).
		GetWorld()->GetTimerManager().SetTimer(GhostCensusTimer, this,
			&USquadAIPlayerDiagnosticSubsystem::LogHostileCensus, 20.f, true, 20.f);
	}

	ReapplyWallFix();

	// P1-2: COMBAT BRIDGE first — core gameplay (player damage dealing) attaches in ALL
	// builds and no longer waits on/derives from the diagnostic path.
	if (!bCombatBridgeAttached)
	{
		if (PlayerPawn->FindComponentByClass<USquadAIPlayerCombatBridge>())
		{
			bCombatBridgeAttached = true;
		}
		else
		{
			USquadAIPlayerCombatBridge* CombatBridge = NewObject<USquadAIPlayerCombatBridge>(PlayerPawn, TEXT("PlayerCombatBridge"));
			if (CombatBridge)
			{
				CombatBridge->RegisterComponent();
				PlayerPawn->AddInstanceComponent(CombatBridge);
				bCombatBridgeAttached = true;
				UE_LOG(LogTemp, Warning, TEXT("[PlayerCombat] Auto-attached combat bridge to player: %s"), *GetNameSafe(PlayerPawn));
			}
		}
	}

#if UE_BUILD_DEBUG || UE_BUILD_DEVELOPMENT
	// === DIAGNOSTIC: dev-only auto-attach (one-time, skip if already done) ===
	if (!bDiagnosticAttached)
	{
		if (PlayerPawn->FindComponentByClass<USquadAIPlayerWeaponDiagnostic>())
		{
			bDiagnosticAttached = true;
		}
		else
		{
			USquadAIPlayerWeaponDiagnostic* Diag = NewObject<USquadAIPlayerWeaponDiagnostic>(PlayerPawn, TEXT("PlayerWeaponDiag"));
			if (Diag)
			{
				Diag->RegisterComponent();
				PlayerPawn->AddInstanceComponent(Diag);
				bDiagnosticAttached = true;
				UE_LOG(LogTemp, Warning, TEXT("[PlayerWeaponFix] Auto-attached diagnostic to player: %s"), *GetNameSafe(PlayerPawn));
			}
		}
	}
#endif

	// Mark setup complete so the engine stops ticking this subsystem.
	// Native SquadAI soldiers have no pack wall-check property, so they need no
	// recurring wall-fix timer; pack pawns get that timer only if the fix applied.
	if ((bFixApplied || bNativeSoldier) && bDiagnosticAttached && bCombatBridgeAttached)
	{
		bSetupComplete = true;
		if (bFixApplied) StartWallFixTimer();
	}
}

// S14-NAVDIAG: prints what the running GAME actually holds for navigation,
// independent of anything the editor claims. Reads: how many nav data actors
// exist (must be exactly 1), each one's runtime-generation mode (the ACTOR's
// value - this is what overrides Project Settings), its live tile count
// (0 = no navmesh anywhere, growing = dynamic build working), the number of
// registered NavMeshBoundsVolumes (0 = bounds streamed out or missing), and
// whether the ground under the player projects onto navmesh at all.
void USquadAIPlayerDiagnosticSubsystem::LogNavmeshCensus()
{
	UWorld* World = GetWorld();
	if (!World) return;

	UNavigationSystemV1* NavSys = FNavigationSystem::GetCurrent<UNavigationSystemV1>(World);
	if (!NavSys)
	{
		UE_LOG(LogTemp, Warning, TEXT("[SquadAI][NavCensus] NO NavigationSystem in world %s"), *GetNameSafe(World));
		return;
	}

	const ANavigationData* DefaultNavData = NavSys->GetDefaultNavDataInstance(FNavigationSystem::DontCreate);
	const int32 BoundsCount = NavSys->GetNavigationBounds().Num();

	int32 Count = 0;
	for (TActorIterator<ARecastNavMesh> It(World); It; ++It)
	{
		ARecastNavMesh* NM = *It;
		if (!NM) continue;
		Count++;
		const ERuntimeGenerationType Gen = NM->GetRuntimeGenerationMode();
		const TCHAR* GenStr =
			Gen == ERuntimeGenerationType::Dynamic ? TEXT("Dynamic") :
			Gen == ERuntimeGenerationType::DynamicModifiersOnly ? TEXT("DynamicModifiersOnly") :
			Gen == ERuntimeGenerationType::Static ? TEXT("Static") : TEXT("Legacy");
		UE_LOG(LogTemp, Warning, TEXT("[SquadAI][NavCensus] #%d %s: RuntimeGeneration=%s Tiles=%d IsDefault=%s"),
			Count, *GetNameSafe(NM), GenStr, NM->GetNavMeshTilesCount(),
			(NM == DefaultNavData) ? TEXT("YES") : TEXT("no"));
	}

	FString PlayerProj = TEXT("n/a");
	if (APawn* P = UGameplayStatics::GetPlayerPawn(World, 0))
	{
		FNavLocation Out;
		PlayerProj = NavSys->ProjectPointToNavigation(P->GetActorLocation(), Out, FVector(500.f, 500.f, 1000.f)) ? TEXT("YES") : TEXT("NO");
	}

	UE_LOG(LogTemp, Warning, TEXT("[SquadAI][NavCensus] NavDataActors=%d NavBoundsVolumes=%d NavmeshUnderPlayer=%s"),
		Count, BoundsCount, *PlayerProj);
}

// =====================================================================
//  S14-GHOST — hostile census: WHERE is every counted hostile?
// =====================================================================
void USquadAIPlayerDiagnosticSubsystem::LogHostileCensus()
{
	UWorld* World = GetWorld();
	if (!World) return;

	APawn* PlayerPawn = UGameplayStatics::GetPlayerPawn(World, 0);
	const FVector PlayerLoc = PlayerPawn ? PlayerPawn->GetActorLocation() : FVector::ZeroVector;

	int32 Alive = 0, Dead = 0, Sleeping = 0, Logged = 0;
	for (TActorIterator<ASoldierCharacter> It(World); It; ++It)
	{
		ASoldierCharacter* S = *It;
		if (!S || !S->IsEnemy()) continue;

		const FVector Loc = S->GetActorLocation();
		const bool bPooledSleeper = Loc.Z < -9000.f; // pool parks at (0,0,-10000)
		if (bPooledSleeper) { Sleeping++; continue; }
		if (!S->IsAlive()) { Dead++; continue; }
		Alive++;

		if (Logged >= 30) continue; // cap spam; totals still counted
		Logged++;

		const ASoldierAIController* AIC = Cast<ASoldierAIController>(S->GetController());
		const USkeletalMeshComponent* Mesh = S->GetMesh();
		const UCharacterMovementComponent* CMC = S->GetCharacterMovement();
		UE_LOG(LogTemp, Warning,
			TEXT("[SquadAI][GhostCensus] %s pos=%s distToPlayer=%.0fm hiddenActor=%d meshVis=%d meshHidden=%d ctrl=%s stRunning=%d moveMode=%d hp=%.0f"),
			*S->GetName(), *Loc.ToCompactString(),
			PlayerPawn ? FVector::Dist(Loc, PlayerLoc) / 100.f : -1.f,
			S->IsHidden() ? 1 : 0,
			(Mesh && Mesh->IsVisible()) ? 1 : 0,
			(Mesh && Mesh->bHiddenInGame) ? 1 : 0,
			AIC ? *AIC->GetName() : TEXT("NONE"),
			(AIC && AIC->StateTreeComp && AIC->StateTreeComp->IsRunning()) ? 1 : 0,
			CMC ? static_cast<int32>(CMC->MovementMode.GetValue()) : -1,
			S->HealthComp ? S->HealthComp->CurrentHealth : -1.f);
	}

	UE_LOG(LogTemp, Warning, TEXT("[SquadAI][GhostCensus] TOTAL aliveEnemies=%d deadOnMap=%d pooledSleepers=%d (alive should match the HUD count)"),
		Alive, Dead, Sleeping);
}

#include "Performance/SquadAIAudioSubsystem.h"
#include "Actors/SquadAIAudioManager.h"
#include "SquadAITuning.h"
#include "Quest/MissionZone.h"
#include "Quest/QuestChain.h"
#include "Characters/SoldierCharacter.h"
#include "Components/HealthComponent.h"
#include "Performance/SoldierRegistrySubsystem.h"
#include "Kismet/GameplayStatics.h"
#include "Components/AudioComponent.h"
#include "Sound/SoundBase.h"
#include "Sound/SoundAttenuation.h"
#include "Engine/World.h"
#include "TimerManager.h"
#include "Camera/CameraShakeBase.h"
#include "Camera/PlayerCameraManager.h"
#include "GameFramework/PlayerController.h"

USquadAIAudioSubsystem::USquadAIAudioSubsystem()
{
}

void USquadAIAudioSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);

	UWorld* World = GetWorld();
	if (World && World->IsGameWorld())
	{
		TWeakObjectPtr<USquadAIAudioSubsystem> WeakThis(this);
		World->GetTimerManager().SetTimer(MusicTickTimerHandle, [WeakThis]()
		{
			if (WeakThis.IsValid())
			{
				WeakThis->Tick(0.05f);
			}
		}, 0.05f, true);

		// Schedule periodic distant artillery rumblings on the horizon (every 25-50s)
		World->GetTimerManager().SetTimer(DistantArtilleryTimerHandle, this, &USquadAIAudioSubsystem::TriggerDistantHorizonArtillery, 25.0f, false);

		SetAudioGameState(EAudioGameState::Exploration, nullptr, 3.0f);
	}
}

void USquadAIAudioSubsystem::Deinitialize()
{
	UWorld* World = GetWorld();
	if (World)
	{
		World->GetTimerManager().ClearTimer(MusicTickTimerHandle);
		World->GetTimerManager().ClearTimer(DuckTimerHandle);
		World->GetTimerManager().ClearTimer(DistantArtilleryTimerHandle);
	}

	if (PrimaryMusicComp) { PrimaryMusicComp->Stop(); PrimaryMusicComp = nullptr; }
	if (FadingMusicComp) { FadingMusicComp->Stop(); FadingMusicComp = nullptr; }
	if (StingerComp) { StingerComp->Stop(); StingerComp = nullptr; }
	if (HordeStemComp) { HordeStemComp->Stop(); HordeStemComp = nullptr; }
	if (DesertWindAudioComp) { DesertWindAudioComp->Stop(); DesertWindAudioComp = nullptr; }
	if (HeartbeatAudioComp) { HeartbeatAudioComp->Stop(); HeartbeatAudioComp = nullptr; }
	if (ActiveVoicelineComp) { ActiveVoicelineComp->Stop(); ActiveVoicelineComp = nullptr; }

	ActiveAudioManager = nullptr;
	CurrentActiveMission = nullptr;
	Super::Deinitialize();
}

void USquadAIAudioSubsystem::Tick(float DeltaTime)
{
	UpdateCrossfade(DeltaTime);
	UpdateHordeStemMixing(DeltaTime);
	EvaluateThreatsAndCooldown(DeltaTime);
	UpdateKhuzestanBattlefieldAmbience(DeltaTime);

	// Reset hardware voice rate limiters every 0.1s
	VoiceBudgetResetTimer += DeltaTime;
	if (VoiceBudgetResetTimer >= 0.1f)
	{
		VoiceBudgetResetTimer = 0.f;
		GunshotVoiceCounter = 0;
		ExplosionVoiceCounter = 0;
	}
}

USquadAIAudioSubsystem* USquadAIAudioSubsystem::Get(const UObject* WorldContextObject)
{
	if (!WorldContextObject) return nullptr;
	UWorld* World = GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::ReturnNull);
	return World ? World->GetSubsystem<USquadAIAudioSubsystem>() : nullptr;
}

void USquadAIAudioSubsystem::RegisterAudioManager(ASquadAIAudioManager* InManager)
{
	ActiveAudioManager = InManager;
	if (InManager)
	{
		UE_LOG(LogTemp, Warning, TEXT("[SquadAIAudio] Registered in-editor Audio Manager: %s"), *InManager->GetName());

		// Start desert wind ambience if assigned
		if (InManager->bEnableKhuzestanAtmosphere && InManager->DesertWindAmbience && GetWorld() && GetWorld()->IsGameWorld())
		{
			if (!DesertWindAudioComp)
			{
				DesertWindAudioComp = UGameplayStatics::SpawnSound2D(GetWorld(), InManager->DesertWindAmbience, 0.45f * SettingsMusicVolume * SettingsMasterVolume, 1.0f, 0.0f, nullptr, true, false);
				if (DesertWindAudioComp)
				{
					DesertWindAudioComp->bIsUISound = true;
					DesertWindAudioComp->Play();
				}
			}
		}

		SetAudioGameState(CurrentState, nullptr, InManager->MusicCrossfadeDuration);
	}
}

void USquadAIAudioSubsystem::SetAudioGameState(EAudioGameState NewState, USoundBase* CustomMusicOverride, float FadeDuration)
{
	CurrentState = NewState;

	USoundBase* MusicToPlay = CustomMusicOverride;
	if (!MusicToPlay)
	{
		MusicToPlay = ResolveDefaultTrackForState(NewState);
	}

	if (NewState == EAudioGameState::Victory)
	{
		USoundBase* Stinger = ActiveAudioManager.IsValid() ? ActiveAudioManager->VictoryStingerSound.Get() : nullptr;
		if (!Stinger)
		{
			const USquadAITuning* Tuning = USquadAITuning::Get();
			Stinger = Tuning ? Tuning->VictoryStingerSound.Get() : nullptr;
		}

		if (Stinger)
		{
			PlayStinger(Stinger, 0.30f, 3.5f);
		}

		SetHordeIntensity(0.0f, 0);
		CrossfadeMusic(ResolveDefaultTrackForState(EAudioGameState::Exploration), FadeDuration, 0.8f);
		return;
	}

	if (NewState == EAudioGameState::Defeat)
	{
		USoundBase* Stinger = ActiveAudioManager.IsValid() ? ActiveAudioManager->DefeatStingerSound.Get() : nullptr;
		if (!Stinger)
		{
			const USquadAITuning* Tuning = USquadAITuning::Get();
			Stinger = Tuning ? Tuning->DefeatStingerSound.Get() : nullptr;
		}

		if (Stinger)
		{
			PlayStinger(Stinger, 0.20f, 4.0f);
		}
		SetHordeIntensity(0.0f, 0);
		return;
	}

	if (MusicToPlay)
	{
		const float MasterVol = ActiveAudioManager.IsValid() ? ActiveAudioManager->MusicMasterVolume : 0.85f;
		float StateVol = 0.75f;
		if (NewState == EAudioGameState::Combat || NewState == EAudioGameState::DefendEarlyStage)
		{
			StateVol = 0.90f;
		}
		else if (NewState == EAudioGameState::CombatHorde || NewState == EAudioGameState::DefendClimax)
		{
			StateVol = 1.0f;
		}

		CrossfadeMusic(MusicToPlay, FadeDuration, StateVol * MasterVol);
	}
}

void USquadAIAudioSubsystem::CrossfadeMusic(USoundBase* NewMusic, float FadeDuration, float TargetVolume)
{
	if (!NewMusic || !GetWorld() || !GetWorld()->IsGameWorld()) return;

	if (PrimaryMusicComp && PrimaryMusicComp->Sound == NewMusic && PrimaryMusicComp->IsPlaying())
	{
		TargetMusicVolume = TargetVolume;
		return;
	}

	if (FadingMusicComp)
	{
		FadingMusicComp->Stop();
	}
	FadingMusicComp = PrimaryMusicComp;
	// P1-A3: capture the OLD absolute volume (fading from the new target made the old
	// track swell audibly whenever the new state was louder).
	CrossfadeStartVolume = FadingMusicComp ? FadingMusicComp->VolumeMultiplier : 0.f;

	PrimaryMusicComp = UGameplayStatics::SpawnSound2D(GetWorld(), NewMusic, 0.001f, 1.0f, 0.0f, nullptr, true, false);
	if (PrimaryMusicComp)
	{
		PrimaryMusicComp->bIsUISound = true;
		PrimaryMusicComp->bAutoDestroy = true;
		PrimaryMusicComp->Play();
	}

	TargetMusicVolume = TargetVolume;
	CrossfadeTotalDuration = FMath::Max(0.2f, FadeDuration);
	CrossfadeRemaining = CrossfadeTotalDuration;
	bIsCrossfading = true;
}

void USquadAIAudioSubsystem::PlayStinger(USoundBase* StingerSound, float DuckMusicMultiplier, float DuckDuration)
{
	if (!StingerSound || !GetWorld()) return;

	if (StingerComp)
	{
		StingerComp->Stop();
	}

	StingerComp = UGameplayStatics::SpawnSound2D(GetWorld(), StingerSound, 1.0f * SettingsSFXVolume * SettingsMasterVolume, 1.0f, 0.0f, nullptr, true, false);
	if (StingerComp)
	{
		StingerComp->bIsUISound = true;
		StingerComp->Play();
	}

	DuckMultiplier = FMath::Clamp(DuckMusicMultiplier, 0.05f, 1.0f);
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(DuckTimerHandle);
		World->GetTimerManager().SetTimer(DuckTimerHandle, this, &USquadAIAudioSubsystem::ResetDuckVolume, DuckDuration, false);
	}
}

void USquadAIAudioSubsystem::ResetDuckVolume()
{
	DuckMultiplier = 1.0f;
}

void USquadAIAudioSubsystem::StopMusic(float FadeOutDuration)
{
	if (PrimaryMusicComp) PrimaryMusicComp->FadeOut(FadeOutDuration, 0.0f);
	if (FadingMusicComp) FadingMusicComp->FadeOut(FadeOutDuration, 0.0f);
	if (HordeStemComp) HordeStemComp->FadeOut(FadeOutDuration, 0.0f);
}

void USquadAIAudioSubsystem::NotifyMissionStateChanged(AMissionZone* Mission, uint8 NewState)
{
	if (!Mission) return;
	CurrentActiveMission = Mission;

	EMissionZoneState State = static_cast<EMissionZoneState>(NewState);
	switch (State)
	{
	case EMissionZoneState::Active:
		PlayTacticalVoiceline(ETacticalVoicelineType::Radio_MissionStart, Mission);
		if (Mission->MissionType == EMissionType::Defend)
		{
			SetAudioGameState(EAudioGameState::DefendEarlyStage, Mission->CustomCombatMusic.Get(), 2.0f);
		}
		else if (Mission->MissionType == EMissionType::Clear)
		{
			SetAudioGameState(EAudioGameState::Combat, Mission->CustomCombatMusic.Get(), 2.0f);
		}
		else
		{
			SetAudioGameState(EAudioGameState::MissionActive, Mission->CustomAmbientMusic.Get(), 2.5f);
		}
		break;

	case EMissionZoneState::Completed:
		// P1-A1: state change owns the stinger (was: voiceline ALSO fired VictoryStinger = double-play).
		SetAudioGameState(EAudioGameState::Victory, nullptr, 2.0f);
		break;

	case EMissionZoneState::Failed:
		// P1-A1: state change owns the stinger (was: voiceline ALSO fired DefeatStinger = double-play).
		SetAudioGameState(EAudioGameState::Defeat, nullptr, 2.0f);
		break;

	case EMissionZoneState::Locked:
	default:
		SetAudioGameState(EAudioGameState::Exploration, nullptr, 3.0f);
		break;
	}
}

void USquadAIAudioSubsystem::NotifyMissionProgress(AMissionZone* Mission, float Progress, float TimeRemaining, int32 AliveEnemyCount)
{
	if (!Mission || Mission != CurrentActiveMission.Get()) return;

	if (Mission->MissionType == EMissionType::Defend)
	{
		float ClimaxThreshold = 20.f;
		if (ActiveAudioManager.IsValid())
		{
			ClimaxThreshold = ActiveAudioManager->DefendClimaxThresholdSeconds;
		}

		if (TimeRemaining > 0.f && TimeRemaining <= ClimaxThreshold)
		{
			if (CurrentState != EAudioGameState::DefendClimax)
			{
				USoundBase* ClimaxOverride = Mission->CustomClimaxMusic ? Mission->CustomClimaxMusic.Get() : nullptr;
				SetAudioGameState(EAudioGameState::DefendClimax, ClimaxOverride, 1.8f);
			}
		}
	}

	int32 HordeThresh = 7;
	if (ActiveAudioManager.IsValid())
	{
		HordeThresh = ActiveAudioManager->HordeEnemyThreshold;
	}

	const float Intensity = FMath::Clamp(static_cast<float>(AliveEnemyCount) / static_cast<float>(FMath::Max(1, HordeThresh)), 0.0f, 1.0f);
	SetHordeIntensity(Intensity, AliveEnemyCount);
}

void USquadAIAudioSubsystem::SetHordeIntensity(float InIntensity, int32 NearbyEnemyCount)
{
	TargetCombatIntensity = FMath::Clamp(InIntensity, 0.0f, 1.0f);

	if (TargetCombatIntensity > 0.05f)
	{
		CombatCooldownTimer = 6.0f;
	}

	USoundBase* HordeStemAsset = nullptr;
	if (CurrentActiveMission.IsValid() && CurrentActiveMission->CustomHordeStem)
	{
		HordeStemAsset = CurrentActiveMission->CustomHordeStem.Get();
	}
	else if (ActiveAudioManager.IsValid() && ActiveAudioManager->HordeCombatStem)
	{
		HordeStemAsset = ActiveAudioManager->HordeCombatStem.Get();
	}

	if (HordeStemAsset && GetWorld() && GetWorld()->IsGameWorld())
	{
		if (!HordeStemComp || HordeStemComp->Sound != HordeStemAsset || !HordeStemComp->IsPlaying())
		{
			if (HordeStemComp) HordeStemComp->Stop();

			HordeStemComp = UGameplayStatics::SpawnSound2D(GetWorld(), HordeStemAsset, 0.001f, 1.0f, 0.0f, nullptr, true, false);
			if (HordeStemComp)
			{
				HordeStemComp->bIsUISound = true;
				HordeStemComp->Play();
			}
		}
	}
}

void USquadAIAudioSubsystem::UpdateHordeStemMixing(float DeltaTime)
{
	CurrentCombatIntensity = FMath::FInterpTo(CurrentCombatIntensity, TargetCombatIntensity, DeltaTime, 1.5f);

	if (HordeStemComp && HordeStemComp->IsPlaying())
	{
		const float DesiredStemVol = (CurrentCombatIntensity > 0.35f) ? (CurrentCombatIntensity * TargetMusicVolume * DuckMultiplier) : 0.0f;
		HordeStemVolume = FMath::FInterpTo(HordeStemVolume, DesiredStemVol, DeltaTime, 2.0f);
		HordeStemComp->SetVolumeMultiplier(HordeStemVolume * SettingsMusicVolume * SettingsMasterVolume);

		if (HordeStemVolume <= 0.01f && TargetCombatIntensity <= 0.05f)
		{
			HordeStemComp->Stop();
			HordeStemComp = nullptr;
		}
	}
}

void USquadAIAudioSubsystem::EvaluateThreatsAndCooldown(float DeltaTime)
{
	if (CombatCooldownTimer > 0.0f)
	{
		CombatCooldownTimer -= DeltaTime;
		if (CombatCooldownTimer <= 0.0f && CurrentCombatIntensity <= 0.05f)
		{
			if (CurrentState == EAudioGameState::Combat || CurrentState == EAudioGameState::CombatHorde)
			{
				SetAudioGameState(EAudioGameState::Exploration, nullptr, 3.5f);
			}
		}
	}
}

void USquadAIAudioSubsystem::UpdateKhuzestanBattlefieldAmbience(float DeltaTime)
{
	APawn* Player = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	if (!Player) return;

	// 1. Low Health Heartbeat Effect (< 30% HP)
	float PlayerHealthPercent = 1.0f;
	if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(Player))
	{
		if (Soldier->HealthComp && Soldier->HealthComp->MaxHealth > 0.f)
		{
			PlayerHealthPercent = Soldier->HealthComp->CurrentHealth / Soldier->HealthComp->MaxHealth;
		}
	}

	if (ActiveAudioManager.IsValid() && ActiveAudioManager->LowHealthHeartbeat)
	{
		if (PlayerHealthPercent < 0.30f && PlayerHealthPercent > 0.0f)
		{
			if (!HeartbeatAudioComp || !HeartbeatAudioComp->IsPlaying())
			{
				HeartbeatAudioComp = UGameplayStatics::SpawnSound2D(GetWorld(), ActiveAudioManager->LowHealthHeartbeat, 0.8f * SettingsSFXVolume * SettingsMasterVolume, 1.0f, 0.0f, nullptr, true, false);
				if (HeartbeatAudioComp)
				{
					HeartbeatAudioComp->bIsUISound = true;
					HeartbeatAudioComp->Play();
				}
			}
		}
		else if (HeartbeatAudioComp && HeartbeatAudioComp->IsPlaying())
		{
			HeartbeatAudioComp->FadeOut(1.5f, 0.0f);
			HeartbeatAudioComp = nullptr;
		}
	}
}

void USquadAIAudioSubsystem::PlayTacticalVoiceline(ETacticalVoicelineType VoicelineType, AActor* SpeakerActor)
{
	UWorld* World = GetWorld();
	if (!World || !World->IsGameWorld()) return;
	// P1-A2: no manager → tuning fallback for stinger-backed radio types (mirrors music
	// fallback); other types have no tuning assets and stay silent.
	if (!ActiveAudioManager.IsValid())
	{
		const USquadAITuning* Tuning = USquadAITuning::Get();
		USoundBase* Fallback = nullptr;
		if (VoicelineType == ETacticalVoicelineType::Radio_MissionSuccess) Fallback = Tuning ? Tuning->VictoryStingerSound.Get() : nullptr;
		else if (VoicelineType == ETacticalVoicelineType::Radio_MissionFail) Fallback = Tuning ? Tuning->DefeatStingerSound.Get() : nullptr;
		if (Fallback)
		{
			UGameplayStatics::PlaySound2D(World, Fallback, SettingsVoiceVolume * SettingsMasterVolume);
		}
		return;
	}

	const float Now = World->GetTimeSeconds();

	// Anti-Spam Cooldown & Priority Checks
	switch (VoicelineType)
	{
	case ETacticalVoicelineType::Ally_EnemySpotted:
		if (Now - LastContactVoicelineTime < 5.0f) return;
		LastContactVoicelineTime = Now;
		break;

	case ETacticalVoicelineType::Ally_UnderFire:
		if (Now - LastUnderFireVoicelineTime < 4.0f) return;
		LastUnderFireVoicelineTime = Now;
		break;

	case ETacticalVoicelineType::Ally_Reloading:
		if (Now - LastReloadVoicelineTime < 6.0f) return;
		LastReloadVoicelineTime = Now;
		break;

	case ETacticalVoicelineType::Ally_IncomingGrenade:
		if (Now - LastMortarWarningVoicelineTime < 3.0f) return;
		LastMortarWarningVoicelineTime = Now;
		break;

	case ETacticalVoicelineType::Ally_ManDown:
		if (Now - LastManDownVoicelineTime < 4.0f) return;
		LastManDownVoicelineTime = Now;
		break;

	case ETacticalVoicelineType::Ally_Healing: // MEGA-5 (G-11): dedicated medic callout.
		if (Now - LastHealingVoicelineTime < 4.0f) return;
		LastHealingVoicelineTime = Now;
		break;

	case ETacticalVoicelineType::Ally_KillConfirmed:
		if (Now - LastKillConfirmedVoicelineTime < 4.0f) return;
		LastKillConfirmedVoicelineTime = Now;
		break;

	case ETacticalVoicelineType::Ally_Flanking:
		if (Now - LastFlankingVoicelineTime < 6.0f) return;
		LastFlankingVoicelineTime = Now;
		break;

	case ETacticalVoicelineType::Ally_Victory:
		break;

	case ETacticalVoicelineType::Leader_OrderMove:
	case ETacticalVoicelineType::Leader_OrderEngage:
		if (Now - LastOrderVoicelineTime < 4.5f) return;
		LastOrderVoicelineTime = Now;
		break;

	case ETacticalVoicelineType::Enemy_Alerted:
	case ETacticalVoicelineType::Enemy_CombatBark:
		if (Now - LastEnemyBarkVoicelineTime < 3.5f) return;
		LastEnemyBarkVoicelineTime = Now;
		break;

	default:
		break;
	}

	USoundBase* SelectedVoiceline = nullptr;
	bool bPlayAs2DRadio = false;

	switch (VoicelineType)
	{
	case ETacticalVoicelineType::Radio_MissionStart:
		SelectedVoiceline = ActiveAudioManager->TacticalRadioClick ? ActiveAudioManager->TacticalRadioClick.Get() : nullptr;
		bPlayAs2DRadio = true;
		break;

	case ETacticalVoicelineType::Radio_MissionSuccess:
		SelectedVoiceline = ActiveAudioManager->VictoryStingerSound ? ActiveAudioManager->VictoryStingerSound.Get() : nullptr;
		bPlayAs2DRadio = true;
		break;

	case ETacticalVoicelineType::Radio_MissionFail:
		SelectedVoiceline = ActiveAudioManager->DefeatStingerSound ? ActiveAudioManager->DefeatStingerSound.Get() : nullptr;
		bPlayAs2DRadio = true;
		break;

	case ETacticalVoicelineType::Ally_EnemySpotted:
		SelectedVoiceline = PickRandomSoundFromArray(ActiveAudioManager->AllyEnemySpottedVoicelines);
		break;

	case ETacticalVoicelineType::Ally_UnderFire:
		SelectedVoiceline = PickRandomSoundFromArray(ActiveAudioManager->AllyUnderFireVoicelines);
		break;

	case ETacticalVoicelineType::Ally_Reloading:
		SelectedVoiceline = PickRandomSoundFromArray(ActiveAudioManager->AllyReloadingVoicelines);
		break;

	case ETacticalVoicelineType::Ally_IncomingGrenade:
		SelectedVoiceline = PickRandomSoundFromArray(ActiveAudioManager->AllyIncomingGrenadeVoicelines);
		break;

	case ETacticalVoicelineType::Ally_ManDown:
		SelectedVoiceline = PickRandomSoundFromArray(ActiveAudioManager->AllyManDownVoicelines);
		break;

	case ETacticalVoicelineType::Ally_Healing:
		SelectedVoiceline = PickRandomSoundFromArray(ActiveAudioManager->AllyHealingVoicelines);
		break;

	case ETacticalVoicelineType::Ally_KillConfirmed:
		SelectedVoiceline = PickRandomSoundFromArray(ActiveAudioManager->AllyKillConfirmedVoicelines);
		break;

	case ETacticalVoicelineType::Ally_Flanking:
		SelectedVoiceline = PickRandomSoundFromArray(ActiveAudioManager->AllyFlankingVoicelines);
		break;

	case ETacticalVoicelineType::Ally_Victory:
		SelectedVoiceline = PickRandomSoundFromArray(ActiveAudioManager->AllyKillConfirmedVoicelines);
		break;

	case ETacticalVoicelineType::Leader_OrderMove:
		SelectedVoiceline = PickRandomSoundFromArray(ActiveAudioManager->LeaderOrderMoveVoicelines);
		break;

	case ETacticalVoicelineType::Leader_OrderEngage:
		SelectedVoiceline = PickRandomSoundFromArray(ActiveAudioManager->LeaderOrderEngageVoicelines);
		break;

	case ETacticalVoicelineType::Command_Hold: // F-C1: deleted 2nd identical case (duplicate-case hard compile error).
		// Dedicated array with fallback: works with no asset wired (designer fills it later).
		SelectedVoiceline = PickRandomSoundFromArray(ActiveAudioManager->CommandHoldVoicelines);
		if (!SelectedVoiceline)
		{
			SelectedVoiceline = PickRandomSoundFromArray(ActiveAudioManager->LeaderOrderMoveVoicelines);
		}
		break;

	case ETacticalVoicelineType::Enemy_Alerted:
		SelectedVoiceline = PickRandomSoundFromArray(ActiveAudioManager->EnemyAlertedVoicelines);
		break;

	case ETacticalVoicelineType::Enemy_CombatBark:
		SelectedVoiceline = PickRandomSoundFromArray(ActiveAudioManager->EnemyCombatBarks);
		break;

	default:
		break;
	}

	if (!SelectedVoiceline) return;

	if (bPlayAs2DRadio || !SpeakerActor)
	{
		UGameplayStatics::PlaySound2D(World, SelectedVoiceline, SettingsVoiceVolume * SettingsMasterVolume);
	}
	else
	{
		UGameplayStatics::PlaySoundAtLocation(World, SelectedVoiceline, SpeakerActor->GetActorLocation(), SettingsVoiceVolume * SettingsMasterVolume, 1.0f, 0.0f, ActiveAudioManager->GunshotAttenuationSettings.Get());
	}
}

void USquadAIAudioSubsystem::TriggerDistantHorizonArtillery()
{
	UWorld* World = GetWorld();
	if (!World || !World->IsGameWorld()) return;

	APawn* Player = UGameplayStatics::GetPlayerPawn(World, 0);
	if (Player && ActiveAudioManager.IsValid() && ActiveAudioManager->bEnableKhuzestanAtmosphere)
	{
		USoundBase* RumbleSnd = ActiveAudioManager->DistantArtilleryRumble ? ActiveAudioManager->DistantArtilleryRumble.Get() : ActiveAudioManager->LargeExplosionDistantSound.Get();
		if (RumbleSnd)
		{
			const float Angle = FMath::FRandRange(0.f, 2.f * PI);
			const float Dist = FMath::FRandRange(18000.f, 32000.f);
			const FVector RumbleLoc = Player->GetActorLocation() + FVector(FMath::Cos(Angle) * Dist, FMath::Sin(Angle) * Dist, 500.f);

			PlaySpatialSoundWithDistanceLayers(nullptr, RumbleSnd, RumbleLoc, 2500.f, 50000.f, true, 0.7f);
		}
	}

	const float NextInterval = FMath::FRandRange(25.0f, 50.0f);
	World->GetTimerManager().SetTimer(DistantArtilleryTimerHandle, this, &USquadAIAudioSubsystem::TriggerDistantHorizonArtillery, NextInterval, false);
}

void USquadAIAudioSubsystem::UpdateCrossfade(float DeltaTime)
{
	if (bIsCrossfading)
	{
		CrossfadeRemaining -= DeltaTime;
		const float Alpha = 1.0f - FMath::Clamp(CrossfadeRemaining / CrossfadeTotalDuration, 0.0f, 1.0f);

		if (PrimaryMusicComp)
		{
			const float VolIn = Alpha * TargetMusicVolume * DuckMultiplier * SettingsMusicVolume * SettingsMasterVolume;
			PrimaryMusicComp->SetVolumeMultiplier(VolIn);
		}

		if (FadingMusicComp)
		{
			const float VolOut = (1.0f - Alpha) * CrossfadeStartVolume; // P1-A3: fade from captured old volume, not the new target.
			FadingMusicComp->SetVolumeMultiplier(VolOut);
		}

		if (CrossfadeRemaining <= 0.0f)
		{
			bIsCrossfading = false;
			if (FadingMusicComp)
			{
				FadingMusicComp->Stop();
				FadingMusicComp = nullptr;
			}
		}
	}
	else
	{
		if (PrimaryMusicComp)
		{
			const float CurrentVol = PrimaryMusicComp->VolumeMultiplier;
			const float DesiredVol = TargetMusicVolume * DuckMultiplier * SettingsMusicVolume * SettingsMasterVolume;
			PrimaryMusicComp->SetVolumeMultiplier(FMath::FInterpTo(CurrentVol, DesiredVol, DeltaTime, 4.0f));
		}
	}
}

void USquadAIAudioSubsystem::ApplyVolumeSettings(float Master, float Music, float SFX, float Voice)
{
	SettingsMasterVolume = FMath::Clamp(Master, 0.f, 1.f);
	SettingsMusicVolume = FMath::Clamp(Music, 0.f, 1.f);
	SettingsSFXVolume = FMath::Clamp(SFX, 0.f, 1.f);
	SettingsVoiceVolume = FMath::Clamp(Voice, 0.f, 1.f);
}

void USquadAIAudioSubsystem::PlaySpatialSoundWithDistanceLayers(
	USoundBase* CloseSound,
	USoundBase* DistantSound,
	FVector WorldLocation,
	float CloseRadius,
	float DistantRadius,
	bool bSimulateSpeedOfSound,
	float VolumeMultiplier,
	USoundAttenuation* AttenuationSettings)
{
	UWorld* World = GetWorld();
	if (!World) return;

	// B6-9: settings mix for all spatial SFX.
	VolumeMultiplier *= SettingsSFXVolume * SettingsMasterVolume;

	APlayerCameraManager* CamManager = UGameplayStatics::GetPlayerCameraManager(World, 0);
	APawn* PlayerPawn = UGameplayStatics::GetPlayerPawn(World, 0);
	const FVector ListenerLoc = CamManager ? CamManager->GetCameraLocation() : (PlayerPawn ? PlayerPawn->GetActorLocation() : FVector::ZeroVector);

	const float Distance = FVector::Dist(WorldLocation, ListenerLoc);

	float MaxAudibleDist = DistantRadius;
	if (ActiveAudioManager.IsValid())
	{
		MaxAudibleDist = FMath::Min(DistantRadius, ActiveAudioManager->MaxAudibleDistance);
	}

	if (Distance > MaxAudibleDist)
	{
		return;
	}

	if (GunshotVoiceCounter >= 8 && Distance > 1500.f)
	{
		return;
	}
	GunshotVoiceCounter++;

	float SoundVelocity = 34300.0f;
	bool bSpeedOfSound = bSimulateSpeedOfSound;
	if (ActiveAudioManager.IsValid())
	{
		SoundVelocity = ActiveAudioManager->SpeedOfSoundVelocity;
		bSpeedOfSound = ActiveAudioManager->bSimulateSpeedOfSound;
	}

	const float Delay = (bSpeedOfSound && Distance > 1200.f) ? (Distance / FMath::Max(1000.f, SoundVelocity)) : 0.0f;

	USoundAttenuation* EffectiveAttenuation = AttenuationSettings;
	if (!EffectiveAttenuation && ActiveAudioManager.IsValid())
	{
		EffectiveAttenuation = ActiveAudioManager->GunshotAttenuationSettings.Get();
	}

	auto PlaySoundLambda = [World, CloseSound, DistantSound, WorldLocation, CloseRadius, MaxAudibleDist, Distance, VolumeMultiplier, EffectiveAttenuation]()
	{
		if (!World || !World->IsValidLowLevel()) return;

		const float BlendAlpha = FMath::Clamp((Distance - CloseRadius) / FMath::Max(1.0f, MaxAudibleDist - CloseRadius), 0.0f, 1.0f);
		const float CloseVol = (1.0f - BlendAlpha) * VolumeMultiplier;
		const float DistantVol = BlendAlpha * VolumeMultiplier;

		if (CloseSound && CloseVol > 0.03f)
		{
			UGameplayStatics::PlaySoundAtLocation(World, CloseSound, WorldLocation, CloseVol, 1.0f, 0.0f, EffectiveAttenuation);
		}

		if (DistantSound && DistantVol > 0.03f)
		{
			UGameplayStatics::PlaySoundAtLocation(World, DistantSound, WorldLocation, DistantVol, 1.0f, 0.0f, EffectiveAttenuation);
		}
		else if (!DistantSound && CloseSound && DistantVol > 0.03f)
		{
			UGameplayStatics::PlaySoundAtLocation(World, CloseSound, WorldLocation, DistantVol * 0.65f, 0.92f, 0.0f, EffectiveAttenuation);
		}
	};

	if (Delay > 0.04f)
	{
		FTimerHandle SndDelayHandle;
		World->GetTimerManager().SetTimer(SndDelayHandle, FTimerDelegate::CreateLambda(PlaySoundLambda), Delay, false);
	}
	else
	{
		PlaySoundLambda();
	}
}

void USquadAIAudioSubsystem::TriggerExplosionConcussion(
	FVector ExplosionLocation,
	float InnerRadius,
	float OuterRadius,
	TSubclassOf<UCameraShakeBase> CameraShakeClass)
{
	UWorld* World = GetWorld();
	if (!World) return;

	APawn* PlayerPawn = UGameplayStatics::GetPlayerPawn(World, 0);
	if (!PlayerPawn) return;

	const float Distance = FVector::Dist(ExplosionLocation, PlayerPawn->GetActorLocation());
	if (Distance > OuterRadius) return;

	const float Intensity = 1.0f - FMath::Clamp((Distance - InnerRadius) / FMath::Max(1.0f, OuterRadius - InnerRadius), 0.0f, 1.0f);

	TSubclassOf<UCameraShakeBase> ShakeClass = CameraShakeClass;
	if (!ShakeClass && ActiveAudioManager.IsValid())
	{
		ShakeClass = ActiveAudioManager->ExplosionCameraShake;
	}

	if (ShakeClass)
	{
		if (APlayerController* PC = Cast<APlayerController>(PlayerPawn->GetController()))
		{
			PC->ClientStartCameraShake(ShakeClass, Intensity * 1.5f);
		}
	}

	if (Intensity > 0.35f)
	{
		DuckMultiplier = FMath::Lerp(0.5f, 0.15f, Intensity);
		World->GetTimerManager().ClearTimer(DuckTimerHandle);
		World->GetTimerManager().SetTimer(DuckTimerHandle, this, &USquadAIAudioSubsystem::ResetDuckVolume, 2.5f * Intensity, false);

		if (ActiveAudioManager.IsValid() && ActiveAudioManager->ConcussionTinnitusSound)
		{
			UGameplayStatics::PlaySound2D(World, ActiveAudioManager->ConcussionTinnitusSound, Intensity * 0.9f * SettingsSFXVolume * SettingsMasterVolume);
		}
	}
}

USoundBase* USquadAIAudioSubsystem::ResolveDefaultTrackForState(EAudioGameState State) const
{
	if (ActiveAudioManager.IsValid())
	{
		switch (State)
		{
		case EAudioGameState::Combat:
		case EAudioGameState::CombatHorde:
			if (ActiveAudioManager->CombatMusic) return ActiveAudioManager->CombatMusic.Get();
			if (ActiveAudioManager->CombatMusicPlaylist.Num() > 0)
			{
				return GetNextPlaylistTrack(ActiveAudioManager->CombatMusicPlaylist, const_cast<int32&>(CurrentCombatPlaylistIndex));
			}
			break;

		case EAudioGameState::DefendEarlyStage:
			if (ActiveAudioManager->DefendIntroMusic) return ActiveAudioManager->DefendIntroMusic.Get();
			if (ActiveAudioManager->CombatMusic) return ActiveAudioManager->CombatMusic.Get();
			break;

		case EAudioGameState::DefendClimax:
			if (ActiveAudioManager->DefendClimaxMusic) return ActiveAudioManager->DefendClimaxMusic.Get();
			if (ActiveAudioManager->CombatMusic) return ActiveAudioManager->CombatMusic.Get();
			break;

		case EAudioGameState::MissionActive:
		case EAudioGameState::Exploration:
		default:
			if (ActiveAudioManager->AmbientMusic) return ActiveAudioManager->AmbientMusic.Get();
			if (ActiveAudioManager->AmbientMusicPlaylist.Num() > 0)
			{
				return GetNextPlaylistTrack(ActiveAudioManager->AmbientMusicPlaylist, const_cast<int32&>(CurrentAmbientPlaylistIndex));
			}
			break;
		}
	}

	const USquadAITuning* Tuning = USquadAITuning::Get();
	if (!Tuning) return nullptr;

	switch (State)
	{
	case EAudioGameState::Combat:
	case EAudioGameState::CombatHorde:
		return Tuning->DefaultCombatMusic.Get();
	case EAudioGameState::DefendEarlyStage:
	case EAudioGameState::DefendClimax:
		return Tuning->DefaultDefendClimaxMusic ? Tuning->DefaultDefendClimaxMusic.Get() : Tuning->DefaultCombatMusic.Get();
	case EAudioGameState::MissionActive:
	case EAudioGameState::Exploration:
	default:
		return Tuning->DefaultAmbientMusic.Get();
	}
}

USoundBase* USquadAIAudioSubsystem::GetNextPlaylistTrack(const TArray<TObjectPtr<USoundBase>>& Playlist, int32& InOutIndex) const
{
	if (Playlist.Num() == 0) return nullptr;

	if (InOutIndex < 0 || InOutIndex >= Playlist.Num())
	{
		InOutIndex = 0;
	}

	USoundBase* Selected = Playlist[InOutIndex].Get();
	InOutIndex = (InOutIndex + 1) % Playlist.Num();
	return Selected;
}

USoundBase* USquadAIAudioSubsystem::PickRandomSoundFromArray(const TArray<TObjectPtr<USoundBase>>& SoundArray) const
{
	if (SoundArray.Num() == 0) return nullptr;
	const int32 Index = FMath::RandRange(0, SoundArray.Num() - 1);
	return SoundArray[Index].Get();
}

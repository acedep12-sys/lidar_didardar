// SquadAIPlayerCombatBridge.cpp — Custom damage system and tactical combat bridge
// Traces from player camera, detects enemy hits, applies damage, calls mortar fire support & guidance vision.
// Works with BOTH SquadAI ASoldierCharacter AND TPWCS pack enemies.
#include "Performance/SquadAIPlayerCombatBridge.h"
#include "Performance/SquadAIRecovery.h"   // S19-PACKHP
#include "Diagnostics/SquadAISituationLog.h"   // S19-LOGGER
#include "Performance/SquadAIDevDebugSubsystem.h"
#include "Characters/SoldierCharacter.h"
#include "Components/HealthComponent.h"
#include "Components/TacticalGrenadeComponent.h"
#include "Tactical/TacticalGrenadeActor.h"
#include "HUD/QuestNativeHUD.h"
#include "Tutorial/TutorialRangeActor.h" // S18-TUT
#include "Performance/SoldierRegistrySubsystem.h"
#include "Tactical/SquadAIFireSupportSubsystem.h"
#include "Tactical/SquadAIRadioChatterSubsystem.h"
#include "GameFramework/SquadAIInventorySubsystem.h"
#include "GameFramework/SquadAIProgressionSubsystem.h"
#include "Performance/SquadAIAudioSubsystem.h"
#include "GameFramework/PlayerController.h"
#include "GameFramework/PlayerInput.h"
#include "GameFramework/Pawn.h"
#include "GameFramework/Character.h"
#include "Components/SkeletalMeshComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Perception/AISense_Damage.h"
#include "Engine/World.h"
#include "HAL/PlatformTime.h"
#include "HAL/IConsoleManager.h"
#include "DrawDebugHelpers.h"

// S14-HIT: `SquadAI.DebugPlayerHits 1` logs every combat trace while firing -
// what the trace hit (actor/component/collision profile/bone/distance) and
// which damage path accepted or refused it. Companion to S11-DIAG's enemy-goal
// cvar; exists because "bullets do nothing" has three indistinguishable causes
// without it (trace misses, wrong faction, health path refuses).
static TAutoConsoleVariable<int32> CVarSquadAIDebugPlayerHits(
	TEXT("SquadAI.DebugPlayerHits"),
	0,
	TEXT("1 = log player combat trace hits and damage-path decisions."),
	ECVF_Cheat);
#include "UObject/UnrealType.h"

USquadAIPlayerCombatBridge::USquadAIPlayerCombatBridge()
{
	PrimaryComponentTick.bCanEverTick = true;
	// S12-INPUT: was TickInterval = 0.05f. UI keys were edge-detected from
	// IsInputKeyDown() inside this tick, so at 20 Hz any keypress shorter than
	// 50 ms landed entirely between two ticks and was dropped - the "I / Esc
	// only works on the 3rd or 4th try" bug. Input must be sampled every frame;
	// the heavy work below is throttled individually instead.
	PrimaryComponentTick.TickInterval = 0.0f;
	// Needed so this component still owns Escape while the pause menu has the
	// game paused (otherwise nothing could un-pause it).
	PrimaryComponentTick.bTickEvenWhenPaused = true;
}

void USquadAIPlayerCombatBridge::BeginPlay()
{
	Super::BeginPlay();
	UE_LOG(LogTemp, Warning, TEXT("[PlayerCombat] CombatBridge attached to %s. TraceInterval=%.2f, MaxDist=%.0f, Damage=%.0f"),
		*GetNameSafe(GetOwner()), TraceInterval, MaxTraceDistance, DamagePerHit);

	// S19-PACKHP: the player's TPWCS health component can come up (or be pushed)
	// above its own maxHealth — observed live at 1998.338 against maxHealth 100.
	// While that holds, every enemy bullet is real but invisible: the bar is
	// pinned at 100% and the player cannot be killed by gunfire, which players
	// read as "the first shot does no damage". Clamp at attach, then audit.
	FString PackHealthWhy;
	if (SquadAIRecovery::ClampPackHealthToMax(GetOwner(), &PackHealthWhy))
	{
		UE_LOG(LogTemp, Warning, TEXT("[PlayerCombat] S19-PACKHP on attach: %s"), *PackHealthWhy);
		SquadAISituation::Note(FString::Printf(TEXT("PACKHP-CLAMP on attach: %s"), *PackHealthWhy));
	}

	// Sync chosen Armory weapon from USquadAIProgressionSubsystem into USquadAIInventorySubsystem & player pawn
	if (USquadAIInventorySubsystem* WepInv = USquadAIInventorySubsystem::Get(this))
	{
		if (const USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(this))
		{
			WepInv->SelectWeaponByID(Prog->GetEquippedWeaponID());
		}
		if (APawn* Pawn = Cast<APawn>(GetOwner()))
		{
			WepInv->EquipSelectedWeapon(Pawn);
		}
	}
}

void USquadAIPlayerCombatBridge::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
	if (!GetOwner()) return;

	// S19-PACKHP: 5 s audit of the player's pack health (cheap: component scan +
	// two property reads). Keeps the "invisible damage" state from ever settling
	// in, whatever pack code path produced it.
	PackHealthAuditAccum += DeltaTime;
	if (PackHealthAuditAccum >= 5.f)
	{
		PackHealthAuditAccum = 0.f;
		FString HeartbeatWhy;
		if (SquadAIRecovery::ClampPackHealthToMax(GetOwner(), &HeartbeatWhy))
		{
			UE_LOG(LogTemp, Warning, TEXT("[PlayerCombat] S19-PACKHP heartbeat: %s"), *HeartbeatWhy);
			SquadAISituation::Note(FString::Printf(TEXT("PACKHP-CLAMP heartbeat: %s"), *HeartbeatWhy));
		}
	}

	// S19-LOGGER: primary host for the situation log (the leader's tick is the second).
	// It throttles itself, so calling it every frame is free.
	SquadAISituation::Tick(GetWorld(), DeltaTime);

	APawn* Pawn = Cast<APawn>(GetOwner());
	APlayerController* PC = Pawn ? Cast<APlayerController>(Pawn->GetController()) : nullptr;

	// S12-INPUT: SINGLE OWNER for the UI keys (Escape/P and I/Tab).
	// These used to be read here AND again inside the HUD's draw code
	// (DrawInventoryScreen / the pause-menu draw). Both ran in the same frame,
	// so one press toggled the panel open and then straight back closed - which
	// is why the icons "flickered for a split second" and it took several
	// presses to stick. The HUD draw-time readers have been removed; this is now
	// the only place these keys are consumed.
	//
	// S14-INPUT: WasInputKeyJustPressed re-introduced the instant-close in a
	// different disguise. It reads UPlayerInput event counts, which are only
	// rebuilt when the PlayerController processes the input stack. Unpaused,
	// this component is guaranteed to tick after the controller (component ->
	// pawn -> controller tick prerequisites). But ToggleInventory / Toggle-
	// PauseMenu pause the game, and on the FIRST PAUSED FRAME the pawn does
	// not tick, the prerequisite chain is broken, and this component (which
	// ticks even when paused) can run BEFORE the controller's paused input
	// pass - so it saw the previous frame's still-uncleared Pressed event and
	// toggled the menu straight back closed after one frame. Fix: level-based
	// rising-edge detection on IsInputKeyDown (safe now that we tick every
	// frame; it cannot double-fire off stale state, at worst it fires one
	// frame late), plus a 0.2 s real-time debounce as belt-and-braces.
	const bool bPaused = UGameplayStatics::IsGamePaused(GetWorld());
	if (PC)
	{
		AQuestNativeHUD* UIHud = AQuestNativeHUD::Get(this);

		const bool bPauseKeyDown = PC->IsInputKeyDown(EKeys::Escape) || PC->IsInputKeyDown(EKeys::P);
		const bool bInvKeyDown   = PC->IsInputKeyDown(EKeys::I) || PC->IsInputKeyDown(EKeys::Tab);
		bool bTogglePause = bPauseKeyDown && !bUIPauseKeyDownPrev;
		bool bToggleInv   = bInvKeyDown && !bUIInvKeyDownPrev;
		bUIPauseKeyDownPrev = bPauseKeyDown;
		bUIInvKeyDownPrev   = bInvKeyDown;

		const double NowReal = FPlatformTime::Seconds();
		if ((bTogglePause || bToggleInv) && LastUIToggleRealTime >= 0.0 && (NowReal - LastUIToggleRealTime) < 0.2)
		{
			bTogglePause = false;
			bToggleInv   = false;
		}

		if (UIHud && (bTogglePause || bToggleInv))
		{
			LastUIToggleRealTime = NowReal;
			if (bToggleInv && !UIHud->IsPauseMenuActive())
			{
				UIHud->ToggleInventory(!UIHud->IsInventoryOpen());
			}
			else if (bTogglePause)
			{
				// Escape backs out of the inventory first, then opens/closes pause.
				if (UIHud->IsInventoryOpen())
				{
					UIHud->ToggleInventory(false);
				}
				else
				{
					UIHud->TogglePauseMenu(!UIHud->IsPauseMenuActive());
				}
			}
		}
	}

	// While paused, nothing below (combat, mortar, healing) should run.
	if (bPaused)
	{
		return;
	}

	// 1. Tactical Mortar Call-In via Middle Mouse Button (Aiming & Salvo Execution)
	if (PC)
	{
		AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this);
		USquadAIFireSupportSubsystem* FireSupport = USquadAIFireSupportSubsystem::Get(this);

		if (PC->IsInputKeyDown(EKeys::MiddleMouseButton))
		{
			FVector CamLoc;
			FRotator CamRot;
			PC->GetPlayerViewPoint(CamLoc, CamRot);

			FHitResult MortarHit;
			FCollisionQueryParams Params;
			Params.AddIgnoredActor(GetOwner());

			if (GetWorld()->LineTraceSingleByChannel(MortarHit, CamLoc, CamLoc + CamRot.Vector() * 25000.f, ECC_Visibility, Params))
			{
				if (HUD)
				{
					HUD->SetMortarAimingActive(true, MortarHit.ImpactPoint);
				}
			}
		}
		else if (PC->WasInputKeyJustReleased(EKeys::MiddleMouseButton))
		{
			FVector CamLoc;
			FRotator CamRot;
			PC->GetPlayerViewPoint(CamLoc, CamRot);

			FHitResult MortarHit;
			FCollisionQueryParams Params;
			Params.AddIgnoredActor(GetOwner());

			if (GetWorld()->LineTraceSingleByChannel(MortarHit, CamLoc, CamLoc + CamRot.Vector() * 25000.f, ECC_Visibility, Params))
			{
				if (FireSupport && FireSupport->CallMortarStrike(MortarHit.ImpactPoint, 5))
				{
					if (USquadAIRadioChatterSubsystem* Radio = USquadAIRadioChatterSubsystem::Get(this))
					{
						Radio->BroadcastRadioChatter(TEXT("سرگرد شهید رستمی"), ETacticalRadioContext::MortarInbound);
					}
				}
			}

			if (HUD)
			{
				HUD->SetMortarAimingActive(false);
			}
		}
	}

	// 2. Tactical Guiding Wind Navigation on holding 'V'
	if (PC && PC->IsInputKeyDown(EKeys::V))
	{
		if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this))
		{
			HUD->SetGuidanceVisionActive(true);
		}
	}
	else
	{
		if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this))
		{
			HUD->SetGuidanceVisionActive(false);
		}
	}

	// 3. Tactical Ordnance Input Listeners [G] Frag / [H] Smoke
	//    S19-GRENARC: hold to aim, release to throw. This bridge is the live G/H
	//    listener for the player, so the contract has to be implemented HERE - it used
	//    to throw on the key press, which meant the aim state never became true and the
	//    HUD preview (let alone a landing arrow) could never appear in normal play.
	//    The component's own hold/release path stays as the fallback for pawns with no
	//    bridge, and both drive the same BeginAim/ReleaseAim pair.
	if (PC)
	{
		const bool bGDown = PC->IsInputKeyDown(EKeys::G);
		const bool bHDown = PC->IsInputKeyDown(EKeys::H);

		UTacticalGrenadeComponent* AimComp = Pawn ? Pawn->FindComponentByClass<UTacticalGrenadeComponent>() : nullptr;
		USquadAIInventorySubsystem* GrenadeInv = USquadAIInventorySubsystem::Get(this);
		const bool bHasFragInInv = GrenadeInv ? (GrenadeInv->FragGrenades > 0) : false;
		const bool bHasSmokeInInv = GrenadeInv ? (GrenadeInv->SmokeGrenades > 0) : false;

		const bool bGPress = bGDown && !bGKeyDownPrev;
		const bool bGRelease = !bGDown && bGKeyDownPrev;
		const bool bHPress = bHDown && !bHKeyDownPrev;
		const bool bHRelease = !bHDown && bHKeyDownPrev;

		// The raw throw the old code used whenever the component refused (cooldown,
		// counters out of sync) or was missing. Kept so the key never feels dead - but
		// now it happens on RELEASE, after the aim phase.
		auto SpawnRawGrenade = [&](EGrenadeType Type) -> bool
		{
			if (!Pawn) return false;
			const FVector CamLoc = PC->PlayerCameraManager ? PC->PlayerCameraManager->GetCameraLocation() : Pawn->GetActorLocation() + FVector(0.f, 0.f, 60.f);
			const FVector CamDir = PC->GetControlRotation().Vector();
			FActorSpawnParameters SpawnParams;
			SpawnParams.Instigator = Pawn;
			SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
			ATacticalGrenadeActor* Grenade = GetWorld()
				? GetWorld()->SpawnActor<ATacticalGrenadeActor>(ATacticalGrenadeActor::StaticClass(), CamLoc + CamDir * 60.f, CamDir.Rotation(), SpawnParams)
				: nullptr;
			if (!Grenade) return false;
			Grenade->GrenadeType = Type;
			const FVector LaunchDir = (CamDir.GetSafeNormal() + FVector(0.f, 0.f, 0.28f)).GetSafeNormal();
			Grenade->LaunchGrenade(LaunchDir * 1600.f, Pawn);
			if (GrenadeInv)
			{
				if (Type == EGrenadeType::Fragmentation) GrenadeInv->FragGrenades = FMath::Max(0, GrenadeInv->FragGrenades - 1);
				else GrenadeInv->SmokeGrenades = FMath::Max(0, GrenadeInv->SmokeGrenades - 1);
			}
			return true;
		};

		if (AimComp)
		{
			if (bGPress)
			{
				if (bHasFragInInv)
				{
					if (!AimComp->BeginAim(EGrenadeType::Fragmentation))
					{
						// Refused (cooldown / unavailable) with ammo in the pouch: the
						// same fallback the old code had, and it says so.
						SquadAISituation::Note(TEXT("GRENADE frag aim refused by the component (cooldown?) - raw fallback throw"));
						SpawnRawGrenade(EGrenadeType::Fragmentation);
					}
				}
				else
				{
					SquadAISituation::Note(FString::Printf(TEXT("GRENADE G pressed with an empty frag pouch (frag %d, smoke %d)"),
						GrenadeInv ? GrenadeInv->FragGrenades : -1, GrenadeInv ? GrenadeInv->SmokeGrenades : -1));
				}
			}
			else if (bHPress)
			{
				if (bHasSmokeInInv)
				{
					if (!AimComp->BeginAim(EGrenadeType::SmokeScreen))
					{
						SquadAISituation::Note(TEXT("GRENADE smoke aim refused by the component (cooldown?) - raw fallback throw"));
						SpawnRawGrenade(EGrenadeType::SmokeScreen);
					}
				}
				else
				{
					SquadAISituation::Note(FString::Printf(TEXT("GRENADE H pressed with an empty smoke pouch (frag %d, smoke %d)"),
						GrenadeInv ? GrenadeInv->FragGrenades : -1, GrenadeInv ? GrenadeInv->SmokeGrenades : -1));
				}
			}

			if (AimComp->IsAimingGrenade())
			{
				const EGrenadeType AimType = AimComp->GetAimingGrenadeType();
				const bool bReleasedThisKey = (AimType == EGrenadeType::SmokeScreen) ? bHRelease : bGRelease;
				if (bReleasedThisKey)
				{
					if (AimComp->ReleaseAim())
					{
						if (GrenadeInv)
						{
							GrenadeInv->FragGrenades = FMath::Max(0, AimComp->GetFragCount());
							GrenadeInv->SmokeGrenades = FMath::Max(0, AimComp->GetSmokeCount());
						}
					}
					else
					{
						// Rejected on release (the cooldown started during the aim): keep
						// the old guarantee that the key still produces a grenade when
						// the pouch is not empty.
						const bool bHasThisInInv = (AimType == EGrenadeType::SmokeScreen) ? bHasSmokeInInv : bHasFragInInv;
						if (bHasThisInInv)
						{
							SquadAISituation::Note(TEXT("GRENADE release refused by the component - raw fallback throw"));
							SpawnRawGrenade(AimType);
						}
						else
						{
							SquadAISituation::Note(TEXT("GRENADE aim ended on release but nothing was thrown"));
						}
					}
				}
				else if (AQuestNativeHUD* UIHud = AQuestNativeHUD::Get(this))
				{
					// Aiming under an open menu would leave the ghost aiming on a frozen
					// frame; cancel it the way Escape already cancels the UI.
					if (UIHud->IsPauseMenuActive() || UIHud->IsInventoryOpen())
					{
						AimComp->CancelAim();
					}
				}
			}
		}
		else if (bGPress || bHPress)
		{
			// No grenade component at all: the original press-to-throw behaviour.
			if (bGPress && bHasFragInInv) SpawnRawGrenade(EGrenadeType::Fragmentation);
			else if (bHPress && bHasSmokeInInv) SpawnRawGrenade(EGrenadeType::SmokeScreen);
		}

		// Edge tracking for the next frame - WITHOUT these two lines every frame looks
		// like a fresh press and a fresh release, which would re-enter the aim and throw
		// continuously. (The splice that rewrote this section dropped them once.)
		bGKeyDownPrev = bGDown;
		bHKeyDownPrev = bHDown;

		// Quick First Aid Kit [4] or [5]
		const bool bMedDown = PC->IsInputKeyDown(EKeys::Four) || PC->IsInputKeyDown(EKeys::Five);
		if (bMedDown && !bMedKeyDownPrev)
		{
			USquadAIInventorySubsystem* Inv = USquadAIInventorySubsystem::Get(this);
			if (Inv && Inv->FirstAidKits > 0 && Pawn)
			{
				bool bHealed = false;
				if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(Pawn))
				{
					if (Soldier->HealthComp && !Soldier->HealthComp->bIsDead && Soldier->HealthComp->CurrentHealth < Soldier->HealthComp->MaxHealth) // F-G9 companion: medkits do not resurrect the dead (no kit wasted on a corpse).
					{
						// Route through Heal() so HUD bars and events update (was a silent direct write). Kits are
						// only consumed when someone was actually hurt (see bHealed gate below).
						Soldier->HealthComp->Heal(Soldier->HealthComp->MaxHealth);
						bHealed = true;
					}
				}

				TArray<UActorComponent*> Comps;
				Pawn->GetComponents(Comps);
				for (UActorComponent* C : Comps)
				{
					if (!C || !C->GetName().Contains(TEXT("BPC_Health"))) continue;
					// Read the pack's own max first (double/float/int), then top up only if hurt.
					double PackMax = 100.0;
					for (const FName& MaxName : { FName(TEXT("maxHealth")), FName(TEXT("MaxHealth")), FName(TEXT("Max Health")), FName(TEXT("MaxHP")) })
					{
						if (FDoubleProperty* MDP = FindFProperty<FDoubleProperty>(C->GetClass(), MaxName)) { PackMax = MDP->GetPropertyValue_InContainer(C); break; }
						if (FFloatProperty* MFP = FindFProperty<FFloatProperty>(C->GetClass(), MaxName)) { PackMax = MFP->GetPropertyValue_InContainer(C); break; }
						if (FIntProperty* MIP = FindFProperty<FIntProperty>(C->GetClass(), MaxName)) { PackMax = MIP->GetPropertyValue_InContainer(C); break; }
					}
					for (const FName& PropName : { FName(TEXT("currentHealth")), FName(TEXT("CurrentHealth")), FName(TEXT("Current Health")), FName(TEXT("Health")), FName(TEXT("HP")) })
					{
						if (FDoubleProperty* DP = FindFProperty<FDoubleProperty>(C->GetClass(), PropName))
						{
							if (DP->GetPropertyValue_InContainer(C) < PackMax) { DP->SetPropertyValue_InContainer(C, PackMax); bHealed = true; }
							break;
						}
						if (FFloatProperty* FP = FindFProperty<FFloatProperty>(C->GetClass(), PropName))
						{
							if (FP->GetPropertyValue_InContainer(C) < static_cast<float>(PackMax)) { FP->SetPropertyValue_InContainer(C, static_cast<float>(PackMax)); bHealed = true; }
							break;
						}
						if (FIntProperty* IP = FindFProperty<FIntProperty>(C->GetClass(), PropName))
						{
							if (IP->GetPropertyValue_InContainer(C) < FMath::RoundToInt(PackMax)) { IP->SetPropertyValue_InContainer(C, FMath::RoundToInt(PackMax)); bHealed = true; }
							break;
						}
					}
				}

				if (bHealed)
				{
					Inv->FirstAidKits = FMath::Max(0, Inv->FirstAidKits - 1);
					if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
					{
						AudioSys->PlayTacticalVoiceline(ETacticalVoicelineType::Ally_Healing, Pawn); // MEGA-5 (G-11): medic bark, not a hold order.
					}
				}
			}
		}
		bMedKeyDownPrev = bMedDown;

		// Live Weapon Slot Switching ([1..6] Arsenal Weapons, [Q] Cycle Next Weapon) & Reload ([R])
		if (USquadAIInventorySubsystem* WepInv = USquadAIInventorySubsystem::Get(this))
		{
			if (PC->WasInputKeyJustPressed(EKeys::One))
			{
				WepInv->SelectWeaponByIndex(0);
				if (Pawn) WepInv->EquipSelectedWeapon(Pawn);
			}
			else if (PC->WasInputKeyJustPressed(EKeys::Two))
			{
				WepInv->SelectWeaponByIndex(1);
				if (Pawn) WepInv->EquipSelectedWeapon(Pawn);
			}
			else if (PC->WasInputKeyJustPressed(EKeys::Three))
			{
				WepInv->SelectWeaponByIndex(2);
				if (Pawn) WepInv->EquipSelectedWeapon(Pawn);
			}
			else if (PC->WasInputKeyJustPressed(EKeys::Four))
			{
				WepInv->SelectWeaponByIndex(3);
				if (Pawn) WepInv->EquipSelectedWeapon(Pawn);
			}
			else if (PC->WasInputKeyJustPressed(EKeys::Five))
			{
				WepInv->SelectWeaponByIndex(4);
				if (Pawn) WepInv->EquipSelectedWeapon(Pawn);
			}
			else if (PC->WasInputKeyJustPressed(EKeys::Six))
			{
				WepInv->SelectWeaponByIndex(5);
				if (Pawn) WepInv->EquipSelectedWeapon(Pawn);
			}
			else if (PC->WasInputKeyJustPressed(EKeys::Q))
			{
				WepInv->NextWeapon();
				if (Pawn) WepInv->EquipSelectedWeapon(Pawn);
			}
			else if (PC->WasInputKeyJustPressed(EKeys::R))
			{
				if (WepInv->Weapons.IsValidIndex(WepInv->SelectedWeaponIndex))
				{
					FSquadInventoryWeaponItem& ActiveWep = WepInv->Weapons[WepInv->SelectedWeaponIndex];
					const int32 Needed = FMath::Max(0, ActiveWep.MaxClipAmmo - ActiveWep.ClipAmmo);
					const int32 ToLoad = FMath::Min(Needed, ActiveWep.ReserveAmmo);
					if (ToLoad > 0)
					{
						ActiveWep.ClipAmmo += ToLoad;
						ActiveWep.ReserveAmmo -= ToLoad;
					}
					if (Pawn)
					{
						WepInv->EquipSelectedWeapon(Pawn);
					}
				}
				if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(Pawn))
				{
					if (Soldier->WeaponComp)
					{
						Soldier->WeaponComp->Reload();
					}
				}
			}
		}

		// S12-INPUT: pause-menu and inventory toggles moved to the single-owner
		// block at the top of this tick.
	}

	// 5. Firing Trace
	TraceTimer += DeltaTime;
	if (TraceTimer >= TraceInterval)
	{
		TraceTimer = 0.f;
		bool bFiring = IsPlayerFiring();
		if (bFiring)
		{
			PerformCombatTrace();
		}
		bWasFiring = bFiring;
	}

	// B7-7: infinite-ammo cheat reader. SquadAI's own WeaponComponent never consumes
	// ammo (the TPWCS pack owns the mag), so top the pack back up every frame.
	// S12-INPUT: this ran at the old 20 Hz tick rate; keep that rate now that the
	// component ticks every frame for input responsiveness.
	AmmoTopUpAccum += DeltaTime;
	if (AmmoTopUpAccum >= 0.05f)
	{
		AmmoTopUpAccum = 0.f;
		TopUpPackAmmoForInfiniteCheat();
	}
}

void USquadAIPlayerCombatBridge::TopUpPackAmmoForInfiniteCheat()
{
	USquadAIDevDebugSubsystem* DevDbg = USquadAIDevDebugSubsystem::Get(this);
	if (!DevDbg || !DevDbg->bInfiniteAmmoActive) return;
	APawn* Pawn = Cast<APawn>(GetOwner());
	if (!Pawn) return;

	UActorComponent* WC = CachedWeaponComp.Get();
	if (!WC)
	{
		TArray<UActorComponent*> Comps;
		Pawn->GetComponents(Comps);
		for (UActorComponent* C : Comps)
		{
			if (C && (C->GetName().Contains(TEXT("BPC_Weapon")) || C->GetName().Contains(TEXT("BPC_Inventory")) || C->GetName().Contains(TEXT("Combat"))))
			{
				WC = C;
				break;
			}
		}
		if (!WC) return;
	}
	if (!bAmmoPropsResolved)
	{
		bAmmoPropsResolved = true;
		for (const FName& PropName : { FName(TEXT("currentAmmo")), FName(TEXT("CurrentAmmo")), FName(TEXT("Ammo")) })
		{
			if (FIntProperty* P = FindFProperty<FIntProperty>(WC->GetClass(), PropName)) { CachedCurrentAmmoProp = P; break; }
		}
		for (const FName& PropName : { FName(TEXT("reserveAmmo")), FName(TEXT("ReserveAmmo")), FName(TEXT("TotalAmmo")) })
		{
			if (FIntProperty* P = FindFProperty<FIntProperty>(WC->GetClass(), PropName)) { CachedReserveAmmoProp = P; break; }
		}
	}
	// Only write when below full so the HUD counters look untouched while firing.
	if (CachedCurrentAmmoProp && CachedCurrentAmmoProp->GetPropertyValue_InContainer(WC) < 30)
	{
		CachedCurrentAmmoProp->SetPropertyValue_InContainer(WC, 30);
	}
	if (CachedReserveAmmoProp && CachedReserveAmmoProp->GetPropertyValue_InContainer(WC) < 180)
	{
		CachedReserveAmmoProp->SetPropertyValue_InContainer(WC, 180);
	}
}

bool USquadAIPlayerCombatBridge::IsPlayerFiring() const
{
	APawn* Pawn = Cast<APawn>(GetOwner());
	if (!Pawn) return false;

	// PERFORMANCE: Cache weapon component pointer — only scan components once
	if (!bWeaponCompCached)
	{
		bWeaponCompCached = true;
		TArray<UActorComponent*> Comps;
		Pawn->GetComponents(Comps);
		for (UActorComponent* C : Comps)
		{
			if (!C) continue;
			const FString N = C->GetName();
			if (N.Contains(TEXT("BPC_WeaponCharacter")))
			{
				CachedWeaponComp = C;
				break;
			}
		}
	}

	// Method 1: Check TPWCS weapon component for shooting state
	if (UActorComponent* WC = CachedWeaponComp.Get())
	{
		if (!bShootingPropResolved)
		{
			bShootingPropResolved = true;
			for (const FName& PropName : { FName(TEXT("bIsShooting?")), FName(TEXT("bIsShooting")) })
			{
				if (FBoolProperty* P = FindFProperty<FBoolProperty>(WC->GetClass(), PropName))
				{
					CachedIsShootingProp = P;
					break;
				}
			}
		}
		if (CachedIsShootingProp && CachedIsShootingProp->GetPropertyValue_InContainer(WC))
		{
			return true;
		}
	}

	// Method 2: Fallback to left mouse button
	if (APlayerController* PC = Cast<APlayerController>(Pawn->GetController()))
	{
		if (PC->IsInputKeyDown(EKeys::LeftMouseButton))
		{
			return true;
		}
	}

	return false;
}

void USquadAIPlayerCombatBridge::PerformCombatTrace()
{
	AActor* Owner = GetOwner();
	if (!Owner) return;

	UWorld* World = GetWorld();
	if (!World) return;

	APlayerController* PC = UGameplayStatics::GetPlayerController(World, 0);
	if (!PC) return;

	FVector CamLoc;
	FRotator CamRot;
	PC->GetPlayerViewPoint(CamLoc, CamRot);

	const FVector TraceStart = CamLoc;
	const FVector TraceDir = CamRot.Vector();
	const FVector TraceEnd = TraceDir * MaxTraceDistance + TraceStart;

	FHitResult Hit;
	FCollisionQueryParams Params;
	Params.AddIgnoredActor(Owner);
	// Also ignore all actors attached to owner (weapon meshes, etc.)
	TArray<AActor*> AttachedActors;
	Owner->GetAttachedActors(AttachedActors);
	for (AActor* Attached : AttachedActors)
	{
		Params.AddIgnoredActor(Attached);
	}

	const bool bHit = World->LineTraceSingleByChannel(Hit, TraceStart, TraceEnd, ECC_Visibility, Params);

	// Consume 1 round in USquadAIInventorySubsystem (and sync native WeaponComp if present)
	const bool bInfAmmo = USquadAIDevDebugSubsystem::Get(this) && USquadAIDevDebugSubsystem::Get(this)->bInfiniteAmmoActive;
	if (!bInfAmmo)
	{
		if (USquadAIInventorySubsystem* WepInv = USquadAIInventorySubsystem::Get(this))
		{
			if (WepInv->Weapons.IsValidIndex(WepInv->SelectedWeaponIndex))
			{
				FSquadInventoryWeaponItem& ActiveWep = WepInv->Weapons[WepInv->SelectedWeaponIndex];
				if (ActiveWep.ClipAmmo > 0)
				{
					ActiveWep.ClipAmmo = FMath::Max(0, ActiveWep.ClipAmmo - 1);
					if (ActiveWep.ClipAmmo == 0 && ActiveWep.ReserveAmmo > 0)
					{
						const int32 ToLoad = FMath::Min(ActiveWep.MaxClipAmmo, ActiveWep.ReserveAmmo);
						ActiveWep.ClipAmmo += ToLoad;
						ActiveWep.ReserveAmmo -= ToLoad;
					}
				}
				else if (ActiveWep.ReserveAmmo > 0)
				{
					const int32 ToLoad = FMath::Min(ActiveWep.MaxClipAmmo, ActiveWep.ReserveAmmo);
					ActiveWep.ClipAmmo = FMath::Max(0, ToLoad - 1);
					ActiveWep.ReserveAmmo -= ToLoad;
				}
				if (APawn* PawnOwner = Cast<APawn>(Owner))
				{
					WepInv->EquipSelectedWeapon(PawnOwner);
				}
			}
		}
		if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(Owner))
		{
			if (Soldier->WeaponComp && Soldier->WeaponComp->CurrentClipAmmo > 0)
			{
				Soldier->WeaponComp->CurrentClipAmmo = FMath::Max(0, Soldier->WeaponComp->CurrentClipAmmo - 1);
				if (Soldier->WeaponComp->CurrentClipAmmo == 0 && Soldier->WeaponComp->ReserveAmmo > 0)
				{
					Soldier->WeaponComp->Reload();
				}
			}
		}
	}

	// Apply suppression along bullet path to suppress nearby enemies
	if (USoldierRegistrySubsystem* Reg = World->GetSubsystem<USoldierRegistrySubsystem>())
	{
		const FVector EndPoint = bHit ? Hit.ImpactPoint : TraceEnd;
		Reg->ApplySuppressionAlongPath(TraceStart, EndPoint, 300.f, 0.40f, Owner);
	}

#if ENABLE_DRAW_DEBUG
	if (bDrawDebugTrace)
	{
		DrawDebugLine(World, TraceStart, TraceEnd,
			bHit ? FColor::Red : FColor::Green, false, 0.15f, 0, 1.5f);
		if (bHit)
		{
			DrawDebugPoint(World, Hit.ImpactPoint, 10.f, FColor::Yellow, false, 0.15f);
		}
	}
#endif

	const bool bHitDebug = CVarSquadAIDebugPlayerHits.GetValueOnGameThread() != 0;

	if (!bHit || !Hit.GetActor())
	{
		if (bHitDebug)
		{
			UE_LOG(LogTemp, Warning, TEXT("[SquadAI][PlayerHit] MISS (nothing within %.0fcm)"), MaxTraceDistance);
		}
		return;
	}

	AActor* HitActor = Hit.GetActor();

	if (bHitDebug)
	{
		UE_LOG(LogTemp, Warning, TEXT("[SquadAI][PlayerHit] hit=%s comp=%s profile=%s bone=%s dist=%.0fcm"),
			*GetNameSafe(HitActor), *GetNameSafe(Hit.GetComponent()),
			Hit.GetComponent() ? *Hit.GetComponent()->GetCollisionProfileName().ToString() : TEXT("?"),
			*Hit.BoneName.ToString(), Hit.Distance);
	}

	// Skip allies and player
	if (APawn* HitPawn = Cast<APawn>(HitActor))
	{
		if (HitPawn->IsPlayerControlled())
		{
			return;
		}
	}

	// === Try SquadAI ASoldierCharacter first ===
	if (ASoldierCharacter* Target = Cast<ASoldierCharacter>(HitActor))
	{
		if (Target->IsAlly())
		{
			if (bHitDebug)
			{
				UE_LOG(LogTemp, Warning, TEXT("[SquadAI][PlayerHit] %s REFUSED: faction says Ally"), *GetNameSafe(Target));
			}
			return;
		}
		if (DamageSoldierCharacter(Target, TraceDir, Hit.BoneName))
		{
			if (bHitDebug)
			{
				UE_LOG(LogTemp, Warning, TEXT("[SquadAI][PlayerHit] %s damaged via native path (hp now %.1f)"),
					*GetNameSafe(Target), Target->HealthComp ? Target->HealthComp->CurrentHealth : -1.f);
			}
			return;
		}
		if (bHitDebug)
		{
			UE_LOG(LogTemp, Warning, TEXT("[SquadAI][PlayerHit] %s native path refused (dead or no HealthComp) - trying pack path"), *GetNameSafe(Target));
		}
	}

	// === S18-TUT: tutorial practice cans have no health component at all ===
	if (ATutorialTargetCan* Can = Cast<ATutorialTargetCan>(HitActor))
	{
		Can->RegisterHit(TraceDir);
		if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this))
		{
			HUD->NotifyHitConfirmed(true);
		}
		return;
	}

	// === Try TPWCS pack enemy (any actor with BPC_HealthAI) ===
	if (DamagePackEnemy(HitActor, TraceDir, Hit.BoneName))
	{
		if (bHitDebug)
		{
			UE_LOG(LogTemp, Warning, TEXT("[SquadAI][PlayerHit] %s damaged via pack path"), *GetNameSafe(HitActor));
		}
		return;
	}

	// === Ultimate fallback: any actor with a health-like component ===
	if (ApplyDamageViaReflection(HitActor, PackDamagePerHit, TraceDir, Hit.BoneName))
	{
		if (bHitDebug)
		{
			UE_LOG(LogTemp, Warning, TEXT("[SquadAI][PlayerHit] %s damaged via reflection fallback"), *GetNameSafe(HitActor));
		}
		return;
	}

	if (bHitDebug)
	{
		UE_LOG(LogTemp, Warning, TEXT("[SquadAI][PlayerHit] %s hit but NO damage path accepted it"), *GetNameSafe(HitActor));
	}
}

bool USquadAIPlayerCombatBridge::DamageSoldierCharacter(ASoldierCharacter* Target, const FVector& TraceDir, FName HitBoneName)
{
	if (!Target || !Target->HealthComp || !Target->HealthComp->IsAlive())
	{
		return false;
	}

	// B7-11: route through the damage chokepoint so invincible clamps, spawn-grace,
	// leader/ally immortality, downed/death events and AI damage stimuli all behave
	// identically to every other damage path (previously written directly, skipping all).
	APawn* CauserPawn = Cast<APawn>(GetOwner());
	const float HPBefore = Target->HealthComp->CurrentHealth;
	Target->HealthComp->ApplyDamage(DamagePerHit, CauserPawn);

	if (bLogHits)
	{
		UE_LOG(LogTemp, Warning, TEXT("[PlayerCombat] HIT SoldierCharacter %s for %.1f (hp: %.1f -> %.1f / %.1f)"),
			*GetNameSafe(Target), DamagePerHit, HPBefore, Target->HealthComp->CurrentHealth, Target->HealthComp->MaxHealth);
	}

	const bool bKilled = !Target->HealthComp->IsAlive();
	if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this))
	{
		HUD->NotifyHitConfirmed(bKilled);
	}

	if (bKilled)
	{
		Target->ApplyDeathImpulse(TraceDir, DeathImpulseForce, HitBoneName);
		UE_LOG(LogTemp, Warning, TEXT("[PlayerCombat] KILLED SoldierCharacter %s with physical impulse"), *GetNameSafe(Target));
	}

	return true;
}

bool USquadAIPlayerCombatBridge::DamagePackEnemy(AActor* Enemy, const FVector& TraceDir, FName HitBoneName)
{
	if (!Enemy) return false;

	TArray<UActorComponent*> Comps;
	Enemy->GetComponents(Comps);

	for (UActorComponent* C : Comps)
	{
		if (!C) continue;
		const FString N = C->GetName();
		if (!N.Contains(TEXT("BPC_Health"))) continue;

		for (const FName& PropName : { FName(TEXT("currentHealth")), FName(TEXT("CurrentHealth")), FName(TEXT("Health")) })
		{
			if (FDoubleProperty* DP = FindFProperty<FDoubleProperty>(C->GetClass(), PropName))
			{
				double CurrentHP = DP->GetPropertyValue_InContainer(C);
				if (CurrentHP <= 0.0) return false;

				double NewHP = FMath::Max(0.0, CurrentHP - static_cast<double>(PackDamagePerHit));
				DP->SetPropertyValue_InContainer(C, NewHP);
				// P1-1: pack-enemy hits must still scream into AI perception (was: silent write,
				// so nearby enemies never reacted to the player gunning down their squad).
				if (UWorld* SenseWorld = Enemy->GetWorld())
				{
					APawn* SenseInstigator = UGameplayStatics::GetPlayerPawn(SenseWorld, 0);
					UAISense_Damage::ReportDamageEvent(SenseWorld, Enemy, SenseInstigator, PackDamagePerHit,
						Enemy->GetActorLocation(), SenseInstigator ? SenseInstigator->GetActorLocation() : Enemy->GetActorLocation());
				}
				const bool bKilled = NewHP <= 0.0;

				if (bLogHits)
				{
					UE_LOG(LogTemp, Warning, TEXT("[PlayerCombat] HIT PackEnemy %s for %.1f (hp: %.1f -> %.1f)"),
						*GetNameSafe(Enemy), PackDamagePerHit, CurrentHP, NewHP);
				}

				if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this))
				{
					HUD->NotifyHitConfirmed(bKilled);
				}

				if (bKilled)
				{
					if (ACharacter* Char = Cast<ACharacter>(Enemy))
					{
						if (USkeletalMeshComponent* Mesh = Char->GetMesh())
						{
							Mesh->SetCollisionProfileName(TEXT("Ragdoll"));
							Mesh->SetSimulatePhysics(true);
							Mesh->AddImpulse(TraceDir * DeathImpulseForce, HitBoneName, true);
						}
					}
					UE_LOG(LogTemp, Warning, TEXT("[PlayerCombat] KILLED PackEnemy %s with physical impulse"), *GetNameSafe(Enemy));
				}
				return true;
			}

			if (FFloatProperty* FP = FindFProperty<FFloatProperty>(C->GetClass(), PropName))
			{
				float CurrentHP = FP->GetPropertyValue_InContainer(C);
				if (CurrentHP <= 0.f) return false;

				float NewHP = FMath::Max(0.f, CurrentHP - PackDamagePerHit);
				FP->SetPropertyValue_InContainer(C, NewHP);
				// P1-1: pack-enemy hits must still scream into AI perception (was: silent write,
				// so nearby enemies never reacted to the player gunning down their squad).
				if (UWorld* SenseWorld = Enemy->GetWorld())
				{
					APawn* SenseInstigator = UGameplayStatics::GetPlayerPawn(SenseWorld, 0);
					UAISense_Damage::ReportDamageEvent(SenseWorld, Enemy, SenseInstigator, PackDamagePerHit,
						Enemy->GetActorLocation(), SenseInstigator ? SenseInstigator->GetActorLocation() : Enemy->GetActorLocation());
				}
				const bool bKilled = NewHP <= 0.f;

				if (bLogHits)
				{
					UE_LOG(LogTemp, Warning, TEXT("[PlayerCombat] HIT PackEnemy %s for %.1f (hp: %.1f -> %.1f)"),
						*GetNameSafe(Enemy), PackDamagePerHit, CurrentHP, NewHP);
				}

				if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this))
				{
					HUD->NotifyHitConfirmed(bKilled);
				}

				if (bKilled)
				{
					if (ACharacter* Char = Cast<ACharacter>(Enemy))
					{
						if (USkeletalMeshComponent* Mesh = Char->GetMesh())
						{
							Mesh->SetCollisionProfileName(TEXT("Ragdoll"));
							Mesh->SetSimulatePhysics(true);
							Mesh->AddImpulse(TraceDir * DeathImpulseForce, HitBoneName, true);
						}
					}
					UE_LOG(LogTemp, Warning, TEXT("[PlayerCombat] KILLED PackEnemy %s with physical impulse"), *GetNameSafe(Enemy));
				}
				return true;
			}
		}

		UE_LOG(LogTemp, Error, TEXT("[PlayerCombat] Found health comp %s on %s but can't read currentHealth!"),
			*N, *GetNameSafe(Enemy));
		return false;
	}

	return false;
}

bool USquadAIPlayerCombatBridge::ApplyDamageViaReflection(AActor* Enemy, float Damage, const FVector& TraceDir, FName HitBoneName)
{
	if (!Enemy) return false;

	AActor* Owner = GetOwner();

	TArray<UActorComponent*> Comps;
	Enemy->GetComponents(Comps);

	for (UActorComponent* C : Comps)
	{
		if (!C) continue;
		const FString CN = C->GetClass() ? C->GetClass()->GetName() : FString();
		if (!CN.Contains(TEXT("Health"))) continue;

		if (C->GetOwner() == Owner) continue;

		for (const FName& PropName : { FName(TEXT("currentHealth")), FName(TEXT("CurrentHealth")), FName(TEXT("Health")), FName(TEXT("HP")) })
		{
			if (FDoubleProperty* DP = FindFProperty<FDoubleProperty>(C->GetClass(), PropName))
			{
				double HP = DP->GetPropertyValue_InContainer(C);
				if (HP <= 0.0) continue;
				const double NewHP = FMath::Max(0.0, HP - static_cast<double>(Damage));
				DP->SetPropertyValue_InContainer(C, NewHP);
				// P1-1: pack-enemy hits must still scream into AI perception (was: silent write,
				// so nearby enemies never reacted to the player gunning down their squad).
				if (UWorld* SenseWorld = Enemy->GetWorld())
				{
					APawn* SenseInstigator = UGameplayStatics::GetPlayerPawn(SenseWorld, 0);
					UAISense_Damage::ReportDamageEvent(SenseWorld, Enemy, SenseInstigator, Damage,
						Enemy->GetActorLocation(), SenseInstigator ? SenseInstigator->GetActorLocation() : Enemy->GetActorLocation());
				}
				const bool bKilled = NewHP <= 0.0;

				UE_LOG(LogTemp, Warning, TEXT("[PlayerCombat] REFLECTION hit %s (%s) for %.1f"), *GetNameSafe(Enemy), *CN, Damage);
				if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this))
				{
					HUD->NotifyHitConfirmed(bKilled);
				}
				if (bKilled)
				{
					if (ACharacter* Char = Cast<ACharacter>(Enemy))
					{
						if (USkeletalMeshComponent* Mesh = Char->GetMesh())
						{
							Mesh->SetCollisionProfileName(TEXT("Ragdoll"));
							Mesh->SetSimulatePhysics(true);
							Mesh->AddImpulse(TraceDir * DeathImpulseForce, HitBoneName, true);
						}
					}
				}
				return true;
			}
			if (FFloatProperty* FP = FindFProperty<FFloatProperty>(C->GetClass(), PropName))
			{
				float HP = FP->GetPropertyValue_InContainer(C);
				if (HP <= 0.f) continue;
				const float NewHP = FMath::Max(0.f, HP - Damage);
				FP->SetPropertyValue_InContainer(C, NewHP);
				// P1-1: pack-enemy hits must still scream into AI perception (was: silent write,
				// so nearby enemies never reacted to the player gunning down their squad).
				if (UWorld* SenseWorld = Enemy->GetWorld())
				{
					APawn* SenseInstigator = UGameplayStatics::GetPlayerPawn(SenseWorld, 0);
					UAISense_Damage::ReportDamageEvent(SenseWorld, Enemy, SenseInstigator, Damage,
						Enemy->GetActorLocation(), SenseInstigator ? SenseInstigator->GetActorLocation() : Enemy->GetActorLocation());
				}
				const bool bKilled = NewHP <= 0.f;

				UE_LOG(LogTemp, Warning, TEXT("[PlayerCombat] REFLECTION hit %s (%s) for %.1f"), *GetNameSafe(Enemy), *CN, Damage);
				if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this))
				{
					HUD->NotifyHitConfirmed(bKilled);
				}
				if (bKilled)
				{
					if (ACharacter* Char = Cast<ACharacter>(Enemy))
					{
						if (USkeletalMeshComponent* Mesh = Char->GetMesh())
						{
							Mesh->SetCollisionProfileName(TEXT("Ragdoll"));
							Mesh->SetSimulatePhysics(true);
							Mesh->AddImpulse(TraceDir * DeathImpulseForce, HitBoneName, true);
						}
					}
				}
				return true;
			}
		}
	}

	return false;
}

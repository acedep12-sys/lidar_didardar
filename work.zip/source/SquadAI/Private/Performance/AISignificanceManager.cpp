// AISignificanceManager.cpp — Tick-based LOD for AI soldiers
// Evaluates every 0.25s (4Hz), applies tick rate + mesh URO + skip-expensive-poll flags
#include "Performance/AISignificanceManager.h"
#include "Characters/SoldierCharacter.h"
#include "AI/SoldierAIController.h"
#include "SquadAITuning.h"
#include "Kismet/GameplayStatics.h"
#include "Components/SkeletalMeshComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/Pawn.h"
#include "TimerManager.h"
#include "Engine/World.h"

void UAISignificanceManager::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
	UpdateInterval = USquadAITuning::Get()->SignificanceUpdateInterval;
	UE_LOG(LogTemp, Warning, TEXT("[PERF] AISignificanceManager active. interval=%.2f dormantDist=%.0f maxHiFi=%d"),
		UpdateInterval,
		USquadAITuning::Get()->SignificanceDormantDistance,
		USquadAITuning::Get()->MaxHighFidelityAgents);
}

void UAISignificanceManager::Deinitialize()
{
	StopEvalTimer();
	RegisteredSoldiers.Empty();
	PendingApply.Empty();
	ApplyCursor = 0;
	Super::Deinitialize();
}

bool UAISignificanceManager::IsTickable() const
{
	return ApplyCursor < PendingApply.Num();
}

void UAISignificanceManager::EnsureEvalTimer()
{
	UWorld* World = GetWorld();
	if (!World || World->GetTimerManager().IsTimerActive(EvalTimer))
	{
		return;
	}
	World->GetTimerManager().SetTimer(EvalTimer, this, &UAISignificanceManager::OnEvalTimer, UpdateInterval, true);
}

void UAISignificanceManager::StopEvalTimer()
{
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(EvalTimer);
	}
}

void UAISignificanceManager::OnEvalTimer()
{
	if (RegisteredSoldiers.Num() == 0)
	{
		PendingApply.Reset();
		ApplyCursor = 0;
		StopEvalTimer();
		return;
	}
	RebuildEvalQueue();
}

void UAISignificanceManager::RegisterSoldier(ASoldierCharacter* Soldier)
{
	if (Soldier)
	{
		RegisteredSoldiers.AddUnique(Soldier);
		EnsureEvalTimer();
	}
}

void UAISignificanceManager::UnregisterSoldier(ASoldierCharacter* Soldier)
{
	RegisteredSoldiers.Remove(Soldier);
	if (RegisteredSoldiers.Num() == 0)
	{
		PendingApply.Reset();
		ApplyCursor = 0;
		StopEvalTimer();
	}
}

void UAISignificanceManager::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	const int32 Budget = FMath::Clamp(PendingApply.Num() / 4, 6, 12);
	int32 Applied = 0;
	while (ApplyCursor < PendingApply.Num() && Applied < Budget)
	{
		const FSquadAIPendingSig& P = PendingApply[ApplyCursor++];
		if (ASoldierCharacter* Soldier = P.Soldier.Get())
		{
			if (Soldier->IsAlive())
			{
				ApplySignificanceBucket(Soldier, P.Bucket);
			}
		}
		++Applied;
	}
}

void UAISignificanceManager::RebuildEvalQueue()
{
	struct FEval
	{
		ASoldierCharacter* Soldier = nullptr;
		float Sig = 0.f;
		EAISignificance Bucket = EAISignificance::Dormant;
	};

	TArray<FEval> Evals;
	Evals.Reserve(RegisteredSoldiers.Num());

	APawn* Player = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	APlayerController* PC = GetWorld() ? GetWorld()->GetFirstPlayerController() : nullptr;
	const FVector PlayerLoc = Player ? Player->GetActorLocation() : FVector::ZeroVector;
	const FVector ViewForward = PC ? PC->GetControlRotation().Vector() : FVector::ForwardVector;
	const float MaxDist = USquadAITuning::Get()->SignificanceDormantDistance;
	const int32 MaxHiFi = FMath::Max(4, USquadAITuning::Get()->MaxHighFidelityAgents);

	for (int32 i = RegisteredSoldiers.Num() - 1; i >= 0; --i)
	{
		ASoldierCharacter* Soldier = RegisteredSoldiers[i].Get();
		if (!Soldier || !Soldier->IsAlive())
		{
			RegisteredSoldiers.RemoveAtSwap(i, EAllowShrinking::No);
			continue;
		}

		FEval E;
		E.Soldier = Soldier;

		const FVector SoldierLoc = Soldier->GetActorLocation();
		const float Distance = Player ? FVector::Dist(SoldierLoc, PlayerLoc) : MaxDist;
		float Significance = 1.f - FMath::Clamp(Distance / FMath::Max(1.f, MaxDist), 0.f, 1.f);

		if (Player)
		{
			const FVector ToSoldier = (SoldierLoc - PlayerLoc).GetSafeNormal();
			const float Dot = FVector::DotProduct(ViewForward, ToSoldier);
			if (Dot > 0.5f) Significance += 0.1f;
			else if (Dot < -0.3f) Significance -= 0.1f;
		}

		if (ASoldierAIController* AI = Cast<ASoldierAIController>(Soldier->GetController()))
		{
			if (AI->bForceFullTick)
			{
				Significance = FMath::Max(Significance, 0.85f);
			}
		}

		E.Sig = FMath::Clamp(Significance, 0.f, 1.f);
		E.Bucket = SignificanceToBucket(E.Sig);
		Evals.Add(E);
	}

	Evals.Sort([](const FEval& A, const FEval& B) { return A.Sig > B.Sig; });
	int32 HiFiCount = 0;
	PendingApply.Reset();
	PendingApply.Reserve(Evals.Num());
	for (FEval& E : Evals)
	{
		if (E.Bucket <= EAISignificance::High)
		{
			++HiFiCount;
			if (HiFiCount > MaxHiFi)
			{
				E.Bucket = EAISignificance::Medium;
			}
		}
		FSquadAIPendingSig P;
		P.Soldier = E.Soldier;
		P.Bucket = E.Bucket;
		PendingApply.Add(P);
	}
	ApplyCursor = 0;
}

float UAISignificanceManager::EvaluateSignificance(ASoldierCharacter* Soldier) const
{
	APawn* Player = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	if (!Player) return 0.5f;

	const FVector SoldierLoc = Soldier->GetActorLocation();
	const FVector PlayerLoc = Player->GetActorLocation();
	const float Distance = FVector::Dist(SoldierLoc, PlayerLoc);
	const float MaxDist = USquadAITuning::Get()->SignificanceDormantDistance;
	float Significance = 1.f - FMath::Clamp(Distance / MaxDist, 0.f, 1.f);

	APlayerController* PC = GetWorld()->GetFirstPlayerController();
	if (PC)
	{
		const FVector ViewForward = PC->GetControlRotation().Vector();
		const FVector ToSoldier = (SoldierLoc - PlayerLoc).GetSafeNormal();
		const float Dot = FVector::DotProduct(ViewForward, ToSoldier);
		if (Dot > 0.5f) Significance += 0.1f;
		else if (Dot < -0.3f) Significance -= 0.1f;
	}

	if (ASoldierAIController* AI = Cast<ASoldierAIController>(Soldier->GetController()))
	{
		if (AI->bForceFullTick)
		{
			Significance = FMath::Max(Significance, 0.85f);
		}
	}

	return FMath::Clamp(Significance, 0.f, 1.f);
}

void UAISignificanceManager::ApplySignificanceBucket(ASoldierCharacter* Soldier, EAISignificance Bucket)
{
	if (!Soldier) return;

	AController* Controller = Soldier->GetController();
	const uint32 Id = Soldier->GetUniqueID();
	const float Phase = static_cast<float>(Id % 8) / 8.f;
	const float Stagger = 0.92f + 0.16f * Phase; // 0.92x–1.08x so same-bucket AI do not wake together

	if (ASoldierAIController* AI = Cast<ASoldierAIController>(Controller))
	{
		AI->CurrentLODBucket = static_cast<int32>(Bucket);
		AI->SignificanceUpdateMultiplier = GetUpdateMultiplierForBucket(Bucket);
		AI->bSkipExpensivePerceptionPolling = ShouldSkipExpensivePolling(Bucket);
		AI->PrimaryActorTick.TickInterval = GetControllerTickIntervalForBucket(Bucket) * Stagger;
	}
	else if (Controller)
	{
		Controller->PrimaryActorTick.TickInterval = GetControllerTickIntervalForBucket(Bucket) * Stagger;
	}

	Soldier->PrimaryActorTick.TickInterval = GetActorTickIntervalForBucket(Bucket) * Stagger;

	if (UCharacterMovementComponent* CMC = Soldier->GetCharacterMovement())
	{
		// City Sample / Mass-style: distant agents do not run CMC every frame.
		switch (Bucket)
		{
		case EAISignificance::Critical:
		case EAISignificance::High:
			CMC->PrimaryComponentTick.TickInterval = 0.f;
			break;
		case EAISignificance::Medium:
			CMC->PrimaryComponentTick.TickInterval = 0.033f;
			break;
		case EAISignificance::Low:
			CMC->PrimaryComponentTick.TickInterval = 0.05f;
			break;
		default:
			CMC->PrimaryComponentTick.TickInterval = 0.10f;
			break;
		}
	}

	if (USkeletalMeshComponent* Mesh = Soldier->GetMesh())
	{
		const bool bFar = (Bucket >= EAISignificance::High);
		Mesh->bEnableUpdateRateOptimizations = bFar;
		// Epic anim docs: skip per-frame physics-asset bounds. Tom Looman: UseAttachParentBound / fixed bounds.
		Mesh->bComponentUseFixedSkelBounds = (Bucket >= EAISignificance::Medium);
		// Only dirty the render proxy when the flag actually changes (shadow-map thrash → GPU hitch).
		const bool bWantShadow = (Bucket < EAISignificance::Low);
		if (Mesh->CastShadow != bWantShadow)
		{
			Mesh->SetCastShadow(bWantShadow);
		}
		if (Bucket >= EAISignificance::VeryLow)
		{
			Mesh->VisibilityBasedAnimTickOption = EVisibilityBasedAnimTickOption::OnlyTickPoseWhenRendered;
		}
		else if (Bucket >= EAISignificance::Medium)
		{
			Mesh->VisibilityBasedAnimTickOption = EVisibilityBasedAnimTickOption::AlwaysTickPose;
		}
		else
		{
			Mesh->VisibilityBasedAnimTickOption = EVisibilityBasedAnimTickOption::AlwaysTickPoseAndRefreshBones;
		}
	}
}

EAISignificance UAISignificanceManager::SignificanceToBucket(float Significance) const
{
	if (Significance >= 0.85f) return EAISignificance::Critical;
	if (Significance >= 0.65f) return EAISignificance::High;
	if (Significance >= 0.45f) return EAISignificance::Medium;
	if (Significance >= 0.25f) return EAISignificance::Low;
	if (Significance >= 0.1f)  return EAISignificance::VeryLow;
	return EAISignificance::Dormant;
}

float UAISignificanceManager::GetControllerTickIntervalForBucket(EAISignificance Bucket) const
{
	switch (Bucket)
	{
	case EAISignificance::Critical: return 0.05f;
	case EAISignificance::High:     return 0.10f;
	case EAISignificance::Medium:   return 0.20f;
	case EAISignificance::Low:      return 0.35f;
	case EAISignificance::VeryLow:  return 0.50f;
	default:                        return 1.00f;
	}
}

float UAISignificanceManager::GetActorTickIntervalForBucket(EAISignificance Bucket) const
{
	switch (Bucket)
	{
	case EAISignificance::Critical: return 0.10f;
	case EAISignificance::High:     return 0.20f;
	case EAISignificance::Medium:   return 0.35f;
	case EAISignificance::Low:      return 0.50f;
	case EAISignificance::VeryLow:  return 0.75f;
	default:                        return 1.50f;
	}
}

float UAISignificanceManager::GetUpdateMultiplierForBucket(EAISignificance Bucket) const
{
	switch (Bucket)
	{
	case EAISignificance::Critical: return 1.0f;
	case EAISignificance::High:     return 1.0f;
	case EAISignificance::Medium:   return 0.8f;
	case EAISignificance::Low:      return 0.6f;
	case EAISignificance::VeryLow:  return 0.4f;
	default:                        return 0.2f;
	}
}

bool UAISignificanceManager::ShouldSkipExpensivePolling(EAISignificance Bucket) const
{
	return Bucket >= EAISignificance::Low;
}

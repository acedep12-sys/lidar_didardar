#include "Performance/SquadAIFXManagerSubsystem.h"
#include "Components/DecalComponent.h"
#include "Materials/MaterialInterface.h"
#include "NiagaraFunctionLibrary.h"
#include "NiagaraSystem.h"
#include "NiagaraComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/World.h"
#include "Engine/Engine.h"

void USquadAIFXManagerSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
	DecalRingBuffer.Empty();
	DecalRingBuffer.Reserve(MaxActiveDecals);
	DecalBufferHead = 0;

	AutoResolveNiagaraExplosions();

	// B7-1: the per-second budgets were incremented but never reset, permanently culling
	// distant FX/audio mid-session. Reset them on a 1-second core ticker.
	TWeakObjectPtr<USquadAIFXManagerSubsystem> WeakSelf(this);
	BudgetResetTickerHandle = FTSTicker::GetCoreTicker().AddTicker(
		FTickerDelegate::CreateLambda([WeakSelf](float /*DeltaTime*/) -> bool
		{
			if (USquadAIFXManagerSubsystem* StrongSelf = WeakSelf.Get())
			{
				StrongSelf->ImpactFXCountThisSecond = 0;
				StrongSelf->WeaponAudioCountThisSecond = 0;
				return true; // keep ticking
			}
			return false; // subsystem gone, unregister
		}), 1.0f);

	UE_LOG(LogTemp, Log, TEXT("[SquadAIFXManager] Initialized Decal Ring Buffer, Niagara Explosions & FX Budget Subsystem (Max Decals: %d)"), MaxActiveDecals);
}

void USquadAIFXManagerSubsystem::Deinitialize()
{
	FTSTicker::GetCoreTicker().RemoveTicker(BudgetResetTickerHandle);
	FlushAllDecals();
	Super::Deinitialize();
}

USquadAIFXManagerSubsystem* USquadAIFXManagerSubsystem::Get(const UObject* WorldContextObject)
{
	if (!WorldContextObject) return nullptr;
	UWorld* World = GEngine ? GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::ReturnNull) : nullptr;
	return World ? World->GetSubsystem<USquadAIFXManagerSubsystem>() : nullptr;
}

void USquadAIFXManagerSubsystem::AutoResolveNiagaraExplosions()
{
	auto ResolveSystem = [](const TCHAR* Path) -> UNiagaraSystem*
	{
		return LoadObject<UNiagaraSystem>(nullptr, Path);
	};

	if (!NS_Dirt_Explosion)
		NS_Dirt_Explosion = ResolveSystem(TEXT("/Game/NiagaraExamples/FX_Explosions/NS_Dirt_Explosion.NS_Dirt_Explosion"));
	if (!NS_Dirt_Explosion)
		NS_Dirt_Explosion = ResolveSystem(TEXT("/Game/NiagaraExamples/FX_Explosions/NS_Dirt_Explosion"));

	if (!NS_Dirt_Explosion_Medium)
		NS_Dirt_Explosion_Medium = ResolveSystem(TEXT("/Game/NiagaraExamples/FX_Explosions/NS_Dirt_Explosion_Medium.NS_Dirt_Explosion_Medium"));
	if (!NS_Dirt_Explosion_Medium)
		NS_Dirt_Explosion_Medium = ResolveSystem(TEXT("/Game/NiagaraExamples/FX_Explosions/NS_Dirt_Explosion_Medium"));

	if (!NS_Dirt_Explosion_Small)
		NS_Dirt_Explosion_Small = ResolveSystem(TEXT("/Game/NiagaraExamples/FX_Explosions/NS_Dirt_Explosion_Small.NS_Dirt_Explosion_Small"));
	if (!NS_Dirt_Explosion_Small)
		NS_Dirt_Explosion_Small = ResolveSystem(TEXT("/Game/NiagaraExamples/FX_Explosions/NS_Dirt_Explosion_Small"));

	if (!NS_Explosion)
		NS_Explosion = ResolveSystem(TEXT("/Game/NiagaraExamples/FX_Explosions/NS_Explosion.NS_Explosion"));
	if (!NS_Explosion)
		NS_Explosion = ResolveSystem(TEXT("/Game/NiagaraExamples/FX_Explosions/NS_Explosion"));

	if (!NS_Explosion_Medium)
		NS_Explosion_Medium = ResolveSystem(TEXT("/Game/NiagaraExamples/FX_Explosions/NS_Explosion_Medium.NS_Explosion_Medium"));
	if (!NS_Explosion_Medium)
		NS_Explosion_Medium = ResolveSystem(TEXT("/Game/NiagaraExamples/FX_Explosions/NS_Explosion_Medium"));

	if (!NS_Explosion_Small)
		NS_Explosion_Small = ResolveSystem(TEXT("/Game/NiagaraExamples/FX_Explosions/NS_Explosion_Small.NS_Explosion_Small"));
	if (!NS_Explosion_Small)
		NS_Explosion_Small = ResolveSystem(TEXT("/Game/NiagaraExamples/FX_Explosions/NS_Explosion_Small"));
}

UNiagaraComponent* USquadAIFXManagerSubsystem::SpawnExplosionFX(FVector Location, float Radius, bool bDirtExplosion)
{
	UWorld* World = GetWorld();
	if (!World) return nullptr;

	if (!CanSpawnImpactVFX(Location, 16000.f))
	{
		return nullptr;
	}

	AutoResolveNiagaraExplosions();

	UNiagaraSystem* ChosenSystem = nullptr;
	if (bDirtExplosion)
	{
		if (Radius >= 600.f)
		{
			ChosenSystem = NS_Dirt_Explosion ? NS_Dirt_Explosion.Get() : NS_Explosion.Get();
		}
		else if (Radius >= 350.f)
		{
			ChosenSystem = NS_Dirt_Explosion_Medium ? NS_Dirt_Explosion_Medium.Get() : NS_Explosion_Medium.Get();
		}
		else
		{
			ChosenSystem = NS_Dirt_Explosion_Small ? NS_Dirt_Explosion_Small.Get() : NS_Explosion_Small.Get();
		}
	}
	else
	{
		if (Radius >= 600.f)
		{
			ChosenSystem = NS_Explosion ? NS_Explosion.Get() : NS_Dirt_Explosion.Get();
		}
		else if (Radius >= 350.f)
		{
			ChosenSystem = NS_Explosion_Medium ? NS_Explosion_Medium.Get() : NS_Dirt_Explosion_Medium.Get();
		}
		else
		{
			ChosenSystem = NS_Explosion_Small ? NS_Explosion_Small.Get() : NS_Dirt_Explosion_Small.Get();
		}
	}

	if (ChosenSystem)
	{
		return UNiagaraFunctionLibrary::SpawnSystemAtLocation(
			World,
			ChosenSystem,
			Location,
			FRotator::ZeroRotator,
			FVector(1.f),
			true,
			true,
			ENCPoolMethod::AutoRelease
		);
	}

	return nullptr;
}

UDecalComponent* USquadAIFXManagerSubsystem::SpawnImpactDecal(
	UMaterialInterface* DecalMaterial,
	FVector Location,
	FVector Normal,
	FVector DecalSize,
	float LifeSpan,
	float FadeDuration)
{
	if (!DecalMaterial) return nullptr;
	UWorld* World = GetWorld();
	if (!World) return nullptr;

	const FRotator DecalRotation = Normal.Rotation();
	UDecalComponent* TargetDecal = nullptr;

	// 1. If buffer has room, spawn a new decal component and add to ring
	if (DecalRingBuffer.Num() < MaxActiveDecals)
	{
		TargetDecal = UGameplayStatics::SpawnDecalAtLocation(
			World,
			DecalMaterial,
			DecalSize,
			Location,
			DecalRotation,
			LifeSpan);

		if (TargetDecal)
		{
			TargetDecal->SetFadeScreenSize(0.005f);
			DecalRingBuffer.Add(TargetDecal);
		}
		return TargetDecal;
	}

	// 2. Buffer full — recycle the oldest decal component (zero GC allocation)
	if (DecalRingBuffer.IsValidIndex(DecalBufferHead))
	{
		TargetDecal = DecalRingBuffer[DecalBufferHead].Get();
		if (IsValid(TargetDecal))
		{
			TargetDecal->SetWorldLocationAndRotation(Location, DecalRotation);
			TargetDecal->DecalSize = DecalSize;
			TargetDecal->SetDecalMaterial(DecalMaterial);
			TargetDecal->SetFadeScreenSize(0.005f);
			TargetDecal->SetVisibility(true);
			TargetDecal->SetLifeSpan(LifeSpan);
		}
		else
		{
			TargetDecal = UGameplayStatics::SpawnDecalAtLocation(
				World,
				DecalMaterial,
				DecalSize,
				Location,
				DecalRotation,
				LifeSpan);
			DecalRingBuffer[DecalBufferHead] = TargetDecal;
		}

		// Advance ring buffer index
		DecalBufferHead = (DecalBufferHead + 1) % MaxActiveDecals;
	}

	return TargetDecal;
}

bool USquadAIFXManagerSubsystem::CanSpawnImpactVFX(FVector Location, float MaxDistance)
{
	UWorld* World = GetWorld();
	if (!World) return true;

	APlayerCameraManager* Cam = UGameplayStatics::GetPlayerCameraManager(World, 0);
	if (!Cam) return true;

	const float DistSq = FVector::DistSquared(Cam->GetCameraLocation(), Location);
	if (DistSq > FMath::Square(MaxDistance))
	{
		return false; // Beyond visual range
	}

	// Distance-based rate throttling
	if (DistSq > FMath::Square(4000.f) && (ImpactFXCountThisSecond > 20))
	{
		return false; // Throttled for distant effects
	}

	ImpactFXCountThisSecond++;
	return true;
}

bool USquadAIFXManagerSubsystem::CanPlayWeaponAudio(FVector Location, float MaxDistance)
{
	UWorld* World = GetWorld();
	if (!World) return true;

	APlayerCameraManager* Cam = UGameplayStatics::GetPlayerCameraManager(World, 0);
	if (!Cam) return true;

	const float DistSq = FVector::DistSquared(Cam->GetCameraLocation(), Location);
	if (DistSq > FMath::Square(MaxDistance))
	{
		return false; // Inaudible distance
	}

	// Maximum 24 concurrent gunshot sounds per second across map
	if (WeaponAudioCountThisSecond >= 24 && DistSq > FMath::Square(1500.f))
	{
		return false; // Throttle distant gunshots to save audio mixing channels
	}

	WeaponAudioCountThisSecond++;
	return true;
}

void USquadAIFXManagerSubsystem::FlushAllDecals()
{
	for (TObjectPtr<UDecalComponent>& Decal : DecalRingBuffer)
	{
		if (Decal && IsValid(Decal))
		{
			Decal->DestroyComponent();
		}
	}
	DecalRingBuffer.Empty();
	DecalBufferHead = 0;
}

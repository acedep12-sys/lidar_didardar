// SoldierRegistrySubsystem.cpp — Sparse 2D hash for O(K) spatial queries
#include "Performance/SoldierRegistrySubsystem.h"
#include "Characters/SoldierCharacter.h"
#include "AI/SoldierAIController.h"
#include "HUD/QuestNativeHUD.h"
#include "Performance/SquadAIAudioSubsystem.h"
#include "SquadAITuning.h"
#include "GameFramework/Pawn.h"
#include "Kismet/GameplayStatics.h"
#include "TimerManager.h"
#include "Engine/World.h"

void USoldierRegistrySubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
	const USquadAITuning* T = USquadAITuning::Get();
	CellSize = T->RegistryCellSize;
	RebuildInterval = T->RegistryRebucketInterval;
}

void USoldierRegistrySubsystem::Deinitialize()
{
	StopRebuildTimer();
	AllSoldiers.Empty();
	Buckets.Empty();
	BroadPawns.Empty();
	Super::Deinitialize();
}

bool USoldierRegistrySubsystem::IsTickable() const
{
	return false;
}

void USoldierRegistrySubsystem::EnsureRebuildTimer()
{
	UWorld* World = GetWorld();
	if (!World || World->GetTimerManager().IsTimerActive(RebuildTimer))
	{
		return;
	}
	World->GetTimerManager().SetTimer(RebuildTimer, this, &USoldierRegistrySubsystem::RunRebuild, RebuildInterval, true);
}

void USoldierRegistrySubsystem::StopRebuildTimer()
{
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(RebuildTimer);
	}
}

void USoldierRegistrySubsystem::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void USoldierRegistrySubsystem::RunRebuild()
{
	RebuildBuckets();

	// Prune expired smoke clouds
	if (UWorld* World = GetWorld())
	{
		const float Now = World->GetTimeSeconds();
		for (int32 i = ActiveSmokeClouds.Num() - 1; i >= 0; --i)
		{
			if (ActiveSmokeClouds[i].ExpirationTime <= Now)
			{
				ActiveSmokeClouds.RemoveAtSwap(i, EAllowShrinking::No);
			}
		}
	}

	TimeSincePawnCache += RebuildInterval;
	if (BroadPawns.Num() == 0 || TimeSincePawnCache >= PawnCacheInterval)
	{
		TimeSincePawnCache = 0.f;
		RebuildBroadPawns();
	}
	if (AllSoldiers.Num() == 0 && ActiveSmokeClouds.Num() == 0)
	{
		StopRebuildTimer();
	}
}

// =====================================================================
//  REGISTRATION
// =====================================================================
void USoldierRegistrySubsystem::RegisterSoldier(ASoldierCharacter* Soldier)
{
	if (Soldier)
	{
		AllSoldiers.AddUnique(Soldier);
		EnsureRebuildTimer();
	}
}

void USoldierRegistrySubsystem::UnregisterSoldier(ASoldierCharacter* Soldier)
{
	AllSoldiers.Remove(Soldier);
	if (AllSoldiers.Num() == 0)
	{
		StopRebuildTimer();
	}
}

// =====================================================================
//  REBUILD BUCKETS — every 0.2s, re-hash all soldier positions
// =====================================================================
void USoldierRegistrySubsystem::RebuildBuckets()
{
	Buckets.Empty();

	for (int32 i = AllSoldiers.Num() - 1; i >= 0; --i)
	{
		ASoldierCharacter* S = AllSoldiers[i].Get();
		if (!S || !S->IsAlive())
		{
			AllSoldiers.RemoveAtSwap(i, EAllowShrinking::No);
			continue;
		}

		FIntPoint Cell = WorldToCell(S->GetActorLocation());
		Buckets.FindOrAdd(Cell).Soldiers.Add(S);
	}
}

// =====================================================================
//  QUERY — O(K) where K = soldiers in nearby cells
// =====================================================================
TArray<ASoldierCharacter*> USoldierRegistrySubsystem::QueryRadius(FVector Center, float Radius) const
{
	TArray<ASoldierCharacter*> Result;
	const float RadiusSq = Radius * Radius;

	TArray<FIntPoint> Cells = GetCellsInRadius(Center, Radius);
	for (const FIntPoint& Cell : Cells)
	{
		const FBucket* Bucket = Buckets.Find(Cell);
		if (!Bucket) continue;

		for (const TWeakObjectPtr<ASoldierCharacter>& WeakS : Bucket->Soldiers)
		{
			ASoldierCharacter* S = WeakS.Get();
			if (S && S->IsAlive() && FVector::DistSquared(S->GetActorLocation(), Center) <= RadiusSq)
			{
				Result.Add(S);
			}
		}
	}

	return Result;
}

// =====================================================================
//  SUPPRESSION — apply along a bullet path
// =====================================================================
void USoldierRegistrySubsystem::ApplySuppressionAlongPath(
	FVector Start, FVector End, float Radius, float Amount, AActor* Ignore)
{
	// 1. Check Player Proximity for suppression feedback (tunnel vision & audio)
	if (UWorld* World = GetWorld())
	{
		if (APawn* Player = UGameplayStatics::GetPlayerPawn(World, 0))
		{
			if (Player != Ignore)
			{
				const FVector PlayerLoc = Player->GetActorLocation();
				const float PathLen = FVector::Dist(Start, End);
				if (PathLen > 1.f)
				{
					const FVector Dir = (End - Start) / PathLen;
					const FVector ToPlayer = PlayerLoc - Start;
					const float t = FMath::Clamp(FVector::DotProduct(ToPlayer, Dir), 0.f, PathLen);
					const FVector ClosestPoint = Start + Dir * t;
					if (FVector::DistSquared(PlayerLoc, ClosestPoint) <= (Radius * Radius))
					{
						if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this))
						{
							HUD->AddPlayerSuppression(Amount);
						}
					}
				}
			}
		}
	}

	// 2. Query cells along the path line for AI soldiers
	TArray<ASoldierCharacter*> Nearby;
	
	const float PathLen = FVector::Dist(Start, End);
	if (PathLen <= 1.f) return;
	const FVector Dir = (End - Start) / PathLen;
	
	for (float Dist = 0.f; Dist <= PathLen; Dist += CellSize * 0.5f)
	{
		FVector SamplePt = Start + Dir * Dist;
		TArray<ASoldierCharacter*> CellSoldiers = QueryRadius(SamplePt, CellSize * 0.7f);
		for (ASoldierCharacter* S : CellSoldiers) Nearby.AddUnique(S);
	}

	USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this);

	for (ASoldierCharacter* S : Nearby)
	{
		if (S == Ignore || !S->IsAlive()) continue;

		const FVector SoldierLoc = S->GetActorLocation();
		
		const FVector ToSoldier = SoldierLoc - Start;
		const float t = FMath::Clamp(FVector::DotProduct(ToSoldier, Dir), 0.f, PathLen);
		
		const FVector ClosestPoint = Start + Dir * t;
		if (FVector::DistSquared(SoldierLoc, ClosestPoint) <= (Radius * Radius))
		{
			if (ASoldierAIController* AI = Cast<ASoldierAIController>(S->GetController()))
			{
				AI->AddSuppression(Amount);

				if (AI->GetSuppression() >= 0.65f && S->IsAlly() && AudioSys)
				{
					AudioSys->PlayTacticalVoiceline(ETacticalVoicelineType::Ally_UnderFire, S);
				}
			}
		}
	}
}

void USoldierRegistrySubsystem::RegisterSmokeCloud(const FVector& Location, float Radius, float Duration)
{
	UWorld* World = GetWorld();
	if (!World) return;

	FActiveSmokeCloud Cloud;
	Cloud.Location = Location;
	Cloud.Radius = Radius;
	Cloud.ExpirationTime = World->GetTimeSeconds() + Duration;

	ActiveSmokeClouds.Add(Cloud);
	EnsureRebuildTimer();

	UE_LOG(LogTemp, Log, TEXT("[SoldierRegistry] Registered tactical smoke screen at %s (Radius: %.0f, Duration: %.1fs)"),
		*Location.ToString(), Radius, Duration);
}

bool USoldierRegistrySubsystem::IsLineOfSightBlockedBySmoke(const FVector& Start, const FVector& End) const
{
	if (ActiveSmokeClouds.Num() == 0) return false;

	const float PathLen = FVector::Dist(Start, End);
	if (PathLen <= 1.f) return false;

	const FVector Dir = (End - Start) / PathLen;

	for (const FActiveSmokeCloud& Cloud : ActiveSmokeClouds)
	{
		const FVector ToCloud = Cloud.Location - Start;
		const float t = FMath::Clamp(FVector::DotProduct(ToCloud, Dir), 0.f, PathLen);
		const FVector ClosestPoint = Start + Dir * t;
		if (FVector::DistSquared(Cloud.Location, ClosestPoint) <= (Cloud.Radius * Cloud.Radius))
		{
			return true; // Ray passes directly through smoke
		}
	}

	return false;
}

// =====================================================================
//  COUNT HOSTILES — for leader area-clear check
// =====================================================================
int32 USoldierRegistrySubsystem::CountHostilesNear(
	FVector Center, float Radius, uint8 FriendlyTeamId) const
{
	int32 Count = 0;
	TArray<ASoldierCharacter*> Nearby = QueryRadius(Center, Radius);

	for (ASoldierCharacter* S : Nearby)
	{
		if (S->GetGenericTeamId().GetId() != FriendlyTeamId && S->IsAlive())
		{
			Count++;
		}
	}

	return Count;
}

// =====================================================================
//  SPATIAL HASH HELPERS
// =====================================================================
FIntPoint USoldierRegistrySubsystem::WorldToCell(FVector Pos) const
{
	return FIntPoint(
		FMath::FloorToInt(Pos.X / CellSize),
		FMath::FloorToInt(Pos.Y / CellSize)
	);
}

TArray<FIntPoint> USoldierRegistrySubsystem::GetCellsInRadius(FVector Center, float Radius) const
{
	TArray<FIntPoint> Result;
	const FIntPoint Min = WorldToCell(Center - FVector(Radius, Radius, 0));
	const FIntPoint Max = WorldToCell(Center + FVector(Radius, Radius, 0));

	for (int32 X = Min.X; X <= Max.X; ++X)
	{
		for (int32 Y = Min.Y; Y <= Max.Y; ++Y)
		{
			Result.Add(FIntPoint(X, Y));
		}
	}

	return Result;
}

void USoldierRegistrySubsystem::RebuildBroadPawns()
{
	// Full-world TActorIterator<APawn> at 1 Hz was a game-thread hitch.
	// Wave enemies are SoldierCharacter (already in AllSoldiers). The pack
	// player is the non-soldier pawn PollRegistryForHostiles needs.
	BroadPawns.Reset();
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}
	if (APawn* Player = UGameplayStatics::GetPlayerPawn(World, 0))
	{
		if (!Player->IsA<ASoldierCharacter>())
		{
			BroadPawns.Add(Player);
		}
	}
}

// SquadAIPlayerWeaponDiagnostic.cpp — Runtime diagnostic for player weapon state
#include "Performance/SquadAIPlayerWeaponDiagnostic.h"

#include "GameFramework/Character.h"
#include "GameFramework/PlayerController.h"
#include "GameFramework/PlayerInput.h"
#include "Components/InputComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/World.h"
#include "UObject/UnrealType.h"

USquadAIPlayerWeaponDiagnostic::USquadAIPlayerWeaponDiagnostic()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.bStartWithTickEnabled = false;
	PrimaryComponentTick.TickInterval = 0.25f; // Tick every 0.25s for fast detection
}

void USquadAIPlayerWeaponDiagnostic::BeginPlay()
{
	Super::BeginPlay();

	if (!GetOwner()) return;
	if (APawn* Pawn = Cast<APawn>(GetOwner()))
	{
		if (!Pawn->IsLocallyControlled())
		{
			PrimaryComponentTick.bCanEverTick = false;
			return;
		}
	}

	if (!bEnableLogging)
	{
		SetComponentTickEnabled(false);
		return;
	}

	SetComponentTickEnabled(true);
	UE_LOG(LogTemp, Warning, TEXT("[PlayerWeaponDiag] Attached to player: %s (Class: %s)"),
		*GetNameSafe(GetOwner()), GetOwner() ? *GetOwner()->GetClass()->GetName() : TEXT("NULL"));
}

void USquadAIPlayerWeaponDiagnostic::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (!bEnableLogging || !GetOwner()) return;

	TimeSinceLastLog += DeltaTime;
	if (TimeSinceLastLog >= LogInterval)
	{
		TimeSinceLastLog = 0.f;
		LogWeaponState();
	}
}

UObject* USquadAIPlayerWeaponDiagnostic::FindPlayerWeaponComponent(AActor* Owner)
{
	if (!Owner) return nullptr;

	TArray<UActorComponent*> Components;
	Owner->GetComponents(Components);

	for (UActorComponent* C : Components)
	{
		if (!C) continue;
		const FString N = C->GetName();
		const FString CN = C->GetClass() ? C->GetClass()->GetName() : FString();
		if (N.Contains(TEXT("BPC_WeaponCharacterPlayer")) || CN.Contains(TEXT("BPC_WeaponCharacterPlayer")) ||
			N.Contains(TEXT("BPC_WeaponCharacter")) || CN.Contains(TEXT("BPC_WeaponCharacter")))
		{
			return C;
		}
	}
	return nullptr;
}

// Helper to read a bool property with multiple name candidates
static bool ReadBoolProp(UObject* Obj, const TArray<FName>& Names, bool& OutValue)
{
	if (!Obj) return false;
	for (const FName& N : Names)
	{
		if (FBoolProperty* P = FindFProperty<FBoolProperty>(Obj->GetClass(), N))
		{
			OutValue = P->GetPropertyValue_InContainer(Obj);
			return true;
		}
	}
	return false;
}

// Helper to read a byte/enum property with multiple name candidates
static bool ReadByteProp(UObject* Obj, const TArray<FName>& Names, uint8& OutValue)
{
	if (!Obj) return false;
	for (const FName& N : Names)
	{
		if (FByteProperty* P = FindFProperty<FByteProperty>(Obj->GetClass(), N))
		{
			OutValue = P->GetPropertyValue_InContainer(Obj);
			return true;
		}
	}
	return false;
}

void USquadAIPlayerWeaponDiagnostic::LogWeaponState()
{
	AActor* Owner = GetOwner();
	if (!Owner) return;

	const FVector Loc = Owner->GetActorLocation();

	UObject* WeaponTarget = FindPlayerWeaponComponent(Owner);
	const bool bHasWeapon = WeaponTarget != nullptr;

	bool bIsShooting = false;
	bool bIsAiming = false;
	int32 AimingState = -1;
	int32 Ammo = -1;
	FString ActiveWeapon = TEXT("NONE");
	bool bLeftHandIK = false;
	bool bTooCloseToWall = false;
	bool bIgnoreCloseWallCheck = false;
	bool bFiredSuccessfully = false;
	int32 GroundState = -1;
	int32 WeaponAnimState = -1;
	bool bIsRagdoll = false;
	bool bIsWeaponUsable = false;

	if (WeaponTarget)
	{
		ReadBoolProp(WeaponTarget, { TEXT("bIsShooting?"), TEXT("bIsShooting"), TEXT("IsShooting") }, bIsShooting);

		uint8 AimByte = 0;
		if (ReadByteProp(WeaponTarget, { TEXT("aimingState"), TEXT("AimingState") }, AimByte))
		{
			AimingState = AimByte;
			bIsAiming = AimByte > 0;
		}

		// Ammo
		for (const FName& N : { FName(TEXT("Ammo Clip Current")), FName(TEXT("AmmoClipCurrent")), FName(TEXT("ClipAmmo")) })
		{
			if (FIntProperty* P = FindFProperty<FIntProperty>(WeaponTarget->GetClass(), N))
			{
				Ammo = P->GetPropertyValue_InContainer(WeaponTarget);
				break;
			}
		}

		// Active Weapon
		for (const FName& N : { FName(TEXT("Active Weapon")), FName(TEXT("ActiveWeapon")) })
		{
			if (FNameProperty* P = FindFProperty<FNameProperty>(WeaponTarget->GetClass(), N))
			{
				ActiveWeapon = P->GetPropertyValue_InContainer(WeaponTarget).ToString();
				break;
			}
			if (FStrProperty* P = FindFProperty<FStrProperty>(WeaponTarget->GetClass(), N))
			{
				ActiveWeapon = P->GetPropertyValue_InContainer(WeaponTarget);
				break;
			}
		}

		ReadBoolProp(WeaponTarget, { TEXT("bLeftHandIK?"), TEXT("bLeftHandIK"), TEXT("Left Hand IK") }, bLeftHandIK);

		// CRITICAL: Check wall blocking — TPWCS properties end with '?'
		ReadBoolProp(WeaponTarget, {
			TEXT("bIsTooCloseToWall?"), TEXT("Is Too Close To Wall?"), TEXT("IsTooCloseToWall"), TEXT("bIsTooCloseToWall"),
			TEXT("TooCloseToWall"), TEXT("bTooCloseToWall")
		}, bTooCloseToWall);

		ReadBoolProp(WeaponTarget, {
			TEXT("bIgnoreCloseWallCheck?"), TEXT("Ignore Close Wall Check"), TEXT("IgnoreCloseWallCheck"), TEXT("bIgnoreCloseWallCheck")
		}, bIgnoreCloseWallCheck);

		ReadBoolProp(WeaponTarget, {
			TEXT("bFiredSuccesfully?"), TEXT("Fired Successfully?"), TEXT("FiredSuccessfully"), TEXT("bFiredSuccessfully")
		}, bFiredSuccessfully);

		uint8 GS = 0;
		if (ReadByteProp(WeaponTarget, { TEXT("Ground State"), TEXT("GroundState") }, GS))
			GroundState = GS;

		uint8 WAS = 0;
		if (ReadByteProp(WeaponTarget, { TEXT("Weapon Anim State"), TEXT("WeaponAnimState") }, WAS))
			WeaponAnimState = WAS;

		ReadBoolProp(WeaponTarget, {
			TEXT("Is Ragdoll Active?"), TEXT("IsRagdollActive"), TEXT("bIsRagdollActive")
		}, bIsRagdoll);

		ReadBoolProp(WeaponTarget, {
			TEXT("Is Weapon Usable?"), TEXT("IsWeaponUsable"), TEXT("bIsWeaponUsable")
		}, bIsWeaponUsable);
	}

	// Also check player controller state
	bool bInputEnabled = true;
	FString ControllerName = TEXT("NONE");
	if (APawn* Pawn = Cast<APawn>(Owner))
	{
		bInputEnabled = Pawn->GetController() != nullptr;
		if (APlayerController* PC = Cast<APlayerController>(Pawn->GetController()))
		{
			ControllerName = PC->GetName();
		}
	}

	// Detect state changes
	const bool bStateChanged = (bHasWeapon != bLastHadWeapon) || (bIsAiming != bLastWasAiming) || (bIsShooting != bLastWasShooting);

	if (bStateChanged || bEnableLogging)
	{
		UE_LOG(LogTemp, Warning, TEXT("[PlayerWeaponDiag] Player=%s Loc=(%.0f,%.0f,%.0f) Weapon=%s Ammo=%d Aim=%d Shoot=%d Ground=%d Wall=%d IgnoreWall=%d Input=%d Ragdoll=%d Usable=%d Ctrl=%s"),
			*GetNameSafe(Owner),
			Loc.X, Loc.Y, Loc.Z,
			*ActiveWeapon,
			Ammo,
			AimingState,
			bIsShooting ? 1 : 0,
			GroundState,
			bTooCloseToWall ? 1 : 0,
			bIgnoreCloseWallCheck ? 1 : 0,
			bInputEnabled ? 1 : 0,
			bIsRagdoll ? 1 : 0,
			bIsWeaponUsable ? 1 : 0,
			*ControllerName);

		if (bStateChanged)
		{
			UE_LOG(LogTemp, Error, TEXT("[PlayerWeaponDiag] *** STATE CHANGE *** HadWeapon=%d->%d Aiming=%d->%d Shooting=%d->%d Loc=(%.0f,%.0f,%.0f)"),
				bLastHadWeapon ? 1 : 0, bHasWeapon ? 1 : 0,
				bLastWasAiming ? 1 : 0, bIsAiming ? 1 : 0,
				bLastWasShooting ? 1 : 0, bIsShooting ? 1 : 0,
				Loc.X, Loc.Y, Loc.Z);
		}

		if (bLogDetailedProperties && WeaponTarget)
		{
			LogDetailedWeaponProperties(WeaponTarget);
		}
	}

	bLastHadWeapon = bHasWeapon;
	bLastWasAiming = bIsAiming;
	bLastWasShooting = bIsShooting;
	LastLogLocation = Loc;
}

void USquadAIPlayerWeaponDiagnostic::LogDetailedWeaponProperties(UObject* WeaponTarget)
{
	if (!WeaponTarget) return;

	UE_LOG(LogTemp, Warning, TEXT("[PlayerWeaponDiag] === ALL Properties on %s ==="), *GetNameSafe(WeaponTarget));

	// Scan ALL properties on the weapon component for anything that looks blocking
 UClass* TargetClass = WeaponTarget->GetClass();
	for (TFieldIterator<FProperty> It(TargetClass); It; ++It)
	{
		FProperty* P = *It;
		if (!P) continue;

		const FString PropName = P->GetName();

		// Log properties that might be blocking
		if (PropName.Contains(TEXT("TooClose"), ESearchCase::IgnoreCase) ||
			PropName.Contains(TEXT("Wall"), ESearchCase::IgnoreCase) ||
			PropName.Contains(TEXT("Block"), ESearchCase::IgnoreCase) ||
			PropName.Contains(TEXT("Disable"), ESearchCase::IgnoreCase) ||
			PropName.Contains(TEXT("Enable"), ESearchCase::IgnoreCase) ||
			PropName.Contains(TEXT("Can"), ESearchCase::IgnoreCase) ||
			PropName.Contains(TEXT("Usable"), ESearchCase::IgnoreCase) ||
			PropName.Contains(TEXT("Range"), ESearchCase::IgnoreCase) ||
			PropName.Contains(TEXT("Distance"), ESearchCase::IgnoreCase) ||
			PropName.Contains(TEXT("Input"), ESearchCase::IgnoreCase) ||
			PropName.Contains(TEXT("Fire"), ESearchCase::IgnoreCase) ||
			PropName.Contains(TEXT("Shoot"), ESearchCase::IgnoreCase))
		{
			FString ValueStr;
			const void* ValuePtr = P->ContainerPtrToValuePtr<void>(WeaponTarget);
			P->ExportTextItem_Direct(ValueStr, ValuePtr, nullptr, nullptr, PPF_None);
			UE_LOG(LogTemp, Warning, TEXT("[PlayerWeaponDiag]   [MATCH] %s : %s = %s"), *P->GetCPPType(), *PropName, *ValueStr);
		}
	}
}

#include "Performance/SquadAICinematicCombatSubsystem.h"
#include "Characters/SoldierCharacter.h"
#include "Performance/SquadAIAudioSubsystem.h"
#include "Actors/SquadAIAudioManager.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/World.h"
#include "Engine/Engine.h"
#include "TimerManager.h"

void USquadAICinematicCombatSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
	UE_LOG(LogTemp, Log, TEXT("[SquadAICinematicCombatSubsystem] Cinematic Combat & Slow-Motion Subsystem Initialized"));
}

void USquadAICinematicCombatSubsystem::Deinitialize()
{
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(SlowMoTimerHandle);
		UGameplayStatics::SetGlobalTimeDilation(World, 1.0f);
	}
	Super::Deinitialize();
}

USquadAICinematicCombatSubsystem* USquadAICinematicCombatSubsystem::Get(const UObject* WorldContextObject)
{
	if (!WorldContextObject) return nullptr;
	UWorld* World = GEngine ? GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::ReturnNull) : nullptr;
	return World ? World->GetSubsystem<USquadAICinematicCombatSubsystem>() : nullptr;
}

void USquadAICinematicCombatSubsystem::TriggerCinematicHeroMoment(float Dilation, float Duration)
{
	UWorld* World = GetWorld();
	if (!World) return;

	UGameplayStatics::SetGlobalTimeDilation(World, FMath::Clamp(Dilation, 0.1f, 1.0f));

	World->GetTimerManager().ClearTimer(SlowMoTimerHandle);
	// Convert real-time duration to scaled world time duration
	const float ScaledDuration = Duration * Dilation;
	World->GetTimerManager().SetTimer(SlowMoTimerHandle, this, &USquadAICinematicCombatSubsystem::RestoreTimeDilation, ScaledDuration, false);

	USoundBase* Snd = VictoryStingerSound;
	if (!Snd)
	{
		if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
		{
			if (ASquadAIAudioManager* Mgr = AudioSys->GetActiveAudioManager())
			{
				Snd = Mgr->VictoryStingerSound.Get();
			}
		}
	}

	if (Snd)
	{
		UGameplayStatics::PlaySound2D(World, Snd, 1.0f);
	}
}

void USquadAICinematicCombatSubsystem::NotifyEnemyEliminated(ASoldierCharacter* DeadSoldier, bool bWasHeadshot, bool bWasLastEnemyInArea)
{
	if (!bEnableLastKillSlowMo) return;
	// P1-4: zone-owned last-kill passes no soldier (nullptr + last flag); the pawn was
	// only ever null-checked, never used.
	if (!DeadSoldier && !bWasLastEnemyInArea) return;

	if (bWasLastEnemyInArea)
	{
		TriggerCinematicHeroMoment(SlowMoTimeDilation, SlowMoDurationSeconds);
		UE_LOG(LogTemp, Log, TEXT("[CinematicCombat] Last enemy neutralized! Triggered cinematic victory moment!"));
	}
}

void USquadAICinematicCombatSubsystem::RestoreTimeDilation()
{
	if (UWorld* World = GetWorld())
	{
		UGameplayStatics::SetGlobalTimeDilation(World, 1.0f);
	}
}

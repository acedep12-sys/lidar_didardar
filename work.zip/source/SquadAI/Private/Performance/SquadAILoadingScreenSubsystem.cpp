#include "Performance/SquadAILoadingScreenSubsystem.h"
#include "Utilities/SquadAIAssetHelper.h"
#include "Localization/SquadAILocalizationSubsystem.h"
#include "HUD/SquadAILoadingScreenWidget.h"
#include "Blueprint/UserWidget.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/World.h"
#include "Engine/Engine.h"
#include "Engine/LevelStreaming.h"
#include "Containers/Ticker.h"
#include "HUD/QuestNativeHUD.h"

namespace
{
	bool SquadAILoadingIsEnglish(const UObject* Context)
	{
		if (const USquadAILocalizationSubsystem* Loc = USquadAILocalizationSubsystem::Get(Context))
		{
			// P7-L4: non-Persian languages (en, ar) use the English-facing defaults.
			return !Loc->GetCurrentLanguage().StartsWith(TEXT("fa"), ESearchCase::IgnoreCase);
		}
		return false;
	}
}

void USquadAILoadingScreenSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
	PopulateCombatTips();
	bIsLoading = false;
	// P1-6: widgets die at OpenLevel — re-create the screen when the destination world initializes.
	PostLoadMapHandle = FWorldDelegates::OnPostWorldInitialization.AddUObject(this, &USquadAILoadingScreenSubsystem::HandlePostLoadMap);

	if (!DefaultBackgroundArtwork)
	{
		DefaultBackgroundArtwork = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Loading_Background_TrenchAssault.Loading_Background_TrenchAssault"), TEXT("Textures/Loading_Background_TrenchAssault.png"));
	}

	UE_LOG(LogTemp, Log, TEXT("[SquadAILoadingScreen] Initialized Tactical Loading Screen Subsystem"));
}

void USquadAILoadingScreenSubsystem::Deinitialize()
{
	FWorldDelegates::OnPostWorldInitialization.Remove(PostLoadMapHandle);
	FTSTicker::GetCoreTicker().RemoveTicker(DeferredTravelHandle);
	Handoff.Cancel(); // S19-INSTANT: a teardown must never leave a transition pending
	if (UWorld* HW = HandshakeWorld.Get()) HW->GetTimerManager().ClearTimer(DestinationHandshakeHandle);
	HandshakeWorld = nullptr;
	HideLoadingScreen(0.f);
	Super::Deinitialize();
}

USquadAILoadingScreenSubsystem* USquadAILoadingScreenSubsystem::Get(const UObject* WorldContextObject)
{
	if (!WorldContextObject) return nullptr;
	UGameInstance* GI = UGameplayStatics::GetGameInstance(WorldContextObject);
	return GI ? GI->GetSubsystem<USquadAILoadingScreenSubsystem>() : nullptr;
}

void USquadAILoadingScreenSubsystem::PopulateCombatTips()
{
	TacticalCombatTips.Empty();
	const bool bEnglish = SquadAILoadingIsEnglish(this);
	TacticalCombatTips.Add(FText::FromString(bEnglish ? TEXT("Tactical tip: suppressive fire sharply reduces enemy accuracy and forces them behind sandbags.") : TEXT("نکته تاکتیکی: آتش سرکوبگر دقت دشمن را به شدت کاهش داده و آن‌ها را مجبور به پناه گرفتن در پشت گونی‌های شنی می‌کند.")));
	TacticalCombatTips.Add(FText::FromString(bEnglish ? TEXT("Tactical tip: smoke grenades create an 18-second visual screen against snipers and DShK nests.") : TEXT("نکته تاکتیکی: نارنجک‌های دودزا یک پرده دید ۱۸ ثانیه‌ای غیرقابل نفوذ در برابر تک‌تیراندازها و سنگرهای دوشکا ایجاد می‌کنند.")));
	TacticalCombatTips.Add(FText::FromString(bEnglish ? TEXT("Tactical tip: hold [E] near wounded squadmates to revive and assist them.") : TEXT("نکته تاکتیکی: برای امدادرسانی و احیای همرزمان مجروح جوخه، کلید [E] را در نزدیکی آن‌ها نگه دارید.")));
	TacticalCombatTips.Add(FText::FromString(bEnglish ? TEXT("Tactical tip: a mounted heavy machine gun provides continuous suppressive fire to stabilize the defensive line.") : TEXT("نکته تاکتیکی: تیربار سنگین مستقر، آتش سرکوبگر پرحجم و پیوسته را برای تثبیت خط دفاعی فراهم می‌سازد.")));
	TacticalCombatTips.Add(FText::FromString(bEnglish ? TEXT("Tactical tip: ammunition crates and first-aid kits are inside trenches — resupply before advancing.") : TEXT("نکته تاکتیکی: جعبه‌های مهمات و بسته‌های امدادی در سنگرها قرار دارند — پیش از پیشروی خشاب‌ها را پر کنید.")));
	TacticalCombatTips.Add(FText::FromString(bEnglish ? TEXT("Tactical tip: hold [V] to reveal the safest illuminated route toward the objective.") : TEXT("نکته تاکتیکی: با فشردن و نگه‌داشتن کلید [V]، مسیر راهنمای نورانی امن‌ترین راه به سمت نقطه هدف را نشان می‌دهد.")));
	TacticalCombatTips.Add(FText::FromString(bEnglish ? TEXT("Tactical tip: fuel barrel explosions can break mud-brick walls and enemy machine-gun positions.") : TEXT("نکته تاکتیکی: انفجار بشکه‌های سوخت می‌تواند دیوارهای خشتی و مواضع تیربار دشمن را منهدم کند.")));
	TacticalCombatTips.Add(FText::FromString(bEnglish ? TEXT("Tactical tip: middle-click to place a 3D marker for guiding Major Rostami and the squad to tactical positions.") : TEXT("نکته تاکتیکی: با کلیک وسط ماوس، نشانگر سه‌بعدی برای هدایت سرگرد رستمی و جوخه به موقعیت‌های تاکتیکی قرار دهید.")));
}

FText USquadAILoadingScreenSubsystem::GetRandomTacticalTip() const
{
	// L2-INI: the file's Loading/Tip1..Tip7 pool is now LIVE (was a decoy — no code read it).
	// INI tips take precedence; the compiled-in tips stay as the fallback pool when the file
	// defines nothing (and as the non-Persian fallback via the built-in English table).
	if (const USquadAILocalizationSubsystem* Loc = USquadAILocalizationSubsystem::Get(this))
	{
		TArray<FText> IniTips;
		for (int32 i = 1; i <= 7; ++i)
		{
			const FString IniTip = Loc->GetString(TEXT("Loading"), FString::Printf(TEXT("Tip%d"), i), TEXT(""));
			if (!IniTip.IsEmpty()) { IniTips.Add(FText::FromString(IniTip)); }
		}
		if (IniTips.Num() > 0)
		{
			return IniTips[FMath::RandRange(0, IniTips.Num() - 1)];
		}
	}
	if (TacticalCombatTips.Num() == 0) return FText::FromString(TEXT("Prepare for battle."));
	const int32 Index = FMath::RandRange(0, TacticalCombatTips.Num() - 1);
	return TacticalCombatTips[Index];
}

void USquadAILoadingScreenSubsystem::StartDeploymentTransition(FName LevelName, FName MapOrSectorID)
{
	PopulateCombatTips();
	const bool bEnglish = SquadAILoadingIsEnglish(this);
	FText SectorTitle = FText::FromString(bEnglish ? TEXT("Khuzestan Operational Sector") : TEXT("منطقه عملیاتی خوزستان"));
	FText SectorBriefing = FText::FromString(bEnglish ? TEXT("Advance through Dehlavieh forward trenches and stabilize the defensive line beside Major Shahid Iraj Rostami.") : TEXT("پیشروی در سنگرهای خط مقدم دهلاویه و تثبیت خط پدافندی با همراهی شهید سرگرد ایرج رستمی."));

	const FString IDStr = MapOrSectorID.ToString();
	if (IDStr.Contains(TEXT("Dehlavieh")) || IDStr.Contains(TEXT("Karkheh")))
	{
		SectorTitle = FText::FromString(bEnglish ? TEXT("Dehlavieh and Karkheh River Axis") : TEXT("محور دهلاویه و رودخانه کرخه"));
		SectorBriefing = FText::FromString(bEnglish ? TEXT("Advance through the Dehlavieh forward trenches, destroy enemy heavy machine-gun positions, and stabilize the defensive line.") : TEXT("پیشروی در سنگرهای خط مقدم دهلاویه، انهدام مواضع تیربار سنگین دشمن و تثبیت خط پدافندی."));
	}
	else if (IDStr.Contains(TEXT("Bostan")) || IDStr.Contains(TEXT("Chazzabeh")))
	{
		SectorTitle = FText::FromString(bEnglish ? TEXT("Bostan and Chazzabeh Pass Axis") : TEXT("محور بستان و تنگه چزابه"));
		SectorBriefing = FText::FromString(bEnglish ? TEXT("Liberate Bostan and seal the Chazzabeh infiltration route across the dune fields.") : TEXT("آزادسازی بستان و بستن معبر نفوذی تنگه چزابه در میان تپه‌های رملی."));
	}
	else if (IDStr.Contains(TEXT("Khorramshahr")) || IDStr.Contains(TEXT("Arvand")))
	{
		SectorTitle = FText::FromString(bEnglish ? TEXT("Khorramshahr and Arvand River") : TEXT("خرمشهر و اروندرود"));
		SectorBriefing = FText::FromString(bEnglish ? TEXT("Urban combat through alleys, the Grand Mosque, and the customs district to block enemy armored units.") : TEXT("نبرد شهری در کوچه‌ها، مسجد جامع و گمرک خرمشهر و سد معبر پیشروی یگان‌های زرهی."));
	}

	LoadLevelWithScreen(LevelName, SectorTitle, SectorBriefing);
}

void USquadAILoadingScreenSubsystem::LoadLevelWithScreen(
	FName LevelName,
	FText SectorTitle,
	FText MissionBriefing,
	TSubclassOf<UUserWidget> CustomLoadingWidgetClass)
{
	UWorld* World = GetWorld();
	if (!World || LevelName.IsNone()) return;

	bIsLoading = true;
	PopulateCombatTips();
	const bool bEnglish = SquadAILoadingIsEnglish(this);
	CurrentSectorTitle = SectorTitle.IsEmpty() ? FText::FromString(bEnglish ? TEXT("Khuzestan Operational Sector - Dehlavieh Front Line") : TEXT("منطقه عملیاتی خوزستان - خط مقدم دهلاویه")) : SectorTitle;
	CurrentMissionBriefing = MissionBriefing.IsEmpty() ? FText::FromString(bEnglish ? TEXT("Advancing through the forward trenches, destroying enemy heavy machine-gun positions, and stabilizing the defensive line with Major Rostami and the squad.") : TEXT("پیشروی در سنگرهای خط مقدم، انهدام مواضع تیربار سنگین دشمن و تثبیت خط پدافندی با سرگرد رستمی و جوخه.")) : MissionBriefing;
	CurrentCombatTip = GetRandomTacticalTip();

	// S19-INSTANT: the screen the player sees is drawn by whichever canvas HUD is
	// live in this world (the menu HUD in the menu, the gameplay veil in a
	// mission); the UMG widget is an opt-in overlay and a class with no widget
	// tree is refused, because an invisible full-screen widget is exactly the
	// trap this round removed.
	PendingWidgetClass = CustomLoadingWidgetClass ? CustomLoadingWidgetClass : LoadingScreenWidgetClass;
	SpawnLoadingWidget(World);

	Handoff.BeginDeparture();
	LastHandoffSeconds = 0.f; // the ticker's fallback test starts from the new clock

	OnLoadingScreenShown.Broadcast();
	UE_LOG(LogTemp, Log, TEXT("[SquadAILoadingScreen] Displayed loading screen for level '%s'"), *LevelName.ToString());

	// P7-LD1 + S19-INSTANT: paint BEFORE the blocking travel. The old code fired OpenLevel
	// in the very same frame, so the loading screen rendered ~0 frames — the menu world
	// visibly froze ("thinking" pause) during the synchronous map load and the screen only
	// appeared afterwards. P7 showed the screen and travelled 0.25 s later, but the screen it
	// showed was a widget that draws nothing in C++; S19 makes the live HUD draw the screen
	// and makes this travel WAIT for that paint (Handoff), so the freeze always happens
	// behind the loading screen. The core TS ticker survives travel.
	HandshakeElapsed = 0.f;
	HandshakeSettleElapsed = 0.f;
	HandshakeWorld = nullptr;
	PendingTravelLevel = LevelName;
	FTSTicker::GetCoreTicker().RemoveTicker(DeferredTravelHandle);
	DeferredTravelHandle = FTSTicker::GetCoreTicker().AddTicker(
		FTickerDelegate::CreateUObject(this, &USquadAILoadingScreenSubsystem::FireDeferredTravel),
		0.25f);
}

bool USquadAILoadingScreenSubsystem::FireDeferredTravel(float DeltaTime)
{
	// S19-INSTANT: this runs every 0.25 s until the gate opens (the screen has been
	// painted, and the defer window has passed), or until the hard timeout fires the
	// travel anyway. See SquadAILoadingHandoffModel.h.
	//
	// This ticker is the FALLBACK clock. While the live HUD draws the departure screen it
	// calls TickTransition() once per frame, so the bar fills at frame rate - adding this
	// 0.25 s here as well would count the same wall time twice. The test is simply whether
	// the clock moved since our last visit: if it did, a HUD is driving; if it did not,
	// nothing is drawing (a BP HUD, a headless run, a paused game) and the hard timeout
	// must still be reachable, or the travel would never fire.
	if (Handoff.ElapsedSeconds <= LastHandoffSeconds)
	{
		Handoff.Tick(DeltaTime);
	}
	LastHandoffSeconds = Handoff.ElapsedSeconds;

	const FName TravelTarget = PendingTravelLevel;
	if (TravelTarget.IsNone() || !bIsLoading)
	{
		Handoff.Cancel();
		return false;
	}
	if (!Handoff.ShouldFireTravel())
	{
		// The screen is up (or is about to be) but the player has not seen it yet.
		// Keep ticking: the game stays in the source world for a few more frames
		// INSTEAD of blocking inside OpenLevel with the menu still on screen.
		if (Handoff.PaintedFrames == 0)
		{
			UE_LOG(LogTemp, Log, TEXT("[SquadAILoadingScreen] Travel to '%s' held: waiting for the departure screen to be painted (%.2fs of %.2fs)."),
				*TravelTarget.ToString(), Handoff.ElapsedSeconds, FSquadAILoadingHandoff::HardTimeoutSeconds);
		}
		return true;
	}

	UWorld* World = GetWorld();
	if (!World)
	{
		Handoff.Cancel();
		bIsLoading = false;
		return false;
	}

	UE_LOG(LogTemp, Log, TEXT("[SquadAILoadingScreen] Travelling to '%s' now: screen painted %d time(s) over %.2fs."),
		*TravelTarget.ToString(), Handoff.PaintedFrames, Handoff.ElapsedSeconds);

	PendingTravelLevel = NAME_None;
	Handoff.MarkTravelled();

	// P1-6: the widget belongs to the OLD world — OpenLevel destroys it. Null our ref
	// (never deref post-travel); HandlePostLoadMap re-creates it at the destination.
	ActiveLoadingWidget = nullptr;
	UGameplayStatics::OpenLevel(World, TravelTarget);
	return false; // one-shot
}

bool USquadAILoadingScreenSubsystem::IsDeparturePending() const
{
	return Handoff.IsDeparturePending() && !PendingTravelLevel.IsNone();
}

void USquadAILoadingScreenSubsystem::NotifyDepartureScreenPainted()
{
	Handoff.NotifyScreenPainted();
}

void USquadAILoadingScreenSubsystem::TickTransition(float DeltaSeconds)
{
	// One drawn frame's worth of transition time (see the header). Clamped inside the
	// model, so a hitch cannot push the bar or the gate past what a frame means.
	Handoff.Tick(DeltaSeconds);
}

float USquadAILoadingScreenSubsystem::GetTransitionProgress() const
{
	return Handoff.GetProgress();
}

void USquadAILoadingScreenSubsystem::SpawnLoadingWidget(UWorld* World)
{
	// S19-INSTANT: no class configured -> nothing to spawn. The canvas HUDs draw the
	// loading screen, so an empty widget class here would only add an invisible
	// full-screen overlay (and the false impression that a screen was shown).
	if (!World || !PendingWidgetClass) return;
	if (APlayerController* PC = World->GetFirstPlayerController())
	{
		ActiveLoadingWidget = CreateWidget<UUserWidget>(PC, PendingWidgetClass);
		if (ActiveLoadingWidget)
		{
			if (USquadAILoadingScreenWidget* Screen = Cast<USquadAILoadingScreenWidget>(ActiveLoadingWidget))
			{
				Screen->SetLoadingContent(CurrentSectorTitle, CurrentMissionBriefing, CurrentCombatTip);
				Screen->bRequirePlayerInputToDeploy = bRequirePlayerInputToDeploy;
				if (DefaultBackgroundArtwork) Screen->BackgroundArtwork = DefaultBackgroundArtwork;
				if (DefaultBackgroundMaterial) Screen->BackgroundMaterial = DefaultBackgroundMaterial;
				if (DeployConfirmationSound) Screen->DeployConfirmationSound = DeployConfirmationSound;
			}
		// S19-INSTANT: a widget with no widget tree draws nothing. Refuse it here,
		// loudly, instead of shipping an invisible screen and a log line that claims
		// the player was shown one.
		if (ActiveLoadingWidget->GetRootWidget() == nullptr)
		{
			UE_LOG(LogTemp, Warning, TEXT("[SquadAILoadingScreen] Loading widget class '%s' has no widget tree — it would draw nothing, so it was not used. The canvas HUD draws the loading screen; set LoadingScreenWidgetClass to a Blueprint if you want a custom one."),
				*PendingWidgetClass->GetName());
			ActiveLoadingWidget = nullptr;
			return;
		}
		ActiveLoadingWidget->AddToViewport(1000); // Top-priority Z-Order
		// P6-6: exempt our own widget from the foreign-UMG suppression sweep in the HUD.
		AQuestNativeHUD::RegisterAllowedViewportWidget(ActiveLoadingWidget);
	}
}
}

void USquadAILoadingScreenSubsystem::HandlePostLoadMap(UWorld* LoadedWorld, UWorld::InitializationValues)
{
	// P1-6: travel-surviving layer — the pre-travel widget died with the old world.
	// Re-create it in the destination world and start the readiness handshake.
	// (No OnLoadingScreenShown re-broadcast: one logical show per transition.)
	if (!bIsLoading || !LoadedWorld) return;
	HandshakeWorld = LoadedWorld;
	HandshakeElapsed = 0.f;
	SpawnLoadingWidget(LoadedWorld);
	LoadedWorld->GetTimerManager().SetTimer(DestinationHandshakeHandle, this,
		&USquadAILoadingScreenSubsystem::PollDestinationReady, 0.25f, true);
}

void USquadAILoadingScreenSubsystem::PollDestinationReady()
{
	UWorld* World = HandshakeWorld.Get();
	if (!bIsLoading || !World)
	{
		// Double-travel strands this poll: the timer dies with its world. Just release.
		HandshakeWorld = nullptr;
		return;
	}
	HandshakeElapsed += 0.25f;
	APlayerController* PC = World->GetFirstPlayerController();

	// P6-7: the post-travel spawn could race PlayerController creation and silently produce
	// NO loading screen. Retry each poll until the widget exists.
	if (!ActiveLoadingWidget)
	{
		SpawnLoadingWidget(World);
	}

	// P7-LD2: hold the screen until the destination is GENUINELY ready, not just begun —
	// the old 1-second release dropped the player into a world that was still spawning
	// waves, baking cover, streaming and compiling shaders (the first-seconds FPS drop).
	const bool bCoreReady = World->HasBegunPlay() && PC != nullptr;
	bool bStreamingSettled = true;
	for (ULevelStreaming* SL : World->GetStreamingLevels())
	{
		if (SL && SL->ShouldBeLoaded() && !(SL->IsLevelLoaded() && SL->IsLevelVisible()))
		{
			bStreamingSettled = false;
			break;
		}
	}
	// Pawn requirement: gameplay destinations possess one quickly; menu destinations
	// never do, so the pawn becomes optional after 6 s (return-to-menu is unaffected).
	const bool bPawnReady = (PC && PC->GetPawn() != nullptr) || HandshakeElapsed >= 6.f;
	const bool bAllReady = bCoreReady && bStreamingSettled && bPawnReady;
	HandshakeSettleElapsed = bAllReady ? (HandshakeSettleElapsed + 0.25f) : 0.f;
	// Extra settle: once everything is ready, give spawners / cover bake / shader
	// first-use a final buffer behind the loading screen before releasing.
	if ((bAllReady && HandshakeSettleElapsed >= 2.0f && HandshakeElapsed >= 3.0f) || HandshakeElapsed >= 30.f)
	{
		World->GetTimerManager().ClearTimer(DestinationHandshakeHandle);
		HandshakeWorld = nullptr;
		HandshakeSettleElapsed = 0.f;
		MarkLoadingComplete();
	}
}

void USquadAILoadingScreenSubsystem::MarkLoadingComplete()
{
	// P1-6: destination handshake entry (auto-called by the poll; still BlueprintCallable
	// for manual override). IsValid guards the travel window.
	if (USquadAILoadingScreenWidget* Screen = Cast<USquadAILoadingScreenWidget>(ActiveLoadingWidget))
	{
		if (IsValid(Screen))
		{
			Screen->MarkLoadingComplete();
			return;
		}
	}
	HideLoadingScreen(0.8f);
}

void USquadAILoadingScreenSubsystem::HideLoadingScreen(float FadeDuration)
{
	bIsLoading = false;
	if (UWorld* HW = HandshakeWorld.Get()) HW->GetTimerManager().ClearTimer(DestinationHandshakeHandle);
	HandshakeWorld = nullptr;
	if (ActiveLoadingWidget)
	{
		ActiveLoadingWidget->RemoveFromParent();
		ActiveLoadingWidget = nullptr;
	}
	OnLoadingScreenHidden.Broadcast();
	UE_LOG(LogTemp, Log, TEXT("[SquadAILoadingScreen] Dismissed tactical loading screen"));
}

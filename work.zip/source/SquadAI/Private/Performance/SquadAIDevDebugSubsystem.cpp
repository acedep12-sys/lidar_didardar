#include "Performance/SquadAIDevDebugSubsystem.h"
#include "HUD/FarsiTextHelper.h"
#include "Utilities/SquadAIAssetHelper.h"
#include "Performance/SquadAIAudioSubsystem.h"
#include "Characters/SoldierCharacter.h"
#include "Characters/LeaderCharacter.h"
#include "Characters/AllySoldier.h"
#include "Characters/EnemySoldier.h"
#include "Components/HealthComponent.h"
#include "Components/WeaponComponent.h"
#include "Components/TacticalGrenadeComponent.h"
#include "Actors/FirstAidKitActor.h"
#include "Actors/AmmoCrateActor.h"
#include "Actors/SquadAIAutoSetupManager.h"
#include "Quest/QuestChain.h"
#include "Quest/MissionZone.h"
#include "Quest/SandstormWeatherDirector.h"
#include "Tactical/SquadAIFireSupportSubsystem.h"
#include "Tactical/SquadAIRadioChatterSubsystem.h"
#include "Environment/DestroyedBuildingActor.h"
#include "Kismet/GameplayStatics.h"
#include "GameFramework/PlayerController.h"
#include "Engine/World.h"
#include "Engine/Engine.h"
#include "EngineUtils.h"

void USquadAIDevDebugSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
	UE_LOG(LogTemp, Log, TEXT("[SquadAIDevDebugSubsystem] Developer Debug & Cheat Subsystem Initialized (Hotkeys F1-F7 active in PIE)"));
#if UE_BUILD_DEBUG || UE_BUILD_DEVELOPMENT
	// P1-P1: audit on boot in dev only — Test/Shipping call SquadAI.CheckAssets on demand (Exec UFUNCTION).
	AuditGameAssets();
#endif
}

void USquadAIDevDebugSubsystem::AuditGameAssets()
{
	struct FAssetCheckEntry
	{
		FString Category;
		FString FriendlyName;
		FString AssetPath;
	};

	TArray<FAssetCheckEntry> RequiredAssets = {
		// 1. Backgrounds & Loading
		{ TEXT("Backgrounds"), TEXT("Menu Background Desert War"), TEXT("/Game/Textures/Menu_Background_KhuzestanDesertWar") },
		{ TEXT("Backgrounds"), TEXT("Loading Trench Assault"), TEXT("/Game/Textures/Loading_Background_TrenchAssault") },
		{ TEXT("Backgrounds"), TEXT("Player Progression Art"), TEXT("/Game/Textures/UI_Player_Progression_Art") },

		// 2. Soldier Avatars
		{ TEXT("Avatars"), TEXT("Major Shahid Rostami"), TEXT("/Game/Textures/UI_Avatar_ShahidRostami") },
		{ TEXT("Avatars"), TEXT("Guerrilla Fighter"), TEXT("/Game/Textures/UI_Avatar_GuerrillaHunter") },
		{ TEXT("Avatars"), TEXT("Artesh Paratrooper"), TEXT("/Game/Textures/UI_Avatar_ArteshParatrooper") },
		{ TEXT("Avatars"), TEXT("Young Basiji"), TEXT("/Game/Textures/UI_Avatar_YoungBasiji") },

		// 3. Map Previews
		{ TEXT("Maps"), TEXT("Dehlavieh & Karkheh"), TEXT("/Game/Textures/Map_Preview_Dehlavieh_Karkheh") },
		{ TEXT("Maps"), TEXT("Bostan & Chazzabeh"), TEXT("/Game/Textures/Map_Preview_Bostan_Chazzabeh") },
		{ TEXT("Maps"), TEXT("Khorramshahr & Arvand"), TEXT("/Game/Textures/Map_Preview_Khorramshahr_Arvand") },

		// 4. Weapon Previews
		{ TEXT("Weapons"), TEXT("AK-47 Showcase"), TEXT("/Game/Textures/Weapon_Preview_AK47") },
		{ TEXT("Weapons"), TEXT("G3A3 Showcase"), TEXT("/Game/Textures/Weapon_Preview_G3A3") },
		{ TEXT("Weapons"), TEXT("MG3 Showcase"), TEXT("/Game/Textures/Weapon_Preview_MG3") },
		{ TEXT("Weapons"), TEXT("RPG-7 Showcase"), TEXT("/Game/Textures/Weapon_Preview_RPG7") },
		{ TEXT("Weapons"), TEXT("SVD Showcase"), TEXT("/Game/Textures/Weapon_Preview_SVD") },

		// 5. HUD Weapon Silhouettes
		{ TEXT("HUD Icons"), TEXT("HUD AK-47"), TEXT("/Game/Textures/HUD_Weapon_AK47") },
		{ TEXT("HUD Icons"), TEXT("HUD G3A3"), TEXT("/Game/Textures/HUD_Weapon_G3A3") },
		{ TEXT("HUD Icons"), TEXT("HUD MG3"), TEXT("/Game/Textures/HUD_Weapon_MG3") },
		{ TEXT("HUD Icons"), TEXT("HUD RPG-7"), TEXT("/Game/Textures/HUD_Weapon_RPG7") },
		{ TEXT("HUD Icons"), TEXT("HUD SVD"), TEXT("/Game/Textures/HUD_Weapon_SVD") },
		{ TEXT("HUD Icons"), TEXT("HUD Unarmed Knife"), TEXT("/Game/Textures/HUD_Weapon_Unarmed") },

		// 6. Speciality Traits
		{ TEXT("Traits"), TEXT("Silent Marksman"), TEXT("/Game/Textures/UI_Trait_SilentMarksman") },
		{ TEXT("Traits"), TEXT("Heavy Caliber"), TEXT("/Game/Textures/UI_Trait_HeavyCaliber") },
		{ TEXT("Traits"), TEXT("Desert Reliability"), TEXT("/Game/Textures/UI_Trait_DesertReliability") },
		{ TEXT("Traits"), TEXT("Area Suppression"), TEXT("/Game/Textures/UI_Trait_AreaSuppression") },
		{ TEXT("Traits"), TEXT("Tank Destroyer"), TEXT("/Game/Textures/UI_Trait_TankDestroyer") },

		// 7. Tactical Frames & Emblems
		{ TEXT("Frames"), TEXT("Tactical Gold Border"), TEXT("/Game/Textures/UI_Frame_TacticalBorder_Gold") },
		{ TEXT("Frames"), TEXT("Tactical Crimson Border"), TEXT("/Game/Textures/UI_Frame_TacticalBorder_Crimson") },
		{ TEXT("Frames"), TEXT("Avatar Portrait Frame"), TEXT("/Game/Textures/UI_Frame_Avatar_Portrait") },
		{ TEXT("Frames"), TEXT("Badge Hexagon Frame"), TEXT("/Game/Textures/UI_Frame_Badge_Hexagon") },
		{ TEXT("Frames"), TEXT("Military Watermark Emblem"), TEXT("/Game/Textures/UI_Military_Watermark_Emblem") },
		{ TEXT("Frames"), TEXT("Loading Bar Frame"), TEXT("/Game/Textures/UI_LoadingBar_Frame") },
		{ TEXT("Frames"), TEXT("Loading Bar Fill"), TEXT("/Game/Textures/UI_LoadingBar_Fill") },
		{ TEXT("Frames"), TEXT("Tactical Button"), TEXT("/Game/Textures/UI_Button_Tactical_Normal") },
		{ TEXT("Frames"), TEXT("Tactical Pause Card"), TEXT("/Game/Textures/UI_Frame_Tactical_PauseCard") },

		// 8. Inventory & Backpack Items
		{ TEXT("Inventory"), TEXT("Pocket Holy Quran"), TEXT("/Game/Textures/UI_Item_PocketQuran") },
		{ TEXT("Inventory"), TEXT("Pocket Frontline Radio"), TEXT("/Game/Textures/UI_Item_PocketRadio") },
		{ TEXT("Inventory"), TEXT("Combat Wallet & Dog Tag"), TEXT("/Game/Textures/UI_Item_CombatWallet") },
		{ TEXT("Inventory"), TEXT("First Aid Canvas Pouch"), TEXT("/Game/Textures/UI_Item_FirstAidPouch") },
		{ TEXT("Inventory"), TEXT("Military Canteen Flask"), TEXT("/Game/Textures/UI_Item_Canteen") }
	};

	UE_LOG(LogTemp, Warning, TEXT("[SQUADAI_ASSET_AUDIT] ========================================================"));
	UE_LOG(LogTemp, Warning, TEXT("[SQUADAI_ASSET_AUDIT] === SQUADAI TACTICAL ASSET AUDIT & TEXTURE DIAGNOSTIC ==="));
	UE_LOG(LogTemp, Warning, TEXT("[SQUADAI_ASSET_AUDIT] ========================================================"));

	int32 FoundCount = 0;
	int32 MissingCount = 0;

	for (const FAssetCheckEntry& Entry : RequiredAssets)
	{
		const FString CleanName = FPaths::GetCleanFilename(Entry.AssetPath);
		const FString FullPath = Entry.AssetPath + TEXT(".") + CleanName;
		const FString RelativePng = FString::Printf(TEXT("Textures/%s.png"), *CleanName);
		UTexture2D* Tex = FSquadAIAssetHelper::LoadTextureSafe(*FullPath, *RelativePng);

		if (Tex)
		{
			FoundCount++;
			UE_LOG(LogTemp, Display, TEXT("[SQUADAI_ASSET_AUDIT] [FOUND]   [%-12s] %-26s -> Path: %s (Res: %dx%d)"),
				*Entry.Category, *Entry.FriendlyName, *Entry.AssetPath,
				Tex->GetSizeX(), Tex->GetSizeY());
		}
		else
		{
			MissingCount++;
			UE_LOG(LogTemp, Error, TEXT("[SQUADAI_ASSET_AUDIT] [MISSING] [%-12s] %-26s -> Expected: %s (Fallback: Procedural Vector)"),
				*Entry.Category, *Entry.FriendlyName, *Entry.AssetPath);
		}
	}

	const float Pct = (RequiredAssets.Num() > 0) ? (static_cast<float>(FoundCount) / RequiredAssets.Num() * 100.0f) : 100.0f;
	UE_LOG(LogTemp, Warning, TEXT("[SQUADAI_ASSET_AUDIT] ========================================================"));
	UE_LOG(LogTemp, Warning, TEXT("[SQUADAI_ASSET_AUDIT] AUDIT SUMMARY: %d Found / %d Missing (%0.1f%% Assets Loaded)"),
		FoundCount, MissingCount, Pct);
	if (MissingCount > 0)
	{
		UE_LOG(LogTemp, Warning, TEXT("[SQUADAI_ASSET_AUDIT] TIP: Import PNG files from SquadAI/Content/Textures/ into Unreal Content Browser at /Game/Textures/"));
	}
	UE_LOG(LogTemp, Warning, TEXT("[SQUADAI_ASSET_AUDIT] ========================================================"));

	// AAA-MW-21: log-only. The on-screen green asset-audit message was visible over
	// the polished main menu, so do not draw it in-game.
}

void USquadAIDevDebugSubsystem::Deinitialize()
{
	Super::Deinitialize();
}

USquadAIDevDebugSubsystem* USquadAIDevDebugSubsystem::Get(const UObject* WorldContextObject)
{
	if (!WorldContextObject) return nullptr;
	UWorld* World = GEngine ? GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::ReturnNull) : nullptr;
	return World ? World->GetSubsystem<USquadAIDevDebugSubsystem>() : nullptr;
}

void USquadAIDevDebugSubsystem::PollDeveloperHotkeys(APlayerController* PC)
{
	if (!bEnableDeveloperHotkeys || !PC) return;

	if (PC->WasInputKeyJustPressed(EKeys::F1))
	{
		// Shift+F1 toggles infinite ammo; plain F1 keeps god-mode + refill.
		if (PC->IsInputKeyDown(EKeys::LeftShift) || PC->IsInputKeyDown(EKeys::RightShift))
		{
			ToggleInfiniteAmmo();
		}
		else
		{
			ToggleGodMode();
			RefillAllAmmo();
		}
	}
	else if (PC->WasInputKeyJustPressed(EKeys::F2))
	{
		TeleportToNextObjective();
	}
	else if (PC->WasInputKeyJustPressed(EKeys::F3))
	{
		SpawnEnemySquadAtCrosshair(3);
	}
	else if (PC->WasInputKeyJustPressed(EKeys::F4))
	{
		SpawnAllyReinforcementsAtCrosshair(2);
	}
	else if (PC->WasInputKeyJustPressed(EKeys::F5))
	{
		DropSupplyKitAtFeet();
	}
	else if (PC->WasInputKeyJustPressed(EKeys::F6))
	{
		ToggleAIDebugVisuals();
		DumpDiagnostics();
	}
	else if (PC->WasInputKeyJustPressed(EKeys::F7))
	{
		CompleteCurrentObjective();
	}
	else if (PC->WasInputKeyJustPressed(EKeys::F8))
	{
		CallDevMortarStrikeAtCrosshair();
	}
	else if (PC->WasInputKeyJustPressed(EKeys::F9))
	{
		TriggerDevRadioChatter();
	}
	else if (PC->WasInputKeyJustPressed(EKeys::F10))
	{
		SpawnDestroyedBuildingAtCrosshair();
	}
}

void USquadAIDevDebugSubsystem::ToggleGodMode()
{
	bGodModeActive = !bGodModeActive;
	// B7-5: the flag used to have zero readers (only a one-time heal). It now drives
	// UHealthComponent::ApplyDamage via bCheatGodMode — true invulnerability.
	if (APawn* PlayerPawn = UGameplayStatics::GetPlayerPawn(GetWorld(), 0))
	{
		if (UHealthComponent* HC = PlayerPawn->FindComponentByClass<UHealthComponent>())
		{
			HC->bCheatGodMode = bGodModeActive;
			if (bGodModeActive)
			{
				HC->Revive(); // F-G9 companion: Revive is the only path that clears bIsDead (Heal no longer resurrects).
			}
		}
	}
	if (GEngine)
	{
		GEngine->AddOnScreenDebugMessage(-1, 3.0f, bGodModeActive ? FColor::Green : FColor::Red,
			FString::Printf(TEXT("[DEV CHEAT] God Mode: %s"), bGodModeActive ? TEXT("ON (Invulnerable & Healed)") : TEXT("OFF")));
	}
}

void USquadAIDevDebugSubsystem::ToggleInfiniteAmmo()
{
	bInfiniteAmmoActive = !bInfiniteAmmoActive;
	// The reader lives in USquadAIPlayerCombatBridge::TickComponent, which tops up the
	// TPWCS pack mag/reserve every frame (SquadAI's WeaponComponent never consumes ammo).
	if (bInfiniteAmmoActive)
	{
		RefillAllAmmo();
	}
	if (GEngine)
	{
		GEngine->AddOnScreenDebugMessage(-1, 3.0f, bInfiniteAmmoActive ? FColor::Green : FColor::Red,
			FString::Printf(TEXT("[DEV CHEAT] Infinite Ammo: %s"), bInfiniteAmmoActive ? TEXT("ON") : TEXT("OFF")));
	}
}

void USquadAIDevDebugSubsystem::RefillAllAmmo()
{
	APawn* PlayerPawn = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	if (!PlayerPawn) return;

	// Refill TPWCS Pack ammo if present
	TArray<UActorComponent*> Comps;
	PlayerPawn->GetComponents(Comps);
	for (UActorComponent* C : Comps)
	{
		if (!C) continue;
		if (C->GetName().Contains(TEXT("BPC_Weapon")) || C->GetName().Contains(TEXT("BPC_Inventory")) || C->GetName().Contains(TEXT("Combat")))
		{
			for (const FName& PropName : { FName(TEXT("currentAmmo")), FName(TEXT("CurrentAmmo")), FName(TEXT("Ammo")) })
			{
				if (FIntProperty* IP = FindFProperty<FIntProperty>(C->GetClass(), PropName))
				{
					IP->SetPropertyValue_InContainer(C, 30);
				}
			}
			for (const FName& PropName : { FName(TEXT("reserveAmmo")), FName(TEXT("ReserveAmmo")), FName(TEXT("TotalAmmo")) })
			{
				if (FIntProperty* IP = FindFProperty<FIntProperty>(C->GetClass(), PropName))
				{
					IP->SetPropertyValue_InContainer(C, 180);
				}
			}
		}
	}

	// Refill Grenades
	if (UTacticalGrenadeComponent* GrenadeComp = PlayerPawn->FindComponentByClass<UTacticalGrenadeComponent>())
	{
		GrenadeComp->RefillGrenades(4, 4);
	}

	if (GEngine)
	{
		GEngine->AddOnScreenDebugMessage(-1, 3.0f, FColor::Cyan, TEXT("[DEV CHEAT] Ammo & Tactical Grenades Refilled to Maximum!"));
	}
}

void USquadAIDevDebugSubsystem::TeleportToNextObjective()
{
	UWorld* World = GetWorld();
	if (!World) return;

	APawn* Player = UGameplayStatics::GetPlayerPawn(World, 0);
	if (!Player) return;

	if (AQuestChain* Chain = AQuestChain::FindPreferred(World, false))
	{
		if (AMissionZone* Cur = Chain->GetCurrentMission())
		{
			Player->SetActorLocation(Cur->GetActorLocation() + FVector(0.f, 0.f, 60.f));
			if (GEngine)
			{
				GEngine->AddOnScreenDebugMessage(-1, 3.0f, FColor::Yellow, FString::Printf(TEXT("[DEV CHEAT] Teleported to Objective: %s"), *Cur->MissionDescription.ToString()));
			}
			return;
		}
	}

	TeleportToSquadLeader();
}

void USquadAIDevDebugSubsystem::TeleportToSquadLeader()
{
	UWorld* World = GetWorld();
	if (!World) return;

	APawn* Player = UGameplayStatics::GetPlayerPawn(World, 0);
	if (!Player) return;

	for (TActorIterator<ALeaderCharacter> It(World); It; ++It)
	{
		ALeaderCharacter* Leader = *It;
		if (Leader)
		{
			const FVector BehindLeader = Leader->GetActorLocation() - Leader->GetActorForwardVector() * 150.f + FVector(0.f, 0.f, 50.f);
			Player->SetActorLocation(BehindLeader);
			if (GEngine)
			{
				GEngine->AddOnScreenDebugMessage(-1, 3.0f, FColor::Emerald, TEXT("[DEV CHEAT] Teleported to Squad Leader"));
			}
			return;
		}
	}
}

FVector USquadAIDevDebugSubsystem::GetPlayerCrosshairWorldLocation(APlayerController* PC) const
{
	if (!PC || !GetWorld()) return FVector::ZeroVector;

	int32 ViewportX, ViewportY;
	PC->GetViewportSize(ViewportX, ViewportY);

	FVector WorldLoc, WorldDir;
	if (PC->DeprojectScreenPositionToWorld(ViewportX * 0.5f, ViewportY * 0.5f, WorldLoc, WorldDir))
	{
		FHitResult Hit;
		FCollisionQueryParams Params;
		if (PC->GetPawn()) Params.AddIgnoredActor(PC->GetPawn());

		if (GetWorld()->LineTraceSingleByChannel(Hit, WorldLoc, WorldLoc + WorldDir * 20000.f, ECC_Visibility, Params))
		{
			return Hit.ImpactPoint;
		}
		return WorldLoc + WorldDir * 2000.f;
	}

	return PC->GetPawn() ? PC->GetPawn()->GetActorLocation() + PC->GetPawn()->GetActorForwardVector() * 500.f : FVector::ZeroVector;
}

void USquadAIDevDebugSubsystem::SpawnEnemySquadAtCrosshair(int32 Count)
{
	UWorld* World = GetWorld();
	if (!World) return;

	APlayerController* PC = UGameplayStatics::GetPlayerController(World, 0);
	const FVector TargetLoc = GetPlayerCrosshairWorldLocation(PC);

	FActorSpawnParameters SpawnParams;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;

	for (int32 i = 0; i < Count; ++i)
	{
		const FVector Offset(FMath::FRandRange(-250.f, 250.f), FMath::FRandRange(-250.f, 250.f), 40.f);
		World->SpawnActor<AEnemySoldier>(AEnemySoldier::StaticClass(), TargetLoc + Offset, FRotator::ZeroRotator, SpawnParams);
	}

	if (GEngine)
	{
		GEngine->AddOnScreenDebugMessage(-1, 3.0f, FColor::Red, FString::Printf(TEXT("[DEV CHEAT] Spawned %d Hostile Enemy Soldiers at Crosshair!"), Count));
	}
}

void USquadAIDevDebugSubsystem::SpawnAllyReinforcementsAtCrosshair(int32 Count)
{
	UWorld* World = GetWorld();
	if (!World) return;

	APlayerController* PC = UGameplayStatics::GetPlayerController(World, 0);
	const FVector TargetLoc = GetPlayerCrosshairWorldLocation(PC);

	FActorSpawnParameters SpawnParams;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;

	for (int32 i = 0; i < Count; ++i)
	{
		const FVector Offset(FMath::FRandRange(-200.f, 200.f), FMath::FRandRange(-200.f, 200.f), 40.f);
		World->SpawnActor<AAllySoldier>(AAllySoldier::StaticClass(), TargetLoc + Offset, FRotator::ZeroRotator, SpawnParams);
	}

	if (GEngine)
	{
		GEngine->AddOnScreenDebugMessage(-1, 3.0f, FColor::Cyan, FString::Printf(TEXT("[DEV CHEAT] Spawned %d Ally Reinforcements at Crosshair!"), Count));
	}
}

void USquadAIDevDebugSubsystem::DropSupplyKitAtFeet()
{
	UWorld* World = GetWorld();
	if (!World) return;

	APawn* Player = UGameplayStatics::GetPlayerPawn(World, 0);
	if (!Player) return;

	const FVector Origin = Player->GetActorLocation() + Player->GetActorForwardVector() * 120.f;
	FActorSpawnParameters SpawnParams;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;

	World->SpawnActor<AFirstAidKitActor>(AFirstAidKitActor::StaticClass(), Origin - Player->GetActorRightVector() * 40.f, FRotator::ZeroRotator, SpawnParams);
	World->SpawnActor<AAmmoCrateActor>(AAmmoCrateActor::StaticClass(), Origin + Player->GetActorRightVector() * 40.f, FRotator::ZeroRotator, SpawnParams);

	if (GEngine)
	{
		GEngine->AddOnScreenDebugMessage(-1, 3.0f, FColor::Green, TEXT("[DEV CHEAT] Dropped First Aid Kit & Ammo Crate at your feet!"));
	}
}

void USquadAIDevDebugSubsystem::CompleteCurrentObjective()
{
	UWorld* World = GetWorld();
	if (!World) return;

	if (AQuestChain* Chain = AQuestChain::FindPreferred(World, false))
	{
		if (AMissionZone* Cur = Chain->GetCurrentMission())
		{
			// B7-9: the old field-hacks never advanced the quest. Set the polled
			// counters, then run the real completion path (timers, spawners, chain).
			Cur->AliveEnemies = 0;
			Cur->DefendTimeRemaining = 0.0f;
			Cur->CompleteMission();
			if (GEngine)
			{
				GEngine->AddOnScreenDebugMessage(-1, 3.0f, FColor::Orange, FString::Printf(TEXT("[DEV CHEAT] Completed Current Objective: %s"), *Cur->MissionDescription.ToString()));
			}
			return;
		}
	}
}

void USquadAIDevDebugSubsystem::ToggleSandstormWeather()
{
	UWorld* World = GetWorld();
	if (!World) return;

	for (TActorIterator<ASandstormWeatherDirector> It(World); It; ++It)
	{
		ASandstormWeatherDirector* Director = *It;
		if (Director)
		{
			if (Director->CurrentPhase == EWeatherStormPhase::Clear)
			{
				Director->TriggerSandstorm(120.f);
			}
			else
			{
				Director->StopSandstorm();
			}
			if (GEngine)
			{
				const bool bActive = (Director->CurrentPhase != EWeatherStormPhase::Clear);
				GEngine->AddOnScreenDebugMessage(-1, 3.0f, FColor::Magenta,
					FString::Printf(TEXT("[DEV CHEAT] Sandstorm Weather: %s"), bActive ? TEXT("ACTIVE (Haboob)") : TEXT("CLEARED")));
			}
			return;
		}
	}
}

void USquadAIDevDebugSubsystem::CallDevMortarStrikeAtCrosshair()
{
	UWorld* World = GetWorld();
	if (!World) return;

	APlayerController* PC = UGameplayStatics::GetPlayerController(World, 0);
	const FVector TargetLoc = GetPlayerCrosshairWorldLocation(PC);

	if (USquadAIFireSupportSubsystem* FireSupport = USquadAIFireSupportSubsystem::Get(this))
	{
		FireSupport->CallMortarStrike(TargetLoc, 5);
	}
}

void USquadAIDevDebugSubsystem::TriggerDevRadioChatter()
{
	if (USquadAIRadioChatterSubsystem* RadioSys = USquadAIRadioChatterSubsystem::Get(this))
	{
		static int32 RadioIdx = 0;
		ETacticalRadioContext Contexts[] = {
			ETacticalRadioContext::SpotHostile,
			ETacticalRadioContext::SuppressingFire,
			ETacticalRadioContext::FlankingManeuver,
			ETacticalRadioContext::TargetNeutralized,
			ETacticalRadioContext::HeavyMGActive,
			ETacticalRadioContext::MortarInbound
		};
		const int32 NumContexts = sizeof(Contexts) / sizeof(Contexts[0]);
		RadioSys->BroadcastRadioChatter(TEXT("سرگرد رستمی (فرمانده)"), Contexts[RadioIdx % NumContexts]);
		RadioIdx++;
	}
}

void USquadAIDevDebugSubsystem::SpawnDestroyedBuildingAtCrosshair()
{
	UWorld* World = GetWorld();
	if (!World) return;

	APlayerController* PC = UGameplayStatics::GetPlayerController(World, 0);
	const FVector TargetLoc = GetPlayerCrosshairWorldLocation(PC);

	FActorSpawnParameters SpawnParams;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;

	ADestroyedBuildingActor* Building = World->SpawnActor<ADestroyedBuildingActor>(
		ADestroyedBuildingActor::StaticClass(),
		TargetLoc,
		FRotator::ZeroRotator,
		SpawnParams);

	if (Building)
	{
		static int32 StyleIdx = 0;
		EBuildingStyle Styles[] = {
			EBuildingStyle::TwoStorySniperRuins,
			EBuildingStyle::SingleStoryMudbrick,
			EBuildingStyle::WalledCourtyardHouse,
			EBuildingStyle::VillageMarketStalls,
			EBuildingStyle::OutpostObservationTower
		};
		Building->BuildingStyle = Styles[StyleIdx % 5];
		Building->bSpawnSupplies = true;
		Building->bSpawnMountedHeavyMG = true;
		Building->bSpawnExplosiveBarrels = true;
		Building->BuildBuilding();
		StyleIdx++;

		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3.5f, FColor::Emerald, TEXT("[DEV CHEAT] Spawned Destroyed Middle East Building at Crosshair!"));
		}
	}
}

void USquadAIDevDebugSubsystem::ToggleAIDebugVisuals()
{
	bDrawAIDebugVisuals = !bDrawAIDebugVisuals;
	if (GEngine)
	{
		GEngine->AddOnScreenDebugMessage(-1, 3.0f, FColor::White, FString::Printf(TEXT("[DEV CHEAT] AI Debug Visuals: %s"), bDrawAIDebugVisuals ? TEXT("ENABLED") : TEXT("DISABLED")));
	}
}

void USquadAIDevDebugSubsystem::ToggleDebugLogs()
{
	static bool bLogsActive = false;
	bLogsActive = !bLogsActive;
	// B7-8: was a placebo static with zero log effect. Drive the real gates
	// (ASquadAIAutoSetupManager::ShouldLog*) that the codebase actually reads.
	ASquadAIAutoSetupManager::SetVerboseDebugLogsEnabled(bLogsActive);
	if (GEngine)
	{
		GEngine->AddOnScreenDebugMessage(-1, 3.5f, bLogsActive ? FColor::Green : FColor::Orange,
			FString::Printf(TEXT("[DEV CHEAT] Diagnostic Logging: %s"), bLogsActive ? TEXT("VERBOSE (All Categories Active)") : TEXT("STANDARD (Errors Only)")));
	}
	UE_LOG(LogTemp, Warning, TEXT("[SquadAIDevDebug] Diagnostic Logging set to: %s"), bLogsActive ? TEXT("VERBOSE") : TEXT("STANDARD"));
}

FString USquadAIDevDebugSubsystem::DumpDiagnostics()
{
	UWorld* World = GetWorld();
	if (!World) return TEXT("ERROR: World is NULL");

	FString Report;
	Report += TEXT("====================================================\n");
	Report += TEXT("🔍 SQUADAI SYSTEM DIAGNOSTIC SNAPSHOT REPORT\n");
	Report += TEXT("====================================================\n");

	// 1. Leader & Allies
	int32 AllyCount = 0;
	int32 AliveAllies = 0;
	AActor* LeaderActor = nullptr;

	for (TActorIterator<ALeaderCharacter> It(World); It; ++It) { LeaderActor = *It; break; }
	for (TActorIterator<AAllySoldier> It(World); It; ++It)
	{
		AllyCount++;
		if (It->HealthComp && It->HealthComp->IsAlive()) AliveAllies++;
	}

	Report += FString::Printf(TEXT("• SQUAD LEADER: %s\n"), LeaderActor ? *LeaderActor->GetName() : TEXT("None / Player-Led"));
	Report += FString::Printf(TEXT("• ALLIES: %d total (%d alive)\n"), AllyCount, AliveAllies);

	// 2. Enemies
	int32 EnemyCount = 0;
	int32 AliveEnemies = 0;
	for (TActorIterator<AEnemySoldier> It(World); It; ++It)
	{
		EnemyCount++;
		if (It->HealthComp && It->HealthComp->IsAlive()) AliveEnemies++;
	}
	Report += FString::Printf(TEXT("• HOSTILE ENEMIES: %d total (%d alive)\n"), EnemyCount, AliveEnemies);

	// 3. Quest & Missions
	AQuestChain* Chain = AQuestChain::FindPreferred(World, false);
	if (Chain)
	{
		AMissionZone* Cur = Chain->GetCurrentMission();
		Report += FString::Printf(TEXT("• QUEST CHAIN: %s (Active Mission: [%d] %s)\n"),
			*Chain->GetName(),
			Cur ? Cur->MissionIndex : -1,
			Cur ? *Cur->MissionDescription.ToString() : TEXT("None"));
		if (Cur)
		{
			Report += FString::Printf(TEXT("  - Mission State: %s | Progress: %.1f%% | Enemies Remaining: %d\n"),
				Cur->MissionState == EMissionZoneState::Active ? TEXT("Active") :
				Cur->MissionState == EMissionZoneState::Completed ? TEXT("Completed") : TEXT("Locked"),
				Cur->MissionProgress * 100.f,
				Cur->AliveEnemies);
		}
	}
	else
	{
		Report += TEXT("• QUEST CHAIN: None Active (Use Auto-Fix Level & Missions)\n");
	}

	// 4. Audio Subsystem
	if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
	{
		Report += FString::Printf(TEXT("• AUDIO SUBSYSTEM: Active | Combat Intensity: %.2f\n"),
			AudioSys->GetCurrentCombatIntensity());
	}

	Report += TEXT("====================================================\n");

	UE_LOG(LogTemp, Warning, TEXT("%s"), *Report);

	if (GEngine)
	{
		GEngine->AddOnScreenDebugMessage(-1, 8.0f, FColor::Yellow, Report);
	}

	return Report;
}

void USquadAIDevDebugSubsystem::TestFarsiShaping()
{
	// MEGA-5 (P1-L3 harness): log the shaper output for torture strings so the
	// EN-labels-through-Farsi-path + RTL/LTR mixing check is one console command.
	const TArray<FString> Cases = {
		TEXT("Test 1 - EN label: Squad Ammo: 120"),
		TEXT("Test 2 - FA label: \u0645\u0647\u0645\u0627\u062a: 120"),
		TEXT("Test 3 - timer mix: Timer 03:45 \u0628\u0627\u0642\u06cc\u200c\u0645\u0627\u0646\u062f\u0647"),
		TEXT("Test 4 - diacritics: \u0642\u0631\u0622\u0646 \u06f2:\u06f2\u06f5\u06f5"),
		TEXT("Test 5 - ZWNJ verbs: \u0645\u06cc\u200c\u0634\u0648\u062f \u0646\u0645\u06cc\u200c\u0634\u0648\u062f"),
		TEXT("Test 6 - ligatures: \ufdfa test \ufdf2"),
	};
	for (const FString& C : Cases)
	{
		UE_LOG(LogTemp, Warning, TEXT("[FarsiTest] IN=[%s] OUT=[%s]"), *C, *UFarsiTextHelper::ShapeAndOrder(C));
	}
}

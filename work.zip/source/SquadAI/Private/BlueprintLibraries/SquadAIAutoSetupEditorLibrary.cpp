#include "BlueprintLibraries/SquadAIAutoSetupEditorLibrary.h"

#include "HAL/FileManager.h"                 // S26-VIDEO: MakeDirectory / Copy / FileSize
#include "HAL/IConsoleManager.h"             // S26-VIDEOFIX: read the menu video CVars
#include "Actors/SquadAIMainMenuSetupActor.h"     // S26-VIDEOFIX: ...and the Menu Director's
#if WITH_EDITOR
#include "Editor.h"                          // S26-VIDEOFIX: GEditor->GetEditorWorldContext() for console commands
#endif
#if WITH_EDITOR
#include "Framework/Notifications/NotificationManager.h"   // S26-VIDEOFIX: CallInEditor buttons return into the void
#include "Widgets/Notifications/SNotificationList.h"       // a failed install was INVISIBLE before this
#endif
#include "Materials/MaterialInstanceDynamic.h"   // S26-VIS: type-colored mission markers
#include "Components/StaticMeshComponent.h"  // S26-VIS: tint + size the spawner's editor mesh
#include "Engine/StaticMeshActor.h"          // S26-LIFE: crater + scenery pieces
#include "BlueprintLibraries/SquadAIPackBridgeLibrary.h"
#include "Components/SquadAILeaderTeamAutoSetupComponent.h"
#include "Components/SquadAIPackAutoCharacterComponent.h"
#include "Components/SquadAIPackValidationComponent.h"
#include "Quest/MissionZone.h"
#include "Quest/QuestChain.h"
#include "Quest/TerrainStructureModel.h"   // S21-TERRAIN: the land's elevation structure
#include "Quest/WarWorksModel.h"        // S25-WARWORKS: the war's geography, engine-free
#include "Actors/WarWorksActor.h"       // S25-WARWORKS: the manager's war pieces
#include "Quest/EnemyWaveSpawner.h"
#include "Quest/SceneDecorator.h"
#include "Performance/SquadAIAssetCacheSubsystem.h"   // S26-MAT: textured prop materials
#include "Quest/AtmosphericDustScatterer.h"
#include "Quest/SandstormWeatherDirector.h"
#include "Actors/SquadAIAudioManager.h"
#include "Actors/AmmoCrateActor.h"
#include "Actors/FirstAidKitActor.h"
#include "Actors/MedicalStationActor.h"
#include "Actors/MountedTurretActor.h"
#include "Actors/CombatEncounterVolume.h"
#include "Actors/ExplosiveBarrelActor.h"
#include "Actors/QuickFortificationSpawnerActor.h"
#include "CoverSystem/TacticalCoverGeneratorActor.h"
#include "CoverSystem/CoverSystemSubsystem.h"
#include "Environment/DestroyedBuildingActor.h"
#include "Environment/DestroyedVillageCompoundActor.h"
#include "GameFramework/Actor.h"
// S19-TEMPLATE: the mission factory's inputs and the props it deploys.
#include "Quest/MissionArchetypeModel.h"
#include "Quest/MissionBriefingModel.h"     // S23-BRIEF: briefings written by the land
#include "Quest/MissionTemplateAsset.h"
#include "Quest/SabotageTargetActor.h"
#include "Quest/SupplyCrateActor.h"
#include "Quest/IntelSiteActor.h"
#include "Quest/ExtractionZoneActor.h"
#include "Quest/CapturePointActor.h"         // S19-CAP
#include "Quest/MapLayoutModel.h"            // S19-MAP: the landscape checker's rules
#include "Components/InstancedStaticMeshComponent.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h"   // S26-WEAR2: instanced shells
#include "Components/SplineComponent.h"
#include "GameFramework/PlayerStart.h"
#include "HAL/PlatformFileManager.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "Quest/DefendedAssetActor.h"        // S19-ASSET
#include "Quest/InterdictionDirectorActor.h" // S19-INTERDICT
#include "Quest/EscortTargetActor.h"
#include "Actors/EnemyPatrolRoute.h"
#include "Characters/SoldierCharacter.h"
#include "EngineUtils.h"
#include "Engine/World.h"

bool USquadAIAutoSetupEditorLibrary::ValidateActorForPackSetup(AActor* Actor)
{
    if (!Actor)
    {
        return false;
    }

    USquadAIPackValidationComponent* Validator = Actor->FindComponentByClass<USquadAIPackValidationComponent>();
    if (!Validator)
    {
        Validator = NewObject<USquadAIPackValidationComponent>(Actor, TEXT("SquadAIPackValidationComponent_Auto"));
        if (!Validator)
        {
            return false;
        }
        Validator->RegisterComponent();
    }

    return Validator->ValidateCurrentOwner(true).bOverallPass;
}

bool USquadAIAutoSetupEditorLibrary::AutoSetupActorForPackInEditor(AActor* Actor, bool bTreatAsLeader)
{
    if (!Actor)
    {
        return false;
    }

    USquadAIPackAutoCharacterComponent* AutoComp = Actor->FindComponentByClass<USquadAIPackAutoCharacterComponent>();
    if (!AutoComp)
    {
        AutoComp = NewObject<USquadAIPackAutoCharacterComponent>(Actor, TEXT("SquadAIPackAutoCharacterComponent_Auto"));
        if (!AutoComp)
        {
            return false;
        }
        AutoComp->RegisterComponent();
    }

    if (bTreatAsLeader)
    {
        // Property is editor-visible; this call path intentionally relies on leader class too.
    }

    return AutoComp->RunAutoSetup();
}

bool USquadAIAutoSetupEditorLibrary::AutoSetupLeaderTeamInEditor(AActor* LeaderActor, const TArray<AActor*>& AllyActors)
{
    if (!LeaderActor)
    {
        return false;
    }

    const bool bLeaderSetup = AutoSetupActorForPackInEditor(LeaderActor, true);

    bool bAlliesSetup = true;
    for (AActor* AllyActor : AllyActors)
    {
        bAlliesSetup &= AutoSetupActorForPackInEditor(AllyActor, false);
    }

    const bool bConfigured = USquadAIPackBridgeLibrary::AutoConfigureExistingLeaderTeam(
        LeaderActor,
        AllyActors,
        0);

    const bool bWaypointsBuilt = USquadAIPackBridgeLibrary::AutoBuildLeaderWaypointsFromQuest(
        LeaderActor,
        true);

    return bLeaderSetup && bAlliesSetup && bConfigured && bWaypointsBuilt;
}

FString USquadAIAutoSetupEditorLibrary::AutoFixAndWireLevelMissions(UWorld* World)
{
    if (!World) return TEXT("ERROR: World is NULL");

    FString Log;
    Log += TEXT("=== AUTO-FIX LEVEL MISSIONS & SPAWNERS ===\n");

    // 1. Collect all MissionZones and Spawners
    TArray<AMissionZone*> MissionZones;
    TArray<AEnemyWaveSpawner*> AllSpawners;
    AQuestChain* FoundChain = nullptr;

    for (TActorIterator<AMissionZone> It(World); It; ++It)
    {
        if (AMissionZone* MZ = *It) MissionZones.Add(MZ);
    }

    for (TActorIterator<AEnemyWaveSpawner> It(World); It; ++It)
    {
        if (AEnemyWaveSpawner* S = *It) AllSpawners.Add(S);
    }

    // Also detect generic spawner actors in map if no AEnemyWaveSpawner found
    if (AllSpawners.Num() == 0)
    {
        for (TActorIterator<AActor> It(World); It; ++It)
        {
            AActor* Act = *It;
            if (!Act || Act->IsA<AMissionZone>() || Act->IsA<AQuestChain>()) continue;
            const FString Name = Act->GetName();
            if (Act->ActorHasTag(TEXT("Spawner")) || Name.Contains(TEXT("Spawner"), ESearchCase::IgnoreCase) || Name.Contains(TEXT("EnemySpawn"), ESearchCase::IgnoreCase) || Name.Contains(TEXT("WaveSpawn"), ESearchCase::IgnoreCase))
            {
                // Spawn an AEnemyWaveSpawner at this actor's position
                FActorSpawnParameters SpawnerParams;
                SpawnerParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;
                AEnemyWaveSpawner* NewSpawner = World->SpawnActor<AEnemyWaveSpawner>(AEnemyWaveSpawner::StaticClass(), Act->GetActorLocation(), Act->GetActorRotation(), SpawnerParams);
                if (NewSpawner)
                {
                    AllSpawners.Add(NewSpawner);
                    Log += FString::Printf(TEXT(" - Created SquadAI Wave Spawner matching map spawner '%s'\n"), *Act->GetName());
                }
            }
        }
    }

    for (TActorIterator<AQuestChain> It(World); It; ++It)
    {
        FoundChain = *It;
        break;
    }

    Log += FString::Printf(TEXT("Found %d MissionZone(s), %d Spawner(s), Chain: %s\n"),
        MissionZones.Num(), AllSpawners.Num(), FoundChain ? *FoundChain->GetName() : TEXT("NONE (Spawning one)"));

    // If map has spawners but no MissionZones yet, auto-create MissionZones at spawner locations
    if (MissionZones.Num() == 0 && AllSpawners.Num() > 0)
    {
        Log += FString::Printf(TEXT("Auto-generating %d MissionZone(s) at Spawner locations...\n"), AllSpawners.Num());
        FActorSpawnParameters MZSpawnParams;
        MZSpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;

        for (int32 i = 0; i < AllSpawners.Num(); ++i)
        {
            AEnemyWaveSpawner* Spawner = AllSpawners[i];
            if (!Spawner) continue;

            const FVector MZLoc = Spawner->GetActorLocation();
            AMissionZone* NewMZ = World->SpawnActor<AMissionZone>(AMissionZone::StaticClass(), MZLoc, FRotator::ZeroRotator, MZSpawnParams);
            if (NewMZ)
            {
                NewMZ->MissionType = (Spawner->MaxWaves > 1) ? EMissionType::Defend : EMissionType::Clear;
                NewMZ->MissionDescription = FText::FromString(FString::Printf(TEXT("Eliminate Hostiles at Sector %d"), i + 1));
                NewMZ->LinkedSpawners.Add(Spawner);
                MissionZones.Add(NewMZ);
                Log += FString::Printf(TEXT(" - Created MissionZone for Spawner '%s' (Type=%s)\n"),
                    *Spawner->GetName(), NewMZ->MissionType == EMissionType::Defend ? TEXT("Defend") : TEXT("Clear"));
            }
        }
    }

    // Spawn QuestChain if none exists
    if (!FoundChain)
    {
        FActorSpawnParameters SpawnParams;
        SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
        FoundChain = World->SpawnActor<AQuestChain>(AQuestChain::StaticClass(), FVector::ZeroVector, FRotator::ZeroRotator, SpawnParams);
#if WITH_EDITORONLY_DATA
        FoundChain->SetIsSpatiallyLoaded(false);   // S20-WP: the campaign brain never streams out
#endif
        if (FoundChain)
        {
            FoundChain->bAutoStart = true;
            Log += TEXT("Created new AQuestChain (bAutoStart = true)\n");
        }
    }

    // Sort MissionZones by MissionIndex or distance
    MissionZones.Sort([](const AMissionZone& A, const AMissionZone& B)
    {
        return A.MissionIndex < B.MissionIndex;
    });

    if (FoundChain)
    {
        FoundChain->Modify();
        FoundChain->Missions.Empty();
        for (int32 i = 0; i < MissionZones.Num(); ++i)
        {
            AMissionZone* MZ = MissionZones[i];
            if (!MZ) continue;

            MZ->Modify();
            MZ->MissionIndex = i;
            MZ->OwningChain = FoundChain;
            FoundChain->Missions.Add(MZ);

            // Auto-wire spawners if none linked for Clear/Defend missions
            if ((MZ->MissionType == EMissionType::Clear || MZ->MissionType == EMissionType::Defend) && MZ->LinkedSpawners.Num() == 0)
            {
                const FVector ZoneLoc = MZ->GetActorLocation();
                for (AEnemyWaveSpawner* Spawner : AllSpawners)
                {
                    if (Spawner && FVector::Dist(ZoneLoc, Spawner->GetActorLocation()) <= 10000.f)
                    {
                        MZ->LinkedSpawners.Add(Spawner);
                        Log += FString::Printf(TEXT(" - Linked Spawner '%s' to Mission '%s'\n"), *Spawner->GetName(), *MZ->GetName());
                    }
                }
            }

            Log += FString::Printf(TEXT("Configured Mission [%d] '%s' (Type=%s)\n"),
                i, *MZ->GetName(),
                MZ->MissionType == EMissionType::Reach ? TEXT("Reach") :
                MZ->MissionType == EMissionType::Clear ? TEXT("Clear") : TEXT("Defend"));
        }
        FoundChain->bAutoStart = true;
    }

    Log += TEXT("=== AUTO-FIX COMPLETED SUCCESSFULLY ===\n");
    return Log;
}

FString USquadAIAutoSetupEditorLibrary::EnsureEssentialEnvironmentActors(UWorld* World)
{
    if (!World) return TEXT("ERROR: World is NULL");

    FString Log;
    Log += TEXT("=== ESSENTIAL ENVIRONMENT ACTORS CHECK ===\n");

    ASquadAIAudioManager* AudioMgr = nullptr;
    AAtmosphericDustScatterer* DustScatterer = nullptr;
    ASceneDecorator* SceneDec = nullptr;
    ASandstormWeatherDirector* WeatherDirector = nullptr;
    AAmmoCrateActor* AmmoCrate = nullptr;
    AFirstAidKitActor* FirstAidKit = nullptr;
    AMedicalStationActor* MedicalStation = nullptr;
    AMountedTurretActor* MountedTurret = nullptr;

    for (TActorIterator<ASquadAIAudioManager> It(World); It; ++It) { AudioMgr = *It; break; }
    for (TActorIterator<AAtmosphericDustScatterer> It(World); It; ++It) { DustScatterer = *It; break; }
    for (TActorIterator<ASceneDecorator> It(World); It; ++It) { SceneDec = *It; break; }
    for (TActorIterator<ASandstormWeatherDirector> It(World); It; ++It) { WeatherDirector = *It; break; }
    for (TActorIterator<AAmmoCrateActor> It(World); It; ++It) { AmmoCrate = *It; break; }
    for (TActorIterator<AFirstAidKitActor> It(World); It; ++It) { FirstAidKit = *It; break; }
    for (TActorIterator<AMedicalStationActor> It(World); It; ++It) { MedicalStation = *It; break; }
    for (TActorIterator<AMountedTurretActor> It(World); It; ++It) { MountedTurret = *It; break; }

    FActorSpawnParameters SpawnParams;
    SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

    if (!AudioMgr)
    {
        AudioMgr = World->SpawnActor<ASquadAIAudioManager>(ASquadAIAudioManager::StaticClass(), FVector(0.f, 0.f, 200.f), FRotator::ZeroRotator, SpawnParams);
        Log += TEXT("Spawned ASquadAIAudioManager (GUI Audio Controller)\n");
    }
    else
    {
        Log += FString::Printf(TEXT("Found ASquadAIAudioManager: %s\n"), *AudioMgr->GetName());
    }

    if (!DustScatterer)
    {
        DustScatterer = World->SpawnActor<AAtmosphericDustScatterer>(AAtmosphericDustScatterer::StaticClass(), FVector(0.f, 0.f, 100.f), FRotator::ZeroRotator, SpawnParams);
        Log += TEXT("Spawned AAtmosphericDustScatterer (Khuzestan Trench/Ditch Atmosphere)\n");
    }
    else
    {
        Log += FString::Printf(TEXT("Found AAtmosphericDustScatterer: %s\n"), *DustScatterer->GetName());
    }

    if (!SceneDec)
    {
        SceneDec = World->SpawnActor<ASceneDecorator>(ASceneDecorator::StaticClass(), FVector(0.f, 0.f, 50.f), FRotator::ZeroRotator, SpawnParams);
        Log += TEXT("Spawned ASceneDecorator (Battlefield Fire & Debris)\n");
    }
    else
    {
        Log += FString::Printf(TEXT("Found ASceneDecorator: %s\n"), *SceneDec->GetName());
    }

    if (!WeatherDirector)
    {
        WeatherDirector = World->SpawnActor<ASandstormWeatherDirector>(ASandstormWeatherDirector::StaticClass(), FVector(0.f, 0.f, 150.f), FRotator::ZeroRotator, SpawnParams);
        Log += TEXT("Spawned ASandstormWeatherDirector (Dynamic Haboob Weather Controller)\n");
    }
    else
    {
        Log += FString::Printf(TEXT("Found ASandstormWeatherDirector: %s\n"), *WeatherDirector->GetName());
    }

    if (!AmmoCrate)
    {
        AmmoCrate = World->SpawnActor<AAmmoCrateActor>(AAmmoCrateActor::StaticClass(), FVector(200.f, 150.f, 50.f), FRotator::ZeroRotator, SpawnParams);
        Log += TEXT("Spawned AAmmoCrateActor (Tactical Resupply Crate)\n");
    }
    else
    {
        Log += FString::Printf(TEXT("Found AAmmoCrateActor: %s\n"), *AmmoCrate->GetName());
    }

    if (!FirstAidKit)
    {
        FirstAidKit = World->SpawnActor<AFirstAidKitActor>(AFirstAidKitActor::StaticClass(), FVector(200.f, -150.f, 50.f), FRotator::ZeroRotator, SpawnParams);
        Log += TEXT("Spawned AFirstAidKitActor (Tactical First Aid Kit)\n");
    }
    else
    {
        Log += FString::Printf(TEXT("Found AFirstAidKitActor: %s\n"), *FirstAidKit->GetName());
    }

    if (!MountedTurret)
    {
        MountedTurret = World->SpawnActor<AMountedTurretActor>(AMountedTurretActor::StaticClass(), FVector(400.f, 0.f, 50.f), FRotator::ZeroRotator, SpawnParams);
        Log += TEXT("Spawned AMountedTurretActor (Mounted Heavy Machine Gun)\n");
    }
    else
    {
        Log += FString::Printf(TEXT("Found AMountedTurretActor: %s\n"), *MountedTurret->GetName());
    }

    Log += TEXT("=== ESSENTIAL ENVIRONMENT CHECK COMPLETED ===\n");
    return Log;
}

// S26-FIX: the plan path below calls factory helpers whose namespace body is
// defined further down this file - C++ needs the names declared before use.
namespace SquadAIMissionFactory
{
    static void SquadAIApplyPropMaterial(AActor* A, const TCHAR* TexKey, const FLinearColor& Tint);
    static void DecorateBarrel(AActor* Barrel);
    static void StampIdent(AActor* A, const FString& Label, const TCHAR* Folder);   // S26-COMPILE: the plan path labels its barrels too
}

FString USquadAIAutoSetupEditorLibrary::AutoPopulateLevelWithEncounterZones(UWorld* World)
{
    // S19-TEMPLATE: this pass is ARCHETYPE-AWARE now. The old version stamped every
    // Clear and Defend zone with the same thing - 2-3 waves of four enemies and one
    // barrel - and never read a single one of the zone's own features (the officer
    // hunt, the artillery spotter, the sabotage list). It now asks the zone what kind
    // of mission it is and deploys accordingly, and it says WHY in its report.
    if (!World) return TEXT("ERROR: World is NULL");

    FString Log;
    Log += TEXT("=== AUTO-POPULATE LEVEL WITH ENCOUNTERS (archetype-aware) ===\n");

    int32 SpawnedEncounters = 0;
    int32 SpawnedForts = 0;
    int32 SpawnedBarrels = 0;

    FActorSpawnParameters SpawnParams;
    SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;

    for (TActorIterator<AMissionZone> It(World); It; ++It)
    {
        AMissionZone* MZ = *It;
        if (!MZ) continue;

        // ---- what kind of mission is this? --------------------------------
        FMissionArchetypeQuery Query;
        Query.bReach = (MZ->MissionType == EMissionType::Reach);
        Query.bClear = (MZ->MissionType == EMissionType::Clear);
        Query.bDefend = (MZ->MissionType == EMissionType::Defend);
        Query.bHVTHunt = MZ->bHVTHunt;

        for (TActorIterator<AEnemyPatrolRoute> RouteIt(World); RouteIt; ++RouteIt)
        {
            if (RouteIt->GetPointCount() < 2) continue;
            if (FVector::Dist(MZ->GetActorLocation(), RouteIt->GetActorLocation())
                <= FMissionArchetypeModel::CampPatrolRadiusCm())
            {
                Query.bNearbyPatrolRoute = true;
                break;
            }
        }

        const EMissionPresetKind Preset = FMissionArchetypeModel::ChoosePreset(Query);
        const FMissionPresetPlan Plan = FMissionArchetypeModel::PlanFor(Preset);

        // ---- the encounter volume -----------------------------------------
        bool bHasEncounter = false;
        for (TActorIterator<ACombatEncounterVolume> EncIt(World); EncIt; ++EncIt)
        {
            if (FVector::Dist(MZ->GetActorLocation(), EncIt->GetActorLocation()) < 3000.f)
            {
                bHasEncounter = true;
                break;
            }
        }

        if (bHasEncounter)
        {
            Log += FString::Printf(TEXT("Mission '%s' (%s): an encounter already stands here - left alone.\n"),
                *MZ->GetName(), FMissionArchetypeModel::PresetName(Preset));
            continue;
        }

        ACombatEncounterVolume* Enc = World->SpawnActor<ACombatEncounterVolume>(
            ACombatEncounterVolume::StaticClass(), MZ->GetActorLocation(),
            MZ->GetActorRotation(), SpawnParams);
        if (!Enc)
        {
            Log += FString::Printf(TEXT("Mission '%s': FAILED to spawn an encounter volume.\n"), *MZ->GetName());
            continue;
        }

        // Kind -> encounter type. Checkpoint is the light one; a plain Clear gets the
        // standard multi-wave assault; the two named kinds pass straight through.
        switch (Preset)
        {
        case EMissionPresetKind::CommanderHunt: Enc->EncounterType = ECombatEncounterType::CommanderHunt; break;
        case EMissionPresetKind::PatrolCamp:    Enc->EncounterType = ECombatEncounterType::PatrolCamp;    break;
        case EMissionPresetKind::Stronghold:    Enc->EncounterType = ECombatEncounterType::DefendPosition; break;
        case EMissionPresetKind::Checkpoint:    Enc->EncounterType = ECombatEncounterType::Ambush;         break;
        case EMissionPresetKind::Ambush:
        default:                                Enc->EncounterType = ECombatEncounterType::WaveAssault;    break;
        }

        Enc->EncounterName = MZ->MissionDescription.IsEmpty()
            ? FText::FromString(TEXT("Tactical Sector")) : MZ->MissionDescription;
        Enc->TotalWaves = Plan.TotalWaves;
        Enc->EnemiesPerWave = Plan.EnemiesPerWave;
        Enc->WaveIntervalSeconds = Plan.DelayBetweenWaves;
        Enc->bAutoScatterSupplyKits = Plan.bAutoScatterSupplyKits;
        Enc->bSpawnMountedTurret = Plan.bSpawnMountedTurret;
        Enc->bSpawnCommander = Plan.bSpawnCommander;
        Enc->AssistantsPerCommander = Plan.AssistantsPerCommander;
        if (MZ->MissionType == EMissionType::Defend)
        {
            // A defence that runs out of waves is not a defence.
            Enc->TotalWaves = FMath::Max(Enc->TotalWaves, FMath::CeilToInt(MZ->DefendDuration / FMath::Max(1.f, MZ->DefendWaveInterval)) + 1);
        }
        SpawnedEncounters++;

        Log += FString::Printf(
            TEXT("Mission '%s' (%s) -> %s: %d wave(s) x %d, %s%s%s, %d barrel(s) nearby.\n"),
            *MZ->GetName(),
            MZ->MissionType == EMissionType::Reach ? TEXT("Reach") :
            MZ->MissionType == EMissionType::Clear ? TEXT("Clear") : TEXT("Defend"),
            FMissionArchetypeModel::PresetName(Preset),
            Enc->TotalWaves, Enc->EnemiesPerWave,
            Plan.bSpawnCommander ? TEXT("commander + assistants, ") : TEXT(""),
            Plan.bSpawnMountedTurret ? TEXT("mounted MG, ") : TEXT(""),
            Plan.bAutoScatterSupplyKits ? TEXT("supply kits") : TEXT("no supplies"),
            Plan.ExplosiveBarrels);

        // ---- fortification -------------------------------------------------
        if (Plan.bFortify)
        {
            bool bHasFort = false;
            for (TActorIterator<AQuickFortificationSpawnerActor> FortIt(World); FortIt; ++FortIt)
            {
                if (FVector::Dist(MZ->GetActorLocation(), FortIt->GetActorLocation()) < 2500.f)
                {
                    bHasFort = true;
                    break;
                }
            }
            if (!bHasFort)
            {
                const FVector FortLoc = MZ->GetActorLocation();
                AQuickFortificationSpawnerActor* Fort = World->SpawnActor<AQuickFortificationSpawnerActor>(
                    AQuickFortificationSpawnerActor::StaticClass(), FortLoc, MZ->GetActorRotation(), SpawnParams);
                if (Fort)
                {
                    Fort->FortificationPreset = (Preset == EMissionPresetKind::Checkpoint)
                        ? EFortificationPreset::RoadblockCheckpoint
                        : EFortificationPreset::SandbagBunker;
                    Fort->bSpawnHeavyMG = Plan.bSpawnMountedTurret;
                    MZ->FactorySpawnedActors.Add(Fort);   // S26-LOGIC: the fort dies with its zone - this was an orphan before
                    SpawnedForts++;
                    Log += FString::Printf(TEXT("   + fortification: %s\n"),
                        Fort->FortificationPreset == EFortificationPreset::RoadblockCheckpoint
                            ? TEXT("roadblock checkpoint") : TEXT("sandbag bunker"));
                }
            }
        }

        // ---- barrels (deterministic ring, not random) -----------------------
        const TArray<FVector> BarrelRing = FMissionArchetypeModel::PropRingOffsets(
            Plan.ExplosiveBarrels, 450.f, 30.f, 360.f);
        for (const FVector& Offset : BarrelRing)
        {
            // S26-LIFE: drum bottom 2 cm above ground (47, not the old buried 20),
            // textured and rimmed like every other barrel
            const FVector BarrelLoc = MZ->GetActorLocation() + Offset + FVector(0.f, 0.f, 47.f);
            if (AExplosiveBarrelActor* PlanBarrel = World->SpawnActor<AExplosiveBarrelActor>(AExplosiveBarrelActor::StaticClass(),
                BarrelLoc, FRotator::ZeroRotator, SpawnParams))
            {
                MZ->FactorySpawnedActors.Add(PlanBarrel);
                SquadAIMissionFactory::SquadAIApplyPropMaterial(PlanBarrel, TEXT("RustyBarrel"), FLinearColor::White);   // S26-LIFE
                SquadAIMissionFactory::StampIdent(PlanBarrel, TEXT("Explosive Barrel"), TEXT("SquadAI/Missions/Props"));   // S26-FOLDER
                SquadAIMissionFactory::DecorateBarrel(PlanBarrel);   // S26-LIFE
                SpawnedBarrels++;
            }
        }
    }

    Log += FString::Printf(TEXT("Spawned %d encounter volume(s), %d fortification(s), %d barrel(s).\n"),
        SpawnedEncounters, SpawnedForts, SpawnedBarrels);
    return Log;
}

FString USquadAIAutoSetupEditorLibrary::AutoBakeCoverNodesAcrossMap(UWorld* World)
{
    if (!World) return TEXT("ERROR: World is NULL");

    FString Log;
    Log += TEXT("=== AUTO-BAKE COVER NODES ACROSS MAP ===\n");

    ATacticalCoverGeneratorActor* Generator = nullptr;
    for (TActorIterator<ATacticalCoverGeneratorActor> It(World); It; ++It)
    {
        Generator = *It;
        break;
    }

    if (!Generator)
    {
        FActorSpawnParameters SpawnParams;
        SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
        Generator = World->SpawnActor<ATacticalCoverGeneratorActor>(ATacticalCoverGeneratorActor::StaticClass(), FVector(0.f, 0.f, 100.f), FRotator::ZeroRotator, SpawnParams);
        Log += TEXT("Created new ATacticalCoverGeneratorActor\n");
    }

    if (Generator)
    {
        const int32 Count = Generator->BakeCoverPoints();
        Log += FString::Printf(TEXT("Successfully baked and registered %d tactical cover nodes!\n"), Count);
    }

    return Log;
}

FString USquadAIAutoSetupEditorLibrary::AutoSpawnDestroyedVillageInLevel(UWorld* World, FVector Location, int32 BuildingCount)
{
    if (!World) return TEXT("ERROR: World is NULL");

    // High-altitude ground raycast to find terrain elevation
    FHitResult Hit;
    FCollisionQueryParams TraceParams;
    if (World->LineTraceSingleByChannel(Hit, Location + FVector(0.f, 0.f, 15000.f), Location - FVector(0.f, 0.f, 50000.f), ECC_Visibility, TraceParams))
    {
        Location = Hit.ImpactPoint + FVector(0.f, 0.f, 10.f);
    }

    FActorSpawnParameters SpawnParams;
    SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

    ADestroyedVillageCompoundActor* Village = World->SpawnActor<ADestroyedVillageCompoundActor>(
        ADestroyedVillageCompoundActor::StaticClass(),
        Location,
        FRotator::ZeroRotator,
        SpawnParams);

    if (Village)
    {
        Village->BuildingCount = BuildingCount;
        Village->BuildVillage();
        return FString::Printf(TEXT("Successfully generated war-torn Middle Eastern village with %d buildings at %s!"), BuildingCount, *Location.ToString());
    }

    return TEXT("ERROR: Failed to spawn Destroyed Village Actor");
}


// ===========================================================================
//  S19-TEMPLATE: the mission factory
// ===========================================================================

namespace SquadAIMissionFactory
{
    /** Drop a raw point onto the ground (downward trace), lifted by LiftCm. */
    static FVector GroundPoint(UWorld* World, const FVector& Raw, float LiftCm)
    {
        if (!World) return Raw;
        FCollisionQueryParams Params(SCENE_QUERY_STAT(MissionFactoryGround), /*bTraceComplex=*/false);
        // S26-GROUND2: +1500 could start INSIDE a hill when the authored point came
        // from a sky-high marker; trace from the sky to far below instead.
        auto TraceDown = [&](const FVector& At) -> TOptional<FVector>
        {
            // S26-FIXALL: multi-hit trace, take the DEEPEST blocking hit. A
            // banner or debris piece tracing down inside a fortified base
            // used to land on a ROOF, a crate or a wall first and spawn in
            // the sky; the terrain is always the LAST thing the ray meets.
            TArray<FHitResult> Hits;
            if (World->LineTraceMultiByChannel(Hits, At + FVector(0.f, 0.f, 50000.f),
                At - FVector(0.f, 0.f, 150000.f), ECC_Visibility, Params) && Hits.Num() > 0)
            {
                return TOptional<FVector>(Hits.Last().ImpactPoint);
            }
            return TOptional<FVector>();
        };
        if (const TOptional<FVector> Direct = TraceDown(Raw))
        {
            return Direct.GetValue() + FVector(0.f, 0.f, LiftCm);
        }
        // S26-LANDING: a straight miss used to return the authored point - and
        // an authored point from map data can be a kilometre in the SKY. Spiral
        // outward until solid ground appears (map edge, water void, anything).
        for (float Rad = 300.f; Rad <= 8100.f; Rad *= 3.f)
        {
            for (int32 Ang = 0; Ang < 8; ++Ang)
            {
                const FVector Probe = Raw + FRotator(0.f, Ang * 45.f, 0.f).Vector() * Rad;
                if (const TOptional<FVector> Found = TraceDown(Probe))
                {
                    return Found.GetValue() + FVector(0.f, 0.f, LiftCm);
                }
            }
        }
        return Raw; // truly nothing solid within 81 m: keep the authored point
    }

    /** World point for ring offset Index, grounded, or the origin if out of range. */
    static FVector RingPoint(UWorld* World, const FVector& Origin, const TArray<FVector>& Offsets,
        int32 Index, float LiftCm)
    {
        if (!Offsets.IsValidIndex(Index)) return Origin;
        return GroundPoint(World, Origin + Offsets[Index], LiftCm);
    }

    // S26-MAT: every factory prop wears its texture - SupplyCrate, CommsPanel,
    // HazardPad, Concrete, CamoTarp - on the shared M_SquadAIProp (Tex x Tint).
    // No texture in the project yet -> the prop keeps its own material.
    static void SquadAIApplyPropMaterial(AActor* A, const TCHAR* TexKey, const FLinearColor& Tint)
    {
        if (!A) return;
        USquadAIAssetCacheSubsystem* Cache = USquadAIAssetCacheSubsystem::Get(A);
        if (!Cache) return;
        UMaterialInterface* M = Cache->GetPropMaterial(TexKey, Tint);
        if (!M) return;
        TInlineComponentArray<UStaticMeshComponent*> Meshes(A);
        for (UStaticMeshComponent* MC : Meshes)
        {
            if (MC && MC->GetStaticMesh()) { MC->SetMaterial(0, M); }
        }
    }

    // =========================================================================
    // S26-DETAIL: multi-piece mission props. Each factory prop keeps its
    // gameplay root (hit detection, quest wiring) and gains decorative
    // static-mesh pieces around it - a truck gets wheels, a barrel gets rims
    // and a stain, an intel site gets a dish and a generator. Pieces are
    // NoCollision so a bullet aimed at the root NEVER lands on decoration,
    // they attach with KeepWorld so they follow the actor, and CreationMethod
    // Native so they save with the level.
    // =========================================================================
    enum class EPropShape { Cube, Cyl, Sphere };

    static UMaterialInterface* PropMat(AActor* A, const TCHAR* TexKey, const FLinearColor& Tint, float UVScale = 1.f)
    {
        USquadAIAssetCacheSubsystem* Cache = USquadAIAssetCacheSubsystem::Get(A);
        if (!Cache) return nullptr;
        UMaterialInterface* M = Cache->GetPropMaterial(TexKey, Tint, UVScale);   // S26-PATINA: callers can tile big surfaces
        return M ? M : Cache->GetDefaultBasicMaterial();
    }

    static UStaticMeshComponent* AddPropPiece(AActor* Owner, EPropShape Shape, const FVector& RelLoc,
        const FRotator& RelRot, const FVector& SizeCm, UMaterialInterface* Mat)
    {
        USquadAIAssetCacheSubsystem* Cache = USquadAIAssetCacheSubsystem::Get(Owner);
        if (!Owner || !Cache || !Owner->GetRootComponent()) return nullptr;
        UStaticMesh* Mesh = (Shape == EPropShape::Cube) ? Cache->GetCubeMesh()
            : (Shape == EPropShape::Cyl) ? Cache->GetCylinderMesh() : Cache->GetSphereMesh();
        if (!Mesh) return nullptr;
        UStaticMeshComponent* C = NewObject<UStaticMeshComponent>(Owner);
        C->ComponentTags.Add(TEXT("SquadAIDetailPiece"));
        C->CreationMethod = EComponentCreationMethod::Native;   // saved with the level
        C->SetStaticMesh(Mesh);
        C->SetCollisionEnabled(ECollisionEnabled::NoCollision);  // decoration never eats a hit meant for the root
        C->SetCanEverAffectNavigation(false);
        const float Yaw = Owner->GetActorRotation().Yaw;
        const FVector WorldLoc = Owner->GetActorLocation() + RelLoc.RotateAngleAxis(Yaw, FVector::UpVector);
        C->SetWorldLocationAndRotation(WorldLoc, RelRot + FRotator(0.f, Yaw, 0.f));
        // cube/sphere are 100 cm; the cylinder is 100 cm tall and 50 cm radius
        C->SetWorldScale3D(Shape == EPropShape::Cyl
            ? FVector(SizeCm.X / 50.f, SizeCm.X / 50.f, SizeCm.Z / 100.f)
            : SizeCm / 100.f);
        if (Mat) { C->SetMaterial(0, Mat); }
        C->RegisterComponent();
        C->AttachToComponent(Owner->GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
        return C;
    }

    /** Intel site: mast + dish + field generator + conduit. */
    static void DecorateIntelSite(AActor* Site)
    {
        const float G = -2.f;   // ground relative to the actor origin (ring lift 2 cm)
        AddPropPiece(Site, EPropShape::Cyl, FVector(55.f, 0.f, G + 200.f), FRotator::ZeroRotator,
            FVector(5.f, 0.f, 400.f), PropMat(Site, TEXT("CommsPanel"), FLinearColor(0.6f, 0.62f, 0.6f, 1.f)));
        AddPropPiece(Site, EPropShape::Sphere, FVector(55.f, 0.f, G + 415.f), FRotator(-35.f, 0.f, 0.f),
            FVector(34.f, 34.f, 10.f), PropMat(Site, TEXT("CommsPanel"), FLinearColor(0.92f, 0.92f, 0.95f, 1.f)));
        AddPropPiece(Site, EPropShape::Cube, FVector(-75.f, 45.f, G + 27.5f), FRotator(0.f, 12.f, 0.f),
            FVector(80.f, 55.f, 55.f), PropMat(Site, TEXT("OliveArmor"), FLinearColor(0.55f, 0.58f, 0.45f, 1.f)));
        AddPropPiece(Site, EPropShape::Cube, FVector(-15.f, 45.f, G + 4.f), FRotator::ZeroRotator,
            FVector(120.f, 6.f, 6.f), PropMat(Site, TEXT("ScorchedMetal"), FLinearColor(0.1f, 0.1f, 0.1f, 1.f)));
        // S26-SURF: generator exhaust stub + a recessed door line on its face
        AddPropPiece(Site, EPropShape::Cyl, FVector(-75.f, 45.f, G + 64.f), FRotator(0.f, 12.f, 0.f),
            FVector(5.f, 0.f, 18.f), PropMat(Site, TEXT("ScorchedMetal"), FLinearColor(0.15f, 0.15f, 0.15f, 1.f)));
        AddPropPiece(Site, EPropShape::Cube, FVector(-75.f, 73.f, G + 30.f), FRotator(0.f, 12.f, 0.f),
            FVector(50.f, 3.f, 35.f), PropMat(Site, TEXT("ScorchedMetal"), FLinearColor(0.12f, 0.12f, 0.12f, 1.f)));
        Site->MarkPackageDirty();
    }

    /** Supply crate: banded lid + two companion crates. */
    static void DecorateSupplyCrate(AActor* Crate)
    {
        const float G = -2.f;
        AddPropPiece(Crate, EPropShape::Cube, FVector(0.f, 0.f, 50.f), FRotator::ZeroRotator,
            FVector(59.f, 59.f, 7.f), PropMat(Crate, TEXT("SupplyCrate"), FLinearColor(0.75f, 0.72f, 0.62f, 1.f)));
        for (float SX = -1.f; SX <= 1.f; SX += 2.f)
        {
            AddPropPiece(Crate, EPropShape::Cube, FVector(SX * 16.f, 0.f, 24.f), FRotator::ZeroRotator,
                FVector(6.f, 61.f, 47.f), PropMat(Crate, TEXT("ScorchedMetal"), FLinearColor(0.15f, 0.15f, 0.15f, 1.f)));
        }
        AddPropPiece(Crate, EPropShape::Cube, FVector(85.f, -25.f, G + 25.f), FRotator(0.f, 18.f, 0.f),
            FVector(60.f, 60.f, 50.f), PropMat(Crate, TEXT("SupplyCrate"), FLinearColor::White));
        AddPropPiece(Crate, EPropShape::Cube, FVector(70.f, 45.f, G + 19.f), FRotator(0.f, -25.f, 0.f),
            FVector(45.f, 45.f, 38.f), PropMat(Crate, TEXT("SupplyCrate"), FLinearColor(0.9f, 0.88f, 0.8f, 1.f)));
        // S26-SURF: lid latches + steel corner brackets
        for (float LX = -1.f; LX <= 1.f; LX += 2.f)
        {
            AddPropPiece(Crate, EPropShape::Cube, FVector(LX * 18.f, 31.f, 50.f), FRotator::ZeroRotator,
                FVector(10.f, 6.f, 12.f), PropMat(Crate, TEXT("ScorchedMetal"), FLinearColor(0.2f, 0.2f, 0.2f, 1.f)));
        }
        for (float CX = -1.f; CX <= 1.f; CX += 2.f)
        {
            for (float CY = -1.f; CY <= 1.f; CY += 2.f)
            {
                AddPropPiece(Crate, EPropShape::Cube, FVector(CX * 25.f, CY * 25.f, 48.f), FRotator::ZeroRotator,
                    FVector(14.f, 14.f, 10.f), PropMat(Crate, TEXT("MetalPlate"), FLinearColor(0.6f, 0.62f, 0.58f, 1.f)));
            }
        }
        Crate->MarkPackageDirty();
    }

    /** Sabotage target: staggered ammo stack + open lid + charge light. */
    static void DecorateSabotageTarget(AActor* Target)
    {
        const float G = -2.f;
        AddPropPiece(Target, EPropShape::Cube, FVector(0.f, 0.f, G + 24.f), FRotator(0.f, 8.f, 0.f),
            FVector(95.f, 60.f, 48.f), PropMat(Target, TEXT("AmmoBox"), FLinearColor::White));
        AddPropPiece(Target, EPropShape::Cube, FVector(10.f, -8.f, G + 68.f), FRotator(0.f, -14.f, 0.f),
            FVector(75.f, 50.f, 40.f), PropMat(Target, TEXT("AmmoBox"), FLinearColor(0.9f, 0.9f, 0.85f, 1.f)));
        AddPropPiece(Target, EPropShape::Cube, FVector(58.f, 18.f, G + 14.f), FRotator(65.f, 40.f, 0.f),
            FVector(55.f, 55.f, 5.f), PropMat(Target, TEXT("AmmoBox"), FLinearColor(0.6f, 0.6f, 0.55f, 1.f)));
        AddPropPiece(Target, EPropShape::Sphere, FVector(10.f, -8.f, G + 92.f), FRotator::ZeroRotator,
            FVector(8.f, 8.f, 8.f), PropMat(Target, TEXT("ScorchedMetal"), FLinearColor(1.f, 0.1f, 0.05f, 1.f)));
        // S26-SURF: stencil plate on the big box + det cord snaking to it
        AddPropPiece(Target, EPropShape::Cube, FVector(0.f, 31.f, G + 26.f), FRotator(0.f, 8.f, 0.f),
            FVector(60.f, 3.f, 20.f), PropMat(Target, TEXT("MetalPlate"), FLinearColor(0.9f, 0.9f, 0.85f, 1.f)));
        AddPropPiece(Target, EPropShape::Cyl, FVector(-32.f, -22.f, G + 4.f), FRotator(0.f, 35.f, 90.f),
            FVector(1.2f, 0.f, 55.f), PropMat(Target, TEXT("ScorchedMetal"), FLinearColor(0.9f, 0.75f, 0.1f, 1.f)));
        Target->MarkPackageDirty();
    }

    /** Escort truck: camo cab + tarp hump + six wheels + bumper + fuel can. */
    static void DecorateConvoy(AActor* Convoy)
    {
        const float G = -2.f;   // truck chassis bottom sits at the actor origin
        AddPropPiece(Convoy, EPropShape::Cube, FVector(0.f, 87.f, G + 127.5f), FRotator::ZeroRotator,
            FVector(112.f, 88.f, 75.f), PropMat(Convoy, TEXT("CamoTarp"), FLinearColor(0.85f, 0.9f, 0.8f, 1.f)));
        AddPropPiece(Convoy, EPropShape::Cube, FVector(0.f, -40.f, G + 117.5f), FRotator::ZeroRotator,
            FVector(124.f, 150.f, 55.f), PropMat(Convoy, TEXT("CamoTarp"), FLinearColor(0.75f, 0.8f, 0.7f, 1.f)));
        const float Axles[3] = { 85.f, -15.f, -95.f };
        for (const float AY : Axles)
        {
            for (float Side = -1.f; Side <= 1.f; Side += 2.f)
            {
                AddPropPiece(Convoy, EPropShape::Cyl, FVector(Side * 63.f, AY, G + 26.f), FRotator(0.f, 0.f, 90.f),
                    FVector(26.f, 0.f, 18.f), PropMat(Convoy, TEXT("ScorchedMetal"), FLinearColor(0.08f, 0.08f, 0.08f, 1.f)));
            }
        }
        AddPropPiece(Convoy, EPropShape::Cube, FVector(0.f, 138.f, G + 30.f), FRotator::ZeroRotator,
            FVector(16.f, 108.f, 22.f), PropMat(Convoy, TEXT("ScorchedMetal"), FLinearColor(0.12f, 0.12f, 0.12f, 1.f)));
        AddPropPiece(Convoy, EPropShape::Cube, FVector(42.f, -128.f, G + 23.f), FRotator(0.f, 10.f, 0.f),
            FVector(25.f, 40.f, 45.f), PropMat(Convoy, TEXT("OliveArmor"), FLinearColor(0.55f, 0.58f, 0.45f, 1.f)));
        // S26-SURF: headlights, fenders over the axles, tie straps over the tarp
        for (float HX = -1.f; HX <= 1.f; HX += 2.f)
        {
            AddPropPiece(Convoy, EPropShape::Sphere, FVector(HX * 38.f, 133.f, G + 100.f), FRotator::ZeroRotator,
                FVector(14.f, 8.f, 14.f), PropMat(Convoy, TEXT("ScorchedMetal"), FLinearColor(0.95f, 0.95f, 0.8f, 1.f)));
        }
        for (const float AY : Axles)
        {
            AddPropPiece(Convoy, EPropShape::Cube, FVector(0.f, AY, G + 62.f), FRotator::ZeroRotator,
                FVector(136.f, 58.f, 6.f), PropMat(Convoy, TEXT("CamoTarp"), FLinearColor(0.6f, 0.64f, 0.55f, 1.f)));
        }
        for (int32 StrapI = 0; StrapI < 3; ++StrapI)
        {
            AddPropPiece(Convoy, EPropShape::Cube, FVector(0.f, -100.f + StrapI * 60.f, G + 148.f), FRotator::ZeroRotator,
                FVector(130.f, 8.f, 40.f), PropMat(Convoy, TEXT("ScorchedMetal"), FLinearColor(0.15f, 0.15f, 0.15f, 1.f)));
        }
        Convoy->MarkPackageDirty();
    }

    /** Extraction pad: painted H, corner light posts, windsock. */
    static void DecorateExtractionPad(AActor* Pad)
    {
        const float G = -2.f;
        const FLinearColor White(0.95f, 0.95f, 0.95f, 1.f);
        AddPropPiece(Pad, EPropShape::Cube, FVector(-90.f, 0.f, G + 8.f), FRotator::ZeroRotator,
            FVector(12.f, 180.f, 8.f), PropMat(Pad, TEXT("ScorchedMetal"), White, 1.8f));   // S26-PATINA
        AddPropPiece(Pad, EPropShape::Cube, FVector(90.f, 0.f, G + 8.f), FRotator::ZeroRotator,
            FVector(12.f, 180.f, 8.f), PropMat(Pad, TEXT("ScorchedMetal"), White, 1.8f));
        AddPropPiece(Pad, EPropShape::Cube, FVector(0.f, 0.f, G + 8.f), FRotator::ZeroRotator,
            FVector(190.f, 12.f, 8.f), PropMat(Pad, TEXT("ScorchedMetal"), White, 1.9f));
        for (float SX = -1.f; SX <= 1.f; SX += 2.f)
        {
            for (float SY = -1.f; SY <= 1.f; SY += 2.f)
            {
                AddPropPiece(Pad, EPropShape::Cyl, FVector(SX * 540.f, SY * 540.f, G + 65.f), FRotator::ZeroRotator,
                    FVector(7.f, 0.f, 130.f), PropMat(Pad, TEXT("MetalPlate"), FLinearColor(0.8f, 0.82f, 0.78f, 1.f)));
                AddPropPiece(Pad, EPropShape::Sphere, FVector(SX * 540.f, SY * 540.f, G + 135.f), FRotator::ZeroRotator,
                    FVector(11.f, 11.f, 11.f), PropMat(Pad, TEXT("ScorchedMetal"), FLinearColor(1.f, 0.65f, 0.1f, 1.f)));
            }
        }
        AddPropPiece(Pad, EPropShape::Cyl, FVector(620.f, -620.f, G + 225.f), FRotator::ZeroRotator,
            FVector(5.f, 0.f, 450.f), PropMat(Pad, TEXT("MetalPlate"), FLinearColor(0.7f, 0.72f, 0.68f, 1.f)));
        AddPropPiece(Pad, EPropShape::Cube, FVector(662.f, -620.f, G + 430.f), FRotator(0.f, 0.f, -6.f),
            FVector(72.f, 18.f, 18.f), PropMat(Pad, TEXT("ScorchedMetal"), FLinearColor(1.f, 0.45f, 0.08f, 1.f)));
        // S26-SURF: dark tire-wear bands running through the H - a pad that is USED
        for (float SY = -1.f; SY <= 1.f; SY += 2.f)
        {
            AddPropPiece(Pad, EPropShape::Cube, FVector(SY * 160.f, 0.f, G + 6.f), FRotator::ZeroRotator,
                FVector(60.f, 400.f, 3.f), PropMat(Pad, TEXT("ScorchedMetal"), FLinearColor(0.1f, 0.1f, 0.1f, 1.f), 4.0f));   // S26-PATINA: 4 m of wear, not one stretched smear
        }
        Pad->MarkPackageDirty();
    }

    /** Capture point: concrete base blocks + a field radio beside the pole. */
    static void DecorateCapturePoint(AActor* Point)
    {
        const float G = -2.f;
        const float RingYaws[3] = { 20.f, 140.f, 260.f };
        for (const float Y : RingYaws)
        {
            const FVector Dir = FRotator(0.f, Y, 0.f).Vector();
            AddPropPiece(Point, EPropShape::Cube, Dir * 95.f + FVector(0.f, 0.f, G + 14.f), FRotator(0.f, Y, 0.f),
                FVector(55.f, 55.f, 28.f), PropMat(Point, TEXT("Concrete"), FLinearColor(0.85f, 0.85f, 0.82f, 1.f)));
        }
        AddPropPiece(Point, EPropShape::Cube, FVector(110.f, 0.f, G + 15.f), FRotator(0.f, 25.f, 0.f),
            FVector(40.f, 40.f, 30.f), PropMat(Point, TEXT("OliveArmor"), FLinearColor(0.55f, 0.58f, 0.45f, 1.f)));
        AddPropPiece(Point, EPropShape::Cyl, FVector(110.f, 0.f, G + 120.f), FRotator(0.f, 25.f, 0.f),
            FVector(2.5f, 0.f, 180.f), PropMat(Point, TEXT("OliveArmor"), FLinearColor(0.4f, 0.42f, 0.35f, 1.f)));
        // S26-SURF: crossbar at the masthead + guy wires to concrete anchors
        AddPropPiece(Point, EPropShape::Cube, FVector(0.f, 0.f, 188.f), FRotator(0.f, 90.f, 0.f),
            FVector(45.f, 6.f, 6.f), PropMat(Point, TEXT("OliveArmor"), FLinearColor(0.45f, 0.48f, 0.38f, 1.f)));
        for (float GX = -1.f; GX <= 1.f; GX += 2.f)
        {
            AddPropPiece(Point, EPropShape::Cube, FVector(GX * 72.f, 0.f, 100.f), FRotator(0.f, 0.f, GX * -28.f),
                FVector(4.f, 4.f, 185.f), PropMat(Point, TEXT("ScorchedMetal"), FLinearColor(0.12f, 0.12f, 0.12f, 1.f)));
            AddPropPiece(Point, EPropShape::Cube, FVector(GX * 145.f, 0.f, G + 6.f), FRotator(0.f, GX * 20.f, 0.f),
                FVector(18.f, 18.f, 12.f), PropMat(Point, TEXT("Concrete"), FLinearColor(0.75f, 0.75f, 0.72f, 1.f)));
        }
        Point->MarkPackageDirty();
    }

    /** Defended asset: antenna mast + leaned armor plates + ready crates. */
    static void DecorateDefendedAsset(AActor* Asset)
    {
        const float G = -2.f;
        AddPropPiece(Asset, EPropShape::Cyl, FVector(-60.f, -60.f, 350.f), FRotator::ZeroRotator,
            FVector(4.f, 0.f, 380.f), PropMat(Asset, TEXT("OliveArmor"), FLinearColor(0.45f, 0.48f, 0.38f, 1.f)));
        AddPropPiece(Asset, EPropShape::Sphere, FVector(-60.f, -60.f, 545.f), FRotator::ZeroRotator,
            FVector(8.f, 8.f, 8.f), PropMat(Asset, TEXT("ScorchedMetal"), FLinearColor(1.f, 0.15f, 0.1f, 1.f)));
        for (float Side = -1.f; Side <= 1.f; Side += 2.f)
        {
            AddPropPiece(Asset, EPropShape::Cube, FVector(Side * 112.f, -Side * 40.f, G + 72.f),
                FRotator(0.f, Side * 40.f, Side * -28.f), FVector(90.f, 110.f, 12.f),
                PropMat(Asset, TEXT("OliveArmor"), FLinearColor(0.5f, 0.53f, 0.42f, 1.f)));
        }
        AddPropPiece(Asset, EPropShape::Cube, FVector(150.f, 120.f, G + 29.f), FRotator(0.f, 15.f, 0.f),
            FVector(70.f, 70.f, 58.f), PropMat(Asset, TEXT("SupplyCrate"), FLinearColor::White));
        AddPropPiece(Asset, EPropShape::Cube, FVector(172.f, 58.f, G + 22.f), FRotator(0.f, -20.f, 0.f),
            FVector(55.f, 55.f, 45.f), PropMat(Asset, TEXT("SupplyCrate"), FLinearColor(0.9f, 0.88f, 0.8f, 1.f)));
        // S26-SURF: door inset with hinges on the face, hatch frame on the roof
        AddPropPiece(Asset, EPropShape::Cube, FVector(101.f, 20.f, 70.f), FRotator::ZeroRotator,
            FVector(4.f, 90.f, 110.f), PropMat(Asset, TEXT("ScorchedMetal"), FLinearColor(0.18f, 0.18f, 0.16f, 1.f)));
        for (float HY = -1.f; HY <= 1.f; HY += 2.f)
        {
            AddPropPiece(Asset, EPropShape::Cube, FVector(103.f, 20.f + HY * 38.f, 70.f), FRotator::ZeroRotator,
                FVector(8.f, 10.f, 18.f), PropMat(Asset, TEXT("ScorchedMetal"), FLinearColor(0.1f, 0.1f, 0.1f, 1.f)));
        }
        AddPropPiece(Asset, EPropShape::Cube, FVector(0.f, 0.f, 162.f), FRotator(0.f, 25.f, 0.f),
            FVector(90.f, 90.f, 8.f), PropMat(Asset, TEXT("MetalPlate"), FLinearColor(0.7f, 0.72f, 0.66f, 1.f)));
        Asset->MarkPackageDirty();
    }

    /** Explosive barrel: rim rings + cap + oil stain + a leaning spare. */
    static void DecorateBarrel(AActor* Barrel)
    {
        const float G = -47.f;   // barrel spawn lift: root drum bottom 2 cm above ground
        const FLinearColor Dark(0.12f, 0.12f, 0.12f, 1.f);
        AddPropPiece(Barrel, EPropShape::Cyl, FVector(0.f, 0.f, -22.f), FRotator::ZeroRotator,
            FVector(34.f, 0.f, 7.f), PropMat(Barrel, TEXT("ScorchedMetal"), Dark));
        AddPropPiece(Barrel, EPropShape::Cyl, FVector(0.f, 0.f, 22.f), FRotator::ZeroRotator,
            FVector(34.f, 0.f, 7.f), PropMat(Barrel, TEXT("ScorchedMetal"), Dark));
        AddPropPiece(Barrel, EPropShape::Cyl, FVector(0.f, 0.f, 47.f), FRotator::ZeroRotator,
            FVector(28.f, 0.f, 6.f), PropMat(Barrel, TEXT("ScorchedMetal"), FLinearColor(0.2f, 0.2f, 0.2f, 1.f)));
        if (UStaticMeshComponent* Stain = AddPropPiece(Barrel, EPropShape::Cyl, FVector(0.f, 0.f, G + 1.f),
            FRotator::ZeroRotator, FVector(75.f, 0.f, 2.f), PropMat(Barrel, TEXT("ScorchedMetal"),
            FLinearColor(0.05f, 0.05f, 0.05f, 1.f))))
        {
            Stain->SetCastShadow(false);   // a stain is not a solid thing
        }
        AddPropPiece(Barrel, EPropShape::Cyl, FVector(82.f, 16.f, G + 44.f), FRotator(-14.f, 15.f, 0.f),
            FVector(30.f, 0.f, 90.f), PropMat(Barrel, TEXT("RustyBarrel"), FLinearColor(0.9f, 0.75f, 0.65f, 1.f)));
        // S26-SURF: rust streaks running down the drum face
        for (float DX = -1.f; DX <= 1.f; DX += 2.f)
        {
            AddPropPiece(Barrel, EPropShape::Cube, FVector(DX * 18.f, 29.f, 5.f), FRotator(0.f, 0.f, DX * 4.f),
                FVector(7.f, 4.f, 55.f), PropMat(Barrel, TEXT("ScorchedMetal"), FLinearColor(0.15f, 0.1f, 0.06f, 1.f)));
        }
        Barrel->MarkPackageDirty();
    }

    // S26-FOLDER: every actor the factory stamps gets a NAME and a HOME in the
    // World Outliner. "Many mesh actors you don't know what they are" ends
    // here - a level full of StaticMeshActor_214 is unreadable.
    static void StampIdent(AActor* A, const FString& Label, const TCHAR* Folder)
    {
        if (!A) return;
#if WITH_EDITOR
        A->SetActorLabel(Label);
        A->SetFolderPath(FName(FString(Folder)));
#endif
    }

    /** S26-LIFE: a scenery piece owned by the mission - purged with it. */
    /**
     * S26-SPHERE2: find-or-create a per-zone HISM for repeated scenery.
     * Rocks and brush come in dozens per zone; one component with N
     * instances beats N scenery actors (draw calls, culling, the outliner),
     * and ClearInstances makes an in-place rebuild replay identically -
     * the same contract the shell-casing HISM already follows.
     */
    static UHierarchicalInstancedStaticMeshComponent* ZoneSceneryHISM(AMissionZone* Zone,
        const TCHAR* Name, UStaticMesh* Mesh, UMaterialInterface* Mat)
    {
        if (!Zone || !Mesh || !Zone->GetRootComponent()) return nullptr;
        {
            TArray<UInstancedStaticMeshComponent*> Comps;
            Zone->GetComponents<UInstancedStaticMeshComponent>(Comps);
            for (UInstancedStaticMeshComponent* C : Comps)
            {
                if (C && C->GetFName() == Name)
                {
                    if (UHierarchicalInstancedStaticMeshComponent* H = Cast<UHierarchicalInstancedStaticMeshComponent>(C))
                    {
                        H->ClearInstances();   // rebuild-safe: the scatter replays identically
                        return H;
                    }
                }
            }
        }
        UHierarchicalInstancedStaticMeshComponent* H = NewObject<UHierarchicalInstancedStaticMeshComponent>(Zone, FName(Name));
        if (!H) return nullptr;
        H->RegisterComponent();
        H->AttachToComponent(Zone->GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
        H->SetMobility(Zone->GetRootComponent()->Mobility);   // never more static than the zone
        H->SetStaticMesh(Mesh);
        H->SetCollisionProfileName(TEXT("NoCollision"));
        H->SetCastShadow(false);
        H->SetCanEverAffectNavigation(false);
        if (Mat) { H->SetMaterial(0, Mat); }
        return H;
    }

    static AStaticMeshActor* SceneryPiece(UWorld* World, AMissionZone* Zone, const FVector& Loc,
        const FRotator& Rot, UStaticMesh* Mesh, const FVector& Scale, UMaterialInterface* Mat,
        const FString& Label = FString(), const TCHAR* Folder = TEXT("SquadAI/Mission Scenery"))
    {
        if (!World || !Mesh) return nullptr;
        FActorSpawnParameters Params;
        Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
        AStaticMeshActor* Piece = World->SpawnActor<AStaticMeshActor>(AStaticMeshActor::StaticClass(), Loc, Rot, Params);
        if (Piece && Piece->GetStaticMeshComponent())
        {
            if (Zone)
            {
                Piece->AttachToComponent(Zone->GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
                Zone->FactorySpawnedActors.Add(Piece);
            }
            Piece->GetStaticMeshComponent()->SetStaticMesh(Mesh);
            Piece->GetStaticMeshComponent()->SetRelativeScale3D(Scale);
            Piece->GetStaticMeshComponent()->SetCollisionEnabled(ECollisionEnabled::NoCollision);
            Piece->GetStaticMeshComponent()->SetCanEverAffectNavigation(false);
            if (Mat) { Piece->GetStaticMeshComponent()->SetMaterial(0, Mat); }
        }
        StampIdent(Piece, Label.IsEmpty() ? FString(TEXT("Scenery Piece")) : Label, Folder);   // S26-FOLDER
        return Piece;
    }

    /** S26-LIFE: a shell crater - scorched plate + heaved rim stones. */
    static void DecorateCrater(UWorld* World, AMissionZone* Zone, USquadAIAssetCacheSubsystem* Cache, const FVector& Loc)
    {
        if (!World || !Zone || !Cache) return;
        UMaterialInterface* Scorch = Cache->GetPropMaterial(TEXT("ScorchedMetal"), FLinearColor(0.05f, 0.045f, 0.04f, 1.f));
        UMaterialInterface* Dirt = Cache->GetPropMaterial(TEXT("Concrete"), FLinearColor(0.42f, 0.36f, 0.28f, 1.f));
        if (AStaticMeshActor* Plate = SceneryPiece(World, Zone, Loc, FRotator::ZeroRotator,
            Cache->GetCylinderMesh(), FVector(2.6f, 2.6f, 0.06f), Scorch, TEXT("Shell Crater")))
        {
            Plate->GetStaticMeshComponent()->SetCastShadow(false);
        }
        for (int32 Ri = 0; Ri < 6; ++Ri)
        {
            const float Ra = Ri * 60.f + 9.f;
            SceneryPiece(World, Zone, Loc + FRotator(0.f, Ra, 0.f).Vector() * 245.f + FVector(0.f, 0.f, 7.f),
                FRotator(14.f, Ra, 18.f), Cache->GetCubeMesh(), FVector(0.5f, 0.4f, 0.22f), Dirt, TEXT("Crater Rim Stone"));
        }
    }
}

AMissionZone* USquadAIAutoSetupEditorLibrary::BuildMissionFromTemplate_GetZone(UWorld* World, UMissionTemplateAsset* Template,
    FVector Origin, FRotator Rotation, bool bAppendToQuestChain, FString* OutReport)
{
    const auto Finish = [&OutReport](const FString& Report, AMissionZone* Zone) -> AMissionZone*
    {
        if (OutReport) *OutReport = Report;
        return Zone;
    };
    if (!World) return Finish(TEXT("ERROR: World is NULL"), nullptr);
    if (!Template) return Finish(TEXT("ERROR: no mission template given."), nullptr);

    // ---- 1. validate before building anything -------------------------------
    FMissionSetupFacts Facts;
    Facts.bReach = (Template->MissionType == EMissionType::Reach);
    Facts.bClear = (Template->MissionType == EMissionType::Clear);
    Facts.bDefend = (Template->MissionType == EMissionType::Defend);
    Facts.bHVTHunt = false;              // the template has no HVT group; the zone can add it after
    Facts.bArtillerySpotter = false;
    Facts.bEscort = Template->bEscort;
    Facts.EscortRouteLegs = Template->EscortRouteLegs;
    Facts.IntelSiteCount = Template->IntelSiteCount;
    Facts.SupplyCrateCount = Template->SupplyCrateCount;
    Facts.SabotageTargetCount = Template->SabotageTargetCount;
    Facts.POWCaptiveCount = Template->POWCaptiveCount;
    Facts.bPOWClassSet = (Template->POWClass != nullptr);
    Facts.bExtraction = Template->bExtraction;
    Facts.bRequireExtraction = Template->bRequireExtraction;
    Facts.ExtractionHoldSeconds = Template->ExtractionHoldSeconds;
    Facts.CapturePointCount = Template->CapturePointCount;      // S19-CAP
    Facts.bDefendedAsset = Template->bDefendedAsset;            // S19-ASSET
    Facts.bInterdiction = Template->bInterdiction;              // S19-INTERDICT
    Facts.InterdictionCourierCount = Template->InterdictionCourierCount;
    Facts.InterdictionStopQuota = Template->InterdictionStopQuota;
    Facts.TimeLimitSeconds = Template->TimeLimitSeconds;
    Facts.ParTimeSeconds = Template->ParTimeSeconds;
    Facts.TotalWaves = Template->TotalWaves;

    TArray<FString> Notes;
    const int32 Errors = FMissionArchetypeModel::ValidateSetup(Facts, Notes);

    FString Log;
    Log += TEXT("=== BUILD MISSION FROM TEMPLATE ===\n");
    Log += FString::Printf(TEXT("Template: %s (%s)\n"),
        *Template->GetName(),
        Template->MissionType == EMissionType::Reach ? TEXT("Reach") :
        Template->MissionType == EMissionType::Clear ? TEXT("Clear") : TEXT("Defend"));
    for (const FString& Note : Notes)
    {
        Log += TEXT("   ") + Note + TEXT("\n");
    }
    if (Errors > 0)
    {
        Log += FString::Printf(TEXT("REFUSED: %d error(s) above - nothing was built. Fix the template and run it again.\n"), Errors);
        UE_LOG(LogTemp, Warning, TEXT("%s"), *Log);
        return Finish(Log, nullptr);
    }

    FActorSpawnParameters SpawnParams;
    SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;

    // ---- 2. the mission zone -------------------------------------------------
    AMissionZone* Zone = World->SpawnActor<AMissionZone>(AMissionZone::StaticClass(), Origin, Rotation, SpawnParams);
    if (!Zone)
    {
        Log += TEXT("ERROR: could not spawn the mission zone.\n");
        return Finish(Log, nullptr);
    }
#if WITH_EDITOR
    Zone->SetActorLabel(Template->MissionName.IsEmpty() ? Template->GetName() : Template->MissionName.ToString());
#endif

    Zone->MissionType = Template->MissionType;
    Zone->MissionDescription = Template->MissionDescription;
    Zone->CustomBadgeText = Template->CustomBadgeText;

    // S26-VIS: the zone's marker wears the mission's color - blue hold, red
    // assault, green recon, amber extraction - at a size you can actually see
    // from height. Gray 1 m engine slabs told the user nothing about the campaign.
    if (Zone->VisualMarker)
    {
        FLinearColor ZoneColor(0.85f, 0.15f, 0.12f, 1.f);            // Clear = assault red
        if (Template->MissionType == EMissionType::Defend)          { ZoneColor = FLinearColor(0.15f, 0.40f, 0.90f, 1.f); }
        else if (Template->MissionType == EMissionType::Reach)      { ZoneColor = FLinearColor(0.20f, 0.60f, 0.25f, 1.f); }
        if (Template->bExtraction)                                   { ZoneColor = FLinearColor(0.95f, 0.75f, 0.10f, 1.f); }
        if (UMaterialInterface* BaseMat = LoadObject<UMaterialInterface>(nullptr,
            TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial")))
        {
            Zone->VisualMarker->SetMaterial(0, BaseMat);
            if (UMaterialInstanceDynamic* MarkerMID = Zone->VisualMarker->CreateAndSetMaterialInstanceDynamic(0))
            {
                MarkerMID->SetVectorParameterValue(TEXT("Color"), ZoneColor);
            }
        }
        Zone->VisualMarker->SetRelativeScale3D(FVector(3.f, 3.f, 0.08f));   // a 3x3 m ground pad
    }

    Zone->DefendDuration = Template->DefendDuration;
    Zone->DefendWaveInterval = Template->DefendWaveInterval;
    Zone->bFailIfOverrun = Template->bFailIfOverrun;
    Zone->OverrunRadius = Template->OverrunRadius;
    Zone->OverrunEnemyCount = Template->OverrunEnemyCount;
    Zone->OverrunGraceTime = Template->OverrunGraceTime;
    Zone->bCounterattackAfterComplete = Template->bCounterattackAfterComplete;
    Zone->CounterattackDelay = Template->CounterattackDelay;
    Zone->CounterattackDuration = Template->CounterattackDuration;

    Zone->TimeLimitSeconds = Template->TimeLimitSeconds;
    Zone->bFailOnTimeExpiry = Template->bFailOnTimeExpiry;
    Zone->TimeLimitWarnFraction = Template->TimeLimitWarnFraction;
    Zone->ParTimeSeconds = Template->ParTimeSeconds;

    Zone->TitleCardPlace = Template->TitleCardPlace;
    Zone->TitleCardDate = Template->TitleCardDate;
    Zone->TitleCardUnit = Template->TitleCardUnit;
    Zone->MissionBriefingTitle = Template->BriefingTitle;
    Zone->MissionBriefingText = Template->BriefingText;
    Zone->MissionBriefingDuration = Template->BriefingDuration;

    // ---- 3. the wave spawner -------------------------------------------------
    // Offset from the zone so the two actors do not sit on top of each other in the
    // outliner; the spawner's own SpawnRadius scatters the enemies.
    const FVector SpawnerLoc = Origin + Rotation.RotateVector(FVector(600.f, 0.f, 0.f));
    AEnemyWaveSpawner* Spawner = World->SpawnActor<AEnemyWaveSpawner>(
        AEnemyWaveSpawner::StaticClass(), SpawnerLoc, Rotation, SpawnParams);
    if (Spawner)
    {
        Spawner->EnemiesPerWave = FMath::Max(1, Template->EnemiesPerWave);
        Spawner->MaxWaves = FMath::Max(1, Template->TotalWaves);
        Spawner->DelayBetweenWaves = FMath::Max(0.1f, Template->WaveIntervalSeconds);
        Spawner->SpawnIntervalSeconds = FMath::Max(0.1f, Template->SpawnIntervalSeconds);
        Spawner->bLoopWaves = Template->bLoopWaves;
        Spawner->SpawnRadius = FMath::Max(0.f, Template->SpawnRadiusCm);
        Spawner->MaxAliveEnemies = FMath::Max(0, Template->MaxAliveEnemies);
        if (Template->EnemyClass) Spawner->EnemyClass = Template->EnemyClass;
        Spawner->CommanderWavePolicy = Template->bEliteCommander
            ? ECommanderWavePolicy::FinalWave : ECommanderWavePolicy::Never;
        Spawner->AssistantsPerCommander = FMath::Clamp(Template->AssistantsPerCommander, 0, 6);
        // Activated by the zone (ActivateLinkedSpawners), never on its own BeginPlay.
        Spawner->bAutoActivate = false;

        Zone->LinkedSpawners.Add(Spawner);
        Zone->FactorySpawnedActors.Add(Spawner);      // S19-OP: torn down with the zone (B2)

        // S26-VIS: the spawner reads as what it is - an enemy presence - a 1.5 m
        // red marker you can find from height, not a 30 cm gray marble.
        {
            TInlineComponentArray<UStaticMeshComponent*> SpawnerMeshes(Spawner);
            for (UStaticMeshComponent* MC : SpawnerMeshes)
            {
                if (!MC || !MC->GetStaticMesh()) continue;
                if (UMaterialInterface* BaseMat = LoadObject<UMaterialInterface>(nullptr,
                    TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial")))
                {
                    MC->SetMaterial(0, BaseMat);
                    if (UMaterialInstanceDynamic* SpawnerMID = MC->CreateAndSetMaterialInstanceDynamic(0))
                    {
                        SpawnerMID->SetVectorParameterValue(TEXT("Color"), FLinearColor(0.75f, 0.08f, 0.06f, 1.f));
                    }
                }
                MC->SetRelativeScale3D(FVector(1.5f));
            }
        }
        Log += FString::Printf(TEXT("   + wave spawner: %d wave(s) x %d every %.0f s%s\n"),
            Spawner->MaxWaves, Spawner->EnemiesPerWave, Spawner->DelayBetweenWaves,
            Template->bEliteCommander ? TEXT(", commander on the final wave") : TEXT(""));
    }
    else
    {
        Log += TEXT("   warning: the wave spawner could not be spawned - the zone has nothing to clear.\n");
    }

    // ---- 4. the prop ring ----------------------------------------------------
    const TArray<FVector> Ring = FMissionArchetypeModel::PropRingOffsets(
        6, Template->PropRingRadiusCm, Template->PropRingStartAngleDeg, Template->PropRingArcDeg);
    // (6 offsets: the widest single group any template can ask for is carved from this
    //  ring in order - intel, supplies, demolition, captives - so no two groups overlap.)

    int32 RingCursor = 0;
    FRandomStream PropStream(2626);   // S26-TEX4: ring props face roughly out, not exactly out
    // S26-DETAIL: 2 cm, not 40 - the crate body starts ~1.5 cm above its actor
    // origin, so 40 cm of lift left crates and marker discs FLOATING. Each prop's
    // root geometry decides its own lift below (barrel 47, truck 2, pad 2).
    float PropLift = 2.f;
    // S26-SITE: where each prop group started - the signature detail is built
    // AT its prop, not at the zone centre where it would float free.
    FVector FirstIntelLoc = FVector::ZeroVector, FirstSupplyLoc = FVector::ZeroVector,
        FirstDemoLoc = FVector::ZeroVector, FirstCaptiveLoc = FVector::ZeroVector;

    // -- intel sites -----------------------------------------------------------
    for (int32 i = 0; i < Template->IntelSiteCount; ++i)
    {
        const FVector Loc = SquadAIMissionFactory::RingPoint(World, Origin, Ring, RingCursor++ % FMath::Max(1, Ring.Num()), 2.f);
        if (i == 0) { FirstIntelLoc = Loc; }   // S26-SITE
        if (AIntelSiteActor* Site = World->SpawnActor<AIntelSiteActor>(
            AIntelSiteActor::StaticClass(), Loc, Rotation, SpawnParams))
        {
            Site->SiteName = Template->MissionDescription;
            Zone->IntelSites.Add(Site);
            Zone->FactorySpawnedActors.Add(Site);
            SquadAIMissionFactory::SquadAIApplyPropMaterial(Site, TEXT("CommsPanel"), FLinearColor(0.92f, 0.92f, 0.95f, 1.f));   // S26-MAT
            SquadAIMissionFactory::StampIdent(Site, TEXT("Intel Site"), TEXT("SquadAI/Missions/Props"));   // S26-FOLDER
            SquadAIMissionFactory::DecorateIntelSite(Site);   // S26-DETAIL
        }
    }
    if (Template->IntelSiteCount > 0)
    {
        Log += FString::Printf(TEXT("   + %d intel site(s)\n"), Zone->IntelSites.Num());
    }

    // -- supply crates ---------------------------------------------------------
    for (int32 i = 0; i < Template->SupplyCrateCount; ++i)
    {
        const FVector Loc = SquadAIMissionFactory::RingPoint(World, Origin, Ring, RingCursor++ % FMath::Max(1, Ring.Num()), PropLift);
        if (i == 0) { FirstSupplyLoc = Loc; }   // S26-SITE
        if (ASupplyCrateActor* Crate = World->SpawnActor<ASupplyCrateActor>(
            ASupplyCrateActor::StaticClass(), Loc,
            FRotator(0.f, Rotation.Yaw + PropStream.FRandRange(-16.f, 16.f), 0.f), SpawnParams))   // S26-TEX4
        {
            Zone->SupplyCrates.Add(Crate);
            Zone->FactorySpawnedActors.Add(Crate);
            SquadAIMissionFactory::SquadAIApplyPropMaterial(Crate, TEXT("SupplyCrate"), FLinearColor::White);   // S26-MAT
            SquadAIMissionFactory::StampIdent(Crate, TEXT("Supply Crate"), TEXT("SquadAI/Missions/Props"));   // S26-FOLDER
            SquadAIMissionFactory::DecorateSupplyCrate(Crate);   // S26-DETAIL
        }
    }
    if (Template->SupplyCrateCount > 0)
    {
        // The crates come home to the zone itself; a designer can repoint the delivery
        // point afterwards - and if he does, the crates are told at BeginPlay.
        Zone->SupplyDeliveryPoint = Zone;
        Log += FString::Printf(TEXT("   + %d supply crate(s), delivered to the zone\n"), Zone->SupplyCrates.Num());
    }

    // -- demolition targets ----------------------------------------------------
    for (int32 i = 0; i < Template->SabotageTargetCount; ++i)
    {
        const FVector Loc = SquadAIMissionFactory::RingPoint(World, Origin, Ring, RingCursor++ % FMath::Max(1, Ring.Num()), PropLift);
        if (i == 0) { FirstDemoLoc = Loc; }   // S26-SITE
        if (ASabotageTargetActor* Target = World->SpawnActor<ASabotageTargetActor>(
            ASabotageTargetActor::StaticClass(), Loc,
            FRotator(0.f, Rotation.Yaw + PropStream.FRandRange(-14.f, 14.f), 0.f), SpawnParams))   // S26-TEX4
        {
            Zone->SabotageTargets.Add(Target);
            Zone->FactorySpawnedActors.Add(Target);
            SquadAIMissionFactory::SquadAIApplyPropMaterial(Target, TEXT("AmmoBox"), FLinearColor::White);   // S26-MAT2: demolition target = munitions
            SquadAIMissionFactory::StampIdent(Target, TEXT("Demolition Target"), TEXT("SquadAI/Missions/Props"));   // S26-FOLDER
            SquadAIMissionFactory::DecorateSabotageTarget(Target);   // S26-DETAIL
        }
    }
    if (Template->SabotageTargetCount > 0)
    {
        Log += FString::Printf(TEXT("   + %d demolition target(s)\n"), Zone->SabotageTargets.Num());
    }

    // -- POW captives ----------------------------------------------------------
    if (Template->POWCaptiveCount > 0 && Template->POWClass)
    {
        for (int32 i = 0; i < Template->POWCaptiveCount; ++i)
        {
            const FVector Loc = SquadAIMissionFactory::RingPoint(World, Origin, Ring, RingCursor++ % FMath::Max(1, Ring.Num()), 100.f);
            if (i == 0) { FirstCaptiveLoc = Loc; }   // S26-SITE
            if (ASoldierCharacter* Captive = World->SpawnActor<ASoldierCharacter>(
                Template->POWClass, Loc, Rotation, SpawnParams))
            {
                SquadAIMissionFactory::StampIdent(Captive, TEXT("POW Captive"), TEXT("SquadAI/Missions/Props"));   // S26-FOLDER
                Zone->POWCaptives.Add(Captive);
                Zone->FactorySpawnedActors.Add(Captive);
            }
        }
        Zone->bPOWsFollowPlayer = Template->bPOWsFollowPlayer;
        Log += FString::Printf(TEXT("   + %d POW captive(s)\n"), Zone->POWCaptives.Num());
    }

    // -- the convoy and its route ----------------------------------------------
    if (Template->bEscort)
    {
        // The route starts a ring-radius away from the zone, walks out along the
        // template's yaw, and the convoy is placed on its first point. The zone is the
        // destination: the last leg ends at the zone centre, which is what "arrived"
        // should mean for a convoy delivering to an objective.
        const TArray<FVector> RouteOffsets = FMissionArchetypeModel::EscortRouteOffsets(
            Template->EscortRouteLegs, Template->EscortRouteLegLengthCm, Template->EscortRouteStartYawDeg);

        // The route is laid out BACKWARDS from the objective: the last point IS the zone
        // centre, so "the convoy arrived" means it reached the mission and not a spot
        // near it. The heading (Escort Route Start Yaw) sets which way it approaches from.
        const FVector RouteStart = Origin - RouteOffsets.Last();
        AEnemyPatrolRoute* Route = World->SpawnActor<AEnemyPatrolRoute>(
            AEnemyPatrolRoute::StaticClass(), RouteStart, Rotation, SpawnParams);
        if (Route)
        {
            Route->RouteName = FString::Printf(TEXT("Convoy route - %s"), *Template->GetName());
            Zone->FactorySpawnedActors.Add(Route);         // S19-OP (B2): the route dies with the mission
            Route->bClosedLoop = false;      // an escort route ENDS; it does not lap
            Route->DefaultPointWaitSeconds = 0.f;
#if WITH_EDITOR
            Route->SetActorLabel(Route->RouteName);
#endif

            // Every point is grounded on its own, except the last, which stays exactly on
            // the zone: the arrival test compares against THIS actor's location, and a
            // 1 m grounding error there would be a 1 m error in the gate.
            for (int32 PointIndex = 0; PointIndex < RouteOffsets.Num(); ++PointIndex)
            {
                const FVector Raw = RouteStart + RouteOffsets[PointIndex];
                const FVector PointWorld = (PointIndex == RouteOffsets.Num() - 1)
                    ? Origin : SquadAIMissionFactory::GroundPoint(World, Raw, 50.f);
                Route->AddPointAt(PointWorld);
            }

            // S26-DETAIL: face the first real leg of the route. The truck body's
            // long axis is local +Y, so the actor yaw is heading - 90; before this
            // fix every convoy stood broadside to its own route.
            float ConvoyYawDeg = Rotation.Yaw;
            for (int32 LegI = 1; LegI < Route->GetPointCount(); ++LegI)
            {
                const FVector LegA = Route->GetPointLocation(LegI - 1);
                const FVector LegB = Route->GetPointLocation(LegI);
                const FVector LegDir = LegB - LegA;
                if (LegDir.SizeSquared() > 10000.f)
                {
                    ConvoyYawDeg = FMath::RadiansToDegrees(FMath::Atan2(LegDir.Y, LegDir.X)) - 90.f;
                    break;
                }
            }
            const FVector ConvoyLoc = SquadAIMissionFactory::GroundPoint(World, RouteStart, 2.f);
            if (AEscortTargetActor* Convoy = World->SpawnActor<AEscortTargetActor>(
                AEscortTargetActor::StaticClass(), ConvoyLoc, FRotator(0.f, ConvoyYawDeg, 0.f), SpawnParams))
            {
                Convoy->EscortName = Template->MissionName;
                Convoy->Route = Route;
                Zone->EscortTarget = Convoy;
                Zone->FactorySpawnedActors.Add(Convoy);
                SquadAIMissionFactory::SquadAIApplyPropMaterial(Convoy, TEXT("CamoTarp"), FLinearColor(0.9f, 0.95f, 0.85f, 1.f));   // S26-MAT
            SquadAIMissionFactory::DecorateConvoy(Convoy);   // S26-DETAIL
                Zone->bRequireEscortArrival = Template->bRequireEscortArrival;
                Zone->bFailIfEscortDies = Template->bFailIfEscortDies;
                Log += FString::Printf(TEXT("   + convoy: %d route point(s), %.0f m out, %s the arrival gate\n"),
                    Route->GetPointCount(), Template->EscortRouteLegLengthCm * Template->EscortRouteLegs / 100.f,
                    Template->bRequireEscortArrival ? TEXT("holding") : TEXT("not holding"));
            }
        }
    }

    // -- the extraction pad -----------------------------------------------------
    if (Template->bExtraction)
    {
        const FVector PadLoc = SquadAIMissionFactory::GroundPoint(
            World, Origin + FRotator(0.f, Template->PropRingStartAngleDeg, 0.f).Vector() * Template->ExtractionOffsetCm, 2.f);
        if (AExtractionZoneActor* Pad = World->SpawnActor<AExtractionZoneActor>(
            AExtractionZoneActor::StaticClass(), PadLoc, Rotation, SpawnParams))
        {
            Pad->CallSign = Template->MissionName;
            Pad->HoldSeconds = FMath::Max(1.f, Template->ExtractionHoldSeconds);
            Zone->ExtractionZone = Pad;
            Zone->FactorySpawnedActors.Add(Pad);
            SquadAIMissionFactory::SquadAIApplyPropMaterial(Pad, TEXT("HazardPad"), FLinearColor::White);   // S26-MAT
            SquadAIMissionFactory::StampIdent(Pad, FString::Printf(TEXT("Extraction Pad '%s'"), *Pad->CallSign.ToString()), TEXT("SquadAI/Missions/Props"));   // S26-FOLDER (CallSign is FText)
            SquadAIMissionFactory::DecorateExtractionPad(Pad);   // S26-DETAIL
            Zone->bRequireExtraction = Template->bRequireExtraction;
            Log += FString::Printf(TEXT("   + extraction pad %.0f m from the zone, hold %.0f s\n"),
                Template->ExtractionOffsetCm / 100.f, Pad->HoldSeconds);
        }
    }

    // -- capture points (S19-CAP) -----------------------------------------------
    for (int32 i = 0; i < Template->CapturePointCount; ++i)
    {
        const FVector Loc = SquadAIMissionFactory::RingPoint(World, Origin, Ring, RingCursor++ % FMath::Max(1, Ring.Num()), PropLift);
        if (ACapturePointActor* Point = World->SpawnActor<ACapturePointActor>(
            ACapturePointActor::StaticClass(), Loc, Rotation, SpawnParams))
        {
            Point->PostCaptureHoldSeconds = FMath::Max(0.f, Template->CaptureHoldSeconds);
            Zone->CapturePoints.Add(Point);
            Zone->FactorySpawnedActors.Add(Point);
            SquadAIMissionFactory::SquadAIApplyPropMaterial(Point, TEXT("Concrete"), FLinearColor::White);   // S26-MAT
            SquadAIMissionFactory::StampIdent(Point, TEXT("Capture Point"), TEXT("SquadAI/Missions/Props"));   // S26-FOLDER
            SquadAIMissionFactory::DecorateCapturePoint(Point);   // S26-DETAIL
        }
    }
    if (Template->CapturePointCount > 0)
    {
        Log += FString::Printf(TEXT("   + %d capture point(s), hold %.0f s each\n"),
            Zone->CapturePoints.Num(), Template->CaptureHoldSeconds);
    }

    // -- the defended asset (S19-ASSET) -------------------------------------------
    if (Template->bDefendedAsset)
    {
        const FVector Loc = SquadAIMissionFactory::RingPoint(World, Origin, Ring, RingCursor++ % FMath::Max(1, Ring.Num()), PropLift);
        if (ADefendedAssetActor* Asset = World->SpawnActor<ADefendedAssetActor>(
            ADefendedAssetActor::StaticClass(), Loc, Rotation, SpawnParams))
        {
            Zone->DefendedAsset = Asset;
            Zone->FactorySpawnedActors.Add(Asset);
            SquadAIMissionFactory::SquadAIApplyPropMaterial(Asset, TEXT("OliveArmor"), FLinearColor::White);   // S26-MAT
            SquadAIMissionFactory::DecorateDefendedAsset(Asset);   // S26-DETAIL
            Zone->bFailIfAssetDestroyed = true;
            Log += TEXT("   + the defended asset (protect it - sappers will come for it)\n");
        }
    }

    // -- the interdiction run (S19-INTERDICT) ---------------------------------------
    if (Template->bInterdiction)
    {
        // The route crosses the WHOLE area: eight grounded points from 45 m east of the
        // zone to 45 m west, straight through it - the couriers drive THROUGH the fight.
        const FVector RouteStart = Origin + FVector(4500.f, 0.f, 0.f);
        if (AEnemyPatrolRoute* Route = World->SpawnActor<AEnemyPatrolRoute>(
            AEnemyPatrolRoute::StaticClass(), RouteStart, Rotation, SpawnParams))
        {
            Zone->FactorySpawnedActors.Add(Route);         // S19-OP (B2)
            Route->RouteName = FString::Printf(TEXT("Courier route - %s"), *Template->GetName());
            Route->bClosedLoop = false;
            Route->DefaultPointWaitSeconds = 0.f;
#if WITH_EDITOR
            Route->SetActorLabel(Route->RouteName);
#endif
            for (int32 i = 0; i < 8; ++i)
            {
                const FVector Raw = Origin + FVector(4500.f - (9000.f * i) / 7.f, 0.f, 0.f);
                Route->AddPointAt(SquadAIMissionFactory::GroundPoint(World, Raw, 50.f));
            }

            const FVector DirectorLoc = SquadAIMissionFactory::GroundPoint(World, Origin + FVector(600.f, 600.f, 0.f), 50.f);
            if (AInterdictionDirectorActor* Director = World->SpawnActor<AInterdictionDirectorActor>(
                AInterdictionDirectorActor::StaticClass(), DirectorLoc, Rotation, SpawnParams))
            {
                Director->CourierRoute = Route;
                Director->CourierCount = FMath::Clamp(Template->InterdictionCourierCount, 1, 12);
                // The validator already refuses quota > count; clamp anyway so a hand-tweaked
                // asset can never build an unachievable run.
                Director->StopQuota = FMath::Min(Template->InterdictionStopQuota, Director->CourierCount);
                Zone->InterdictionDirector = Director;
                Zone->FactorySpawnedActors.Add(Director);
                Log += FString::Printf(TEXT("   + interdiction: %d courier(s), stop %d, the route crosses the zone\n"),
                    Director->CourierCount, Director->StopQuota);
            }
        }
    }

    // ---- 5. scenery ----------------------------------------------------------
    if (Template->bSpawnFortification)
    {
        if (AQuickFortificationSpawnerActor* Fort = World->SpawnActor<AQuickFortificationSpawnerActor>(
            AQuickFortificationSpawnerActor::StaticClass(), Origin, Rotation, SpawnParams))
        {
            Fort->FortificationPreset = Template->FortificationPreset;
            Zone->FactorySpawnedActors.Add(Fort);
            Log += TEXT("   + fortification\n");
        }
    }
    const TArray<FVector> BarrelRing = FMissionArchetypeModel::PropRingOffsets(
        Template->ExplosiveBarrels, 450.f, 150.f, 360.f);
    for (const FVector& Offset : BarrelRing)
    {
        if (AActor* Barrel = World->SpawnActor<AExplosiveBarrelActor>(AExplosiveBarrelActor::StaticClass(),
            Origin + Offset + FVector(0.f, 0.f, 47.f),
            FRotator(0.f, PropStream.FRandRange(-24.f, 24.f), 0.f), SpawnParams))   // S26-TEX4: barrels never stand in formation (drum bottom 2 cm above ground)
        {
            Zone->FactorySpawnedActors.Add(Barrel);
            SquadAIMissionFactory::SquadAIApplyPropMaterial(Barrel, TEXT("RustyBarrel"), FLinearColor::White);   // S26-MAT2: a barrel is a barrel
            SquadAIMissionFactory::StampIdent(Barrel, TEXT("Explosive Barrel"), TEXT("SquadAI/Missions/Props"));   // S26-FOLDER
            SquadAIMissionFactory::DecorateBarrel(Barrel);   // S26-DETAIL
        }
    }
    if (BarrelRing.Num() > 0)
    {
        Log += FString::Printf(TEXT("   + %d explosive barrel(s)\n"), BarrelRing.Num());
    }

    // -- S26-LIFE: old shellfire on combat missions - craters ring the zone ----
    if (Template->MissionType != EMissionType::Reach)
    {
        USquadAIAssetCacheSubsystem* Cache = USquadAIAssetCacheSubsystem::Get(World);
        // S26-WEAR5: a Defend zone is under siege - the shellfire reads
        // thicker. Each crater also drifts a little off its ring slot so
        // five never stack onto three positions.
        const int32 CraterCount = (Template->MissionType == EMissionType::Defend) ? 5 : 3;
        for (int32 Ci = 0; Ci < CraterCount && Cache; ++Ci)
        {
            const FVector Loc = SquadAIMissionFactory::RingPoint(World, Origin, Ring,
                (Ci * 2 + 1) % FMath::Max(1, Ring.Num()), 3.f)
                + FVector(Ci * 74.f - 111.f, Ci * 58.f - 87.f, 0.f);
            SquadAIMissionFactory::DecorateCrater(World, Zone, Cache, Loc);
        }
        Log += FString::Printf(TEXT("   + %d shell crater(s)\n"), CraterCount);
    }

    // -- S26-TEX3: ground detail - rocks kicked up around every zone. The land
    //    between the props is a battlefield too; half-buried boulders give the
    //    eye somewhere to rest and break the perfectly clean ground.
    {
        USquadAIAssetCacheSubsystem* Cache = USquadAIAssetCacheSubsystem::Get(World);
        if (Cache && Cache->GetSphereMesh() && Ring.Num() > 0)
        {
            // S26-PATINA: three stone tints - a field of identical boulders
            // reads as clones; three greys read as geology. 3 MIDs, map-wide.
            UMaterialInterface* RockMats[3] = {
                Cache->GetPropMaterial(TEXT("Concrete"), FLinearColor(0.60f, 0.58f, 0.54f, 1.f)),
                Cache->GetPropMaterial(TEXT("Concrete"), FLinearColor(0.50f, 0.48f, 0.44f, 1.f)),
                Cache->GetPropMaterial(TEXT("Concrete"), FLinearColor(0.68f, 0.65f, 0.60f, 1.f)),
            };
            // S26-SPHERE2: boulders are HISM instances now, and each rock is a
            // COMPOSITE - a main squashed sphere plus a rolled flanker leaning
            // against it. A lone squashed sphere reads as a "weird ball with no
            // identity" (the exact report from the HQ); two overlapping masses
            // with different tilts read as geology. Three HISM components (one
            // per stone tint), zero extra actors - was 9 scenery actors a zone.
            UHierarchicalInstancedStaticMeshComponent* RockHISMs[3] = { nullptr, nullptr, nullptr };
            FRandomStream RockStream(2627);
            for (int32 Ri = 0; Ri < 9; ++Ri)
            {
                const int32 Tint = Ri % 3;
                if (!RockHISMs[Tint])
                {
                    RockHISMs[Tint] = SquadAIMissionFactory::ZoneSceneryHISM(Zone,
                        *FString::Printf(TEXT("HISM_Rocks%d"), Tint), Cache->GetSphereMesh(),
                        RockMats[Tint] ? RockMats[Tint] : RockMats[0]);
                }
                if (!RockHISMs[Tint]) continue;
                const FVector Base = SquadAIMissionFactory::RingPoint(World, Origin, Ring,
                    (Ri * 3 + 2) % Ring.Num(), 5.f);
                const FVector Loc = Base + FVector(
                    RockStream.FRandRange(-240.f, 240.f), RockStream.FRandRange(-240.f, 240.f), 0.f);
                const float Wide = RockStream.FRandRange(30.f, 95.f);
                const float Yaw = RockStream.FRandRange(0.f, 360.f);
                // the main mass, tilted so it is never a perfect dome
                RockHISMs[Tint]->AddInstance(FTransform(
                    FRotator(RockStream.FRandRange(-10.f, 10.f), Yaw, RockStream.FRandRange(-12.f, 12.f)),
                    Loc,
                    FVector(Wide / 100.f, (Wide * RockStream.FRandRange(0.7f, 1.0f)) / 100.f,
                        (Wide * RockStream.FRandRange(0.35f, 0.55f)) / 100.f)), true);
                // the flanker: a split-off chunk leaning against the main mass
                const float FWide = Wide * RockStream.FRandRange(0.35f, 0.55f);
                RockHISMs[Tint]->AddInstance(FTransform(
                    FRotator(RockStream.FRandRange(8.f, 22.f), Yaw + RockStream.FRandRange(-70.f, 70.f),
                        RockStream.FRandRange(18.f, 38.f)),
                    Loc + FRotator(0.f, RockStream.FRandRange(0.f, 360.f), 0.f).Vector() * (Wide * 0.4f),
                    FVector(FWide / 100.f, (FWide * 0.85f) / 100.f, (FWide * 0.6f) / 100.f)), true);
            }
        }
    }

    // -- S26-SITE: a signature piece of ground for each kind of mission. The
    //    counts already say what this site IS - intel means a field HQ,
    //    demolition means a working yard, captives mean a holding pen, a lone
    //    supply drop means a pallet under its parachute, a Reach means a
    //    waystation. Built at the prop it belongs with, so two zones of the
    //    same archetype never read identical.
    {
        USquadAIAssetCacheSubsystem* Cache = USquadAIAssetCacheSubsystem::Get(World);
        if (Cache && Cache->GetCubeMesh() && Cache->GetCylinderMesh() && Cache->GetSphereMesh())
        {
            FRandomStream SiteStream(2628);
            int32 SiteSerial = 0;   // S26-FOLDER: every site piece gets a name
            const TCHAR* SiteWhat = TEXT("detail");
            const float ZoneYaw = Rotation.Yaw;
            UMaterialInterface* WoodMat = Cache->GetPropMaterial(TEXT("WoodPlanks"), FLinearColor(0.8f, 0.75f, 0.62f, 1.f), 1.5f);   // S26-PATINA: tables and posts tile at their real size
            UMaterialInterface* TarpMat = Cache->GetPropMaterial(TEXT("CamoTarp"), FLinearColor(0.7f, 0.75f, 0.6f, 1.f), 2.4f);
            UMaterialInterface* SteelMat = Cache->GetPropMaterial(TEXT("MetalPlate"), FLinearColor(0.65f, 0.67f, 0.63f, 1.f));
            auto YawOffset = [&](float Fwd, float Rt)
            {
                return FVector(Fwd, Rt, 0.f).RotateAngleAxis(ZoneYaw, FVector::UpVector);
            };
            auto PieceAt = [&](const FVector& Base, const FVector& Rel, float LiftCm, const FRotator& RelRot,
                UStaticMesh* Mesh, const FVector& Scale, UMaterialInterface* Mat)
            {
                return SquadAIMissionFactory::SceneryPiece(World, Zone,
                    SquadAIMissionFactory::GroundPoint(World, Base + Rel, LiftCm), RelRot, Mesh, Scale, Mat,
                    *FString::Printf(TEXT("Site: %s %d"), SiteWhat, ++SiteSerial), TEXT("SquadAI/Mission Scenery"));
            };

            SiteWhat = TEXT("field HQ");   // S26-FOLDER
            // field HQ - a map table with a marked map and two stools by the intel tent
            if (FirstIntelLoc != FVector::ZeroVector)
            {
                const FVector T = FirstIntelLoc + YawOffset(165.f, 30.f);
                PieceAt(T, FVector::ZeroVector, 74.f, FRotator(0.f, ZoneYaw + 8.f, 0.f), Cache->GetCubeMesh(),
                    FVector(1.5f, 0.8f, 0.08f), WoodMat);
                for (float LX = -1.f; LX <= 1.f; LX += 2.f)
                {
                    for (float LY = -1.f; LY <= 1.f; LY += 2.f)
                    {
                        PieceAt(T, YawOffset(LX * 60.f, LY * 28.f), 35.f, FRotator::ZeroRotator,
                            Cache->GetCylinderMesh(), FVector(0.08f, 0.08f, 0.7f), SteelMat);
                    }
                }
                PieceAt(T, YawOffset(10.f, -10.f), 80.f, FRotator(0.f, ZoneYaw - 15.f, 0.f),
                    Cache->GetCubeMesh(), FVector(0.5f, 0.7f, 0.02f),
                    Cache->GetPropMaterial(TEXT("CommsPanel"), FLinearColor(0.92f, 0.92f, 0.95f, 1.f)));
                for (int32 St = 0; St < 2; ++St)
                {
                    PieceAt(FirstIntelLoc, YawOffset(230.f, St == 0 ? -60.f : 90.f), 20.f,
                        FRotator(0.f, ZoneYaw + SiteStream.FRandRange(-25.f, 25.f), 0.f),
                        Cache->GetCylinderMesh(), FVector(0.32f, 0.32f, 0.4f), WoodMat);
                }
                Log += TEXT("   + site detail: field HQ (map table + stools)\n");
            }

            SiteWhat = TEXT("demolition yard");   // S26-FOLDER
            // demolition yard - a lean-to over the charges, a crate stack, a wire spool
            if (FirstDemoLoc != FVector::ZeroVector)
            {
                for (float PY = -1.f; PY <= 1.f; PY += 2.f)
                {
                    PieceAt(FirstDemoLoc, YawOffset(150.f, PY * 95.f), 100.f, FRotator::ZeroRotator,
                        Cache->GetCylinderMesh(), FVector(0.12f, 0.12f, 2.0f), WoodMat);
                }
                PieceAt(FirstDemoLoc, YawOffset(215.f, 0.f), 150.f, FRotator(-24.f, ZoneYaw, 0.f),
                    Cache->GetCubeMesh(), FVector(2.4f, 0.06f, 1.1f), TarpMat);
                for (int32 Bx = 0; Bx < 3; ++Bx)
                {
                    PieceAt(FirstDemoLoc, YawOffset(30.f, 165.f), 18.f + Bx * 36.f,
                        FRotator(0.f, ZoneYaw + (Bx - 1) * 14.f, 0.f), Cache->GetCubeMesh(),
                        FVector(0.6f, 0.42f, 0.36f), WoodMat);
                }
                PieceAt(FirstDemoLoc, YawOffset(95.f, -150.f), 26.f, FRotator(90.f, ZoneYaw, 0.f),
                    Cache->GetCylinderMesh(), FVector(0.5f, 0.5f, 0.32f), SteelMat);
                Log += TEXT("   + site detail: demolition yard (lean-to + crates + spool)\n");
            }

            SiteWhat = TEXT("holding pen");   // S26-FOLDER
            // holding pen - posts and rail wires around the captives
            if (FirstCaptiveLoc != FVector::ZeroVector)
            {
                for (int32 Pa = -2; Pa <= 2; ++Pa)
                {
                    const float Ang = ZoneYaw + Pa * 24.f - 90.f;
                    PieceAt(FirstCaptiveLoc, FRotator(0.f, Ang, 0.f).Vector() * 240.f, 75.f,
                        FRotator(0.f, SiteStream.FRandRange(-4.f, 4.f), 0.f),
                        Cache->GetCylinderMesh(), FVector(0.1f, 0.1f, 1.5f), WoodMat);
                }
                for (float RZ = 55.f; RZ <= 125.f; RZ += 70.f)
                {
                    PieceAt(FirstCaptiveLoc, YawOffset(-2.f, 0.f), RZ,
                        FRotator(0.f, ZoneYaw, 0.f), Cache->GetCubeMesh(), FVector(4.3f, 0.04f, 0.04f), SteelMat);
                }
                PieceAt(FirstCaptiveLoc, YawOffset(70.f, -60.f), 12.f, FRotator::ZeroRotator,
                    Cache->GetCylinderMesh(), FVector(0.24f, 0.24f, 0.25f), SteelMat);
                Log += TEXT("   + site detail: holding pen (posts + rail wires)\n");
            }

            SiteWhat = TEXT("supply drop");   // S26-FOLDER
            // a lone supply drop - the pallet it came on, the parachute beside it
            if (FirstSupplyLoc != FVector::ZeroVector && Template->IntelSiteCount == 0
                && Template->SabotageTargetCount == 0 && Template->POWCaptiveCount == 0)
            {
                PieceAt(FirstSupplyLoc, FVector::ZeroVector, 7.f, FRotator(0.f, ZoneYaw, 0.f),
                    Cache->GetCubeMesh(), FVector(1.5f, 1.5f, 0.14f), WoodMat);
                PieceAt(FirstSupplyLoc, YawOffset(85.f, 60.f), 18.f,
                    FRotator(32.f, ZoneYaw + 30.f, 8.f), Cache->GetSphereMesh(),
                    FVector(1.7f, 1.7f, 0.4f), TarpMat);
                for (float SY = -1.f; SY <= 1.f; SY += 2.f)
                {
                    PieceAt(FirstSupplyLoc, YawOffset(0.f, SY * 45.f), 16.f,
                        FRotator(0.f, ZoneYaw + 90.f, 0.f), Cache->GetCubeMesh(), FVector(1.6f, 0.1f, 0.04f), SteelMat);
                }
                Log += TEXT("   + site detail: supply drop (pallet + parachute)\n");
            }

            SiteWhat = TEXT("waystation");   // S26-FOLDER
            // waystation - a signpost, a bench, a water can: somewhere to wait
            if (Template->MissionType == EMissionType::Reach)
            {
                const FVector W = SquadAIMissionFactory::RingPoint(World, Origin, Ring, 0, 2.f);
                PieceAt(W, FVector::ZeroVector, 95.f, FRotator(0.f, SiteStream.FRandRange(-3.f, 3.f), 0.f),
                    Cache->GetCylinderMesh(), FVector(0.12f, 0.12f, 1.9f), WoodMat);
                PieceAt(W, YawOffset(8.f, -16.f), 152.f, FRotator(0.f, ZoneYaw + 38.f, 0.f),
                    Cache->GetCubeMesh(), FVector(0.9f, 0.26f, 0.05f), WoodMat);
                PieceAt(W, YawOffset(8.f, 18.f), 178.f, FRotator(0.f, ZoneYaw - 152.f, 0.f),
                    Cache->GetCubeMesh(), FVector(0.9f, 0.26f, 0.05f), WoodMat);
                PieceAt(W, YawOffset(-95.f, 60.f), 42.f, FRotator(0.f, ZoneYaw - 12.f, 0.f),
                    Cache->GetCubeMesh(), FVector(1.3f, 0.36f, 0.08f), WoodMat);
                for (float BL = -1.f; BL <= 1.f; BL += 2.f)
                {
                    PieceAt(W, YawOffset(-95.f + BL * 50.f, 60.f), 20.f, FRotator::ZeroRotator,
                        Cache->GetCylinderMesh(), FVector(0.08f, 0.08f, 0.4f), SteelMat);
                }
                PieceAt(W, YawOffset(-40.f, -70.f), 18.f, FRotator::ZeroRotator,
                    Cache->GetCylinderMesh(), FVector(0.32f, 0.32f, 0.36f),
                    Cache->GetPropMaterial(TEXT("RustyBarrel"), FLinearColor::White));
                Log += TEXT("   + site detail: waystation (signpost + bench + water)\n");
            }
        }
    }

    // -- S26-AMBIENCE: the ground tells the same story as the props. Dead
    //    trees and dry scrub on fought-over land, a knocked sandbag pile where
    //    a fight brushed the ring, a banner over ground they intend to KEEP,
    //    and the worn dirt path every patrol beat into the approach.
    {
        USquadAIAssetCacheSubsystem* Cache = USquadAIAssetCacheSubsystem::Get(World);
        if (Cache && Cache->GetCubeMesh() && Cache->GetCylinderMesh() && Cache->GetSphereMesh()
            && Ring.Num() > 0 && Template->MissionType != EMissionType::Reach)
        {
            FRandomStream AmbStream(2629);
            const float ZoneYaw = Rotation.Yaw;
            UMaterialInterface* BarkMat = Cache->GetPropMaterial(TEXT("WoodPlanks"), FLinearColor(0.30f, 0.26f, 0.22f, 1.f));
            UMaterialInterface* ScrubMat = Cache->GetPropMaterial(TEXT("CamoTarp"), FLinearColor(0.32f, 0.36f, 0.24f, 1.f));
            UMaterialInterface* BagMat = Cache->GetPropMaterial(TEXT("Sandbags"), FLinearColor(0.75f, 0.70f, 0.55f, 1.f));
            UMaterialInterface* BannerMat = Cache->GetPropMaterial(TEXT("CamoTarp"), FLinearColor(0.52f, 0.14f, 0.11f, 1.f));
            UMaterialInterface* DirtMat = Cache->GetPropMaterial(TEXT("Concrete"), FLinearColor(0.45f, 0.39f, 0.31f, 1.f));
            int32 AmbCount = 0;

            // dead trees: a trunk leaning with the weather, two bare branches
            const int32 TreeCount = AmbStream.RandRange(2, 3);
            for (int32 Ti = 0; Ti < TreeCount; ++Ti)
            {
                const FVector Base = SquadAIMissionFactory::RingPoint(World, Origin, Ring,
                    (Ti * 2 + 4) % Ring.Num(), 5.f)
                    + FVector(AmbStream.FRandRange(-260.f, 260.f), AmbStream.FRandRange(-260.f, 260.f), 0.f);
                const FVector Loc = SquadAIMissionFactory::GroundPoint(World, Base, 0.f);
                const float TrunkH = AmbStream.FRandRange(320.f, 430.f);
                const float TrunkR = AmbStream.FRandRange(14.f, 19.f);
                const float TreeYaw = AmbStream.FRandRange(0.f, 360.f);
                // S26-WEAR5: some trees the shellfire simply TOOK - a snapped
                // stump, splinters at the break, the crown pitched over on
                // the ground, a limb flung clear. Rolled per tree: a zone
                // with none is luckier, not safer.
                const bool bSnapped = AmbStream.FRand() > 0.55f;
                if (bSnapped)
                {
                    SquadAIMissionFactory::SceneryPiece(World, Zone,
                        Loc + FVector(0.f, 0.f, TrunkH * 0.28f),
                        FRotator(AmbStream.FRandRange(-2.f, 2.f), TreeYaw, AmbStream.FRandRange(-2.f, 2.f)),
                        Cache->GetCylinderMesh(), FVector(TrunkR / 50.f, TrunkR / 50.f, (TrunkH * 0.56f) / 100.f),
                        BarkMat, TEXT("Snapped Tree Stump"));
                    const float FallYaw = TreeYaw + AmbStream.FRandRange(-40.f, 40.f);
                    const float CrownL = TrunkH * AmbStream.FRandRange(0.55f, 0.75f);
                    SquadAIMissionFactory::SceneryPiece(World, Zone,
                        Loc + FRotator(0.f, FallYaw, 0.f).Vector() * (CrownL * 0.34f)
                            + FVector(0.f, 0.f, TrunkH * 0.56f - CrownL * 0.16f),
                        FRotator(68.f, FallYaw, 0.f),
                        Cache->GetCylinderMesh(), FVector((TrunkR * 0.8f) / 50.f, (TrunkR * 0.8f) / 50.f, CrownL / 100.f),
                        BarkMat, TEXT("Snapped Tree Crown"));
                    // splinters still standing at the break
                    SquadAIMissionFactory::SceneryPiece(World, Zone,
                        Loc + FVector(0.f, 0.f, TrunkH * 0.56f + 12.f),
                        FRotator(5.f, FallYaw, 7.f),
                        Cache->GetCylinderMesh(), FVector(0.05f, 0.05f, 0.35f),
                        BarkMat, FString());
                    SquadAIMissionFactory::SceneryPiece(World, Zone,
                        Loc + FVector(0.f, 0.f, TrunkH * 0.56f + 8.f) + FRotator(0.f, FallYaw + 100.f, 0.f).Vector() * 16.f,
                        FRotator(-4.f, FallYaw, -9.f),
                        Cache->GetCylinderMesh(), FVector(0.04f, 0.04f, 0.28f),
                        BarkMat, FString());
                    // a limb flung clear of the blast, lying flat
                    SquadAIMissionFactory::SceneryPiece(World, Zone,
                        SquadAIMissionFactory::GroundPoint(World,
                            Loc + FRotator(0.f, FallYaw + 90.f, 0.f).Vector() * AmbStream.FRandRange(150.f, 230.f), 8.f),
                        FRotator(90.f, AmbStream.FRandRange(0.f, 360.f), 0.f),
                        Cache->GetCylinderMesh(), FVector(0.10f, 0.10f, AmbStream.FRandRange(1.4f, 2.0f)),
                        BarkMat, TEXT("Flung Limb"));
                    AmbCount += 5;
                }
                else
                {
                    SquadAIMissionFactory::SceneryPiece(World, Zone,
                        Loc + FVector(0.f, 0.f, TrunkH * 0.5f),
                        FRotator(AmbStream.FRandRange(-4.f, 4.f), TreeYaw, AmbStream.FRandRange(-3.f, 3.f)),
                        Cache->GetCylinderMesh(), FVector(TrunkR / 50.f, TrunkR / 50.f, TrunkH / 100.f),
                        BarkMat, TEXT("Dead Tree"));
                    for (int32 Bi = 0; Bi < 2; ++Bi)
                    {
                        const float BL = AmbStream.FRandRange(150.f, 220.f);
                        const float BYaw = TreeYaw + (Bi == 0 ? 40.f : 215.f) + AmbStream.FRandRange(-15.f, 15.f);
                        SquadAIMissionFactory::SceneryPiece(World, Zone,
                            Loc + FVector(0.f, 0.f, TrunkH * 0.82f)
                                + FRotator(0.f, BYaw, 0.f).Vector() * (BL * 0.3f),
                            FRotator(38.f + AmbStream.FRandRange(-8.f, 8.f), BYaw, 0.f),
                            Cache->GetCylinderMesh(), FVector(0.12f, 0.12f, BL / 100.f),
                            BarkMat, TEXT("Dead Tree Branch"));
                        ++AmbCount;
                    }
                    ++AmbCount;
                }
            }

            // dry scrub: low mats of dead brush - S26-SPHERE2: a CLUMP of
            // three small masses now, not one ball; a lone squashed sphere
            // reads as nothing in particular, three overlapping ones read as
            // a dead bush. HISM instances, zero scenery actors.
            UHierarchicalInstancedStaticMeshComponent* ScrubHISM = nullptr;
            for (int32 Si = 0; Si < 2; ++Si)
            {
                const FVector Base = SquadAIMissionFactory::RingPoint(World, Origin, Ring,
                    (Si * 3 + 2) % Ring.Num(), 5.f)
                    + FVector(AmbStream.FRandRange(-300.f, 300.f), AmbStream.FRandRange(-300.f, 300.f), 0.f);
                const float Wide = AmbStream.FRandRange(45.f, 80.f);
                const FVector Loc = SquadAIMissionFactory::GroundPoint(World, Base, Wide * 0.10f);
                if (!ScrubHISM)
                {
                    ScrubHISM = SquadAIMissionFactory::ZoneSceneryHISM(Zone, TEXT("HISM_Scrub"),
                        Cache->GetSphereMesh(), ScrubMat);
                }
                if (ScrubHISM)
                {
                    for (int32 Clump = 0; Clump < 3; ++Clump)
                    {
                        const float CW = Wide * AmbStream.FRandRange(0.35f, 0.6f);
                        ScrubHISM->AddInstance(FTransform(
                            FRotator(AmbStream.FRandRange(-8.f, 8.f), AmbStream.FRandRange(0.f, 360.f),
                                AmbStream.FRandRange(-8.f, 8.f)),
                            Loc + FVector(AmbStream.FRandRange(-1.f, 1.f), AmbStream.FRandRange(-1.f, 1.f), 0.f) * Wide * 0.22f,
                            FVector(CW / 100.f, (CW * 0.85f) / 100.f, (CW * 0.32f) / 100.f)), true);
                    }
                }
                ++AmbCount;
            }

            // the knocked pile: two bags still stacked, two flung, a post down
            {
                const FVector Base = SquadAIMissionFactory::RingPoint(World, Origin, Ring, 3, 5.f)
                    + FVector(AmbStream.FRandRange(-200.f, 200.f), AmbStream.FRandRange(-200.f, 200.f), 0.f);
                const FVector Loc = SquadAIMissionFactory::GroundPoint(World, Base, 0.f);
                SquadAIMissionFactory::SceneryPiece(World, Zone, Loc + FVector(0.f, 0.f, 14.f),
                    FRotator(2.f, ZoneYaw + 8.f, 0.f), Cache->GetCubeMesh(),
                    FVector(0.55f, 0.35f, 0.26f), BagMat, TEXT("Knocked Sandbags"));
                SquadAIMissionFactory::SceneryPiece(World, Zone, Loc + FVector(18.f, -14.f, 40.f),
                    FRotator(-6.f, ZoneYaw - 14.f, 3.f), Cache->GetCubeMesh(),
                    FVector(0.55f, 0.35f, 0.26f), BagMat, TEXT("Knocked Sandbags"));
                SquadAIMissionFactory::SceneryPiece(World, Zone, Loc + FVector(76.f, 52.f, 12.f),
                    FRotator(0.f, ZoneYaw + 65.f, 74.f), Cache->GetCubeMesh(),
                    FVector(0.55f, 0.35f, 0.26f), BagMat, TEXT("Flung Sandbag"));
                SquadAIMissionFactory::SceneryPiece(World, Zone, Loc + FVector(-58.f, -84.f, 12.f),
                    FRotator(0.f, ZoneYaw - 30.f, 68.f), Cache->GetCubeMesh(),
                    FVector(0.55f, 0.35f, 0.26f), BagMat, TEXT("Flung Sandbag"));
                SquadAIMissionFactory::SceneryPiece(World, Zone, Loc + FVector(120.f, -26.f, 8.f),
                    FRotator(84.f, ZoneYaw + 18.f, 0.f), Cache->GetCylinderMesh(),
                    FVector(0.12f, 0.f, 1.5f), BarkMat, TEXT("Fallen Post"));
                AmbCount += 5;
            }

            // the banner: defended ground gets a flag they mean to keep
            if (Template->MissionType == EMissionType::Defend)
            {
                const FVector Base = SquadAIMissionFactory::RingPoint(World, Origin, Ring, 0, 5.f);
                const FVector Loc = SquadAIMissionFactory::GroundPoint(World, Base, 0.f);
                SquadAIMissionFactory::SceneryPiece(World, Zone, Loc + FVector(0.f, 0.f, 300.f),
                    FRotator(0.f, ZoneYaw + AmbStream.FRandRange(-6.f, 6.f), 0.f),
                    Cache->GetCylinderMesh(), FVector(0.08f, 0.08f, 6.0f), BarkMat, TEXT("Position Banner Pole"));
                SquadAIMissionFactory::SceneryPiece(World, Zone, Loc + FVector(0.f, 0.f, 585.f),
                    FRotator(0.f, ZoneYaw, 0.f), Cache->GetCubeMesh(),
                    FVector(0.95f, 0.05f, 0.05f), BannerMat, TEXT("Position Banner Crossbar"));
                SquadAIMissionFactory::SceneryPiece(World, Zone, Loc + FVector(0.f, 0.f, 530.f),
                    FRotator(0.f, ZoneYaw, 0.f), Cache->GetCubeMesh(),
                    FVector(0.8f, 0.03f, 0.95f), BannerMat, TEXT("Position Banner"));
                AmbCount += 3;
            }

            // the worn path: trampled dirt where the patrols come and go
            for (int32 Pi = 0; Pi < 3; ++Pi)
            {
                const FVector Base = SquadAIMissionFactory::RingPoint(World, Origin, Ring, (Pi * 2 + 1) % Ring.Num(), 5.f);
                if (AStaticMeshActor* Path = SquadAIMissionFactory::SceneryPiece(World, Zone,
                    SquadAIMissionFactory::GroundPoint(World, Base, 3.f),
                    FRotator(0.f, ZoneYaw + Pi * 120.f, 0.f), Cache->GetCylinderMesh(),
                    FVector(1.7f, 1.7f, 0.035f), DirtMat, TEXT("Worn Path")))
                {
                    Path->GetStaticMeshComponent()->SetCastShadow(false);
                }
            }
            Log += FString::Printf(TEXT("   + ambience: %d pieces (trees, scrub, battle wear%s, worn paths)\n"),
                AmbCount, Template->MissionType == EMissionType::Defend ? TEXT(", banner") : TEXT(""));
        }
    }

    // -- S26-WEAR: the small debris a fight leaves behind. A dropped helmet,
    //    a pile of spent brass where someone reloaded, wire snagged off its
    //    post, pocks stitched across the dirt, scrap planks nobody picked up.
    {
        USquadAIAssetCacheSubsystem* Cache = USquadAIAssetCacheSubsystem::Get(World);
        if (Cache && Cache->GetCubeMesh() && Cache->GetCylinderMesh() && Cache->GetSphereMesh()
            && Ring.Num() > 0 && Template->MissionType != EMissionType::Reach)
        {
            FRandomStream WearStream(2630);
            UMaterialInterface* OliveMat = Cache->GetPropMaterial(TEXT("OliveArmor"), FLinearColor(0.42f, 0.45f, 0.34f, 1.f));
            UMaterialInterface* BrassMat = Cache->GetPropMaterial(TEXT("MetalPlate"), FLinearColor(0.72f, 0.55f, 0.22f, 1.f));
            UMaterialInterface* SteelMat = Cache->GetPropMaterial(TEXT("MetalPlate"), FLinearColor(0.55f, 0.57f, 0.53f, 1.f));
            UMaterialInterface* PockMat = Cache->GetPropMaterial(TEXT("ScorchedMetal"), FLinearColor(0.10f, 0.09f, 0.08f, 1.f));
            UMaterialInterface* ScrapMat = Cache->GetPropMaterial(TEXT("WoodPlanks"), FLinearColor(0.5f, 0.46f, 0.4f, 1.f));

            const FVector HelmLoc = SquadAIMissionFactory::GroundPoint(World,
                SquadAIMissionFactory::RingPoint(World, Origin, Ring, 4, 5.f)
                    + FVector(WearStream.FRandRange(-220.f, 220.f), WearStream.FRandRange(-220.f, 220.f), 0.f), 0.f);
            SquadAIMissionFactory::SceneryPiece(World, Zone, HelmLoc + FVector(0.f, 0.f, 7.f),
                FRotator(WearStream.FRandRange(-40.f, 40.f), WearStream.FRandRange(0.f, 360.f), 12.f),
                Cache->GetSphereMesh(), FVector(0.26f, 0.26f, 0.15f), OliveMat, TEXT("Dropped Helmet"));

            // S26-WEAR5: the rifle it was dropped with - wooden body, steel
            // barrel, magazine tilted in. It shares the helmet's clearing;
            // whoever owned them did not walk back.
            if (WearStream.FRand() > 0.5f)
            {
                const FVector RifleBase = HelmLoc
                    + FVector(WearStream.FRandRange(80.f, 150.f), WearStream.FRandRange(-100.f, 100.f), 0.f);
                const FVector RifleLoc = SquadAIMissionFactory::GroundPoint(World, RifleBase, 4.f);
                const float RifleYaw = WearStream.FRandRange(0.f, 360.f);
                const FVector RDir = FRotator(0.f, RifleYaw, 0.f).Vector();
                SquadAIMissionFactory::SceneryPiece(World, Zone, RifleLoc,
                    FRotator(0.f, RifleYaw, 3.f),
                    Cache->GetCubeMesh(), FVector(1.05f, 0.07f, 0.07f), ScrapMat, TEXT("Dropped Rifle"));
                SquadAIMissionFactory::SceneryPiece(World, Zone, RifleLoc + RDir * 62.f + FVector(0.f, 0.f, 1.f),
                    FRotator(90.f, RifleYaw, 3.f),
                    Cache->GetCylinderMesh(), FVector(0.03f, 0.03f, 0.55f), SteelMat, FString());
                SquadAIMissionFactory::SceneryPiece(World, Zone, RifleLoc - RDir * 8.f + FVector(0.f, 0.f, 5.f),
                    FRotator(0.f, RifleYaw, 14.f),
                    Cache->GetCubeMesh(), FVector(0.05f, 0.12f, 0.20f), SteelMat, FString());
            }

            const FVector BrassLoc = SquadAIMissionFactory::GroundPoint(World,
                SquadAIMissionFactory::RingPoint(World, Origin, Ring, 1, 5.f)
                    + FVector(WearStream.FRandRange(-180.f, 180.f), WearStream.FRandRange(-180.f, 180.f), 0.f), 0.f);
            // S26-WEAR2: the brass becomes HISM instances - one component on
            // the zone, never one actor per casing. A real fight leaves dozens
            // of shells; the renderer should see a single instanced draw.
            int32 ShellCount = 0;
            UHierarchicalInstancedStaticMeshComponent* Shells = nullptr;
            {
                TArray<UInstancedStaticMeshComponent*> Comps;
                Zone->GetComponents<UInstancedStaticMeshComponent>(Comps);
                for (UInstancedStaticMeshComponent* C : Comps)
                {
                    if (C && C->GetFName() == TEXT("HISM_Shells"))
                    {
                        Shells = Cast<UHierarchicalInstancedStaticMeshComponent>(C);
                        break;
                    }
                }
            }
            if (!Shells && Zone->GetRootComponent())
            {
                Shells = NewObject<UHierarchicalInstancedStaticMeshComponent>(Zone, TEXT("HISM_Shells"));
                if (Shells)
                {
                    Shells->RegisterComponent();
                    Shells->AttachToComponent(Zone->GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
                    Shells->SetMobility(Zone->GetRootComponent()->Mobility);   // never more static than the zone
                    Shells->SetStaticMesh(Cache->GetCylinderMesh());
                    Shells->SetCollisionProfileName(TEXT("NoCollision"));
                    Shells->SetCastShadow(false);
                    Shells->SetCanEverAffectNavigation(false);
                    Shells->SetMaterial(0, BrassMat);
                }
            }
            if (Shells)
            {
                Shells->ClearInstances();   // rebuild-safe: fixed seed, the scatter replays identically
                // casings lie flat: cylinder axis pitched to horizontal
                auto ShellAt = [&Shells, &ShellCount](const FVector& Loc, float Yaw)
                {
                    Shells->AddInstance(FTransform(FRotator(90.f, Yaw, 0.f),
                        Loc + FVector(0.f, 0.f, 2.f), FVector(0.024f, 0.024f, 0.055f)), true);
                    ++ShellCount;
                };
                // the reload pile - someone went through magazines here
                for (int32 Ci = 0; Ci < 8; ++Ci)
                {
                    ShellAt(SquadAIMissionFactory::GroundPoint(World,
                        BrassLoc + FVector(WearStream.FRandRange(-45.f, 45.f), WearStream.FRandRange(-45.f, 45.f), 0.f), 0.f),
                        WearStream.FRandRange(0.f, 360.f));
                }
                // burst clusters around the ring - the fight moved as it went
                for (int32 Bi = 0; Bi < 4; ++Bi)
                {
                    const FVector BurstLoc = SquadAIMissionFactory::RingPoint(World, Origin, Ring, (Bi * 2 + 3) % 6, 5.f)
                        + FVector(WearStream.FRandRange(-200.f, 200.f), WearStream.FRandRange(-200.f, 200.f), 0.f);
                    const int32 InBurst = 5 + (Bi % 3);
                    for (int32 Ii = 0; Ii < InBurst; ++Ii)
                    {
                        ShellAt(SquadAIMissionFactory::GroundPoint(World,
                            BurstLoc + FVector(WearStream.FRandRange(-45.f, 45.f), WearStream.FRandRange(-45.f, 45.f), 0.f), 0.f),
                            WearStream.FRandRange(0.f, 360.f));
                    }
                }
                // strays - singles thrown wide, the tail of it
                for (int32 Si = 0; Si < 10; ++Si)
                {
                    ShellAt(SquadAIMissionFactory::GroundPoint(World,
                        SquadAIMissionFactory::RingPoint(World, Origin, Ring, Si % 6, 5.f)
                            + FVector(WearStream.FRandRange(-320.f, 320.f), WearStream.FRandRange(-320.f, 320.f), 0.f), 0.f),
                        WearStream.FRandRange(0.f, 360.f));
                }
            }

            const FVector WireLoc = SquadAIMissionFactory::GroundPoint(World,
                SquadAIMissionFactory::RingPoint(World, Origin, Ring, 5, 5.f)
                    + FVector(WearStream.FRandRange(-200.f, 200.f), WearStream.FRandRange(-200.f, 200.f), 0.f), 0.f);
            // S26-SPHERE2: a coiled wire pile reads as a flat cylinder drum,
            // not as the squashed steel ball it used to be
            SquadAIMissionFactory::SceneryPiece(World, Zone, WireLoc + FVector(0.f, 0.f, 7.f),
                FRotator(0.f, WearStream.FRandRange(0.f, 360.f), 0.f),
                Cache->GetCylinderMesh(), FVector(0.5f, 0.5f, 0.14f), SteelMat, TEXT("Snagged Wire"));
            SquadAIMissionFactory::SceneryPiece(World, Zone, WireLoc + FVector(70.f, -30.f, 5.f),
                FRotator(0.f, WearStream.FRandRange(0.f, 360.f), 90.f),
                Cache->GetCylinderMesh(), FVector(0.04f, 0.04f, 0.8f), SteelMat, TEXT("Broken Wire Post"));

            const FVector PockLoc = SquadAIMissionFactory::GroundPoint(World,
                SquadAIMissionFactory::RingPoint(World, Origin, Ring, 2, 5.f)
                    + FVector(WearStream.FRandRange(-150.f, 150.f), WearStream.FRandRange(-150.f, 150.f), 0.f), 0.f);
            for (int32 Pi = 0; Pi < 4; ++Pi)
            {
                if (AStaticMeshActor* Pock = SquadAIMissionFactory::SceneryPiece(World, Zone,
                    PockLoc + FVector(Pi * 34.f, WearStream.FRandRange(-18.f, 18.f), 1.5f),
                    FRotator(0.f, 0.f, 0.f),   // a ground pock is a flat disc, not a coin on edge
                    Cache->GetCylinderMesh(), FVector(0.10f, 0.10f, 0.016f), PockMat,
                    Pi == 0 ? TEXT("Bullet Pocks") : FString()))
                {
                    Pock->GetStaticMeshComponent()->SetCastShadow(false);
                }
            }

            for (int32 Si = 0; Si < 2; ++Si)
            {
                SquadAIMissionFactory::SceneryPiece(World, Zone,
                    SquadAIMissionFactory::GroundPoint(World,
                        PockLoc + FVector(WearStream.FRandRange(-260.f, 260.f), WearStream.FRandRange(-260.f, 260.f), 0.f), 3.f),
                    FRotator(0.f, WearStream.FRandRange(0.f, 360.f), WearStream.FRandRange(-4.f, 4.f)),   // lying flat, never on edge
                    Cache->GetCubeMesh(), FVector(0.6f, 0.12f, 0.04f), ScrapMat, TEXT("Scrap Plank"));
            }
            Log += FString::Printf(TEXT("   + battle wear: helmet, brass x%d on one HISM, wire snag, pocks, scrap\n"), ShellCount);
        }
    }

    // ---- 6. the quest chain ---------------------------------------------------
    if (bAppendToQuestChain)
    {
        AQuestChain* Chain = nullptr;
        for (TActorIterator<AQuestChain> ChainIt(World); ChainIt; ++ChainIt)
        {
            Chain = *ChainIt;
            break;
        }
        if (!Chain)
        {
            Chain = World->SpawnActor<AQuestChain>(AQuestChain::StaticClass(), Origin, Rotation, SpawnParams);
            Log += TEXT("   + created a quest chain (none was in the level)\n");
        }
        if (Chain)
        {
#if WITH_EDITORONLY_DATA
            Chain->SetIsSpatiallyLoaded(false);   // S20-WP: the campaign brain never streams out
#endif
            Chain->Missions.Add(Zone);
            Zone->OwningChain = Chain;
            Zone->MissionIndex = Chain->Missions.Num() - 1;
            Chain->ExpectedMissionCount = FMath::Max(Chain->ExpectedMissionCount, Chain->Missions.Num());
            Log += FString::Printf(TEXT("   + appended to quest chain as mission #%d\n"), Zone->MissionIndex + 1);
        }
    }
    else
    {
        Log += TEXT("   note: not appended to a chain - activate this zone with a trigger or ActivateMission.\n");
    }

    Log += FString::Printf(TEXT("DONE: mission '%s' built at %s.\n"),
        *Template->GetName(), *Origin.ToCompactString());
    UE_LOG(LogTemp, Warning, TEXT("%s"), *Log);
    return Finish(Log, Zone);
}

// The FString overload is a thin wrapper: everyone who wants the log gets the log.
FString USquadAIAutoSetupEditorLibrary::BuildMissionFromTemplate(UWorld* World, UMissionTemplateAsset* Template,
    FVector Origin, FRotator Rotation, bool bAppendToQuestChain)
{
    FString Report;
    BuildMissionFromTemplate_GetZone(World, Template, Origin, Rotation, bAppendToQuestChain, &Report);
    return Report;
}


// ===========================================================================
//  S19-MAP: the landscape checker and the automatic mission putter
//  The RULES live in Quest/MapLayoutModel.h (harness-pinned); this is the
//  actor walking and the file writing.
// ===========================================================================

namespace SquadAILandscape
{
	// S26-GROUND2: THE ground. The terrain grid is a SAMPLE of the land - on a
	// lidar map its cells can sit meters above or below the visible landscape,
	// which put towers in the sky and bridges under riverbeds. One line trace
	// from high above to far below reads the landscape collision itself; the
	// caller's Z becomes the fallback, never the truth.
	static double GroundZAt(UWorld* World, const FVector& XY, double FallbackZ)
	{
		if (!World)
		{
			return FallbackZ;
		}
		// S26-FIXALL SWEEP: multi-hit, take the DEEPEST blocking hit - the same
		// rule GroundPoint now follows. A single hit lands on the first roof or
		// wall above the point; the terrain is always the LAST thing the ray
		// meets. Matters here because the map-bounds clamp can move an outpost
		// or tower toward ground that already carries a mission's buildings.
		TArray<FHitResult> Hits;
		FCollisionQueryParams Params(SCENE_QUERY_STAT(SquadAIGroundAt), /*bTraceComplex=*/false);
		const FVector Sky(XY.X, XY.Y, 100000.0);
		const FVector Deep(XY.X, XY.Y, -100000.0);
		if (World->LineTraceMultiByChannel(Hits, Sky, Deep, ECC_Visibility, Params) && Hits.Num() > 0)
		{
			return Hits.Last().ImpactPoint.Z;
		}
		return FallbackZ;
	}

	static bool MatchesTokens(const AActor* Actor, const TArray<FString>& Tokens)
	{
		if (Tokens.Num() == 0 || !Actor)
		{
			return false;
		}
		const FString ClassName = Actor->GetClass()->GetName();
#if WITH_EDITOR
		const FString Label = Actor->GetActorLabel();
#else
		const FString Label = Actor->GetName();
#endif
		for (const FString& Token : Tokens)
		{
			const FString T = Token.TrimStartAndEnd();
			if (!T.IsEmpty() && (ClassName.Contains(T) || Label.Contains(T)))
			{
				return true;
			}
		}
		return false;
	}

	/** Actor positions, or instance positions for foliage/ISM (sampled to a cap). */
	static void CollectFeaturePoints(UWorld* World, const TArray<FString>& Tokens,
		TArray<FVector>& OutPoints, int32& OutActorsRead)
	{
		OutPoints.Reset();
		OutActorsRead = 0;
		if (Tokens.Num() == 0)
		{
			return;
		}
		constexpr int32 MaxInstancesPerComponent = 1500;
		for (TActorIterator<AActor> It(World); It; ++It)
		{
			AActor* Actor = *It;
			if (!Actor || !MatchesTokens(Actor, Tokens))
			{
				continue;
			}
			++OutActorsRead;

			bool bAddedInstances = false;
			TArray<UInstancedStaticMeshComponent*> ISMs;
			Actor->GetComponents<UInstancedStaticMeshComponent>(ISMs);
			for (UInstancedStaticMeshComponent* ISM : ISMs)
			{
				if (!ISM)
				{
					continue;
				}
				const int32 Count = ISM->GetInstanceCount();
				const int32 Step = FMath::Max(1, Count / MaxInstancesPerComponent);
				FTransform Xform;
				for (int32 i = 0; i < Count; i += Step)
				{
					if (ISM->GetInstanceTransform(i, Xform, /*bWorldSpace=*/true))
					{
						OutPoints.Add(Xform.GetTranslation());
					}
				}
				bAddedInstances = OutPoints.Num() > 0;
			}
			if (!bAddedInstances)
			{
				OutPoints.Add(Actor->GetActorLocation());
			}
		}
	}

	/** EVERY water actor keeps its own polyline: each of its spline components is
	 *  read IN spline order (a spline's point order IS the river's true course -
	 *  never re-shuffled; a meandering river used to get scrambled into shortcuts).
	 *  Actors without a spline contribute their position as a lone marker; lone
	 *  markers are chained nearest-neighbour among themselves (an unordered pile),
	 *  then lines that touch within a small gap are joined - so one river split
	 *  across several spline actors becomes one line while truly separate rivers
	 *  stay separate (the old single-array weld fused every river into one). */
	static void CollectRiverPolylines(UWorld* World, const TArray<FString>& Tokens,
		TArray<TArray<FVector>>& OutRivers, int32& OutActorsRead)
	{
		OutRivers.Reset();
		OutActorsRead = 0;
		if (Tokens.Num() == 0)
		{
			return;
		}
		TArray<FVector> LoneMarkers;
		for (TActorIterator<AActor> It(World); It; ++It)
		{
			AActor* Actor = *It;
			if (!Actor || !MatchesTokens(Actor, Tokens))
			{
				continue;
			}
			++OutActorsRead;
			bool bReadSpline = false;
			TArray<USplineComponent*> Splines;
			Actor->GetComponents<USplineComponent>(Splines);
			for (USplineComponent* Spline : Splines)
			{
				if (!Spline || Spline->GetNumberOfSplinePoints() < 2)
				{
					continue;
				}
				const int32 N = Spline->GetNumberOfSplinePoints();
				TArray<FVector> Line;
				for (int32 i = 0; i < N; ++i)
				{
					Line.Add(Spline->GetWorldLocationAtSplinePoint(i));   // world space, IN order
				}
				OutRivers.Add(Line);
				bReadSpline = true;
			}
			if (!bReadSpline)
			{
				LoneMarkers.Add(Actor->GetActorLocation());
			}
		}

		// An unordered marker PILE becomes one walkable chain (spline lines are
		// never touched - their order is already the truth).
		if (LoneMarkers.Num() > 1)
		{
			int32 Cursor = 0;
			for (int32 i = 1; i < LoneMarkers.Num(); ++i)
			{
				if (LoneMarkers[i].X < LoneMarkers[Cursor].X) Cursor = i;
			}
			TArray<FVector> Chained;
			TArray<bool> Used;
			Used.Init(false, LoneMarkers.Num());
			Chained.Add(LoneMarkers[Cursor]);
			Used[Cursor] = true;
			while (Chained.Num() < LoneMarkers.Num())
			{
				int32 Best = -1;
				double BestDist = DBL_MAX;
				for (int32 i = 0; i < LoneMarkers.Num(); ++i)
				{
					if (Used[i]) continue;
					const double D = FVector::Dist2D(Chained.Last(), LoneMarkers[i]);
					if (D < BestDist) { BestDist = D; Best = i; }
				}
				if (Best == -1) break;
				Chained.Add(LoneMarkers[Best]);
				Used[Best] = true;
			}
			OutRivers.Add(Chained);
		}
		else if (LoneMarkers.Num() == 1)
		{
			OutRivers.Add(LoneMarkers);
		}

		// One river split across several spline actors -> one line; separate rivers
		// stay separate.
		FMapLayoutModel::JoinRiverPolylines(OutRivers);
	}

	/** True ground height under an XY (editor world traced straight down). */
	static bool SampleGroundZ(UWorld* World, const FVector& XY, float& OutZ)
	{
		if (!World)
		{
			return false;
		}
		FHitResult Hit;
		FCollisionQueryParams Params(TEXT("SquadAITerrainScan"), /*bTraceComplex=*/true);
		const bool bHit = World->LineTraceSingleByChannel(Hit,
			FVector(XY.X, XY.Y, 5000000.0), FVector(XY.X, XY.Y, -5000000.0),
			ECC_WorldStatic, Params);
		if (!bHit)
		{
			return false;
		}
		OutZ = Hit.Location.Z;
		return true;
	}

	/** Sample the WHOLE playable area into a height grid (S21-TERRAIN). CellSizeCm
	 *  lands near 200 m for a 9-km map (~2,000 editor traces - fine offline). Cells
	 *  whose trace finds nothing stay invalid and are skipped by every rule. */
	static FHeightGrid BuildHeightGridWorld(UWorld* World,
		double MinX, double MinY, double MaxX, double MaxY)
	{
		FHeightGrid G;
		if (!World || MaxX <= MinX || MaxY <= MinY)
		{
			return G;
		}
		const double SX = MaxX - MinX;
		const double SY = MaxY - MinY;
		// complex hills need a fine net: ~128 cells across -> ~70 m cells on a
		// 9-km map (16,384 one-shot editor traces; every deep read that consumes
		// the grid is linear or near-linear in cells)
		G.CellSizeCm = FMath::Max(7000.0, FMath::Max(SX, SY) / 128.0);
		G.W = FMath::Clamp((int32)(SX / G.CellSizeCm) + 1, 2, 128);
		G.H = FMath::Clamp((int32)(SY / G.CellSizeCm) + 1, 2, 128);
		G.Cells.SetNum(G.W * G.H);
		for (int32 Y = 0; Y < G.H; ++Y)
		{
			for (int32 X = 0; X < G.W; ++X)
			{
				FHeightCell C;
				C.bValid = SampleGroundZ(World,
					FVector(MinX + X * G.CellSizeCm, MinY + Y * G.CellSizeCm, 0.0), C.Z);
				G.Cells[Y * G.W + X] = C;
			}
		}
		FTerrainStructureModel::ComputeRange(G);
		FTerrainStructureModel::ComputeProminence(G);   // the true hills, by saddle rank
		return G;
	}

	/** One guard post (sandbags / roadblock) planted on real ground. */
	static AQuickFortificationSpawnerActor* SpawnGuardPost(UWorld* World,
		const FVector& Pos, EFortificationPreset Preset, const FString& Label,
		float YawDeg = 0.f)
	{
		if (!World)
		{
			return nullptr;
		}
		FActorSpawnParameters Params;
		Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
		AQuickFortificationSpawnerActor* Post = World->SpawnActor<AQuickFortificationSpawnerActor>(
			AQuickFortificationSpawnerActor::StaticClass(), Pos, FRotator(0.f, YawDeg, 0.f), Params);
		if (Post)
		{
			// S26-LOGIC: same lifecycle tag as the war works - the purge is
			// tag-based, never label-based (a renamed label used to orphan it)
			Post->Tags.AddUnique(FName(TEXT("SquadAIStampedWarWork")));
			Post->FortificationPreset = Preset;
#if WITH_EDITOR
			Post->SetActorLabel(Label);
			Post->SetFolderPath(FName(TEXT("SquadAI/Guard Posts")));   // S26-FOLDER
#endif
		}
		return Post;
	}

	/** S25-WARWORKS: one war piece (bridge / tower / hull) planted on the land.
	 *  Built entirely from the asset cache's basic meshes and shared dynamic
	 *  materials - the module creates the materials itself, no content needed. */
	static AWarWorksActor* SpawnWarWork(UWorld* World, const FVector& Pos, float YawDeg,
		EWarWorkPreset Preset, float SpanCm, const FString& Label)
	{
		if (!World)
		{
			return nullptr;
		}
		FVector FinalPos = Pos;
		// S26-VIEW: a tower is only worth building where it can SEE. The model
		// picks high ground from the map data, but a mountain BOWL is high on
		// average and blind in every direction. Scan a 5x5 grid up to 80 m out:
		// a candidate wins with >= 3 of 8 directions at 150 m at least 5 m
		// BELOW it, ranked by view count first, then height.
		if (Preset == EWarWorkPreset::WatchTower)
		{
			auto GroundAt = [&](const FVector& At) -> float
			{
				return SquadAIMissionFactory::GroundPoint(World, At, 0.f).Z;   // S26-COMPILE: SpawnWarWork lives in SquadAILandscape; GroundPoint does not
			};
			int32 BestViews = -1;
			float BestZ = -1e9f;
			FVector BestXY = Pos;
			for (int32 GX = -2; GX <= 2; ++GX)
			{
				for (int32 GY = -2; GY <= 2; ++GY)
				{
					const FVector Cand = Pos + FVector(GX * 4000.f, GY * 4000.f, 0.f);
					const float CZ = GroundAt(Cand);
					int32 Views = 0;
					for (int32 Dir = 0; Dir < 8; ++Dir)
					{
						if (GroundAt(Cand + FRotator(0.f, Dir * 45.f, 0.f).Vector() * 15000.f) < CZ - 500.f)
						{
							++Views;
						}
					}
					const bool bBetter = (Views > BestViews) || (Views == BestViews && CZ > BestZ);
					if (Views >= 3 && bBetter)
					{
						BestViews = Views;
						BestZ = CZ;
						BestXY = FVector(Cand.X, Cand.Y, CZ);
					}
				}
			}
			if (BestViews >= 3)
			{
				FinalPos = BestXY;   // grounded on its own vantage, not the bowl
			}
		}
		FActorSpawnParameters Params;
		Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
		AWarWorksActor* Work = World->SpawnActor<AWarWorksActor>(
			AWarWorksActor::StaticClass(), FinalPos, FRotator(0.f, YawDeg, 0.f), Params);
		if (Work)
		{
			// S26-LOGIC: scatter-stamped pieces carry a tag; the purge on the next
			// press removes tagged actors ONLY - a hand-placed tower survives.
			Work->Tags.AddUnique(FName(TEXT("SquadAIStampedWarWork")));
			Work->Preset = Preset;
			Work->SpanCm = SpanCm;
			Work->BuildWarWork();   // OnConstruction ran with defaults - rebuild for the real preset
#if WITH_EDITOR
			Work->SetActorLabel(Label);
			Work->SetFolderPath(FName(TEXT("SquadAI/War Works")));   // S26-FOLDER
#endif
		}
		return Work;
	}

	/** Scan every zone's ground (center + up to 32 spread samples) and write the
	 *  measured drop into HeightSpreadCm. Unscannable zones stay -1 (unscanned). */
	static void ApplyTerrainScan(UWorld* World, TArray<FMapZone>& Zones)
	{
		for (FMapZone& Z : Zones)
		{
			float MinZ = FLT_MAX, MaxZ = -FLT_MAX, H = 0.f;
			auto Take = [&](const FVector& P)
			{
				if (SampleGroundZ(World, P, H))
				{
					MinZ = FMath::Min(MinZ, H);
					MaxZ = FMath::Max(MaxZ, H);
				}
			};
			Take(Z.Center);
			const int32 N = Z.SamplePoints.Num();
			if (N > 0)
			{
				const int32 Step = FMath::Max(1, (N + 31) / 32);
				for (int32 i = 0; i < N; i += Step)
				{
					Take(Z.SamplePoints[i]);
				}
			}
			if (MinZ <= MaxZ)
			{
				Z.HeightSpreadCm = MaxZ - MinZ;
			}
		}
	}

	/** The ground relief right around the player start (a +/-25 m cross). */
	static float MeasureAnchorDropCm(UWorld* World, const FVector& Anchor)
	{
		float MinZ = FLT_MAX, MaxZ = -FLT_MAX, H = 0.f;
		auto Take = [&](const FVector& P)
		{
			if (SampleGroundZ(World, P, H))
			{
				MinZ = FMath::Min(MinZ, H);
				MaxZ = FMath::Max(MaxZ, H);
			}
		};
		Take(Anchor);
		static const float Off[4][2] = { { 2500.f, 0.f }, { -2500.f, 0.f }, { 0.f, 2500.f }, { 0.f, -2500.f } };
		for (int32 i = 0; i < 4; ++i)
		{
			Take(Anchor + FVector(Off[i][0], Off[i][1], 0.f));
		}
		return MinZ <= MaxZ ? (MaxZ - MinZ) : -1.f;
	}

	static bool SaveReportFile(const FString& FileName, const FString& Content, FString& OutPath)
	{
		const FString Dir = FPaths::ProjectDir() + TEXT("SquadAIReports/");
		IPlatformFile& Platform = FPlatformFileManager::Get().GetPlatformFile();
		Platform.CreateDirectoryTree(*Dir);
		OutPath = Dir + FileName;
		return FFileHelper::SaveStringToFile(Content, *OutPath);
	}
}

TArray<FString> USquadAIAutoSetupEditorLibrary::DefaultCrateTokens()
{
	return { TEXT("Crate"), TEXT("Trench") };
}

TArray<FString> USquadAIAutoSetupEditorLibrary::DefaultTreeTokens()
{
	return { TEXT("Tree"), TEXT("Bush"), TEXT("Foliage"), TEXT("Plant") };
}

TArray<FString> USquadAIAutoSetupEditorLibrary::DefaultRiverTokens()
{
	return { TEXT("Water"), TEXT("River"), TEXT("Lake"), TEXT("Creek") };
}

FString USquadAIAutoSetupEditorLibrary::AnalyzeLandscapeLayout(UWorld* World,
	const TArray<FString>& CrateTokens, const TArray<FString>& TreeTokens,
	const TArray<FString>& RiverTokens)
{
	if (!World) return TEXT("ERROR: World is NULL");

	int32 CrateActors = 0, TreeActors = 0, RiverActors = 0;
	TArray<FVector> CratePoints, TreePoints;
	TArray<TArray<FVector>> Rivers;
	SquadAILandscape::CollectFeaturePoints(World, CrateTokens, CratePoints, CrateActors);
	SquadAILandscape::CollectFeaturePoints(World, TreeTokens, TreePoints, TreeActors);
	SquadAILandscape::CollectRiverPolylines(World, RiverTokens, Rivers, RiverActors);

	TArray<FMapZone> TrenchZones = FMapLayoutModel::ClusterPoints(CratePoints, EMapFeatureKind::Trench);
	TArray<FMapZone> BiomeZones = FMapLayoutModel::ClusterPoints(TreePoints, EMapFeatureKind::Biome);
	SquadAILandscape::ApplyTerrainScan(World, TrenchZones);
	SquadAILandscape::ApplyTerrainScan(World, BiomeZones);

	// the anchor: the player start, else the middle of everything
	FVector Anchor = FVector::ZeroVector;
	{
		double SumX = 0, SumY = 0; int32 N = 0;
		auto Acc = [&](const FVector& P) { SumX += P.X; SumY += P.Y; ++N; };
		for (const FMapZone& Z : TrenchZones) { Acc(Z.Center); }
		for (const FMapZone& Z : BiomeZones)  { Acc(Z.Center); }
		for (const TArray<FVector>& L : Rivers)
		{
			for (const FVector& P : L)    { Acc(P); }
		}
		Anchor = N > 0 ? FVector(SumX / N, SumY / N, 0.f) : FVector::ZeroVector;
		for (TActorIterator<APlayerStart> It(World); It; ++It)
		{
			Anchor = It->GetActorLocation();
			break;
		}
	}

	FString R;
	R += TEXT("=== LANDSCAPE CHECKER - MAP LAYOUT REPORT ===\n");
	R += TEXT("ONE map, ONE campaign. Everything below is what the mission putter reads.\n");
	if (World->GetWorldPartition())
	{
		R += TEXT("WORLD PARTITION map: this scan reads LOADED cells only - anything in an unloaded cell is MISSING from the numbers below. Load the whole map (or stream over it) before Analyze and Auto Scatter.\n");
	}
	R += TEXT("\n");
	R += FMapLayoutModel::DescribeLayout(TrenchZones, BiomeZones, Rivers, Anchor);
	{
		const float HQDrop = SquadAILandscape::MeasureAnchorDropCm(World, Anchor);
		R += HQDrop >= 0.f
			? FString::Printf(TEXT("the ground at your start is %s within 50 m (drop %.0f m).\n"),
				FMapLayoutModel::TerrainWord(HQDrop), HQDrop / 100.f)
			: TEXT("the ground at your start could not be traced - is there landscape under it?\n");
	}
	R += FString::Printf(TEXT("trench markers : %d actor(s) -> %d point(s) -> %d trench zone(s)\n"),
		CrateActors, CratePoints.Num(), TrenchZones.Num());
	R += FString::Printf(TEXT("biome markers  : %d actor(s) -> %d point(s) -> %d biome zone(s)\n"),
		TreeActors, TreePoints.Num(), BiomeZones.Num());
	R += FString::Printf(TEXT("river markers  : %d actor(s) -> %d river(s), %d line point(s)\n"),
		RiverActors, Rivers.Num(), FMapLayoutModel::RiverPointCount(Rivers));
	if (CrateActors == 0)
	{
		R += TEXT("  NOTE: no trench markers matched. Check the crate tokens (defaults: Crate, Trench)\n");
		R += TEXT("        against how your crates/trenches are actually named in the outliner.\n");
	}
	if (TreeActors == 0)
	{
		R += TEXT("  NOTE: no tree markers matched. Foliage painted with Instanced Meshes IS read;\n");
		R += TEXT("        check the tree tokens (defaults: Tree, Bush, Foliage, Plant).\n");
	}
	if (RiverActors == 0)
	{
		R += TEXT("  NOTE: no river markers matched - the scatter will avoid nothing along the water.\n");
	}
	R += TEXT("\nTRENCH ZONES (crate clusters = held ground):\n");
	for (const FMapZone& Z : TrenchZones)
	{
		float Nearest = -1.f;   // nearest OTHER trench, so you can tune Min Separation
		for (const FMapZone& O : TrenchZones)
		{
			if (&O != &Z)
			{
				const float D = static_cast<float>(FVector::Dist2D(Z.Center, O.Center));
				Nearest = (Nearest < 0.f || D < Nearest) ? D : Nearest;
			}
		}
		R += FString::Printf(TEXT("  (%.0f, %.0f) r=%.0f m, %d marker(s), from HQ %.0f m%s"),
			Z.Center.X / 100.f, Z.Center.Y / 100.f, Z.RadiusCm / 100.f, Z.PointCount,
			static_cast<float>(FVector::Dist2D(Z.Center, Anchor)) / 100.f,
			Nearest >= 0.f ? TEXT("") : TEXT(", the only trench line\n"));
		if (Nearest >= 0.f)
		{
			R += FString::Printf(TEXT(", nearest other trench %.0f m\n"), Nearest / 100.f);
		}
	}
	R += TEXT("\nBIOME ZONES (tree clusters = cover-dense terrain):\n");
	for (const FMapZone& Z : BiomeZones)
	{
		R += FString::Printf(TEXT("  (%.0f, %.0f) r=%.0f m, %d marker(s), from HQ %.0f m\n"),
			Z.Center.X / 100.f, Z.Center.Y / 100.f, Z.RadiusCm / 100.f, Z.PointCount,
			static_cast<float>(FVector::Dist2D(Z.Center, Anchor)) / 100.f);
	}
	float RiverLenM = 0.f;
	for (const TArray<FVector>& Line : Rivers)
	{
		for (int32 i = 1; i < Line.Num(); ++i)
		{
			RiverLenM += static_cast<float>(FVector::Dist2D(Line[i - 1], Line[i])) / 100.f;
		}
	}
	R += FString::Printf(TEXT("\nRIVER LINE: %d river(s), %d point(s), ~%.0f m long\n\n"),
		Rivers.Num(), FMapLayoutModel::RiverPointCount(Rivers), RiverLenM);

	// -- the LAND ITSELF: a sampled height grid, its rise, its bands and its
	// dominant ground (the guard-post sites) - S21-TERRAIN ---------------------------
	{
		double TMinX, TMaxX, TMinY, TMaxY;
		if (FMapLayoutModel::LayoutBounds(TrenchZones, BiomeZones, Rivers, Anchor,
			TMinX, TMaxX, TMinY, TMaxY))
		{
			const FHeightGrid Grid = SquadAILandscape::BuildHeightGridWorld(World, TMinX, TMinY, TMaxX, TMaxY);
			if (Grid.IsValid())
			{
				const float Rise = Grid.MaxZ - Grid.MinZ;
				int32 Bands[3] = { 0, 0, 0 };
				for (const FHeightCell& C : Grid.Cells)
				{
					if (C.bValid)
					{
						++Bands[FTerrainStructureModel::ElevationBand(C.Z, Grid.MinZ, Grid.MaxZ)];
					}
				}
				const float Total = (float)FMath::Max(1, Grid.ValidCount);
				float Steep = 0.f;
				int32 SteepCells = 0;
				for (int32 Y = 0; Y < Grid.H; ++Y)
				{
					for (int32 X = 0; X < Grid.W; ++X)
					{
						const float S = FTerrainStructureModel::SlopeAt(Grid, X, Y);
						Steep = FMath::Max(Steep, S);
						SteepCells += S > 0.6f ? 1 : 0;
					}
				}
				R += TEXT("TERRAIN STRUCTURE (the land itself, from a sampled height grid):\n");
				R += FString::Printf(TEXT("the land rises %.0f m from the lowest traced ground to the highest; steepest face %.0f%% (%d steep cell(s) of %d).\n"),
					Rise / 100.f, Steep * 100.f, SteepCells, Grid.ValidCount);
				R += FString::Printf(TEXT("lowland %d%% | mid-slope %d%% | highland %d%%\n"),
					(int)(Bands[0] * 100.f / Total), (int)(Bands[1] * 100.f / Total), (int)(Bands[2] * 100.f / Total));
				const TArray<FTerrainHighPoint> Highs = FTerrainStructureModel::FindHighGround(Grid, 8);
				if (Highs.Num() > 0)
				{
					R += FString::Printf(TEXT("the real hills, ranked by PROMINENCE (rise over the saddle joining each to higher ground - %d site(s), best first):\n"), Highs.Num());
					for (const FTerrainHighPoint& P : Highs)
					{
						R += FString::Printf(TEXT("  (%.0f, %.0f) prominence %.0f m, standing %.0f m over the lowland\n"),
							(TMinX + P.CellX * Grid.CellSizeCm) / 100.f,
							(TMinY + P.CellY * Grid.CellSizeCm) / 100.f,
							P.ProminenceCm / 100.f, P.RiseCm / 100.f);
					}
				}
					// S21-DEEP: the full survey - how the land is SHAPEN (landform
					// census + ruggedness), where water runs and pools, the passes
					// between the hills, and which hills actually SEE which. The
					// user's hills are complex; prominence alone was one instrument.
					{
						const float TpiThr = FMath::Max(500.f, (Grid.MaxZ - Grid.MinZ) * 0.02f);
						int32 Census[6] = {};
						double TriSum = 0.0;
						float TriMax = 0.f;
						int32 Counted = 0;
						for (int32 Y = 0; Y < Grid.H; ++Y)
						{
							for (int32 X = 0; X < Grid.W; ++X)
							{
								const FHeightCell* C = Grid.At(X, Y);
								if (!C || !C->bValid)
								{
									continue;
								}
								++Census[FTerrainStructureModel::ClassifyLandform(Grid, X, Y, 3, TpiThr)];
								const float Tri = FTerrainStructureModel::TriAt(Grid, X, Y);
								TriSum += Tri;
								TriMax = FMath::Max(TriMax, Tri);
								++Counted;
							}
						}
						if (Counted > 0)
						{
							R += FString::Printf(TEXT("landform census: %d%% peaks | %d%% crest lines | %d%% upper slopes | %d%% lower slopes | %d%% valley floors | %d%% plain floors\n"),
								Census[1] * 100 / Counted, Census[2] * 100 / Counted,
								Census[3] * 100 / Counted, Census[4] * 100 / Counted,
								Census[5] * 100 / Counted, Census[0] * 100 / Counted);
							R += FString::Printf(TEXT("broken ground: mean ruggedness %.1f m per cell, worst %.1f m\n"),
								TriSum / Counted / 100.0, TriMax / 100.f);
						}
					}
					{   // S21-DEEP: water, basins and the passes between the hills
						TArray<int32> Area, Down;
						FTerrainStructureModel::ComputeFlow(Grid, Area, Down);
						TArray<TArray<int32>> Lines;
						FTerrainStructureModel::TraceStreams(Grid, Area, Down,
							FMath::Max(16, Grid.ValidCount / 192), Lines);
						int32 StreamCells = 0, Longest = 0;
						for (const TArray<int32>& Line : Lines)
						{
							StreamCells += Line.Num();
							Longest = FMath::Max(Longest, Line.Num());
						}
						if (Lines.Num() > 0)
						{
							R += FString::Printf(TEXT("water: %d stream line(s) on the height grid, %.1f km total, longest %.1f km\n"),
								Lines.Num(),
								StreamCells * Grid.CellSizeCm / 100000.f,
								Longest * Grid.CellSizeCm / 100000.f);
						}
						const TArray<FTerrainDepression> Pits = FTerrainStructureModel::FindDepressions(Grid, 4);
						if (Pits.Num() > 0)
						{
							R += FString::Printf(TEXT("closed basins (water cannot leave): %d, deepest %.0f m\n"),
								Pits.Num(), Pits[0].DepthCm / 100.f);
							for (int32 i = 0; i < FMath::Min(3, Pits.Num()); ++i)
							{
								R += FString::Printf(TEXT("  basin %.0f m deep at (%.0f, %.0f)\n"),
									Pits[i].DepthCm / 100.f,
									(TMinX + Pits[i].CellX * Grid.CellSizeCm) / 100.f,
									(TMinY + Pits[i].CellY * Grid.CellSizeCm) / 100.f);
							}
						}
						const TArray<FTerrainSaddle> Passes = FTerrainStructureModel::FindPasses(Grid, 6);
						if (Passes.Num() > 0)
						{
							R += FString::Printf(TEXT("passes between the hills (the one easy way through) - %d, best first:\n"), Passes.Num());
							for (int32 i = 0; i < FMath::Min(4, Passes.Num()); ++i)
							{
								R += FString::Printf(TEXT("  %.0f m col at (%.0f, %.0f)\n"),
									Passes[i].ColProminenceCm / 100.f,
									(TMinX + Passes[i].CellX * Grid.CellSizeCm) / 100.f,
									(TMinY + Passes[i].CellY * Grid.CellSizeCm) / 100.f);
							}
						}
					}
					{   // S21-DEEP: sightlines, the best observation post, tank country
						const TArray<FTerrainHighPoint> Sights = FTerrainStructureModel::FindHighGround(Grid, 6);
						int32 SeenPairs = 0, AllPairs = 0;
						FString SeenText;
						for (int32 i = 0; i < Sights.Num(); ++i)
						{
							for (int32 j = i + 1; j < Sights.Num(); ++j)
							{
								++AllPairs;
								if (FTerrainStructureModel::Sees(Grid, Sights[i].CellX, Sights[i].CellY,
									Sights[j].CellX, Sights[j].CellY, 200.f))
								{
									++SeenPairs;
									if (SeenText.Len() < 240)
									{
										SeenText += FString::Printf(TEXT(" (%.0f,%.0f)<->(%.0f,%.0f)"),
											(TMinX + Sights[i].CellX * Grid.CellSizeCm) / 100.f,
											(TMinY + Sights[i].CellY * Grid.CellSizeCm) / 100.f,
											(TMinX + Sights[j].CellX * Grid.CellSizeCm) / 100.f,
											(TMinY + Sights[j].CellY * Grid.CellSizeCm) / 100.f);
									}
								}
							}
						}
						if (AllPairs > 0)
						{
							R += FString::Printf(TEXT("sightlines between the %d ranked hills: %d of %d pairs connect unbroken%s%s\n"),
								Sights.Num(), SeenPairs, AllPairs,
								SeenText.Len() > 0 ? TEXT(":") : TEXT(""), *SeenText);
						}
						if (Sights.Num() > 0)
						{
							int32 BestI = 0;
							int32 BestV = FTerrainStructureModel::ViewshedCells(Grid,
								Sights[0].CellX, Sights[0].CellY, 200.f);
							for (int32 i = 1; i < Sights.Num(); ++i)
							{
								const int32 V = FTerrainStructureModel::ViewshedCells(Grid,
									Sights[i].CellX, Sights[i].CellY, 200.f);
								if (V > BestV) { BestV = V; BestI = i; }
							}
							R += FString::Printf(TEXT("best observation post: (%.0f, %.0f) sees %d of %d traced cells\n"),
								(TMinX + Sights[BestI].CellX * Grid.CellSizeCm) / 100.f,
								(TMinY + Sights[BestI].CellY * Grid.CellSizeCm) / 100.f,
								BestV, Grid.ValidCount);
						}
						const FTerrainPatch Tanks = FTerrainStructureModel::LargestFlatPatch(Grid, 0.10f);
						if (Tanks.CellCount > 0)
						{
							const float CellM = Grid.CellSizeCm / 100.f;
							R += FString::Printf(TEXT("tank country: %.0f ha of near-level ground centred (%.0f, %.0f)\n"),
								Tanks.CellCount * CellM * CellM / 10000.f,
								TMinX / 100.f + Tanks.CentroidX * CellM,
								TMinY / 100.f + Tanks.CentroidY * CellM);
						}
					}
					{   // S21-DEEP: POSSIBLE MISSION AREAS - the land's own proposal,
					// ranked round-robin so no one kind of ground crowds the others out.
						const TArray<FTerrainCandidate> Cands = FTerrainStructureModel::FindOperationalGround(Grid, 8, 3);
						R += FString::Printf(TEXT("possible mission areas - the land's own proposal (%d, best first):\n"), Cands.Num());
						for (int32 i = 0; i < Cands.Num(); ++i)
						{
							const FTerrainCandidate& C = Cands[i];
							FString Line;
							if (C.Kind == Cand_Overwatch)
							{
								Line = FString::Printf(TEXT("sees %d of %d traced cells"), C.ScoreCells, Grid.ValidCount);
							}
							else if (C.Kind == Cand_Pass)
							{
								Line = FString::Printf(TEXT("the %.0f m col between the hills"), C.ScoreCm / 100.f);
							}
							else if (C.Kind == Cand_Basin)
							{
								Line = FString::Printf(TEXT("%.0f m deep, closed on all sides"), C.ScoreCm / 100.f);
							}
							else
							{
								Line = FString::Printf(TEXT("%.0f ha of level going"),
									C.ScoreCells * (Grid.CellSizeCm / 100.f) * (Grid.CellSizeCm / 100.f) / 10000.f);
							}
							R += FString::Printf(TEXT("  %d. %s at (%.0f, %.0f) - %s\n"),
								i + 1, FTerrainStructureModel::CandidateWord(C.Kind),
								(TMinX + C.CellX * Grid.CellSizeCm) / 100.f,
								(TMinY + C.CellY * Grid.CellSizeCm) / 100.f, *Line);
						}
					}


			}
			else
			{
				R += TEXT("TERRAIN STRUCTURE: the height grid traced no ground - load the landscape cells first.\n");
			}
		}
	}

	// -- the geometry block: EXACT shapes for offline rendering (this is what turns
	// the checker's numbers into a true picture of the map) --------------------------
	{
		R += TEXT("\n<!-- GEOMETRY (machine-readable, for map rendering)\n");
		R += FString::Printf(TEXT("rivers %d\n"), Rivers.Num());
		for (const TArray<FVector>& Line : Rivers)
		{
			R += FString::Printf(TEXT("river %d\n"), Line.Num());
			for (const FVector& P : Line)
			{
				R += FString::Printf(TEXT("RIVER %.0f %.0f\n"), P.X / 100.f, P.Y / 100.f);
			}
		}
		auto DumpZonePoints = [&R](const TArray<FMapZone>& Zones, const TCHAR* Tag)
		{
			for (int32 i = 0; i < Zones.Num(); ++i)
			{
				R += FString::Printf(TEXT("%s %d"), Tag, i + 1);
				for (const FVector& P : Zones[i].SamplePoints)
				{
					R += FString::Printf(TEXT(" %.0f,%.0f"), P.X / 100.f, P.Y / 100.f);
				}
				R += TEXT("\n");
			}
		};
		DumpZonePoints(TrenchZones, TEXT("TRENCHPTS"));
		DumpZonePoints(BiomeZones, TEXT("BIOMEPTS"));
		auto DumpTerrain = [&R](const TArray<FMapZone>& Zones, const TCHAR* Tag)
		{
			for (int32 i = 0; i < Zones.Num(); ++i)
			{
				R += FString::Printf(TEXT("%s %d %.0f\n"), Tag, i + 1, Zones[i].HeightSpreadCm);
			}
		};
		DumpTerrain(TrenchZones, TEXT("TERRAIN"));
		DumpTerrain(BiomeZones, TEXT("BIOMETERRAIN"));
		{
			double TMinX, TMaxX, TMinY, TMaxY;
			if (FMapLayoutModel::LayoutBounds(TrenchZones, BiomeZones, Rivers, Anchor,
				TMinX, TMaxX, TMinY, TMaxY))
			{
				const FHeightGrid Grid = SquadAILandscape::BuildHeightGridWorld(World, TMinX, TMinY, TMaxX, TMaxY);
				if (Grid.IsValid())
				{
					R += FString::Printf(TEXT("grid %d %d %.0f %.0f %.0f\n"),
						Grid.W, Grid.H, Grid.CellSizeCm / 100.f, Grid.MinZ / 100.f, Grid.MaxZ / 100.f);
					for (const FTerrainHighPoint& P : FTerrainStructureModel::FindHighGround(Grid, 12))
					{
						R += FString::Printf(TEXT("PEAK %.0f %.0f %.0f %.0f\n"),
							(TMinX + P.CellX * Grid.CellSizeCm) / 100.f,
							(TMinY + P.CellY * Grid.CellSizeCm) / 100.f,
							P.RiseCm / 100.f, P.ProminenceCm / 100.f);
					}
					// the FULL height grid (metres, row by row, north row FIRST) - the raw
					// land for offline hillshade/contour rendering
					R += FString::Printf(TEXT("HZGRID %d %d %.0f %.0f %.0f %.0f %.0f\n"),   // S21-TERRAIN
						Grid.W, Grid.H, Grid.CellSizeCm / 100.f,
						TMinX / 100.f, TMinY / 100.f, Grid.MinZ / 100.f, Grid.MaxZ / 100.f);
					for (int32 GY = Grid.H - 1; GY >= 0; --GY)   // north (max Y) first for drawing
					{
						R += TEXT("HZ");
						for (int32 GX = 0; GX < Grid.W; ++GX)
						{
							const FHeightCell& C = Grid.Cells[GY * Grid.W + GX];
							R += C.bValid
								? FString::Printf(TEXT(" %.0f"), C.Z / 100.f)
								: TEXT(" -1");
						}
						R += TEXT("\n");
					}
					// S21-DEEP exports: the landform map, the water, the passes, the
					// basins, the sightlines and the tank country - machine-readable
					// rows mirroring the report's words, for offline map rendering.
					{
						// LF codes (ETerrainLandform): 0 plain | 1 peak | 2 crest |
						// 3 upper slope | 4 lower slope | 5 valley | -1 invalid
						R += FString::Printf(TEXT("LFGRID %d %d %.0f\n"),
							Grid.W, Grid.H, Grid.CellSizeCm / 100.f);
						const float TpiThr = FMath::Max(500.f, (Grid.MaxZ - Grid.MinZ) * 0.02f);
						for (int32 GY = Grid.H - 1; GY >= 0; --GY)   // north row first, like HZ
						{
							R += TEXT("LF");
							for (int32 GX = 0; GX < Grid.W; ++GX)
							{
								const FHeightCell* C = Grid.At(GX, GY);
								R += (C && C->bValid)
									? FString::Printf(TEXT(" %d"),
										FTerrainStructureModel::ClassifyLandform(Grid, GX, GY, 3, TpiThr))
									: TEXT(" -1");
							}
							R += TEXT("\n");
						}
						TArray<int32> Area, Down;
						FTerrainStructureModel::ComputeFlow(Grid, Area, Down);
						TArray<TArray<int32>> Lines;
						FTerrainStructureModel::TraceStreams(Grid, Area, Down,
							FMath::Max(16, Grid.ValidCount / 192), Lines);
						int32 Shown = 0;
						for (const TArray<int32>& Line : Lines)
						{
							if (Line.Num() < 2 || Shown >= 24) { continue; }
							++Shown;
							const int32 Stride = 1 + Line.Num() / 120;   // cap the points per line
							R += FString::Printf(TEXT("STREAM %d"), (Line.Num() + Stride - 1) / Stride);
							for (int32 K = 0; K < Line.Num(); K += Stride)
							{
								R += FString::Printf(TEXT(" %.0f,%.0f"),
									(TMinX + (Line[K] % Grid.W) * Grid.CellSizeCm) / 100.f,
									(TMinY + (Line[K] / Grid.W) * Grid.CellSizeCm) / 100.f);
							}
							R += TEXT("\n");
						}
						for (const FTerrainSaddle& S : FTerrainStructureModel::FindPasses(Grid, 8))
						{
							R += FString::Printf(TEXT("PASS %.0f %.0f %.0f %.0f\n"),
								(TMinX + S.CellX * Grid.CellSizeCm) / 100.f,
								(TMinY + S.CellY * Grid.CellSizeCm) / 100.f,
								S.Z / 100.f, S.ColProminenceCm / 100.f);
						}
						for (const FTerrainDepression& D : FTerrainStructureModel::FindDepressions(Grid, 6))
						{
							R += FString::Printf(TEXT("PIT %.0f %.0f %.0f %.0f\n"),
								(TMinX + D.CellX * Grid.CellSizeCm) / 100.f,
								(TMinY + D.CellY * Grid.CellSizeCm) / 100.f,
								D.Z / 100.f, D.DepthCm / 100.f);
						}
						const TArray<FTerrainHighPoint> Sites = FTerrainStructureModel::FindHighGround(Grid, 8);
						for (int32 i = 0; i < Sites.Num(); ++i)
						{
							for (int32 j = i + 1; j < Sites.Num(); ++j)
							{
								R += FString::Printf(TEXT("LOS %.0f %.0f %.0f %.0f %d\n"),
									(TMinX + Sites[i].CellX * Grid.CellSizeCm) / 100.f,
									(TMinY + Sites[i].CellY * Grid.CellSizeCm) / 100.f,
									(TMinX + Sites[j].CellX * Grid.CellSizeCm) / 100.f,
									(TMinY + Sites[j].CellY * Grid.CellSizeCm) / 100.f,
									FTerrainStructureModel::Sees(Grid, Sites[i].CellX, Sites[i].CellY,
										Sites[j].CellX, Sites[j].CellY, 200.f) ? 1 : 0);
							}
						}
						const FTerrainPatch Tanks = FTerrainStructureModel::LargestFlatPatch(Grid, 0.10f);
						if (Tanks.CellCount > 0)
						{
							const float CellM = Grid.CellSizeCm / 100.f;
							R += FString::Printf(TEXT("TANK %d %.0f %.0f %.0f\n"),
								Tanks.CellCount,
								TMinX / 100.f + Tanks.CentroidX * CellM,
								TMinY / 100.f + Tanks.CentroidY * CellM,
								Tanks.CellCount * CellM * CellM / 10000.f);
						}
						// CAND rank x y kind (0 overwatch | 1 pass | 2 basin | 3 armor) -
						// the land's own proposals, best first
						const TArray<FTerrainCandidate> Cands = FTerrainStructureModel::FindOperationalGround(Grid, 8, 3);
						for (int32 i = 0; i < Cands.Num(); ++i)
						{
							const FTerrainCandidate& C = Cands[i];
							R += FString::Printf(TEXT("CAND %d %.0f %.0f %d\n"), i + 1,
								(TMinX + C.CellX * Grid.CellSizeCm) / 100.f,
								(TMinY + C.CellY * Grid.CellSizeCm) / 100.f, C.Kind);
						}

					}

				}
			}
		}
		auto DumpRoles = [&R](const TArray<FMapZone>& Zones, const TCHAR* Tag)
		{
			for (int32 i = 0; i < Zones.Num(); ++i)
			{
				R += FString::Printf(TEXT("%s %d %s\n"), Tag, i + 1,
					FMapLayoutModel::ZoneRole(Zones[i]));
			}
		};
		DumpRoles(TrenchZones, TEXT("ROLE"));
		DumpRoles(BiomeZones, TEXT("BIOMEROLE"));
		const TArray<TArray<FVector>> Fords = FMapLayoutModel::FindRiverFords(Rivers);
		R += FString::Printf(TEXT("fords %d\n"), Fords.Num());
		for (int32 i = 0; i < Fords.Num(); ++i)
		{
			R += FString::Printf(TEXT("FORDS %d"), i + 1);
			for (const FVector& P : Fords[i])
			{
				R += FString::Printf(TEXT(" %.0f,%.0f"), P.X / 100.f, P.Y / 100.f);
			}
			R += TEXT("\n");
		}
		R += TEXT("-->\n");
	}

	FString SavedPath;
	SquadAILandscape::SaveReportFile(TEXT("LandscapeReport.md"), R, SavedPath);
	R += FString::Printf(TEXT("report saved: %s\n"), *SavedPath);
	UE_LOG(LogTemp, Warning, TEXT("%s"), *R);
	return R;
}

// ============================ S26-VIDEO =====================================
// Shared installer: copy the picked file to Content/Movies/<DestFileName>. The menu
// HUD probes these canonical paths at menu load - no further setup needed. Used by
// the auto-setup manager AND the main menu director actor.
#if WITH_EDITOR
// S26-VIDEOFIX: a CallInEditor button's RETURN VALUE is discarded by the editor
// UI. An install that failed (bad path, locked file) used to be completely
// silent - the level kept the old video and nobody could tell why. Every
// outcome is now an on-screen notification, success or failure.
static void SquadAIVideoNotify(const FString& Msg, bool bFailed, float ExpireSec = 7.f)
{
	FNotificationInfo Info(FText::FromString(Msg));
	Info.bUseSuccessFailIcons = true;
	Info.ExpireDuration = bFailed ? 15.f : ExpireSec;
	Info.bFireAndForget = true;
	if (TSharedPtr<SNotificationItem> Item = FSlateNotificationManager::Get().AddNotification(Info))
	{
		Item->SetCompletionState(bFailed ? SNotificationItem::CS_Fail : SNotificationItem::CS_Success);
	}
}
#else
static void SquadAIVideoNotify(const FString&, bool, float = 7.f) {}
#endif

// S26-VIDEOFIX: true when the named console variable exists and is NOT 1
static bool SquadAICVarIsOff(const TCHAR* Name)
{
	if (IConsoleVariable* CV = IConsoleManager::Get().FindConsoleVariable(Name))
	{
		return (CV->GetInt() != 1);
	}
	return false;
}

FString USquadAIAutoSetupEditorLibrary::InstallMenuVideoFile(const FFilePath& SrcFile,
	const FString& DestFileName, const FString& WhatFor)
{
	const FString Raw = SrcFile.FilePath;
	if (Raw.IsEmpty())
	{
		const FString Msg = TEXT("Failed: pick a video file in the 'Video File' slot first, then press the button again.");
		SquadAIVideoNotify(Msg, true);
		UE_LOG(LogTemp, Error, TEXT("[SquadAI][S26-VIDEOFIX] %s"), *Msg);
		return Msg;
	}
	// S26-VIDEOFIX: FFilePath values can come back RELATIVE. Try the raw path,
	// then project-relative, then the lidar data root - and say WHICH were tried.
	const FString Candidates[3] = {
		Raw,
		FPaths::ConvertRelativePathToFull(FPaths::ProjectDir() / Raw),
		FPaths::ConvertRelativePathToFull(TEXT("C:/lidar_mission/data") / Raw),
	};
	FString Src;
	for (const FString& C : Candidates)
	{
		if (FPaths::FileExists(C)) { Src = C; break; }
	}
	if (Src.IsEmpty())
	{
		const FString Msg = FString::Printf(TEXT("Failed: file not found.\nTried:\n  %s\n  %s\n  %s"),
			*Candidates[0], *Candidates[1], *Candidates[2]);
		SquadAIVideoNotify(Msg, true);
		UE_LOG(LogTemp, Error, TEXT("[SquadAI][S26-VIDEOFIX] %s"), *Msg);
		return Msg;
	}

	const FString Ext = FPaths::GetExtension(Src).ToLower();
	const bool bIsMp4 = (Ext == TEXT("mp4"));
	if (!bIsMp4)
	{
		UE_LOG(LogTemp, Warning,
			TEXT("[SquadAI][S26-VIDEO] %s is not an MP4 - H.264 video + AAC audio in an .mp4 container is the one format every codec path handles. It will be installed, but may not play."),
			*Src);
	}

	const FString DestDir = FPaths::ProjectContentDir() / TEXT("Movies");
	const FString Dest = DestDir / DestFileName;
	IFileManager::Get().MakeDirectory(*DestDir, true);

	// S26-VIDEOFIX: remember what was there, so the report can PROVE replacement
	const int64 OldSize = IFileManager::Get().FileSize(*Dest);

	// Overwrite whatever was installed before (one press = replace), then verify the copy by size.
	int32 CopyRes = IFileManager::Get().Copy(*Dest, *Src, /*bReplace*/ true, /*bEvenIfReadOnly*/ true);
	const int64 SrcSize = IFileManager::Get().FileSize(*Src);
	int64 DstSize = IFileManager::Get().FileSize(*Dest);
	if (CopyRes < 0 || DstSize != SrcSize)
	{
		// S26-VIDEOFIX: the usual cause is the OLD file still held open by a
		// running PIE session (Windows refuses to replace it). Delete, retry.
		IFileManager::Get().Delete(*Dest, /*bRequireExists*/ false, /*bTree*/ false, /*bOverwriteReadOnly*/ true);
		CopyRes = IFileManager::Get().Copy(*Dest, *Src, true, true);
		DstSize = IFileManager::Get().FileSize(*Dest);
	}
	if (SrcSize <= 0 || CopyRes < 0 || DstSize != SrcSize)
	{
		const FString Msg = FString::Printf(
			TEXT("Failed: could not install '%s' to\n%s\n(source %lld bytes, destination %lld bytes).\nIf a PIE session is running, CLOSE IT - it holds the old video file open."),
			*FPaths::GetCleanFilename(Src), *Dest, SrcSize, DstSize);
		SquadAIVideoNotify(Msg, true);
		UE_LOG(LogTemp, Error, TEXT("[SquadAI][S26-VIDEOFIX] %s"), *Msg);
		return Msg;
	}

	// S26-VIDEOFIX: the two things that can still make the OLD intro play after
	// a successful install - an image-sequence folder that outranks the MP4, or
	// the feature cvar switched off. Both are reported, never guessed at.
	FString Notes;
	const FString BaseName = DestFileName.Replace(TEXT(".mp4"), TEXT(""));
	const FString SeqDir = DestDir / (BaseName + TEXT("_Seq"));
	if (IFileManager::Get().DirectoryExists(*SeqDir))
	{
		Notes += FString::Printf(TEXT("\n\nWARNING: %s EXISTS - that image sequence plays INSTEAD of this MP4 (SquadAI.MenuImgSeq prefers it). Delete the folder if you want the MP4, or set SquadAI.MenuImgSeq 0."), *SeqDir);
	}
	if (BaseName == TEXT("MenuIntro") && SquadAICVarIsOff(TEXT("SquadAI.MenuIntro")))
	{
		Notes += TEXT("\n\nWARNING: SquadAI.MenuIntro is 0 - the intro is disabled. Type 'SquadAI.MenuIntro 1' in the console.");
	}
	if (BaseName == TEXT("MenuBackground") && SquadAICVarIsOff(TEXT("SquadAI.MenuVideo")))
	{
		Notes += TEXT("\n\nWARNING: SquadAI.MenuVideo is 0 - the background video is disabled. Type 'SquadAI.MenuVideo 1' in the console.");
	}

	UE_LOG(LogTemp, Log,
		TEXT("[SquadAI][S26-VIDEO] installed %s as %s (%lld bytes, was %lld -> %s). It auto-plays on the next menu open - delete the file to fall back to the built-in art."),
		*FPaths::GetCleanFilename(Src), *WhatFor, DstSize, OldSize, *Dest);

	const FString OldLine = (OldSize >= 0)
		? FString::Printf(TEXT("Replaced the previous file (%lld bytes)."), OldSize)
		: TEXT("No previous file - first install.");
	const FString Msg = FString::Printf(TEXT("Installed '%s' as the %s.\n%s\n%lld bytes -> %s\nPlays on the next menu open (PIE or packaged; not the editor viewport).%s%s"),
		*FPaths::GetCleanFilename(Src), *WhatFor, *OldLine, DstSize, *Dest, *Notes,
		bIsMp4 ? TEXT("") : TEXT("\nNote: not an MP4 - H.264+AAC .mp4 is the safe format; this file may not play."));
	SquadAIVideoNotify(Msg, false, Notes.IsEmpty() ? 7.f : 15.f);
	return Msg;
}

FString USquadAIAutoSetupEditorLibrary::WhatWillTheMenuVideosPlay()
{
	// S26-VIDEOFIX: the diagnostic button. Answers ONE question exactly: the
	// next time the menu opens, what plays - and if the wrong thing, WHY.
	const FString MoviesDir = FPaths::ProjectContentDir() / TEXT("Movies");
	auto IntCVar = [](const TCHAR* Name) -> int32
	{
		IConsoleVariable* CV = IConsoleManager::Get().FindConsoleVariable(Name);
		return CV ? CV->GetInt() : -1;
	};
	auto FileState = [](const FString& Path) -> FString
	{
		if (!IFileManager::Get().FileExists(*Path)) { return TEXT("no file"); }
		return FString::Printf(TEXT("%lld bytes, modified %s"),
			IFileManager::Get().FileSize(*Path),
			*IFileManager::Get().GetTimeStamp(*Path).ToString(TEXT("%Y-%m-%d %H:%M")));
	};
	const int32 IntroOn = IntCVar(TEXT("SquadAI.MenuIntro"));
	const int32 BgOn = IntCVar(TEXT("SquadAI.MenuVideo"));
	const int32 SeqPref = IntCVar(TEXT("SquadAI.MenuImgSeq"));
	const FString IntroMp4 = MoviesDir / TEXT("MenuIntro.mp4");
	const FString IntroSeq = MoviesDir / TEXT("MenuIntro_Seq");
	const FString BgMp4 = MoviesDir / TEXT("MenuBackground.mp4");
	const FString BgSeq = MoviesDir / TEXT("MenuBackground_Seq");

	FString R = TEXT("=== WHAT THE MENU WILL ACTUALLY PLAY ===\n\n[INTRO - fullscreen before the menu]\n");
	if (IntroOn == 0)
	{
		R += TEXT("DISABLED - SquadAI.MenuIntro is 0. Straight to menu.\n");
	}
	else if (SeqPref == 1 && IFileManager::Get().DirectoryExists(*IntroSeq))
	{
		R += FString::Printf(TEXT("The IMAGE SEQUENCE at\n%s\nplays INSTEAD of MenuIntro.mp4.\nTHIS is why replacing the MP4 changed nothing - the _Seq folder outranks it.\nDelete the folder, or set SquadAI.MenuImgSeq 0."), *IntroSeq);
	}
	else if (IFileManager::Get().FileExists(*IntroMp4))
	{
		R += FString::Printf(TEXT("Will play MenuIntro.mp4\n(%s)"), *FileState(IntroMp4));
	}
	else
	{
		R += TEXT("Nothing installed - straight to menu (wipe only).\nPick an MP4 on the manager and press the intro install button.");
	}
	R += FString::Printf(TEXT("\n(MenuIntro.mp4: %s | MenuIntro_Seq: %s | SquadAI.MenuIntro=%d, MenuImgSeq=%d)\n\n"),
		*FileState(IntroMp4), IFileManager::Get().DirectoryExists(*IntroSeq) ? TEXT("EXISTS") : TEXT("no"), IntroOn, SeqPref);

	R += TEXT("[BACKGROUND - looping behind the menu]\n");
	if (BgOn == 0)
	{
		R += TEXT("DISABLED - SquadAI.MenuVideo is 0. Static image.\n");
	}
	else if (SeqPref == 1 && IFileManager::Get().DirectoryExists(*BgSeq))
	{
		R += FString::Printf(TEXT("The IMAGE SEQUENCE at\n%s\nplays INSTEAD of MenuBackground.mp4.\nDelete the folder, or set SquadAI.MenuImgSeq 0."), *BgSeq);
	}
	else if (IFileManager::Get().FileExists(*BgMp4))
	{
		R += FString::Printf(TEXT("Will loop MenuBackground.mp4\n(%s)"), *FileState(BgMp4));
	}
	else
	{
		R += TEXT("Nothing installed - static built-in art.");
	}
	R += FString::Printf(TEXT("\n(MenuBackground.mp4: %s | MenuBackground_Seq: %s | SquadAI.MenuVideo=%d)\n\n"),
		*FileState(BgMp4), IFileManager::Get().DirectoryExists(*BgSeq) ? TEXT("EXISTS") : TEXT("no"), BgOn);

	R += TEXT("Videos play in PIE and packaged games - NOT in the editor viewport.");
	SquadAIVideoNotify(R, false, 25.f);
	UE_LOG(LogTemp, Log, TEXT("[SquadAI][S26-VIDEOFIX] %s"), *R.Replace(TEXT("\n"), TEXT(" | ")));
	return R;
}

#if WITH_EDITOR
// S26-VIDEOFIX: the exec fallbacks. The user asked for "an exec button or
// something" - these work even when the Details panel shows no button (a stale
// DLL, a filtered panel, a Blueprint instance): open the console (~) and type.
static FAutoConsoleCommand GSquadAIWhatWillMenuVideosPlayCmd(
	TEXT("SquadAI.WhatWillMenuVideosPlay"),
	TEXT("Reports exactly what the menu intro/background videos will play next menu open - and why an install did or did not take."),
	FConsoleCommandDelegate::CreateLambda([]()
	{
		USquadAIAutoSetupEditorLibrary::WhatWillTheMenuVideosPlay();
	}));

static FAutoConsoleCommand GSquadAIInstallMenuVideosCmd(
	TEXT("SquadAI.InstallMenuVideos"),
	TEXT("Installs the intro + background menu videos from the file paths picked on the AutoSetupManager (or Menu Director actor) in this level."),
	FConsoleCommandDelegate::CreateLambda([]()
	{
		UWorld* World = GEditor ? GEditor->GetEditorWorldContext().World() : nullptr;
		if (!World)
		{
			SquadAIVideoNotify(TEXT("SquadAI.InstallMenuVideos: no level open - open a level first."), true);
			return;
		}
		// S26-MENUSPLIT: videos are MENU-MAP things - the Menu Director owns them
		for (TActorIterator<ASquadAIMainMenuSetupActor> It(World); It; ++It)
		{
			It->InstallMenuBackgroundVideo();
			It->InstallIntroMovieVideo();
			return;
		}
		SquadAIVideoNotify(TEXT("SquadAI.InstallMenuVideos: no Menu Director actor in this level.\nMenu videos are menu-map things: open the MENU map, place a SquadAI Main Menu Director (the manager has a 1-click button for that), then pick the video path on it - setting the path installs immediately."), true);
	}));
#endif

// S26-REPRESS: is this mission zone one the scatter stamped? Tagged missions are certain;
// the label fallback also catches leftovers from presses made before the tag
// existed (and any renamed-but-recognizable stamp), like the guard-post purge does.
static bool SquadAIIsScatterMission(AMissionZone* Z)
{
	if (!Z) return false;
	if (Z->ActorHasTag(TEXT("SquadAIStampedMission"))) return true;
#if WITH_EDITOR
	const FString L = Z->GetActorLabel();
	if (L.StartsWith(TEXT("HQ - Hold the Line ")) || L.StartsWith(TEXT("Trench Assault "))
		|| L.StartsWith(TEXT("Biome Recon ")) || L.StartsWith(TEXT("River Crossing "))
		|| L.StartsWith(TEXT("Convoy Run ")))
	{
		return true;
	}
#endif
	return false;
}

FString USquadAIAutoSetupEditorLibrary::DeleteScatteredContent(UWorld* World,
	bool bAlsoStampedMissions, bool bRepressWording)
{
	// S26-DELBTN: the standalone teardown. Extracted verbatim from the
	// re-press purge so the delete button and a re-press can never drift
	// apart. Tag-based, never label-based: SquadAIStampedWarWork covers war
	// works and guard posts; SquadAIStampedMission covers the scatter's
	// mission zones plus everything their factory spawned. Untagged,
	// hand-placed content is never touched.
	if (!World)
	{
		return TEXT("");
	}
	const TCHAR* Verb = bRepressWording ? TEXT("replaced") : TEXT("deleted");
	FString R;
	int32 PurgedMissions = 0;
	TArray<AActor*> ToDestroy;
	if (bAlsoStampedMissions)
	{
		// Two phases on purpose: destroying inside the actor iterator shifts the
		// level's actor array (the iterator can skip a zone or read a destroyed
		// slot) - collect first, destroy after the walk is complete.
		for (TActorIterator<AMissionZone> MIt(World); MIt; ++MIt)
		{
			AMissionZone* Z = *MIt;
			if (!SquadAIIsScatterMission(Z)) continue;
			if (AQuestChain* C = Z->OwningChain)
			{
				C->Missions.Remove(Z);
				Z->OwningChain = nullptr;
			}
			ToDestroy.Add(Z);
			for (AActor* A : Z->FactorySpawnedActors)
			{
				if (A) { ToDestroy.Add(A); }   // DestroyActor ignores already-dead actors
			}
			++PurgedMissions;
		}
		for (AActor* A : ToDestroy)
		{
			if (A) { World->DestroyActor(A, false); }
		}
	}
	int32 Purged = 0;
	// S26-LOGIC: tag-based, and collected BEFORE any destroy (the iterator
	// must never walk an array being mutated). Labels are gone as an
	// identity: rename a guard post and it stays yours to keep, and a
	// hand-placed tower or fort is never touched.
	for (TActorIterator<AActor> It(World); It; ++It)
	{
		AActor* A = *It;
		if (A && A->ActorHasTag(TEXT("SquadAIStampedWarWork")))
		{
			ToDestroy.Add(A);
			++Purged;
		}
	}
	for (AActor* A : ToDestroy)
	{
		if (A && IsValid(A)) { World->DestroyActor(A, false); }   // S26-LOGIC: destroy AFTER the walk; IsValid guards the already-destroyed mission pass
	}
	if (Purged > 0 && PurgedMissions > 0)
	{
		R += FString::Printf(TEXT("%s %d war-work/guard piece(s) + %d stamped mission(s)\n"), Verb, Purged, PurgedMissions);
	}
	else if (Purged > 0)
	{
		R += FString::Printf(TEXT("%s %d war-work/guard piece(s)\n"), Verb, Purged);
	}
	else if (PurgedMissions > 0)
	{
		R += FString::Printf(TEXT("%s %d stamped mission(s)\n"), Verb, PurgedMissions);
	}
	else
	{
		R = TEXT("nothing to delete - no SquadAI-stamped content in this level\n");
	}
	UE_LOG(LogTemp, Log, TEXT("[SquadAI] DeleteScatteredContent: %s"), *R);
	return R;
}

FString USquadAIAutoSetupEditorLibrary::AutoScatterMissionsFromLandscape(UWorld* World,
	int32 MissionCount, float MinSeparationCm, bool bDryRun,
	const TArray<FString>& CrateTokens, const TArray<FString>& TreeTokens,
	const TArray<FString>& RiverTokens, bool bAppendToQuestChain,
	double CampaignSpreadKm)
{
	if (!World) return TEXT("ERROR: World is NULL");

	// ---- 1. read the map ------------------------------------------------------
	int32 CrateActors = 0, TreeActors = 0, RiverActors = 0;
	TArray<FVector> CratePoints, TreePoints;
	TArray<TArray<FVector>> Rivers;
	SquadAILandscape::CollectFeaturePoints(World, CrateTokens, CratePoints, CrateActors);
	SquadAILandscape::CollectFeaturePoints(World, TreeTokens, TreePoints, TreeActors);
	SquadAILandscape::CollectRiverPolylines(World, RiverTokens, Rivers, RiverActors);

	TArray<FMapZone> TrenchZones = FMapLayoutModel::ClusterPoints(CratePoints, EMapFeatureKind::Trench);
	TArray<FMapZone> BiomeZones = FMapLayoutModel::ClusterPoints(TreePoints, EMapFeatureKind::Biome);
	SquadAILandscape::ApplyTerrainScan(World, TrenchZones);
	SquadAILandscape::ApplyTerrainScan(World, BiomeZones);

	// ---- 2. the anchor: the player start, else the map's middle -----------------
	FVector Anchor = FVector::ZeroVector;
	{
		double SumX = 0, SumY = 0; int32 N = 0;
		auto Acc = [&](const FVector& P) { SumX += P.X; SumY += P.Y; ++N; };
		for (const FMapZone& Z : TrenchZones) { Acc(Z.Center); }
		for (const FMapZone& Z : BiomeZones)  { Acc(Z.Center); }
		for (const TArray<FVector>& L : Rivers)
		{
			for (const FVector& P : L)    { Acc(P); }
		}
		Anchor = N > 0 ? FVector(SumX / N, SumY / N, 0.f) : FVector::ZeroVector;
		for (TActorIterator<APlayerStart> It(World); It; ++It)
		{
			Anchor = It->GetActorLocation();   // the player start outranks the average
			break;
		}
	}

	// ---- 3. the missions that already exist (the scatter steers around them) -----
	// S26-REPRESS: stamped missions from a previous press are replaced below, so they do
	// NOT steer this press's plan - only hand-placed missions do. This keeps the
	// plan identical between a dry run and the press that follows it.
	TArray<FVector> Existing;
	for (TActorIterator<AMissionZone> It(World); It; ++It)
	{
		if (SquadAIIsScatterMission(*It)) continue;
		Existing.Add(It->GetActorLocation());
	}


	// ---- 4. the plan: ONE campaign across the WHOLE map ---------------------------
	// Mission count 0 = AUTO: the HQ, every trench, every biome, the river - the
	// whole open world becomes the campaign. Then the story pass orders the acts:
	// HQ first, the trench line broken nearest-first, the trees, the open road -
	// and the river crossing is always the finale. The chain plays them in stamp
	// order, so the campaign plays in story order.
	const int32 Count = FMapLayoutModel::PickMissionCount(
		TrenchZones, BiomeZones, FMapLayoutModel::HasWalkableRiver(Rivers), MissionCount);
	const TArray<FMissionSpot> Plan = FMapLayoutModel::BuildStoryPlan(
		TrenchZones, BiomeZones, Rivers, Anchor, Existing, Count, MinSeparationCm,
		CampaignSpreadKm > 0.0 ? CampaignSpreadKm * 100000.0 : 0.0);

	double MinX, MaxX, MinY, MaxY;
	const bool bBounds = FMapLayoutModel::LayoutBounds(
		TrenchZones, BiomeZones, Rivers, Anchor, MinX, MaxX, MinY, MaxY);

	// S21-TERRAIN: the land's structure - guard posts go on DOMINANT ground,
	// never on random flat dirt
	FHeightGrid TerrainGrid;
	TArray<int32> UsedGuardCells;
	int32 TrenchStamped = 0;
	int32 BiomeStamped = 0;
	if (bBounds)
	{
		TerrainGrid = SquadAILandscape::BuildHeightGridWorld(World, MinX, MinY, MaxX, MaxY);
	}

	FString R;
	R += bDryRun
		? TEXT("=== MISSION SCATTER - DRY RUN (nothing stamped) ===\n")
		: TEXT("=== MISSION SCATTER - STAMPING THE CAMPAIGN ===\n");
	R += FString::Printf(TEXT("ONE CAMPAIGN - %d act(s)"), Count);
	if (MissionCount <= 0)
	{
		R += TEXT(" (count 0 = AUTO: the HQ, every trench, every biome, the river)");
	}
	R += TEXT(".\n");
	if (bBounds)
	{
		R += FString::Printf(TEXT("the map is about %.1f x %.1f km and the campaign walks about %.1f km of it.\n"),
			(MaxX - MinX) / 100000.0, (MaxY - MinY) / 100000.0,
			FMapLayoutModel::StoryRouteLengthCm(Plan) / 100000.0);
		if (CampaignSpreadKm > 0.0)
		{
			R += FString::Printf(TEXT("the campaign front: a tight %.1f km around the HQ (raise 'Campaign Spread km' or set 0 for the whole map).\n"),
				CampaignSpreadKm);
		}
	}
	R += FString::Printf(TEXT("read: %d trench zone(s), %d biome zone(s), %d river(s), %d river point(s), %d existing mission(s)\n\n"),
		TrenchZones.Num(), BiomeZones.Num(), Rivers.Num(),
		FMapLayoutModel::RiverPointCount(Rivers), Existing.Num());

	// ---- 5. stamp (or just report) -------------------------------------------------
	int32 Stamped = 0;
	// S23-BRIEF: the legs' measured exposure, computed ONCE - the report's march
	// table and every act's briefing read the same numbers (one truth).
	TArray<FTerrainHighPoint> NetHills;
	TArray<int32> LegPct;
	TArray<float> LegKm;
	if (TerrainGrid.IsValid() && Plan.Num() > 1)
	{
		NetHills = FTerrainStructureModel::FindHighGround(TerrainGrid, 6);
		for (int32 Leg = 1; Leg < Plan.Num(); ++Leg)
		{
			const FVector& A = Plan[Leg - 1].Position;
			const FVector& B = Plan[Leg].Position;
			const int32 AX = FMath::Clamp((int32)((A.X - MinX) / TerrainGrid.CellSizeCm), 0, TerrainGrid.W - 1);
			const int32 AY = FMath::Clamp((int32)((A.Y - MinY) / TerrainGrid.CellSizeCm), 0, TerrainGrid.H - 1);
			const int32 BX = FMath::Clamp((int32)((B.X - MinX) / TerrainGrid.CellSizeCm), 0, TerrainGrid.W - 1);
			const int32 BY = FMath::Clamp((int32)((B.Y - MinY) / TerrainGrid.CellSizeCm), 0, TerrainGrid.H - 1);
			const int32 Steps = FMath::Max(FMath::Max(FMath::Abs(BX - AX), FMath::Abs(BY - AY)), 1);
			int32 Seen = 0;
			int32 Counted = 0;
			for (int32 T2 = 0; T2 <= Steps; ++T2)
			{
				const float F = static_cast<float>(T2) / static_cast<float>(Steps);
				const int32 SX = AX + static_cast<int32>((BX - AX) * F + 0.5f);
				const int32 SY = AY + static_cast<int32>((BY - AY) * F + 0.5f);
				const FHeightCell* C = TerrainGrid.At(SX, SY);
				if (!C || !C->bValid)
				{
					continue;   // no data neither proves nor hides
				}
				++Counted;
				for (const FTerrainHighPoint& H : NetHills)
				{
					if (FTerrainStructureModel::Sees(TerrainGrid, H.CellX, H.CellY, SX, SY))
					{
						++Seen;
						break;
					}
				}
			}
			LegPct.Add(Counted > 0 ? Seen * 100 / Counted : 0);
			LegKm.Add(static_cast<float>(FVector::Dist(A, B) / 100000.0));
		}
	}
	// S25-WARWORKS: ONE PRESS, ONE WAR. A second press REPLACES the manager's
	// stamped pieces - it never stacks a second set on the same ground. The
	// placements are deterministic (same land, same cells), so purge-and-restamp
	// is lossless; without this, every press doubled the bridges, towers, posts.
	if (!bDryRun)
	{
		// S26-DELBTN: the purge lives in its own function now - the manager's
		// "Delete Scattered Content" button runs the exact same teardown a
		// re-press does, so one code path stays honest.
		R += DeleteScatteredContent(World, true, true);
	}
	for (int32 i = 0; i < Plan.Num(); ++i)
	{
		const FMissionSpot& Spot = Plan[i];
		R += FString::Printf(TEXT("%d. %s at (%.0f, %.0f) - %s (%s)\n"),
			i + 1, FMapLayoutModel::SpotKindName(Spot.Kind),
			Spot.Position.X / 100.f, Spot.Position.Y / 100.f, *Spot.StoryLine, *Spot.Reason);

		// S21-DEEP: the dry run reports the placement too - nothing spawns, but
		// the land is already read, so the plan shows exactly where each post
		// would sit (same rule, same order, as the stamping pass)
		if (bDryRun && TerrainGrid.IsValid())
		{
			const int32 GCX = FMath::Clamp((int32)((Spot.Position.X - MinX) / TerrainGrid.CellSizeCm), 0, TerrainGrid.W - 1);
			const int32 GCY = FMath::Clamp((int32)((Spot.Position.Y - MinY) / TerrainGrid.CellSizeCm), 0, TerrainGrid.H - 1);
			const bool bFinale = Spot.Kind == EMissionSpotKind::RiverExtraction;
			FTerrainHighPoint HP;
			if (FTerrainStructureModel::NearestHighPoint(TerrainGrid, GCX, GCY,
				bFinale ? 3 : 4, HP) && !UsedGuardCells.Contains(HP.CellY * 1000 + HP.CellX))
			{
				UsedGuardCells.Add(HP.CellY * 1000 + HP.CellX);
				R += FString::Printf(TEXT("   + guard post PLANNED on the high ground at (%.0f, %.0f), %.0f m over the lowland, %.0f m of prominence\n"),
					(MinX + (HP.CellX + 0.5) * TerrainGrid.CellSizeCm) / 100.f,
					(MinY + (HP.CellY + 0.5) * TerrainGrid.CellSizeCm) / 100.f,
					HP.RiseCm / 100.f, HP.ProminenceCm / 100.f);
				R += FString::Printf(TEXT("GPOST %d %.0f %.0f %.0f %.0f %s\n"),
					i + 1,
					(MinX + (HP.CellX + 0.5) * TerrainGrid.CellSizeCm) / 100.f,
					(MinY + (HP.CellY + 0.5) * TerrainGrid.CellSizeCm) / 100.f,
					HP.RiseCm / 100.f, HP.ProminenceCm / 100.f,
					bFinale ? TEXT("RoadblockCheckpoint") : TEXT("SandbagBunker"));
				}
		}

		if (bDryRun)
		{
			continue;
		}

		// The terrain decides the mission (kind -> template facts).
		UMissionTemplateAsset* T = NewObject<UMissionTemplateAsset>(GetTransientPackage(), NAME_None, RF_Transient);
		// S26-EXFILFIX: never inherit a header default - the factory refuses 'requires
		// extraction' without a pad. The river case re-enables it below.
		T->bRequireExtraction = false;
		FString MissionName;
		FString TitlePlace;   // S21-STORY: the title card's place line
		switch (Spot.Kind)
		{
		case EMissionSpotKind::HQDefend:
			MissionName = FString::Printf(TEXT("HQ - Hold the Line %d"), i + 1);
			TitlePlace = TEXT("the headquarters");
			T->MissionType = EMissionType::Defend;
			T->DefendDuration = 90.f;
			T->bFailIfOverrun = true;
			T->bLoopWaves = true;
			T->TotalWaves = 3; T->EnemiesPerWave = 5;
			T->bDefendedAsset = true;
			T->bSpawnFortification = true;
			break;
		case EMissionSpotKind::TrenchAssault:
			MissionName = FString::Printf(TEXT("Trench Assault %d"), i + 1);
			TitlePlace = TEXT("the trench line");
			T->MissionType = EMissionType::Clear;
			// the ground scales the fight: a 3,369-crate fortress is not a 48-crate bunker
			T->TotalWaves = Spot.ZoneMarkers >= 2000 ? 3 : 2;
			T->EnemiesPerWave = 5;
			T->SabotageTargetCount = 1;
			T->ExplosiveBarrels = Spot.ZoneMarkers >= 2000 ? 3 : 2;
			T->bSpawnFortification = true;
			// S21-VARIETY: take-and-HOLD, then a commander's counterstroke - never
			// the same assault twice in a row
			if (TrenchStamped % 3 == 1)
			{
				T->bCounterattackAfterComplete = true;   // they want their trench back
			}
			else if (TrenchStamped % 3 == 2)
			{
				T->bEliteCommander = true;               // an officer leads the last wave
				T->AssistantsPerCommander = 2;
			}
			++TrenchStamped;
			break;
		case EMissionSpotKind::BiomeRecon:
			MissionName = FString::Printf(TEXT("Biome Recon %d"), i + 1);
			TitlePlace = TEXT("the green zone");
			T->MissionType = EMissionType::Clear;
			// a 20,000-tree deep forest is a longer hunt than a 300-tree grove
			T->TotalWaves = Spot.ZoneMarkers >= 4000 ? 2 : 1;
			T->EnemiesPerWave = 4;
			T->IntelSiteCount = Spot.ZoneMarkers >= 4000 ? 3 : 2;
			T->TimeLimitSeconds = Spot.ZoneMarkers >= 4000 ? 360.f : 300.f;   // against the clock
			// S21-VARIETY: hunt / officer hunt / hold-the-glade - the woods do not
			// hand out the same job twice
			if (BiomeStamped % 3 == 1 && Spot.ZoneMarkers >= 4000)
			{
				T->bEliteCommander = true;
				T->AssistantsPerCommander = 2;
			}
			else if (BiomeStamped % 3 == 2)
			{
				T->CapturePointCount = 1;            // take and hold the glade
				T->CaptureHoldSeconds = 10.f;
				T->SupplyCrateCount = 2;             // and grab what they stored there
			}
			++BiomeStamped;
			break;
		case EMissionSpotKind::RiverExtraction:
			MissionName = FString::Printf(TEXT("River Crossing %d"), i + 1);
			TitlePlace = TEXT("the crossing");
			T->MissionType = EMissionType::Clear;
			T->TotalWaves = 1; T->EnemiesPerWave = 4;
			T->bExtraction = true;
			T->bRequireExtraction = true;
			T->ExtractionHoldSeconds = 30.f;
			T->ExtractionOffsetCm = 1200.f;
			T->bSpawnFortification = true;   // the pad you build at the water
			break;
		default:
			MissionName = FString::Printf(TEXT("Convoy Run %d"), i + 1);
			TitlePlace = TEXT("the open road");
			T->MissionType = EMissionType::Clear;
			T->TotalWaves = 2; T->EnemiesPerWave = 5;
			T->bEscort = true;
			T->EscortRouteLegs = 4;
			T->EscortRouteLegLengthCm = 4000.f;
			T->bFailIfEscortDies = true;
			break;
		}
		T->MissionName = FText::FromString(MissionName);
		T->MissionDescription = FText::FromString(FString::Printf(TEXT("%s %s (%s)"),
			*MissionName, *Spot.StoryLine, *Spot.Reason));
		// S21-STORY: every act announces itself - place, act number, the unit, and
		// the act's words as the briefing. The campaign tells its story in-engine.
		T->TitleCardPlace = FText::FromString(TitlePlace);
		T->TitleCardDate = FText::FromString(FString::Printf(TEXT("Act %d of %d"), i + 1, Count));
		T->TitleCardUnit = FText::FromString(TEXT("Rostami Battalion - Dehlavieh Sector"));
		T->BriefingTitle = FText::FromString(MissionName);
		// S23-BRIEF: the briefing, WRITTEN BY THE LAND - titled sections with
		// the measured facts (landform, watchers, march exposure, the post),
		// not one flat paragraph. The HUD reads the [TAGS] and stages them
		// with the typewriter effect; old flat briefings still display fine.
		{
			FMissionBriefingFacts Facts;
			Facts.ActNumber = i + 1;
			Facts.ActCount = Count;
			Facts.KindWord =
				Spot.Kind == EMissionSpotKind::HQDefend ? TEXT("hq") :
				Spot.Kind == EMissionSpotKind::TrenchAssault ? TEXT("trench") :
				Spot.Kind == EMissionSpotKind::RiverExtraction ? TEXT("river") :
				Spot.Kind == EMissionSpotKind::OpenConvoy ? TEXT("road") : TEXT("forest");
			Facts.ZoneMarkers = Spot.ZoneMarkers;
			Facts.bFinale = Spot.Kind == EMissionSpotKind::RiverExtraction;
			// S23-BRIEF: the act's real objectives, straight off the template it is
			// stamped from - the briefing names THE JOB, not just the kind of ground
			{
				TArray<FString> Parts;
				if (T->TotalWaves > 0 && T->EnemiesPerWave > 0)
				{
					Parts.Add(FString::Printf(TEXT("%d wave%s of %d"),
						T->TotalWaves, T->TotalWaves == 1 ? TEXT("") : TEXT("s"), T->EnemiesPerWave));
				}
				if (T->bEliteCommander)          { Parts.Add(TEXT("an officer leads the last wave")); }
				if (T->bCounterattackAfterComplete) { Parts.Add(TEXT("expect their counterattack")); }
				if (T->SabotageTargetCount > 0)
				{
					Parts.Add(FString::Printf(TEXT("%d demolition target%s"),
						T->SabotageTargetCount, T->SabotageTargetCount == 1 ? TEXT("") : TEXT("s")));
				}
				if (T->IntelSiteCount > 0)
				{
					Parts.Add(FString::Printf(TEXT("%d intel site%s"),
						T->IntelSiteCount, T->IntelSiteCount == 1 ? TEXT("") : TEXT("s")));
				}
				if (T->CapturePointCount > 0)    { Parts.Add(TEXT("a flag to take and hold")); }
				if (T->SupplyCrateCount > 0)
				{
					Parts.Add(FString::Printf(TEXT("%d supply cache%s"),
						T->SupplyCrateCount, T->SupplyCrateCount == 1 ? TEXT("") : TEXT("s")));
				}
				if (T->bExtraction && T->bRequireExtraction) { Parts.Add(TEXT("extract across the water")); }
				if (T->MissionType == EMissionType::Defend)
				{
					Parts.Add(FString::Printf(TEXT("hold %.0f s - the asset must live"), T->DefendDuration));
				}
				if (T->bEscort)                 { Parts.Add(TEXT("the convoy must get through")); }
				if (T->TimeLimitSeconds > 0)
				{
					// S25-BUILD: TimeLimitSeconds is a float - '%' needs ints (C2296)
					const int32 ClockSecs = (int32)(T->TimeLimitSeconds + 0.5f);
					Parts.Add(FString::Printf(TEXT("clock %02d:%02d"),
						ClockSecs / 60, ClockSecs % 60));
				}
				if (Parts.Num() > 0)
				{
					Facts.JobLine = FString::Join(Parts, TEXT(", ")) + TEXT(".");
				}
			}
			// S23-BRIEF: the bearing out of the LAST fight - eight-way compass word,
			// north = +Y (the same convention the layout report's compass sides use)
			if (i >= 1)
			{
				const FVector& From = Plan[i - 1].Position;
				const double Deg = FMath::RadiansToDegrees(FMath::Atan2(
					Spot.Position.X - From.X, Spot.Position.Y - From.Y));
				const int32 Sector = ((int32)FMath::Fmod((float)Deg + 382.5f, 360.f)) / 45;
				static const TCHAR* Words[8] =
				{
					TEXT("north"), TEXT("north-east"), TEXT("east"), TEXT("south-east"),
					TEXT("south"), TEXT("south-west"), TEXT("west"), TEXT("north-west")
				};
				Facts.DepartureWord = Words[Sector & 7];
			}
			if (TerrainGrid.IsValid())
			{
				const int32 FCX = FMath::Clamp((int32)((Spot.Position.X - MinX) / TerrainGrid.CellSizeCm), 0, TerrainGrid.W - 1);
				const int32 FCY = FMath::Clamp((int32)((Spot.Position.Y - MinY) / TerrainGrid.CellSizeCm), 0, TerrainGrid.H - 1);
				const int32 LF = FTerrainStructureModel::ClassifyLandform(TerrainGrid, FCX, FCY, 3,
					FMath::Max(500.f, (TerrainGrid.MaxZ - TerrainGrid.MinZ) * 0.02f));
				Facts.LandformWord =
					LF == ETerrainLandform::Landform_Peak ? TEXT("peak") :
					LF == ETerrainLandform::Landform_Crest ? TEXT("crest") :
					LF == ETerrainLandform::Landform_UpperSlope ? TEXT("upper-slope") :
					LF == ETerrainLandform::Landform_LowerSlope ? TEXT("lower-slope") :
					LF == ETerrainLandform::Landform_Valley ? TEXT("valley-floor") : TEXT("plain");
				for (const FTerrainHighPoint& H : NetHills)
				{
					if (FTerrainStructureModel::Sees(TerrainGrid, H.CellX, H.CellY, FCX, FCY))
					{
						++Facts.Watchers;
					}
				}
				FTerrainHighPoint PostHP;
				if (FTerrainStructureModel::NearestHighPoint(TerrainGrid, FCX, FCY,
					Facts.bFinale ? 3 : 4, PostHP))
				{
					Facts.GuardRiseM = PostHP.RiseCm / 100.f;
				}
			}
			if (i >= 1 && LegPct.IsValidIndex(i - 1))
			{
				Facts.MarchPct = LegPct[i - 1];
				Facts.MarchKm = LegKm[i - 1];
			}
			TArray<FMissionSection> Sections;
			FMissionBriefingModel::BuildBriefing(Facts, Sections);
			T->BriefingText = FText::FromString(
				FMissionBriefingModel::FormatBriefingForCard(Sections));
		}

		FString BuildLog;
		// S26-GROUND: the map's marker actors can sit at any Z (lidar-import height),
		// and a mission stamped there FLOATS. The zone is PLANTED: its Z comes from the
		// same terrain grid the guard posts use - real ground, every act, every prop
		// (they are all placed relative to this origin).
		FVector StampedAt = Spot.Position;
		{
			// S26-GROUND2: grid Z as the fallback, the landscape trace as the truth
			double FallbackZ = StampedAt.Z;
			if (TerrainGrid.IsValid())
			{
				const int32 ZX = FMath::Clamp((int32)((Spot.Position.X - MinX) / TerrainGrid.CellSizeCm), 0, TerrainGrid.W - 1);
				const int32 ZY = FMath::Clamp((int32)((Spot.Position.Y - MinY) / TerrainGrid.CellSizeCm), 0, TerrainGrid.H - 1);
				const FHeightCell& ZCell = TerrainGrid.Cells[ZY * TerrainGrid.W + ZX];
				if (ZCell.bValid)
				{
					FallbackZ = ZCell.Z;
				}
			}
			StampedAt.Z = SquadAILandscape::GroundZAt(World, StampedAt, FallbackZ);
			// S26-LANDING: if BOTH the landscape trace and this exact grid cell
			// failed (map edge, water void), the mission used to keep its
			// authored Z - which can be a kilometre in the sky. Borrow the
			// nearest cell that DOES have data.
			if (TerrainGrid.IsValid() && FMath::IsNearlyEqual(StampedAt.Z, FallbackZ, 0.01)
				&& FMath::IsNearlyEqual(FallbackZ, Spot.Position.Z, 0.01))
			{
				const int32 CX = FMath::Clamp((int32)((Spot.Position.X - MinX) / TerrainGrid.CellSizeCm), 0, TerrainGrid.W - 1);
				const int32 CY = FMath::Clamp((int32)((Spot.Position.Y - MinY) / TerrainGrid.CellSizeCm), 0, TerrainGrid.H - 1);
				for (int32 Ring = 1; Ring <= 8; ++Ring)
				{
					bool bFound = false;
					for (int32 DX = -Ring; DX <= Ring && !bFound; ++DX)
					{
						for (int32 DY = -Ring; DY <= Ring && !bFound; ++DY)
						{
							if (FMath::Abs(DX) != Ring && FMath::Abs(DY) != Ring) { continue; }   // ring edge only
							const int32 NX2 = CX + DX, NY2 = CY + DY;
							if (NX2 < 0 || NY2 < 0 || NX2 >= TerrainGrid.W || NY2 >= TerrainGrid.H) { continue; }
							const FHeightCell& NC = TerrainGrid.Cells[NY2 * TerrainGrid.W + NX2];
							if (NC.bValid)
							{
								StampedAt.Z = NC.Z;
								bFound = true;
							}
						}
					}
					if (bFound) { break; }
				}
			}
		}
		AMissionZone* Zone = BuildMissionFromTemplate_GetZone(World, T, StampedAt,
			FRotator::ZeroRotator, bAppendToQuestChain, &BuildLog);
		if (Zone)
		{
			++Stamped;

			// S26-REPRESS: this mission was stamped by the scatter - the next press replaces it
			// (zone + everything the factory spawned for it + its quest-chain entry).
			// Hand-placed missions carry no tag and are never touched.
			Zone->Tags.AddUnique(FName(TEXT("SquadAIStampedMission")));

#if WITH_EDITOR
			// S26-FOLDER: the outliner says what kind of mission this is
			Zone->SetFolderPath(FName(FString::Printf(TEXT("SquadAI/Missions/%s"),
				T->MissionType == EMissionType::Reach ? TEXT("Reach") :
				T->MissionType == EMissionType::Clear ? TEXT("Clear") : TEXT("Defend"))));
#endif

			// S21-TERRAIN: the guard post is PLANTED ON THE LAND - the dominant
			// ground near the op, nothing random about it
			if (TerrainGrid.IsValid())
			{
				const int32 GCX = FMath::Clamp((int32)((Spot.Position.X - MinX) / TerrainGrid.CellSizeCm), 0, TerrainGrid.W - 1);
				const int32 GCY = FMath::Clamp((int32)((Spot.Position.Y - MinY) / TerrainGrid.CellSizeCm), 0, TerrainGrid.H - 1);
				const bool bFinale = Spot.Kind == EMissionSpotKind::RiverExtraction;
				FTerrainHighPoint HP;
				if (FTerrainStructureModel::NearestHighPoint(TerrainGrid, GCX, GCY,
						bFinale ? 3 : 4, HP))
				{
					const int32 Key = HP.CellY * 1000 + HP.CellX;
					if (!UsedGuardCells.Contains(Key))
					{
						UsedGuardCells.Add(Key);
						const FVector PostPos(
							MinX + (HP.CellX + 0.5) * TerrainGrid.CellSizeCm,
							MinY + (HP.CellY + 0.5) * TerrainGrid.CellSizeCm,
							// S26-GROUND2: the hill's grid Z is the fallback; the
							// landscape itself decides where the post stands
							SquadAILandscape::GroundZAt(World,
								FVector(MinX + (HP.CellX + 0.5) * TerrainGrid.CellSizeCm,
									MinY + (HP.CellY + 0.5) * TerrainGrid.CellSizeCm, 0.f),
								HP.Z) + 40.0);
						if (SquadAILandscape::SpawnGuardPost(World, PostPos,
							bFinale ? EFortificationPreset::RoadblockCheckpoint
								: EFortificationPreset::SandbagBunker,
							FString::Printf(TEXT("SquadAI Guard Post %d"), Stamped)))
						{
							R += FString::Printf(TEXT("   + guard post on the high ground at (%.0f, %.0f), %.0f m over the lowland, %.0f m of prominence\n"),
								PostPos.X / 100.f, PostPos.Y / 100.f, HP.RiseCm / 100.f, HP.ProminenceCm / 100.f);
							R += FString::Printf(TEXT("GPOST %d %.0f %.0f %.0f %.0f %s\n"),
								i + 1, PostPos.X / 100.f, PostPos.Y / 100.f,
								HP.RiseCm / 100.f, HP.ProminenceCm / 100.f,
								bFinale ? TEXT("RoadblockCheckpoint") : TEXT("SandbagBunker"));
						}
					}
				}
			}
		}
		else
		{
			R += TEXT("   !! the factory refused this spot (see its notes above)\n");
		}
	}
	// S22-MARCH: the war map - how much of every march their hills can
	// SEE (the legs were measured once above; the table just prints them).
	if (TerrainGrid.IsValid() && Plan.Num() > 1 && LegPct.Num() == Plan.Num() - 1)
	{
		R += TEXT("\nthe marches - how much of each leg their hills can see:\n");
		for (int32 Leg = 1; Leg < Plan.Num(); ++Leg)
		{
			const int32 Pct = LegPct[Leg - 1];
			R += FString::Printf(TEXT("march %d->%d: %.1f km - %d%% under the net%s\n"),
				Leg, Leg + 1, LegKm[Leg - 1], Pct,
				Pct >= 50 ? TEXT(" - EXPOSED") : (Pct <= 15 ? TEXT(" - covered") : TEXT("")));
		}
	}

	// =====================================================================
	//  S25-WARWORKS: the manager builds the WAR, not just the missions.
	//  Their bridges over the water and ours in the blind spots, their watch
	//  towers on the net hills, our outposts, the armor staging, hulls at the
	//  tank country rim and the hulks of the last push - all derived from the
	//  same land read the missions used, all built from cache meshes with
	//  materials the module creates itself. One press, whole battlefield.
	// =====================================================================
	int32 WWStamped = 0;   // S25-BUILD: the counter the stamp lines below bump (was missing - C2065)
	if (TerrainGrid.IsValid() && Plan.Num() > 0)
	{
		// HQ = the first act's ground; their war aims at the centroid of the rest
		int32 HQX = 0, HQY = 0;
		const auto WorldCell = [&](const FVector& P, int32& CX, int32& CY)
		{
			CX = FMath::Clamp((int32)((P.X - MinX) / TerrainGrid.CellSizeCm), 0, TerrainGrid.W - 1);
			CY = FMath::Clamp((int32)((P.Y - MinY) / TerrainGrid.CellSizeCm), 0, TerrainGrid.H - 1);
		};
		WorldCell(Plan[0].Position, HQX, HQY);
		double SumX = 0.0, SumY = 0.0;
		int32 Spots = 0;
		for (int32 i = 1; i < Plan.Num(); ++i)
		{
			int32 CX = 0, CY = 0;
			WorldCell(Plan[i].Position, CX, CY);
			SumX += CX; SumY += CY; ++Spots;
		}
		const FIntPoint EnemyC(
			Spots > 0 ? (int32)(SumX / Spots + 0.5) : HQX,
			Spots > 0 ? (int32)(SumY / Spots + 0.5) : HQY);

		FWarWorksPlan WW;
		TArray<FTerrainHighPoint> WarHills = NetHills;
		if (WarHills.Num() == 0)
		{
			WarHills = FTerrainStructureModel::FindHighGround(TerrainGrid, 6);   // a one-act map still gets the net
		}
		FWarWorksModel::BuildTowers(TerrainGrid, WarHills, 6, 8, 10, WW);

		// the longest river's cells - the crossings the war is fought over
		const TArray<FVector>* MainRiver = nullptr;
		for (const TArray<FVector>& L : Rivers)
		{
			if (!MainRiver || L.Num() > MainRiver->Num()) { MainRiver = &L; }
		}
		TArray<FIntPoint> RiverCells;
		if (MainRiver)
		{
			for (const FVector& P : *MainRiver)
			{
				int32 CX = 0, CY = 0;
				WorldCell(P, CX, CY);
				const FIntPoint C(CX, CY);
				if (RiverCells.Num() == 0 || RiverCells.Last() != C) { RiverCells.Add(C); }
			}
		}
		if (RiverCells.Num() >= 4)
		{
			// S26-BRIDGE-MATH: a bank is ground 3.5 m above the bed - the flood
			// channel's edge. The old 25 m threshold only matched canyon walls;
			// ordinary river valleys had NO banks at all, and their crossings
			// fell through to the bankless fallback (see the model) or got
			// absurd 25 m-banked spans.
			FWarWorksModel::BuildBridges(TerrainGrid, RiverCells, WW.Towers, 3, 2, 10, 350.f, WW);
		}

		// OUR ground: the hills that stand nearer HQ than their war aim
		TArray<FTerrainHighPoint> OurHills;
		for (const FTerrainHighPoint& H : FTerrainStructureModel::FindHighGround(TerrainGrid, 16))
		{
			const double DHq = FMath::Sqrt((double)(H.CellX - HQX) * (H.CellX - HQX)
				+ (double)(H.CellY - HQY) * (H.CellY - HQY));
			const double DEn = FMath::Sqrt((double)(H.CellX - EnemyC.X) * (H.CellX - EnemyC.X)
				+ (double)(H.CellY - EnemyC.Y) * (H.CellY - EnemyC.Y));
			if (DHq < DEn) { OurHills.Add(H); }
		}
		// S26-TOWERCELL: a tower already holds that hill - our outposts must not be stamped into their camp
		TArray<FTerrainHighPoint> OurFreeHills;
		for (const FTerrainHighPoint& H : OurHills)
		{
			bool bHeldByTower = false;
			for (const FWarWorkPoint& T : WW.Towers)
			{
				if (FMath::Abs(H.CellX - T.CellX) <= 1 && FMath::Abs(H.CellY - T.CellY) <= 1) { bHeldByTower = true; break; }
			}
			if (!bHeldByTower) { OurFreeHills.Add(H); }
		}
		FWarWorksModel::BuildOutposts(OurFreeHills, EnemyC, 3, 8, WW);

		// the armor war on the tank country
		const FTerrainPatch TankPatch = FTerrainStructureModel::LargestFlatPatch(TerrainGrid, 0.10f);
		if (TankPatch.CellCount >= 6)
		{
			FWarWorksModel::BuildArmor(TerrainGrid, TankPatch, EnemyC, 2500.f, WW);
		}

		// ---- the report (dry-run too: the plan is the deliverable there) ----
		R += FString::Printf(TEXT("\nthe war works - the ground both sides fortified before you arrived:\n"));
		const auto WorldOf = [&](const FWarWorkPoint& P)
		{
			return FVector(MinX + (P.CellX + 0.5) * TerrainGrid.CellSizeCm,
				MinY + (P.CellY + 0.5) * TerrainGrid.CellSizeCm, 0.0);
		};
		int32 WWNum = 0;
		const auto ReportWork = [&](const TCHAR* Kind, const FWarWorkPoint& P, const TCHAR* Side)
		{
			const FVector W = WorldOf(P);
			R += FString::Printf(TEXT("   + %s %s at (%.0f, %.0f) facing %.0f%s\n"),
				Side, Kind, W.X / 100.f, W.Y / 100.f, P.FacingYawDeg,
				P.WidthCm > 0.f ? *FString::Printf(TEXT(", %.0f m span"), P.WidthCm / 100.f) : TEXT(""));
			R += FString::Printf(TEXT("WARWORKS %s %.0f %.0f %.0f %.0f %s\n"),
				Kind, W.X / 100.f, W.Y / 100.f, P.FacingYawDeg, P.WidthCm / 100.f, Side);
		};
		for (const FWarWorkPoint& P : WW.Towers) { ReportWork(TEXT("TOWER"), P, TEXT("theirs")); ++WWNum; }
		for (const FWarWorkPoint& P : WW.BridgesTheirs) { ReportWork(TEXT("BRIDGE"), P, TEXT("theirs")); ++WWNum; }
		for (const FWarWorkPoint& P : WW.BridgesOurs) { ReportWork(TEXT("BRIDGE"), P, TEXT("ours")); ++WWNum; }
		for (const FWarWorkPoint& P : WW.Outposts) { ReportWork(TEXT("OUTPOST"), P, TEXT("ours")); ++WWNum; }
		for (const FWarWorkPoint& P : WW.Staging) { ReportWork(TEXT("STAGE"), P, TEXT("ours")); ++WWNum; }
		for (const FWarWorkPoint& P : WW.Hulls) { ReportWork(TEXT("HULL"), P, TEXT("theirs")); ++WWNum; }
		for (const FWarWorkPoint& P : WW.DeadHulks) { ReportWork(TEXT("DEAD"), P, TEXT("theirs")); ++WWNum; }

		// ---- stamp on the land (dry-run only plans) ----
		if (!bDryRun)
		{
			const auto CellZ = [&](const FWarWorkPoint& P)
			{
				return TerrainGrid.Cells[P.CellY * TerrainGrid.W + P.CellX].Z + 50.0;
			};
			// S26-FIXALL: no war work off the map. The model works in grid cells
			// and a hill cell at the data's edge can sit past the playable land.
			// The map's real bounds are MEASURED from the features the read step
			// actually found (trenches, biomes, river points) - clamp every
			// stamp inside them, 25 m from the edge.
			FBox2D MapBounds(ForceInit);
			for (const FMapZone& Z : TrenchZones) { MapBounds += FVector2D(Z.Center); }
			for (const FMapZone& Z : BiomeZones)  { MapBounds += FVector2D(Z.Center); }
			for (const TArray<FVector>& Poly : Rivers)
			{
				for (const FVector& Pt : Poly) { MapBounds += FVector2D(Pt); }
			}
			const auto ClampToMap = [&MapBounds](FVector& W)
			{
				if (!MapBounds.bIsValid) { return; }
				const float Margin = 2500.f;
				// S27-COMPILEFIX: TBox2 has no GetMin()/GetMax() - Min/Max are
				// the public members on every engine version.
				const FVector2D Min = MapBounds.Min + FVector2D(Margin, Margin);
				const FVector2D Max = MapBounds.Max - FVector2D(Margin, Margin);
				if (Min.X < Max.X) { W.X = FMath::Clamp(W.X, Min.X, Max.X); }
				if (Min.Y < Max.Y) { W.Y = FMath::Clamp(W.Y, Min.Y, Max.Y); }
			};
			int32 TNum = 0, BNum = 0, ONum = 0, HNum = 0;
			for (const FWarWorkPoint& P : WW.Towers)
			{
				FVector W = WorldOf(P); ClampToMap(W); W.Z = SquadAILandscape::GroundZAt(World, W, CellZ(P));   // S26-GROUND2 / S26-FIXALL clamp
				if (SquadAILandscape::SpawnWarWork(World, W, P.FacingYawDeg, EWarWorkPreset::WatchTower, 0.f,
					FString::Printf(TEXT("SquadAI Watch Tower %d"), ++TNum))) { ++WWStamped; }
			}
			for (const FWarWorkPoint& P : WW.BridgesTheirs)
			{
				FVector W = WorldOf(P); ClampToMap(W); W.Z = SquadAILandscape::GroundZAt(World, W, CellZ(P));   // S26-GROUND2 / S26-FIXALL clamp
				if (SquadAILandscape::SpawnWarWork(World, W, P.FacingYawDeg, EWarWorkPreset::EnemyBridge, P.WidthCm,
					FString::Printf(TEXT("SquadAI Enemy Bridge %d"), ++BNum))) { ++WWStamped; }
			}
			for (const FWarWorkPoint& P : WW.BridgesOurs)
			{
				FVector W = WorldOf(P); ClampToMap(W); W.Z = SquadAILandscape::GroundZAt(World, W, CellZ(P));   // S26-GROUND2 / S26-FIXALL clamp
				if (SquadAILandscape::SpawnWarWork(World, W, P.FacingYawDeg, EWarWorkPreset::FriendlyBridge, P.WidthCm,
					FString::Printf(TEXT("SquadAI Engineer Bridge %d"), ++BNum))) { ++WWStamped; }
			}
			for (const FWarWorkPoint& P : WW.Outposts)
			{
				FVector W = WorldOf(P); ClampToMap(W); W.Z = SquadAILandscape::GroundZAt(World, W, CellZ(P));   // S26-GROUND2 / S26-FIXALL clamp
				if (SquadAILandscape::SpawnGuardPost(World, W, EFortificationPreset::SandbagBunker,
					FString::Printf(TEXT("SquadAI Outpost %d"), ++ONum), P.FacingYawDeg)) { ++WWStamped; }
			}
			for (const FWarWorkPoint& P : WW.Staging)
			{
				FVector W = WorldOf(P); ClampToMap(W); W.Z = SquadAILandscape::GroundZAt(World, W, CellZ(P));   // S26-GROUND2 / S26-FIXALL clamp
				if (SquadAILandscape::SpawnGuardPost(World, W, EFortificationPreset::SandbagBunker,
					FString::Printf(TEXT("SquadAI Armor Staging %d"), ++HNum), P.FacingYawDeg)) { ++WWStamped; }
			}
			for (const FWarWorkPoint& P : WW.Hulls)
			{
				FVector W = WorldOf(P); ClampToMap(W); W.Z = SquadAILandscape::GroundZAt(World, W, CellZ(P));   // S26-GROUND2 / S26-FIXALL clamp
				if (SquadAILandscape::SpawnWarWork(World, W, P.FacingYawDeg, EWarWorkPreset::TankHull, 0.f,
					FString::Printf(TEXT("SquadAI Tank Hull %d"), ++HNum))) { ++WWStamped; }
			}
			for (const FWarWorkPoint& P : WW.DeadHulks)
			{
				FVector W = WorldOf(P); ClampToMap(W); W.Z = SquadAILandscape::GroundZAt(World, W, CellZ(P));   // S26-GROUND2 / S26-FIXALL clamp
				if (SquadAILandscape::SpawnWarWork(World, W, P.FacingYawDeg, EWarWorkPreset::DeadHull, 0.f,
					FString::Printf(TEXT("SquadAI Dead Hull %d"), ++HNum))) { ++WWStamped; }
			}
			R += FString::Printf(TEXT("   %d war works stamped on the land\n"), WWStamped);
		}
	}

	// S20-WP: the campaign must outlive streaming. The chain brain becomes always-
	// loaded and carries the expected total, so far acts (registered only when the
	// player's cell streams them in) can never end the campaign early.
	for (TActorIterator<AQuestChain> ChainIt(World); ChainIt; ++ChainIt)
	{
		AQuestChain* Chain = *ChainIt;
		if (!Chain)
		{
			continue;
		}
#if WITH_EDITORONLY_DATA
		Chain->SetIsSpatiallyLoaded(false);
#endif
		Chain->ExpectedMissionCount = FMath::Max(Chain->ExpectedMissionCount, Chain->Missions.Num());
	}
	R += FString::Printf(TEXT("\n%d mission(s) stamped; the map of the plan is in MissionScatterMap.svg\n"), Stamped);

	// ---- 6. the map and the report files --------------------------------------------
	const FString Svg = FMapLayoutModel::BuildScatterSVG(TrenchZones, BiomeZones, Rivers,
		Plan, Existing, Anchor, 5000.f, CratePoints, TreePoints);
	FString SvgPath, ReportPath;
	FString Full = R;
	Full += TEXT("\n");
	SquadAILandscape::SaveReportFile(TEXT("MissionScatterMap.svg"), Svg, SvgPath);
	SquadAILandscape::SaveReportFile(TEXT("MissionScatterReport.md"), Full, ReportPath);
	R += FString::Printf(TEXT("map saved: %s\nreport saved: %s\n"), *SvgPath, *ReportPath);
	UE_LOG(LogTemp, Warning, TEXT("%s"), *R);
	return R;
}

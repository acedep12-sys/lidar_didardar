// SquadAIWeaponVisualPreset.cpp — Auto-populates from TPWCS data tables
#include "SquadAIWeaponVisualPreset.h"
#include "Engine/DataTable.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "AssetRegistry/AssetData.h"
#include "UObject/UnrealType.h"
#include "Particles/ParticleSystem.h"
#include "NiagaraSystem.h"
#include "Sound/SoundBase.h"
#include "Animation/AnimMontage.h"

void USquadAIWeaponVisualPreset::LoadAllAssets()
{
	if (!MuzzleFlashCascade.IsNull()) LoadedMuzzleFlash = MuzzleFlashCascade.LoadSynchronous();
	if (!MuzzleFlashNiagara.IsNull()) LoadedMuzzleFlashNS = MuzzleFlashNiagara.LoadSynchronous();
	if (!BulletTrailCascade.IsNull()) LoadedBulletTrail = BulletTrailCascade.LoadSynchronous();
	if (!BulletTrailNiagara.IsNull()) LoadedBulletTrailNS = BulletTrailNiagara.LoadSynchronous();
	if (!BulletImpactCascade.IsNull()) LoadedBulletImpact = BulletImpactCascade.LoadSynchronous();
	if (!FiringMontage.IsNull()) LoadedFiringMontage = FiringMontage.LoadSynchronous();
	if (!ReloadMontage.IsNull()) LoadedReloadMontage = ReloadMontage.LoadSynchronous();
	if (!EquipMontage.IsNull()) LoadedEquipMontage = EquipMontage.LoadSynchronous();
	if (!FireSound.IsNull()) LoadedFireSound = FireSound.LoadSynchronous();
	if (!FireTailSound.IsNull()) LoadedFireTailSound = FireTailSound.LoadSynchronous();
	if (!EmptyClipSound.IsNull()) LoadedEmptyClipSound = EmptyClipSound.LoadSynchronous();
	if (!WeaponSkeletalMesh.IsNull()) LoadedWeaponMesh = WeaponSkeletalMesh.LoadSynchronous();
}

static UDataTable* FindDataTable(const FString& TableName)
{
	const TArray<FString> SearchPaths = {
		FString::Printf(TEXT("/Game/ThirdPersonWeaponCombatSystem/Data/DataTables/%s.%s"), *TableName, *TableName),
		FString::Printf(TEXT("/Game/ThirdPersonMP/Blueprints/DataTables/%s.%s"), *TableName, *TableName),
		FString::Printf(TEXT("/Game/TPWCS/DataTables/%s.%s"), *TableName, *TableName),
		FString::Printf(TEXT("/Game/TPWCS/%s.%s"), *TableName, *TableName),
		FString::Printf(TEXT("/Game/DataTables/%s.%s"), *TableName, *TableName),
	};
	for (const FString& Path : SearchPaths)
	{
		if (UDataTable* DT = Cast<UDataTable>(StaticLoadObject(UDataTable::StaticClass(), nullptr, *Path)))
			return DT;
	}
	FAssetRegistryModule& ARM = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	TArray<FAssetData> Assets;
	ARM.Get().GetAssetsByClass(UDataTable::StaticClass()->GetClassPathName(), Assets);
	for (const FAssetData& A : Assets)
	{
		if (A.AssetName.ToString() == TableName)
			return Cast<UDataTable>(A.GetAsset());
	}
	return nullptr;
}

// Read a soft object property from a struct by name (supports partial/prefix matching for hashed BP names)
static UObject* ReadSoftObj(void* Data, const UScriptStruct* Struct, const FString& PropPrefix)
{
	if (!Data || !Struct) return nullptr;
	for (TFieldIterator<FProperty> It(Struct); It; ++It)
	{
		if (It->GetName().StartsWith(PropPrefix))
		{
			if (FSoftObjectProperty* SP = CastField<FSoftObjectProperty>(*It))
			{
				const FSoftObjectPtr& Ptr = SP->GetPropertyValue_InContainer(Data);
				if (Ptr.IsValid()) return Ptr.Get();
			}
			if (FObjectProperty* OP = CastField<FObjectProperty>(*It))
				return OP->GetObjectPropertyValue_InContainer(Data);
		}
	}
	return nullptr;
}

// Read a nested struct (returns pointer to the struct data within the row)
static void* ReadNestedStruct(void* Data, const UScriptStruct* Struct, const FString& PropPrefix)
{
	if (!Data || !Struct) return nullptr;
	for (TFieldIterator<FProperty> It(Struct); It; ++It)
	{
		if (It->GetName().StartsWith(PropPrefix))
		{
			if (FStructProperty* SP = CastField<FStructProperty>(*It))
				return SP->ContainerPtrToValuePtr<void>(Data);
		}
	}
	return nullptr;
}

// Get the UScriptStruct of a nested struct property
static const UScriptStruct* GetNestedStructType(const UScriptStruct* ParentStruct, const FString& PropPrefix)
{
	if (!ParentStruct) return nullptr;
	for (TFieldIterator<FProperty> It(ParentStruct); It; ++It)
	{
		if (It->GetName().StartsWith(PropPrefix))
		{
			if (FStructProperty* SP = CastField<FStructProperty>(*It))
				return SP->Struct;
		}
	}
	return nullptr;
}

// Read a string/name property (supports prefix matching)
static FString ReadString(void* Data, const UScriptStruct* Struct, const FString& PropPrefix)
{
	if (!Data || !Struct) return TEXT("");
	for (TFieldIterator<FProperty> It(Struct); It; ++It)
	{
		if (It->GetName().StartsWith(PropPrefix))
		{
			if (FStrProperty* SP = CastField<FStrProperty>(*It))
				return SP->GetPropertyValue_InContainer(Data);
			if (FNameProperty* NP = CastField<FNameProperty>(*It))
				return NP->GetPropertyValue_InContainer(Data).ToString();
		}
	}
	return TEXT("");
}

// Known TPWCS montage paths (from DT_WeaponAnims default_UE5 row)
// Maps firingAnimID/reloadingAnimID/equippingAnimID to asset paths
struct FTpwcMontageLookup
{
	static FString GetFiringMontage(const FString& AnimID)
	{
		static TMap<FString, FString> Map = {
			{ TEXT("pistol"), TEXT("/Game/ThirdPersonWeaponCombatSystem/Animations5/AnimMontages/AM_FirePistol_UE5.AM_FirePistol_UE5") },
			{ TEXT("pistolFreeaim"), TEXT("/Game/ThirdPersonWeaponCombatSystem/Animations5/AnimMontages/AM_FirePistolFreeaim_UE5.AM_FirePistolFreeaim_UE5") },
			{ TEXT("rifleHip"), TEXT("/Game/ThirdPersonWeaponCombatSystem/Animations5/AnimMontages/AM_FireRifleHip_UE5.AM_FireRifleHip_UE5") },
			{ TEXT("rifleIronsights"), TEXT("/Game/ThirdPersonWeaponCombatSystem/Animations5/AnimMontages/AM_FireRifleIronsights_UE5.AM_FireRifleIronsights_UE5") },
			{ TEXT("rpg"), TEXT("/Game/ThirdPersonWeaponCombatSystem/Animations5/AnimMontages/AM_FireRPG_UE5.AM_FireRPG_UE5") },
			{ TEXT("shotgun"), TEXT("/Game/ThirdPersonWeaponCombatSystem/Animations5/AnimMontages/AM_FireShotgunHip_UE5.AM_FireShotgunHip_UE5") },
			{ TEXT("shotgunAuto"), TEXT("/Game/ThirdPersonWeaponCombatSystem/Animations5/AnimMontages/AM_FireShotgunAutoHip_UE5.AM_FireShotgunAutoHip_UE5") },
			{ TEXT("thrown"), TEXT("/Game/ThirdPersonWeaponCombatSystem/Animations5/AnimMontages/AM_FireThrown_UE5.AM_FireThrown_UE5") },
		};
		FString* Found = Map.Find(AnimID);
		return Found ? *Found : TEXT("");
	}

	static FString GetReloadMontage(const FString& AnimID)
	{
		static TMap<FString, FString> Map = {
			{ TEXT("pistol"), TEXT("/Game/ThirdPersonWeaponCombatSystem/Animations5/AnimMontages/AM_ReloadPistol_UE5.AM_ReloadPistol_UE5") },
			{ TEXT("rifle"), TEXT("/Game/ThirdPersonWeaponCombatSystem/Animations5/AnimMontages/AM_ReloadRifleIronsights_UE5.AM_ReloadRifleIronsights_UE5") },
			{ TEXT("shotgun"), TEXT("/Game/ThirdPersonWeaponCombatSystem/Animations5/AnimMontages/AM_ReloadShotgunHip_UE5.AM_ReloadShotgunHip_UE5") },
			{ TEXT("shotgunAuto"), TEXT("/Game/ThirdPersonWeaponCombatSystem/Animations5/AnimMontages/AM_ReloadShotgunAutoHip_UE5.AM_ReloadShotgunAutoHip_UE5") },
			{ TEXT("thrown"), TEXT("/Game/ThirdPersonWeaponCombatSystem/Animations5/AnimMontages/AM_ReloadThrown_UE5.AM_ReloadThrown_UE5") },
			{ TEXT("rpg"), TEXT("/Game/ThirdPersonWeaponCombatSystem/Animations5/AnimMontages/AM_ReloadRPG_UE5.AM_ReloadRPG_UE5") },
		};
		FString* Found = Map.Find(AnimID);
		return Found ? *Found : TEXT("");
	}

	static FString GetEquipMontage(const FString& AnimID)
	{
		static TMap<FString, FString> Map = {
			{ TEXT("rifle"), TEXT("/Game/ThirdPersonWeaponCombatSystem/Animations5/AnimMontages/AM_EquipRifle_UE5.AM_EquipRifle_UE5") },
			{ TEXT("thrown"), TEXT("/Game/ThirdPersonWeaponCombatSystem/Animations5/AnimMontages/AM_ReloadThrown_UE5.AM_ReloadThrown_UE5") },
		};
		FString* Found = Map.Find(AnimID);
		return Found ? *Found : TEXT("");
	}
};

void USquadAIWeaponVisualPreset::AutoPopulateFromTPWCS()
{
	if (WeaponID.IsNone())
	{
		UE_LOG(LogTemp, Error, TEXT("[WeaponPreset] WeaponID is not set!"));
		return;
	}

	UE_LOG(LogTemp, Warning, TEXT("[WeaponPreset] Auto-populating '%s' for weapon '%s'..."), *GetName(), *WeaponID.ToString());

	// === DT_Weapons ===
	UDataTable* WeaponsDT = FindDataTable(TEXT("DT_Weapons"));
	if (!WeaponsDT)
	{
		UE_LOG(LogTemp, Error, TEXT("[WeaponPreset] DT_Weapons not found!"));
		return;
	}

	void* WeaponRow = WeaponsDT->FindRowUnchecked(WeaponID);
	if (!WeaponRow)
	{
		UE_LOG(LogTemp, Error, TEXT("[WeaponPreset] Row '%s' not found in DT_Weapons"), *WeaponID.ToString());
		return;
	}

	const UScriptStruct* WeaponStruct = WeaponsDT->GetRowStruct();

	// Debug: dump all top-level property names on the weapon row struct
	{
		FString AllProps;
		for (TFieldIterator<FProperty> It(WeaponStruct); It; ++It)
		{
			AllProps += It->GetName() + TEXT("(") + It->GetClass()->GetName() + TEXT("), ");
		}
		UE_LOG(LogTemp, Warning, TEXT("[WeaponPreset] DT_Weapons struct properties: %s"), *AllProps);
	}

	// Read VFXInfo nested struct (prefix match — UE5 hashes BP property names)
	void* VFXInfo = ReadNestedStruct(WeaponRow, WeaponStruct, TEXT("VFXInfo"));
	if (VFXInfo)
	{
		const UScriptStruct* VFXStruct = GetNestedStructType(WeaponStruct, TEXT("VFXInfo"));

		UObject* MuzzleObj = ReadSoftObj(VFXInfo, VFXStruct, TEXT("muzzleFlashC"));
		if (!MuzzleObj) MuzzleObj = ReadSoftObj(VFXInfo, VFXStruct, TEXT("muzzleFlashN"));
		if (MuzzleObj)
		{
			if (UParticleSystem* PS = Cast<UParticleSystem>(MuzzleObj))
				MuzzleFlashCascade = PS;
			else if (UNiagaraSystem* NS = Cast<UNiagaraSystem>(MuzzleObj))
				MuzzleFlashNiagara = NS;
			UE_LOG(LogTemp, Warning, TEXT("[WeaponPreset]   Muzzle Flash: %s"), *MuzzleObj->GetName());
		}

		UObject* TrailObj = ReadSoftObj(VFXInfo, VFXStruct, TEXT("bulletTrailC"));
		if (!TrailObj) TrailObj = ReadSoftObj(VFXInfo, VFXStruct, TEXT("bulletTrailN"));
		if (TrailObj)
		{
			if (UParticleSystem* PS = Cast<UParticleSystem>(TrailObj))
				BulletTrailCascade = PS;
			else if (UNiagaraSystem* NS = Cast<UNiagaraSystem>(TrailObj))
				BulletTrailNiagara = NS;
			UE_LOG(LogTemp, Warning, TEXT("[WeaponPreset]   Bullet Trail: %s"), *TrailObj->GetName());
		}
	}

	// Read soundsInfo
	void* SoundsInfo = ReadNestedStruct(WeaponRow, WeaponStruct, TEXT("soundsInfo"));
	if (SoundsInfo)
	{
		const UScriptStruct* SoundStruct = GetNestedStructType(WeaponStruct, TEXT("soundsInfo"));
		UObject* FireSnd = ReadSoftObj(SoundsInfo, SoundStruct, TEXT("fireSound"));
		if (FireSnd)
		{
			FireSound = Cast<USoundBase>(FireSnd);
			UE_LOG(LogTemp, Warning, TEXT("[WeaponPreset]   Fire Sound: %s"), *FireSnd->GetName());
		}
	}

	// Read baseInfo for weapon mesh
	void* BaseInfo = ReadNestedStruct(WeaponRow, WeaponStruct, TEXT("baseInfo"));
	if (BaseInfo)
	{
		const UScriptStruct* BaseStruct = GetNestedStructType(WeaponStruct, TEXT("baseInfo"));
		UObject* MeshObj = ReadSoftObj(BaseInfo, BaseStruct, TEXT("weaponMesh"));
		if (MeshObj)
		{
			WeaponSkeletalMesh = Cast<USkeletalMesh>(MeshObj);
			UE_LOG(LogTemp, Warning, TEXT("[WeaponPreset]   Weapon Mesh: %s"), *MeshObj->GetName());
		}
	}

	// Read animationInfo for montage IDs (prefix match handles hashed names)
	void* AnimInfo = ReadNestedStruct(WeaponRow, WeaponStruct, TEXT("animationInfo"));
	FString FiringAnimID, ReloadAnimID, EquipAnimID;
	if (AnimInfo)
	{
		const UScriptStruct* AnimStruct = GetNestedStructType(WeaponStruct, TEXT("animationInfo"));

		// Debug: dump animationInfo properties
		{
			FString AnimProps;
			for (TFieldIterator<FProperty> It(AnimStruct); It; ++It)
				AnimProps += It->GetName() + TEXT(", ");
			UE_LOG(LogTemp, Warning, TEXT("[WeaponPreset] animationInfo properties: %s"), *AnimProps);
		}

		FiringAnimID = ReadString(AnimInfo, AnimStruct, TEXT("firingAnimID"));
		ReloadAnimID = ReadString(AnimInfo, AnimStruct, TEXT("reloadingAnimID"));
		EquipAnimID = ReadString(AnimInfo, AnimStruct, TEXT("equippingAnimID"));

		UE_LOG(LogTemp, Warning, TEXT("[WeaponPreset]   AnimIDs: firing='%s' reload='%s' equip='%s'"), *FiringAnimID, *ReloadAnimID, *EquipAnimID);
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("[WeaponPreset] animationInfo struct NOT FOUND"));
	}

	// === Resolve montages from known paths ===
	if (!FiringAnimID.IsEmpty())
	{
		FString MontagePath = FTpwcMontageLookup::GetFiringMontage(FiringAnimID);
		if (!MontagePath.IsEmpty())
		{
			UAnimMontage* M = Cast<UAnimMontage>(StaticLoadObject(UAnimMontage::StaticClass(), nullptr, *MontagePath));
			if (M)
			{
				FiringMontage = M;
				UE_LOG(LogTemp, Warning, TEXT("[WeaponPreset]   Firing Montage: %s"), *M->GetName());
			}
		}
	}
	if (!ReloadAnimID.IsEmpty())
	{
		FString MontagePath = FTpwcMontageLookup::GetReloadMontage(ReloadAnimID);
		if (!MontagePath.IsEmpty())
		{
			UAnimMontage* M = Cast<UAnimMontage>(StaticLoadObject(UAnimMontage::StaticClass(), nullptr, *MontagePath));
			if (M)
			{
				ReloadMontage = M;
				UE_LOG(LogTemp, Warning, TEXT("[WeaponPreset]   Reload Montage: %s"), *M->GetName());
			}
		}
	}
	if (!EquipAnimID.IsEmpty())
	{
		FString MontagePath = FTpwcMontageLookup::GetEquipMontage(EquipAnimID);
		if (!MontagePath.IsEmpty())
		{
			UAnimMontage* M = Cast<UAnimMontage>(StaticLoadObject(UAnimMontage::StaticClass(), nullptr, *MontagePath));
			if (M)
			{
				EquipMontage = M;
				UE_LOG(LogTemp, Warning, TEXT("[WeaponPreset]   Equip Montage: %s"), *M->GetName());
			}
		}
	}

	MarkPackageDirty();
	UE_LOG(LogTemp, Warning, TEXT("[WeaponPreset] Auto-populate complete for '%s'"), *WeaponID.ToString());
}

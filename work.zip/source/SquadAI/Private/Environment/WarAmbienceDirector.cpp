// WarAmbienceDirector.cpp — S17-EVNT
#include "Environment/WarAmbienceDirector.h"
#include "Tactical/TacticalMortarBarrageActor.h"
#include "Tactical/SquadAIRadioChatterSubsystem.h"
#include "Performance/SquadAIAudioSubsystem.h"
#include "Actors/SquadAIAudioManager.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/World.h"
#include "GameFramework/Pawn.h"
#include "TimerManager.h"

AWarAmbienceDirector::AWarAmbienceDirector()
{
	PrimaryActorTick.bCanEverTick = false;
}

void AWarAmbienceDirector::BeginPlay()
{
	Super::BeginPlay();
	if (bEnabled)
	{
		ScheduleNextEvent();
	}
}

void AWarAmbienceDirector::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (GetWorld())
	{
		GetWorld()->GetTimerManager().ClearTimer(EventTimerHandle);
		GetWorld()->GetTimerManager().ClearTimer(GunBurstHandle);
	}
	Super::EndPlay(EndPlayReason);
}

void AWarAmbienceDirector::ScheduleNextEvent()
{
	if (!GetWorld()) return;
	const float Delay = FMath::FRandRange(MinEventInterval, FMath::Max(MinEventInterval + 1.f, MaxEventInterval));
	GetWorld()->GetTimerManager().SetTimer(EventTimerHandle,
		FTimerDelegate::CreateUObject(this, &AWarAmbienceDirector::FireRandomEvent),
		Delay, false);
}

FVector AWarAmbienceDirector::RandomPointNearPlayer(float MinDist, float MaxDist) const
{
	const APawn* Player = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	const FVector Base = Player ? Player->GetActorLocation() : GetActorLocation();
	const float Angle = FMath::FRandRange(0.f, 2.f * PI);
	const float Dist = FMath::FRandRange(MinDist, FMath::Max(MinDist + 100.f, MaxDist));
	return Base + FVector(FMath::Cos(Angle) * Dist, FMath::Sin(Angle) * Dist, 0.f);
}

void AWarAmbienceDirector::FireRandomEvent()
{
	if (!bEnabled || !GetWorld()) return;
	if (!UGameplayStatics::GetPlayerPawn(GetWorld(), 0))
	{
		ScheduleNextEvent();
		return;
	}

	// Weighted pick among the enabled events.
	struct FEventEntry { int32 Weight; int32 Id; };
	TArray<FEventEntry, TInlineAllocator<4>> Pool;
	if (bDistantShellfire)   Pool.Add({4, 0});
	if (bDistantGunfire)     Pool.Add({3, 1});
	if (bRadioChatterBursts) Pool.Add({3, 2});
	if (bHarassmentBarrages) Pool.Add({2, 3});
	if (Pool.Num() == 0)
	{
		ScheduleNextEvent();
		return;
	}
	int32 TotalWeight = 0;
	for (const FEventEntry& E : Pool) TotalWeight += E.Weight;
	int32 Roll = FMath::RandRange(1, TotalWeight);
	int32 Picked = Pool[0].Id;
	for (const FEventEntry& E : Pool)
	{
		Roll -= E.Weight;
		if (Roll <= 0) { Picked = E.Id; break; }
	}

	switch (Picked)
	{
	case 0: EventDistantShellfire(); break;
	case 1: EventDistantGunfire(); break;
	case 2: EventRadioChatter(); break;
	case 3: EventHarassmentBarrage(); break;
	default: break;
	}

	ScheduleNextEvent();
}

void AWarAmbienceDirector::EventDistantShellfire()
{
	USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this);
	ASquadAIAudioManager* Mgr = AudioSys ? AudioSys->GetActiveAudioManager() : nullptr;
	if (!Mgr) return;
	const FVector Loc = RandomPointNearPlayer(DistantSoundRangeMin, DistantSoundRangeMax);

	USoundBase* Boom = (FMath::RandBool() ? Mgr->LargeExplosionDistantSound.Get() : Mgr->MediumExplosionDistantSound.Get());
	if (!Boom) Boom = Mgr->DistantArtilleryRumble.Get();
	if (Boom)
	{
		UGameplayStatics::PlaySoundAtLocation(GetWorld(), Boom, Loc);
	}
	if (Mgr->DistantArtilleryRumble && FMath::RandBool())
	{
		UGameplayStatics::PlaySoundAtLocation(GetWorld(), Mgr->DistantArtilleryRumble.Get(), Loc, 0.8f);
	}
	UE_LOG(LogTemp, Verbose, TEXT("[WarAmbience] Distant shellfire echo."));
}

void AWarAmbienceDirector::EventDistantGunfire()
{
	GunBurstShotsLeft = FMath::RandRange(3, 6);
	GunBurstLocation = RandomPointNearPlayer(DistantSoundRangeMin, DistantSoundRangeMax);
	PlayGunBurstShot();
}

void AWarAmbienceDirector::PlayGunBurstShot()
{
	if (GunBurstShotsLeft <= 0 || !GetWorld()) return;
	GunBurstShotsLeft--;

	USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this);
	ASquadAIAudioManager* Mgr = AudioSys ? AudioSys->GetActiveAudioManager() : nullptr;
	if (Mgr && Mgr->DefaultGunshotDistantSound)
	{
		// Slight drift so the "exchange" wanders like a real firefight.
		GunBurstLocation += FVector(FMath::FRandRange(-300.f, 300.f), FMath::FRandRange(-300.f, 300.f), 0.f);
		UGameplayStatics::PlaySoundAtLocation(GetWorld(), Mgr->DefaultGunshotDistantSound.Get(), GunBurstLocation,
			FMath::FRandRange(0.7f, 1.0f), FMath::FRandRange(0.92f, 1.08f));
	}
	if (GunBurstShotsLeft > 0)
	{
		GetWorld()->GetTimerManager().SetTimer(GunBurstHandle,
			FTimerDelegate::CreateUObject(this, &AWarAmbienceDirector::PlayGunBurstShot),
			FMath::FRandRange(0.25f, 0.9f), false);
	}
}

void AWarAmbienceDirector::EventRadioChatter()
{
	USquadAIRadioChatterSubsystem* Radio = USquadAIRadioChatterSubsystem::Get(this);
	if (!Radio) return;
	// Khuzestan river call signs — thematic squad net idents.
	static const TCHAR* CallSigns[] = { TEXT("کرخه"), TEXT("کارون"), TEXT("دز"), TEXT("اروند") };
	static const ETacticalRadioContext Contexts[] = {
		ETacticalRadioContext::SpotHostile,
		ETacticalRadioContext::SuppressingFire,
		ETacticalRadioContext::FlankingManeuver,
		ETacticalRadioContext::MortarInbound };
	const FString CallSign = CallSigns[FMath::RandRange(0, 3)];
	Radio->BroadcastRadioChatter(CallSign, Contexts[FMath::RandRange(0, 3)]);
	UE_LOG(LogTemp, Verbose, TEXT("[WarAmbience] Radio chatter burst (%s)."), *CallSign);
}

void AWarAmbienceDirector::EventHarassmentBarrage()
{
	UWorld* World = GetWorld();
	if (!World) return;
	const FVector Center = RandomPointNearPlayer(HarassMinDistance, HarassMaxDistance);

	FActorSpawnParameters SpawnParams;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	if (ATacticalMortarBarrageActor* Barrage = World->SpawnActor<ATacticalMortarBarrageActor>(
		ATacticalMortarBarrageActor::StaticClass(), Center, FRotator::ZeroRotator, SpawnParams))
	{
		Barrage->ShellCount = HarassShellCount;
		Barrage->ShellDamage = HarassShellDamage;
		Barrage->StartBarrage(Center); // whistle + HUD danger ring built in
		UE_LOG(LogTemp, Warning, TEXT("[WarAmbience] Harassment salvo (%d shells) landing %s"), HarassShellCount, *Center.ToString());
	}
}

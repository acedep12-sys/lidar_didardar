// BridgeSplineActor.cpp — S17-BRDG: spline-driven bridge builder.
#include "Environment/BridgeSplineActor.h"
#include "Components/SplineComponent.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h"
#include "Materials/MaterialInterface.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Engine/World.h"
#include "Engine/StaticMesh.h"
#include "CollisionQueryParams.h"

ABridgeSplineActor::ABridgeSplineActor()
{
	PrimaryActorTick.bCanEverTick = false;

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SetRootComponent(SceneRoot);

	BridgeSpline = CreateDefaultSubobject<USplineComponent>(TEXT("BridgeSpline"));
	BridgeSpline->SetupAttachment(SceneRoot);
	// Default: a straight 20 m span — stretch the second point to the far bank.
	BridgeSpline->SetLocationAtSplinePoint(1, FVector(2000.f, 0.f, 0.f), ESplineCoordinateSpace::Local, true);

	HISM_Deck = MakeHISM(TEXT("HISM_Deck"), /*bWalkable=*/true);
	HISM_Rail = MakeHISM(TEXT("HISM_Rail"), /*bWalkable=*/false);
	HISM_Pier = MakeHISM(TEXT("HISM_Pier"), /*bWalkable=*/false);
}

UHierarchicalInstancedStaticMeshComponent* ABridgeSplineActor::MakeHISM(const TCHAR* Name, bool bWalkable)
{
	UHierarchicalInstancedStaticMeshComponent* H = CreateDefaultSubobject<UHierarchicalInstancedStaticMeshComponent>(Name);
	H->SetupAttachment(SceneRoot);
	H->SetMobility(EComponentMobility::Static);
	H->SetCollisionProfileName(TEXT("BlockAll"));
	// Deck must carry the navmesh so AI (squad, enemies) can cross the river;
	// rails/piers block movement/bullets but must not carve walkable area.
	H->SetCanEverAffectNavigation(bWalkable);
	return H;
}

void ABridgeSplineActor::ConfigureHISM(UHierarchicalInstancedStaticMeshComponent* HISM, UStaticMesh* Mesh,
	UMaterialInterface* Mat, const FLinearColor& Tint) const
{
	if (!HISM) return;
	HISM->ClearInstances();
	if (HISM->GetStaticMesh() != Mesh)
	{
		HISM->SetStaticMesh(Mesh);
	}
	if (Mat)
	{
		HISM->SetMaterial(0, Mat); // authored PBR shown as-is
	}
	else if (HISM->GetMaterial(0))
	{
		// One shared DMI per HISM (never per instance) — S8-MAT scheme.
		if (UMaterialInstanceDynamic* Dyn = HISM->CreateAndSetMaterialInstanceDynamic(0))
		{
			Dyn->SetVectorParameterValue(TEXT("Color"), Tint);
		}
	}
}

void ABridgeSplineActor::OnConstruction(const FTransform& Transform)
{
	Super::OnConstruction(Transform);
#if WITH_EDITOR
	// S17-TRPERF: debounce — dragging a spline handle fires OnConstruction on
	// every mouse move; rebuilding the whole bridge each time stalls the
	// editor. In editor worlds, rebuild once 0.45s after the LAST change.
	if (GetWorld() && !GetWorld()->IsGameWorld())
	{
		LastSplineEditTime = FPlatformTime::Seconds();
		if (!bDebounceRebuildPending)
		{
			bDebounceRebuildPending = true;
			TWeakObjectPtr<ABridgeSplineActor> WeakThis(this);
			DebounceTickerHandle = FTSTicker::GetCoreTicker().AddTicker(FTickerDelegate::CreateLambda([WeakThis](float) -> bool
			{
				ABridgeSplineActor* Self = WeakThis.Get();
				if (!Self || !IsValid(Self)) return false;
				if (FPlatformTime::Seconds() - Self->LastSplineEditTime < 0.45) return true;
				Self->bDebounceRebuildPending = false;
				if (Self->GetWorld() && !Self->GetWorld()->IsGameWorld())
				{
					Self->RebuildBridge();
				}
				return false;
			}), 0.1f);
		}
		return;
	}
#endif
	RebuildBridge();
}

#if WITH_EDITOR
void ABridgeSplineActor::BeginDestroy()
{
	if (DebounceTickerHandle.IsValid())
	{
		FTSTicker::GetCoreTicker().RemoveTicker(DebounceTickerHandle);
		DebounceTickerHandle.Reset();
	}
	Super::BeginDestroy();
}
#endif

void ABridgeSplineActor::RebuildBridge()
{
	if (!BridgeSpline) return;

	UStaticMesh* Cube = LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cube.Cube"));
	UStaticMesh* Cyl = LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cylinder.Cylinder"));
	if (!Cube || !Cyl) return;

	ConfigureHISM(HISM_Deck, Cube, DeckMaterial, DeckTint);
	ConfigureHISM(HISM_Rail, Cube, RailMaterial, RailTint);
	ConfigureHISM(HISM_Pier, Cyl, PierMaterial, PierTint);

	const float Len = BridgeSpline->GetSplineLength();
	if (Len < 100.f) return;

	FRandomStream Stream(Seed);
	const float Step = FMath::Max(20.f, PlankLength + PlankGap);
	const float HalfW = DeckWidth * 0.5f;

	// ===== 1. PLANK DECK (each plank laid ACROSS the walking direction) =====
	for (float D = Step * 0.5f; D < Len; D += Step)
	{
		const FVector P = BridgeSpline->GetLocationAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);
		FRotator R = BridgeSpline->GetRotationAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);
		R.Yaw += Stream.FRandRange(-1.6f, 1.6f) * Roughness;
		R.Roll += Stream.FRandRange(-0.8f, 0.8f) * Roughness;
		const FVector Pos = P + FVector(0.f, 0.f, Stream.FRandRange(-1.2f, 1.2f) * Roughness);
		HISM_Deck->AddInstance(FTransform(R, Pos,
			FVector(PlankLength / 100.f, DeckWidth / 100.f, PlankThickness / 100.f)), true);
	}

	// ===== 2. LONGITUDINAL STRINGERS (two beams under the planks) =====
	const float StringerStep = 300.f;
	for (float D = 0.f; D < Len; D += StringerStep)
	{
		const float DEnd = FMath::Min(D + StringerStep, Len);
		const FVector A = BridgeSpline->GetLocationAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);
		const FVector B = BridgeSpline->GetLocationAtDistanceAlongSpline(DEnd, ESplineCoordinateSpace::World);
		const FVector Mid = (A + B) * 0.5f;
		const FVector Dir = (B - A).GetSafeNormal();
		if (Dir.IsNearlyZero()) continue;
		const FRotator SegRot = Dir.Rotation();
		const FVector Right = SegRot.RotateVector(FVector::RightVector);
		const float SegLen = FVector::Dist(A, B);
		for (int32 Side = -1; Side <= 1; Side += 2)
		{
			const FVector BeamPos = Mid + Right * (Side * (HalfW - 30.f)) - FVector(0.f, 0.f, PlankThickness * 0.5f + 10.f);
			HISM_Rail->AddInstance(FTransform(SegRot, BeamPos, FVector(SegLen / 100.f + 0.06f, 0.18f, 0.20f)), true);
		}
	}

	// ===== 3. RAILS (posts + top/mid beams on both edges) =====
	if (bBuildRails)
	{
		const int32 NumPosts = FMath::Max(2, FMath::RoundToInt(Len / RailPostSpacing) + 1);
		TArray<FVector> PostTopL, PostTopR;
		for (int32 i = 0; i < NumPosts; i++)
		{
			const float D = (Len * i) / (NumPosts - 1);
			const FVector P = BridgeSpline->GetLocationAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);
			const FRotator R = BridgeSpline->GetRotationAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);
			const FVector Right = R.RotateVector(FVector::RightVector);
			for (int32 Side = -1; Side <= 1; Side += 2)
			{
				const FVector Base = P + Right * (Side * (HalfW - 8.f));
				const FRotator PostRot(0.f, R.Yaw + Stream.FRandRange(-2.f, 2.f) * Roughness, 0.f);
				HISM_Rail->AddInstance(FTransform(PostRot, Base + FVector(0.f, 0.f, RailHeight * 0.5f),
					FVector(0.09f, 0.09f, RailHeight / 100.f)), true);
				(Side < 0 ? PostTopL : PostTopR).Add(Base + FVector(0.f, 0.f, RailHeight));
			}
		}
		auto AddRailRun = [&](const TArray<FVector>& Tops, float ZOffset)
		{
			for (int32 i = 0; i + 1 < Tops.Num(); i++)
			{
				const FVector A = Tops[i] + FVector(0.f, 0.f, ZOffset);
				const FVector B = Tops[i + 1] + FVector(0.f, 0.f, ZOffset);
				const FVector Dir = (B - A).GetSafeNormal();
				if (Dir.IsNearlyZero()) continue;
				HISM_Rail->AddInstance(FTransform(Dir.Rotation(), (A + B) * 0.5f,
					FVector(FVector::Dist(A, B) / 100.f + 0.04f, 0.07f, 0.07f)), true);
			}
		};
		AddRailRun(PostTopL, -3.f);
		AddRailRun(PostTopR, -3.f);
		if (bMidRail)
		{
			AddRailRun(PostTopL, -RailHeight * 0.5f);
			AddRailRun(PostTopR, -RailHeight * 0.5f);
		}
	}

	// ===== 4. PIERS (legs traced down to the riverbed + cross braces) =====
	if (bBuildPiers)
	{
		UWorld* World = GetWorld();
		FCollisionQueryParams TraceParams(SCENE_QUERY_STAT(BridgePierTrace), false, this);
		const int32 NumPiers = FMath::Max(2, FMath::RoundToInt(Len / PierSpacing) + 1);
		for (int32 i = 0; i < NumPiers; i++)
		{
			const float D = (Len * i) / (NumPiers - 1);
			const FVector P = BridgeSpline->GetLocationAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);
			const FRotator R = BridgeSpline->GetRotationAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);
			const FVector Right = R.RotateVector(FVector::RightVector);
			for (int32 s = 0; s < 2; s++)
			{
				const int32 Side = (s == 0) ? -1 : 1;
				const FVector Top = P + Right * (Side * (HalfW - 35.f)) - FVector(0.f, 0.f, PlankThickness * 0.5f);
				float LegLen = FixedPierLength;
				if (bTraceForRiverbed && World)
				{
					FHitResult Hit;
					if (World->LineTraceSingleByChannel(Hit, Top, Top - FVector(0.f, 0.f, PierTraceDepth), ECC_Visibility, TraceParams))
					{
						LegLen = FMath::Max(60.f, (Top.Z - Hit.ImpactPoint.Z) + 40.f); // sink into the bed
					}
				}
				HISM_Pier->AddInstance(FTransform(FRotator::ZeroRotator, Top - FVector(0.f, 0.f, LegLen * 0.5f),
					FVector(0.24f, 0.24f, LegLen / 100.f)), true);
			}
			// Horizontal cross brace between the two legs, just under the deck.
			const FVector BraceA = P - Right * (HalfW - 35.f) - FVector(0.f, 0.f, PlankThickness * 0.5f + 35.f);
			const FVector BraceB = P + Right * (HalfW - 35.f) - FVector(0.f, 0.f, PlankThickness * 0.5f + 35.f);
			const FVector BraceDir = (BraceB - BraceA).GetSafeNormal();
			if (!BraceDir.IsNearlyZero())
			{
				HISM_Rail->AddInstance(FTransform(BraceDir.Rotation(), (BraceA + BraceB) * 0.5f,
					FVector(FVector::Dist(BraceA, BraceB) / 100.f, 0.10f, 0.10f)), true);
			}
		}
	}
}

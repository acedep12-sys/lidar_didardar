// TrenchDetailSplineActor.cpp — S15-TRENCH: procedural trench-line dressing
#include "Environment/TrenchDetailSplineActor.h"
#include "Components/SplineComponent.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h"
#include "Materials/MaterialInterface.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Performance/SquadAIAssetCacheSubsystem.h"
#include "Engine/World.h"
#include "Engine/StaticMesh.h"
#include "Misc/PackageName.h" // S17-TRAUTO

namespace
{
	// S19-TREDGE: one node of a stake-to-stake wire run. Declared at file scope
	// so TArray<> sees a non-local type.
	struct FSquadAIWireNode
	{
		FVector P = FVector::ZeroVector;   // X/Y only; Z is rebuilt per strand
		float    GroundZ = 0.f;
		float    H = 0.f;                  // stake-top height above that ground
	};

	// One shared DMI per HISM (never per instance) — mirrors the village S8-MAT scheme.
	void TrenchTint(UHierarchicalInstancedStaticMeshComponent* Comp, const FLinearColor& Tint)
	{
		if (!Comp) return;
		if (UMaterialInstanceDynamic* Dyn = Comp->CreateAndSetMaterialInstanceDynamic(0))
		{
			static const FName Candidates[] = { TEXT("Color"), TEXT("BaseColor"), TEXT("Tint"), TEXT("BaseColorTint"), TEXT("Albedo"), TEXT("Colour") };
			for (const FName& Param : Candidates)
			{
				Dyn->SetVectorParameterValue(Param, Tint);
			}
		}
	}
}

ATrenchDetailSplineActor::ATrenchDetailSplineActor()
{
	PrimaryActorTick.bCanEverTick = false;

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SetRootComponent(SceneRoot);

	DetailSpline = CreateDefaultSubobject<USplineComponent>(TEXT("DetailSpline"));
	DetailSpline->SetupAttachment(SceneRoot);
	DetailSpline->SetLocationAtSplinePoint(1, FVector(3000.f, 0.f, 0.f), ESplineCoordinateSpace::Local, true);

	HISM_Duckboard  = MakeHISM(TEXT("HISM_Duckboard"));
	HISM_Plank      = MakeHISM(TEXT("HISM_Plank")); // S18-TRMESH
	HISM_Revetment  = MakeHISM(TEXT("HISM_Revetment"));
	HISM_Post       = MakeHISM(TEXT("HISM_Post"));
	HISM_Corrugated = MakeHISM(TEXT("HISM_Corrugated"));
	HISM_Barrel     = MakeHISM(TEXT("HISM_Barrel"));
	HISM_AmmoCan    = MakeHISM(TEXT("HISM_AmmoCan"));
	HISM_Stake      = MakeHISM(TEXT("HISM_Stake"));
	HISM_Wire       = MakeHISM(TEXT("HISM_Wire"));
	HISM_Tarp       = MakeHISM(TEXT("HISM_Tarp"));
	HISM_FiringStep = MakeHISM(TEXT("HISM_FiringStep"));
	HISM_Casing     = MakeHISM(TEXT("HISM_Casing"));
	HISM_Stone      = MakeHISM(TEXT("HISM_Stone"));
	HISM_Scorch     = MakeHISM(TEXT("HISM_Scorch"));
	HISM_Rug        = MakeHISM(TEXT("HISM_Rug")); // S15-TRENCH3
	HISM_Netting      = MakeHISM(TEXT("HISM_Netting"));      // S15-TRENCH4
	HISM_Helmet       = MakeHISM(TEXT("HISM_Helmet"));       // S15-TRENCH4
	HISM_DugoutShadow = MakeHISM(TEXT("HISM_DugoutShadow")); // S15-TRENCH4
	HISM_Sandbag      = MakeHISM(TEXT("HISM_Sandbag"));      // S18-TRBAG
	HISM_SandbagStack = MakeHISM(TEXT("HISM_SandbagStack")); // S18-TRBAG
	HISM_WireSet      = MakeHISM(TEXT("HISM_WireSet"));      // S18-TRWIRE
	HISM_WireSet2     = MakeHISM(TEXT("HISM_WireSet2"));     // S18-TRWIRE
	HISM_WireSet3     = MakeHISM(TEXT("HISM_WireSet3"));     // S18-TRWIRE
	HISM_WireSet4     = MakeHISM(TEXT("HISM_WireSet4"));     // S18-TRWIRE
	HISM_WireSet5     = MakeHISM(TEXT("HISM_WireSet5"));     // S18-TRWIRE2
	HISM_WireSet6     = MakeHISM(TEXT("HISM_WireSet6"));     // S18-TRWIRE2
	HISM_WireObstacle = MakeHISM(TEXT("HISM_WireObstacle")); // S18-TRWIRE2
	HISM_WireCoil     = MakeHISM(TEXT("HISM_WireCoil"));     // S18-TRWIRE2
	HISM_WireCoil2    = MakeHISM(TEXT("HISM_WireCoil2"));    // S18-TRWIRE2
	HISM_Pigtail      = MakeHISM(TEXT("HISM_Pigtail"));      // S18-TRWIRE2
}

UHierarchicalInstancedStaticMeshComponent* ATrenchDetailSplineActor::MakeHISM(const TCHAR* Name)
{
	UHierarchicalInstancedStaticMeshComponent* H = CreateDefaultSubobject<UHierarchicalInstancedStaticMeshComponent>(Name);
	H->SetupAttachment(SceneRoot);
	H->SetMobility(EComponentMobility::Static);
	H->SetCollisionProfileName(TEXT("NoCollision"));
	H->SetCanEverAffectNavigation(false); // dressing must NEVER break trench navigation
	return H;
}

void ATrenchDetailSplineActor::ConfigureHISM(UHierarchicalInstancedStaticMeshComponent* HISM, UStaticMesh* Mesh,
	UMaterialInterface* Mat, const FLinearColor& Tint, bool bCollide, bool bMeshOwnsMaterial) const
{
	if (!HISM) return;
	HISM->ClearInstances();
	if (HISM->GetStaticMesh() != Mesh)
	{
		HISM->SetStaticMesh(Mesh);
	}
	HISM->SetCollisionProfileName((bCollide && bSolidProps) ? TEXT("BlockAllDynamic") : TEXT("NoCollision"));
	if (bMeshOwnsMaterial)
	{
		// S18-TRMESH: imported prop — its own material slots are already right.
		// Clear any override this HISM carried from a previous build.
		HISM->EmptyOverrideMaterials();
	}
	else if (Mat)
	{
		// S15-PBR: an authored material (e.g. M_TrenchWood world-aligned PBR)
		// is shown exactly as authored — no palette tint layered on top.
		HISM->SetMaterial(0, Mat);
	}
	else
	{
		TrenchTint(HISM, Tint); // engine-primitive fallback keeps the flat palette
	}
}

void ATrenchDetailSplineActor::OnConstruction(const FTransform& Transform)
{
	Super::OnConstruction(Transform);

	// Runtime map load: instances were serialized with the level — never touch
	// a registered Static HISM in a game world (the "Mobility is Static" spam).
	if (GetWorld() && GetWorld()->IsGameWorld())
	{
		return;
	}

	if (bAutoRebuild)
	{
#if WITH_EDITOR
		// S17-TRPERF: don't rebuild on every OnConstruction (= every mouse
		// move of a spline handle). Stamp the edit time and let a core-ticker
		// rebuild once, 0.45s after the LAST change. Press Build Details for
		// an immediate rebuild at any time.
		LastSplineEditTime = FPlatformTime::Seconds();
		if (!bDebounceRebuildPending)
		{
			bDebounceRebuildPending = true;
			TWeakObjectPtr<ATrenchDetailSplineActor> WeakThis(this);
			DebounceTickerHandle = FTSTicker::GetCoreTicker().AddTicker(FTickerDelegate::CreateLambda([WeakThis](float) -> bool
			{
				ATrenchDetailSplineActor* Self = WeakThis.Get();
				if (!Self || !IsValid(Self)) return false; // actor gone — stop
				if (FPlatformTime::Seconds() - Self->LastSplineEditTime < 0.45) return true; // still dragging — wait
				Self->bDebounceRebuildPending = false;
				if (Self->bAutoRebuild && Self->GetWorld() && !Self->GetWorld()->IsGameWorld())
				{
					Self->BuildDetails();
				}
				return false; // one-shot
			}), 0.1f);
		}
#else
		BuildDetails();
#endif
	}
}

#if WITH_EDITOR
void ATrenchDetailSplineActor::BeginDestroy()
{
	// S17-TRPERF: never leave a ticker pointing at a dying actor.
	if (DebounceTickerHandle.IsValid())
	{
		FTSTicker::GetCoreTicker().RemoveTicker(DebounceTickerHandle);
		DebounceTickerHandle.Reset();
	}
	Super::BeginDestroy();
}
#endif

void ATrenchDetailSplineActor::ClearDetails()
{
	UHierarchicalInstancedStaticMeshComponent* All[] =
	{
		HISM_Duckboard, HISM_Plank, HISM_Revetment, HISM_Post, HISM_Corrugated, HISM_Barrel,
		HISM_AmmoCan, HISM_Stake, HISM_Wire, HISM_Tarp, HISM_FiringStep,
		HISM_Casing, HISM_Stone, HISM_Scorch, HISM_Rug,
		HISM_Netting, HISM_Helmet, HISM_DugoutShadow,
		HISM_Sandbag, HISM_SandbagStack,
		HISM_WireSet, HISM_WireSet2, HISM_WireSet3, HISM_WireSet4, // S18-TRBAG / S18-TRWIRE
		HISM_WireSet5, HISM_WireSet6, HISM_WireObstacle, HISM_WireCoil, HISM_WireCoil2, HISM_Pigtail // S18-TRWIRE2
	};
	for (UHierarchicalInstancedStaticMeshComponent* H : All)
	{
		if (H) H->ClearInstances();
	}
}

// S15-TRENCH8: low-frequency rest-zone wave (~45 m wavelength). Roughly a third
// of the trench stays visually quiet — env-art negative space, so the busy
// vignettes around firing steps and dugouts actually stand out.
bool ATrenchDetailSplineActor::IsRestZone(float D) const
{
	return FMath::Sin(D * (2.f * PI / 4500.f) + RestZonePhase) < -0.5f;
}

bool ATrenchDetailSplineActor::TraceGroundZ(const FVector& Around, float& OutZ) const
{
	FVector DummyNormal;
	return TraceGround(Around, OutZ, DummyNormal);
}

// S15-TRENCH6: full ground query — height AND surface normal, so floor props
// can tilt to hug the sculpted terrain instead of sitting dead-flat.
bool ATrenchDetailSplineActor::TraceGround(const FVector& Around, float& OutZ, FVector& OutNormal) const
{
	UWorld* World = GetWorld();
	if (!World) return false;

	FHitResult Hit;
	FCollisionQueryParams Params;
	Params.AddIgnoredActor(this);
	if (World->LineTraceSingleByChannel(Hit,
		Around + FVector(0.f, 0.f, 3000.f),
		Around - FVector(0.f, 0.f, 8000.f),
		ECC_WorldStatic, Params))
	{
		OutZ = Hit.ImpactPoint.Z;
		OutNormal = Hit.ImpactNormal.GetSafeNormal();
		if (OutNormal.Z < 0.5f) OutNormal = FVector::UpVector; // wall hit — don't lie props on their side
		return true;
	}
	return false;
}

// ===== S17-TRWALL: real wall detection ======================================
// Trenches are dug lines: from a point just above the floor, horizontal traces
// perpendicular to the spline hit the actual left/right wall faces. Sampled
// every 150cm and cached; every scatter category reads the cache, so details
// hug the real dig instead of a fixed guessed width. Where a probe finds no
// wall (trench mouth, collapsed stretch), the manual WallOffset keeps working.
static constexpr float SquadAITrenchWallSampleStep = 150.f;

// S19-TREDGE: see the header — re-evaluate the spline at D+Delta instead of
// offsetting along a fixed tangent, so spanning elements hug a curving trench.
bool ATrenchDetailSplineActor::SampleAlongTrench(float D, float DeltaAlong,
	FVector& OutPos, FVector& OutRight, FRotator& OutRot, float& OutD) const
{
	if (!DetailSpline) return false;
	const float Len = DetailSpline->GetSplineLength();
	if (Len <= 1.f) return false;

	OutD = FMath::Clamp(D + DeltaAlong, 0.f, Len);
	OutPos   = DetailSpline->GetLocationAtDistanceAlongSpline(OutD, ESplineCoordinateSpace::World);
	OutRight = DetailSpline->GetRightVectorAtDistanceAlongSpline(OutD, ESplineCoordinateSpace::World);
	OutRot   = DetailSpline->GetRotationAtDistanceAlongSpline(OutD, ESplineCoordinateSpace::World);
	return true;
}

void ATrenchDetailSplineActor::SampleTrenchWalls()
{
	WallCacheL.Reset();
	WallCacheR.Reset();
	WallLeanL.Reset(); // S17-TRWALL2
	WallLeanR.Reset();
	WallHitL.Reset(); // S17-TRGATE
	WallHitR.Reset();
	UWorld* World = GetWorld();
	if (!bAutoDetectWalls || !DetailSpline || !World) return;

	const float Len = DetailSpline->GetSplineLength();
	const int32 Num = FMath::Max(2, FMath::CeilToInt(Len / SquadAITrenchWallSampleStep) + 1);
	WallCacheL.SetNum(Num);
	WallCacheR.SetNum(Num);
	WallLeanL.SetNum(Num); // S17-TRWALL2
	WallLeanR.SetNum(Num);
	WallHitL.SetNum(Num); // S17-TRGATE
	WallHitR.SetNum(Num);
	FCollisionQueryParams Params;
	Params.AddIgnoredActor(this);
	const float MaxProbe = ParapetOffset * 2.5f;
	int32 NumHits = 0;
	for (int32 i = 0; i < Num; ++i)
	{
		const float D = FMath::Min(Len, i * SquadAITrenchWallSampleStep);
		const FVector P = DetailSpline->GetLocationAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);
		FVector Right = DetailSpline->GetRightVectorAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);
		Right.Z = 0.f;
		if (!Right.Normalize()) Right = FVector::RightVector;
		float FloorZ = P.Z;
		TraceGroundZ(P, FloorZ);
		const FVector Probe(P.X, P.Y, FloorZ + WallProbeHeight);
		for (int32 SideIdx = 0; SideIdx < 2; ++SideIdx)
		{
			const float Sgn = (SideIdx == 0) ? -1.f : 1.f;
			float Dist = WallOffset; // fallback: the manual value
			float LeanDeg = 0.f;    // S17-TRWALL2: 0 = vertical wall
			float HitFlag = 0.f;    // S17-TRGATE
			FHitResult Hit;
			if (World->LineTraceSingleByChannel(Hit, Probe + Right * (Sgn * 40.f), Probe + Right * (Sgn * MaxProbe), ECC_WorldStatic, Params))
			{
				Dist = FMath::Clamp(FVector::Dist2D(Hit.ImpactPoint, P), 120.f, MaxProbe);
				// S17-TRWALL2: the hit normal tells the wall's slope. A dug
				// wall sloping outward has NormalZ = sin(lean-from-vertical).
				const float NZ = FMath::Clamp(Hit.ImpactNormal.Z, 0.f, 0.9f);
				LeanDeg = FMath::RadiansToDegrees(FMath::Asin(NZ));
				// The probe measured the face at WallProbeHeight — pull the
				// distance back to the WALL FOOT so floor items sit at the
				// real base instead of inside a sloped wall.
				const float Horiz = FMath::Max(0.3f, FMath::Sqrt(1.f - NZ * NZ));
				Dist = FMath::Max(120.f, Dist - WallProbeHeight * (NZ / Horiz));
				HitFlag = 1.f; // S17-TRGATE
				++NumHits;
			}
			(SideIdx == 0 ? WallCacheL : WallCacheR)[i] = Dist;
			(SideIdx == 0 ? WallLeanL : WallLeanR)[i] = LeanDeg; // S17-TRWALL2
			(SideIdx == 0 ? WallHitL : WallHitR)[i] = HitFlag; // S17-TRGATE
		}
	}
	UE_LOG(LogTemp, Log, TEXT("[TrenchDresser] S17-TRWALL: %d/%d wall probes hit real walls (%d samples, %.0fcm spline)."), NumHits, Num * 2, Num, Len);
}

float ATrenchDetailSplineActor::WallDistAt(float D, float Side) const
{
	const TArray<float>& C = (Side < 0.f) ? WallCacheL : WallCacheR;
	if (C.Num() < 2) return WallOffset; // detection off/failed -> old behavior
	const float F = FMath::Clamp(D / SquadAITrenchWallSampleStep, 0.f, static_cast<float>(C.Num() - 1));
	const int32 I0 = FMath::FloorToInt(F);
	const int32 I1 = FMath::Min(I0 + 1, C.Num() - 1);
	return FMath::Lerp(C[I0], C[I1], F - static_cast<float>(I0));
}

// S17-TRWALL2: interpolated wall lean (degrees from vertical) at D.
float ATrenchDetailSplineActor::WallLeanAt(float D, float Side) const
{
	const TArray<float>& C = (Side < 0.f) ? WallLeanL : WallLeanR;
	if (C.Num() < 2) return 0.f; // detection off -> behave like vertical walls
	const float F = FMath::Clamp(D / SquadAITrenchWallSampleStep, 0.f, static_cast<float>(C.Num() - 1));
	const int32 I0 = FMath::FloorToInt(F);
	const int32 I1 = FMath::Min(I0 + 1, C.Num() - 1);
	return FMath::Lerp(C[I0], C[I1], F - static_cast<float>(I0));
}

// S17-TRGATE: did the probes find a REAL wall near D on this side?
// Wall furniture (revetments, corrugated sheets, dugouts, roofs, nets,
// firing steps) must NEVER appear where there is no wall to carry it —
// that was the single worst realism breaker: boards leaning on open air.
// Detection off (cache empty) -> true, preserving the manual workflow.
bool ATrenchDetailSplineActor::WallHitAt(float D, float Side) const
{
	const TArray<float>& C = (Side < 0.f) ? WallHitL : WallHitR;
	if (C.Num() < 2) return true;
	const float F = FMath::Clamp(D / SquadAITrenchWallSampleStep, 0.f, static_cast<float>(C.Num() - 1));
	const int32 I0 = FMath::FloorToInt(F);
	const int32 I1 = FMath::Min(I0 + 1, C.Num() - 1);
	return FMath::Lerp(C[I0], C[I1], F - static_cast<float>(I0)) > 0.5f;
}

float ATrenchDetailSplineActor::ParapetDistAt(float D, float Side) const
{
	if (WallCacheL.Num() < 2) return ParapetOffset;
	return WallDistAt(D, Side) + FMath::Max(60.f, ParapetOffset - WallOffset);
}

float ATrenchDetailSplineActor::FloorHalfAt(float D) const
{
	if (WallCacheL.Num() < 2) return FloorHalfWidth;
	const float Narrow = FMath::Min(WallDistAt(D, -1.f), WallDistAt(D, 1.f)) - 70.f;
	return FMath::Clamp(Narrow, 80.f, FloorHalfWidth);
}

// S17-TRAUTO: the import script (SquadAI_ImportTrenchMaterials.py) always
// saves its materials to /Game/SquadAI/TrenchMaterials — so the dresser can
// set its own table. Only EMPTY slots are filled: anything you assigned by
// hand always wins, and missing assets (e.g. pack not imported yet) are
// skipped silently — engine-primitive defaults keep working as before.
void ATrenchDetailSplineActor::AutoFillMaterials()
{
	struct FAutoSlot { TObjectPtr<UMaterialInterface>* Slot; const TCHAR* Asset; };
	const FAutoSlot Slots[] = {
		{ &WoodMaterial,       TEXT("M_TrenchWood") },
		{ &MetalMaterial,      TEXT("M_TrenchMetal") },
		{ &ClothMaterial,      TEXT("M_TrenchCanvas") },
		{ &GroundMaterial,     TEXT("M_TrenchEarth") },
		{ &ScorchMaterial,     TEXT("M_TrenchScorch") },
		{ &CorrugatedMaterial, TEXT("M_TrenchCorrugated") },
		{ &BarrelMaterial,     TEXT("M_TrenchDrum") },
		{ &AmmoCanMaterial,    TEXT("M_TrenchAmmoCan") },
		{ &RugMaterial,        TEXT("M_TrenchRug") },
		{ &NettingMaterial,    TEXT("M_TrenchNetting") },
	};
	int32 NumFilled = 0, NumMissing = 0;
	for (const FAutoSlot& S : Slots)
	{
		if (*S.Slot) continue; // hand-assigned wins
		const FString PackagePath = FString::Printf(TEXT("/Game/SquadAI/TrenchMaterials/%s"), S.Asset);
		if (!FPackageName::DoesPackageExist(PackagePath))
		{
			++NumMissing;
			continue;
		}
		const FString ObjectPath = FString::Printf(TEXT("%s.%s"), *PackagePath, S.Asset);
		if (UMaterialInterface* M = Cast<UMaterialInterface>(StaticLoadObject(UMaterialInterface::StaticClass(), nullptr, *ObjectPath)))
		{
			*S.Slot = M;
			++NumFilled;
		}
	}
	if (NumFilled > 0)
	{
		UE_LOG(LogTemp, Log, TEXT("[TrenchDresser] S17-TRAUTO: auto-filled %d material slot(s) from /Game/SquadAI/TrenchMaterials (%d not found)."), NumFilled, NumMissing);
	}
}

void ATrenchDetailSplineActor::BuildDetails()
{
	AutoFillMaterials(); // S17-TRAUTO: run the import script once, then just press Build
	if (!DetailSpline || DetailSpline->GetSplineLength() < 200.f) return;

	USquadAIAssetCacheSubsystem* Cache = USquadAIAssetCacheSubsystem::Get(this);
	UStaticMesh* Cube = Cache ? Cache->GetCubeMesh() : nullptr;
	UStaticMesh* Cyl = Cache ? Cache->GetCylinderMesh() : nullptr;
	UStaticMesh* Plane = Cache ? Cache->GetPlaneMesh() : nullptr;
	UStaticMesh* Sphere = Cache ? Cache->GetSphereMesh() : nullptr; // S15-TRENCH4
	if (!Cube) Cube = LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cube.Cube"));
	if (!Cyl) Cyl = LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cylinder.Cylinder"));
	if (!Plane) Plane = LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Plane.Plane"));
	if (!Sphere) Sphere = LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Sphere.Sphere"));
	if (!Cube || !Cyl || !Plane || !Sphere) return;

	// S18-TRMESH: a family that was handed a custom mesh renders with the
	// mesh's own materials (MeshOwns) unless the user forces the family slot.
	const bool bBoardOwns = CustomDuckboardMesh != nullptr && bUseCustomMeshMaterials;
	const bool bRevetOwns = CustomRevetmentMesh != nullptr && bUseCustomMeshMaterials;
	const bool bBarrelOwns = CustomBarrelMesh != nullptr && bUseCustomMeshMaterials;
	const bool bCanOwns = CustomAmmoCanMesh != nullptr && bUseCustomMeshMaterials;
	const bool bStakeOwns = CustomStakeMesh != nullptr && bUseCustomMeshMaterials;
	const bool bTarpOwns = CustomTarpMesh != nullptr && bUseCustomMeshMaterials;

	ConfigureHISM(HISM_Duckboard, CustomDuckboardMesh ? CustomDuckboardMesh.Get() : Cube, WoodMaterial.Get(), WoodTint, false, bBoardOwns);
	ConfigureHISM(HISM_Plank, Cube, WoodMaterial.Get(), WoodTint, false); // S18-TRMESH: always cube planks
	ConfigureHISM(HISM_Revetment, CustomRevetmentMesh ? CustomRevetmentMesh.Get() : Cube, WoodMaterial.Get(), DarkWoodTint, false, bRevetOwns);
	ConfigureHISM(HISM_Post, Cube, WoodMaterial.Get(), DarkWoodTint, false);
	ConfigureHISM(HISM_Corrugated, Cube, CorrugatedMaterial ? CorrugatedMaterial.Get() : MetalMaterial.Get(), CorrugatedTint, false); // S15-TRENCH3
	ConfigureHISM(HISM_Barrel, CustomBarrelMesh ? CustomBarrelMesh.Get() : Cyl, BarrelMaterial ? BarrelMaterial.Get() : MetalMaterial.Get(), BarrelTint, true, bBarrelOwns); // S15-TRENCH3
	ConfigureHISM(HISM_AmmoCan, CustomAmmoCanMesh ? CustomAmmoCanMesh.Get() : Cube, AmmoCanMaterial ? AmmoCanMaterial.Get() : MetalMaterial.Get(), AmmoCanTint, false, bCanOwns); // S15-TRENCH3
	ConfigureHISM(HISM_Stake, CustomStakeMesh ? CustomStakeMesh.Get() : Cube, WoodMaterial.Get(), DarkWoodTint, false, bStakeOwns);
	ConfigureHISM(HISM_Wire, Cyl, MetalMaterial.Get(), WireTint, false);
	ConfigureHISM(HISM_Tarp, CustomTarpMesh ? CustomTarpMesh.Get() : Plane, ClothMaterial.Get(), TarpTint, false, bTarpOwns);
	ConfigureHISM(HISM_FiringStep, Cube, GroundMaterial.Get(), EarthTint, true);
	ConfigureHISM(HISM_Casing, Cyl, nullptr, CasingTint, false); // S15-TRENCH2: always brass tint, never rusty sheet steel
	ConfigureHISM(HISM_Stone, Cube, GroundMaterial.Get(), StoneTint, false);
	ConfigureHISM(HISM_Scorch, Plane, ScorchMaterial ? ScorchMaterial.Get() : GroundMaterial.Get(), ScorchTint, false); // S15-PBR
	ConfigureHISM(HISM_Rug, Plane, RugMaterial.Get(), RugTint, false); // S15-TRENCH3
	ConfigureHISM(HISM_Netting, Plane, NettingMaterial ? NettingMaterial.Get() : ClothMaterial.Get(), NettingTint, false); // S15-TRENCH4
	ConfigureHISM(HISM_Helmet, Sphere, nullptr, HelmetTint, false);        // S15-TRENCH4: always tinted olive
	ConfigureHISM(HISM_DugoutShadow, Plane, nullptr, DugoutShadowTint, false); // S15-TRENCH4: fake-depth black
	// S18-TRBAG / S18-TRWIRE: prop-only families — no mesh assigned means the
	// pass simply does nothing, so old maps are byte-for-byte unchanged.
	ConfigureHISM(HISM_Sandbag, CustomSandbagMesh.Get(), ClothMaterial.Get(), TarpTint, false,
		CustomSandbagMesh != nullptr && bUseCustomMeshMaterials);
	ConfigureHISM(HISM_SandbagStack, CustomSandbagStackMesh.Get(), ClothMaterial.Get(), TarpTint, bSolidProps,
		CustomSandbagStackMesh != nullptr && bUseCustomMeshMaterials);
	ConfigureHISM(HISM_WireSet, CustomWireSetMesh.Get(), MetalMaterial.Get(), WireTint, false,
		CustomWireSetMesh != nullptr && bUseCustomMeshMaterials);
	ConfigureHISM(HISM_WireSet2, CustomWireSetMesh2.Get(), MetalMaterial.Get(), WireTint, false,
		CustomWireSetMesh2 != nullptr && bUseCustomMeshMaterials);
	ConfigureHISM(HISM_WireSet3, CustomWireSetMesh3.Get(), MetalMaterial.Get(), WireTint, false,
		CustomWireSetMesh3 != nullptr && bUseCustomMeshMaterials);
	ConfigureHISM(HISM_WireSet4, CustomWireSetMesh4.Get(), MetalMaterial.Get(), WireTint, false,
		CustomWireSetMesh4 != nullptr && bUseCustomMeshMaterials);
	// S18-TRWIRE2: the rest of the pack's wire family — two more runs, the wooden
	// X-frame obstacle that carries the belt, loose coils and iron pigtail pickets.
	ConfigureHISM(HISM_WireSet5, CustomWireSetMesh5.Get(), MetalMaterial.Get(), WireTint, false,
		CustomWireSetMesh5 != nullptr && bUseCustomMeshMaterials);
	ConfigureHISM(HISM_WireSet6, CustomWireSetMesh6.Get(), MetalMaterial.Get(), WireTint, false,
		CustomWireSetMesh6 != nullptr && bUseCustomMeshMaterials);
	// Wooden frame: collides (it is a real obstacle you cannot walk through).
	ConfigureHISM(HISM_WireObstacle, CustomWireObstacleMesh.Get(), WoodMaterial.Get(), DarkWoodTint, bSolidProps,
		CustomWireObstacleMesh != nullptr && bUseCustomMeshMaterials);
	ConfigureHISM(HISM_WireCoil, CustomWireCoilMesh.Get(), MetalMaterial.Get(), WireTint, false,
		CustomWireCoilMesh != nullptr && bUseCustomMeshMaterials);
	ConfigureHISM(HISM_WireCoil2, CustomWireCoilMesh2.Get(), MetalMaterial.Get(), WireTint, false,
		CustomWireCoilMesh2 != nullptr && bUseCustomMeshMaterials);
	ConfigureHISM(HISM_Pigtail, CustomPigtailMesh.Get(), MetalMaterial.Get(), WireTint, false,
		CustomPigtailMesh != nullptr && bUseCustomMeshMaterials);

	// S15-TRENCH5: per-location seed variation — two dressers with identical
	// settings still get distinct layouts (10 cm grid keeps it stable under
	// sub-centimetre transform noise).
	int32 EffectiveSeed = Seed;
	if (bUniqueSeedPerLocation)
	{
		const FVector Snapped = GetActorLocation().GridSnap(10.f);
		EffectiveSeed = HashCombine(GetTypeHash(Seed), GetTypeHash(Snapped));
	}
	FRandomStream Stream(EffectiveSeed);

	// S15-TRENCH8: composition state — anchors + negative-space rhythm.
	DugoutBuildMarks.Reset();
	ClusterAnchors.Reset();
	RestZonePhase = Stream.FRandRange(0.f, 2.f * PI);

	// S15-TRENCH8 pass order = composition order: structure first (walls,
	// parapet, dugouts register the story anchors), then loose props that
	// gravitate toward those anchors, then filler that respects rest zones.
	SampleTrenchWalls();              // S17-TRWALL: find the real dug walls first
	ScatterWalls(Stream);             // registers firing-step anchors
	ScatterParapet(Stream);
	ScatterDugoutsAndNetting(Stream); // S15-TRENCH4 — registers dugout anchors
	ScatterFloorLine(Stream);         // barrels/cans cluster near anchors
	ScatterDebris(Stream);            // rest-zone aware
	ScatterOverheadCover(Stream);     // S15-TRENCH2
	ScatterCommWire(Stream);          // S15-TRENCH2
	ScatterCampLife(Stream);          // S15-TRENCH3
	ScatterSandbags(Stream);          // S18-TRBAG
	ScatterWireSets(Stream);          // S18-TRWIRE
	ScatterWireObstacles(Stream);     // S18-TRWIRE2

	// S15-TRENCH6: build stats — one line per rebuild so instance costs stay visible.
	{
		const UHierarchicalInstancedStaticMeshComponent* Stats[] =
		{
			HISM_Duckboard, HISM_Plank, HISM_Revetment, HISM_Post, HISM_Corrugated, HISM_Barrel,
			HISM_AmmoCan, HISM_Stake, HISM_Wire, HISM_Tarp, HISM_FiringStep,
			HISM_Casing, HISM_Stone, HISM_Scorch, HISM_Rug,
			HISM_Netting, HISM_Helmet, HISM_DugoutShadow,
			HISM_Sandbag, HISM_SandbagStack,
			HISM_WireSet, HISM_WireSet2, HISM_WireSet3, HISM_WireSet4, // S18-TRBAG / S18-TRWIRE
		HISM_WireSet5, HISM_WireSet6, HISM_WireObstacle, HISM_WireCoil, HISM_WireCoil2, HISM_Pigtail // S18-TRWIRE2
		};
		int32 Total = 0;
		int32 UsedCategories = 0;
		for (const UHierarchicalInstancedStaticMeshComponent* H : Stats)
		{
			if (!H) continue;
			const int32 Count = H->GetInstanceCount();
			Total += Count;
			if (Count > 0) ++UsedCategories;
		}
		UE_LOG(LogTemp, Log, TEXT("[TrenchDresser] %s: built %d instances in %d/24 categories along %.0f m of trench (seed %d)"),
			*GetName(), Total, UsedCategories, DetailSpline->GetSplineLength() / 100.f, Seed);
	}
}

// =====================================================================
//  S15-TRENCH4: the two big "game trench" reads researched from WW1/COD
//  environment art — timber-framed dugout entrances cut into the wall
//  (dark doorway = instant depth + story) and camouflage netting
//  stretched over sections of the trench.
// =====================================================================
void ATrenchDetailSplineActor::ScatterDugoutsAndNetting(FRandomStream& Stream)
{
	const float Len = DetailSpline->GetSplineLength();

	// -- Dugout entrances: every ~25 m, 35%·density.
	if (bDugouts)
	{
		for (float D = 1200.f; D < Len - 600.f; D += 2500.f)
		{
			if (Stream.FRand() > 0.35f * DetailDensity) continue;

			const FVector P = DetailSpline->GetLocationAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);
			const FVector Right = DetailSpline->GetRightVectorAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);
			const FRotator SplineRot = DetailSpline->GetRotationAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);
			const FVector Along = SplineRot.Vector();
			float Side = (Stream.FRand() < 0.5f) ? -1.f : 1.f;
			if (!WallHitAt(D, Side)) Side = -Side;      // S17-TRGATE: try the other wall
			if (!WallHitAt(D, Side)) continue;          // no wall at all -> no dugout

			FVector Base = P + Right * Side * (WallDistAt(D, Side) + 10.f);
			float GroundZ = Base.Z;
			if (!TraceGroundZ(Base, GroundZ)) continue;

			DugoutBuildMarks.Add(D); // S15-TRENCH7: reserve this stretch
			ClusterAnchors.Add(D);   // S15-TRENCH8: dugouts anchor clusters too
			const float Yaw = SplineRot.Yaw;

			// Heavy timber door posts + lintel.
			for (int32 PostIdx = 0; PostIdx < 2; ++PostIdx)
			{
				const FVector PostPos = FVector(Base.X, Base.Y, GroundZ + 75.f)
					+ Along * ((PostIdx == 0 ? -1.f : 1.f) * 55.f);
				HISM_Post->AddInstance(FTransform(FRotator(0.f, Yaw, 0.f), PostPos, FVector(0.14f, 0.14f, 1.55f)), true);
			}
			HISM_Post->AddInstance(FTransform(FRotator(0.f, Yaw, 0.f),
				FVector(Base.X, Base.Y, GroundZ + 152.f), FVector(1.35f, 0.16f, 0.15f)), true);

			// Fake-depth black doorway plane, recessed into the wall.
			const FVector ShadowPos = P + Right * Side * (WallDistAt(D, Side) + 26.f) + FVector(0.f, 0.f, 0.f);
			const float ShadowYaw = Yaw + (Side > 0.f ? -90.f : 90.f); // face the trench
			HISM_DugoutShadow->AddInstance(FTransform(FRotator(90.f, ShadowYaw, 0.f),
				FVector(ShadowPos.X, ShadowPos.Y, GroundZ + 74.f), FVector(1.05f, 1.45f, 1.f)), true);

			// Corrugated rain hood over the lintel, tilted out.
			HISM_Corrugated->AddInstance(FTransform(FRotator(0.f, Yaw, Side * 14.f),
				FVector(Base.X, Base.Y, GroundZ + 170.f) - Right * Side * 12.f,
				FVector(1.45f, 0.62f, 0.035f)), true);

			// Kit dumped beside the doorway.
			const bool bCustomCan = CustomAmmoCanMesh != nullptr;
			const int32 Cans = Stream.RandRange(1, 3);
			for (int32 i = 0; i < Cans; ++i)
			{
				FVector CanPos = P + Right * Side * (WallDistAt(D, Side) - 55.f) + Along * (75.f + i * 34.f);
				float CZ = CanPos.Z; TraceGroundZ(CanPos, CZ);
				CanPos.Z = CZ + (bCustomCan ? 0.f : 9.f);
				HISM_AmmoCan->AddInstance(FTransform(FRotator(0.f, Stream.FRandRange(0.f, 360.f), 0.f),
					CanPos, bCustomCan ? FVector(CustomMeshScale) : FVector(0.30f, 0.16f, 0.18f)), true);
			}
		}
	}

	// -- Camo netting: every ~18 m, 30%·density, stretched berm to berm.
	if (bCamoNetting)
	{
		for (float D = 600.f; D < Len - 400.f; D += 1800.f)
		{
			if (Stream.FRand() > 0.30f * DetailDensity) continue;

			const FVector P = DetailSpline->GetLocationAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);
			const FVector Right = DetailSpline->GetRightVectorAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);
			const FRotator SplineRot = DetailSpline->GetRotationAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);

			if (!WallHitAt(D, -1.f) || !WallHitAt(D, 1.f)) continue; // S17-TRGATE: a net spans a trench, not open dirt

			float LeftZ = P.Z, RightZ = P.Z;
			TraceGroundZ(P - Right * ParapetDistAt(D, -1.f), LeftZ);
			TraceGroundZ(P + Right * ParapetDistAt(D, 1.f), RightZ);
			float FloorZ = P.Z; TraceGroundZ(P, FloorZ);
			const float NetZ = FMath::Max3(LeftZ, RightZ, FloorZ + 200.f) + 42.f;

			// Two slightly tilted overlapping panels read like a draped net
			// (material is masked + two-sided, so no underside instances needed).
			const float Span = (ParapetDistAt(D, -1.f) + ParapetDistAt(D, 1.f)) * 1.05f;
			for (int32 Panel = 0; Panel < 2; ++Panel)
			{
				const float PSide = (Panel == 0) ? -1.f : 1.f;
				FVector PanelPos = P + SplineRot.Vector() * (PSide * 115.f);
				PanelPos.Z = NetZ + Stream.FRandRange(-6.f, 6.f);
				const FRotator PanelRot(PSide * Stream.FRandRange(3.f, 7.f),
					SplineRot.Yaw + Stream.FRandRange(-8.f, 8.f),
					Stream.FRandRange(-5.f, 5.f));
				// S17-TRVAR: a net is cloth, not a tabletop. Each panel is 3
				// overlapping strips across the span — middle strip sags low,
				// outer strips droop toward the lips. Reads as real drape.
				const float StripW = (Span / 100.f) * Stream.FRandRange(0.34f, 0.42f);
				for (int32 Strip = 0; Strip < 3; ++Strip)
				{
					FVector StripPos = PanelPos + Right * ((Strip - 1) * Span * 0.30f);
					StripPos.Z += (Strip == 1) ? Stream.FRandRange(-18.f, -9.f) : Stream.FRandRange(-5.f, 4.f);
					FRotator StripRot = PanelRot;
					StripRot.Roll  += (Strip - 1) * Stream.FRandRange(7.f, 13.f);
					StripRot.Pitch += Stream.FRandRange(-4.f, 4.f);
					HISM_Netting->AddInstance(FTransform(StripRot, StripPos,
						FVector(Stream.FRandRange(2.0f, 2.7f), StripW, 1.f)), true);
				}
				// S17-TRWOOD: hanging edge flaps — seen edge-on a flat net is a
				// thread. Cloth falls over the lips, so a face shows from
				// every camera angle.
				for (int32 Flap = 0; Flap < 3; ++Flap)
				{
					const float FSide = (Flap == 2) ? (Stream.FRand() < 0.5f ? -1.f : 1.f) : ((Flap == 0) ? -1.f : 1.f);
					FVector FlapPos = PanelPos + Right * FSide * Span * 0.45f + SplineRot.Vector() * Stream.FRandRange(-90.f, 90.f);
					FlapPos.Z += Stream.FRandRange(-26.f, -10.f);
					FRotator FlapRot = PanelRot;
					FlapRot.Roll += FSide * Stream.FRandRange(55.f, 80.f);
					FlapRot.Yaw  += Stream.FRandRange(-10.f, 10.f);
					HISM_Netting->AddInstance(FTransform(FlapRot, FlapPos,
						FVector(Stream.FRandRange(0.6f, 1.0f), Stream.FRandRange(0.35f, 0.6f), 1.f)), true);
				}
			}

			// S15-TRENCH5: corner support poles — a net doesn't float.
			const FVector Along = SplineRot.Vector();
			for (int32 Corner = 0; Corner < 4; ++Corner)
			{
				const float ASide = (Corner & 1) ? 1.f : -1.f;
				const float RSide = (Corner & 2) ? 1.f : -1.f;
				FVector PolePos = P + Along * ASide * 235.f + Right * RSide * (ParapetDistAt(D, RSide) * 0.92f);
				float PoleGroundZ = PolePos.Z;
				if (!TraceGroundZ(PolePos, PoleGroundZ)) continue;
				const float PoleH = NetZ - PoleGroundZ + Stream.FRandRange(-4.f, 6.f);
				if (PoleH < 40.f) continue; // berm already carries the net here
				HISM_Post->AddInstance(FTransform(
					FRotator(Stream.FRandRange(-3.f, 3.f), Stream.FRandRange(0.f, 360.f), Stream.FRandRange(-3.f, 3.f)),
					FVector(PolePos.X, PolePos.Y, PoleGroundZ + PoleH * 0.5f),
					FVector(0.06f, 0.06f, PoleH / 100.f)), true);
			}
		}
	}
}

// =====================================================================
//  S15-TRENCH3 CAMP LIFE: the lived-in layer — campfire spots, prayer
//  rugs, stretchers and assault ladders. One feature per stretch so the
//  trench reads organised, not cluttered.
// =====================================================================
void ATrenchDetailSplineActor::ScatterCampLife(FRandomStream& Stream)
{
	const float Len = DetailSpline->GetSplineLength();

	for (float D = 700.f; D < Len; D += 1800.f)
	{
		const FVector P = DetailSpline->GetLocationAtDistanceAlongSpline(D + Stream.FRandRange(-300.f, 300.f), ESplineCoordinateSpace::World);
		const FVector Right = DetailSpline->GetRightVectorAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);
		const FRotator SplineRot = DetailSpline->GetRotationAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);
		const float Side = (Stream.FRand() < 0.5f) ? -1.f : 1.f;
		const float Roll = Stream.FRand();

		// S15-TRENCH7: don't dump camp furniture into a dugout doorway.
		bool bNearDugout = false;
		for (const float Mark : DugoutBuildMarks)
		{
			if (FMath::Abs(Mark - D) < 400.f) { bNearDugout = true; break; }
		}
		if (bNearDugout) continue;

		// -- Fire pit: scorch mark ringed by stones, mid-floor.
		if (bFirePits && Roll < 0.22f * DetailDensity)
		{
			FVector Pos = P + Right * Stream.FRandRange(-FloorHalfAt(D) * 0.4f, FloorHalfAt(D) * 0.4f);
			float GroundZ = Pos.Z;
			FVector GroundN = FVector::UpVector;
			TraceGround(Pos, GroundZ, GroundN); // S15-TRENCH6: slope-aligned burn mark
			const FVector YawDir = FRotator(0.f, Stream.FRandRange(0.f, 360.f), 0.f).Vector();
			HISM_Scorch->AddInstance(FTransform(FRotationMatrix::MakeFromZX(GroundN, YawDir).Rotator(), FVector(Pos.X, Pos.Y, GroundZ + 1.5f), FVector(Stream.FRandRange(1.15f, 1.62f), Stream.FRandRange(1.0f, 1.45f), 1.f)), true);
			const int32 RingStones = 8;
			for (int32 i = 0; i < RingStones; ++i)
			{
				const float Ang = (2.f * PI * i) / RingStones + Stream.FRandRange(-0.15f, 0.15f);
				const float Rad = Stream.FRandRange(48.f, 60.f);
				FVector SPos = Pos + FVector(FMath::Cos(Ang) * Rad, FMath::Sin(Ang) * Rad, 0.f);
				float SZ = SPos.Z; TraceGroundZ(SPos, SZ);
				const float S = Stream.FRandRange(0.09f, 0.14f);
				SPos.Z = SZ + S * 40.f;
				HISM_Stone->AddInstance(FTransform(FRotator(Stream.FRandRange(0.f, 360.f), Stream.FRandRange(0.f, 360.f), 0.f), SPos, FVector(S, S, S * 0.8f)), true);
			}
		}
		// -- Prayer / rest rug: flat near the wall, out of the walkway.
		else if (bPrayerRugs && Roll < 0.40f * DetailDensity)
		{
			FVector Pos = P + Right * Side * (WallDistAt(D, Side) - 130.f);
			float GroundZ = Pos.Z;
			FVector GroundN = FVector::UpVector;
			TraceGround(Pos, GroundZ, GroundN);
			Pos.Z = GroundZ + 2.f;
			// Long axis along the trench, slight casual skew, hugging the slope (S15-TRENCH6).
			const FVector YawDir = FRotator(0.f, SplineRot.Yaw + Stream.FRandRange(-14.f, 14.f), 0.f).Vector();
			FRotator RugRot = FRotationMatrix::MakeFromZX(GroundN, YawDir).Rotator(); // S17-TRVAR
			RugRot.Pitch += Stream.FRandRange(-2.f, 2.f);
			RugRot.Roll  += Stream.FRandRange(-2.f, 2.f);
			const FVector RugScale(Stream.FRandRange(1.4f, 1.75f), Stream.FRandRange(0.82f, 1.05f), 1.f);
			HISM_Rug->AddInstance(FTransform(RugRot, Pos, RugScale), true);
			// S17-TRVAR: 40% get a kicked-up folded corner — used, not ironed.
			if (Stream.FRand() < 0.40f)
			{
				const FVector CornerOff = FRotationMatrix(RugRot).GetUnitAxis(EAxis::X) * (RugScale.X * 42.f * (Stream.FRand() < 0.5f ? 1.f : -1.f))
					+ FRotationMatrix(RugRot).GetUnitAxis(EAxis::Y) * (RugScale.Y * 38.f * (Stream.FRand() < 0.5f ? 1.f : -1.f));
				FRotator FoldRot = RugRot;
				FoldRot.Yaw  += Stream.FRandRange(25.f, 55.f);
				FoldRot.Pitch += Stream.FRandRange(3.f, 8.f);
				HISM_Rug->AddInstance(FTransform(FoldRot, Pos + CornerOff + FVector(0.f, 0.f, 1.4f),
					FVector(0.38f, 0.32f, 1.f)), true);
			}
		}
		// -- Stretcher: two carry poles + canvas, lying along the wall.
		else if (bStretchers && Roll < 0.52f * DetailDensity)
		{
			FVector Pos = P + Right * Side * (WallDistAt(D, Side) - 75.f);
			float GroundZ = Pos.Z;
			FVector GroundN = FVector::UpVector;
			TraceGround(Pos, GroundZ, GroundN); // S15-TRENCH7: stretcher hugs the slope
			const float Yaw = SplineRot.Yaw + Stream.FRandRange(-10.f, 10.f);
			const FVector YawDir = FRotator(0.f, Yaw, 0.f).Vector();
			const FVector PoleAxis = FVector::VectorPlaneProject(YawDir, GroundN).GetSafeNormal();
			const FVector Across = FVector::CrossProduct(GroundN, PoleAxis).GetSafeNormal();
			const FVector Hit(Pos.X, Pos.Y, GroundZ);
			for (int32 PoleIdx = 0; PoleIdx < 2; ++PoleIdx)
			{
				const FVector PolePos = Hit + GroundN * 6.f + Across * ((PoleIdx == 0 ? -1.f : 1.f) * 32.f);
				HISM_Post->AddInstance(FTransform(FRotationMatrix::MakeFromZ(PoleAxis).Rotator(), PolePos, FVector(0.06f, 0.06f, 2.05f)), true);
			}
			HISM_Tarp->AddInstance(FTransform(FRotationMatrix::MakeFromZX(GroundN, YawDir).Rotator(), Hit + GroundN * 10.f, FVector(1.85f, 0.55f, 1.f)), true);
		}
		// -- Assault ladder leaning against the trench wall.
		else if (bLadders && WallHitAt(D, Side) && Roll < LadderChance * DetailDensity) // S18-FIX: ladders were everywhere
		{
			FVector Base = P + Right * Side * (WallDistAt(D, Side) - 25.f);
			float GroundZ = Base.Z; TraceGroundZ(Base, GroundZ);
			Base.Z = GroundZ;

			const float Lean = Stream.FRandRange(14.f, 20.f) * -Side; // top leans INTO the wall
			const FRotator LadderRot(0.f, SplineRot.Yaw, Lean);
			const FVector RailUp = FRotationMatrix(LadderRot).GetUnitAxis(EAxis::Z);
			const FVector RailAcross = FRotationMatrix(LadderRot).GetUnitAxis(EAxis::X);

			for (int32 RailIdx = 0; RailIdx < 2; ++RailIdx)
			{
				const FVector RailPos = Base + RailAcross * ((RailIdx == 0 ? -1.f : 1.f) * 27.f) + RailUp * 115.f;
				HISM_Post->AddInstance(FTransform(LadderRot, RailPos, FVector(0.07f, 0.07f, 2.3f)), true);
			}
			for (int32 RungIdx = 0; RungIdx < 6; ++RungIdx)
			{
				const FVector RungPos = Base + RailUp * (28.f + RungIdx * 36.f);
				HISM_Post->AddInstance(FTransform(LadderRot, RungPos, FVector(0.62f, 0.055f, 0.055f)), true);
			}
		}
	}
}

// =====================================================================
//  S15-TRENCH2 OVERHEAD COVER: plank + corrugated-sheet roof sections
//  spanning the trench from berm to berm (iconic Iran–Iraq trench look).
// =====================================================================
void ATrenchDetailSplineActor::ScatterOverheadCover(FRandomStream& Stream)
{
	if (!bOverheadCover) return;

	const float Len = DetailSpline->GetSplineLength();
	// S17-TRWALL: Span is computed per segment inside the loop now.

	for (float D = 900.f; D < Len - 400.f; D += 1500.f)
	{
		if (Stream.FRand() > 0.30f * DetailDensity) continue;

		const FVector P = DetailSpline->GetLocationAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);
		const FVector Right = DetailSpline->GetRightVectorAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);
		const FRotator SplineRot = DetailSpline->GetRotationAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);
		const FVector Along = SplineRot.Vector();
		const float Span = (ParapetDistAt(D, -1.f) + ParapetDistAt(D, 1.f)) * 0.9f; // S17-TRWALL
		if (!WallHitAt(D, -1.f) || !WallHitAt(D, 1.f)) continue; // S17-TRGATE: no trench cut here -> no roof

		// S17-TRFIX: a roof RESTS on things — find both berm lips and lay the
		// planks from lip to lip (tilted if one side is higher). If a lip
		// doesn't exist (flat ground, blown berm), plant a post under that
		// end instead. Nothing floats.
		FVector LipL = P - Right * ParapetDistAt(D, -1.f);
		FVector LipR = P + Right * ParapetDistAt(D, 1.f);
		float LeftZ = P.Z, RightZ = P.Z;
		const bool bLHit = TraceGroundZ(LipL, LeftZ);
		const bool bRHit = TraceGroundZ(LipR, RightZ);
		float FloorZ = P.Z; TraceGroundZ(P, FloorZ);
		const float MinRoofZ = FloorZ + 190.f;
		LipL.Z = FMath::Max(bLHit ? LeftZ : MinRoofZ, MinRoofZ);
		LipR.Z = FMath::Max(bRHit ? RightZ : MinRoofZ, MinRoofZ);

		const FVector RoofDir = (LipR - LipL).GetSafeNormal();
		const FVector RoofMid = (LipL + LipR) * 0.5f + FVector(0.f, 0.f, 8.f);
		const float RoofLen = FVector::Dist(LipL, LipR) + 55.f; // small overhang
		const FRotator RoofRot = FRotationMatrix::MakeFromXZ(RoofDir, FVector::UpVector).Rotator();

		// Legs under any end that has no berm carrying it.
		for (int32 EndIdx = 0; EndIdx < 2; ++EndIdx)
		{
			// S17-TRGATE: a lip raised above its traced ground (flat terrain,
			// blown berm) carries nothing — that end needs a leg too.
			const bool bTraced = (EndIdx == 0) ? bLHit : bRHit;
			const float TracedZ = (EndIdx == 0) ? LeftZ : RightZ;
			FVector EndPos = (EndIdx == 0) ? LipL : LipR;
			if (bTraced && (EndPos.Z - TracedZ) < 40.f) continue; // berm truly carries this end
			float LegGroundZ = EndPos.Z;
			if (!TraceGroundZ(EndPos, LegGroundZ)) continue;
			const float LegH = EndPos.Z - LegGroundZ;
			if (LegH < 60.f) continue;
			HISM_Post->AddInstance(FTransform(FRotator::ZeroRotator,
				FVector(EndPos.X, EndPos.Y, LegGroundZ + LegH * 0.5f),
				FVector(0.10f, 0.10f, LegH / 100.f)), true);
		}

		// Cross-planks (HISM_Plank = cube planks, same weathered wood). S18-TRMESH
		const int32 PlankCount = Stream.RandRange(3, 5); // S17-TRWOOD: scarce timber — gaps between roof planks
		for (int32 i = 0; i < PlankCount; ++i)
		{
			if (Stream.FRand() < 0.08f) continue; // shell-shifted gap
			FVector PlankPos = RoofMid + Along * ((i - (PlankCount - 1) * 0.5f) * 44.f + Stream.FRandRange(-6.f, 6.f)); // S17-TRWOOD
			PlankPos.Z += Stream.FRandRange(-3.f, 3.f); // S17-TRMESH: uneven lie
			FRotator PlankRot = RoofRot;
			PlankRot.Yaw += Stream.FRandRange(-2.5f, 2.5f);
			PlankRot.Roll += Stream.FRandRange(-2.f, 2.f);
			// S17-TRMESH: scavenged planks — no two share length/width, ends
			// stick out unevenly past the lips.
			const float PlankLen = RoofLen / 100.f * Stream.FRandRange(0.88f, 1.08f);
			PlankPos += FRotationMatrix(PlankRot).GetUnitAxis(EAxis::X) * Stream.FRandRange(-12.f, 12.f);
			const float PlankW2 = Stream.FRandRange(0.17f, 0.30f);
			const FTransform RoofPlankXf(PlankRot, PlankPos,
				FVector(PlankLen, PlankW2, Stream.FRandRange(0.04f, 0.06f)));
			HISM_Plank->AddInstance(RoofPlankXf, true); // S18-TRMESH
			if (bRaggedPlankEnds) RagPlankEnds(HISM_Plank, RoofPlankXf, Stream); // S18-FIX
			// S17-TRWOOD: splintered ends — the silhouette must not be a ruler.
			const FVector PlankDir = FRotationMatrix(PlankRot).GetUnitAxis(EAxis::X);
			for (int32 End = 0; End < 2; ++End)
			{
				if (Stream.FRand() > 0.35f) continue;
				FVector SplPos = PlankPos + PlankDir * ((End == 0 ? -1.f : 1.f) * PlankLen * 50.f);
				FRotator SplRot = PlankRot;
				SplRot.Yaw += Stream.FRandRange(-9.f, 9.f);
				HISM_Plank->AddInstance(FTransform(SplRot, SplPos,
					FVector(Stream.FRandRange(0.08f, 0.16f), PlankW2 * Stream.FRandRange(0.30f, 0.55f), 0.04f)), true); // S18-TRMESH
			}
		}

		// Corrugated sheet laid on the planks, following the same tilt.
		FVector SheetPos = RoofMid + Along * Stream.FRandRange(-15.f, 15.f) + FVector(0.f, 0.f, 7.f);
		FRotator SheetRot = RoofRot;
		SheetRot.Yaw += Stream.FRandRange(-5.f, 5.f);
		HISM_Corrugated->AddInstance(FTransform(SheetRot, SheetPos,
			FVector(RoofLen * 0.8f / 100.f, Stream.FRandRange(1.65f, 2.0f), 0.035f)), true); // S17-TRPOLISH

		// S17-TRPOLISH: spoil heaped on the sheet — a bare plank deck reads
		// fake; real covers carry the excavated earth (reference shots).
		const int32 Lumps = Stream.RandRange(2, 3);
		for (int32 LumpIdx = 0; LumpIdx < Lumps; ++LumpIdx)
		{
			FVector LumpPos = SheetPos
				+ Along * Stream.FRandRange(-60.f, 60.f)
				+ FRotationMatrix(SheetRot).GetUnitAxis(EAxis::X) * Stream.FRandRange(-RoofLen * 0.22f, RoofLen * 0.22f)
				+ FVector(0.f, 0.f, 9.f);
			FRotator LumpRot = SheetRot;
			LumpRot.Yaw += Stream.FRandRange(-20.f, 20.f);
			HISM_FiringStep->AddInstance(FTransform(LumpRot, LumpPos,
				FVector(Stream.FRandRange(0.9f, 1.6f), Stream.FRandRange(0.9f, 1.5f), Stream.FRandRange(0.10f, 0.16f))), true);
		}
		// S17-TRPOLISH: half the covers get a camo net thrown over the top —
		// the single strongest cue from the reference scene.
		if (bCamoNetting && Stream.FRand() < 0.5f)
		{
			FRotator NetRot = SheetRot;
			NetRot.Yaw += Stream.FRandRange(-10.f, 10.f);
			NetRot.Pitch += Stream.FRandRange(-4.f, 4.f);
			HISM_Netting->AddInstance(FTransform(NetRot, SheetPos + FVector(0.f, 0.f, 22.f),
				FVector((RoofLen / 100.f) * Stream.FRandRange(1.05f, 1.2f), Stream.FRandRange(1.6f, 2.1f), 1.f)), true);
			// S17-TRWOOD: flaps falling over both lips — the thrown net gets
			// visible depth from the side instead of a paper line.
			const FVector AcrossDir = FRotationMatrix(NetRot).GetUnitAxis(EAxis::X);
			for (int32 Flap = 0; Flap < 2; ++Flap)
			{
				const float FSide = (Flap == 0) ? -1.f : 1.f;
				FVector FlapPos = SheetPos + AcrossDir * FSide * RoofLen * 0.5f + FVector(0.f, 0.f, 6.f);
				FRotator FlapRot = NetRot;
				FlapRot.Pitch += -FSide * Stream.FRandRange(50.f, 75.f);
				HISM_Netting->AddInstance(FTransform(FlapRot, FlapPos,
					FVector(Stream.FRandRange(0.5f, 0.8f), Stream.FRandRange(1.2f, 1.8f), 1.f)), true);
			}
		}
	}
}

// =====================================================================
//  S15-TRENCH2 COMM WIRE: field-telephone poles along one parapet with a
//  sagging line between them (the overhead wires in the reference shots).
// =====================================================================
void ATrenchDetailSplineActor::ScatterCommWire(FRandomStream& Stream)
{
	if (!bCommWire) return;

	const float Len = DetailSpline->GetSplineLength();
	const float Side = (Stream.FRand() < 0.5f) ? -1.f : 1.f; // one side per trench line
	const float PoleHeight = 260.f;

	FVector PrevTop = FVector::ZeroVector;
	bool bHavePrev = false;

	for (float D = 250.f; D < Len; D += 1200.f)
	{
		const FVector P = DetailSpline->GetLocationAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);
		const FVector Right = DetailSpline->GetRightVectorAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);

		FVector Pos = P + Right * Side * (ParapetDistAt(D, Side) + 70.f);
		float GroundZ = Pos.Z;
		if (!TraceGroundZ(Pos, GroundZ)) { bHavePrev = false; continue; }

		const FRotator PoleRot(Stream.FRandRange(-2.5f, 2.5f), Stream.FRandRange(0.f, 360.f), Stream.FRandRange(-2.5f, 2.5f));
		HISM_Post->AddInstance(FTransform(PoleRot, FVector(Pos.X, Pos.Y, GroundZ + PoleHeight * 0.5f), FVector(0.08f, 0.08f, PoleHeight / 100.f)), true);
		// S17-TRPOLISH: crossarm near the top — bare sticks read as fence
		// posts; field-telephone poles carry the line on a short arm.
		const float ArmYaw = DetailSpline->GetRotationAtDistanceAlongSpline(D, ESplineCoordinateSpace::World).Yaw + 90.f;
		HISM_Post->AddInstance(FTransform(FRotator(0.f, ArmYaw, Stream.FRandRange(-3.f, 3.f)),
			FVector(Pos.X, Pos.Y, GroundZ + PoleHeight - 24.f), FVector(0.55f, 0.055f, 0.05f)), true);

		const FVector Top(Pos.X, Pos.Y, GroundZ + PoleHeight - 6.f);
		if (bHavePrev)
		{
			const float Gap = FVector::Dist(PrevTop, Top);
			if (Gap > 200.f && Gap < 1600.f)
			{
				// 3-segment sagging catenary approximation.
				const float SagDepth = Gap * 0.045f;
				FVector Pts[4];
				for (int32 i = 0; i < 4; ++i)
				{
					const float T = i / 3.f;
					Pts[i] = FMath::Lerp(PrevTop, Top, T);
					Pts[i].Z -= SagDepth * 4.f * T * (1.f - T);
				}
				for (int32 i = 0; i < 3; ++i)
				{
					const FVector Mid = (Pts[i] + Pts[i + 1]) * 0.5f;
					const FVector Dir = (Pts[i + 1] - Pts[i]).GetSafeNormal();
					const float SegLen = FVector::Dist(Pts[i], Pts[i + 1]);
					HISM_Wire->AddInstance(FTransform(FRotationMatrix::MakeFromZ(Dir).Rotator(), Mid, FVector(0.014f, 0.014f, SegLen / 100.f)), true);
				}
			}
		}
		PrevTop = Top;
		bHavePrev = true;
	}
}

// =====================================================================
//  S18-TRBAG: sandbag revetting
//  Runs of stacked bags along the parapet lip (the single most recognisable
//  trench silhouette), plus loose bags slumped at the foot of the wall.
//  Does nothing unless a sandbag mesh is assigned, so existing maps are
//  unaffected until you give it the props.
// =====================================================================
void ATrenchDetailSplineActor::ScatterSandbags(FRandomStream& Stream)
{
	if (!bSandbags) return;
	UStaticMesh* StackMesh = CustomSandbagStackMesh.Get();
	UStaticMesh* BagMesh = CustomSandbagMesh.Get();
	if (!StackMesh && !BagMesh) return;

	const float Len = DetailSpline->GetSplineLength();
	// A run is a continuous stretch of bags; between runs the parapet is bare.
	const float StackStep = 80.f;  // bags overlap slightly along the lip

	for (int32 SideIdx = 0; SideIdx < 2; ++SideIdx)
	{
		const float Side = (SideIdx == 0) ? -1.f : 1.f;
		float D = Stream.FRandRange(150.f, 700.f);
		while (D < Len - 150.f)
		{
			// Gap, then a run of 3-9 stacks (240-720 cm of revetting).
			const float RunLen = Stream.FRandRange(240.f, 720.f);
			const float RunEnd = FMath::Min(D + RunLen, Len - 100.f);
			const bool bQuiet = IsRestZone(D);
			const float RunRoll = Stream.FRand();
			if (bQuiet || RunRoll > 0.75f * DetailDensity)
			{
				D = RunEnd + Stream.FRandRange(500.f, 1700.f);
				continue;
			}

			// Two courses high on about a third of the runs.
			const int32 Courses = (StackMesh && Stream.FRand() < 0.33f) ? 2 : 1;

			for (float Pos = D; Pos < RunEnd; Pos += StackStep)
			{
				if (!WallHitAt(Pos, Side)) continue;
				if (Stream.FRand() < 0.07f) continue; // shell-blown gap

				const FVector P = DetailSpline->GetLocationAtDistanceAlongSpline(Pos, ESplineCoordinateSpace::World);
				FVector Right = DetailSpline->GetRightVectorAtDistanceAlongSpline(Pos, ESplineCoordinateSpace::World);
				Right.Z = 0.f;
				if (!Right.Normalize()) continue;
				const float Yaw = DetailSpline->GetRotationAtDistanceAlongSpline(Pos, ESplineCoordinateSpace::World).Yaw;

				FVector Lip = P + Right * Side * (ParapetDistAt(Pos, Side) - Stream.FRandRange(10.f, 35.f));
				float GroundZ = Lip.Z;
				FVector GroundN = FVector::UpVector;
				if (!TraceGround(Lip, GroundZ, GroundN)) continue;

				UStaticMesh* Use = StackMesh ? StackMesh : BagMesh;
				UHierarchicalInstancedStaticMeshComponent* Target = StackMesh ? HISM_SandbagStack : HISM_Sandbag;
				if (!Target || !Use) continue;

				// Bags are laid by hand: every one is a little off.
				const float CourseH = (Use == StackMesh) ? 95.f : 20.f;
				for (int32 C = 0; C < Courses; ++C)
				{
					if (C > 0 && Stream.FRand() < 0.25f) continue; // upper course thins out
					const FRotator Rot(
						Stream.FRandRange(-3.f, 3.f),
						Yaw + Stream.FRandRange(-7.f, 7.f),
						Stream.FRandRange(-4.f, 4.f));
					const FVector At(Lip.X + Stream.FRandRange(-6.f, 6.f),
						Lip.Y + Stream.FRandRange(-6.f, 6.f),
						GroundZ + C * CourseH * Stream.FRandRange(0.88f, 0.98f));
					Target->AddInstance(FTransform(Rot, At, FVector(CustomMeshScale)), true);
				}

				// A bag or two that slid down into the trench.
				if (BagMesh && HISM_Sandbag && Stream.FRand() < 0.10f)
				{
					FVector Fall = P + Right * Side * (WallDistAt(Pos, Side) - Stream.FRandRange(40.f, 110.f));
					float FZ = Fall.Z;
					if (TraceGroundZ(Fall, FZ))
					{
						HISM_Sandbag->AddInstance(FTransform(
							FRotator(Stream.FRandRange(-12.f, 12.f), Stream.FRandRange(0.f, 360.f), Stream.FRandRange(-12.f, 12.f)),
							FVector(Fall.X, Fall.Y, FZ + 9.f), FVector(CustomMeshScale)), true);
					}
				}
			}
			D = RunEnd + Stream.FRandRange(500.f, 1700.f);
		}
	}
}

// =====================================================================
//  S18-TRWIRE: barbed-wire entanglement runs
//  Lays a real wire-run prop end-to-end out past the parapet, instead of
//  (or alongside) the per-segment cylinder wire. Mesh is assumed to run
//  along its local +X for WireSetLengthCm.
// =====================================================================
void ATrenchDetailSplineActor::ScatterWireSets(FRandomStream& Stream)
{
	if (!bWireSets) return;

	// S18-FIX: up to 4 different wire-run props, mixed along the belt so the
	// entanglement never reads as one stamped mesh repeated forever.
	struct FWireOption { UStaticMesh* Mesh; UHierarchicalInstancedStaticMeshComponent* HISM; float Len; };
	TArray<FWireOption, TInlineAllocator<6>> Options; // S18-TRWIRE2: 6 slots
	auto AddOption = [&Options](UStaticMesh* M, UHierarchicalInstancedStaticMeshComponent* H, float L)
	{
		if (M && H) Options.Add({ M, H, FMath::Max(50.f, L) });
	};
	AddOption(CustomWireSetMesh.Get(), HISM_WireSet, WireSetLengthCm);
	AddOption(CustomWireSetMesh2.Get(), HISM_WireSet2, WireSetLengthCm2);
	AddOption(CustomWireSetMesh3.Get(), HISM_WireSet3, WireSetLengthCm3);
	AddOption(CustomWireSetMesh4.Get(), HISM_WireSet4, WireSetLengthCm4);
	AddOption(CustomWireSetMesh5.Get(), HISM_WireSet5, WireSetLengthCm5); // S18-TRWIRE2
	AddOption(CustomWireSetMesh6.Get(), HISM_WireSet6, WireSetLengthCm6); // S18-TRWIRE2
	if (Options.Num() == 0) return;

	const float Len = DetailSpline->GetSplineLength();

	for (int32 SideIdx = 0; SideIdx < 2; ++SideIdx)
	{
		const float Side = (SideIdx == 0) ? -1.f : 1.f;
		if (SideIdx == 1 && Stream.FRand() < 0.45f) continue; // not always both sides

		const float StandOff = Stream.FRandRange(150.f, 260.f); // clear of the berm
		float D = Stream.FRandRange(60.f, 260.f);

		while (D < Len - 100.f)
		{
			const FWireOption& Opt = Options[Stream.RandRange(0, Options.Num() - 1)];
			const float SetLen = Opt.Len * CustomMeshScale;
			if (D + SetLen * 0.5f > Len - 60.f) break;

			const float Centre = D + SetLen * 0.5f;
			if (Stream.FRand() < 0.16f || IsRestZone(Centre)) // blown gap / quiet stretch
			{
				D += SetLen * Stream.FRandRange(0.6f, 1.1f);
				continue;
			}

			const FVector P = DetailSpline->GetLocationAtDistanceAlongSpline(Centre, ESplineCoordinateSpace::World);
			FVector Right = DetailSpline->GetRightVectorAtDistanceAlongSpline(Centre, ESplineCoordinateSpace::World);
			Right.Z = 0.f;
			if (!Right.Normalize()) { D += SetLen; continue; }
			const float Yaw = DetailSpline->GetRotationAtDistanceAlongSpline(Centre, ESplineCoordinateSpace::World).Yaw;

			FVector At = P + Right * Side * (ParapetDistAt(Centre, Side) + StandOff + Stream.FRandRange(-25.f, 25.f));
			float GroundZ = At.Z;
			FVector GroundN = FVector::UpVector;
			if (!TraceGround(At, GroundZ, GroundN)) { D += SetLen; continue; }
			At.Z = GroundZ - Stream.FRandRange(0.f, 6.f); // bedded into the dirt

			const FRotator Rot(
				Stream.FRandRange(-2.f, 2.f),
				Yaw + Stream.FRandRange(-6.f, 6.f) + (Stream.FRand() < 0.5f ? 0.f : 180.f),
				Stream.FRandRange(-3.f, 3.f));
			Opt.HISM->AddInstance(FTransform(Rot, At, FVector(CustomMeshScale)), true);

			// S18-TRWIRE2: the wire does not float. Stand this run on wooden
			// X-frames (knife rests) — one under each end — for WireObstacleFraction
			// of the belt. The frame is authored long-axis +X, same as the run, so
			// it inherits the run's yaw and simply sits under it.
			const bool bOnFrames = CustomWireObstacleMesh && bWireObstacles
				&& HISM_WireObstacle && Stream.FRand() < WireObstacleFraction;
			if (bOnFrames)
			{
				const float FrameLen = FMath::Max(50.f, WireObstacleLengthCm) * CustomMeshScale;
				const int32 FrameCount = FMath::Clamp(FMath::RoundToInt(SetLen / FrameLen), 1, 6);
				const FVector Along = FRotationMatrix(FRotator(0.f, Yaw, 0.f)).GetUnitAxis(EAxis::X);
				for (int32 FI = 0; FI < FrameCount; ++FI)
				{
					// Spread the frames evenly under the run, centred on it.
					const float T = (FrameCount == 1) ? 0.f
						: (static_cast<float>(FI) / (FrameCount - 1) - 0.5f) * (SetLen - FrameLen);
					FVector FrameAt = At + Along * T + Right * Side * Stream.FRandRange(-8.f, 8.f);
					float FZ = FrameAt.Z;
					FVector FN = FVector::UpVector;
					if (!TraceGround(FrameAt, FZ, FN)) continue;
					FrameAt.Z = FZ - Stream.FRandRange(0.f, 4.f); // feet bedded in
					HISM_WireObstacle->AddInstance(FTransform(
						FRotator(Stream.FRandRange(-2.5f, 2.5f),
							Yaw + Stream.FRandRange(-5.f, 5.f),
							Stream.FRandRange(-2.5f, 2.5f)),
						FrameAt, FVector(CustomMeshScale)), true);
				}
			}

			// S18-TRWIRE2: a loose coil slumped against the belt every so often.
			if (Stream.FRand() < 0.22f)
			{
				UHierarchicalInstancedStaticMeshComponent* CoilH = nullptr;
				if (CustomWireCoilMesh && HISM_WireCoil && (!CustomWireCoilMesh2 || Stream.FRand() < 0.5f))
				{
					CoilH = HISM_WireCoil;
				}
				else if (CustomWireCoilMesh2 && HISM_WireCoil2)
				{
					CoilH = HISM_WireCoil2;
				}
				if (CoilH)
				{
					FVector CoilAt = At + Right * Side * Stream.FRandRange(40.f, 95.f);
					float CZ = CoilAt.Z;
					if (TraceGroundZ(CoilAt, CZ))
					{
						CoilH->AddInstance(FTransform(
							FRotator(Stream.FRandRange(-5.f, 5.f), Stream.FRandRange(0.f, 360.f), Stream.FRandRange(-5.f, 5.f)),
							FVector(CoilAt.X, CoilAt.Y, CZ - 2.f), FVector(CustomMeshScale)), true);
					}
				}
			}

			// A picket hammered in at the joint sells the belt as emplaced.
			// S18-TRWIRE2: prefer the pack's iron pigtail over the cube stake, and
			// skip pickets entirely where the run already stands on X-frames.
			if (bWirePickets && !bOnFrames && Stream.FRand() < 0.45f)
			{
				FVector StakeAt = At + Right * Side * Stream.FRandRange(-20.f, 20.f);
				float SZ = StakeAt.Z;
				if (TraceGroundZ(StakeAt, SZ))
				{
					if (CustomPigtailMesh && HISM_Pigtail)
					{
						HISM_Pigtail->AddInstance(FTransform(
							FRotator(Stream.FRandRange(-5.f, 5.f), Stream.FRandRange(0.f, 360.f), Stream.FRandRange(-5.f, 5.f)),
							FVector(StakeAt.X, StakeAt.Y, SZ), FVector(CustomMeshScale)), true);
					}
					else if (HISM_Stake)
					{
						const bool bCustomStake = CustomStakeMesh != nullptr;
						HISM_Stake->AddInstance(FTransform(
							FRotator(Stream.FRandRange(-6.f, 6.f), Stream.FRandRange(0.f, 360.f), Stream.FRandRange(-6.f, 6.f)),
							FVector(StakeAt.X, StakeAt.Y, SZ + (bCustomStake ? 0.f : 35.f)),
							bCustomStake ? FVector(CustomMeshScale) : FVector(0.07f, 0.07f, 0.7f)), true);
					}
				}
			}

			D += SetLen * Stream.FRandRange(0.94f, 1.02f); // slight overlap or a hair of gap
		}
	}
}

// =====================================================================
//  S18-TRWIRE2: standalone wooden X-frame obstacles (knife rests).
//  Separate from the wire belt: these are the blocks dragged across
//  approaches, communication-trench mouths and the road, usually in a
//  short staggered row, sometimes toppled.
// =====================================================================
void ATrenchDetailSplineActor::ScatterWireObstacles(FRandomStream& Stream)
{
	if (!bWireObstacles || !CustomWireObstacleMesh || !HISM_WireObstacle) return;
	if (StandaloneObstacles <= 0) return;

	const float Len = DetailSpline->GetSplineLength();
	const float FrameLen = FMath::Max(50.f, WireObstacleLengthCm) * CustomMeshScale;
	const int32 Groups = FMath::Max(1, FMath::RoundToInt(StandaloneObstacles * FMath::Max(0.25f, DetailDensity) * 0.5f));

	for (int32 G = 0; G < Groups; ++G)
	{
		const float D = Stream.FRandRange(80.f, FMath::Max(120.f, Len - 80.f));
		if (IsRestZone(D)) continue;

		const float Side = (Stream.FRand() < 0.5f) ? -1.f : 1.f;
		const FVector P = DetailSpline->GetLocationAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);
		FVector Right = DetailSpline->GetRightVectorAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);
		Right.Z = 0.f;
		if (!Right.Normalize()) continue;
		const float Yaw = DetailSpline->GetRotationAtDistanceAlongSpline(D, ESplineCoordinateSpace::World).Yaw;

		// A row of 1-3 frames, staggered, angled across the approach rather than
		// parallel to the trench — that is how they are actually emplaced.
		const int32 Count = Stream.RandRange(1, 3);
		const float BaseYaw = Yaw + Stream.FRandRange(50.f, 130.f) * ((Stream.FRand() < 0.5f) ? -1.f : 1.f);
		const FVector Along = FRotationMatrix(FRotator(0.f, BaseYaw, 0.f)).GetUnitAxis(EAxis::X);
		const float StandOff = ParapetDistAt(D, Side) + Stream.FRandRange(260.f, 520.f);

		for (int32 I = 0; I < Count; ++I)
		{
			FVector At = P + Right * Side * StandOff
				+ Along * (I * FrameLen * Stream.FRandRange(0.82f, 0.95f))
				+ Right * Side * Stream.FRandRange(-40.f, 40.f);
			float GZ = At.Z;
			FVector GN = FVector::UpVector;
			if (!TraceGround(At, GZ, GN)) continue;
			At.Z = GZ - Stream.FRandRange(0.f, 5.f);

			// One in eight has been shoved over by a blast or a vehicle.
			const bool bToppled = Stream.FRand() < 0.12f;
			const FRotator Rot = bToppled
				? FRotator(Stream.FRandRange(-8.f, 8.f), BaseYaw + Stream.FRandRange(-20.f, 20.f), Stream.FRandRange(58.f, 85.f) * ((Stream.FRand() < 0.5f) ? -1.f : 1.f))
				: FRotator(Stream.FRandRange(-3.f, 3.f), BaseYaw + Stream.FRandRange(-8.f, 8.f), Stream.FRandRange(-3.f, 3.f));
			HISM_WireObstacle->AddInstance(FTransform(Rot, At, FVector(CustomMeshScale)), true);

			// Short wire run laid over the row where we have one that fits.
			if (!bToppled && CustomWireSetMesh5 && HISM_WireSet5 && Stream.FRand() < 0.5f)
			{
				HISM_WireSet5->AddInstance(FTransform(
					FRotator(0.f, BaseYaw + Stream.FRandRange(-6.f, 6.f), 0.f),
					At + FVector(0.f, 0.f, 10.f), FVector(CustomMeshScale)), true);
			}
		}
	}
}

// =====================================================================
//  S18-FIX: ragged plank ends. A cube plank has four perfect corners and
//  reads as furniture. This bites chunks out of both ends and leaves a
//  splinter or two, so the silhouette is hand-split war timber.
//  Scale is (LengthX, WidthY, ThickZ) in metres, like the rest of the code.
// =====================================================================
void ATrenchDetailSplineActor::RagPlankEnds(UHierarchicalInstancedStaticMeshComponent* Target,
	const FTransform& PlankXf, FRandomStream& Stream) const
{
	if (!Target) return;
	const FVector S = PlankXf.GetScale3D();
	const FRotator R = PlankXf.Rotator();
	const FVector Along = FRotationMatrix(R).GetUnitAxis(EAxis::X);
	const FVector Across = FRotationMatrix(R).GetUnitAxis(EAxis::Y);
	const FVector Up = FRotationMatrix(R).GetUnitAxis(EAxis::Z);
	const FVector C = PlankXf.GetLocation();

	for (int32 End = 0; End < 2; ++End)
	{
		const float Sgn = (End == 0) ? -1.f : 1.f;
		const FVector EndMid = C + Along * (Sgn * S.X * 50.f);

		// 1-2 corner bites: a small negative-looking notch made by laying a
		// short sliver slightly off-axis across the corner.
		const int32 Bites = Stream.RandRange(1, 2);
		for (int32 b = 0; b < Bites; ++b)
		{
			const float LatSgn = (Stream.FRand() < 0.5f) ? -1.f : 1.f;
			const FVector BitePos = EndMid
				+ Across * (LatSgn * S.Y * Stream.FRandRange(18.f, 42.f))
				- Along * (Sgn * S.X * Stream.FRandRange(2.f, 7.f))
				+ Up * Stream.FRandRange(-0.4f, 0.4f);
			const FRotator BiteRot(R.Pitch + Stream.FRandRange(-6.f, 6.f),
				R.Yaw + Stream.FRandRange(-22.f, 22.f),
				R.Roll + Stream.FRandRange(-8.f, 8.f));
			Target->AddInstance(FTransform(BiteRot, BitePos,
				FVector(S.X * Stream.FRandRange(0.06f, 0.14f),
					S.Y * Stream.FRandRange(0.25f, 0.55f),
					S.Z * Stream.FRandRange(0.9f, 1.15f))), true);
		}

		// A splinter spiking past the end on about half of them.
		if (Stream.FRand() < 0.5f)
		{
			const FVector SplPos = EndMid + Along * (Sgn * S.X * Stream.FRandRange(3.f, 9.f))
				+ Across * (S.Y * Stream.FRandRange(-25.f, 25.f));
			const FRotator SplRot(R.Pitch + Stream.FRandRange(-4.f, 4.f),
				R.Yaw + Stream.FRandRange(-13.f, 13.f),
				R.Roll + Stream.FRandRange(-5.f, 5.f));
			Target->AddInstance(FTransform(SplRot, SplPos,
				FVector(S.X * Stream.FRandRange(0.08f, 0.18f),
					S.Y * Stream.FRandRange(0.12f, 0.3f),
					S.Z * Stream.FRandRange(0.5f, 0.9f))), true);
		}
	}
}

// =====================================================================
//  FLOOR: duckboard walkway runs + barrels + ammo-can clusters
// =====================================================================
void ATrenchDetailSplineActor::ScatterFloorLine(FRandomStream& Stream)
{
	const float Len = DetailSpline->GetSplineLength();
	const bool bCustomBoard = CustomDuckboardMesh != nullptr;

	// S17-TRVAR: slumped earth where wall meets floor. A dead-straight
	// crease along the whole trench reads CAD — random piles of collapsed
	// spoil break the line (only where a real wall exists to slump from).
	for (float SlumpD = 150.f; SlumpD < Len; SlumpD += 500.f)
	{
		if (Stream.FRand() > 0.45f * DetailDensity) continue;
		const float Side = (Stream.FRand() < 0.5f) ? -1.f : 1.f;
		if (!WallHitAt(SlumpD, Side)) continue;
		const FVector P = DetailSpline->GetLocationAtDistanceAlongSpline(SlumpD, ESplineCoordinateSpace::World);
		const FVector Right = DetailSpline->GetRightVectorAtDistanceAlongSpline(SlumpD, ESplineCoordinateSpace::World);
		FVector Pos = P + Right * Side * (WallDistAt(SlumpD, Side) - Stream.FRandRange(18.f, 48.f));
		float GZ = Pos.Z;
		if (!TraceGroundZ(Pos, GZ)) continue;
		const int32 NumLumps = Stream.RandRange(1, 3);
		for (int32 LumpIdx = 0; LumpIdx < NumLumps; ++LumpIdx)
		{
			FVector LPos = Pos + FVector(Stream.FRandRange(-45.f, 45.f), Stream.FRandRange(-45.f, 45.f), 0.f);
			float LZ = GZ; TraceGroundZ(LPos, LZ);
			const float LumpW = Stream.FRandRange(0.55f, 1.1f);
			HISM_FiringStep->AddInstance(FTransform(
				FRotator(Stream.FRandRange(-4.f, 4.f), Stream.FRandRange(0.f, 360.f), Stream.FRandRange(-4.f, 4.f)),
				FVector(LPos.X, LPos.Y, LZ + Stream.FRandRange(2.f, 8.f)),
				FVector(LumpW, LumpW * Stream.FRandRange(0.6f, 0.9f), Stream.FRandRange(0.10f, 0.22f))), true);
		}
	}

	// -- Duckboards: 120 cm sections with gaps and jitter, in intermittent runs.
	if (bDuckboards)
	{
		bool bInRun = true;
		// S19-TREDGE: stay clear of both spline ends (was a hard-coded 60 .. Len).
		const float D0 = FMath::Max(60.f, EndMarginCm);
		const float D1 = FMath::Max(D0 + 1.f, Len - EndMarginCm);
		for (float D = D0; D < D1; D += 130.f)
		{
			// Runs start/stop so the walkway looks scavenged, not factory-laid.
			if (Stream.FRand() < 0.10f) bInRun = !bInRun; // S17-TRWOOD: shorter scavenged runs
			if (!bInRun || Stream.FRand() > 0.60f * DetailDensity) continue; // S17-TRWOOD: wood is rationed

			const FVector P = DetailSpline->GetLocationAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);
			const FVector Right = DetailSpline->GetRightVectorAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);
			const FRotator SplineRot = DetailSpline->GetRotationAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);

			FVector Pos = P + Right * Stream.FRandRange(-25.f, 25.f);
			float GroundZ = Pos.Z;
			FVector GroundN = FVector::UpVector;
			TraceGround(Pos, GroundZ, GroundN); // S15-TRENCH6: keep the normal
			Pos.Z = GroundZ + 3.f;

			// S15-TRENCH6: boards conform to the floor slope (yaw jitter kept).
			const FVector YawDir = FRotator(0.f, SplineRot.Yaw + Stream.FRandRange(-7.f, 7.f), 0.f).Vector();
			const FRotator Rot = FRotationMatrix::MakeFromZX(GroundN, YawDir).Rotator();
			if (bCustomBoard)
			{
				HISM_Duckboard->AddInstance(FTransform(Rot, Pos, FVector(CustomMeshScale)), true);
			}
			else
			{
				// S15-TRENCH2: individual planks with gaps + height jitter, not one slab.
				const FVector Across = FRotationMatrix(Rot).GetUnitAxis(EAxis::Y);
				for (int32 k = 0; k < 4; ++k)
				{
					if (Stream.FRand() < 0.06f) continue; // missing plank
					FVector PlankPos = Pos + Across * ((k - 1.5f) * 24.f);
					PlankPos.Z += Stream.FRandRange(-1.5f, 1.5f);
					// S15-TRENCH6: planks stay slope-aligned like the section.
					const FVector PlankYawDir = FRotator(0.f, Rot.Yaw + Stream.FRandRange(-1.5f, 1.5f), 0.f).Vector();
					const FRotator PlankRot = FRotationMatrix::MakeFromZX(GroundN, PlankYawDir).Rotator();
					const FTransform BoardPlankXf(PlankRot, PlankPos, FVector(1.25f, 0.20f, 0.045f));
					HISM_Duckboard->AddInstance(BoardPlankXf, true);
					if (bRaggedPlankEnds && Stream.FRand() < 0.45f) RagPlankEnds(HISM_Duckboard, BoardPlankXf, Stream); // S18-FIX
				}
			}

			// Occasional loose skewed plank beside the walkway (not in rest zones).
			if (!bCustomBoard && Stream.FRand() < 0.12f && !IsRestZone(D))
			{
				FVector LoosePos = P + Right * Stream.FRandRange(-FloorHalfAt(D) * 0.7f, FloorHalfAt(D) * 0.7f);
				float LZ = LoosePos.Z; TraceGroundZ(LoosePos, LZ); LoosePos.Z = LZ + 4.f;
				const FRotator LooseRot(0.f, SplineRot.Yaw + Stream.FRandRange(-40.f, 40.f), Stream.FRandRange(-4.f, 4.f));
				HISM_Duckboard->AddInstance(FTransform(LooseRot, LoosePos, FVector(0.9f, 0.16f, 0.035f)), true);
			}
		}
	}

	// -- Barrels: hug the walls, some tipped over.
	if (bBarrels)
	{
		const bool bCustomBarrel = CustomBarrelMesh != nullptr;
		for (float D = 300.f; D < Len; D += 900.f)
		{
			if (Stream.FRand() > 0.50f * DetailDensity) continue;

			// S15-TRENCH8: 60% of barrels gravitate to the nearest story anchor
			// (firing step / dugout) — clustered vignettes, not uniform noise.
			// Strays that land in a rest zone are dropped to keep it quiet.
			float BarrelD = D + Stream.FRandRange(-200.f, 200.f);
			if (ClusterAnchors.Num() > 0 && Stream.FRand() < 0.60f)
			{
				float Nearest = ClusterAnchors[0];
				for (const float A : ClusterAnchors)
				{
					if (FMath::Abs(A - D) < FMath::Abs(Nearest - D)) Nearest = A;
				}
				BarrelD = Nearest + Stream.FRandRange(90.f, 240.f) * (Stream.FRand() < 0.5f ? -1.f : 1.f);
			}
			else if (IsRestZone(BarrelD))
			{
				continue;
			}
			// S19-TREDGE: keep the drum inside the dressed run (was 50 .. Len-50,
			// which let a scaled custom barrel hang off the end of the spline).
			BarrelD = FMath::Clamp(BarrelD, EndMarginCm, FMath::Max(EndMarginCm + 1.f, Len - EndMarginCm));

			const FVector P = DetailSpline->GetLocationAtDistanceAlongSpline(BarrelD, ESplineCoordinateSpace::World);
			const FVector Right = DetailSpline->GetRightVectorAtDistanceAlongSpline(BarrelD, ESplineCoordinateSpace::World);
			const float Side = (Stream.FRand() < 0.5f) ? -1.f : 1.f;

			// S19-TREDGE: measure the wall at BarrelD, not at the loop's D. The
			// barrel can be jittered up to 200cm away (or snapped to a cluster
			// anchor), and reading the width at the wrong station pushed drums
			// into the wall on wide/narrow stretches — or left them floating.
			FVector Pos = P + Right * Side * (WallDistAt(BarrelD, Side) - 70.f);
			float GroundZ = Pos.Z;
			FVector GroundN = FVector::UpVector;
			TraceGround(Pos, GroundZ, GroundN); // S15-TRENCH7: slope-aware barrels

			const bool bTipped = Stream.FRand() < 0.25f;
			const FVector Hit(Pos.X, Pos.Y, GroundZ);
			const FVector RandFlat = FRotator(0.f, Stream.FRandRange(0.f, 360.f), 0.f).Vector();

			if (bCustomBarrel)
			{
				HISM_Barrel->AddInstance(FTransform(FRotator(bTipped ? 90.f : 0.f, Stream.FRandRange(0.f, 360.f), 0.f), Hit, FVector(CustomMeshScale)), true);
			}
			else if (bTipped)
			{
				// Drum lies IN the ground plane: axis = random direction projected onto it.
				const FVector Axis = FVector::VectorPlaneProject(RandFlat, GroundN).GetSafeNormal();
				const float DrumR = Stream.FRandRange(0.54f, 0.64f); // S17-TRPOLISH: no two drums identical
				HISM_Barrel->AddInstance(FTransform(
					FRotationMatrix::MakeFromZ(Axis).Rotator(),
					Hit + GroundN * DrumR * 50.f, FVector(DrumR, DrumR, Stream.FRandRange(0.82f, 0.95f))), true);
			}
			else
			{
				// Upright drum tilts with the ground it stands on.
				const float DrumR = Stream.FRandRange(0.54f, 0.64f); // S17-TRPOLISH
				const float DrumH = Stream.FRandRange(0.82f, 0.95f);
				HISM_Barrel->AddInstance(FTransform(
					FRotationMatrix::MakeFromZX(GroundN, RandFlat).Rotator(),
					Hit + GroundN * DrumH * 50.f, FVector(DrumR, DrumR, DrumH)), true);
			}
		}
	}

	// -- Ammo-can clusters near the walls.
	if (bAmmoCans)
	{
		const bool bCustomCan = CustomAmmoCanMesh != nullptr;
		for (float D = 450.f; D < Len; D += 700.f)
		{
			if (Stream.FRand() > 0.45f * DetailDensity) continue;

			// S15-TRENCH8: same clustering rule as barrels.
			float CanD = D;
			if (ClusterAnchors.Num() > 0 && Stream.FRand() < 0.60f)
			{
				float Nearest = ClusterAnchors[0];
				for (const float A : ClusterAnchors)
				{
					if (FMath::Abs(A - D) < FMath::Abs(Nearest - D)) Nearest = A;
				}
				CanD = Nearest + Stream.FRandRange(70.f, 200.f) * (Stream.FRand() < 0.5f ? -1.f : 1.f);
			}
			else if (IsRestZone(CanD))
			{
				continue;
			}
			CanD = FMath::Clamp(CanD, EndMarginCm, FMath::Max(EndMarginCm + 1.f, Len - EndMarginCm));

			const FVector P = DetailSpline->GetLocationAtDistanceAlongSpline(CanD, ESplineCoordinateSpace::World);
			const FVector Right = DetailSpline->GetRightVectorAtDistanceAlongSpline(CanD, ESplineCoordinateSpace::World);
			const float Side = (Stream.FRand() < 0.5f) ? -1.f : 1.f;
			// S19-TREDGE: wall width at the can's own station (was D).
			const FVector Base = P + Right * Side * (WallDistAt(CanD, Side) - 90.f);

			const int32 Count = Stream.RandRange(2, 4);
			for (int32 i = 0; i < Count; ++i)
			{
				FVector Pos = Base + FVector(Stream.FRandRange(-45.f, 45.f), Stream.FRandRange(-45.f, 45.f), 0.f);
				float GroundZ = Pos.Z; TraceGroundZ(Pos, GroundZ);
				Pos.Z = GroundZ + (bCustomCan ? 0.f : 9.f);
				const FVector Scale = bCustomCan ? FVector(CustomMeshScale) : FVector(0.30f, 0.16f, 0.18f);
				HISM_AmmoCan->AddInstance(FTransform(FRotator(0.f, Stream.FRandRange(0.f, 360.f), 0.f), Pos, Scale), true);
			}
		}
	}
}

// =====================================================================
//  WALLS: revetment planks, corrugated sheets, posts, firing steps, tarps
// =====================================================================
void ATrenchDetailSplineActor::ScatterWalls(FRandomStream& Stream)
{
	const float Len = DetailSpline->GetSplineLength();
	const bool bCustomRevet = CustomRevetmentMesh != nullptr;

	// S15-TRENCH4: COD-style trenches are shored floor-to-lip almost continuously,
	// not dressed with occasional panels. Tight step + high odds when enabled.
	const float WallStep = bContinuousShoring ? 175.f : 400.f;
	// S17-TRWOOD: Khuzestan front — timber was SCARCE (no forests, supply
	// went to bunker roofs first). Corrugated sheet and bare earth carry the
	// shoring; wood plank panels are the exception, not the rule.
	const float RevetChance = bContinuousShoring ? 0.30f : 0.16f;
	const float CorrChance  = bContinuousShoring ? 0.78f : 0.48f;

	for (float D = 200.f; D < Len; D += WallStep)
	{
		const FVector P = DetailSpline->GetLocationAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);
		const FVector Right = DetailSpline->GetRightVectorAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);
		const FRotator SplineRot = DetailSpline->GetRotationAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);

		for (int32 SideIdx = 0; SideIdx < 2; ++SideIdx)
		{
			const float Side = (SideIdx == 0) ? -1.f : 1.f;

			// Revetment plank panel leaning against this wall?
			if (bRevetment && WallHitAt(D, Side) && Stream.FRand() < RevetChance * DetailDensity) // S17-TRGATE
			{
				FVector Pos = P + Right * Side * WallDistAt(D, Side);
				float GroundZ = Pos.Z; TraceGroundZ(Pos, GroundZ);
				Pos.Z = GroundZ + 42.f;

				// S17-TRWALL2: lay AGAINST the real wall — its slope plus a
				// small contact jitter (vertical wall -> 5-10, like before).
				float Lean = (WallLeanAt(D, Side) + Stream.FRandRange(5.f, 10.f)) * -Side;

				// S15-TRENCH5: battle damage — some panels blown loose: tilted
				// hard off the wall, sunk, skewed, with planks fallen at the base.
				const bool bCollapsed = bBattleDamage && Stream.FRand() < 0.12f;
				if (bCollapsed)
				{
					Lean = Stream.FRandRange(26.f, 42.f) * -Side;
					Pos.Z -= Stream.FRandRange(8.f, 18.f);
					Pos -= Right * Side * Stream.FRandRange(15.f, 40.f); // slid off the wall
				}
				const FRotator Rot(bCollapsed ? Stream.FRandRange(-9.f, 9.f) : 0.f,
					SplineRot.Yaw + (bCollapsed ? Stream.FRandRange(-16.f, 16.f) : Stream.FRandRange(-5.f, 5.f)),
					Lean);
				if (bCustomRevet)
				{
					HISM_Revetment->AddInstance(FTransform(Rot, Pos, FVector(CustomMeshScale)), true);
				}
				else
				{
					// S17-TRMESH: a revetment is individual planks rammed in by
					// hand, not one CAD board. 5-7 narrow planks, each its own
					// height/width/tilt, some sunk, some broken, some missing,
					// pinned by a horizontal waler.
					int32 NumPlanks = Stream.RandRange(5, 7);
					float Span = Stream.FRandRange(140.f, 175.f);
					// S19-TREDGE: a row wider than the wall step overlaps its
					// neighbours (fine — continuous shoring should read as one
					// shored face) but a row much wider than the trench is bent
					// spills past a corner. Cap it to the local step.
					Span = FMath::Min(Span, WallStep * 1.05f);
					for (int32 PlankIdx = 0; PlankIdx < NumPlanks; ++PlankIdx)
					{
						if (Stream.FRand() < 0.10f) continue; // plank torn out
						const float Frac = (NumPlanks <= 1) ? 0.5f : (float)PlankIdx / (NumPlanks - 1);
						const float AlongOffset = (Frac - 0.5f) * Span;

						// S19-TREDGE: place every plank on the wall at its OWN
						// station. It used to be
						//     PPos = Pos + SplineRot.Vector() * AlongOffset
						// a straight chord — so on a curving trench the end
						// planks left the wall face: buried at one end, hanging
						// out over the floor at the other. Re-evaluating the
						// spline per plank keeps the whole row on the wall.
						FVector PPos = Pos + SplineRot.Vector() * AlongOffset;
						FRotator PRotBase = Rot;
						if (!bCollapsed)
						{
							FVector PC; FVector PRight; FRotator PSplineRot; float PD = D;
							if (SampleAlongTrench(D, AlongOffset, PC, PRight, PSplineRot, PD))
							{
								PPos = PC + PRight * Side * WallDistAt(PD, Side);
								const float PLean = (WallLeanAt(PD, Side) + Stream.FRandRange(5.f, 10.f)) * -Side;
								PRotBase = FRotator(Rot.Pitch, PSplineRot.Yaw, PLean);
							}
						}
						const bool bBroken = Stream.FRand() < 0.10f;
						const float PlankH = bBroken ? Stream.FRandRange(0.35f, 0.55f) : Stream.FRandRange(0.72f, 1.04f);
						// S17-TRGATE: every plank meets ITS OWN ground — no more
						// floating bottom edges on sloped or stepped floors.
						float PlGZ = PPos.Z;
						if (TraceGroundZ(PPos, PlGZ)) PPos.Z = PlGZ + PlankH * 50.f - Stream.FRandRange(4.f, 20.f); // S17-TRWOOD: ragged top line
						else PPos.Z += Stream.FRandRange(-9.f, 7.f);
						const FRotator PRot(
								PRotBase.Pitch + Stream.FRandRange(-2.5f, 2.5f),
								PRotBase.Yaw + Stream.FRandRange(-4.f, 4.f),
								PRotBase.Roll + Stream.FRandRange(-3.5f, bBroken ? 8.f : 3.5f));
						const float PlankW = Stream.FRandRange(0.20f, 0.30f);
						const FTransform RevPlankXf(PRot, PPos,
							FVector(PlankW, Stream.FRandRange(0.05f, 0.07f), PlankH));
						HISM_Revetment->AddInstance(RevPlankXf, true);
						// S18-FIX: revetment boards are hand-split — rag the TOP/BOTTOM
						// ends (local Z is the tall axis here, so swap in a Z-length xf).
						if (bRaggedPlankEnds && Stream.FRand() < 0.7f)
						{
							const FTransform EndsXf(FRotator(PRot.Pitch + 90.f, PRot.Yaw, PRot.Roll), PPos,
								FVector(PlankH, PlankW, Stream.FRandRange(0.05f, 0.07f)));
							RagPlankEnds(HISM_Revetment, EndsXf, Stream);
						}
						// S17-TRWOOD: no factory edges. Half the planks carry an
						// offset half-strip (stepped silhouette), a third get a
						// splinter spiking past the top — hand-split war wood,
						// not wardrobe boards.
						if (Stream.FRand() < 0.5f)
						{
							FVector StepPos = PPos + FRotator(0.f, PRot.Yaw, 0.f).Vector() * (PlankW * 50.f * (Stream.FRand() < 0.5f ? 1.f : -1.f) * 0.55f);
							StepPos.Z += Stream.FRandRange(-10.f, 10.f);
							HISM_Revetment->AddInstance(FTransform(PRot, StepPos,
								FVector(PlankW * 0.5f, 0.05f, PlankH * Stream.FRandRange(0.82f, 1.12f))), true);
						}
						if (!bBroken && Stream.FRand() < 0.35f)
						{
							FVector SplPos = PPos + FRotator(0.f, PRot.Yaw, 0.f).Vector() * Stream.FRandRange(-PlankW * 28.f, PlankW * 28.f);
							SplPos.Z += PlankH * 50.f - 4.f;
							FRotator SplRot = PRot;
							SplRot.Roll  += Stream.FRandRange(-14.f, 14.f);
							SplRot.Pitch += Stream.FRandRange(-10.f, 10.f);
							HISM_Revetment->AddInstance(FTransform(SplRot, SplPos,
								FVector(Stream.FRandRange(0.03f, 0.06f), 0.045f, Stream.FRandRange(0.14f, 0.26f))), true);
						}
					}
					if (!bCollapsed && Stream.FRand() < 0.80f)
					{
						// Waler: rough horizontal plank pinning the row together.
					// S19-TREDGE: the waler used to be a straight board of
					// (Span + 35cm) laid at the yaw of station D. On a bend it
					// chorded straight while the planks it pins curve away, so
					// its ends poked out of the wall. Measure the true chord
					// between the row's two ends and size/orient it to that.
					FVector WalA, WalB;
					{
						FVector EA, EB, RA, RB; FRotator YawA, YawB; float DA = D, DB = D;
						const bool bA = SampleAlongTrench(D, -Span * 0.5f, EA, RA, YawA, DA);
						const bool bB = SampleAlongTrench(D,  Span * 0.5f, EB, RB, YawB, DB);
						WalA = bA ? (EA + RA * Side * WallDistAt(DA, Side)) : (Pos - SplineRot.Vector() * Span * 0.5f);
						WalB = bB ? (EB + RB * Side * WallDistAt(DB, Side)) : (Pos + SplineRot.Vector() * Span * 0.5f);
					}
					const FVector WalMid = (WalA + WalB) * 0.5f;
					const FVector WalDir = (WalB - WalA).GetSafeNormal2D();
					const float WalLen = FVector::Dist2D(WalA, WalB);
					FVector WalPos = WalMid - Right * Side * 7.f;
					WalPos.Z += Stream.FRandRange(8.f, 34.f);
					HISM_Revetment->AddInstance(FTransform(
						FRotator(Rot.Pitch, (WalDir.IsNearlyZero() ? Rot.Yaw : WalDir.Rotation().Yaw) + Stream.FRandRange(-2.f, 2.f), Rot.Roll + Stream.FRandRange(-2.5f, 2.5f)),
						WalPos, FVector(WalLen / 100.f + 0.05f, 0.05f, Stream.FRandRange(0.16f, 0.24f))), true);
				}
			}

if (bCollapsed && !bCustomRevet)
				{
					// Planks shaken loose, lying at the wall base.
					const int32 Fallen = Stream.RandRange(1, 2);
					for (int32 FIdx = 0; FIdx < Fallen; ++FIdx)
					{
						FVector FallPos = P + Right * Side * (WallDistAt(D, Side) - Stream.FRandRange(60.f, 140.f));
						float FZ = FallPos.Z; TraceGroundZ(FallPos, FZ);
						FallPos.Z = FZ + 4.f;
						const FTransform FallenXf( // S18-TRMESH
							FRotator(0.f, SplineRot.Yaw + Stream.FRandRange(-50.f, 50.f), Stream.FRandRange(-5.f, 5.f)),
							FallPos, FVector(Stream.FRandRange(0.7f, 1.1f), 0.17f, 0.04f));
						HISM_Plank->AddInstance(FallenXf, true);
						if (bRaggedPlankEnds) RagPlankEnds(HISM_Plank, FallenXf, Stream); // S18-FIX
					}
				}

				// Support posts pinning the panel (not when it's blown loose).
				if (!bCollapsed && Stream.FRand() < 0.75f)
				{
					for (int32 PostIdx = 0; PostIdx < 2; ++PostIdx)
					{
						// S19-TREDGE: each post stands on the wall at its OWN station. It used to
						// be 70cm along a straight tangent from the panel centre,
						// which walked the pair off a curved wall (one inside the
						// earth, one out over the floor).
						const float PostOffset = (PostIdx == 0 ? -1.f : 1.f) * 70.f;
						FVector PostPos = Pos + SplineRot.Vector() * PostOffset - Right * Side * 12.f;
						FRotator PostRot(Stream.FRandRange(-3.f, 3.f), SplineRot.Yaw, Lean * 0.8f);
						{
							FVector PC; FVector PRight; FRotator PSplineRot; float PD = D;
							if (SampleAlongTrench(D, PostOffset, PC, PRight, PSplineRot, PD))
							{
								PostPos = PC + PRight * Side * (WallDistAt(PD, Side) - 12.f);
								PostRot = FRotator(PostRot.Pitch, PSplineRot.Yaw,
									(WallLeanAt(PD, Side) + 5.f) * -Side * 0.8f);
							}
						}
						float PZ = PostPos.Z; TraceGroundZ(PostPos, PZ);
						PostPos.Z = PZ + 55.f;
						HISM_Post->AddInstance(FTransform(PostRot, PostPos, FVector(0.10f, 0.10f, 1.15f)), true);
					}
				}
			}
			// Corrugated metal sheet instead?
			else if (bCorrugated && WallHitAt(D, Side) && Stream.FRand() < CorrChance * DetailDensity) // S17-TRGATE
			{
				FVector Pos = P + Right * Side * WallDistAt(D, Side);
				float GroundZ = Pos.Z; TraceGroundZ(Pos, GroundZ);
				Pos.Z = GroundZ + 38.f;
				const float Lean = (WallLeanAt(D, Side) + Stream.FRandRange(4.f, 9.f)) * -Side; // S17-TRWALL2
				const FRotator Rot(Stream.FRandRange(-3.f, 3.f), SplineRot.Yaw + Stream.FRandRange(-8.f, 8.f), Lean); // S17-TRMESH
				HISM_Corrugated->AddInstance(FTransform(Rot, Pos,
					FVector(Stream.FRandRange(1.1f, 1.5f), 0.035f, Stream.FRandRange(0.70f, 0.92f))), true); // S17-TRMESH

				// S15-TRENCH2: half-embedded vertical ribs fake the corrugation profile.
				const FVector RibAlong = FRotationMatrix(Rot).GetUnitAxis(EAxis::X);
				const FVector RibOut = FRotationMatrix(Rot).GetUnitAxis(EAxis::Y);
				for (int32 RibIdx = 0; RibIdx < 5; ++RibIdx)
				{
					const FVector RibPos = Pos + RibAlong * ((RibIdx - 2.f) * 27.f) - RibOut * Side * 2.5f;
					HISM_Corrugated->AddInstance(FTransform(Rot, RibPos, FVector(0.045f, 0.045f, 0.82f)), true);
				}
			}

			// Firing step block flush against the wall.
			if (bFiringSteps && WallHitAt(D, Side) && Stream.FRand() < 0.18f * (WallStep / 400.f) * DetailDensity) // rate-normalized vs step
			{
				ClusterAnchors.Add(D); // S15-TRENCH8: a firing step is a story anchor
				FVector Pos = P + Right * Side * (WallDistAt(D, Side) - 35.f);
				float GroundZ = Pos.Z; TraceGroundZ(Pos, GroundZ);
				// S17-TRVAR: no two steps share a size, and packed earth
				// settles — a couple of degrees of tilt sells it.
				const float StepH = Stream.FRandRange(0.40f, 0.50f);
				Pos.Z = GroundZ + StepH * 50.f;
				const FRotator StepRot(Stream.FRandRange(-2.5f, 2.5f), SplineRot.Yaw + Stream.FRandRange(-4.f, 4.f), Stream.FRandRange(-2.f, 2.f));
				HISM_FiringStep->AddInstance(FTransform(StepRot, Pos, FVector(Stream.FRandRange(1.05f, 1.35f), Stream.FRandRange(0.45f, 0.58f), StepH)), true);

				// S15-TRENCH2: wooden tread plank on top of the earth step.
				const FTransform TreadXf( // S18-TRMESH
					FRotator(StepRot.Pitch, SplineRot.Yaw + Stream.FRandRange(-3.f, 3.f), StepRot.Roll),
					FVector(Pos.X, Pos.Y, GroundZ + StepH * 100.f + 2.5f),
					FVector(Stream.FRandRange(1.15f, 1.35f), Stream.FRandRange(0.48f, 0.56f), 0.04f));
				HISM_Plank->AddInstance(TreadXf, true);
				if (bRaggedPlankEnds) RagPlankEnds(HISM_Plank, TreadXf, Stream); // S18-FIX

				// S15-TRENCH4: helmet left resting on the step (COD set-dressing beat).
				if (bHelmets && Stream.FRand() < 0.30f)
				{
					const FVector HelmetPos = FVector(Pos.X, Pos.Y, GroundZ + 55.f)
						+ FRotationMatrix(FRotator(0.f, SplineRot.Yaw, 0.f)).GetUnitAxis(EAxis::X) * Stream.FRandRange(-40.f, 40.f);
					HISM_Helmet->AddInstance(FTransform(
						FRotator(Stream.FRandRange(-8.f, 8.f), Stream.FRandRange(0.f, 360.f), Stream.FRandRange(-8.f, 8.f)),
						HelmetPos, FVector(0.27f, 0.27f, 0.17f)), true);
				}

				// Spent brass around a used position.
				if (bDebris)
				{
					const int32 Casings = Stream.RandRange(5, 11);
					for (int32 i = 0; i < Casings; ++i)
					{
						FVector CPos = Pos + FVector(Stream.FRandRange(-60.f, 60.f), Stream.FRandRange(-60.f, 60.f), 0.f);
						float CZ = CPos.Z; TraceGroundZ(CPos, CZ); CPos.Z = CZ + 2.f;
						HISM_Casing->AddInstance(FTransform(FRotator(90.f, Stream.FRandRange(0.f, 360.f), 0.f), CPos, FVector(0.02f, 0.02f, 0.05f)), true);
					}
				}
			}
		}

		// Tarp awning stretched from one parapet down into the trench.
		if (bTarps && Stream.FRand() < 0.14f * (WallStep / 400.f) * DetailDensity) // rate-normalized vs step
		{
			const float Side = (Stream.FRand() < 0.5f) ? -1.f : 1.f;
			FVector Pos = P + Right * Side * (WallDistAt(D, Side) * 0.55f);
			float GroundZ = Pos.Z; TraceGroundZ(Pos, GroundZ);
			Pos.Z = GroundZ + 175.f;

			if (CustomTarpMesh)
			{
				const FRotator Rot(0.f, SplineRot.Yaw + Stream.FRandRange(-6.f, 6.f), Side * Stream.FRandRange(18.f, 28.f));
				HISM_Tarp->AddInstance(FTransform(Rot, Pos, FVector(CustomMeshScale)), true);
			}
			else
			{
				// S15-TRENCH2: pitched two-panel awning (ridge-tent silhouette), not a flat board.
				const float Yaw = SplineRot.Yaw + Stream.FRandRange(-6.f, 6.f);
				const float Pitch = Stream.FRandRange(16.f, 24.f);
				const FVector Across = FRotationMatrix(FRotator(0.f, Yaw, 0.f)).GetUnitAxis(EAxis::Y);
				const FVector Scale(2.1f, 0.95f, 1.f);
				for (int32 Half = 0; Half < 2; ++Half)
				{
					const float HSide = (Half == 0) ? -1.f : 1.f;
					const FVector HPos = Pos + Across * HSide * 44.f - FVector(0.f, 0.f, 9.f);
					const FRotator HRot(0.f, Yaw, HSide * Pitch);
					HISM_Tarp->AddInstance(FTransform(HRot, HPos, Scale), true);
					// Engine plane is single-sided — add the underside.
					HISM_Tarp->AddInstance(FTransform(FRotator(0.f, Yaw, HSide * Pitch + 180.f), HPos - FVector(0.f, 0.f, 0.5f), Scale), true);
				}
				// Corner tie posts holding the awning up.
				const FVector Along = FRotationMatrix(FRotator(0.f, Yaw, 0.f)).GetUnitAxis(EAxis::X);
				for (int32 PostIdx = 0; PostIdx < 2; ++PostIdx)
				{
					FVector PostPos = Pos + Along * ((PostIdx == 0 ? -1.f : 1.f) * 95.f);
					float PZ = PostPos.Z - 175.f; TraceGroundZ(PostPos, PZ);
					PostPos.Z = PZ + (Pos.Z - 9.f - PZ) * 0.5f;
					const float PostH = (Pos.Z - 9.f - PZ) / 100.f;
					HISM_Post->AddInstance(FTransform(FRotator(0.f, Yaw, 0.f), PostPos, FVector(0.07f, 0.07f, FMath::Max(PostH, 0.5f))), true);
				}
			}
		}
	}
}

// =====================================================================
//  PARAPET: barbed-wire pickets + sagging strands on both lips
// =====================================================================
void ATrenchDetailSplineActor::ScatterParapet(FRandomStream& Stream)
{
	if (!bWirePickets) return;

	const float Len = DetailSpline->GetSplineLength();
	const bool bCustomStake = CustomStakeMesh != nullptr;

	for (int32 SideIdx = 0; SideIdx < 2; ++SideIdx)
	{
		const float Side = (SideIdx == 0) ? -1.f : 1.f;
		FVector PrevTop = FVector::ZeroVector;
		float PrevTopH = 0.f;  // S19-TREDGE: stake-top height above local ground
		float PrevD = 0.f;     // S19-TREDGE: spline station of the previous stake
		bool bHavePrev = false;

		// S19-TREDGE: keep the picket line inside the dressed run (was 150..Len,
		// so the last stake could sit right on the end of the spline).
		const float D0 = FMath::Max(150.f, EndMarginCm);
		const float D1 = FMath::Max(D0 + 1.f, Len - EndMarginCm);
		for (float D = D0; D < D1; D += 350.f)
		{
			if (Stream.FRand() > 0.80f * DetailDensity) { bHavePrev = false; continue; }

			const FVector P = DetailSpline->GetLocationAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);
			const FVector Right = DetailSpline->GetRightVectorAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);

			FVector Pos = P + Right * Side * ParapetDistAt(D, Side);
			float GroundZ = Pos.Z;
			if (!TraceGroundZ(Pos, GroundZ)) { bHavePrev = false; continue; }

			const float TiltOut = Stream.FRandRange(5.f, 16.f) * Side;
			const FRotator Rot(Stream.FRandRange(-4.f, 4.f), Stream.FRandRange(0.f, 360.f), TiltOut);
			float TopZ = GroundZ + 120.f;
			if (bCustomStake)
			{
				Pos.Z = GroundZ;
				HISM_Stake->AddInstance(FTransform(Rot, Pos, FVector(CustomMeshScale)), true);
			}
			else
			{
				// S15-TRENCH8: silhouette variation — identical stake heights
				// scream "instanced"; hand-driven posts never match.
				const float StakeLen = Stream.FRandRange(1.15f, 1.5f);
				const float StakeThick = Stream.FRandRange(0.05f, 0.075f);
				Pos.Z = GroundZ + StakeLen * 50.f - 6.f;
				HISM_Stake->AddInstance(FTransform(Rot, Pos, FVector(StakeThick, StakeThick, StakeLen)), true);
				TopZ = GroundZ + StakeLen * 100.f - 22.f;

				// S15-TRENCH4: the odd helmet hung on a wire stake.
				if (bHelmets && Stream.FRand() < 0.09f)
				{
					HISM_Helmet->AddInstance(FTransform(
						FRotator(Stream.FRandRange(-15.f, 15.f), Stream.FRandRange(0.f, 360.f), Stream.FRandRange(-15.f, 15.f)),
						FVector(Pos.X, Pos.Y, TopZ + 9.f), FVector(0.25f, 0.25f, 0.16f)), true);
				}
			}

			// Two sagging wire strands to the previous stake.
			const FVector Top(Pos.X, Pos.Y, TopZ);
			if (bHavePrev)
			{
				// S15-TRENCH5: concertina coil sitting on the berm between stakes —
				// a 12-chord ring perpendicular to the trench direction, with a
				// touch of axial drift per chord so it reads as a spiral.
				// S18-FIX: prop wire belts replace ALL cylinder wire (coils AND
				// stake-to-stake strands) — that was the second, ugly wire line.
				const bool bPropWire = bWireSets && (CustomWireSetMesh || CustomWireSetMesh2
					|| CustomWireSetMesh3 || CustomWireSetMesh4);
				const bool bProcWireAllowed = bKeepProceduralCoils || !bPropWire;
				if (bConcertinaCoils && bProcWireAllowed && Stream.FRand() < 0.18f * DetailDensity)
				{
					FVector CoilCenter = (PrevTop + Top) * 0.5f;
					float CoilGroundZ = CoilCenter.Z;
					if (TraceGroundZ(CoilCenter, CoilGroundZ))
					{
						const float CoilR = 32.f;
						CoilCenter.Z = CoilGroundZ + CoilR;
						const FVector Axis = (Top - PrevTop).GetSafeNormal2D();
						const FVector Up(0.f, 0.f, 1.f);
						const FVector Out = FVector::CrossProduct(Axis, Up);
						const int32 Chords = 12;
						FVector Prev = CoilCenter + Up * CoilR;
						for (int32 C = 1; C <= Chords; ++C)
						{
							const float Ang = (2.f * PI * C) / Chords;
							const FVector Next = CoilCenter
								+ (Up * FMath::Cos(Ang) + Out * FMath::Sin(Ang)) * CoilR
								+ Axis * (C * 4.5f - Chords * 2.25f); // axial drift = spiral
							const float ChordLen = FVector::Dist(Prev, Next);
							HISM_Wire->AddInstance(FTransform(
								FRotationMatrix::MakeFromZ((Next - Prev).GetSafeNormal()).Rotator(),
								(Prev + Next) * 0.5f,
								FVector(0.008f, 0.008f, ChordLen / 100.f)), true); // S17-TRMESH
							// S17-TRFIX: one barb twist per chord.
							HISM_Wire->AddInstance(FTransform(
								FRotationMatrix::MakeFromZ(FVector::CrossProduct((Next - Prev).GetSafeNormal(), Out).GetSafeNormal()).Rotator(),
								(Prev + Next) * 0.5f, FVector(0.006f, 0.006f, 0.05f)), true); // S17-TRMESH
							Prev = Next;
						}
					}
				}

				const float Dist = FVector::Dist(PrevTop, Top);
				if (bProcWireAllowed && Dist > 80.f && Dist < 650.f) // S18-FIX
				{
					// S19-TREDGE: lay the wire as a POLYLINE that follows the
					// parapet. It used to be two straight segments from stake
					// top to stake top. Stakes sit 350cm apart along a spline
					// that curves, so that chord floated out over open ground
					// on the outside of every bend and sank into the berm on
					// the inside — the wire "imperfections at the edges".
					//
					// Sample intermediate nodes along the spline between the
					// two stakes; each node keeps the parapet offset and gets
					// its own ground height, so the strand hugs the berm the
					// whole way and the sag distributes along a real catenary
					// instead of one V in the middle.
					const int32 NumSegs = FMath::Clamp(
						FMath::CeilToInt(Dist / FMath::Max(20.f, WireSegmentCm)), 2, 10);

					TArray<FSquadAIWireNode> Nodes;
					Nodes.Reserve(NumSegs + 1);
					FSquadAIWireNode N0; N0.P = PrevTop; N0.GroundZ = PrevTop.Z - PrevTopH; N0.H = PrevTopH;
					Nodes.Add(N0);

					// Height of THIS stake's top above its own ground, so the
					// run can taper between two stakes of different length.
					const float TopH = TopZ - GroundZ;
					for (int32 Seg = 1; Seg <= NumSegs; ++Seg)
					{
						const float T = (float)Seg / (float)NumSegs;
						const float SegD = FMath::Lerp(PrevD, D, T);
						const FVector SP = DetailSpline->GetLocationAtDistanceAlongSpline(SegD, ESplineCoordinateSpace::World);
						const FVector SR = DetailSpline->GetRightVectorAtDistanceAlongSpline(SegD, ESplineCoordinateSpace::World);
						FVector WP = SP + SR * Side * ParapetDistAt(SegD, Side);
						float WZ = WP.Z;
						if (!TraceGroundZ(WP, WZ)) break;
						FSquadAIWireNode N;
						N.P = FVector(WP.X, WP.Y, 0.f);
						N.GroundZ = WZ;
						// Interpolate the stake-top height (stakes differ in
						// length) and add a little crookedness so the run never
						// reads as a laser line.
						N.H = FMath::Lerp(PrevTopH, TopH, T) + Stream.FRandRange(-4.f, 4.f);
						Nodes.Add(N);
					}

					if (Nodes.Num() >= 2)
					{
						const float MaxSag = 4.f + Dist * 0.035f;
						for (int32 Strand = 0; Strand < 3; ++Strand) // S15-TRENCH2: 3 strands
						{
							for (int32 i = 1; i < Nodes.Num(); ++i)
							{
								const float T0 = (float)(i - 1) / (float)(Nodes.Num() - 1);
								const float T1 = (float)i / (float)(Nodes.Num() - 1);
								// S15-TRENCH7: sag grows with span and is zero at
								// the stakes, so the wire stays attached at both
								// ends instead of floating below them.
								const float Sag0 = FMath::Sin(T0 * PI) * MaxSag;
								const float Sag1 = FMath::Sin(T1 * PI) * MaxSag;
								const FVector A(Nodes[i - 1].P.X, Nodes[i - 1].P.Y,
									Nodes[i - 1].GroundZ + Nodes[i - 1].H - Strand * 30.f - Sag0);
								const FVector B(Nodes[i].P.X, Nodes[i].P.Y,
									Nodes[i].GroundZ + Nodes[i].H - Strand * 30.f - Sag1);

								const FVector SegDir = (B - A).GetSafeNormal();
								const float SegLen = FVector::Dist(A, B);
								if (SegLen < 1.f) continue;
								HISM_Wire->AddInstance(FTransform(
									FRotationMatrix::MakeFromZ(SegDir).Rotator(),
									(A + B) * 0.5f,
									FVector(0.009f, 0.009f, SegLen / 100.f)), true); // S17-TRMESH: real wire gauge

								// S17-TRFIX: BARBS — crossed 9cm twists every
								// ~45cm, so the strands read as barbed wire,
								// not clothesline.
								FVector Perp = FVector::CrossProduct(SegDir, FVector::UpVector).GetSafeNormal();
								if (Perp.IsNearlyZero()) Perp = FVector::RightVector;
								// S19-TREDGE: 50cm spacing keeps the barb density the old
									// 175cm halves gave (they carried ~3 barbs each).
									const int32 NumBarbs = FMath::Max(1, FMath::RoundToInt(SegLen / 50.f));
								for (int32 BarbIdx = 0; BarbIdx < NumBarbs; ++BarbIdx)
								{
									const float Along01 = (BarbIdx + 0.5f) / NumBarbs;
									const FVector BarbPos = A + SegDir * (SegLen * Along01);
									const float Tw = Stream.FRandRange(0.f, 3.14159f);
									const FVector Rad = (Perp * FMath::Cos(Tw) + FVector::UpVector * FMath::Sin(Tw)).GetSafeNormal();
									const FVector DirA = (Rad + SegDir * 0.35f).GetSafeNormal();
									const FVector DirB = (Rad * -1.f + SegDir * 0.35f).GetSafeNormal();
									HISM_Wire->AddInstance(FTransform(FRotationMatrix::MakeFromZ(DirA).Rotator(), BarbPos, FVector(0.006f, 0.006f, 0.055f)), true);
									HISM_Wire->AddInstance(FTransform(FRotationMatrix::MakeFromZ(DirB).Rotator(), BarbPos, FVector(0.006f, 0.006f, 0.055f)), true);
								}
							}
						}
					}
				}
			}

			PrevTop = Top;
			PrevTopH = TopZ - GroundZ; // S19-TREDGE
			PrevD = D;                 // S19-TREDGE
			bHavePrev = true;
		}
	}
}

// =====================================================================
//  DEBRIS: stones + scorch patches along the whole line
// =====================================================================
void ATrenchDetailSplineActor::ScatterDebris(FRandomStream& Stream)
{
	if (!bDebris) return;

	const float Len = DetailSpline->GetSplineLength();

	for (float D = 100.f; D < Len; D += 250.f)
	{
		if (IsRestZone(D)) continue; // S15-TRENCH8: keep the quiet stretches quiet

		const FVector P = DetailSpline->GetLocationAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);
		const FVector Right = DetailSpline->GetRightVectorAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);

		// Small stones on the floor — biased to the edges so the traversal
		// line down the middle stays visually clean (S15-TRENCH8).
		if (Stream.FRand() < 0.55f * DetailDensity)
		{
			const float Lateral = Stream.FRandRange(FloorHalfAt(D) * 0.45f, FloorHalfAt(D))
				* (Stream.FRand() < 0.5f ? -1.f : 1.f);
			FVector Pos = P + Right * Lateral;
			float GroundZ = Pos.Z; TraceGroundZ(Pos, GroundZ);
			const float S = Stream.FRandRange(0.06f, 0.16f);
			Pos.Z = GroundZ + S * 42.f;
			const FRotator Rot(Stream.FRandRange(0.f, 360.f), Stream.FRandRange(0.f, 360.f), Stream.FRandRange(0.f, 360.f));
			HISM_Stone->AddInstance(FTransform(Rot, Pos, FVector(S, S * Stream.FRandRange(0.7f, 1.3f), S * Stream.FRandRange(0.5f, 1.f))), true);
		}

		// Scorch patch (mortar hit / burn mark) — slope-aligned (S15-TRENCH6).
		if (Stream.FRand() < 0.11f * DetailDensity)
		{
			FVector Pos = P + Right * Stream.FRandRange(-FloorHalfAt(D) * 0.8f, FloorHalfAt(D) * 0.8f);
			float GroundZ = Pos.Z;
			FVector GroundN = FVector::UpVector;
			TraceGround(Pos, GroundZ, GroundN);
			Pos.Z = GroundZ + 1.5f;
			const float S = Stream.FRandRange(1.0f, 1.9f);
			const FVector YawDir = FRotator(0.f, Stream.FRandRange(0.f, 360.f), 0.f).Vector();
			HISM_Scorch->AddInstance(FTransform(FRotationMatrix::MakeFromZX(GroundN, YawDir).Rotator(), Pos, FVector(S * Stream.FRandRange(0.72f, 1.28f), S, 1.f)), true); // S17-TRVAR: burns are not circles
		}
	}
}

#include "Environment/DestroyedVillageCompoundActor.h"
#include "Environment/DestroyedBuildingActor.h"
#include "Actors/CombatEncounterVolume.h"
#include "Actors/ExplosiveBarrelActor.h"
#include "CoverSystem/TacticalCoverGeneratorActor.h"
#include "Performance/SquadAIAssetCacheSubsystem.h"
#include "Engine/World.h"
#include "Engine/StaticMeshActor.h"
#include "Math/RandomStream.h"
#include "Components/PointLightComponent.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h"

namespace
{
	// S6-V2: shared ground snap for all village passes. Optionally ignores the
	// already-spawned village children so props snap to TERRAIN, not roofs/piles.
	bool VillageGroundSnap(UWorld* World, AActor* Ignore, const TArray<TObjectPtr<AActor>>* ExtraIgnore, FVector& InOutLoc)
	{
		if (!World) return false;
		FHitResult Hit;
		FCollisionQueryParams Params;
		if (Ignore) Params.AddIgnoredActor(Ignore);
		if (ExtraIgnore)
		{
			for (const TObjectPtr<AActor>& A : *ExtraIgnore)
			{
				if (A) Params.AddIgnoredActor(A.Get());
			}
		}
		if (World->LineTraceSingleByChannel(Hit, InOutLoc + FVector(0.f, 0.f, 15000.f), InOutLoc - FVector(0.f, 0.f, 50000.f), ECC_Visibility, Params))
		{
			InOutLoc = Hit.ImpactPoint;
			return true;
		}
		return false;
	}

	// S6-V2: runtime DMI tint — tries the common colour parameter names; a silent
	// no-op when the base material exposes none (no assets are ever created).
	void VillageTint(UStaticMeshComponent* Comp, const FLinearColor& Tint)
	{
		if (!Comp) return;
		if (UMaterialInstanceDynamic* Dyn = Comp->CreateAndSetMaterialInstanceDynamic(0))
		{
			static const FName Candidates[] = { TEXT("Color"), TEXT("BaseColor"), TEXT("Tint"), TEXT("BaseColorTint"), TEXT("Albedo"), TEXT("Colour") };
			for (const FName& Param : Candidates)
			{
				Dyn->SetVectorParameterValue(Param, Tint);
			}
		}
	}

	// S6-V2: one-call prop spawn used by the V2 realism passes. Ground-snaps the
	// XY position (optionally ignoring existing village children) and lifts the
	// prop ZLiftAboveGround off the impact point. Caller adds to SpawnedBuildings.
	// S7-H batch kinds mirrored in EnsureV2BatchComponent: 1=Road 2=Scorch 3=WallProps 4=WoodProps
	// S8-MAT: callers pass ResolveVillageMaterial(Category) / GetVillageCategoryTint(Category)
	AStaticMeshActor* SpawnVillageProp(UWorld* World, AActor* Owner, UStaticMesh* Mesh, UMaterialInterface* Mat,
		FVector Loc, float ZLiftAboveGround, const FRotator& Rot, const FVector& Scale,
		bool bBlockCollision, const TArray<TObjectPtr<AActor>>* SnapIgnore, const FLinearColor* Tint, int32 BatchKind = 0)
	{
		if (!World || !Owner || !Mesh) return nullptr;
		VillageGroundSnap(World, Owner, SnapIgnore, Loc);
		Loc.Z += ZLiftAboveGround; // snapped Z + caller lift

		// S7-H: batched path — identical (mesh, mat, tint) V2 props collapse into a
		// shared HISM per batch instead of dozens of per-prop actors.
		if (BatchKind != 0)
		{
			if (ADestroyedVillageCompoundActor* Village = Cast<ADestroyedVillageCompoundActor>(Owner))
			{
				if (UHierarchicalInstancedStaticMeshComponent* BatchComp = Village->EnsureV2BatchComponent(BatchKind, Mesh, Mat, Tint))
				{
					BatchComp->AddInstance(FTransform(Rot, Loc, Scale), true);
					return nullptr; // batched: no actor produced (callers null-guard)
				}
			}
		}

		FActorSpawnParameters SP;
		SP.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;
		SP.Owner = Owner;
		AStaticMeshActor* A = World->SpawnActor<AStaticMeshActor>(AStaticMeshActor::StaticClass(), Loc, Rot, SP);
		if (A && A->GetStaticMeshComponent())
		{
			if (USceneComponent* Root = Owner->GetRootComponent())
			{
				A->AttachToComponent(Root, FAttachmentTransformRules::KeepWorldTransform);
			}
			A->GetStaticMeshComponent()->SetStaticMesh(Mesh);
			A->GetStaticMeshComponent()->SetRelativeScale3D(Scale);
			A->GetStaticMeshComponent()->SetCollisionProfileName(bBlockCollision ? TEXT("BlockAllDynamic") : TEXT("NoCollision"));
			if (Mat) A->GetStaticMeshComponent()->SetMaterial(0, Mat);
			if (Tint) VillageTint(A->GetStaticMeshComponent(), *Tint);
		}
		return A;
	}
}

ADestroyedVillageCompoundActor::ADestroyedVillageCompoundActor()
{
	PrimaryActorTick.bCanEverTick = false;

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SetRootComponent(SceneRoot);
}

void ADestroyedVillageCompoundActor::BeginPlay()
{
	Super::BeginPlay();
	BuildVillage();
}

void ADestroyedVillageCompoundActor::BuildVillage()
{
	ClearVillage();

	UWorld* World = GetWorld();
	if (!World) return;

	const FVector Origin = GetActorLocation();
	const FRandomStream Stream(VillageSeed);

	FActorSpawnParameters SpawnParams;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;
	// S5-14: World Partition places streamed actors under their OWNER. All children
	// (buildings, fortifications, props, encounter, detail passes) must declare the
	// village as owner or they can fail placement / outlive the streamed cell.
	SpawnParams.Owner = this;

	const EBuildingStyle Styles[5] = {
		EBuildingStyle::TwoStorySniperRuins,
		EBuildingStyle::SingleStoryMudbrick,
		EBuildingStyle::WalledCourtyardHouse,
		EBuildingStyle::VillageMarketStalls,
		EBuildingStyle::OutpostObservationTower
	};
	// S6-M: mosque sits at rotation slot 4 so it appears even at BuildingCount 5
	// (the default); with bIncludeMosque OFF the original 5-style cycle is exact.
	const EBuildingStyle StylesWithMosque[6] = {
		EBuildingStyle::TwoStorySniperRuins,
		EBuildingStyle::SingleStoryMudbrick,
		EBuildingStyle::WalledCourtyardHouse,
		EBuildingStyle::VillageMarketStalls,
		EBuildingStyle::VillageMosque,
		EBuildingStyle::OutpostObservationTower
	};

	TArray<FVector> BuildingLocations;

	// S6-V2: organic layout — the village is anchored to a gently CURVING main
	// street (seeded yaw + sine wobble). ~60% of buildings line it on alternating
	// sides and face the road like real village houses; the rest ring the plaza.
	const float StreetYaw = Stream.FRandRange(0.f, 360.f);
	const FVector StreetDir(FMath::Cos(FMath::DegreesToRadians(StreetYaw)), FMath::Sin(FMath::DegreesToRadians(StreetYaw)), 0.f);
	const FVector StreetPerp(-StreetDir.Y, StreetDir.X, 0.f);
	const float StreetPhase = Stream.FRandRange(0.f, 100.f);
	auto StreetPoint = [&](float T) -> FVector
	{
		const float Wob = FMath::Sin(T * 0.00062f + StreetPhase) * VillageRadius * 0.10f;
		return Origin + StreetDir * T + StreetPerp * Wob;
	};

	// 1. Arrange buildings along the main street; ring the plaza with the rest
	const int32 Count = FMath::Clamp(BuildingCount, 2, 12);
	const int32 StreetBuildingCount = bOrganicStreetLayout ? FMath::CeilToInt(Count * 0.6f) : 0;
	for (int32 i = 0; i < Count; ++i)
	{
		FVector BLoc;
		FRotator BRot;
		if (i < StreetBuildingCount)
		{
			const float Side = (i % 2 == 0) ? 1.f : -1.f;
			const float T = FMath::Lerp(-VillageRadius * 0.72f, VillageRadius * 0.72f, (float)i / FMath::Max(1, Count - 1)) + Stream.FRandRange(-170.f, 170.f);
			const FVector OnStreet = StreetPoint(T);
			BLoc = OnStreet + StreetPerp * (Side * Stream.FRandRange(620.f, 980.f)) + FVector(0.f, 0.f, 10.f);
			VillageGroundSnap(World, this, nullptr, BLoc);
			// The house FRONT faces the road, with organic jitter.
			BRot = FRotator(0.f, (OnStreet - BLoc).Rotation().Yaw + Stream.FRandRange(-12.f, 12.f), 0.f);
		}
		else
		{
			const int32 RingIdx = i - StreetBuildingCount;
			const int32 RingTotal = FMath::Max(1, Count - StreetBuildingCount);
			const float Angle = (2.0f * PI * (RingIdx + 0.5f)) / RingTotal + Stream.FRandRange(-0.25f, 0.25f);
			const float Dist = Stream.FRandRange(VillageRadius * 0.45f, VillageRadius * 0.90f);
			BLoc = Origin + FVector(FMath::Cos(Angle) * Dist, FMath::Sin(Angle) * Dist, 10.f);
			VillageGroundSnap(World, this, nullptr, BLoc);
			BRot = (Origin - BLoc).Rotation() + FRotator(0.f, Stream.FRandRange(-25.f, 25.f), 0.f);
		}

		BuildingLocations.Add(BLoc);

		ADestroyedBuildingActor* Building = World->SpawnActor<ADestroyedBuildingActor>(ADestroyedBuildingActor::StaticClass(), BLoc, BRot, SpawnParams);
		if (Building)
		{
			Building->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
			Building->BuildingStyle = bIncludeMosque ? StylesWithMosque[i % 6] : Styles[i % 5]; // S6-M
			Building->GenerationSeed = Stream.RandRange(1000, 999999);
			Building->bSpawnSupplies = true;
			Building->bSpawnMountedHeavyMG = (i == 0 || i == 4); // Key vantage points
			Building->bSpawnExplosiveBarrels = true;
			Building->bSpawnWoodenRafters = true;
			Building->bSpawnInteriorPartitions = true;
			Building->bSpawnSandbagEmbrasures = true;
			Building->bSpawnDebrisFields = true;

			// Forward materials and meshes
			// S8-MAT: forward palette-tinted category materials so the buildings
			// match the props standing around them. With the palette off these
			// resolve to the plain overrides (or BasicShapeMaterial) as before.
			Building->WallMaterialOverride = GetPalettedVillageMaterial(0);
			Building->RubbleMaterialOverride = GetPalettedVillageMaterial(1);
			Building->FloorMaterialOverride = GetPalettedVillageMaterial(2);
			Building->WoodMaterialOverride = GetPalettedVillageMaterial(3);
			Building->SandbagMaterialOverride = GetPalettedVillageMaterial(4);

			if (CustomVillageWallMesh) Building->CustomWallMesh = CustomVillageWallMesh;
			if (CustomVillageSandbagMesh) Building->CustomSandbagMesh = CustomVillageSandbagMesh;
			if (CustomVillageWoodMesh) Building->CustomWoodBeamMesh = CustomVillageWoodMesh;
			if (CustomVillageRubbleMesh) Building->CustomRubbleMesh = CustomVillageRubbleMesh;

			Building->BuildBuilding();
			SpawnedBuildings.Add(Building);
		}
	}

	USquadAIAssetCacheSubsystem* Cache = USquadAIAssetCacheSubsystem::Get(this);
	UStaticMesh* CubeMesh = Cache ? Cache->GetCubeMesh() : LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cube.Cube"));

	// 2. Street Barricades & Central Plaza Fortifications
	if (bSpawnStreetBarricades && CubeMesh)
	{
		// Central sandbag checkpoint
		for (int32 b = 0; b < 4; ++b)
		{
			const float BarrAngle = (PI * 0.5f * b) + 0.25f;
			FVector BarrLoc = Origin + FVector(FMath::Cos(BarrAngle) * 350.f, FMath::Sin(BarrAngle) * 350.f, 0.f);
			VillageGroundSnap(World, this, &SpawnedBuildings, BarrLoc); // S6-V2: was untraced — floated on slopes
			BarrLoc.Z += 20.f;
			const FRotator BarrRot = FRotator(0.f, FMath::RadiansToDegrees(BarrAngle) + 90.f, 0.f);

			// S7-H2: batched into shared sandbag HISM (was a per-prop actor)
			if (AStaticMeshActor* Sandbag = SpawnVillageProp(World, this, CustomVillageSandbagMesh ? CustomVillageSandbagMesh.Get() : CubeMesh, ResolveVillageMaterial(4) /*S8-MAT*/, BarrLoc, 20.f, BarrRot, FVector(0.45f, 2.5f, 0.85f), true, &SpawnedBuildings, GetVillageCategoryTint(4) /*S8-MAT*/, /*S7-H2*/ 6))
			{
				SpawnedBuildings.Add(Sandbag);
			}

			// Red Explosive Barrel in street
			if (b % 2 == 0)
			{
				FVector BarrelLoc = BarrLoc + FVector(60.f, 60.f, 0.f);
				VillageGroundSnap(World, this, &SpawnedBuildings, BarrelLoc); // S6-V2
				AExplosiveBarrelActor* Barrel = World->SpawnActor<AExplosiveBarrelActor>(AExplosiveBarrelActor::StaticClass(), BarrelLoc, FRotator::ZeroRotator, SpawnParams);
				if (Barrel)
				{
					Barrel->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
					SpawnedBuildings.Add(Barrel);
				}
			}
		}
	}

	// 3. Perimeter Compound Walls & Elevated Walkways linking buildings
	if (bSpawnPerimeterWalls && BuildingLocations.Num() > 1 && CubeMesh)
	{
		for (int32 i = 0; i < BuildingLocations.Num(); ++i)
		{
			const FVector P1 = BuildingLocations[i];
			const FVector P2 = BuildingLocations[(i + 1) % BuildingLocations.Num()];
			const FVector Mid = (P1 + P2) * 0.5f;
			const float Dist = FVector::Dist(P1, P2);

			if (Dist > 400.f && Dist < VillageRadius * 1.5f)
			{
				const FRotator WallRot = (P2 - P1).Rotation();
				// Low compound perimeter wall
				// S7-H2: batched
				if (AStaticMeshActor* LowWall = SpawnVillageProp(World, this, CustomVillageWallMesh ? CustomVillageWallMesh.Get() : CubeMesh, ResolveVillageMaterial(0) /*S8-MAT*/, Mid, 50.f, WallRot, FVector(0.35f, (Dist * 0.45f) / 100.f, 1.0f), true, nullptr, GetVillageCategoryTint(0) /*S8-MAT*/, /*S7-H2*/ 3))
				{
					SpawnedBuildings.Add(LowWall);
				}

				// Elevated wooden plank walkway connecting 2nd story ruins across narrow alleys
				if (Dist < 850.f && (i % 2 == 0))
				{
					// S7-H2: batched
					if (AStaticMeshActor* Catwalk = SpawnVillageProp(World, this, CustomVillageWoodMesh ? CustomVillageWoodMesh.Get() : CubeMesh, ResolveVillageMaterial(3) /*S8-MAT*/, Mid, 310.f, WallRot, FVector(1.4f, (Dist * 0.88f) / 100.f, 0.12f), true, nullptr, GetVillageCategoryTint(3) /*S8-MAT*/, /*S7-H2*/ 4))
					{
						SpawnedBuildings.Add(Catwalk);
					}
				}
			}
		}
	}

	// 4. Central Plaza Well & Broken Monument (the village square landmark)
	if (bSpawnPlazaMonument && CubeMesh)
	{
		FVector PlazaCenter = Origin;
		FHitResult PlazaHit;
		FCollisionQueryParams PlazaParams;
		PlazaParams.AddIgnoredActor(this);
		if (World->LineTraceSingleByChannel(PlazaHit, PlazaCenter + FVector(0.f, 0.f, 15000.f), PlazaCenter - FVector(0.f, 0.f, 50000.f), ECC_Visibility, PlazaParams))
		{
			PlazaCenter = PlazaHit.ImpactPoint;
		}

		UStaticMesh* WellMesh = CustomVillageWallMesh ? CustomVillageWallMesh.Get() : CubeMesh;

		// 4a. Circular stone well ring (4 tangential low blocks, ~2.9m diameter, 80cm high)
		for (int32 w = 0; w < 4; ++w)
		{
			const float SegAngle = (PI * 0.5f * w) + Stream.FRandRange(-0.06f, 0.06f);
			const FVector SegLoc = PlazaCenter + FVector(FMath::Cos(SegAngle) * 145.f, FMath::Sin(SegAngle) * 145.f, 40.f);
			const FRotator SegRot(0.f, FMath::RadiansToDegrees(SegAngle) + 90.f, 0.f);

			// S7-H2: batched
			if (AStaticMeshActor* WellSeg = SpawnVillageProp(World, this, WellMesh, ResolveVillageMaterial(0) /*S8-MAT*/, SegLoc, 40.f, SegRot, FVector(0.35f, 1.6f, 0.8f), true, &SpawnedBuildings, GetVillageCategoryTint(0) /*S8-MAT*/, /*S7-H2*/ 3))
			{
				SpawnedBuildings.Add(WellSeg);
			}
		}

		// 4b. Broken monument column beside the well, slightly tilted by the blast
		UStaticMesh* ColumnMesh = CustomVillageRubbleMesh ? CustomVillageRubbleMesh.Get() : WellMesh;
		const FRotator ColumnRot(Stream.FRandRange(-2.f, 2.f), Stream.FRandRange(0.f, 360.f), Stream.FRandRange(-7.f, 7.f));
		FVector ColumnLoc = PlazaCenter + FVector(270.f, -120.f, 0.f);
		VillageGroundSnap(World, this, &SpawnedBuildings, ColumnLoc); // S6-V2: each piece traced — no floaters on slopes
		ColumnLoc.Z += 80.f;
		AStaticMeshActor* Column = World->SpawnActor<AStaticMeshActor>(AStaticMeshActor::StaticClass(), ColumnLoc, ColumnRot, SpawnParams);
		if (Column && Column->GetStaticMeshComponent())
		{
			Column->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
			Column->GetStaticMeshComponent()->SetStaticMesh(ColumnMesh);
			Column->GetStaticMeshComponent()->SetRelativeScale3D(FVector(0.55f, 0.55f, 1.6f));
			Column->GetStaticMeshComponent()->SetCollisionProfileName(TEXT("BlockAllDynamic"));
			UMaterialInterface* ColumnMat = ResolveVillageMaterial(1); /*S8-MAT*/
			if (ColumnMat) Column->GetStaticMeshComponent()->SetMaterial(0, ColumnMat);
			if (const FLinearColor* T = GetVillageCategoryTint(1)) VillageTint(Column->GetStaticMeshComponent(), *T); /*S8-MAT*/
			SpawnedBuildings.Add(Column);
		}

		// 4c. Toppled cap piece of the same monument, lying at its base
		const FRotator CapRot(Stream.FRandRange(74.f, 86.f), Stream.FRandRange(0.f, 360.f), 0.f);
		FVector CapLoc = PlazaCenter + FVector(430.f, -190.f, 0.f);
		VillageGroundSnap(World, this, &SpawnedBuildings, CapLoc); // S6-V2
		CapLoc.Z += 26.f;
		AStaticMeshActor* CapPiece = World->SpawnActor<AStaticMeshActor>(AStaticMeshActor::StaticClass(), CapLoc, CapRot, SpawnParams);
		if (CapPiece && CapPiece->GetStaticMeshComponent())
		{
			CapPiece->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
			CapPiece->GetStaticMeshComponent()->SetStaticMesh(ColumnMesh);
			CapPiece->GetStaticMeshComponent()->SetRelativeScale3D(FVector(0.5f, 0.5f, 1.35f));
			CapPiece->GetStaticMeshComponent()->SetCollisionProfileName(TEXT("NoCollision"));
			UMaterialInterface* CapMat = ResolveVillageMaterial(1); /*S8-MAT*/
			if (CapMat) CapPiece->GetStaticMeshComponent()->SetMaterial(0, CapMat);
			if (const FLinearColor* T = GetVillageCategoryTint(1)) VillageTint(CapPiece->GetStaticMeshComponent(), *T); /*S8-MAT*/
			SpawnedBuildings.Add(CapPiece);
		}
	}

	// 5. War-Damage Rubble Mounds (low mounds are walkover, tall ones block movement)
	if (bSpawnRubbleMounds && CubeMesh)
	{
		UStaticMesh* MoundMesh = CustomVillageRubbleMesh ? CustomVillageRubbleMesh.Get() : CubeMesh;
		const int32 MoundCount = FMath::Clamp(RubbleMoundCount, 0, 24);
		for (int32 m = 0; m < MoundCount; ++m)
		{
			const float MAngle = Stream.FRandRange(0.f, 2.0f * PI);
			const float MDist = Stream.FRandRange(500.f, VillageRadius * 0.85f);
			FVector MLoc = Origin + FVector(FMath::Cos(MAngle) * MDist, FMath::Sin(MAngle) * MDist, 0.f);

			FHitResult MHit;
			FCollisionQueryParams MParams;
			MParams.AddIgnoredActor(this);
			if (World->LineTraceSingleByChannel(MHit, MLoc + FVector(0.f, 0.f, 15000.f), MLoc - FVector(0.f, 0.f, 50000.f), ECC_Visibility, MParams))
			{
				MLoc = MHit.ImpactPoint;
			}

			const float SX = Stream.FRandRange(1.1f, 2.4f);
			const float SY = Stream.FRandRange(1.1f, 2.4f);
			const float SZ = Stream.FRandRange(0.22f, 0.7f);
			const FRotator MRot(0.f, Stream.FRandRange(0.f, 360.f), 0.f);

			// S7-H2: batched — blocking mounds vs walkover mounds split into two batches
			if (AStaticMeshActor* Mound = SpawnVillageProp(World, this, MoundMesh, ResolveVillageMaterial(1) /*S8-MAT*/, MLoc, 50.f * SZ, MRot, FVector(SX, SY, SZ), SZ >= 0.45f, nullptr, GetVillageCategoryTint(1) /*S8-MAT*/, /*S7-H2*/ (SZ >= 0.45f ? 5 : 7)))
			{
				SpawnedBuildings.Add(Mound);
			}
		}
	}

	// 6. Street Clutter (crate stacks & cart planks dropped in alleys outside building doorways)
	if (bSpawnStreetClutter && CubeMesh && BuildingLocations.Num() > 0)
	{
		UStaticMesh* ClutterMesh = CustomVillageWoodMesh ? CustomVillageWoodMesh.Get() : CubeMesh;
		const int32 ClutterTotal = FMath::Clamp(StreetClutterCount, 0, 40);
		for (int32 c = 0; c < ClutterTotal; ++c)
		{
			const FVector& Anchor = BuildingLocations[Stream.RandRange(0, BuildingLocations.Num() - 1)];
			const FVector TowardCenter = (Origin - Anchor).GetSafeNormal();
			const float OffDist = Stream.FRandRange(650.f, 1050.f);
			FVector CLoc = Anchor + TowardCenter * OffDist
				+ FVector(Stream.FRandRange(-260.f, 260.f), Stream.FRandRange(-260.f, 260.f), 0.f);

			FHitResult CHit;
			FCollisionQueryParams CParams;
			CParams.AddIgnoredActor(this);
			if (World->LineTraceSingleByChannel(CHit, CLoc + FVector(0.f, 0.f, 15000.f), CLoc - FVector(0.f, 0.f, 50000.f), ECC_Visibility, CParams))
			{
				CLoc = CHit.ImpactPoint;
			}

			// Three silhouettes: bulky crate, low cart plank, roof beam bundle
			const int32 Variant = Stream.RandRange(0, 2);
			FVector CScale;
			const float CLift = (Variant == 0) ? 30.f : ((Variant == 1) ? 9.f : 17.f);
			switch (Variant)
			{
			case 0:  CScale = FVector(0.6f, 0.6f, 0.6f);   break;
			case 1:  CScale = FVector(1.5f, 0.9f, 0.18f);  break;
			default: CScale = FVector(1.15f, 0.24f, 0.34f); break;
			}
			const FRotator CRot(0.f, Stream.FRandRange(0.f, 360.f), 0.f);

			// S7-H2: batched — thin cart planks go walkover-batch, rest block-batch
			if (AStaticMeshActor* Clutter = SpawnVillageProp(World, this, ClutterMesh, ResolveVillageMaterial(3) /*S8-MAT*/, CLoc, CLift, CRot, CScale, Variant != 1, nullptr, GetVillageCategoryTint(3) /*S8-MAT*/, /*S7-H2*/ (Variant == 1 ? 8 : 4)))
			{
				SpawnedBuildings.Add(Clutter);
			}
		}
	}

	// 7. Outer Defensive Sandbag Arcs (three-segment arcs on the village rim, facing outward)
	if (bSpawnPerimeterSandbags && CubeMesh)
	{
		UStaticMesh* ArcMesh = CustomVillageSandbagMesh ? CustomVillageSandbagMesh.Get() : CubeMesh;
		const int32 ArcTotal = FMath::Clamp(PerimeterSandbagArcs, 0, 8);
		const float ArcDist = VillageRadius * 0.78f;
		for (int32 a = 0; a < ArcTotal; ++a)
		{
			const float ArcAngle = (2.0f * PI * a) / FMath::Max(1, ArcTotal) + Stream.FRandRange(-0.3f, 0.3f);
			const FVector Outward = FVector(FMath::Cos(ArcAngle), FMath::Sin(ArcAngle), 0.f);
			const FVector Forward = FVector(-Outward.Y, Outward.X, 0.f); // tangent of the rim
			const FVector ArcCenter = Origin + Outward * ArcDist;
			const FRotator ArcRot = Outward.Rotation();

			for (int32 s = -1; s <= 1; ++s)
			{
				FVector SLoc = ArcCenter + Forward * (s * 230.f);

				FHitResult SHit;
				FCollisionQueryParams SParams;
				SParams.AddIgnoredActor(this);
				if (World->LineTraceSingleByChannel(SHit, SLoc + FVector(0.f, 0.f, 15000.f), SLoc - FVector(0.f, 0.f, 50000.f), ECC_Visibility, SParams))
				{
					SLoc = SHit.ImpactPoint;
				}

				// S7-H2: batched
				if (AStaticMeshActor* BagSeg = SpawnVillageProp(World, this, ArcMesh, ResolveVillageMaterial(4) /*S8-MAT*/, SLoc, 22.f, ArcRot, FVector(0.45f, 2.3f, 0.85f), true, nullptr, GetVillageCategoryTint(4) /*S8-MAT*/, /*S7-H2*/ 6))
				{
					SpawnedBuildings.Add(BagSeg);
				}
			}
		}
	}

	// 7b. S6-V2: Main Road Ribbon + Plaza Pad + Cross Alley (flattened, walkover,
	// tinted via runtime DMI — procedure: silhouette first, colour if supported)
	if (bSpawnMainRoad && CubeMesh)
	{
		UMaterialInterface* RoadMat = ResolveVillageMaterial(2); /*S8-MAT: floor->rubble->wall->BasicShape*/
		const int32 RoadSegs = FMath::Clamp(FMath::CeilToInt((VillageRadius * 1.9f) / 700.f), 4, 12);
		for (int32 RS = 0; RS < RoadSegs; ++RS)
		{
			const float T0 = FMath::Lerp(-VillageRadius * 0.95f, VillageRadius * 0.95f, (float)RS / RoadSegs);
			const float T1 = FMath::Lerp(-VillageRadius * 0.95f, VillageRadius * 0.95f, (float)(RS + 1) / RoadSegs);
			const FVector P0 = StreetPoint(T0);
			const FVector P1 = StreetPoint(T1);
			FRotator RRot = (P1 - P0).Rotation();
			RRot.Pitch = 0.f; RRot.Roll = 0.f;
			const float SegLen = FMath::Max(1.f, FVector::Dist2D(P0, P1));
			if (AStaticMeshActor* RoadSeg = SpawnVillageProp(World, this, CubeMesh, RoadMat, (P0 + P1) * 0.5f, 4.f, RRot,
				FVector(SegLen / 100.f, 5.5f, 0.05f), false, &SpawnedBuildings, &RoadTint, /*S7-H*/ 1))
			{
				SpawnedBuildings.Add(RoadSeg);
			}
		}
		// Plaza pad: two rotated pads for an organic silhouette
		for (int32 Pad = 0; Pad < 2; ++Pad)
		{
			if (AStaticMeshActor* PlazaPad = SpawnVillageProp(World, this, CubeMesh, RoadMat, Origin + StreetPerp * (Pad * 90.f), 3.5f,
				FRotator(0.f, StreetYaw + Pad * 37.f, 0.f), FVector(9.5f, 8.0f, 0.05f), false, &SpawnedBuildings, &RoadTint, /*S7-H*/ 1))
			{
				SpawnedBuildings.Add(PlazaPad);
			}
		}
		// Cross alley running away from the plaza on both sides
		for (int32 CA = -1; CA <= 1; CA += 2)
		{
			if (AStaticMeshActor* Alley = SpawnVillageProp(World, this, CubeMesh, RoadMat, Origin + StreetPerp * (CA * (260.f + VillageRadius * 0.28f)), 3.5f,
				FRotator(0.f, StreetYaw + 90.f, 0.f), FVector(VillageRadius * 0.0056f, 2.6f, 0.05f), false, &SpawnedBuildings, &RoadTint, /*S7-H*/ 1))
			{
				SpawnedBuildings.Add(Alley);
			}
		}
	}

	// 7c. S6-V2: Village Gate Frames — intact at one street end, battle-collapsed
	// at the other (tilted post, lintel thrown to the ground)
	if (bSpawnGateFrames && CubeMesh)
	{
		UStaticMesh* GateWall = CustomVillageWallMesh ? CustomVillageWallMesh.Get() : CubeMesh;
		UStaticMesh* GateWood = CustomVillageWoodMesh ? CustomVillageWoodMesh.Get() : CubeMesh;
		for (int32 End = 0; End < 2; ++End)
		{
			const float EndSide = (End == 0) ? -1.f : 1.f;
			const FVector GateC = StreetPoint(EndSide * VillageRadius * 0.92f);
			for (int32 PS = -1; PS <= 1; PS += 2)
			{
				const bool bCollapsedPost = (End == 0 && PS == -1);
				FRotator Prot(0.f, StreetYaw, 0.f);
				float Lift = 115.f;
				if (bCollapsedPost)
				{
					Prot = FRotator(Stream.FRandRange(24.f, 36.f), StreetYaw + Stream.FRandRange(-15.f, 15.f), 0.f);
					Lift = 105.f; // sunk into its crater
				}
				if (AStaticMeshActor* Post = SpawnVillageProp(World, this, GateWall, ResolveVillageMaterial(0) /*S8-MAT*/, GateC + StreetPerp * (PS * 250.f), Lift, Prot,
					FVector(0.32f, 0.32f, 2.3f), true, &SpawnedBuildings, GetVillageCategoryTint(0) /*S8-MAT*/, /*S7-H*/ 3))
				{
					SpawnedBuildings.Add(Post);
				}
			}
			if (End == 1)
			{
				if (AStaticMeshActor* Lintel = SpawnVillageProp(World, this, GateWood, ResolveVillageMaterial(3) /*S8-MAT*/, GateC, 218.f, FRotator(0.f, StreetYaw, 0.f),
					FVector(0.22f, 5.6f, 0.22f), false, &SpawnedBuildings, GetVillageCategoryTint(3) /*S8-MAT*/, /*S7-H*/ 4))
				{
					SpawnedBuildings.Add(Lintel);
				}
			}
			else
			{
				if (AStaticMeshActor* Fallen = SpawnVillageProp(World, this, GateWood, ResolveVillageMaterial(3) /*S8-MAT*/, GateC + StreetPerp * Stream.FRandRange(-60.f, 60.f), 8.f,
					FRotator(Stream.FRandRange(72.f, 84.f), StreetYaw + Stream.FRandRange(-30.f, 30.f), 0.f), FVector(0.22f, 5.2f, 0.22f), false, &SpawnedBuildings, GetVillageCategoryTint(3) /*S8-MAT*/, /*S7-H*/ 4))
				{
					SpawnedBuildings.Add(Fallen);
				}
			}
		}
	}

	// 7d. S6-V2: Courtyard L-Walls — the signature compound yard of Khuzestan
	// villages (two short stubs around one corner, seeded per building)
	if (bSpawnCourtyardWalls && CubeMesh && BuildingLocations.Num() > 0)
	{
		UStaticMesh* YardMesh = CustomVillageWallMesh ? CustomVillageWallMesh.Get() : CubeMesh;
		for (int32 Ci = 0; Ci < BuildingLocations.Num(); ++Ci)
		{
			if (Stream.FRand() > 0.62f) continue; // organic: not every house keeps its yard wall
			const FVector& BL = BuildingLocations[Ci];
			const float BaseYaw = Stream.FRandRange(0.f, 360.f);
			for (int32 WS = 0; WS < 2; ++WS)
			{
				const float WallYaw = BaseYaw + 90.f * WS;
				const FVector WDir(FMath::Cos(FMath::DegreesToRadians(WallYaw)), FMath::Sin(FMath::DegreesToRadians(WallYaw)), 0.f);
				if (AStaticMeshActor* Yard = SpawnVillageProp(World, this, YardMesh, ResolveVillageMaterial(0) /*S8-MAT*/, BL + WDir * 450.f, 45.f,
					FRotator(0.f, WallYaw, 0.f), FVector(0.28f, Stream.FRandRange(2.4f, 3.8f), 0.9f), true, &SpawnedBuildings, GetVillageCategoryTint(0) /*S8-MAT*/, /*S7-H*/ 3))
				{
					SpawnedBuildings.Add(Yard);
				}
			}
		}
	}

	// 7e. S6-V2: Weathered Wooden Poles along the street; ~30% battle-snapped
	if (bSpawnTelegraphPoles && CubeMesh)
	{
		UStaticMesh* PoleMesh = CustomVillageWoodMesh ? CustomVillageWoodMesh.Get() : CubeMesh;
		const int32 PoleCount = FMath::Clamp(FMath::FloorToInt((VillageRadius * 1.7f) / 850.f), 2, 8);
		for (int32 Pi = 0; Pi < PoleCount; ++Pi)
		{
			const float T = FMath::Lerp(-VillageRadius * 0.85f, VillageRadius * 0.85f, (float)Pi / FMath::Max(1, PoleCount - 1));
			const FVector PoleBase = StreetPoint(T) + StreetPerp * ((Pi % 2 == 0) ? 430.f : -430.f);
			if (Stream.FRand() < 0.7f)
			{
				const FRotator PoleRot(Stream.FRandRange(-2.f, 2.f), Stream.FRandRange(0.f, 360.f), Stream.FRandRange(-2.f, 2.f));
				if (AStaticMeshActor* Pole = SpawnVillageProp(World, this, PoleMesh, ResolveVillageMaterial(3) /*S8-MAT*/, PoleBase, 152.f, PoleRot,
					FVector(0.13f, 0.13f, 3.05f), true, &SpawnedBuildings, GetVillageCategoryTint(3) /*S8-MAT*/, /*S7-H*/ 4))
				{
					SpawnedBuildings.Add(Pole);
				}
				if (AStaticMeshActor* Cross = SpawnVillageProp(World, this, PoleMesh, ResolveVillageMaterial(3) /*S8-MAT*/, PoleBase, 284.f, FRotator(0.f, StreetYaw + 90.f, 0.f),
					FVector(0.95f, 0.085f, 0.07f), false, &SpawnedBuildings, GetVillageCategoryTint(3) /*S8-MAT*/, /*S7-H*/ 4))
				{
					SpawnedBuildings.Add(Cross);
				}
			}
			else
			{
				// snapped: a stump remains, the shaft lies half-buried nearby
				if (AStaticMeshActor* Stump = SpawnVillageProp(World, this, PoleMesh, ResolveVillageMaterial(3) /*S8-MAT*/, PoleBase, 22.f, FRotator::ZeroRotator,
					FVector(0.13f, 0.13f, 0.44f), true, &SpawnedBuildings, GetVillageCategoryTint(3) /*S8-MAT*/, /*S7-H*/ 4))
				{
					SpawnedBuildings.Add(Stump);
				}
				const FVector FallOff = StreetPerp * Stream.FRandRange(-260.f, 260.f) + StreetDir * Stream.FRandRange(-140.f, 140.f);
				if (AStaticMeshActor* Shaft = SpawnVillageProp(World, this, PoleMesh, ResolveVillageMaterial(3) /*S8-MAT*/, PoleBase + FallOff, 9.f,
					FRotator(Stream.FRandRange(74.f, 84.f), Stream.FRandRange(0.f, 360.f), 0.f), FVector(0.13f, 0.13f, 2.6f), false, &SpawnedBuildings, GetVillageCategoryTint(3) /*S8-MAT*/, /*S7-H*/ 4))
				{
					SpawnedBuildings.Add(Shaft);
				}
			}
		}
	}

	// 7f. S6-V2: Well A-Frame + Bucket over the plaza well
	if (bSpawnWellAFrame && bSpawnPlazaMonument && CubeMesh)
	{
		UStaticMesh* FrameMesh = CustomVillageWoodMesh ? CustomVillageWoodMesh.Get() : CubeMesh;
		for (int32 Beam = -1; Beam <= 1; Beam += 2)
		{
			if (AStaticMeshActor* BeamProp = SpawnVillageProp(World, this, FrameMesh, ResolveVillageMaterial(3) /*S8-MAT*/, Origin + FVector(115.f * Beam, 0.f, 0.f), 58.f,
				FRotator(-24.f * Beam, 0.f, 0.f), FVector(0.10f, 0.10f, 1.30f), true, &SpawnedBuildings, GetVillageCategoryTint(3) /*S8-MAT*/, /*S7-H*/ 4))
			{
				SpawnedBuildings.Add(BeamProp);
			}
		}
		// crossbar ends interpenetrate the beam heads slightly — reads as fastened
		if (AStaticMeshActor* Crossbar = SpawnVillageProp(World, this, FrameMesh, ResolveVillageMaterial(3) /*S8-MAT*/, Origin, 118.f, FRotator(0.f, 90.f, 0.f),
			FVector(0.06f, 1.55f, 0.06f), false, &SpawnedBuildings, GetVillageCategoryTint(3) /*S8-MAT*/, /*S7-H*/ 4))
		{
			SpawnedBuildings.Add(Crossbar);
		}
		if (AStaticMeshActor* Bucket = SpawnVillageProp(World, this, FrameMesh, ResolveVillageMaterial(3) /*S8-MAT*/, Origin + FVector(170.f, -70.f, 0.f), 9.f,
			FRotator(0.f, Stream.FRandRange(0.f, 360.f), 0.f), FVector(0.17f, 0.17f, 0.20f), false, &SpawnedBuildings, GetVillageCategoryTint(3) /*S8-MAT*/, /*S7-H*/ 4))
		{
			SpawnedBuildings.Add(Bucket);
		}
	}

	// 7g. S6-V2: Scorch & dust patches at building wall bases (tinted thin quads)
	if (bSpawnScorchPatches && CubeMesh && BuildingLocations.Num() > 0)
	{
		for (int32 Bi = 0; Bi < BuildingLocations.Num(); ++Bi)
		{
			const int32 PatchTotal = Stream.RandRange(1, 2);
			for (int32 SPi = 0; SPi < PatchTotal; ++SPi)
			{
				const float PA = Stream.FRandRange(0.f, 2.0f * PI);
				const FVector& BL = BuildingLocations[Bi];
				const FVector PLoc = BL + FVector(FMath::Cos(PA), FMath::Sin(PA), 0.f) * Stream.FRandRange(320.f, 520.f);
				const float PSZ = Stream.FRandRange(0.5f, 0.95f);
				// Face outward, away from the wall; snap ignores village children so
				// the patch never ends up sitting on a roof or rubble pile.
				if (AStaticMeshActor* Patch = SpawnVillageProp(World, this, CubeMesh, ResolveVillageMaterial(2) /*S8-MAT*/, PLoc, PSZ * 44.f,
					FRotator(0.f, FMath::RadiansToDegrees(PA) + 180.f, Stream.FRandRange(-3.f, 3.f)), FVector(Stream.FRandRange(0.6f, 1.1f), 0.05f, PSZ),
					false, &SpawnedBuildings, &ScorchTint, /*S7-H*/ 2))
				{
					SpawnedBuildings.Add(Patch);
				}
			}
		}
	}

	// 7h. S6-V2: Warm doorway glow — two shadowless point lights
	if (bSpawnInteriorLights && BuildingLocations.Num() > 0)
	{
		const int32 MaxLights = FMath::Min(2, BuildingLocations.Num());
		for (int32 Li = 0; Li < MaxLights; ++Li)
		{
			UPointLightComponent* PLC = NewObject<UPointLightComponent>(this);
			if (!PLC) break;
			PLC->SetIntensity(240.f);
			PLC->SetAttenuationRadius(1050.f);
			PLC->SetLightColor(FLinearColor(1.0f, 0.55f, 0.24f));
			PLC->CastShadows = false;
			PLC->RegisterComponent();
			PLC->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
			const FVector& BL = BuildingLocations[Stream.RandRange(0, BuildingLocations.Num() - 1)];
			PLC->SetWorldLocation(BL + FVector(0.f, 0.f, 260.f));
		}
	}

	// 8. Spawn Combat Encounter Arena Volume over the village
	if (bCreateCombatEncounter)
	{
		ACombatEncounterVolume* Enc = World->SpawnActor<ACombatEncounterVolume>(ACombatEncounterVolume::StaticClass(), Origin, FRotator::ZeroRotator, SpawnParams);
		if (Enc)
		{
			Enc->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
			Enc->EncounterName = FText::FromString(TEXT("Village Ruins Assault"));
			Enc->TotalWaves = 3;
			Enc->EnemiesPerWave = 4;
			Enc->bAutoScatterSupplyKits = true;
			Enc->bCinematicSlowMoOnClear = true;
			SpawnedBuildings.Add(Enc);
		}
	}

	// 9. Spawn Automated Cover Point Generator
	if (bGenerateCoverNodes)
	{
		ATacticalCoverGeneratorActor* CoverGen = World->SpawnActor<ATacticalCoverGeneratorActor>(ATacticalCoverGeneratorActor::StaticClass(), Origin, FRotator::ZeroRotator, SpawnParams);
		if (CoverGen)
		{
			CoverGen->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
			CoverGen->BakeCoverPoints();
			SpawnedBuildings.Add(CoverGen);
		}
	}

	UE_LOG(LogTemp, Log, TEXT("[DestroyedVillage] %s generated %d ruined village elements across %.0fm radius"), *GetName(), SpawnedBuildings.Num(), VillageRadius / 100.f);
}

// S8-MAT: category material resolution. Categories:
//   0 = Wall/mudbrick   1 = Rubble/masonry   2 = Floor/road
//   3 = Wood/timber     4 = Sandbag/canvas
// Each category prefers its own override, then the closest related override
// (matching how the building generator pairs them), and finally the engine
// BasicShapeMaterial so an un-authored village renders in the same neutral
// material as the buildings inside it instead of default-grey WorldGridMaterial.
UMaterialInterface* ADestroyedVillageCompoundActor::ResolveVillageMaterial(int32 Category) const
{
	UMaterialInterface* Chosen = nullptr;
	switch (Category)
	{
	case 0: // Wall
		Chosen = VillageWallMaterial ? VillageWallMaterial.Get()
			: (VillageRubbleMaterial ? VillageRubbleMaterial.Get() : VillageFloorMaterial.Get());
		break;
	case 1: // Rubble
		Chosen = VillageRubbleMaterial ? VillageRubbleMaterial.Get()
			: (VillageWallMaterial ? VillageWallMaterial.Get() : VillageFloorMaterial.Get());
		break;
	case 2: // Floor / road
		Chosen = VillageFloorMaterial ? VillageFloorMaterial.Get()
			: (VillageRubbleMaterial ? VillageRubbleMaterial.Get() : VillageWallMaterial.Get());
		break;
	case 3: // Wood
		Chosen = VillageWoodMaterial ? VillageWoodMaterial.Get() : VillageWallMaterial.Get();
		break;
	case 4: // Sandbag
		Chosen = VillageSandbagMaterial ? VillageSandbagMaterial.Get() : VillageWallMaterial.Get();
		break;
	default:
		break;
	}
	if (Chosen) return Chosen;

	// Final fallback — shared engine material, cached like every other lookup.
	USquadAIAssetCacheSubsystem* Cache = USquadAIAssetCacheSubsystem::Get(const_cast<ADestroyedVillageCompoundActor*>(this));
	return Cache ? Cache->GetDefaultBasicMaterial()
		: LoadObject<UMaterialInterface>(nullptr, TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"));
}

// S8-MAT: palette-tinted material for forwarding to child building actors, so
// the buildings inside the village share the props' colour identity. One DMI
// per category, cached for the lifetime of the build; a silent no-op returning
// the plain material when the palette is off or the base exposes no colour param.
UMaterialInterface* ADestroyedVillageCompoundActor::GetPalettedVillageMaterial(int32 Category)
{
	UMaterialInterface* Base = ResolveVillageMaterial(Category);
	const FLinearColor* Tint = GetVillageCategoryTint(Category);
	if (!Base || !Tint) return Base;

	if (TObjectPtr<UMaterialInstanceDynamic>* Found = PaletteCache.Find(Category))
	{
		if (Found->Get()) return Found->Get();
	}
	UMaterialInstanceDynamic* Dyn = UMaterialInstanceDynamic::Create(Base, this);
	if (!Dyn) return Base;
	static const FName Candidates[] = { TEXT("Color"), TEXT("BaseColor"), TEXT("Tint"), TEXT("BaseColorTint"), TEXT("Albedo"), TEXT("Colour") };
	for (const FName& Param : Candidates)
	{
		Dyn->SetVectorParameterValue(Param, *Tint);
	}
	PaletteCache.Add(Category, Dyn);
	return Dyn;
}

// S8-MAT: palette tint per category. Returns nullptr when the palette is off or
// the category has no colour identity, in which case the caller tints nothing.
const FLinearColor* ADestroyedVillageCompoundActor::GetVillageCategoryTint(int32 Category) const
{
	if (!bApplyVillagePalette) return nullptr;
	switch (Category)
	{
	case 0: return &WallTint;
	case 1: return &RubbleTint;
	case 3: return &WoodTint;
	case 4: return &SandbagTint;
	default: return nullptr; // roads/scorch carry their own dedicated tints
	}
}

UHierarchicalInstancedStaticMeshComponent* ADestroyedVillageCompoundActor::EnsureV2BatchComponent(int32 BatchKind, UStaticMesh* Mesh, UMaterialInterface* Mat, const FLinearColor* Tint)
{
	if (!bBatchV2PropsIntoHISM || !Mesh) return nullptr;
	// S7-H batch kinds: 1=Road 2=Scorch 3=WallProps 4=WoodProps
	const TCHAR* CompName =
		BatchKind == 1 ? TEXT("HISM_V2_Road") :
		BatchKind == 2 ? TEXT("HISM_V2_Scorch") :
		BatchKind == 3 ? TEXT("HISM_V2_Wall") :
		BatchKind == 4 ? TEXT("HISM_V2_Wood") :
		BatchKind == 5 ? TEXT("HISM_V2_Rubble") :       // S7-H2: blocking rubble mounds
		BatchKind == 6 ? TEXT("HISM_V2_Sandbag") :      // S7-H2: barricade + perimeter arcs
		BatchKind == 7 ? TEXT("HISM_V2_RubbleNC") :     // S7-H2: walkover rubble (NoCollision)
		BatchKind == 8 ? TEXT("HISM_V2_WoodNC") :       // S7-H2: walkover planks (NoCollision)
		nullptr;
	if (!CompName) return nullptr;

	// Rebuild-safe: an existing component from a previous BuildVillage keeps its
	// configured mesh/material (inputs are build-constant per batch).
	for (UActorComponent* C : GetComponents())
	{
		if (UHierarchicalInstancedStaticMeshComponent* H = Cast<UHierarchicalInstancedStaticMeshComponent>(C))
		{
			if (H->GetFName() == CompName)
			{
				return H;
			}
		}
	}

	UHierarchicalInstancedStaticMeshComponent* NewHISM = NewObject<UHierarchicalInstancedStaticMeshComponent>(this, CompName);
	if (!NewHISM) return nullptr;
	NewHISM->RegisterComponent();
	NewHISM->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepRelativeTransform);
	NewHISM->SetMobility(EComponentMobility::Static);
	NewHISM->SetStaticMesh(Mesh);
	NewHISM->SetCollisionProfileName((BatchKind == 1 || BatchKind == 2 || BatchKind >= 7) ? TEXT("NoCollision") : TEXT("BlockAllDynamic")); // S7-H2
	if (Mat) NewHISM->SetMaterial(0, Mat);
	if (Tint) VillageTint(NewHISM, *Tint); // ONE shared DMI per batch, not per prop
	return NewHISM;
}

void ADestroyedVillageCompoundActor::SnapVillageToGround()
{
	UWorld* World = GetWorld();
	if (!World) return;

	FHitResult Hit;
	FCollisionQueryParams TraceParams;
	TraceParams.AddIgnoredActor(this);
	for (AActor* Child : SpawnedBuildings)
	{
		if (Child) TraceParams.AddIgnoredActor(Child);
	}

	const FVector CurrentLoc = GetActorLocation();
	if (World->LineTraceSingleByChannel(Hit, CurrentLoc + FVector(0.f, 0.f, 20000.f), CurrentLoc - FVector(0.f, 0.f, 50000.f), ECC_Visibility, TraceParams))
	{
		SetActorLocation(Hit.ImpactPoint + FVector(0.f, 0.f, 10.f));
		BuildVillage();
		UE_LOG(LogTemp, Warning, TEXT("[DestroyedVillage] Snapped village '%s' to ground at %s"), *GetName(), *Hit.ImpactPoint.ToString());
	}
}

void ADestroyedVillageCompoundActor::RandomizeAndRebuild()
{
	VillageSeed = FMath::RandRange(1, 999999);
	BuildVillage();
}

void ADestroyedVillageCompoundActor::Destroyed()
{
	ClearVillage();   // S10-FIX
	Super::Destroyed();
}

void ADestroyedVillageCompoundActor::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (EndPlayReason == EEndPlayReason::Destroyed)
	{
		ClearVillage();
	}
	Super::EndPlay(EndPlayReason);
}

void ADestroyedVillageCompoundActor::ClearVillage()
{
	for (AActor* Act : SpawnedBuildings)
	{
		if (IsValid(Act))
		{
			Act->Destroy();
		}
	}
	SpawnedBuildings.Empty();
	PaletteCache.Empty(); // S8-MAT: palette DMIs are rebuilt with the village

	// S10-FIX: belt-and-braces sweep. If the tracking array was ever lost (actor
	// reconstructed, blueprint recompiled, level reloaded mid-edit) the spawned
	// pieces stayed in the map forever with no way to remove them. Everything we
	// spawn is attached to our root, so walk the attachment tree and clear it.
	{
		TArray<AActor*> Attached;
		GetAttachedActors(Attached, /*bResetArray=*/true, /*bRecursivelyIncludeAttachedActors=*/true);
		for (AActor* Child : Attached)
		{
			if (IsValid(Child) && (Child->IsA<AStaticMeshActor>() || Child->IsA<ADestroyedBuildingActor>()))
			{
				Child->Destroy();
			}
		}
	}

	// S7-H: batch components persist across rebuilds — drop their instances too.
	for (UActorComponent* C : GetComponents())
	{
		if (UHierarchicalInstancedStaticMeshComponent* H = Cast<UHierarchicalInstancedStaticMeshComponent>(C))
		{
			if (H->GetFName().ToString().StartsWith(TEXT("HISM_V2_")))
			{
				H->ClearInstances();
			}
		}
	}
}

#include "Environment/DestroyedBuildingActor.h"
#include "Actors/MountedTurretActor.h"
#include "Actors/AmmoCrateActor.h"
#include "Actors/FirstAidKitActor.h"
#include "Actors/ExplosiveBarrelActor.h"
#include "Characters/EnemySoldier.h"
#include "Performance/SquadAIAssetCacheSubsystem.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/World.h"
#include "Engine/StaticMeshActor.h"
#include "Math/RandomStream.h"
#include "Materials/MaterialInstanceDynamic.h"

ADestroyedBuildingActor::ADestroyedBuildingActor()
{
	PrimaryActorTick.bCanEverTick = false;

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SetRootComponent(SceneRoot);

	HISM_Walls = CreateDefaultSubobject<UHierarchicalInstancedStaticMeshComponent>(TEXT("HISM_Walls"));
	HISM_Walls->SetupAttachment(SceneRoot);
	HISM_Walls->SetCollisionProfileName(TEXT("BlockAllDynamic"));

	HISM_Floors = CreateDefaultSubobject<UHierarchicalInstancedStaticMeshComponent>(TEXT("HISM_Floors"));
	HISM_Floors->SetupAttachment(SceneRoot);
	HISM_Floors->SetCollisionProfileName(TEXT("BlockAllDynamic"));

	HISM_Wood = CreateDefaultSubobject<UHierarchicalInstancedStaticMeshComponent>(TEXT("HISM_Wood"));
	HISM_Wood->SetupAttachment(SceneRoot);
	HISM_Wood->SetCollisionProfileName(TEXT("BlockAllDynamic"));

	HISM_Sandbags = CreateDefaultSubobject<UHierarchicalInstancedStaticMeshComponent>(TEXT("HISM_Sandbags"));
	HISM_Sandbags->SetupAttachment(SceneRoot);
	HISM_Sandbags->SetCollisionProfileName(TEXT("BlockAllDynamic"));

	HISM_Metal = CreateDefaultSubobject<UHierarchicalInstancedStaticMeshComponent>(TEXT("HISM_Metal"));
	HISM_Metal->SetupAttachment(SceneRoot);
	HISM_Metal->SetCollisionProfileName(TEXT("BlockAllDynamic"));

	HISM_Rubble = CreateDefaultSubobject<UHierarchicalInstancedStaticMeshComponent>(TEXT("HISM_Rubble"));
	HISM_Rubble->SetupAttachment(SceneRoot);
	HISM_Rubble->SetCollisionProfileName(TEXT("BlockAllDynamic"));
}

void ADestroyedBuildingActor::BeginPlay()
{
	Super::BeginPlay();
	BuildBuilding();
}

int32 ADestroyedBuildingActor::GetSpawnedElementCount() const
{
	int32 Total = SpawnedElements.Num();
	if (bUseHISMInstancing)
	{
		if (HISM_Walls) Total += HISM_Walls->GetInstanceCount();
		if (HISM_Floors) Total += HISM_Floors->GetInstanceCount();
		if (HISM_Wood) Total += HISM_Wood->GetInstanceCount();
		if (HISM_Sandbags) Total += HISM_Sandbags->GetInstanceCount();
		if (HISM_Metal) Total += HISM_Metal->GetInstanceCount();
		if (HISM_Rubble) Total += HISM_Rubble->GetInstanceCount();
	}
	return Total;
}

void ADestroyedBuildingActor::PrepareHISMComponents()
{
	USquadAIAssetCacheSubsystem* Cache = USquadAIAssetCacheSubsystem::Get(this);
	UStaticMesh* CubeMesh = Cache ? Cache->GetCubeMesh() : LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cube.Cube"));
	UMaterialInterface* DefMat = Cache ? Cache->GetDefaultBasicMaterial() : LoadObject<UMaterialInterface>(nullptr, TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"));

	if (HISM_Walls)
	{
		HISM_Walls->ClearInstances();
		HISM_Walls->SetStaticMesh(CustomWallMesh ? CustomWallMesh.Get() : CubeMesh);
		if (WallMaterialOverride) HISM_Walls->SetMaterial(0, GetTonedMaterial(WallMaterialOverride));
		else if (DefMat) HISM_Walls->SetMaterial(0, GetTonedMaterial(DefMat));
	}

	if (HISM_Floors)
	{
		HISM_Floors->ClearInstances();
		HISM_Floors->SetStaticMesh(CubeMesh);
		if (FloorMaterialOverride) HISM_Floors->SetMaterial(0, GetTonedMaterial(FloorMaterialOverride));
		else if (WallMaterialOverride) HISM_Floors->SetMaterial(0, GetTonedMaterial(WallMaterialOverride));
		else if (DefMat) HISM_Floors->SetMaterial(0, GetTonedMaterial(DefMat));
	}

	if (HISM_Wood)
	{
		HISM_Wood->ClearInstances();
		HISM_Wood->SetStaticMesh(CustomWoodBeamMesh ? CustomWoodBeamMesh.Get() : CubeMesh);
		if (WoodMaterialOverride) HISM_Wood->SetMaterial(0, GetTonedMaterial(WoodMaterialOverride));
		else if (DefMat) HISM_Wood->SetMaterial(0, GetTonedMaterial(DefMat));
	}

	if (HISM_Sandbags)
	{
		HISM_Sandbags->ClearInstances();
		HISM_Sandbags->SetStaticMesh(CustomSandbagMesh ? CustomSandbagMesh.Get() : CubeMesh);
		if (SandbagMaterialOverride) HISM_Sandbags->SetMaterial(0, GetTonedMaterial(SandbagMaterialOverride));
		else if (DefMat) HISM_Sandbags->SetMaterial(0, GetTonedMaterial(DefMat));
	}

	if (HISM_Metal)
	{
		HISM_Metal->ClearInstances();
		HISM_Metal->SetStaticMesh(CubeMesh);
		if (MetalMaterialOverride) HISM_Metal->SetMaterial(0, GetTonedMaterial(MetalMaterialOverride));
		else if (DefMat) HISM_Metal->SetMaterial(0, GetTonedMaterial(DefMat));
	}

	if (HISM_Rubble)
	{
		HISM_Rubble->ClearInstances();
		HISM_Rubble->SetStaticMesh(CustomRubbleMesh ? CustomRubbleMesh.Get() : CubeMesh);
		if (RubbleMaterialOverride) HISM_Rubble->SetMaterial(0, GetTonedMaterial(RubbleMaterialOverride));
		else if (DefMat) HISM_Rubble->SetMaterial(0, GetTonedMaterial(DefMat));
	}
}

void ADestroyedBuildingActor::BuildBuilding()
{
	ClearBuilding();

	SupportPoints.Reset();   // S10-GEO: rebuilt as walls go up

	UWorld* World = GetWorld();
	if (!World) return;

	if (bUseHISMInstancing)
	{
		PrepareHISMComponents();
	}

	FVector Origin = GetActorLocation();
	const FRotator Rotation = GetActorRotation();

	// High-altitude ground trace to snap precisely onto the landscape surface
	FHitResult Hit;
	FCollisionQueryParams TraceParams;
	TraceParams.AddIgnoredActor(this);
	if (World->LineTraceSingleByChannel(Hit, Origin + FVector(0.f, 0.f, 15000.f), Origin - FVector(0.f, 0.f, 50000.f), ECC_Visibility, TraceParams))
	{
		Origin = Hit.ImpactPoint;
		SetActorLocation(Origin);
	}

	const FRandomStream Stream(GenerationSeed);
	// S6-B2: per-build variation state — piece angle jitter stream + building tone
	PieceStream = FRandomStream(GenerationSeed * 31 + 7);
	ToneCache.Empty();
	CurrentToneOffset = (bSeededVariation && ToneJitter > 0.f) ? PieceStream.FRandRange(-ToneJitter, ToneJitter) : 0.f;

	switch (BuildingStyle)
	{
	case EBuildingStyle::TwoStorySniperRuins:
		ConstructTwoStoryRuins(Origin, Rotation, Stream);
		break;
	case EBuildingStyle::SingleStoryMudbrick:
		ConstructSingleStoryMudbrick(Origin, Rotation, Stream);
		break;
	case EBuildingStyle::WalledCourtyardHouse:
		ConstructWalledCourtyard(Origin, Rotation, Stream);
		break;
	case EBuildingStyle::VillageMarketStalls:
		ConstructMarketStalls(Origin, Rotation, Stream);
		break;
	case EBuildingStyle::OutpostObservationTower:
		ConstructOutpostTower(Origin, Rotation, Stream);
		break;
	case EBuildingStyle::VillageMosque: // S6-M
		ConstructVillageMosque(Origin, Rotation, Stream);
		break;
	}

	SpawnSuppliesAndDefenders(Origin, Rotation);

	UE_LOG(LogTemp, Log, TEXT("[DestroyedBuilding] %s built style %d (HISM: %s, Total: %d elements) at %s"),
		*GetName(), (int32)BuildingStyle, bUseHISMInstancing ? TEXT("TRUE") : TEXT("FALSE"), GetSpawnedElementCount(), *Origin.ToString());
}

void ADestroyedBuildingActor::RandomizeAndRebuild()
{
	GenerationSeed = FMath::RandRange(1, 999999);
	BuildBuilding();
}

void ADestroyedBuildingActor::Destroyed()
{
	// S10-FIX: owned/attached actors are NOT auto-destroyed by AActor::Destroy().
	ClearBuilding();
	Super::Destroyed();
}

void ADestroyedBuildingActor::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (EndPlayReason == EEndPlayReason::Destroyed)
	{
		ClearBuilding();
	}
	Super::EndPlay(EndPlayReason);
}

void ADestroyedBuildingActor::ClearBuilding()
{
	SupportPoints.Reset();   // S10-GEO
	if (HISM_Walls) HISM_Walls->ClearInstances();
	if (HISM_Floors) HISM_Floors->ClearInstances();
	if (HISM_Wood) HISM_Wood->ClearInstances();
	if (HISM_Sandbags) HISM_Sandbags->ClearInstances();
	if (HISM_Metal) HISM_Metal->ClearInstances();
	if (HISM_Rubble) HISM_Rubble->ClearInstances();

	for (AActor* Act : SpawnedElements)
	{
		if (IsValid(Act))
		{
			Act->Destroy();
		}
	}
	SpawnedElements.Empty();
}

void ADestroyedBuildingActor::SpawnWallSegment(const FVector& Location, const FRotator& Rotation, const FVector& Scale, UMaterialInterface* Mat)
{
	// S6-B5: seeded micro angle jitter — real mudbrick never meets at perfect 90°
	FRotator EffRotation = Rotation;
	if (bSeededVariation && PieceAngleJitterDeg > 0.f)
	{
		const float J = PieceAngleJitterDeg;
		EffRotation = Rotation + FRotator(PieceStream.FRandRange(-J, J) * 0.7f, PieceStream.FRandRange(-J, J), PieceStream.FRandRange(-J, J) * 0.7f);
	}

	if (bUseHISMInstancing)
	{
		const FTransform InstanceTransform(EffRotation, Location, Scale);
		if (Mat == FloorMaterialOverride || (FloorMaterialOverride && Scale.Z < 0.25f))
		{
			if (HISM_Floors) HISM_Floors->AddInstance(InstanceTransform, true);
		}
		else
		{
			if (HISM_Walls) HISM_Walls->AddInstance(InstanceTransform, true);
		}
		return;
	}

	UWorld* World = GetWorld();
	if (!World) return;

	FActorSpawnParameters SpawnParams;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	// S5-14: WP ownership for every spawned fragment.
	SpawnParams.Owner = this;

	AStaticMeshActor* WallActor = World->SpawnActor<AStaticMeshActor>(AStaticMeshActor::StaticClass(), Location, EffRotation, SpawnParams);
	if (WallActor && WallActor->GetStaticMeshComponent())
	{
		WallActor->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);

		USquadAIAssetCacheSubsystem* Cache = USquadAIAssetCacheSubsystem::Get(this);
		UStaticMesh* MeshToUse = CustomWallMesh;
		if (!MeshToUse)
		{
			MeshToUse = Cache ? Cache->GetCubeMesh() : LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cube.Cube"));
		}

		if (MeshToUse)
		{
			WallActor->GetStaticMeshComponent()->SetStaticMesh(MeshToUse);
			WallActor->GetStaticMeshComponent()->SetRelativeScale3D(Scale);
			WallActor->GetStaticMeshComponent()->SetCollisionProfileName(TEXT("BlockAllDynamic"));

			UMaterialInterface* MatToApply = Mat;
			if (!MatToApply && WallMaterialOverride)
			{
				MatToApply = WallMaterialOverride;
			}
			else if (!MatToApply && FloorMaterialOverride && Scale.Z < 0.5f)
			{
				MatToApply = FloorMaterialOverride;
			}
			if (!MatToApply)
			{
				MatToApply = Cache ? Cache->GetDefaultBasicMaterial() : LoadObject<UMaterialInterface>(nullptr, TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"));
			}

			if (MatToApply)
			{
				WallActor->GetStaticMeshComponent()->SetMaterial(0, GetTonedMaterial(MatToApply));
			}
		}
		SpawnedElements.Add(WallActor);
	}
}

void ADestroyedBuildingActor::SpawnRubblePile(const FVector& Location, const FRotator& Rotation, const FVector& Scale)
{
	if (bUseHISMInstancing && HISM_Rubble)
	{
		HISM_Rubble->AddInstance(FTransform(Rotation, Location, Scale), true);
		return;
	}

	UWorld* World = GetWorld();
	if (!World) return;

	FActorSpawnParameters SpawnParams;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	// S5-14: WP ownership for every spawned fragment.
	SpawnParams.Owner = this;

	AStaticMeshActor* Rubble = World->SpawnActor<AStaticMeshActor>(AStaticMeshActor::StaticClass(), Location, Rotation, SpawnParams);
	if (Rubble && Rubble->GetStaticMeshComponent())
	{
		Rubble->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);

		USquadAIAssetCacheSubsystem* Cache = USquadAIAssetCacheSubsystem::Get(this);
		UStaticMesh* MeshToUse = CustomRubbleMesh;
		if (!MeshToUse)
		{
			MeshToUse = Cache ? Cache->GetCubeMesh() : LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cube.Cube"));
		}

		if (MeshToUse)
		{
			Rubble->GetStaticMeshComponent()->SetStaticMesh(MeshToUse);
			Rubble->GetStaticMeshComponent()->SetRelativeScale3D(Scale);
			Rubble->GetStaticMeshComponent()->SetCollisionProfileName(TEXT("BlockAllDynamic"));

			UMaterialInterface* MatToApply = RubbleMaterialOverride;
			if (!MatToApply)
			{
				MatToApply = Cache ? Cache->GetDefaultBasicMaterial() : LoadObject<UMaterialInterface>(nullptr, TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"));
			}

			if (MatToApply)
			{
				Rubble->GetStaticMeshComponent()->SetMaterial(0, GetTonedMaterial(MatToApply));
			}
		}
		SpawnedElements.Add(Rubble);
	}
}

void ADestroyedBuildingActor::SpawnWoodenBeam(const FVector& Location, const FRotator& Rotation, const FVector& Scale)
{
	if (bUseHISMInstancing && HISM_Wood)
	{
		HISM_Wood->AddInstance(FTransform(Rotation, Location, Scale), true);
		return;
	}

	UWorld* World = GetWorld();
	if (!World) return;

	FActorSpawnParameters SpawnParams;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	// S5-14: WP ownership for every spawned fragment.
	SpawnParams.Owner = this;

	AStaticMeshActor* BeamActor = World->SpawnActor<AStaticMeshActor>(AStaticMeshActor::StaticClass(), Location, Rotation, SpawnParams);
	if (BeamActor && BeamActor->GetStaticMeshComponent())
	{
		BeamActor->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);

		USquadAIAssetCacheSubsystem* Cache = USquadAIAssetCacheSubsystem::Get(this);
		UStaticMesh* MeshToUse = CustomWoodBeamMesh;
		if (!MeshToUse)
		{
			MeshToUse = Cache ? Cache->GetCubeMesh() : LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cube.Cube"));
		}

		if (MeshToUse)
		{
			BeamActor->GetStaticMeshComponent()->SetStaticMesh(MeshToUse);
			BeamActor->GetStaticMeshComponent()->SetRelativeScale3D(Scale);
			BeamActor->GetStaticMeshComponent()->SetCollisionProfileName(TEXT("BlockAllDynamic"));

			UMaterialInterface* MatToApply = WoodMaterialOverride;
			if (!MatToApply)
			{
				MatToApply = Cache ? Cache->GetDefaultBasicMaterial() : LoadObject<UMaterialInterface>(nullptr, TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"));
			}
			if (MatToApply)
			{
				BeamActor->GetStaticMeshComponent()->SetMaterial(0, GetTonedMaterial(MatToApply));
			}
		}
		SpawnedElements.Add(BeamActor);
	}
}

void ADestroyedBuildingActor::SpawnWindowFrame(const FVector& Location, const FRotator& Rotation, float Width, float Height)
{
	const FVector Right = FRotationMatrix(Rotation).GetScaledAxis(EAxis::Y);
	const FVector Up = FVector::UpVector;

	// 1. Base Stone Sill
	SpawnWallSegment(Location + Up * 35.f, Rotation, FVector(0.42f, Width / 100.f, 0.25f), RubbleMaterialOverride ? RubbleMaterialOverride.Get() : WallMaterialOverride.Get());

	// 2. Sandbag Firing Rest under window
	SpawnSandbagParapet(Location + Up * 40.f, Rotation, FVector(0.35f, (Width * 0.85f) / 100.f, 0.45f));

	// 3. Left & Right Frame Posts
	SpawnWallSegment(Location - Right * (Width * 0.45f) + Up * (Height * 0.5f), Rotation, FVector(0.38f, 0.25f, Height / 100.f));
	SpawnWallSegment(Location + Right * (Width * 0.45f) + Up * (Height * 0.5f), Rotation, FVector(0.38f, 0.25f, Height / 100.f));

	// 4. Top Heavy Wooden Lintel
	SpawnWoodenBeam(Location + Up * Height, Rotation, FVector(0.45f, (Width * 1.25f) / 100.f, 0.35f));

	// 5. Broken Wooden Window Crossbar
	SpawnWoodenBeam(Location + Up * (Height * 0.62f), Rotation, FVector(0.12f, (Width * 0.9f) / 100.f, 0.12f));
}

void ADestroyedBuildingActor::SpawnDoorway(const FVector& Location, const FRotator& Rotation, float Width, float Height)
{
	const FVector Forward = Rotation.Vector();
	const FVector Right = FRotationMatrix(Rotation).GetScaledAxis(EAxis::Y);
	const FVector Up = FVector::UpVector;

	// 1. Threshold Step Slab
	SpawnWallSegment(Location + Up * 8.f, Rotation, FVector(0.5f, Width / 100.f, 0.16f), FloorMaterialOverride);

	// 2. Left & Right Doorway Jambs
	SpawnWallSegment(Location - Right * (Width * 0.48f) + Up * (Height * 0.5f), Rotation, FVector(0.45f, 0.32f, Height / 100.f));
	SpawnWallSegment(Location + Right * (Width * 0.48f) + Up * (Height * 0.5f), Rotation, FVector(0.45f, 0.32f, Height / 100.f));

	// 3. Heavy Timber Lintel Beam
	SpawnWoodenBeam(Location + Up * Height, Rotation, FVector(0.5f, (Width * 1.35f) / 100.f, 0.45f));

	// 4. Slanted Corrugated Metal Awning over entrance
	SpawnMetalSheet(Location + Forward * 65.f + Up * (Height + 15.f), Rotation + FRotator(18.f, 0.f, 0.f), FVector(1.6f, (Width * 1.35f) / 100.f, 0.05f));

	// 5. Splintered Propped Wooden Door Remnant
	SpawnWoodenBeam(Location - Right * (Width * 0.4f) + Forward * 25.f + Up * (Height * 0.4f), Rotation + FRotator(12.f, 28.f, 5.f), FVector(0.08f, 0.85f, (Height * 0.8f) / 100.f));
}

void ADestroyedBuildingActor::SpawnWallButtress(const FVector& Location, const FRotator& Rotation, float Height)
{
	const FVector Up = FVector::UpVector;

	// Multi-tiered stone pilaster buttress
	SpawnWallSegment(Location + Up * (Height * 0.15f), Rotation, FVector(0.85f, 0.85f, (Height * 0.3f) / 100.f), RubbleMaterialOverride ? RubbleMaterialOverride.Get() : WallMaterialOverride.Get());
	SpawnWallSegment(Location + Up * (Height * 0.5f), Rotation, FVector(0.65f, 0.65f, (Height * 0.7f) / 100.f));
	SpawnWallSegment(Location + Up * (Height * 0.9f), Rotation, FVector(0.5f, 0.5f, (Height * 0.2f) / 100.f));
}

void ADestroyedBuildingActor::SpawnRubbleSlope(const FVector& Location, const FRotator& Rotation, const FVector& Extents)
{
	const FVector Forward = Rotation.Vector();
	const FVector Up = FVector::UpVector;

	// Main angled slab for seamless walk-up
	SpawnWallSegment(Location + Up * (Extents.Z * 0.5f), Rotation + FRotator(24.f, 0.f, 0.f), FVector(Extents.X / 100.f, Extents.Y / 100.f, 0.22f), FloorMaterialOverride);

	// Rubble heaps flanking the slope
	SpawnRubblePile(Location - Forward * (Extents.X * 0.45f) + Up * 15.f, Rotation + FRotator(10.f, 25.f, 0.f), FVector(1.6f, 2.0f, 0.5f));
	SpawnRubblePile(Location + Up * (Extents.Z * 0.35f), Rotation + FRotator(-8.f, 40.f, 0.f), FVector(1.4f, 1.6f, 0.45f));
}

void ADestroyedBuildingActor::SpawnHangingRafters(const FVector& Location, const FRotator& Rotation, float Span, int32 Count)
{
	const FVector Right = FRotationMatrix(Rotation).GetScaledAxis(EAxis::Y);
	const FVector Up = FVector::UpVector;

	for (int32 i = 0; i < Count; ++i)
	{
		const float OffsetY = (i - (Count - 1) * 0.5f) * (Span / FMath::Max(1, Count));
		const float BeamLength = (i % 2 == 0) ? 6.2f : 3.8f; // Broken staggered lengths
		const FVector BeamLoc = Location + Right * OffsetY;

		// Main horizontal rafter
		SpawnWoodenBeam(BeamLoc, Rotation, FVector(BeamLength, 0.16f, 0.22f));

		// Dangling broken timber joist
		if (i % 2 == 1)
		{
			SpawnWoodenBeam(BeamLoc + Up * -40.f, Rotation + FRotator(45.f, 15.f, 0.f), FVector(1.8f, 0.12f, 0.14f));
		}

		// Angled tin patch over rafters
		if (i == 1 || i == Count - 2)
		{
			SpawnMetalSheet(BeamLoc + Up * 12.f, Rotation + FRotator(10.f, 5.f, 0.f), FVector(2.4f, 2.8f, 0.04f));
		}
	}
}

void ADestroyedBuildingActor::SpawnSandbagParapet(const FVector& Location, const FRotator& Rotation, const FVector& Scale)
{
	if (bUseHISMInstancing && HISM_Sandbags)
	{
		HISM_Sandbags->AddInstance(FTransform(Rotation, Location, Scale), true);
		return;
	}

	UWorld* World = GetWorld();
	if (!World) return;

	FActorSpawnParameters SpawnParams;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	// S5-14: WP ownership for every spawned fragment.
	SpawnParams.Owner = this;

	AStaticMeshActor* SandbagActor = World->SpawnActor<AStaticMeshActor>(AStaticMeshActor::StaticClass(), Location, Rotation, SpawnParams);
	if (SandbagActor && SandbagActor->GetStaticMeshComponent())
	{
		SandbagActor->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);

		USquadAIAssetCacheSubsystem* Cache = USquadAIAssetCacheSubsystem::Get(this);
		UStaticMesh* MeshToUse = CustomSandbagMesh;
		if (!MeshToUse)
		{
			MeshToUse = Cache ? Cache->GetCubeMesh() : LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cube.Cube"));
		}

		if (MeshToUse)
		{
			SandbagActor->GetStaticMeshComponent()->SetStaticMesh(MeshToUse);
			SandbagActor->GetStaticMeshComponent()->SetRelativeScale3D(Scale);
			SandbagActor->GetStaticMeshComponent()->SetCollisionProfileName(TEXT("BlockAllDynamic"));

			UMaterialInterface* MatToApply = SandbagMaterialOverride;
			if (!MatToApply)
			{
				MatToApply = Cache ? Cache->GetDefaultBasicMaterial() : LoadObject<UMaterialInterface>(nullptr, TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"));
			}
			if (MatToApply)
			{
				SandbagActor->GetStaticMeshComponent()->SetMaterial(0, GetTonedMaterial(MatToApply));
			}
		}
		SpawnedElements.Add(SandbagActor);
	}
}

void ADestroyedBuildingActor::SpawnMetalSheet(const FVector& Location, const FRotator& Rotation, const FVector& Scale)
{
	if (bUseHISMInstancing && HISM_Metal)
	{
		HISM_Metal->AddInstance(FTransform(Rotation, Location, Scale), true);
		return;
	}

	UWorld* World = GetWorld();
	if (!World) return;

	FActorSpawnParameters SpawnParams;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	// S5-14: WP ownership for every spawned fragment.
	SpawnParams.Owner = this;

	AStaticMeshActor* SheetActor = World->SpawnActor<AStaticMeshActor>(AStaticMeshActor::StaticClass(), Location, Rotation, SpawnParams);
	if (SheetActor && SheetActor->GetStaticMeshComponent())
	{
		SheetActor->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);

		USquadAIAssetCacheSubsystem* Cache = USquadAIAssetCacheSubsystem::Get(this);
		UStaticMesh* MeshToUse = Cache ? Cache->GetCubeMesh() : LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cube.Cube"));
		if (MeshToUse)
		{
			SheetActor->GetStaticMeshComponent()->SetStaticMesh(MeshToUse);
			SheetActor->GetStaticMeshComponent()->SetRelativeScale3D(Scale);
			SheetActor->GetStaticMeshComponent()->SetCollisionProfileName(TEXT("BlockAllDynamic"));

			UMaterialInterface* MatToApply = MetalMaterialOverride;
			if (!MatToApply)
			{
				MatToApply = Cache ? Cache->GetDefaultBasicMaterial() : LoadObject<UMaterialInterface>(nullptr, TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"));
			}
			if (MatToApply)
			{
				SheetActor->GetStaticMeshComponent()->SetMaterial(0, GetTonedMaterial(MatToApply));
			}
		}
		SpawnedElements.Add(SheetActor);
	}
}

void ADestroyedBuildingActor::SpawnCrateStack(const FVector& Location, const FRotator& Rotation)
{
	if (bUseHISMInstancing && HISM_Wood)
	{
		HISM_Wood->AddInstance(FTransform(Rotation + FRotator(0.f, 15.f, 0.f), Location + FVector(0.f, 0.f, 35.f), FVector(0.7f, 0.7f, 0.7f)), true);
		HISM_Wood->AddInstance(FTransform(Rotation + FRotator(0.f, -25.f, 0.f), Location + Rotation.RotateVector(FVector(75.f, 15.f, 35.f)), FVector(0.7f, 0.7f, 0.7f)), true);
		HISM_Wood->AddInstance(FTransform(Rotation + FRotator(0.f, 40.f, 0.f), Location + FVector(35.f, 10.f, 95.f), FVector(0.6f, 0.6f, 0.6f)), true);
		return;
	}

	UWorld* World = GetWorld();
	if (!World) return;

	FActorSpawnParameters SpawnParams;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	// S5-14: WP ownership for every spawned fragment.
	SpawnParams.Owner = this;

	USquadAIAssetCacheSubsystem* Cache = USquadAIAssetCacheSubsystem::Get(this);
	UStaticMesh* CubeMesh = Cache ? Cache->GetCubeMesh() : LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cube.Cube"));
	if (!CubeMesh) return;

	// Bottom Crate 1
	AStaticMeshActor* Crate1 = World->SpawnActor<AStaticMeshActor>(AStaticMeshActor::StaticClass(), Location + FVector(0.f, 0.f, 35.f), Rotation + FRotator(0.f, 15.f, 0.f), SpawnParams);
	if (Crate1 && Crate1->GetStaticMeshComponent())
	{
		Crate1->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
		Crate1->GetStaticMeshComponent()->SetStaticMesh(CubeMesh);
		Crate1->GetStaticMeshComponent()->SetRelativeScale3D(FVector(0.7f, 0.7f, 0.7f));
		Crate1->GetStaticMeshComponent()->SetCollisionProfileName(TEXT("BlockAllDynamic"));
		if (WoodMaterialOverride) Crate1->GetStaticMeshComponent()->SetMaterial(0, GetTonedMaterial(WoodMaterialOverride));
		SpawnedElements.Add(Crate1);
	}

	// Bottom Crate 2
	AStaticMeshActor* Crate2 = World->SpawnActor<AStaticMeshActor>(AStaticMeshActor::StaticClass(), Location + Rotation.RotateVector(FVector(75.f, 15.f, 35.f)), Rotation + FRotator(0.f, -25.f, 0.f), SpawnParams);
	if (Crate2 && Crate2->GetStaticMeshComponent())
	{
		Crate2->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
		Crate2->GetStaticMeshComponent()->SetStaticMesh(CubeMesh);
		Crate2->GetStaticMeshComponent()->SetRelativeScale3D(FVector(0.7f, 0.7f, 0.7f));
		Crate2->GetStaticMeshComponent()->SetCollisionProfileName(TEXT("BlockAllDynamic"));
		if (WoodMaterialOverride) Crate2->GetStaticMeshComponent()->SetMaterial(0, GetTonedMaterial(WoodMaterialOverride));
		SpawnedElements.Add(Crate2);
	}

	// Top Crate
	AStaticMeshActor* Crate3 = World->SpawnActor<AStaticMeshActor>(AStaticMeshActor::StaticClass(), Location + FVector(35.f, 10.f, 95.f), Rotation + FRotator(0.f, 40.f, 0.f), SpawnParams);
	if (Crate3 && Crate3->GetStaticMeshComponent())
	{
		Crate3->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
		Crate3->GetStaticMeshComponent()->SetStaticMesh(CubeMesh);
		Crate3->GetStaticMeshComponent()->SetRelativeScale3D(FVector(0.6f, 0.6f, 0.6f));
		Crate3->GetStaticMeshComponent()->SetCollisionProfileName(TEXT("BlockAllDynamic"));
		if (WoodMaterialOverride) Crate3->GetStaticMeshComponent()->SetMaterial(0, GetTonedMaterial(WoodMaterialOverride));
		SpawnedElements.Add(Crate3);
	}
}

UMaterialInterface* ADestroyedBuildingActor::GetTonedMaterial(UMaterialInterface* BaseMaterial)
{
	if (!BaseMaterial) return nullptr;
	if (CurrentToneOffset == 0.f) return BaseMaterial; // variation off or zero draw
	if (TObjectPtr<UMaterialInstanceDynamic>* Found = ToneCache.Find(BaseMaterial))
	{
		return Found->Get();
	}
	// S6-B4: one DMI per material per building — warm plaster tone variance, whole
	// building shaded uniformly. Silent no-op on colour-param-less materials.
	UMaterialInstanceDynamic* Dyn = UMaterialInstanceDynamic::Create(BaseMaterial, this);
	if (!Dyn) return BaseMaterial;
	const float O = CurrentToneOffset;
	const FLinearColor Tone(1.f + O, 1.f + O * 0.7f, 1.f + O * 0.45f, 1.f);
	static const FName Candidates[] = { TEXT("Color"), TEXT("BaseColor"), TEXT("Tint"), TEXT("BaseColorTint"), TEXT("Albedo"), TEXT("Colour") };
	for (const FName& Param : Candidates)
	{
		Dyn->SetVectorParameterValue(Param, Tone);
	}
	ToneCache.Add(BaseMaterial, Dyn);
	return Dyn;
}

// =============================================================================
// S10-GEO: geometry helpers (see header for rationale)
// =============================================================================

void ADestroyedBuildingActor::RegisterSupport(const FVector& TopPoint)
{
	SupportPoints.Add(TopPoint);
}

bool ADestroyedBuildingActor::IsSupported(const FVector& Point, float Radius, float ZTolerance) const
{
	const float R2 = Radius * Radius;
	for (const FVector& S : SupportPoints)
	{
		if (FMath::Abs(S.Z - Point.Z) > ZTolerance)
		{
			continue;
		}
		if (FVector::DistSquared2D(S, Point) <= R2)
		{
			return true;
		}
	}
	return false;
}

void ADestroyedBuildingActor::SpawnCompositeWall(const FVector& Center, const FRotator& Rotation,
	float Length, float Height, float Thickness, float IntactFraction, UMaterialInterface* Mat)
{
	if (Length <= 1.f || Height <= 1.f)
	{
		return;
	}

	const FVector Along = FRotationMatrix(Rotation).GetScaledAxis(EAxis::Y);
	const FVector Norm  = FRotationMatrix(Rotation).GetScaledAxis(EAxis::X);
	const FVector Up    = FVector::UpVector;

	// Adobe is laid in courses and is thicker at the base (batter). Splitting the
	// wall into courses is what gives it a silhouette instead of a flat slab.
	const int32 Courses = FMath::Clamp(FMath::RoundToInt(Height / 55.f), 3, 9);
	const float CourseH = Height / Courses;

	// Horizontal split: a few masses per course, so the top line can erode and
	// individual blocks can slump out of plane.
	const int32 Bays = FMath::Clamp(FMath::RoundToInt(Length / 140.f), 2, 8);
	const float BayL = Length / Bays;

	const float Clamped = FMath::Clamp(IntactFraction, 0.f, 1.f);

	for (int32 b = 0; b < Bays; ++b)
	{
		const float BayCentre = -Length * 0.5f + BayL * (b + 0.5f);

		// How tall this bay survives. Ends of a blown span taper down rather than
		// stopping at a clean vertical edge.
		float BayFrac = 1.f;
		if (Clamped < 1.f)
		{
			const float T = (b + 0.5f) / Bays;             // 0..1 along the wall
			BayFrac = FMath::Clamp((Clamped - T) * 3.0f + 0.35f, 0.f, 1.f);
		}
		if (bSeededVariation)
		{
			BayFrac *= PieceStream.FRandRange(0.88f, 1.0f);   // eroded top line
		}

		const int32 BayCourses = FMath::RoundToInt(Courses * BayFrac);
		if (BayCourses <= 0)
		{
			continue;
		}

		for (int32 ci = 0; ci < BayCourses; ++ci)
		{
			const float Z = CourseH * (ci + 0.5f);

			// Batter: base courses are thicker, top courses thinner.
			const float TaperT = (float)ci / FMath::Max(1, Courses - 1);
			float Th = Thickness * FMath::Lerp(1.12f, 0.86f, TaperT);

			// Per-block jitter so no two courses line up perfectly.
			float OutOfPlane = 0.f;
			float LenScale = 1.f;
			if (bSeededVariation)
			{
				Th *= PieceStream.FRandRange(0.96f, 1.06f);
				// S13-GEO: out-of-plane jitter halved. Combined with the gaps
				// below it was reading as stacked Lego bricks rather than a
				// hand-laid adobe wall.
				OutOfPlane = PieceStream.FRandRange(-0.018f, 0.018f) * Thickness;
				// S13-GEO: was 0.97..1.0, i.e. every block was SHRUNK by up to
				// 3% of its bay. Adjacent bays therefore never touched and the
				// wall showed a hard vertical seam at every bay boundary - the
				// "blocks are visibly separate" Lego effect. Blocks must
				// OVERLAP; the overlap is hidden inside the neighbour.
				LenScale = PieceStream.FRandRange(1.02f, 1.06f);

				// The odd block has slumped or been knocked out entirely.
				if (ci == BayCourses - 1 && PieceStream.FRand() < 0.22f)
				{
					continue;
				}
			}

			// S13-GEO: the bottom course is driven into the ground so the wall
			// never floats above uneven terrain, and its foot is hidden rather
			// than showing a clean gap against the dirt.
			float BlockH = CourseH * 1.10f;   // was 1.02f - too small to hide the course seam
			float ZOffset = Z;
			if (ci == 0)
			{
				BlockH += GroundEmbedDepth;
				ZOffset -= GroundEmbedDepth * 0.5f;
			}

			const FVector Loc = Center
				+ Along * BayCentre
				+ Norm * OutOfPlane
				+ Up * ZOffset;

			SpawnWallSegment(Loc, Rotation,
				FVector(Th / 100.f, (BayL * LenScale) / 100.f, BlockH / 100.f), Mat);
		}

		// This bay can carry a roof only if it survived to near full height.
		if (BayCourses >= Courses - 1)
		{
			RegisterSupport(Center + Along * BayCentre + Up * Height);
		}
		else
		{
			// Collapsed portion leaves a rubble skirt at its foot.
			if (bSpawnDebrisFields && bSeededVariation && PieceStream.FRand() < 0.55f)
			{
				SpawnRubblePile(Center + Along * BayCentre + Norm * (Thickness * 0.5f)
						+ Up * (CourseH * 0.35f),
					Rotation + FRotator(0.f, PieceStream.FRandRange(-25.f, 25.f), 0.f),
					FVector(BayL / 110.f, BayL / 90.f, 0.45f));
			}
		}
	}
}

void ADestroyedBuildingActor::SpawnRoofParapet(const FVector& Center, const FRotator& Rotation,
	float Length, float RoofZ, float Height, float Thickness)
{
	if (Length <= 1.f)
	{
		return;
	}

	const FVector Along = FRotationMatrix(Rotation).GetScaledAxis(EAxis::Y);
	const FVector Up = FVector::UpVector;

	// "Standing brick" roof edge with ventilation gaps, as on Dezful/Shushtar
	// roofs. Some merlons are missing or knocked askew.
	const int32 Count = FMath::Clamp(FMath::RoundToInt(Length / 70.f), 3, 16);
	const float Step = Length / Count;

	for (int32 i = 0; i < Count; ++i)
	{
		if (bSeededVariation && PieceStream.FRand() < 0.28f)
		{
			continue;   // gap: ventilation opening or war damage
		}

		float H = Height;
		FRotator R = Rotation;
		if (bSeededVariation)
		{
			H *= PieceStream.FRandRange(0.65f, 1.05f);
			R += FRotator(PieceStream.FRandRange(-4.f, 4.f), PieceStream.FRandRange(-6.f, 6.f), 0.f);
		}

		const FVector Loc = Center + Along * (-Length * 0.5f + Step * (i + 0.5f))
			+ Up * (RoofZ + H * 0.5f);

		SpawnWallSegment(Loc, R, FVector(Thickness / 100.f, (Step * 0.82f) / 100.f, H / 100.f));
	}
}

void ADestroyedBuildingActor::SpawnBeamStubs(const FVector& WallCenter, const FRotator& Rotation,
	float Length, float Z, int32 Count)
{
	if (Count <= 0)
	{
		return;
	}

	const FVector Along = FRotationMatrix(Rotation).GetScaledAxis(EAxis::Y);
	const FVector Norm = FRotationMatrix(Rotation).GetScaledAxis(EAxis::X);
	const FVector Up = FVector::UpVector;

	for (int32 i = 0; i < Count; ++i)
	{
		if (bSeededVariation && PieceStream.FRand() < 0.2f)
		{
			continue;
		}
		const float T = (i + 0.5f) / Count;
		const float Off = FMath::Lerp(-Length * 0.5f, Length * 0.5f, T);

		float Poke = 22.f;
		FRotator R = Rotation;
		if (bSeededVariation)
		{
			Poke *= PieceStream.FRandRange(0.6f, 1.5f);
			R += FRotator(PieceStream.FRandRange(-5.f, 3.f), PieceStream.FRandRange(-4.f, 4.f), 0.f);
		}

		SpawnWoodenBeam(WallCenter + Along * Off + Norm * (Poke * 0.5f) + Up * Z, R,
			FVector(Poke / 100.f, 0.14f, 0.13f));
	}
}

void ADestroyedBuildingActor::SpawnSupportedRoof(const FVector& Origin, const FRotator& Rotation,
	float HalfW, float HalfD, float RoofZ, float FloorZ, const FRandomStream& Stream)
{
	const FVector Forward = FRotationMatrix(Rotation).GetScaledAxis(EAxis::X);
	const FVector Right = FRotationMatrix(Rotation).GetScaledAxis(EAxis::Y);
	const FVector Up = FVector::UpVector;

	FRandomStream RS = Stream;

	// Grid of slabs rather than one big plate, so the roof can break up honestly.
	const int32 NX = FMath::Clamp(FMath::RoundToInt((HalfD * 2.f) / 180.f), 2, 5);
	const int32 NY = FMath::Clamp(FMath::RoundToInt((HalfW * 2.f) / 180.f), 2, 5);
	const float TileD = (HalfD * 2.f) / NX;
	const float TileW = (HalfW * 2.f) / NY;

	// A slab needs support within roughly one tile of its centre.
	const float SupportRadius = FMath::Max(TileD, TileW) * 0.95f;

	for (int32 ix = 0; ix < NX; ++ix)
	{
		for (int32 iy = 0; iy < NY; ++iy)
		{
			const float FX = -HalfD + TileD * (ix + 0.5f);
			const float FY = -HalfW + TileW * (iy + 0.5f);
			const FVector TileCentre = Origin + Forward * FX + Right * FY + Up * RoofZ;

			const bool bHasSupport = IsSupported(TileCentre, SupportRadius, RoofZ * 0.45f + 60.f);

			if (bHasSupport)
			{
				FRotator SlabRot = Rotation;
				float Z = RoofZ;
				if (bSeededVariation)
				{
					// Sagging: a supported slab still droops a little.
					// S13-GEO: tilt/drop reduced. At a ~2 m tile a 1.6 deg lean
					// shifts an edge ~5 cm, which ate the whole overlap and left
					// daylight between adjacent roof slabs.
					SlabRot += FRotator(RS.FRandRange(-0.7f, 0.7f), RS.FRandRange(-0.7f, 0.7f), 0.f);
					Z -= RS.FRandRange(0.f, 2.f);
				}
				SpawnWallSegment(Origin + Forward * FX + Right * FY + Up * Z, SlabRot,
					// S13-GEO: 1.02 -> 1.12 so neighbouring slabs genuinely overlap.
					FVector((TileD * 1.12f) / 100.f, (TileW * 1.12f) / 100.f, 0.22f),
					FloorMaterialOverride);
				continue;
			}

			// UNSUPPORTED. Previously a slab was placed here anyway and appeared to
			// float. Now it either rests on a surviving timber post, or it has
			// already fallen into the room.
			const bool bPropped = bSpawnWoodenRafters && RS.FRand() < 0.3f;
			if (bPropped)
			{
				const FVector PostBase = Origin + Forward * FX + Right * FY + Up * FloorZ;
				SpawnWoodenBeam(PostBase + Up * ((RoofZ - FloorZ) * 0.5f),
					Rotation + FRotator(0.f, RS.FRandRange(-6.f, 6.f), 0.f),
					FVector(0.16f, 0.16f, (RoofZ - FloorZ) / 100.f));

				SpawnWallSegment(Origin + Forward * FX + Right * FY + Up * (RoofZ - 4.f),
					Rotation + FRotator(RS.FRandRange(-1.2f, 1.2f), 0.f, RS.FRandRange(-1.2f, 1.2f)),
					// S13-GEO: was 0.92 - each slab was SMALLER than its cell, so
					// this path always left holes. This is the "ceiling parts are
					// not connected" report.
					FVector((TileD * 1.10f) / 100.f, (TileW * 1.10f) / 100.f, 0.20f),
					FloorMaterialOverride);
				RegisterSupport(Origin + Forward * FX + Right * FY + Up * RoofZ);
				continue;
			}

			// Collapsed slab lying at an angle on the floor / on its own debris.
			const float Tilt = RS.FRandRange(8.f, 34.f) * (RS.FRand() < 0.5f ? -1.f : 1.f);
			SpawnWallSegment(Origin + Forward * (FX + RS.FRandRange(-20.f, 20.f))
					+ Right * (FY + RS.FRandRange(-20.f, 20.f))
					+ Up * (FloorZ + RS.FRandRange(14.f, 46.f)),
				Rotation + FRotator(Tilt, RS.FRandRange(-20.f, 20.f), Tilt * 0.4f),
				FVector((TileD * RS.FRandRange(0.45f, 0.8f)) / 100.f,
						(TileW * RS.FRandRange(0.45f, 0.8f)) / 100.f, 0.20f),
				FloorMaterialOverride);

			if (bSpawnDebrisFields)
			{
				SpawnRubblePile(Origin + Forward * FX + Right * FY + Up * (FloorZ + 16.f),
					Rotation + FRotator(0.f, RS.FRandRange(0.f, 360.f), 0.f),
					FVector(TileD / 130.f, TileW / 130.f, 0.42f));
			}
		}
	}
}

void ADestroyedBuildingActor::ConstructTwoStoryRuins(const FVector& Origin, const FRotator& Rot, const FRandomStream& Stream)
{
	const FVector Forward = Rot.Vector();
	FVector Right = FRotationMatrix(Rot).GetScaledAxis(EAxis::Y);
	// S6-B1: seeded mirror — doubles silhouette variety; all placements stay consistent
	FRandomStream VS = Stream;
	if (bSeededVariation && VS.RandRange(0, 1) == 1) { Right = -Right; }
	auto JD = [&](float Lo, float Hi) -> float { return bSeededVariation ? VS.FRandRange(Lo, Hi) : 1.f; };
	const FVector Up = FVector::UpVector;

	const float HalfW = BuildingWidth * 0.5f * JD(0.94f, 1.07f);
	const float HalfD = BuildingDepth * 0.5f * JD(0.94f, 1.07f);
	const float H1 = FloorHeight * JD(0.95f, 1.06f);

	// 1. Stepped Foundation Plinth & Entry Steps
	SpawnWallSegment(Origin + Up * 6.f, Rot, FVector(BuildingDepth * 1.05f / 100.f, BuildingWidth * 1.05f / 100.f, 0.15f), RubbleMaterialOverride ? RubbleMaterialOverride.Get() : FloorMaterialOverride.Get());
	SpawnWallSegment(Origin + Forward * (HalfD + 40.f) + Up * 4.f, Rot, FVector(0.8f, 2.5f, 0.10f), FloorMaterialOverride);

	// 2. Corner Buttress Pilasters
	SpawnWallButtress(Origin - Forward * HalfD - Right * HalfW, Rot, H1 * 1.8f);
	SpawnWallButtress(Origin - Forward * HalfD + Right * HalfW, Rot, H1 * 1.8f);
	SpawnWallButtress(Origin + Forward * HalfD - Right * HalfW, Rot, H1 * 1.2f);
	SpawnWallButtress(Origin + Forward * HalfD + Right * HalfW, Rot, H1 * 0.8f);

	// 3. Ground Floor Walls — S10-GEO: composite battered masonry
	const float WallTh2 = 40.f;
	const FRotator SideRot2 = Rot + FRotator(0.f, 90.f, 0.f);

	// Back wall, with a ragged remnant of the upper storey still standing on it
	SpawnCompositeWall(Origin - Forward * HalfD, Rot, BuildingWidth, H1, WallTh2);
	SpawnCompositeWall(Origin - Forward * HalfD - Right * (HalfW * 0.25f) + Up * H1, Rot,
		BuildingWidth * 0.45f, 70.f, WallTh2 * 0.92f, 0.7f);

	// Left wall, split around two windows
	SpawnCompositeWall(Origin - Right * HalfW - Forward * (HalfD * 0.75f), SideRot2,
		BuildingDepth * 0.25f, H1, WallTh2);
	SpawnWindowFrame(Origin - Right * HalfW - Forward * (HalfD * 0.25f), SideRot2, 180.f, 220.f);
	SpawnCompositeWall(Origin - Right * HalfW + Forward * (HalfD * 0.25f), SideRot2,
		BuildingDepth * 0.25f, H1, WallTh2);
	SpawnWindowFrame(Origin - Right * HalfW + Forward * (HalfD * 0.75f), SideRot2, 180.f, 220.f);

	// Right wall breached in the centre
	SpawnCompositeWall(Origin + Right * HalfW - Forward * (HalfD * 0.55f), SideRot2,
		BuildingDepth * 0.4f, H1, WallTh2);
	SpawnCompositeWall(Origin + Right * HalfW + Forward * (HalfD * 0.55f), SideRot2,
		BuildingDepth * 0.35f, H1, WallTh2, 0.55f);

	// Front wall, split around the main doorway
	SpawnCompositeWall(Origin + Forward * HalfD - Right * (HalfW * 0.55f), Rot,
		BuildingWidth * 0.35f, H1, WallTh2);
	SpawnDoorway(Origin + Forward * HalfD, Rot, 220.f, 240.f);
	SpawnCompositeWall(Origin + Forward * HalfD + Right * (HalfW * 0.55f), Rot,
		BuildingWidth * 0.35f, H1, WallTh2);

	// Rafter ends below the first-floor line
	if (bSpawnWoodenRafters)
	{
		SpawnBeamStubs(Origin + Forward * HalfD + Forward * (WallTh2 * 0.5f), Rot,
			BuildingWidth * 0.85f, H1 - 30.f, 7);
	}

	// 4. Interior Partition Dividing Wall (Divides Ground Floor into 2 Rooms)
	if (bSpawnInteriorPartitions)
	{
		// Left partition wall with doorway cutout
		SpawnWallSegment(Origin - Forward * (HalfD * 0.1f) - Right * (HalfW * 0.6f) + Up * (H1 * 0.5f), Rot, FVector(0.28f, (BuildingWidth * 0.35f) / 100.f, H1 / 100.f));
		SpawnWallSegment(Origin - Forward * (HalfD * 0.1f) - Right * (HalfW * 0.05f) + Up * (H1 * 0.5f), Rot, FVector(0.28f, (BuildingWidth * 0.25f) / 100.f, H1 / 100.f));
		SpawnWoodenBeam(Origin - Forward * (HalfD * 0.1f) - Right * (HalfW * 0.35f) + Up * 220.f, Rot, FVector(0.3f, 1.8f, 0.3f));
	}

	// 5. Mantleable Collapsed Rubble Slope & 2nd Floor Ramp
	// Seamless angled walk-up connecting ground level directly to upper sniper loft
	SpawnRubbleSlope(Origin + Right * (HalfW * 0.25f) + Forward * (HalfD * 0.15f), Rot, FVector(520.f, 320.f, H1));

	// 6. Second Floor Slab — S10-GEO: support-aware, so the loft can no longer
	//    hang in mid-air over the breached side.
	SpawnSupportedRoof(Origin, Rot, HalfW * 0.9f, HalfD * 0.85f, H1, 12.f, VS);
	SpawnRoofParapet(Origin - Forward * HalfD, Rot, BuildingWidth * 0.8f, H1, 40.f, WallTh2 * 0.6f);

	// 7. Second Floor Broken Sniper Loft Walls
	SpawnWallSegment(Origin - Forward * HalfD + Up * (H1 + H1 * 0.45f), Rot, FVector(0.4f, BuildingWidth / 100.f, (H1 * 0.9f) / 100.f));
	SpawnWallSegment(Origin - Right * HalfW - Forward * (HalfD * 0.35f) + Up * (H1 + H1 * 0.45f), Rot + FRotator(0.f, 90.f, 0.f), FVector(0.4f, (BuildingDepth * 0.55f) / 100.f, (H1 * 0.9f) / 100.f));

	// 8. Rooftop Sniper Sandbag Embrasures & Parapet
	if (bSpawnSandbagEmbrasures)
	{
		SpawnSandbagParapet(Origin - Right * (HalfW * 0.35f) + Forward * (HalfD * 0.15f) + Up * (H1 + 45.f), Rot, FVector(0.45f, 2.8f, 0.85f));
		SpawnSandbagParapet(Origin - Right * (HalfW * 0.85f) + Up * (H1 + 45.f), Rot + FRotator(0.f, 90.f, 0.f), FVector(0.45f, 2.4f, 0.85f));
		SpawnSandbagParapet(Origin + Right * (HalfW * 0.35f) - Forward * (HalfD * 0.3f) + Up * (H1 + 45.f), Rot, FVector(0.45f, 2.2f, 0.85f));
	}

	// 9. Charred Ceiling Rafters & Hanging Timbers
	if (bSpawnWoodenRafters)
	{
		SpawnHangingRafters(Origin - Forward * (HalfD * 0.2f) + Up * (H1 * 1.85f), Rot, BuildingWidth * 0.85f, VS.RandRange(4, 9)); // S6-B6
	}

	// 10. Battlefield Dressing & Crate Stacks
	SpawnCrateStack(Origin - Right * (HalfW * 0.65f) - Forward * (HalfD * 0.65f), Rot);
	SpawnCrateStack(Origin + Right * (HalfW * 0.65f) - Forward * (HalfD * 0.65f), Rot + FRotator(0.f, 35.f, 0.f));

	if (bSpawnDebrisFields)
	{
		SpawnRubblePile(Origin + Right * (HalfW + 70.f) + Up * 20.f, Rot + FRotator(15.f, 45.f, 0.f), FVector(2.0f, 2.6f, 0.65f));
		SpawnRubblePile(Origin + Right * (HalfW - 25.f) + Up * 15.f, Rot + FRotator(-10.f, 30.f, 0.f), FVector(1.5f, 1.8f, 0.5f));
		SpawnRubblePile(Origin - Forward * (HalfD + 60.f) + Up * 15.f, Rot + FRotator(5.f, -20.f, 0.f), FVector(1.4f, 2.0f, 0.45f));
	}
}

void ADestroyedBuildingActor::ConstructSingleStoryMudbrick(const FVector& Origin, const FRotator& Rot, const FRandomStream& Stream)
{
	const FVector Forward = Rot.Vector();
	FVector Right = FRotationMatrix(Rot).GetScaledAxis(EAxis::Y);
	// S6-B1: seeded mirror — doubles silhouette variety; all placements stay consistent
	FRandomStream VS = Stream;
	if (bSeededVariation && VS.RandRange(0, 1) == 1) { Right = -Right; }
	auto JD = [&](float Lo, float Hi) -> float { return bSeededVariation ? VS.FRandRange(Lo, Hi) : 1.f; };
	const FVector Up = FVector::UpVector;

	const float HalfW = BuildingWidth * 0.48f * JD(0.94f, 1.07f);
	const float HalfD = BuildingDepth * 0.48f * JD(0.94f, 1.07f);
	const float H = FloorHeight * 0.90f * JD(0.94f, 1.06f);

	// 1. Foundation Plinth
	SpawnWallSegment(Origin + Up * 6.f, Rot, FVector(BuildingDepth * 0.95f / 100.f, BuildingWidth * 0.95f / 100.f, 0.16f), FloorMaterialOverride);

	// 2. Corner Buttresses
	SpawnWallButtress(Origin - Forward * HalfD - Right * HalfW, Rot, H);
	SpawnWallButtress(Origin - Forward * HalfD + Right * HalfW, Rot, H);
	SpawnWallButtress(Origin + Forward * HalfD - Right * HalfW, Rot, H * 0.85f);

	// 3. Adobe Walls — S10-GEO: composite, battered, eroded courses instead of
	//    one scaled cube per wall.
	const float WallTh = 42.f;
	const FRotator SideRot = Rot + FRotator(0.f, 90.f, 0.f);

	// Back wall — intact
	SpawnCompositeWall(Origin - Forward * HalfD, Rot, BuildingWidth * 0.9f, H, WallTh);

	// Left wall, split around the window opening
	SpawnCompositeWall(Origin - Right * HalfW - Forward * (HalfD * 0.45f), SideRot,
		BuildingDepth * 0.45f, H, WallTh);
	SpawnWindowFrame(Origin - Right * HalfW + Forward * (HalfD * 0.2f), SideRot, 160.f, 200.f);
	SpawnCompositeWall(Origin - Right * HalfW + Forward * (HalfD * 0.7f), SideRot,
		BuildingDepth * 0.25f, H, WallTh);

	// Front wall, split around the doorway
	SpawnCompositeWall(Origin + Forward * HalfD - Right * (HalfW * 0.5f), Rot,
		BuildingWidth * 0.4f, H, WallTh);
	SpawnDoorway(Origin + Forward * HalfD + Right * (HalfW * 0.1f), Rot, 180.f, 220.f);
	SpawnCompositeWall(Origin + Forward * HalfD + Right * (HalfW * 0.65f), Rot,
		BuildingWidth * 0.3f, H, WallTh);

	// Right wall took the shell hit — collapses progressively along its length,
	// so the roof above it will now correctly fail to find support.
	SpawnCompositeWall(Origin + Right * HalfW, SideRot,
		BuildingDepth * 0.9f, H, WallTh, /*IntactFraction=*/0.45f);

	// Protruding rafter ends under the roof line (very Khuzestani)
	if (bSpawnWoodenRafters)
	{
		SpawnBeamStubs(Origin - Forward * HalfD - Forward * (WallTh * 0.5f), Rot,
			BuildingWidth * 0.8f, H - 26.f, 6);
		SpawnBeamStubs(Origin + Forward * HalfD + Forward * (WallTh * 0.5f), Rot,
			BuildingWidth * 0.8f, H - 26.f, 5);
	}

	// 4. Interior Partition Wall
	if (bSpawnInteriorPartitions)
	{
		SpawnWallSegment(Origin - Right * (HalfW * 0.15f) - Forward * (HalfD * 0.1f) + Up * (H * 0.5f), Rot + FRotator(0.f, 90.f, 0.f), FVector(0.28f, (BuildingDepth * 0.55f) / 100.f, H / 100.f));
	}

	// 5. Protruding Ceiling Timbers
	if (bSpawnWoodenRafters)
	{
		SpawnHangingRafters(Origin - Forward * (HalfD * 0.1f) + Up * (H - 12.f), Rot, BuildingWidth * 0.85f, 5);
	}

	// 6. Flat adobe roof — S10-GEO: support-aware. Slabs only appear where a wall
	//    actually survived beneath them; the rest have fallen into the room.
	SpawnSupportedRoof(Origin, Rot, HalfW, HalfD, H, 10.f, VS);

	// Roof-edge parapet of standing bricks with ventilation gaps
	SpawnRoofParapet(Origin - Forward * HalfD, Rot, BuildingWidth * 0.9f, H, 46.f, WallTh * 0.62f);
	SpawnRoofParapet(Origin - Right * HalfW, SideRot, BuildingDepth * 0.85f, H, 42.f, WallTh * 0.62f);

	// 7. Sandbag Parapets & Crate Dressing
	if (bSpawnSandbagEmbrasures)
	{
		SpawnSandbagParapet(Origin + Right * HalfW + Forward * (HalfD * 0.35f) + Up * 40.f, Rot + FRotator(0.f, 90.f, 0.f), FVector(0.45f, 2.2f, 0.85f));
	}
	SpawnCrateStack(Origin - Right * (HalfW * 0.6f) + Forward * (HalfD * 0.3f), Rot);

	if (bSpawnDebrisFields)
	{
		SpawnRubblePile(Origin + Right * (HalfW + 40.f) - Forward * (HalfD * 0.35f) + Up * 20.f, Rot + FRotator(5.f, 20.f, 0.f), FVector(2.2f, 2.6f, 0.7f));
	}
}

void ADestroyedBuildingActor::ConstructWalledCourtyard(const FVector& Origin, const FRotator& Rot, const FRandomStream& Stream)
{
	const FVector Forward = Rot.Vector();
	FVector Right = FRotationMatrix(Rot).GetScaledAxis(EAxis::Y);
	// S6-B1: seeded mirror — doubles silhouette variety; all placements stay consistent
	FRandomStream VS = Stream;
	if (bSeededVariation && VS.RandRange(0, 1) == 1) { Right = -Right; }
	auto JD = [&](float Lo, float Hi) -> float { return bSeededVariation ? VS.FRandRange(Lo, Hi) : 1.f; };
	const FVector Up = FVector::UpVector;

	const float CompoundW = BuildingWidth * 1.55f * JD(0.93f, 1.08f);
	const float CompoundD = BuildingDepth * 1.55f * JD(0.93f, 1.08f);
	const float WallH = 240.0f * JD(0.90f, 1.10f);

	// 1. Perimeter Boundary Walls with Pilasters
	SpawnWallSegment(Origin - Forward * (CompoundD * 0.5f) + Up * (WallH * 0.5f), Rot, FVector(0.38f, CompoundW / 100.f, WallH / 100.f));
	SpawnWallSegment(Origin - Right * (CompoundW * 0.5f) + Up * (WallH * 0.5f), Rot + FRotator(0.f, 90.f, 0.f), FVector(0.38f, CompoundD / 100.f, WallH / 100.f));
	SpawnWallSegment(Origin + Right * (CompoundW * 0.5f) + Up * (WallH * 0.5f), Rot + FRotator(0.f, 90.f, 0.f), FVector(0.38f, CompoundD / 100.f, WallH / 100.f));

	// 2. Corner Buttress Pillars
	SpawnWallButtress(Origin - Forward * (CompoundD * 0.5f) - Right * (CompoundW * 0.5f), Rot, WallH * 1.15f);
	SpawnWallButtress(Origin - Forward * (CompoundD * 0.5f) + Right * (CompoundW * 0.5f), Rot, WallH * 1.15f);
	SpawnWallButtress(Origin + Forward * (CompoundD * 0.5f) - Right * (CompoundW * 0.5f), Rot, WallH * 1.15f);
	SpawnWallButtress(Origin + Forward * (CompoundD * 0.5f) + Right * (CompoundW * 0.5f), Rot, WallH * 1.15f);

	// 3. Front Wall with Large Breached Wooden Gate
	SpawnWallSegment(Origin + Forward * (CompoundD * 0.5f) - Right * (CompoundW * 0.35f) + Up * (WallH * 0.5f), Rot, FVector(0.38f, (CompoundW * 0.35f) / 100.f, WallH / 100.f));
	SpawnWallSegment(Origin + Forward * (CompoundD * 0.5f) + Right * (CompoundW * 0.35f) + Up * (WallH * 0.5f), Rot, FVector(0.38f, (CompoundW * 0.35f) / 100.f, WallH / 100.f));

	// Wooden Gate Posts & Archway Lintel
	SpawnWoodenBeam(Origin + Forward * (CompoundD * 0.5f) - Right * 160.f + Up * (WallH * 0.5f), Rot, FVector(0.4f, 0.4f, WallH / 100.f));
	SpawnWoodenBeam(Origin + Forward * (CompoundD * 0.5f) + Right * 160.f + Up * (WallH * 0.5f), Rot, FVector(0.4f, 0.4f, WallH / 100.f));
	SpawnWoodenBeam(Origin + Forward * (CompoundD * 0.5f) + Up * (WallH + 15.f), Rot, FVector(0.45f, 3.8f, 0.4f));

	// Sandbags along front breach
	if (bSpawnSandbagEmbrasures)
	{
		SpawnSandbagParapet(Origin + Forward * (CompoundD * 0.5f) + Right * 50.f + Up * 40.f, Rot, FVector(0.45f, 2.5f, 0.85f));
	}

	// 4. Inner Rear Mudbrick House
	const FVector HouseLoc = Origin - Forward * (CompoundD * 0.22f);
	ConstructSingleStoryMudbrick(HouseLoc, Rot, Stream);

	// 5. Courtyard Battlefield Supplies & Crates
	SpawnCrateStack(Origin + Right * (CompoundW * 0.28f) - Forward * (CompoundD * 0.1f), Rot);
	SpawnCrateStack(Origin - Right * (CompoundW * 0.28f) + Forward * (CompoundD * 0.15f), Rot + FRotator(0.f, 45.f, 0.f));
}

void ADestroyedBuildingActor::ConstructMarketStalls(const FVector& Origin, const FRotator& Rot, const FRandomStream& Stream)
{
	const FVector Forward = Rot.Vector();
	FVector Right = FRotationMatrix(Rot).GetScaledAxis(EAxis::Y);
	// S6-B1: seeded mirror — doubles silhouette variety; all placements stay consistent
	FRandomStream VS = Stream;
	if (bSeededVariation && VS.RandRange(0, 1) == 1) { Right = -Right; }
	auto JD = [&](float Lo, float Hi) -> float { return bSeededVariation ? VS.FRandRange(Lo, Hi) : 1.f; };
	const FVector Up = FVector::UpVector;

	// Row of 3 ruined marketplace stalls with stone counters, wooden frames, and tin canopies
	for (int32 i = -1; i <= 1; ++i)
	{
		const FVector StallLoc = Origin + Right * (i * 390.f);

		// Stepped Foundation
		SpawnWallSegment(StallLoc + Up * 6.f, Rot, FVector(4.2f, 3.8f, 0.12f), FloorMaterialOverride);

		// Stone Partition Walls
		SpawnWallSegment(StallLoc - Right * 190.f + Up * 140.f, Rot + FRotator(0.f, 90.f, 0.f), FVector(0.38f, 3.8f, 2.8f));
		SpawnWallSegment(StallLoc + Right * 190.f + Up * 140.f, Rot + FRotator(0.f, 90.f, 0.f), FVector(0.38f, 3.8f, 2.8f));

		// Back Wall
		SpawnWallSegment(StallLoc - Forward * 190.f + Up * 140.f, Rot, FVector(0.38f, 3.9f, 2.8f));

		// Stone Display Counter with Sandbag Base
		SpawnWallSegment(StallLoc + Forward * 120.f + Up * 45.f, Rot, FVector(0.55f, 3.4f, 0.85f));
		SpawnSandbagParapet(StallLoc + Forward * 140.f + Up * 40.f, Rot, FVector(0.35f, 3.0f, 0.75f));

		// Wooden Roof Posts & Slanted Metal Canopy
		SpawnWoodenBeam(StallLoc + Forward * 130.f - Right * 170.f + Up * 140.f, Rot, FVector(0.22f, 0.22f, 2.8f));
		SpawnWoodenBeam(StallLoc + Forward * 130.f + Right * 170.f + Up * 140.f, Rot, FVector(0.22f, 0.22f, 2.8f));
		SpawnMetalSheet(StallLoc + Up * 270.f, Rot + FRotator(-18.f, 0.f, 0.f), FVector(3.6f, 3.9f, 0.05f));

		// Produce Crates & Rubble
		SpawnCrateStack(StallLoc - Forward * 60.f, Rot + FRotator(0.f, i * 25.f, 0.f));
		SpawnRubblePile(StallLoc + Forward * 160.f + Up * 15.f, Rot + FRotator(10.f, i * 45.f, 0.f), FVector(1.4f, 1.6f, 0.45f));
	}
}

void ADestroyedBuildingActor::ConstructOutpostTower(const FVector& Origin, const FRotator& Rot, const FRandomStream& Stream)
{
	const FVector Forward = Rot.Vector();
	FVector Right = FRotationMatrix(Rot).GetScaledAxis(EAxis::Y);
	// S6-B1: seeded mirror — doubles silhouette variety; all placements stay consistent
	FRandomStream VS = Stream;
	if (bSeededVariation && VS.RandRange(0, 1) == 1) { Right = -Right; }
	auto JD = [&](float Lo, float Hi) -> float { return bSeededVariation ? VS.FRandRange(Lo, Hi) : 1.f; };
	const FVector Up = FVector::UpVector;

	const float TowerH = FloorHeight * 1.65f * JD(0.92f, 1.10f);
	const float TowerRadius = 360.f * JD(0.92f, 1.08f);

	// 1. Tower Foundation Base & Stepped Threshold
	SpawnWallSegment(Origin + Up * 8.f, Rot, FVector(7.5f, 7.5f, 0.35f), FloorMaterialOverride);
	SpawnWallSegment(Origin + Forward * (TowerRadius + 40.f) + Up * 4.f, Rot, FVector(0.8f, 2.8f, 0.12f), FloorMaterialOverride);

	// 2. Corner Buttresses
	SpawnWallButtress(Origin - Forward * TowerRadius - Right * TowerRadius, Rot, TowerH * 1.1f);
	SpawnWallButtress(Origin - Forward * TowerRadius + Right * TowerRadius, Rot, TowerH * 1.1f);
	SpawnWallButtress(Origin + Forward * TowerRadius - Right * TowerRadius, Rot, TowerH * 1.1f);
	SpawnWallButtress(Origin + Forward * TowerRadius + Right * TowerRadius, Rot, TowerH * 1.1f);

	// 3. 4 Thick Fortified Walls with Narrow Firing Slits
	SpawnWallSegment(Origin - Forward * TowerRadius + Up * (TowerH * 0.5f), Rot, FVector(0.65f, 7.2f, TowerH / 100.f));
	SpawnWallSegment(Origin - Right * TowerRadius + Up * (TowerH * 0.5f), Rot + FRotator(0.f, 90.f, 0.f), FVector(0.65f, 7.2f, TowerH / 100.f));
	SpawnWallSegment(Origin + Right * TowerRadius + Up * (TowerH * 0.5f), Rot + FRotator(0.f, 90.f, 0.f), FVector(0.65f, 7.2f, TowerH / 100.f));

	// Front Wall with Arched Entrance & Heavy Door Posts
	SpawnWallSegment(Origin + Forward * TowerRadius - Right * 170.f + Up * (TowerH * 0.5f), Rot, FVector(0.65f, 2.4f, TowerH / 100.f));
	SpawnWallSegment(Origin + Forward * TowerRadius + Right * 170.f + Up * (TowerH * 0.5f), Rot, FVector(0.65f, 2.4f, TowerH / 100.f));
	SpawnWoodenBeam(Origin + Forward * TowerRadius + Up * (TowerH * 0.82f), Rot, FVector(0.65f, 2.8f, 0.45f));

	// 4. Rooftop Slab & 360° Sandbag Rampart Nest
	SpawnWallSegment(Origin + Up * TowerH, Rot, FVector(7.6f, 7.6f, 0.35f), FloorMaterialOverride);
	SpawnSandbagParapet(Origin + Forward * (TowerRadius - 25.f) + Up * (TowerH + 45.f), Rot, FVector(0.48f, 6.2f, 0.85f));
	SpawnSandbagParapet(Origin - Right * (TowerRadius - 25.f) + Up * (TowerH + 45.f), Rot + FRotator(0.f, 90.f, 0.f), FVector(0.48f, 6.2f, 0.85f));
	SpawnSandbagParapet(Origin + Right * (TowerRadius - 25.f) + Up * (TowerH + 45.f), Rot + FRotator(0.f, 90.f, 0.f), FVector(0.48f, 6.2f, 0.85f));
	SpawnSandbagParapet(Origin - Forward * (TowerRadius - 25.f) + Up * (TowerH + 45.f), Rot, FVector(0.48f, 6.2f, 0.85f));

	// 5. Wooden Lookout Canopy Frame
	SpawnWoodenBeam(Origin - Forward * (TowerRadius - 40.f) - Right * (TowerRadius - 40.f) + Up * (TowerH + 120.f), Rot, FVector(0.24f, 0.24f, 2.4f));
	SpawnWoodenBeam(Origin - Forward * (TowerRadius - 40.f) + Right * (TowerRadius - 40.f) + Up * (TowerH + 120.f), Rot, FVector(0.24f, 0.24f, 2.4f));
	SpawnWoodenBeam(Origin + Forward * (TowerRadius - 40.f) - Right * (TowerRadius - 40.f) + Up * (TowerH + 120.f), Rot, FVector(0.24f, 0.24f, 2.4f));
	SpawnWoodenBeam(Origin + Forward * (TowerRadius - 40.f) + Right * (TowerRadius - 40.f) + Up * (TowerH + 120.f), Rot, FVector(0.24f, 0.24f, 2.4f));
	SpawnMetalSheet(Origin + Up * (TowerH + 245.f), Rot + FRotator(8.f, 0.f, 0.f), FVector(5.2f, 5.2f, 0.05f));

	// 6. Perimeter Ammo Caches & Base Fortifications
	SpawnSandbagParapet(Origin + Forward * (TowerRadius + 130.f) + Right * 130.f + Up * 40.f, Rot, FVector(0.48f, 2.5f, 0.85f));
	SpawnCrateStack(Origin + Forward * (TowerRadius + 90.f) - Right * 190.f, Rot);
}

void ADestroyedBuildingActor::ConstructVillageMosque(const FVector& Origin, const FRotator& Rot, const FRandomStream& Stream)
{
	// S6-M: village mosque — intact-ish flat-roofed prayer hall with archway door,
	// high window slits, mihrab alcove, and a buttressed square minaret beside it.
	const FVector Forward = Rot.Vector();
	FVector Right = FRotationMatrix(Rot).GetScaledAxis(EAxis::Y);
	FRandomStream VS = Stream;
	if (bSeededVariation && VS.RandRange(0, 1) == 1) { Right = -Right; } // mirror: minaret swaps side
	auto JD = [&](float Lo, float Hi) -> float { return bSeededVariation ? VS.FRandRange(Lo, Hi) : 1.f; };
	const FVector Up = FVector::UpVector;

	const float HalfW = BuildingWidth * 0.55f * JD(0.94f, 1.07f);
	const float HalfD = BuildingDepth * 0.42f * JD(0.94f, 1.07f);
	const float RoofH = FloorHeight * 0.80f * JD(0.95f, 1.06f);

	// --- 1. Prayer hall shell --- S10-GEO: composite battered masonry ----
	const float MTh = 40.f;
	const FRotator MSide = Rot + FRotator(0.f, 90.f, 0.f);

	// Rear (qibla) wall — kept solid
	SpawnCompositeWall(Origin - Forward * HalfD, Rot, HalfW * 2.f, RoofH, MTh);

	// Left wall: solid + one high window slit
	SpawnCompositeWall(Origin - Right * HalfW - Forward * (HalfD * 0.55f), MSide, HalfD, RoofH, MTh);
	SpawnWindowFrame(Origin - Right * HalfW + Forward * (HalfD * 0.25f), MSide, 130.f, 170.f);
	SpawnCompositeWall(Origin - Right * HalfW + Forward * (HalfD * 0.75f), MSide, HalfD * 0.5f, RoofH, MTh);

	// Right wall: matching slit (mirror flips these around)
	SpawnCompositeWall(Origin + Right * HalfW - Forward * (HalfD * 0.55f), MSide, HalfD, RoofH, MTh);
	SpawnWindowFrame(Origin + Right * HalfW + Forward * (HalfD * 0.25f), MSide, 130.f, 170.f);
	SpawnCompositeWall(Origin + Right * HalfW + Forward * (HalfD * 0.75f), MSide, HalfD * 0.5f, RoofH, MTh);

	// Front wall flanking the prayer archway door
	SpawnCompositeWall(Origin + Forward * HalfD - Right * (HalfW * 0.62f), Rot, HalfW * 0.62f, RoofH, MTh);
	SpawnDoorway(Origin + Forward * HalfD, Rot, 200.f, 235.f);
	SpawnCompositeWall(Origin + Forward * HalfD + Right * (HalfW * 0.62f), Rot, HalfW * 0.62f, RoofH, MTh);

	// Mihrab alcove block against the qibla wall
	SpawnWallSegment(Origin - Forward * (HalfD - 35.f) + Up * 105.f, Rot, FVector(0.42f, 1.15f, 2.1f));

	// Flat roof: mostly intact; 25% of mosques lost the front-right corner to a
	// shell hit (two partial slabs leave a blasted notch over the doorway)
	SpawnSupportedRoof(Origin, Rot, HalfW, HalfD, RoofH, 8.f, VS);

	// Parapet along the qibla and side walls
	SpawnRoofParapet(Origin - Forward * HalfD, Rot, HalfW * 1.9f, RoofH, 52.f, MTh * 0.6f);
	SpawnRoofParapet(Origin - Right * HalfW, MSide, HalfD * 1.8f, RoofH, 48.f, MTh * 0.6f);
	SpawnRoofParapet(Origin + Right * HalfW, MSide, HalfD * 1.8f, RoofH, 48.f, MTh * 0.6f);

	// Charred ceiling beams visible through the doorway / roof notch
	if (bSpawnWoodenRafters)
	{
		SpawnHangingRafters(Origin + Up * (RoofH * 0.92f), Rot, HalfW * 1.8f, VS.RandRange(5, 8));
	}

	// --- 2. Buttressed square minaret ------------------------------------
	const FVector MinBase = Origin + Right * (HalfW + 200.f) - Forward * (HalfD * 0.25f);
	const float ShaftH = FloorHeight * JD(2.2f, 2.6f);

	// Solid mudbrick shaft + base buttresses
	SpawnWallSegment(MinBase + Up * (ShaftH * 0.5f), Rot, FVector(1.05f, 1.05f, ShaftH / 100.f));
	SpawnWallButtress(MinBase - Right * 70.f - Forward * 70.f, Rot, 170.f * JD(0.9f, 1.1f));
	SpawnWallButtress(MinBase + Right * 70.f - Forward * 70.f, Rot, 170.f);
	SpawnWallButtress(MinBase - Right * 70.f + Forward * 70.f, Rot, 170.f * JD(0.9f, 1.1f));
	SpawnWallButtress(MinBase + Right * 70.f + Forward * 70.f, Rot, 170.f);

	// Muezzin balcony near the crown: ring slab + broken parapet stubs
	SpawnWallSegment(MinBase + Up * (ShaftH - 45.f), Rot, FVector(1.55f, 1.55f, 0.35f), FloorMaterialOverride);
	SpawnWallSegment(MinBase + Up * (ShaftH - 12.f) - Forward * 72.f, Rot + FRotator(0.f, 90.f, 0.f), FVector(0.28f, 1.45f, 0.55f));
	SpawnWallSegment(MinBase + Up * (ShaftH - 12.f) + Right * 72.f, Rot, FVector(0.28f, 1.45f, 0.32f)); // short = battle-broken

	// Wooden muezzin-platform beams shed by the topple, occasionally
	if (VS.FRand() < 0.3f)
	{
		SpawnWoodenBeam(MinBase + Right * 150.f + Up * 12.f, Rot + FRotator(VS.FRandRange(70.f, 82.f), VS.FRandRange(0.f, 360.f), 0.f), FVector(0.28f, 2.2f, 0.28f));
		SpawnWoodenBeam(MinBase - Forward * 120.f + Up * 10.f, Rot + FRotator(VS.FRandRange(72.f, 85.f), VS.FRandRange(0.f, 360.f), 0.f), FVector(0.28f, 2.6f, 0.28f));
	}

	// Low enclosure wall tying hall to minaret
	SpawnWallSegment(Origin + Right * (HalfW + 100.f) + Forward * (HalfD * 0.9f) + Up * 40.f, Rot + FRotator(0.f, 90.f, 0.f), FVector(0.30f, 1.6f, 0.80f));

	if (bSpawnDebrisFields)
	{
		SpawnRubblePile(MinBase + Forward * 130.f + Up * 14.f, Rot + FRotator(8.f, VS.FRandRange(0.f, 360.f), 0.f), FVector(1.3f, 1.7f, 0.42f));
		SpawnRubblePile(Origin + Forward * (HalfD + 55.f) + Up * 14.f, Rot + FRotator(-6.f, VS.FRandRange(0.f, 360.f), 0.f), FVector(1.2f, 1.5f, 0.38f));
	}
}

void ADestroyedBuildingActor::SpawnSuppliesAndDefenders(const FVector& Center, const FRotator& Rotation)
{
	UWorld* World = GetWorld();
	if (!World) return;

	const FVector Forward = Rotation.Vector();
	const FVector Right = FRotationMatrix(Rotation).GetScaledAxis(EAxis::Y);
	const FVector Up = FVector::UpVector;

	FActorSpawnParameters SpawnParams;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;
	// S5-14: WP ownership for every spawned fragment.
	SpawnParams.Owner = this;

	// 1. First Aid Kit
	if (bSpawnSupplies)
	{
		const FVector MedLoc = Center - Forward * (BuildingDepth * 0.25f) - Right * (BuildingWidth * 0.25f) + Up * 20.f;
		AFirstAidKitActor* Kit = World->SpawnActor<AFirstAidKitActor>(AFirstAidKitActor::StaticClass(), MedLoc, Rotation, SpawnParams);
		if (Kit)
		{
			Kit->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
			SpawnedElements.Add(Kit);
		}

		// Ammo Crate
		const FVector AmmoLoc = Center - Forward * (BuildingDepth * 0.25f) + Right * (BuildingWidth * 0.25f) + Up * 20.f;
		AAmmoCrateActor* Ammo = World->SpawnActor<AAmmoCrateActor>(AAmmoCrateActor::StaticClass(), AmmoLoc, Rotation, SpawnParams);
		if (Ammo)
		{
			Ammo->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
			SpawnedElements.Add(Ammo);
		}
	}

	// 2. Mounted Heavy MG on Roof / Sandbag Nest
	if (bSpawnMountedHeavyMG)
	{
		const float MountZ = (BuildingStyle == EBuildingStyle::TwoStorySniperRuins) ? (FloorHeight + 20.f) :
							 (BuildingStyle == EBuildingStyle::OutpostObservationTower) ? (FloorHeight * 1.6f + 20.f) : 20.f;

		const FVector MGLoc = Center + Forward * (BuildingDepth * 0.2f) + Up * MountZ;
		AMountedTurretActor* Turret = World->SpawnActor<AMountedTurretActor>(AMountedTurretActor::StaticClass(), MGLoc, Rotation, SpawnParams);
		if (Turret)
		{
			Turret->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
			SpawnedElements.Add(Turret);
		}
	}

	// 3. Red Explosive Barrel near Breach
	if (bSpawnExplosiveBarrels)
	{
		const FVector BarrelLoc = Center + Right * (BuildingWidth * 0.55f) + Up * 20.f;
		AExplosiveBarrelActor* Barrel = World->SpawnActor<AExplosiveBarrelActor>(AExplosiveBarrelActor::StaticClass(), BarrelLoc, Rotation, SpawnParams);
		if (Barrel)
		{
			Barrel->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
			SpawnedElements.Add(Barrel);
		}
	}

	// 4. Enemy Defenders / Snipers
	if (bSpawnHostileDefenders)
	{
		for (int32 i = 0; i < DefenderCount; ++i)
		{
			const float OffsetX = (i - (DefenderCount - 1) * 0.5f) * 150.f;
			const float DefenderZ = (BuildingStyle == EBuildingStyle::TwoStorySniperRuins && i == 0) ? (FloorHeight + 40.f) : 40.f;
			const FVector EnemyLoc = Center - Forward * (BuildingDepth * 0.1f) + Right * OffsetX + Up * DefenderZ;

			AEnemySoldier* Enemy = World->SpawnActor<AEnemySoldier>(AEnemySoldier::StaticClass(), EnemyLoc, Rotation, SpawnParams);
			if (Enemy)
			{
				Enemy->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
				SpawnedElements.Add(Enemy);
			}
		}
	}
}

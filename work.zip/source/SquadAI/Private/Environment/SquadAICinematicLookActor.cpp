// SquadAICinematicLookActor.cpp — S18-LOOK
#include "Environment/SquadAICinematicLookActor.h"

#include "Engine/DirectionalLight.h"
#include "Engine/SkyLight.h"
#include "Components/DirectionalLightComponent.h"
#include "Components/SkyLightComponent.h"
#include "Components/ExponentialHeightFogComponent.h"
#include "Engine/ExponentialHeightFog.h"
#include "Engine/PostProcessVolume.h"
#include "EngineUtils.h"
#include "Engine/World.h"

ASquadAICinematicLookActor::ASquadAICinematicLookActor()
{
	PrimaryActorTick.bCanEverTick = false;
	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
}

void ASquadAICinematicLookActor::BeginPlay()
{
	Super::BeginPlay();
	if (bApplyOnBeginPlay)
	{
		ApplyLook();
	}
}

// ---------------------------------------------------------------------------
//  Presets. These only overwrite the numeric fields; the per-section toggles
//  (bGradeSun etc.) are always respected.
// ---------------------------------------------------------------------------
void ASquadAICinematicLookActor::ApplyPreset()
{
	switch (Preset)
	{
	case ESquadAILookPreset::GoldenHour:
		SunPitchDeg = 14.f;  SunIntensityLux = 7.5f;  SunTemperatureK = 4700.f;
		SkyLightIntensity = 1.15f; SkyLightTint = FLinearColor(1.0f, 0.86f, 0.70f, 1.f);
		FogDensity = 0.012f; FogInscatteringColor = FLinearColor(0.62f, 0.49f, 0.34f, 1.f);
		FogDirectionalInscattering = FLinearColor(1.0f, 0.72f, 0.38f, 1.f);
		ExposureCompensation = -0.25f; Saturation = 0.94f;
		break;

	case ESquadAILookPreset::HarshNoon:
		SunPitchDeg = 62.f;  SunIntensityLux = 11.f;   SunTemperatureK = 6200.f;
		SkyLightIntensity = 1.6f;  SkyLightTint = FLinearColor(0.95f, 0.95f, 1.0f, 1.f);
		FogDensity = 0.006f; FogInscatteringColor = FLinearColor(0.70f, 0.66f, 0.58f, 1.f);
		FogDirectionalInscattering = FLinearColor(1.0f, 0.92f, 0.78f, 1.f);
		ExposureCompensation = -0.55f; Saturation = 0.88f;
		break;

	case ESquadAILookPreset::DustStorm:
		SunPitchDeg = 26.f;  SunIntensityLux = 3.2f;   SunTemperatureK = 5200.f;
		SkyLightIntensity = 0.75f; SkyLightTint = FLinearColor(0.85f, 0.66f, 0.45f, 1.f);
		FogDensity = 0.055f; FogInscatteringColor = FLinearColor(0.58f, 0.41f, 0.24f, 1.f);
		FogDirectionalInscattering = FLinearColor(0.95f, 0.65f, 0.32f, 1.f);
		ExposureCompensation = 0.15f; Saturation = 0.78f;
		break;

	case ESquadAILookPreset::ColdDawn:
		SunPitchDeg = 6.f;   SunIntensityLux = 3.8f;   SunTemperatureK = 7600.f;
		SkyLightIntensity = 1.35f; SkyLightTint = FLinearColor(0.72f, 0.80f, 1.0f, 1.f);
		FogDensity = 0.030f; FogInscatteringColor = FLinearColor(0.42f, 0.48f, 0.60f, 1.f);
		FogDirectionalInscattering = FLinearColor(1.0f, 0.78f, 0.55f, 1.f);
		ExposureCompensation = -0.1f; Saturation = 0.90f;
		break;

	case ESquadAILookPreset::Custom:
	default:
		break; // leave everything as authored in the details panel
	}
}

ADirectionalLight* ASquadAICinematicLookActor::FindSun() const
{
	UWorld* World = GetWorld();
	if (!World) return nullptr;
	ADirectionalLight* Best = nullptr;
	float BestIntensity = -1.f;
	for (TActorIterator<ADirectionalLight> It(World); It; ++It)
	{
		// Several directional lights are common (sun + a fill). Grade the brightest.
		if (const ULightComponent* LC = It->GetLightComponent())
		{
			if (LC->Intensity > BestIntensity)
			{
				BestIntensity = LC->Intensity;
				Best = *It;
			}
		}
	}
	return Best;
}

ASkyLight* ASquadAICinematicLookActor::FindSkyLight() const
{
	UWorld* World = GetWorld();
	if (!World) return nullptr;
	for (TActorIterator<ASkyLight> It(World); It; ++It)
	{
		return *It;
	}
	return nullptr;
}

AExponentialHeightFog* ASquadAICinematicLookActor::FindOrSpawnFog()
{
	UWorld* World = GetWorld();
	if (!World) return nullptr;
	for (TActorIterator<AExponentialHeightFog> It(World); It; ++It)
	{
		return *It;
	}
	if (!bSpawnFogIfMissing) return nullptr;

	FActorSpawnParameters SP;
	SP.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	AExponentialHeightFog* Fog = World->SpawnActor<AExponentialHeightFog>(
		AExponentialHeightFog::StaticClass(), FVector(0.f, 0.f, 200.f), FRotator::ZeroRotator, SP);
	UE_LOG(LogTemp, Warning, TEXT("[S18-LOOK] No height fog in the level — spawned one."));
	return Fog;
}

APostProcessVolume* ASquadAICinematicLookActor::FindOrSpawnPostVolume()
{
	UWorld* World = GetWorld();
	if (!World) return nullptr;
	APostProcessVolume* Unbound = nullptr;
	for (TActorIterator<APostProcessVolume> It(World); It; ++It)
	{
		if (It->bUnbound)
		{
			Unbound = *It;
			break;
		}
		if (!Unbound) Unbound = *It; // fall back to any volume
	}
	if (Unbound) return Unbound;
	if (!bSpawnPostVolumeIfMissing) return nullptr;

	FActorSpawnParameters SP;
	SP.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	APostProcessVolume* PPV = World->SpawnActor<APostProcessVolume>(
		APostProcessVolume::StaticClass(), FVector::ZeroVector, FRotator::ZeroRotator, SP);
	if (PPV)
	{
		PPV->bUnbound = true;
		PPV->BlendWeight = 1.f;
		UE_LOG(LogTemp, Warning, TEXT("[S18-LOOK] No post-process volume — spawned an unbound one."));
	}
	return PPV;
}

// ---------------------------------------------------------------------------
void ASquadAICinematicLookActor::ApplyLook()
{
	UWorld* World = GetWorld();
	if (!World) return;

	ApplyPreset();

	// ---------------- sun ----------------
	if (bGradeSun)
	{
		if (ADirectionalLight* Sun = FindSun())
		{
			UDirectionalLightComponent* DL = Cast<UDirectionalLightComponent>(Sun->GetLightComponent());
			if (DL)
			{
				if (!bCapturedOriginal)
				{
					OrigSunRot = Sun->GetActorRotation();
					OrigSunIntensity = DL->Intensity;
				}
				Sun->SetActorRotation(FRotator(-FMath::Abs(SunPitchDeg), SunYawDeg, 0.f));
				DL->SetIntensity(SunIntensityLux);
				DL->SetUseTemperature(true);
				DL->SetTemperature(SunTemperatureK);
				// A 0.5-1 degree source angle is what turns a stencil-sharp UE
				// shadow into a believable sun shadow.
				DL->LightSourceAngle = FMath::Max(0.f, SunSourceAngleDeg);
				DL->ContactShadowLength = ContactShadowLength;
				DL->bCastVolumetricShadow = true;
				DL->DynamicShadowDistanceMovableLight = FMath::Max(DL->DynamicShadowDistanceMovableLight, 20000.f);
				DL->CascadeDistributionExponent = 2.6f;   // detail near the player
				DL->DynamicShadowCascades = FMath::Max(DL->DynamicShadowCascades, 4);
				DL->MarkRenderStateDirty();
				UE_LOG(LogTemp, Log, TEXT("[S18-LOOK] Sun graded: pitch %.1f, %.1f lux, %.0fK."),
					SunPitchDeg, SunIntensityLux, SunTemperatureK);
			}
		}
		else
		{
			UE_LOG(LogTemp, Warning, TEXT("[S18-LOOK] No directional light found — sun not graded."));
		}
	}

	// ---------------- sky ----------------
	if (bGradeSky)
	{
		if (ASkyLight* Sky = FindSkyLight())
		{
			if (USkyLightComponent* SLC = Sky->GetLightComponent())
			{
				SLC->SetIntensity(SkyLightIntensity);
				SLC->SetLightColor(SkyLightTint);
				SLC->SetVolumetricScatteringIntensity(1.0f);
				SLC->bRealTimeCapture = true; // follows the sun we just moved
				SLC->MarkRenderStateDirty();
				SLC->RecaptureSky();
			}
		}
	}

	// ---------------- fog ----------------
	if (bGradeFog)
	{
		if (AExponentialHeightFog* Fog = FindOrSpawnFog())
		{
			if (UExponentialHeightFogComponent* FC = Fog->GetComponent())
			{
				if (!bCapturedOriginal)
				{
					OrigFogDensity = FC->FogDensity;
					bOrigVolumetricFog = FC->bEnableVolumetricFog;
				}
				FC->SetFogDensity(FogDensity);
				FC->SetFogHeightFalloff(FogHeightFalloff);
				FC->SetFogInscatteringColor(FogInscatteringColor);
				FC->SetDirectionalInscatteringColor(FogDirectionalInscattering);
				FC->SetDirectionalInscatteringExponent(FogDirectionalExponent);
				FC->SetDirectionalInscatteringStartDistance(1200.f);
				FC->SetStartDistance(350.f);           // no fog on the player's hands
				FC->SetVolumetricFog(bVolumetricFog);
				FC->SetVolumetricFogExtinctionScale(VolumetricFogExtinctionScale);
				FC->SetVolumetricFogScatteringDistribution(0.35f); // forward scatter = god rays
				FC->MarkRenderStateDirty();
				UE_LOG(LogTemp, Log, TEXT("[S18-LOOK] Fog graded: density %.4f, volumetric %s."),
					FogDensity, bVolumetricFog ? TEXT("on") : TEXT("off"));
			}
		}
	}

	// ---------------- post ----------------
	if (bGradePost)
	{
		if (APostProcessVolume* PPV = FindOrSpawnPostVolume())
		{
			FPostProcessSettings& P = PPV->Settings;

			P.bOverride_AutoExposureMethod = true;
			P.AutoExposureMethod = EAutoExposureMethod::AEM_Histogram;
			P.bOverride_AutoExposureBias = true;
			P.AutoExposureBias = ExposureCompensation;
			// Clamp the eye so walking from sun into a dugout does not blow out.
			P.bOverride_AutoExposureMinBrightness = true;
			P.AutoExposureMinBrightness = 0.35f;
			P.bOverride_AutoExposureMaxBrightness = true;
			P.AutoExposureMaxBrightness = 2.4f;
			P.bOverride_AutoExposureSpeedUp = true;   P.AutoExposureSpeedUp = 2.6f;
			P.bOverride_AutoExposureSpeedDown = true; P.AutoExposureSpeedDown = 1.1f;

			P.bOverride_BloomIntensity = true;   P.BloomIntensity = BloomIntensity;
			P.bOverride_BloomThreshold = true;   P.BloomThreshold = 0.9f;

			P.bOverride_VignetteIntensity = true; P.VignetteIntensity = VignetteIntensity;
			P.bOverride_FilmGrainIntensity = true; P.FilmGrainIntensity = FilmGrainIntensity;
			P.bOverride_SceneFringeIntensity = true; P.SceneFringeIntensity = ChromaticAberration;

			P.bOverride_ColorSaturation = true;
			P.ColorSaturation = FVector4(Saturation, Saturation, Saturation, 1.0f);
			P.bOverride_ColorGain = true;    P.ColorGain = ColorGainHighlights;
			P.bOverride_ColorOffset = true;  P.ColorOffset = ColorOffsetShadows;
			P.bOverride_ColorContrast = true;
			P.ColorContrast = FVector4(1.06f, 1.06f, 1.08f, 1.0f);

			P.bOverride_AmbientOcclusionIntensity = true;
			P.AmbientOcclusionIntensity = AmbientOcclusionIntensity;
			P.bOverride_AmbientOcclusionRadius = true;
			P.AmbientOcclusionRadius = 120.f;

			P.bOverride_IndirectLightingIntensity = true;
			P.IndirectLightingIntensity = IndirectLightingIntensity;

			// Motion blur: a little sells weight, a lot makes people sick.
			P.bOverride_MotionBlurAmount = true; P.MotionBlurAmount = 0.22f;
			P.bOverride_MotionBlurMax = true;    P.MotionBlurMax = 3.0f;

			// Lens flare off: it reads as asset-store, not as film.
			P.bOverride_LensFlareIntensity = true; P.LensFlareIntensity = 0.f;

			PPV->bEnabled = true;
			PPV->BlendWeight = 1.f;
			UE_LOG(LogTemp, Log, TEXT("[S18-LOOK] Post-process graded on %s."), *PPV->GetName());
		}
	}

	bCapturedOriginal = true;
	UE_LOG(LogTemp, Warning, TEXT("[S18-LOOK] Look applied: preset %d."), static_cast<int32>(Preset));
}

void ASquadAICinematicLookActor::RestoreOriginalLook()
{
	if (!bCapturedOriginal)
	{
		UE_LOG(LogTemp, Warning, TEXT("[S18-LOOK] Nothing captured yet — nothing to restore."));
		return;
	}
	if (ADirectionalLight* Sun = FindSun())
	{
		Sun->SetActorRotation(OrigSunRot);
		if (ULightComponent* LC = Sun->GetLightComponent())
		{
			LC->SetIntensity(OrigSunIntensity);
			LC->MarkRenderStateDirty();
		}
	}
	for (TActorIterator<AExponentialHeightFog> It(GetWorld()); It; ++It)
	{
		if (UExponentialHeightFogComponent* FC = It->GetComponent())
		{
			FC->SetFogDensity(OrigFogDensity);
			FC->SetVolumetricFog(bOrigVolumetricFog);
			FC->MarkRenderStateDirty();
		}
		break;
	}
	UE_LOG(LogTemp, Warning, TEXT("[S18-LOOK] Sun and fog restored (post-process volume left as-is)."));
}

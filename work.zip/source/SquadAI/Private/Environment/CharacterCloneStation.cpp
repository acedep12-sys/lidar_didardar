// CharacterCloneStation.cpp — S17-CLONE: one-button ready-clone factory.
#include "Environment/CharacterCloneStation.h"
#include "Characters/SoldierCharacter.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/SkeletalMesh.h"
#include "Engine/SkeletalMeshSocket.h"
#include "Animation/Skeleton.h"
#include "Characters/SquadAIGripRetarget.h" // S18-GRIP

#if WITH_EDITOR
#include "AssetToolsModule.h"
#include "IAssetTools.h"
#include "ObjectTools.h" // S19-DELASSET: ObjectTools::DeleteAssets (IAssetTools has no DeleteAssets in UE 5.7)
#include "Engine/Blueprint.h"
#include "Kismet2/KismetEditorUtilities.h"
#include "FileHelpers.h"
#include "Misc/PackageName.h"
#include "UObject/Package.h"
#include "AssetRegistry/AssetRegistryModule.h" // S17-CLONE2: project-wide socket scan
#include "UObject/SoftObjectPath.h"           // S19-CLONE3: FSoftObjectPath (asset lookup before delete)
#endif

ACharacterCloneStation::ACharacterCloneStation()
{
	PrimaryActorTick.bCanEverTick = false;
	SetHidden(true);
	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
}

#if WITH_EDITOR
namespace SquadAICloneStation
{
	// Socket may live on the mesh asset OR its skeleton — check both.
	static const USkeletalMeshSocket* FindSocketOnMeshOrSkeleton(const USkeletalMesh* Mesh, FName SocketName)
	{
		if (!Mesh || SocketName.IsNone()) return nullptr;
		if (const USkeletalMeshSocket* S = Mesh->FindSocket(SocketName)) return S;
		if (const USkeleton* Skel = Mesh->GetSkeleton())
		{
			for (const TObjectPtr<USkeletalMeshSocket>& S : Skel->Sockets)
			{
				if (S && S->SocketName == SocketName) return S;
			}
		}
		return nullptr;
	}

	// ===== S19-GRIPHUNT =====================================================
	// The bake used to hunt for ONE name: WeaponAttachSocketName ("RifleSocket" by
	// default). The engine's own mannequin - and most third-party packs - call their
	// right-hand weapon socket "weapon_r". So in a project with a perfectly good
	// template the hunt reported "no template socket found", fell through to the
	// attach offsets (zero on a freshly duplicated character) and baked an IDENTITY
	// socket at the hand bone. An identity socket puts the weapon's pivot exactly on
	// the hand bone with the hand bone's own axes - the rifle sits wrong no matter
	// how correct the retarget math is, because there was never anything to retarget.
	//
	// Two extra hunts, in order of confidence:
	//   1. the standard engine/pack socket names, through the same sources;
	//   2. ANY socket in the project that is parented to a right-hand bone.
	static const TArray<FName>& StandardGripSocketNames()
	{
		static const TArray<FName> Names = {
			FName(TEXT("weapon_r")), FName(TEXT("Weapon_R")), FName(TEXT("weaponR")),
			FName(TEXT("weapon_rSocket")), FName(TEXT("hand_r_weapon")),
			FName(TEXT("GripSocket")), FName(TEXT("WeaponSocket"))
		};
		return Names;
	}

	/** True for the right-hand bone under the naming schemes this project sees:
	 *  hand_r (UE), righthand / right_hand (mixamo-ish), Bip01_R_Hand, hand_R, ... */
	static bool IsRightHandBoneName(const FName& BoneName)
	{
		const FString B = BoneName.ToString().ToLower();
		if (B.IsEmpty()) return false;
		return B == TEXT("hand_r")
			|| B == TEXT("righthand")
			|| B == TEXT("handright")
			|| B.Contains(TEXT("hand_r"))
			|| B.Contains(TEXT("hand_r_"))
			|| B.EndsWith(TEXT("righthand"))
			|| B.Contains(TEXT("_r_hand"))
			|| B.Contains(TEXT("hand_r"));
	}

	/** S19-GRIPHUNT (2): find any socket under /Game whose BONE is a right hand.
	 *  Last resort, for projects that renamed the socket outright. */
	static const USkeletalMeshSocket* ScanProjectForGripSocketOnHandBone(
		const USkeletalMesh*& OutTemplateMesh, const USkeleton* IgnoreSkeleton,
		FName& OutSocketName, FName& OutBoneName)
	{
		OutTemplateMesh = nullptr;
		OutSocketName = NAME_None;
		OutBoneName = NAME_None;
		const IAssetRegistry& Registry = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry").Get();

		// Skeleton assets first (fewer of them, and sockets usually live there).
		TArray<FAssetData> SkeletonAssets;
		Registry.GetAssetsByClass(USkeleton::StaticClass()->GetClassPathName(), SkeletonAssets);
		for (const FAssetData& AD : SkeletonAssets)
		{
			if (!AD.PackageName.ToString().StartsWith(TEXT("/Game"))) continue;
			const USkeleton* Skel = Cast<USkeleton>(AD.GetAsset());
			if (!Skel || Skel == IgnoreSkeleton) continue;
			for (const TObjectPtr<USkeletalMeshSocket>& S : Skel->Sockets)
			{
				if (S && IsRightHandBoneName(S->BoneName))
				{
					OutSocketName = S->SocketName;
					OutBoneName = S->BoneName;
					return S;
				}
			}
		}

		// Then mesh-level sockets.
		TArray<FAssetData> MeshAssets;
		Registry.GetAssetsByClass(USkeletalMesh::StaticClass()->GetClassPathName(), MeshAssets);
		for (const FAssetData& MD : MeshAssets)
		{
			if (!MD.PackageName.ToString().StartsWith(TEXT("/Game"))) continue;
			// NON-const on purpose: GetMeshOnlySocketList() is a non-const accessor here,
			// and this is the same form the proven calls in this file use. We only read.
			USkeletalMesh* Mesh = Cast<USkeletalMesh>(MD.GetAsset());
			if (!Mesh || Mesh->GetSkeleton() == IgnoreSkeleton) continue;
			// Element type of GetMeshOnlySocketList() varies across UE versions, so
			// iterate by index and let the raw pointer convert (same pattern as
			// BakeSocketsIntoMesh below).
			const auto& MeshSockets = Mesh->GetMeshOnlySocketList();
			for (int32 i = 0; i < MeshSockets.Num(); ++i)
			{
				const USkeletalMeshSocket* S = MeshSockets[i];
				if (S && IsRightHandBoneName(S->BoneName))
				{
					OutTemplateMesh = Mesh;
					OutSocketName = S->SocketName;
					OutBoneName = S->BoneName;
					return S;
				}
			}
		}
		return nullptr;
	}

	// S17-CLONE2: last-resort template hunt — scan the WHOLE project for the
	// grip socket. Covers V3 Blueprints that were duplicated (not child-of the
	// mannequin BP), where the class-walk never reaches the mannequin mesh.
	// Skeleton assets first (sockets usually live there, and there are few of
	// them), then mesh-level sockets on skeletal meshes. /Game content only.
	static const USkeletalMeshSocket* ScanProjectForTemplateSocket(FName SocketName, const USkeletalMesh*& OutTemplateMesh, const USkeleton* IgnoreSkeleton)
	{
		OutTemplateMesh = nullptr;
		const IAssetRegistry& Registry = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry").Get();

		// Pass 1: every Skeleton asset under /Game.
		TArray<FAssetData> SkeletonAssets;
		Registry.GetAssetsByClass(USkeleton::StaticClass()->GetClassPathName(), SkeletonAssets);
		for (const FAssetData& AD : SkeletonAssets)
		{
			if (!AD.PackageName.ToString().StartsWith(TEXT("/Game"))) continue;
			const USkeleton* Skel = Cast<USkeleton>(AD.GetAsset());
			if (!Skel || Skel == IgnoreSkeleton) continue;
			for (const TObjectPtr<USkeletalMeshSocket>& S : Skel->Sockets)
			{
				if (S && S->SocketName == SocketName)
				{
					// Find a mesh that uses this skeleton (for the GRIP2 net).
					TArray<FAssetData> MeshAssets;
					Registry.GetAssetsByClass(USkeletalMesh::StaticClass()->GetClassPathName(), MeshAssets);
					const FString SkelPath = FAssetData(Skel).GetExportTextName();
					for (const FAssetData& MD : MeshAssets)
					{
						if (!MD.PackageName.ToString().StartsWith(TEXT("/Game"))) continue;
						FString MeshSkel;
						if (MD.GetTagValue(TEXT("Skeleton"), MeshSkel) && MeshSkel == SkelPath)
						{
							OutTemplateMesh = Cast<USkeletalMesh>(MD.GetAsset());
							if (OutTemplateMesh) break;
						}
					}
					UE_LOG(LogTemp, Warning, TEXT("[CloneStation] Template socket '%s' found by PROJECT SCAN on skeleton '%s' (mesh net: %s)."),
						*SocketName.ToString(), *Skel->GetName(), *GetNameSafe(OutTemplateMesh));
					return S;
				}
			}
		}

		// Pass 2: mesh-level sockets on skeletal meshes under /Game.
		TArray<FAssetData> MeshAssets;
		Registry.GetAssetsByClass(USkeletalMesh::StaticClass()->GetClassPathName(), MeshAssets);
		for (const FAssetData& MD : MeshAssets)
		{
			if (!MD.PackageName.ToString().StartsWith(TEXT("/Game"))) continue;
			const USkeletalMesh* Mesh = Cast<USkeletalMesh>(MD.GetAsset());
			if (!Mesh || Mesh->GetSkeleton() == IgnoreSkeleton) continue;
			if (const USkeletalMeshSocket* S = Mesh->FindSocket(SocketName))
			{
				OutTemplateMesh = Mesh;
				UE_LOG(LogTemp, Warning, TEXT("[CloneStation] Template socket '%s' found by PROJECT SCAN on mesh '%s'."),
					*SocketName.ToString(), *Mesh->GetName());
				return S;
			}
		}
		return nullptr;
	}


	/** S19-GRIPHUNT: second-chance template hunt, shared by BOTH output buttons
	 *  (CreateReadyClone and CreateReadyMesh) so they can never disagree.
	 *
	 *  Pass 1: the standard engine/pack socket names ('weapon_r' and friends) through
	 *          the same sources the named hunt uses - reference character, grip
	 *          template mesh, the character's class chain, then the project scan.
	 *  Pass 2: any socket under /Game parented to a right-hand bone.
	 *
	 *  Returns nullptr when nothing was found; the caller then fabricates a socket and
	 *  ComputeGripTransform logs an ERROR, because an identity socket is not neutral. */
	static const USkeletalMeshSocket* HuntStandardGripTemplate(
		FName SocketName,
		const ASoldierCharacter* RefCDO,
		UClass* SourceCharacterClass,
		const USkeletalMesh* GripTemplateMesh,
		const USkeletalMesh* TargetMesh,
		const USkeleton* TargetSkeleton,
		const USkeletalMesh*& OutTemplateMesh,
		const TCHAR* Context)
	{
		OutTemplateMesh = nullptr;

		// ---- pass 1: standard names, same source order as the named hunt ----------
		for (const FName& Candidate : StandardGripSocketNames())
		{
			if (Candidate == SocketName) continue;   // already tried by the caller

			if (RefCDO && RefCDO->GetMesh() && RefCDO->GetMesh()->GetSkeletalMeshAsset())
			{
				const USkeletalMesh* M = RefCDO->GetMesh()->GetSkeletalMeshAsset();
				if (const USkeletalMeshSocket* S = FindSocketOnMeshOrSkeleton(M, Candidate))
				{
					OutTemplateMesh = M;
					UE_LOG(LogTemp, Warning, TEXT("[CloneStation] S19-GRIPHUNT (%s): standard socket '%s' found on the ReferenceCharacter's mesh '%s' - retargeting it onto the clone instead of fabricating a zero socket."),
						Context, *Candidate.ToString(), *M->GetName());
					return S;
				}
			}
			if (GripTemplateMesh)
			{
				if (const USkeletalMeshSocket* S = FindSocketOnMeshOrSkeleton(GripTemplateMesh, Candidate))
				{
					OutTemplateMesh = GripTemplateMesh;
					UE_LOG(LogTemp, Warning, TEXT("[CloneStation] S19-GRIPHUNT (%s): standard socket '%s' found on GripTemplateMesh '%s'."),
						Context, *Candidate.ToString(), *GripTemplateMesh->GetName());
					return S;
				}
			}
			if (SourceCharacterClass)
			{
				for (UClass* Cls = SourceCharacterClass; Cls && Cls->IsChildOf(ASoldierCharacter::StaticClass()); Cls = Cls->GetSuperClass())
				{
					const ASoldierCharacter* CDO = Cls->GetDefaultObject<ASoldierCharacter>();
					const USkeletalMesh* CDOMesh = (CDO && CDO->GetMesh()) ? CDO->GetMesh()->GetSkeletalMeshAsset() : nullptr;
					if (!CDOMesh) continue;
					if (const USkeletalMeshSocket* S = FindSocketOnMeshOrSkeleton(CDOMesh, Candidate))
					{
						OutTemplateMesh = CDOMesh;
						UE_LOG(LogTemp, Warning, TEXT("[CloneStation] S19-GRIPHUNT (%s): standard socket '%s' found via the class chain on '%s'."),
							Context, *Candidate.ToString(), *CDOMesh->GetName());
						return S;
					}
				}
			}
			const USkeletalMesh* ScanMesh = nullptr;
			if (const USkeletalMeshSocket* S = ScanProjectForTemplateSocket(Candidate, ScanMesh, TargetSkeleton))
			{
				OutTemplateMesh = ScanMesh;
				UE_LOG(LogTemp, Warning, TEXT("[CloneStation] S19-GRIPHUNT (%s): standard socket '%s' found by the project scan."),
					Context, *Candidate.ToString());
				return S;
			}
		}

		// ---- pass 2: any socket on a right-hand bone -----------------------------
		FName FoundSocketName = NAME_None;
		FName FoundBoneName = NAME_None;
		if (const USkeletalMeshSocket* S = ScanProjectForGripSocketOnHandBone(OutTemplateMesh, TargetSkeleton, FoundSocketName, FoundBoneName))
		{
			UE_LOG(LogTemp, Warning, TEXT("[CloneStation] S19-GRIPHUNT (%s): no standard socket name matched, but socket '%s' (bone '%s') is on a right hand - using it as the grip template."),
				Context, *FoundSocketName.ToString(), *FoundBoneName.ToString());
			return S;
		}
		return nullptr;
	}

	// S18-GRIP: retarget math lives in Characters/SquadAIGripRetarget.h

	// ===== S19-CLONE3: shared bake machinery =================================
	//
	// Root cause of the "weapon under the feet" bug, and why it survived
	// re-running this tool:
	//   1. The grip socket was written onto the clone's SKELETON. Skeletons are
	//      shared between meshes, so a hand-tuned rifle socket leaked onto every
	//      other character using that skeleton.
	//   2. Once a socket existed, the tool logged "already exists — nothing to
	//      create" and returned. A socket baked with wrong math could therefore
	//      never be corrected: the tool was idempotent in the worst possible way.
	//   3. Nothing ever measured where the socket ended up, so a grip at Z=0
	//      (the mesh root = between the feet) looked exactly like a good run.
	//
	// Fix: bake into a DUPLICATE of the mesh as a MESH-level socket (mesh
	// sockets are found before skeleton sockets), replace rather than skip, and
	// verify the result afterwards.

	/** Final local transform for a grip socket, plus the reason it was chosen. */
	struct FGripTransform
	{
		FVector  Loc   = FVector::ZeroVector;
		FRotator Rot   = FRotator::ZeroRotator;
		FVector  Scale = FVector::OneVector;
		FString  Why;
	};

	/** Decide the grip socket's LOCAL transform for GripBone on TargetMesh.
	 *
	 *  - With a template socket and retargeting ON: rebuild the template's
	 *    offset inside the target hand's own axes (SquadAIGripRetarget.h).
	 *  - With a template and retargeting OFF: verbatim copy + scale nudge.
	 *  - With no template anywhere: fall back to the working character's own
	 *    attach offsets, which is how that character grips today. */
	static FGripTransform ComputeGripTransform(
		const USkeletalMesh* TemplateMesh,
		const USkeletalMeshSocket* TemplateSocket,
		const USkeletalMesh* TargetMesh,
		FName GripBone,
		bool bRetarget,
		bool bAutoScale,
		float ScaleMultiplier,
		const ASoldierCharacter* OffsetSourceCDO)
	{
		FGripTransform Out;
		if (TemplateSocket)
		{
			Out.Loc   = TemplateSocket->RelativeLocation;
			Out.Rot   = TemplateSocket->RelativeRotation;
			Out.Scale = TemplateSocket->RelativeScale;
			Out.Why   = TEXT("verbatim copy (retarget disabled)");

			if (bRetarget)
			{
				FVector RLoc; FRotator RRot; FVector RScale; FString Why;
				if (SquadAIGrip::RetargetSocketTransform(TemplateMesh, TemplateSocket, TargetMesh, GripBone,
						bAutoScale, ScaleMultiplier, RLoc, RRot, RScale, Why))
				{
					Out.Loc = RLoc; Out.Rot = RRot; Out.Scale = RScale;
					Out.Why = Why;
				}
				else
				{
					Out.Why = FString::Printf(TEXT("retarget FAILED (%s) — fell back to verbatim"), *Why);
					Out.Scale = Out.Scale * FMath::Max(0.01f, ScaleMultiplier);
				}
			}
			else
			{
				Out.Scale = Out.Scale * FMath::Max(0.01f, ScaleMultiplier);
			}
		}
		else
		{
			// No grip socket anywhere in the project: the reference character
			// grips through the hand-bone fallback plus its attach offsets, so
			// bake those offsets straight into the socket.
			if (OffsetSourceCDO)
			{
				Out.Loc = OffsetSourceCDO->WeaponAttachLocationOffset;
				Out.Rot = OffsetSourceCDO->WeaponAttachRotationOffset;
				Out.Scale = OffsetSourceCDO->bOverrideWeaponAttachScale
					? OffsetSourceCDO->WeaponAttachScale : FVector::OneVector;
				Out.Why = TEXT("baked from the working character's attach offsets (no template socket found)");
			}
			else
			{
				Out.Why = TEXT("zero offset (no template socket and no reference character)");
			}

			// S19-GRIPHUNT: an IDENTITY grip socket is not a neutral choice. It puts the
			// weapon's pivot exactly on the hand bone with the hand bone's own axes, so a
			// rifle points along the hand instead of along the barrel - the exact "weapon
			// in the wrong position" report. Say so at ERROR level instead of shipping a
			// quiet zero, and name the three ways to fix it.
			const bool bIdentity =
				Out.Loc.IsNearlyZero(0.01) && Out.Rot.IsNearlyZero(0.01) && Out.Scale.Equals(FVector::OneVector, 0.001);
			if (bIdentity)
			{
				UE_LOG(LogTemp, Error, TEXT("[CloneStation] S19-GRIPHUNT: about to bake an IDENTITY grip socket on bone '%s'. ")
					TEXT("That places the weapon pivot exactly on the hand bone with the hand's own orientation and will LOOK WRONG. ")
					TEXT("Fix one of: (1) set 'Grip Template Mesh' / 'Reference Character' to a mesh that already grips correctly ")
					TEXT("(the engine mannequin carries 'weapon_r' on hand_r), (2) set WeaponAttachLocationOffset / ")
					TEXT("WeaponAttachRotationOffset on the reference character to the values that work in PIE, or (3) bake again ")
					TEXT("after adding a weapon socket to the source mesh."), *GripBone.ToString());
			}
		}
		UE_LOG(LogTemp, Warning, TEXT("[CloneStation] grip transform: loc=%s rot=%s scale=%s (%s)"),
			*Out.Loc.ToString(), *Out.Rot.ToString(), *Out.Scale.ToString(), *Out.Why);
		return Out;
	}

	/** Bake the grip socket into a MESH under every name in Names.
	 *  Mesh-level sockets are resolved BEFORE skeleton sockets, so this wins
	 *  over any stale skeleton socket left by an earlier attempt. Existing
	 *  sockets with the same names are REPLACED, never skipped. */
	/** S19-NAMEBAKE: the transform that must be baked under ONE socket name.
	 *
	 *  A name that already exists on a WORKING mesh has to keep ITS OWN transform: the
	 *  consumer asks for that name because whatever it attaches was authored for it. The
	 *  live log showed the cost of baking ONE shared transform under every name - the
	 *  leader's mesh carried 'hand_rSocket' with the ENGINE mannequin's 'weapon_r' rotation
	 *  (Y=95.0) while the player's mesh has the real 'hand_rSocket' (Y=185.0). Same bone,
	 *  same hand, 90 degrees apart: a rifle held sideways.
	 *
	 *  Order: the explicit GripTemplateMesh override, the ReferenceCharacter's mesh, the
	 *  SourceCharacter class chain (the character whose grip works in-game), the mesh being
	 *  cloned, then a project scan for that exact name. False = no name-specific template
	 *  exists anywhere; the caller keeps the shared grip transform for that name.
	 */
	static bool ResolveNameSpecificGripTransform(
		FName SocketName,
		const ASoldierCharacter* RefCDO,
		UClass* SourceCharacterClass,
		const USkeletalMesh* GripTemplateMesh,
		const USkeletalMesh* SourceMesh,
		const USkeletalMesh* TargetMesh,
		FName GripBone,
		bool bRetarget,
		bool bAutoScale,
		float ScaleMultiplier,
		FGripTransform& Out,
		const USkeletalMesh*& OutTemplateMesh,
		FString& OutWhere)
	{
		OutTemplateMesh = nullptr;
		OutWhere.Reset();
		if (SocketName.IsNone() || !TargetMesh || GripBone.IsNone()) return false;

		auto Accept = [&](const USkeletalMesh* M, const USkeletalMeshSocket* Sock, const TCHAR* What) -> bool
		{
			if (!M || !Sock) return false;
			Out = ComputeGripTransform(M, Sock, TargetMesh, GripBone,
				bRetarget, bAutoScale, ScaleMultiplier, RefCDO);
			OutTemplateMesh = M;
			OutWhere = FString::Printf(TEXT("%s '%s' socket '%s' loc=%s rot=%s"),
				What, *M->GetName(), *Sock->SocketName.ToString(),
				*Sock->RelativeLocation.ToCompactString(), *Sock->RelativeRotation.ToString());
			return true;
		};

		if (GripTemplateMesh)
		{
			if (Accept(GripTemplateMesh, FindSocketOnMeshOrSkeleton(GripTemplateMesh, SocketName), TEXT("GripTemplateMesh"))) return true;
		}
		if (RefCDO && RefCDO->GetMesh())
		{
			if (const USkeletalMesh* M = RefCDO->GetMesh()->GetSkeletalMeshAsset())
			{
				if (Accept(M, FindSocketOnMeshOrSkeleton(M, SocketName), TEXT("reference character"))) return true;
			}
		}
		if (SourceCharacterClass)
		{
			for (UClass* Cls = SourceCharacterClass; Cls && Cls->IsChildOf(ASoldierCharacter::StaticClass()); Cls = Cls->GetSuperClass())
			{
				const ASoldierCharacter* CDO = Cls->GetDefaultObject<ASoldierCharacter>();
				const USkeletalMesh* M = (CDO && CDO->GetMesh()) ? CDO->GetMesh()->GetSkeletalMeshAsset() : nullptr;
				if (Accept(M, FindSocketOnMeshOrSkeleton(M, SocketName), TEXT("character class"))) return true;
			}
		}
		if (SourceMesh)
		{
			if (Accept(SourceMesh, FindSocketOnMeshOrSkeleton(SourceMesh, SocketName), TEXT("source mesh"))) return true;
		}
		const USkeletalMesh* ScanMesh = nullptr;
		if (const USkeletalMeshSocket* S = ScanProjectForTemplateSocket(SocketName, ScanMesh, TargetMesh->GetSkeleton()))
		{
			if (Accept(ScanMesh, S, TEXT("project scan"))) return true;
		}
		return false;
	}

	/** S19-NAMEBAKE: build one transform per name (parallel to Names), logging which
	 *  names got their own template and which fell back to the shared grip transform.
	 *  Keeps the two output buttons identical in behaviour. */
	static void BuildPerNameGripTransforms(
		const TArray<FName>& Names,
		const FGripTransform& Shared,
		const ASoldierCharacter* RefCDO,
		UClass* SourceCharacterClass,
		const USkeletalMesh* GripTemplateMesh,
		const USkeletalMesh* SourceMesh,
		const USkeletalMesh* TargetMesh,
		FName GripBone,
		bool bRetarget,
		bool bAutoScale,
		float ScaleMultiplier,
		const TCHAR* Context,
		TArray<FGripTransform>& Out)
	{
		Out.Reset();
		Out.Reserve(Names.Num());
		int32 OwnTemplate = 0;
		for (const FName& N : Names)
		{
			FGripTransform T = Shared;
			const USkeletalMesh* TemplateUsed = nullptr;
			FString Where;
			if (ResolveNameSpecificGripTransform(N, RefCDO, SourceCharacterClass, GripTemplateMesh,
				SourceMesh, TargetMesh, GripBone, bRetarget, bAutoScale, ScaleMultiplier, T, TemplateUsed, Where))
			{
				++OwnTemplate;
				UE_LOG(LogTemp, Warning, TEXT("[CloneStation] S19-NAMEBAKE (%s): '%s' <- %s [retargeted for this rig: loc=%s rot=%s]"),
					Context, *N.ToString(), *Where,
					*T.Loc.ToCompactString(), *T.Rot.ToString());
			}
			else
			{
				UE_LOG(LogTemp, Warning, TEXT("[CloneStation] S19-NAMEBAKE (%s): '%s' exists on no working mesh - using the shared grip transform (loc=%s rot=%s)"),
					Context, *N.ToString(), *Shared.Loc.ToCompactString(), *Shared.Rot.ToString());
			}
			Out.Add(T);
		}
		UE_LOG(LogTemp, Warning, TEXT("[CloneStation] S19-NAMEBAKE (%s): %d/%d name(s) carry their own working template; the rest share the found grip transform."),
			Context, OwnTemplate, Names.Num());
	}

	static int32 BakeSocketsIntoMesh(USkeletalMesh* Mesh, FName BoneName,
		const TArray<FName>& Names, const FGripTransform& T)
	{
		if (!Mesh || BoneName.IsNone() || Names.Num() == 0) return 0;

		TArray<FName> Wanted;
		for (const FName& N : Names) { if (!N.IsNone()) Wanted.AddUnique(N); }

		Mesh->Modify();
		auto& MeshSockets = Mesh->GetMeshOnlySocketList(); // element type varies across UE versions
		for (int32 i = MeshSockets.Num() - 1; i >= 0; --i)
		{
			if (MeshSockets[i] && Wanted.Contains(MeshSockets[i]->SocketName)) MeshSockets.RemoveAt(i);
		}
		int32 Made = 0;
		for (const FName& N : Wanted)
		{
			USkeletalMeshSocket* S = NewObject<USkeletalMeshSocket>(Mesh);
			S->SocketName       = N;
			S->BoneName         = BoneName;
			S->RelativeLocation = T.Loc;
			S->RelativeRotation = T.Rot;
			S->RelativeScale    = T.Scale;
			MeshSockets.Add(S);
			++Made;
		}
		Mesh->MarkPackageDirty();
		return Made;
	}

	/** S19-NAMEBAKE: same as BakeSocketsIntoMesh, but each name carries its OWN transform. */
	static int32 BakeSocketsIntoMeshPerName(USkeletalMesh* Mesh, FName BoneName,
		const TArray<FName>& Names, const TArray<FGripTransform>& Transforms)
	{
		if (!Mesh || BoneName.IsNone() || Names.Num() == 0) return 0;
		if (Transforms.Num() != Names.Num()) return BakeSocketsIntoMesh(Mesh, BoneName, Names,
			Transforms.Num() > 0 ? Transforms[0] : FGripTransform());

		TArray<FName> Wanted;
		for (const FName& N : Names) { if (!N.IsNone()) Wanted.AddUnique(N); }

		Mesh->Modify();
		auto& MeshSockets = Mesh->GetMeshOnlySocketList();
		for (int32 i = MeshSockets.Num() - 1; i >= 0; --i)
		{
			if (MeshSockets[i] && Wanted.Contains(MeshSockets[i]->SocketName)) MeshSockets.RemoveAt(i);
		}
		int32 Made = 0;
		for (int32 i = 0; i < Names.Num(); ++i)
		{
			const FName& N = Names[i];
			if (N.IsNone()) continue;
			const FGripTransform& T = Transforms[i];
			USkeletalMeshSocket* S = NewObject<USkeletalMeshSocket>(Mesh);
			S->SocketName       = N;
			S->BoneName         = BoneName;
			S->RelativeLocation = T.Loc;
			S->RelativeRotation = T.Rot;
			S->RelativeScale    = T.Scale;
			MeshSockets.Add(S);
			++Made;
		}
		Mesh->MarkPackageDirty();
		return Made;
	}

	/** Legacy path: bake onto the (possibly shared) SKELETON.
	 *  An existing socket of the same name is REPLACED, not skipped — that
	 *  skip is exactly what made a bad grip permanent. */
	static bool BakeSocketIntoSkeleton(USkeleton* Skeleton, FName SocketName,
		FName BoneName, const FGripTransform& T)
	{
		if (!Skeleton || SocketName.IsNone() || BoneName.IsNone()) return false;

		Skeleton->Modify();
		int32 Removed = 0;
		for (int32 i = Skeleton->Sockets.Num() - 1; i >= 0; --i)
		{
			USkeletalMeshSocket* S = Skeleton->Sockets[i];
			if (S && S->SocketName == SocketName)
			{
				Skeleton->Sockets.RemoveAt(i);
				++Removed;
			}
		}
		USkeletalMeshSocket* NewSocket = NewObject<USkeletalMeshSocket>(Skeleton);
		NewSocket->SocketName       = SocketName;
		NewSocket->BoneName         = BoneName;
		NewSocket->RelativeLocation = T.Loc;
		NewSocket->RelativeRotation = T.Rot;
		NewSocket->RelativeScale    = T.Scale;
		Skeleton->Sockets.Add(NewSocket);
		Skeleton->MarkPackageDirty();

		UE_LOG(LogTemp, Warning, TEXT("[CloneStation] Socket '%s' written on SKELETON '%s' at bone '%s' (%s)%s"),
			*SocketName.ToString(), *Skeleton->GetName(), *BoneName.ToString(), *T.Why,
			Removed ? *FString::Printf(TEXT(" — replaced %d previous socket(s)"), Removed) : TEXT(""));
		return true;
	}

	/** Delete an asset so re-running replaces it instead of spawning _2/_3/_4. */
	static bool DeleteExistingAsset(const FString& PackagePath)
	{
		if (!FPackageName::DoesPackageExist(PackagePath)) return false;
		const FString ObjectPath = PackagePath + TEXT(".") + FPackageName::GetShortName(PackagePath);
		const FAssetData Existing = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry").Get()
			.GetAssetByObjectPath(FSoftObjectPath(ObjectPath));
		if (!Existing.IsValid()) return false;
		TArray<FAssetData> ToDelete;
		ToDelete.Add(Existing);
		// S19-DELASSET: IAssetTools has no DeleteAssets() in UE 5.7; it lives in
		// ObjectTools, and it returns the NUMBER deleted (int32), not a bool.
		// bShowConfirmation=false is required: the default true opens a modal
		// Slate dialog that blocks the editor (the station is button-driven).
		const int32 Deleted = ObjectTools::DeleteAssets(ToDelete, false);
		UE_LOG(LogTemp, Log, TEXT("[CloneStation] %s existing '%s' before rebuild (bOverwriteExistingClones)."),
			Deleted > 0 ? TEXT("Deleted") : TEXT("Could NOT delete"), *PackagePath);
		return Deleted > 0;
	}

	/** Pick the output asset name: replace an existing one, or fall back to
	 *  an incrementing suffix the way it always used to. */
	static FString ResolveOutputName(const FString& BaseName, const FString& Folder, bool bOverwrite)
	{
		FString FinalName = BaseName;
		if (bOverwrite && DeleteExistingAsset(Folder / FinalName))
		{
			return FinalName;
		}
		int32 Suffix = 2;
		while (FPackageName::DoesPackageExist(Folder / FinalName))
		{
			FinalName = FString::Printf(TEXT("%s_%d"), *BaseName, Suffix++);
		}
		return FinalName;
	}

	/** S19-CLONE3 — the check that was missing. Measure where the socket
	 *  actually landed and shout if it is down at the feet. */
	static bool VerifyGripSocket(const USkeletalMesh* Mesh, FName SocketName, FName GripBone)
	{
		const USkeletalMeshSocket* S = FindSocketOnMeshOrSkeleton(Mesh, SocketName);
		if (!S)
		{
			UE_LOG(LogTemp, Error, TEXT("[CloneStation] VERIFY FAILED: socket '%s' does not exist on '%s' after the bake. "
				"The weapon will attach to the mesh root — i.e. under the feet."),
				*SocketName.ToString(), *GetNameSafe(Mesh));
			return false;
		}

		// S19-GRIPHUNT: a socket can exist, be on the right bone, be at a sane height -
		// and still be useless, because its OFFSET is identity. Position alone cannot
		// detect that, which is why a wrong grip survived this verifier for so long.
		const bool bIdentityOffset =
			S->RelativeLocation.IsNearlyZero(0.01) && S->RelativeRotation.IsNearlyZero(0.01);
		if (bIdentityOffset)
		{
			UE_LOG(LogTemp, Error, TEXT("[CloneStation] VERIFY WARNING: socket '%s' is an IDENTITY socket (loc %s, rot %s) on bone '%s'. ")
				TEXT("It is on the right bone but it carries no grip correction, so the weapon's pivot sits on the hand with the hand's ")
				TEXT("orientation — the rifle will point along the hand instead of along the barrel. Re-run with a grip template that ")
				TEXT("already works (GripTemplateMesh / ReferenceCharacter) or with non-zero attach offsets."),
				*SocketName.ToString(), *S->RelativeLocation.ToString(), *S->RelativeRotation.ToString(), *S->BoneName.ToString());
		}

		const FTransform SocketCS = SquadAIGrip::SocketComponentSpace(Mesh, S);
		const FVector P = SocketCS.GetTranslation();

		const FReferenceSkeleton& Ref = Mesh->GetRefSkeleton();
		const FTransform BoneCS = SquadAIGrip::RefBoneComponentSpace(Ref, Ref.FindBoneIndex(S->BoneName));
		const FVector BonePos = BoneCS.GetTranslation();
		const double DistFromBone = (P - BonePos).Size();

		// S19-CLONE3: rig extents from the REFERENCE POSE, deliberately not
		// Mesh->GetBounds(). GetBounds() needs render data and reads as zero on
		// a mesh that has not been built, whereas the ref skeleton is always
		// available and is exactly what the socket math above already uses.
		// Measuring against the rig's own lowest bone also makes the check
		// correct for skeletons that are not authored with the feet at Z = 0.
		double RigMinZ = 1e30;
		double RigMaxZ = -1e30;
		for (int32 i = 0; i < Ref.GetNum(); ++i)
		{
			const double Z = static_cast<double>(SquadAIGrip::RefBoneComponentSpace(Ref, i).GetTranslation().Z);
			RigMinZ = FMath::Min(RigMinZ, Z);
			RigMaxZ = FMath::Max(RigMaxZ, Z);
		}
		const bool   bHaveRig        = (RigMaxZ > RigMinZ);
		const double MeshHeight      = bHaveRig ? (RigMaxZ - RigMinZ) : 0.0;
		const double HeightAboveFeet = bHaveRig ? (static_cast<double>(P.Z) - RigMinZ) : static_cast<double>(P.Z);
		const double BoneAboveFeet   = bHaveRig ? (static_cast<double>(BonePos.Z) - RigMinZ) : static_cast<double>(BonePos.Z);

		UE_LOG(LogTemp, Warning, TEXT("[CloneStation] VERIFY socket '%s': component-space loc %s | bone '%s' | %.1f cm from "
			"that bone | %.1f cm above the rig's lowest bone | rig height %.1f"),
			*SocketName.ToString(), *P.ToString(), *S->BoneName.ToString(), DistFromBone, HeightAboveFeet, MeshHeight);

		bool bOk = true;
		if (HeightAboveFeet <= 1.0)
		{
			UE_LOG(LogTemp, Error, TEXT("[CloneStation] VERIFY FAILED: socket sits only %.1f cm above the rig's lowest bone "
				"— that is the MESH ROOT, so the weapon will be under the feet. Socket is on bone '%s'; the grip "
				"bone was mis-resolved. Check ResolveRightHandBone against this rig's bone names."),
				HeightAboveFeet, *S->BoneName.ToString());
			bOk = false;
		}
		else if (bHaveRig && BoneAboveFeet > 1.0 && HeightAboveFeet < BoneAboveFeet * 0.5)
		{
			UE_LOG(LogTemp, Warning, TEXT("[CloneStation] VERIFY: socket is %.1f cm above the feet but its bone sits at "
				"%.1f cm — the grip will hang low. Check the template socket's relative transform."),
				HeightAboveFeet, BoneAboveFeet);
			bOk = false;
		}
		if (DistFromBone > 60.0)
		{
			UE_LOG(LogTemp, Warning, TEXT("[CloneStation] VERIFY: socket is %.1f cm away from bone '%s' — suspiciously far "
				"for a grip point."), DistFromBone, *S->BoneName.ToString());
			bOk = false;
		}
		if (bHaveRig && HeightAboveFeet > MeshHeight)
		{
			UE_LOG(LogTemp, Warning, TEXT("[CloneStation] VERIFY: socket is %.1f cm above the feet but the whole rig is only "
				"%.1f cm tall — the weapon will float over the character's head."), HeightAboveFeet, MeshHeight);
			bOk = false;
		}
		if (bOk)
		{
			UE_LOG(LogTemp, Warning, TEXT("[CloneStation] VERIFY OK: socket '%s' is %.1f cm above the origin, on bone '%s'."),
				*SocketName.ToString(), P.Z, *S->BoneName.ToString());
		}
		return bOk;
	}

	/** Log every hand/wrist/arm bone so a rig we cannot resolve is fixable. */
	static void LogHandBoneCandidates(const USkeletalMesh* Mesh, const TCHAR* What)
	{
		if (!Mesh) return;
		FString Candidates;
		const FReferenceSkeleton& Ref = Mesh->GetRefSkeleton();
		for (int32 i = 0; i < Ref.GetNum(); ++i)
		{
			const FString N = Ref.GetBoneName(i).ToString();
			if (N.Contains(TEXT("hand"), ESearchCase::IgnoreCase) || N.Contains(TEXT("arm"), ESearchCase::IgnoreCase)
				|| N.Contains(TEXT("wrist"), ESearchCase::IgnoreCase))
			{
				Candidates += (Candidates.IsEmpty() ? TEXT("") : TEXT(", ")) + N;
			}
		}
		UE_LOG(LogTemp, Error, TEXT("[CloneStation] Could not identify a RIGHT-HAND bone on %s '%s'. Hand/arm-ish bones found: [%s]. "
			"Send me this list and I'll add the pattern."),
			What, *Mesh->GetName(), Candidates.IsEmpty() ? TEXT("none — send the full bone list from the Skeleton editor") : *Candidates);
	}

	// S18-GRIP: delegates to the shared resolver in SquadAIGripRetarget.h so the
	// editor tool and the runtime attach can never know different bone names.
	static FName ResolveGripBoneOnMesh(const USkeletalMesh* Mesh, const USkeletalMeshSocket* TemplateSocket)
	{
		return SquadAIGrip::ResolveRightHandBone(Mesh, TemplateSocket, TEXT("CloneStation"));
	}
}
#endif // WITH_EDITOR

void ACharacterCloneStation::CreateReadyClone()
{
#if WITH_EDITOR
	using namespace SquadAICloneStation;

	// ---- 1. validate input --------------------------------------------------
	if (!SourceCharacter)
	{
		UE_LOG(LogTemp, Error, TEXT("[CloneStation] Set SourceCharacter first (your V3 character Blueprint)."));
		return;
	}
	UBlueprint* SourceBP = Cast<UBlueprint>(SourceCharacter->ClassGeneratedBy);
	if (!SourceBP)
	{
		UE_LOG(LogTemp, Error, TEXT("[CloneStation] '%s' is a C++ class — pick a Blueprint character."), *SourceCharacter->GetName());
		return;
	}
	const ASoldierCharacter* SourceCDO = SourceCharacter->GetDefaultObject<ASoldierCharacter>();

	// S17-CLONE3: when a ReferenceCharacter is set (the mannequin BP that
	// holds the weapon correctly), the clone is set up EXACTLY like it — its
	// socket name wins over whatever the V3 Blueprint carries.
	const ASoldierCharacter* RefCDO = ReferenceCharacter ? ReferenceCharacter->GetDefaultObject<ASoldierCharacter>() : nullptr;
	const FName SocketName = RefCDO ? RefCDO->GetWeaponAttachSocketName()
		: (SourceCDO ? SourceCDO->GetWeaponAttachSocketName() : FName(TEXT("RifleSocket")));

	// ---- 2. resolve the grip template socket (mannequin) ---------------------
	// Order: ReferenceCharacter's mesh → GripTemplateMesh → SourceCharacter's
	// parent classes → whole-project scan (S17-CLONE2).
	const USkeletalMeshSocket* TemplateSocket = nullptr;
	const USkeletalMesh* TemplateMesh = nullptr;
	if (RefCDO && RefCDO->GetMesh() && RefCDO->GetMesh()->GetSkeletalMeshAsset())
	{
		TemplateMesh = RefCDO->GetMesh()->GetSkeletalMeshAsset();
		TemplateSocket = FindSocketOnMeshOrSkeleton(TemplateMesh, SocketName);
		if (!TemplateSocket)
		{
			UE_LOG(LogTemp, Warning, TEXT("[CloneStation] ReferenceCharacter '%s' has no socket '%s' on its mesh/skeleton — it must be gripping via hand-bone fallback. Its attach offsets will still be copied; continuing the socket hunt elsewhere."),
				*ReferenceCharacter->GetName(), *SocketName.ToString());
		}
	}
	if (!TemplateSocket && GripTemplateMesh)
	{
		TemplateMesh = GripTemplateMesh;
		TemplateSocket = FindSocketOnMeshOrSkeleton(TemplateMesh, SocketName);
	}
	for (UClass* Cls = *SourceCharacter; !TemplateSocket && Cls && Cls->IsChildOf(ASoldierCharacter::StaticClass()); Cls = Cls->GetSuperClass())
	{
		const ASoldierCharacter* CDO = Cls->GetDefaultObject<ASoldierCharacter>();
		const USkeletalMesh* CDOMesh = (CDO && CDO->GetMesh()) ? CDO->GetMesh()->GetSkeletalMeshAsset() : nullptr;
		if (CDOMesh)
		{
			TemplateSocket = FindSocketOnMeshOrSkeleton(CDOMesh, SocketName);
			if (TemplateSocket) TemplateMesh = CDOMesh;
		}
	}
	if (!TemplateSocket)
	{
		// S17-CLONE2: duplicated (non-child) V3 Blueprints never reach the
		// mannequin through the class walk — scan the whole project instead.
		const USkeletalMesh* TargetMesh = V3Mesh ? V3Mesh.Get()
			: ((SourceCDO && SourceCDO->GetMesh()) ? SourceCDO->GetMesh()->GetSkeletalMeshAsset() : nullptr);
		const USkeleton* TargetSkeleton = TargetMesh ? TargetMesh->GetSkeleton() : nullptr;
		TemplateSocket = ScanProjectForTemplateSocket(SocketName, TemplateMesh, TargetSkeleton);
	}
	if (!TemplateSocket)
	{
		// ===== S19-GRIPHUNT =====================================================
		// The named hunt above only ever looked for ONE socket name. The engine's own
		// mannequin calls its right-hand weapon socket 'weapon_r', so a project that HAS
		// a usable template reported "no template socket found" and baked an identity
		// socket instead - weapon pivot on the hand bone, hand axes, looks wrong.
		// HuntStandardGripTemplate() is shared with CreateReadyMesh() so the two output
		// paths can never disagree about which template they found.
		const USkeletalMesh* TargetMesh2 = V3Mesh ? V3Mesh.Get()
			: ((SourceCDO && SourceCDO->GetMesh()) ? SourceCDO->GetMesh()->GetSkeletalMeshAsset() : nullptr);
		TemplateSocket = HuntStandardGripTemplate(SocketName, RefCDO, *SourceCharacter, GripTemplateMesh,
			TargetMesh2, TargetMesh2 ? TargetMesh2->GetSkeleton() : nullptr, TemplateMesh, TEXT("CREATE READY CLONE"));
	}
	if (!TemplateSocket)
	{
		// S17-CLONE4: the socket exists NOWHERE — the working character grips
		// via hand-bone fallback + attach offsets. Solution: FABRICATE the
		// socket directly on the V3 skeleton's right-hand bone (zero relative
		// transform), so the copied/duplicated offsets produce the exact same
		// grip as the mannequin's fallback path.
		UE_LOG(LogTemp, Warning, TEXT("[CloneStation] No socket '%s' anywhere in the project — will CREATE it on the clone's right-hand bone (zero offset) and drive the grip with the copied attach offsets, exactly like the working character does."), *SocketName.ToString());
	}

	// ---- 3. duplicate the Blueprint ------------------------------------------
	FString BaseName = CloneName.TrimStartAndEnd();
	if (BaseName.IsEmpty())
	{
		BaseName = FString::Printf(TEXT("BP_%s_Ready"), *SourceBP->GetName().Replace(TEXT("BP_"), TEXT("")));
	}
	FString Folder = CloneFolder.TrimStartAndEnd();
	if (Folder.IsEmpty()) Folder = TEXT("/Game/SquadAI/Clones");

	// S19-CLONE3: replacing the previous clone keeps one asset per name and
	// removes the "which _3 do I place?" problem when re-running the fix.
	const FString FinalName = ResolveOutputName(BaseName, Folder, bOverwriteExistingClones);

	IAssetTools& AssetTools = FModuleManager::LoadModuleChecked<FAssetToolsModule>("AssetTools").Get();
	UBlueprint* CloneBP = Cast<UBlueprint>(AssetTools.DuplicateAsset(FinalName, Folder, SourceBP));
	if (!CloneBP || !CloneBP->GeneratedClass)
	{
		UE_LOG(LogTemp, Error, TEXT("[CloneStation] Duplicating '%s' into '%s' failed."), *SourceBP->GetName(), *Folder);
		return;
	}

	// ---- 4. configure the clone's defaults -----------------------------------
	ASoldierCharacter* CloneCDO = CloneBP->GeneratedClass->GetDefaultObject<ASoldierCharacter>();
	if (!CloneCDO || !CloneCDO->GetMesh())
	{
		UE_LOG(LogTemp, Error, TEXT("[CloneStation] Clone has no mesh component — aborting configure."));
		return;
	}
	CloneCDO->Modify();
	if (V3Mesh)
	{
		CloneCDO->GetMesh()->SetSkeletalMeshAsset(V3Mesh);
	}
	CloneCDO->GripSocketTemplateMesh = const_cast<USkeletalMesh*>(TemplateMesh); // runtime safety net (GRIP2)

	// S19-CLONE3: OPEN THE GATE FIRST. ApplyEquippedWeaponAttachment() bails out
	// entirely when bAutoAttachEquippedWeaponToMesh is false or
	// bUsePackPresentationMode is true — the weapon is then never attached and
	// just sits at the actor origin (between the feet). A V3 Blueprint that was
	// not derived from the mannequin BP leaves both flags at their defaults
	// (false / false... with auto-attach FALSE), which no socket fix can cure.
	if (bForceWeaponAttachOnClone)
	{
		const bool bAttachBefore = CloneCDO->bAutoAttachEquippedWeaponToMesh;
		const bool bPackBefore = CloneCDO->bUsePackPresentationMode;
		CloneCDO->bAutoAttachEquippedWeaponToMesh = RefCDO ? RefCDO->bAutoAttachEquippedWeaponToMesh : true;
		CloneCDO->bUsePackPresentationMode = RefCDO ? RefCDO->bUsePackPresentationMode : false;
		if (CloneCDO->bAutoAttachEquippedWeaponToMesh != bAttachBefore || CloneCDO->bUsePackPresentationMode != bPackBefore)
		{
			UE_LOG(LogTemp, Warning, TEXT("[CloneStation] Weapon-attach gate was CLOSED on the source (bAutoAttachEquippedWeaponToMesh=%d, bUsePackPresentationMode=%d) — "
				"the weapon was never being attached at all. Now %d / %d."),
				bAttachBefore ? 1 : 0, bPackBefore ? 1 : 0,
				CloneCDO->bAutoAttachEquippedWeaponToMesh ? 1 : 0, CloneCDO->bUsePackPresentationMode ? 1 : 0);
		}
	}

	// S17-CLONE3: set the clone up exactly like the reference (mannequin):
	// same socket name and the same hand-tuned attach offsets.
	if (RefCDO)
	{
		CloneCDO->WeaponAttachSocketName = RefCDO->WeaponAttachSocketName;
		CloneCDO->WeaponAttachLocationOffset = RefCDO->WeaponAttachLocationOffset;
		CloneCDO->WeaponAttachRotationOffset = RefCDO->WeaponAttachRotationOffset;
		CloneCDO->bOverrideWeaponAttachScale = RefCDO->bOverrideWeaponAttachScale;
		CloneCDO->WeaponAttachScale = RefCDO->WeaponAttachScale;
		// S19-CLONE3: these three drive the runtime retarget. Copying them keeps
		// the clone's runtime grip identical to the reference's instead of
		// silently falling back to the C++ defaults.
		CloneCDO->bRetargetGripToOwnSkeleton = RefCDO->bRetargetGripToOwnSkeleton;
		CloneCDO->bAutoScaleWeaponToGrip = RefCDO->bAutoScaleWeaponToGrip;
		CloneCDO->WeaponGripScaleMultiplier = RefCDO->WeaponGripScaleMultiplier;
	}

	// S19-CLONE3: extra packages (fixed mesh / skeleton) that must be saved
	// alongside the Blueprint, plus the outcome flag for the final log.
	TArray<UPackage*> ExtraPackages;
	bool bSocketCreated = false;

	// ---- 5. permanent grip socket (S19-CLONE3) ------------------------------
	// Bake onto a DUPLICATE of the mesh as a MESH-level socket. The V3 mesh and
	// its (usually shared) skeleton are never modified, and a socket baked with
	// old math is REPLACED instead of being skipped as "already exists".
	USkeletalMesh* CloneMesh = V3Mesh ? V3Mesh.Get() : CloneCDO->GetMesh()->GetSkeletalMeshAsset();
	if (!CloneMesh)
	{
		UE_LOG(LogTemp, Error, TEXT("[CloneStation] Clone has no skeletal mesh — grip socket step skipped."));
	}
	else
	{
		const FName GripBone = ResolveGripBoneOnMesh(CloneMesh, TemplateSocket);
		if (GripBone.IsNone())
		{
			LogHandBoneCandidates(CloneMesh, TEXT("mesh"));
		}
		else
		{
			const FGripTransform Grip = ComputeGripTransform(
				TemplateMesh, TemplateSocket, CloneMesh, GripBone,
				bRetargetGripSocket, bAutoScaleWeaponToGrip, WeaponScaleMultiplier,
				RefCDO ? RefCDO : SourceCDO);

			// Bake the name the runtime asks for, plus every alias, so that
			// whichever name a consumer looks up, it exists and is correct.
			TArray<FName> BakeNames;
			BakeNames.AddUnique(SocketName);
			for (const FName& Extra : AdditionalSocketNames) { if (!Extra.IsNone()) BakeNames.AddUnique(Extra); }
			// S19-GRIPHUNT: also bake the standard engine/pack names. The consumer decides which
			// name it asks for, and the mesh is the only artefact that reaches it - a missing
			// name silently attaches the weapon to the mesh root.
			for (const FName& Standard : StandardGripSocketNames()) { if (!Standard.IsNone()) BakeNames.AddUnique(Standard); }

			if (bDuplicateMeshForClone)
			{
				// BP_Foo_Ready -> SK_Foo_Ready (drop the BP_ prefix, add SK_)
				FString Stem = FinalName;
				if (Stem.StartsWith(TEXT("BP_"), ESearchCase::CaseSensitive)) Stem = Stem.Mid(3);
				const FString MeshBase = FString::Printf(TEXT("SK_%s"), *Stem);
				const FString MeshName = ResolveOutputName(MeshBase, Folder, bOverwriteExistingClones);
				USkeletalMesh* FixedMesh = Cast<USkeletalMesh>(AssetTools.DuplicateAsset(MeshName, Folder, CloneMesh));
				if (FixedMesh)
				{
					// S19-NAMEBAKE: same per-name rule as CREATE READY MESH, so the two
					// buttons can never bake different grips under the same name.
					TArray<FGripTransform> CloneTransforms;
					BuildPerNameGripTransforms(BakeNames, Grip, RefCDO, *SourceCharacter, GripTemplateMesh,
						CloneMesh, FixedMesh, GripBone,
						bRetargetGripSocket, bAutoScaleWeaponToGrip, WeaponScaleMultiplier,
						TEXT("CREATE READY CLONE"), CloneTransforms);
					const int32 Made = BakeSocketsIntoMeshPerName(FixedMesh, GripBone, BakeNames, CloneTransforms);
					CloneCDO->GetMesh()->SetSkeletalMeshAsset(FixedMesh);
					CloneCDO->GripSocketTemplateMesh = const_cast<USkeletalMesh*>(TemplateMesh);
					CloneMesh = FixedMesh;
					ExtraPackages.Add(FixedMesh->GetOutermost());
					bSocketCreated = Made > 0;
					UE_LOG(LogTemp, Warning, TEXT("[CloneStation] Baked %d mesh-level grip socket(s) into '%s/%s' at bone '%s' (%s). "
						"Original '%s' and its skeleton are untouched."),
						Made, *Folder, *MeshName, *GripBone.ToString(), *Grip.Why, *GetNameSafe(V3Mesh ? V3Mesh.Get() : nullptr));
				}
				else
				{
					UE_LOG(LogTemp, Warning, TEXT("[CloneStation] Mesh duplication failed — falling back to a socket on the shared skeleton."));
				}
			}

			if (!bSocketCreated)
			{
				// Legacy path (bDuplicateMeshForClone off, or duplication failed):
				// still REPLACE rather than skip.
				USkeleton* CloneSkeleton = CloneMesh->GetSkeleton();
				if (!CloneSkeleton)
				{
					UE_LOG(LogTemp, Warning, TEXT("[CloneStation] Clone mesh has no skeleton — no socket created (runtime GRIP2 clone still covers it)."));
				}
				else if ([&]() -> bool
					{
						// S19-NAMEBAKE: the named socket gets the working template's transform
						// when one exists under that exact name.
						FGripTransform Own = Grip;
						const USkeletalMesh* TemplateUsed = nullptr;
						FString Where;
						ResolveNameSpecificGripTransform(SocketName, RefCDO, *SourceCharacter, GripTemplateMesh,
							CloneMesh, CloneMesh, GripBone, bRetargetGripSocket, bAutoScaleWeaponToGrip,
							WeaponScaleMultiplier, Own, TemplateUsed, Where);
						if (!Where.IsEmpty())
						{
							UE_LOG(LogTemp, Warning, TEXT("[CloneStation] S19-NAMEBAKE (CREATE READY CLONE/skeleton): '%s' <- %s"), *SocketName.ToString(), *Where);
						}
						return BakeSocketIntoSkeleton(CloneSkeleton, SocketName, GripBone, Own);
					}())
				{
					ExtraPackages.Add(CloneSkeleton->GetOutermost());
					bSocketCreated = true;
				}
			}

			if (bVerifyGripSocket)
			{
				VerifyGripSocket(CloneMesh, SocketName, GripBone);
			}
		}
	}

	// ---- 6. compile + save ----------------------------------------------------
	FKismetEditorUtilities::CompileBlueprint(CloneBP);
	CloneBP->MarkPackageDirty();
	TArray<UPackage*> ToSave;
	ToSave.Add(CloneBP->GetOutermost());
	for (UPackage* Pkg : ExtraPackages)
	{
		if (Pkg && Pkg != CloneBP->GetOutermost()) ToSave.AddUnique(Pkg);
	}
	UEditorLoadingAndSavingUtils::SavePackages(ToSave, /*bOnlyDirty*/ false);

	UE_LOG(LogTemp, Warning, TEXT("[CloneStation] READY: %s/%s — mesh:%s, grip socket:%s (bone from '%s'), reference:%s, template net:%s. Place it in your mission and play."),
		*Folder, *FinalName,
		V3Mesh ? *V3Mesh->GetName() : TEXT("kept from source"),
		bSocketCreated ? TEXT("BAKED+SAVED") : TEXT("FAILED — see the errors above"),
		TemplateSocket ? *TemplateSocket->BoneName.ToString() : TEXT("fallback grip"),
		RefCDO ? *ReferenceCharacter->GetName() : TEXT("auto"),
		*GetNameSafe(TemplateMesh));
#else
	UE_LOG(LogTemp, Warning, TEXT("[CloneStation] Editor-only tool — does nothing in a packaged game."));
#endif // WITH_EDITOR
}

void ACharacterCloneStation::CreateReadyMesh()
{
#if WITH_EDITOR
	// S17-CLONE5: pure-MESH output for external consumers (leader pack etc.).
	// No Blueprint is created: the V3 mesh is duplicated and the grip socket
	// is baked into the DUPLICATE's own socket list. Mesh-level sockets are
	// checked BEFORE skeleton sockets by GetSocketByName, so this wins over
	// any stale/misplaced skeleton socket from earlier attempts.
	using namespace SquadAICloneStation;

	// ---- 1. the mesh to fix ---------------------------------------------
	USkeletalMesh* Source = V3Mesh ? V3Mesh.Get() : nullptr;
	const ASoldierCharacter* SourceCDO = SourceCharacter ? SourceCharacter->GetDefaultObject<ASoldierCharacter>() : nullptr;
	if (!Source && SourceCDO && SourceCDO->GetMesh())
	{
		Source = SourceCDO->GetMesh()->GetSkeletalMeshAsset();
	}
	if (!Source)
	{
		UE_LOG(LogTemp, Error, TEXT("[CloneStation] Set V3Mesh (your character's skeletal mesh) first."));
		return;
	}

	// ---- 2. socket name + grip template ----------------------------------
	const ASoldierCharacter* RefCDO = ReferenceCharacter ? ReferenceCharacter->GetDefaultObject<ASoldierCharacter>() : nullptr;
	const FName SocketName = RefCDO ? RefCDO->GetWeaponAttachSocketName()
		: (SourceCDO ? SourceCDO->GetWeaponAttachSocketName() : FName(TEXT("RifleSocket")));

	const USkeletalMeshSocket* TemplateSocket = nullptr;
	const USkeletalMesh* TemplateMesh = nullptr;
	if (RefCDO && RefCDO->GetMesh() && RefCDO->GetMesh()->GetSkeletalMeshAsset())
	{
		TemplateMesh = RefCDO->GetMesh()->GetSkeletalMeshAsset();
		TemplateSocket = FindSocketOnMeshOrSkeleton(TemplateMesh, SocketName);
	}
	if (!TemplateSocket && GripTemplateMesh)
	{
		TemplateMesh = GripTemplateMesh;
		TemplateSocket = FindSocketOnMeshOrSkeleton(TemplateMesh, SocketName);
	}
	if (!TemplateSocket)
	{
		TemplateSocket = ScanProjectForTemplateSocket(SocketName, TemplateMesh, Source->GetSkeleton());
	}
	if (!TemplateSocket)
	{
		// S19-GRIPHUNT: THE PATH THAT MATTERS when the ready MESH (not the clone
		// Blueprint) is what gets assigned to a character - this is the button that makes
		// the mesh the leader pack wears. It used to stop at the named hunt above, which
		// is exactly why a project that HAS the engine mannequin ('weapon_r') still baked
		// an identity socket on hand_r.
		TemplateSocket = HuntStandardGripTemplate(SocketName, RefCDO, *SourceCharacter, GripTemplateMesh,
			Source, Source->GetSkeleton(), TemplateMesh, TEXT("CREATE READY MESH"));
	}

	// ---- 3. right-hand bone on THIS mesh ----------------------------------
	const FName GripBone = ResolveGripBoneOnMesh(Source, TemplateSocket);
	if (GripBone.IsNone())
	{
		LogHandBoneCandidates(Source, TEXT("mesh"));
		return;
	}

	// ---- 4. duplicate the mesh asset --------------------------------------
	// S19-CLONE3: reuse the existing name instead of spawning _2/_3/_4, so the
	// asset stays put and consumers keep referencing the same thing.
	FString BaseName = CloneName.TrimStartAndEnd();
	if (BaseName.IsEmpty())
	{
		BaseName = FString::Printf(TEXT("SK_%s_Ready"), *Source->GetName());
	}
	FString Folder = CloneFolder.TrimStartAndEnd();
	if (Folder.IsEmpty()) Folder = TEXT("/Game/SquadAI/Clones");
	const FString FinalName = ResolveOutputName(BaseName, Folder, bOverwriteExistingClones);

	IAssetTools& AssetTools = FModuleManager::LoadModuleChecked<FAssetToolsModule>("AssetTools").Get();
	USkeletalMesh* NewMesh = Cast<USkeletalMesh>(AssetTools.DuplicateAsset(FinalName, Folder, Source));
	if (!NewMesh)
	{
		UE_LOG(LogTemp, Error, TEXT("[CloneStation] Duplicating mesh '%s' into '%s' failed."), *Source->GetName(), *Folder);
		return;
	}

	// ---- 5. bake the socket INTO the duplicate ----------------------------
	// S19-CLONE3: same shared math as CREATE READY CLONE, so the two buttons
	// can never disagree about where the grip belongs.
	const FGripTransform Grip = ComputeGripTransform(
		TemplateMesh, TemplateSocket, Source, GripBone,
		bRetargetGripSocket, bAutoScaleWeaponToGrip, WeaponScaleMultiplier,
		RefCDO ? RefCDO : SourceCDO);

	// S17-CLONE6: bake under the main name PLUS every AdditionalSocketNames
	// entry (same bone, same transform) — external consumers each look for
	// their own socket name, and this way whichever it asks for exists.
	TArray<FName> BakeNames;
	BakeNames.AddUnique(SocketName);
	for (const FName& Extra : AdditionalSocketNames) { if (!Extra.IsNone()) BakeNames.AddUnique(Extra); }
	// S19-GRIPHUNT: also bake the standard engine/pack names. The consumer decides which
	// name it asks for, and the mesh is the only artefact that reaches it - a missing
	// name silently attaches the weapon to the mesh root.
	for (const FName& Standard : StandardGripSocketNames()) { if (!Standard.IsNone()) BakeNames.AddUnique(Standard); }

	// S19-NAMEBAKE: per-name transforms. 'hand_rSocket' must carry the SAME grip the working
	// character uses under that name, not the engine mannequin's 'weapon_r' rotation - that
	// mismatch is what kept the rifle sideways in the log.
	TArray<FGripTransform> BakeTransforms;
	BuildPerNameGripTransforms(BakeNames, Grip, RefCDO, *SourceCharacter, GripTemplateMesh,
		Source, NewMesh, GripBone,
		bRetargetGripSocket, bAutoScaleWeaponToGrip, WeaponScaleMultiplier,
		TEXT("CREATE READY MESH"), BakeTransforms);

	const int32 Made = BakeSocketsIntoMeshPerName(NewMesh, GripBone, BakeNames, BakeTransforms);
	if (Made == 0)
	{
		UE_LOG(LogTemp, Error, TEXT("[CloneStation] No socket was baked into '%s' — nothing to save."), *FinalName);
		return;
	}

	if (bVerifyGripSocket)
	{
		VerifyGripSocket(NewMesh, SocketName, GripBone);
	}

	TArray<UPackage*> ToSave;
	ToSave.Add(NewMesh->GetOutermost());
	UEditorLoadingAndSavingUtils::SavePackages(ToSave, /*bOnlyDirty*/ false);

	UE_LOG(LogTemp, Warning, TEXT("[CloneStation] READY MESH: %s/%s — socket '%s' baked ON THE MESH at bone '%s' (%s). Give this mesh to your leader pack; the original '%s' is untouched."),
		*Folder, *FinalName, *SocketName.ToString(), *GripBone.ToString(),
		TemplateSocket ? TEXT("transform cloned from template") : TEXT("transform baked from the working character's attach offsets"),
		*Source->GetName());


	// S19-GRIPHUNT: say plainly WHICH mesh the character class is using right now, and
	// whether the mesh that was just baked is the one it will wear. "The weapon is still in
	// the wrong position" has two possible causes and this line separates them:
	//   * this line names a mesh that is NOT the new one  -> the assignment never happened
	//     (the ready MESH has to be set on the character/Blueprint; the clone Blueprint is
	//      not used in this project's workflow), or
	//   * it names the new mesh -> the socket is right and the pack's own attach is the
	//     remaining suspect (the runtime snapshot line then reports parent/socket/exists).
	{
		const USkeletalMesh* InUseNow = nullptr;
		const TCHAR* InUseOwner = TEXT("nobody");
		if (ReferenceCharacter)
		{
			if (const ASoldierCharacter* CDO = ReferenceCharacter->GetDefaultObject<ASoldierCharacter>())
			{
				if (CDO->GetMesh()) { InUseNow = CDO->GetMesh()->GetSkeletalMeshAsset(); }
				InUseOwner = TEXT("ReferenceCharacter");
			}
		}
		if (!InUseNow && SourceCharacter)
		{
			if (const ASoldierCharacter* CDO = SourceCharacter->GetDefaultObject<ASoldierCharacter>())
			{
				if (CDO->GetMesh()) { InUseNow = CDO->GetMesh()->GetSkeletalMeshAsset(); }
				InUseOwner = TEXT("SourceCharacter");
			}
		}

		if (InUseNow == NewMesh)
		{
			UE_LOG(LogTemp, Warning, TEXT("[CloneStation] ASSIGNMENT OK: %s already points at the mesh that was just baked (%s)."),
				InUseOwner, *NewMesh->GetName());
		}
		else
		{
			UE_LOG(LogTemp, Warning, TEXT("[CloneStation] ASSIGNMENT CHECK: %s currently uses mesh '%s'. The mesh just baked is '%s' — assign THAT one to the character/Blueprint that wears it, or the new grip socket is simply not in use."),
				InUseOwner,
				InUseNow ? *InUseNow->GetName() : TEXT("(no mesh set)"),
				*NewMesh->GetName());
		}
	}
#else
	UE_LOG(LogTemp, Warning, TEXT("[CloneStation] Editor-only tool — does nothing in a packaged game."));
#endif // WITH_EDITOR
}

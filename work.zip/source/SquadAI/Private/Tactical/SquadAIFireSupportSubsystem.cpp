#include "Tactical/SquadAIFireSupportSubsystem.h"
#include "Performance/SquadAIAudioSubsystem.h"
#include "Actors/SquadAIAudioManager.h"
#include "Kismet/GameplayStatics.h"
#include "Tutorial/SquadAITutorialSubsystem.h" // S18-TUT
#include "Engine/World.h"
#include "Engine/Engine.h"

void USquadAIFireSupportSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
	UE_LOG(LogTemp, Log, TEXT("[SquadAIFireSupportSubsystem] Tactical Fire Support Subsystem Initialized"));
}

void USquadAIFireSupportSubsystem::Deinitialize()
{
	Super::Deinitialize();
}

USquadAIFireSupportSubsystem* USquadAIFireSupportSubsystem::Get(const UObject* WorldContextObject)
{
	if (!WorldContextObject) return nullptr;
	UWorld* World = GEngine ? GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::ReturnNull) : nullptr;
	return World ? World->GetSubsystem<USquadAIFireSupportSubsystem>() : nullptr;
}

bool USquadAIFireSupportSubsystem::IsFireSupportReady() const
{
	if (bUnlimitedArtilleryCalls || SupportCooldownSeconds <= 0.0f)
	{
		return true;
	}
	if (const UWorld* World = GetWorld())
	{
		return (World->GetTimeSeconds() - LastStrikeTimeSeconds) >= SupportCooldownSeconds;
	}
	return CurrentCooldownTimer <= 0.0f;
}

float USquadAIFireSupportSubsystem::GetCooldownRemaining() const
{
	if (bUnlimitedArtilleryCalls || SupportCooldownSeconds <= 0.0f)
	{
		return 0.0f;
	}
	if (const UWorld* World = GetWorld())
	{
		return FMath::Max(0.0f, SupportCooldownSeconds - (World->GetTimeSeconds() - LastStrikeTimeSeconds));
	}
	return FMath::Max(0.0f, CurrentCooldownTimer);
}

void USquadAIFireSupportSubsystem::TickCooldown(float DeltaTime)
{
	if (CurrentCooldownTimer > 0.0f)
	{
		CurrentCooldownTimer -= DeltaTime;
	}
}

bool USquadAIFireSupportSubsystem::CallMortarStrike(const FVector& TargetLocation, int32 ShellCount)
{
	if (!IsFireSupportReady())
	{
		UE_LOG(LogTemp, Warning, TEXT("[FireSupport] Artillery on cooldown (%.1fs remaining)"), GetCooldownRemaining());
		return false;
	}

	UWorld* World = GetWorld();
	if (!World) return false;

	FActorSpawnParameters SpawnParams;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	ATacticalMortarBarrageActor* Barrage = World->SpawnActor<ATacticalMortarBarrageActor>(ATacticalMortarBarrageActor::StaticClass(), TargetLocation, FRotator::ZeroRotator, SpawnParams);
	if (!Barrage) return false;

	Barrage->ShellCount = ShellCount;
	Barrage->StartBarrage(TargetLocation);

	CurrentCooldownTimer = bUnlimitedArtilleryCalls ? 0.0f : SupportCooldownSeconds;
	LastStrikeTimeSeconds = World->GetTimeSeconds();

	if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
	{
		if (ASquadAIAudioManager* Mgr = AudioSys->GetActiveAudioManager())
		{
			if (Mgr->TacticalRadioClick)
			{
				UGameplayStatics::PlaySound2D(World, Mgr->TacticalRadioClick.Get(), 1.0f);
			}
		}
	}

	if (GEngine)
	{
		GEngine->AddOnScreenDebugMessage(-1, 3.5f, FColor::Orange, FString::Printf(TEXT("[FIRE SUPPORT] Mortar Strike Salvo Inbound (%d shells)!"), ShellCount));
	}

	// S18-TUT: the "درخواست آتیش توپخانه" training step completes here.
	if (USquadAITutorialSubsystem* Tut = USquadAITutorialSubsystem::Get(this))
	{
		Tut->NotifyArtilleryCalled();
	}

	return true;
}

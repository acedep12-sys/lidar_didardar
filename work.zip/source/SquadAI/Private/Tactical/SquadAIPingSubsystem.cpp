#include "Tactical/SquadAIPingSubsystem.h"
#include "Performance/SquadAIAudioSubsystem.h"
#include "Actors/SquadAIAudioManager.h"
#include "Engine/World.h"
#include "TimerManager.h"
#include "Kismet/GameplayStatics.h"

void USquadAIPingSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);

	UWorld* World = GetWorld();
	if (World && World->IsGameWorld())
	{
		World->GetTimerManager().SetTimer(PingTickTimerHandle, this, &USquadAIPingSubsystem::TickPings, 0.05f, true);
	}
}

void USquadAIPingSubsystem::Deinitialize()
{
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(PingTickTimerHandle);
	}
	ActivePings.Empty();
	Super::Deinitialize();
}

USquadAIPingSubsystem* USquadAIPingSubsystem::Get(const UObject* WorldContextObject)
{
	if (!WorldContextObject) return nullptr;
	UWorld* World = GEngine ? GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::ReturnNull) : nullptr;
	return World ? World->GetSubsystem<USquadAIPingSubsystem>() : nullptr;
}

void USquadAIPingSubsystem::PlacePing(FVector Location, ETacticalPingType Type, AActor* Instigator)
{
	FTacticalPing NewPing;
	NewPing.WorldLocation = Location;
	NewPing.Type = Type;
	NewPing.MaxDuration = 8.0f;
	NewPing.TimeRemaining = 8.0f;
	NewPing.Instigator = Instigator;

	// Limit concurrent pings to 5
	if (ActivePings.Num() >= 5)
	{
		ActivePings.RemoveAt(0);
	}

	ActivePings.Add(NewPing);

	// Play spatialized / 2D ping feedback sound
	if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
	{
		if (ASquadAIAudioManager* Mgr = AudioSys->GetActiveAudioManager())
		{
			if (Mgr->TacticalRadioClick)
			{
				UGameplayStatics::PlaySound2D(GetWorld(), Mgr->TacticalRadioClick, 0.9f);
			}
		}
	}

	OnPingPlaced.Broadcast(Location, Type);
}

void USquadAIPingSubsystem::ClearAllPings()
{
	ActivePings.Empty();
}

void USquadAIPingSubsystem::TickPings()
{
	constexpr float DeltaTime = 0.05f;

	for (int32 i = ActivePings.Num() - 1; i >= 0; --i)
	{
		ActivePings[i].TimeRemaining -= DeltaTime;
		if (ActivePings[i].TimeRemaining <= 0.0f)
		{
			ActivePings.RemoveAt(i);
		}
	}
}

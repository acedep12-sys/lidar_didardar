// SquadAIExplosiveDamage.cpp — S18-BOOM
#include "Tactical/SquadAIExplosiveDamage.h"
#include "Characters/SoldierCharacter.h"
#include "Components/HealthComponent.h"
#include "HUD/QuestNativeHUD.h"
#include "Engine/World.h"
#include "Engine/Engine.h"
#include "GameFramework/Pawn.h"
#include "Kismet/GameplayStatics.h"
#include "Tutorial/SquadAITutorialSubsystem.h" // S18-TUT2
#include "CollisionQueryParams.h"
#include "Tactical/TacticalMortarBarrageActor.h" // S19-BLASTGUARD (artillery-only guard)

static UWorld* BoomWorld(const UObject* Ctx)
{
	return (Ctx && GEngine) ? GEngine->GetWorldFromContextObject(Ctx, EGetWorldErrorMode::ReturnNull) : nullptr;
}

bool USquadAIExplosiveDamageLibrary::ApplyDamageToPlayerPawn(APawn* PlayerPawn, float Damage, AActor* DamageCauser)
{
	if (!PlayerPawn || Damage <= 0.f)
	{
		return false;
	}

	// S18-TUT2: the player is invulnerable for the duration of the tutorial —
	// including his own practice grenade and the artillery he is told to call.
	if (USquadAITutorialSubsystem::IsTutorialProtectingPlayer(PlayerPawn))
	{
		UE_LOG(LogTemp, Verbose, TEXT("[S18-BOOM] Player damage ignored: tutorial protection active."));
		return true;
	}

	// 1. Native SquadAI character — go through the normal damage chokepoint so
	//    invincibility, spawn grace, downed/death events all behave.
	if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(PlayerPawn))
	{
		if (Soldier->HealthComp && Soldier->HealthComp->IsAlive())
		{
			Soldier->HealthComp->ApplyDamage(Damage, DamageCauser);
			return true;
		}
	}

	// 2. Pack Blueprint health component — reflection, same as the combat bridge.
	TArray<UActorComponent*> Comps;
	PlayerPawn->GetComponents(Comps);
	for (UActorComponent* C : Comps)
	{
		if (!C || !C->GetClass()) continue;
		if (!C->GetClass()->GetName().Contains(TEXT("Health"))) continue;

		for (const FName& PropName : { FName(TEXT("currentHealth")), FName(TEXT("CurrentHealth")), FName(TEXT("Health")), FName(TEXT("HP")) })
		{
			if (FDoubleProperty* DP = FindFProperty<FDoubleProperty>(C->GetClass(), PropName))
			{
				const double HP = DP->GetPropertyValue_InContainer(C);
				if (HP <= 0.0) continue;
				DP->SetPropertyValue_InContainer(C, FMath::Max(0.0, HP - static_cast<double>(Damage)));
				UE_LOG(LogTemp, Warning, TEXT("[S18-BOOM] Player took %.1f explosive damage (%s.%s %.1f -> %.1f)"),
					Damage, *C->GetClass()->GetName(), *PropName.ToString(), HP, FMath::Max(0.0, HP - Damage));
				return true;
			}
			if (FFloatProperty* FP = FindFProperty<FFloatProperty>(C->GetClass(), PropName))
			{
				const float HP = FP->GetPropertyValue_InContainer(C);
				if (HP <= 0.f) continue;
				FP->SetPropertyValue_InContainer(C, FMath::Max(0.f, HP - Damage));
				UE_LOG(LogTemp, Warning, TEXT("[S18-BOOM] Player took %.1f explosive damage (%s.%s %.1f -> %.1f)"),
					Damage, *C->GetClass()->GetName(), *PropName.ToString(), HP, FMath::Max(0.f, HP - Damage));
				return true;
			}
		}
	}

	// 3. Last resort: the engine path, in case the pawn does implement TakeDamage.
	UGameplayStatics::ApplyDamage(PlayerPawn, Damage, PlayerPawn->GetController(), DamageCauser, nullptr);
	UE_LOG(LogTemp, Warning, TEXT("[S18-BOOM] Player explosive damage %.1f sent via TakeDamage fallback (no health component found on %s)."),
		Damage, *GetNameSafe(PlayerPawn));
	return true;
}

// S19-BLASTGUARD: helpers. The pack's health lives on a Blueprint component we reach by
// reflection (same as ApplyDamageToPlayerPawn takes care of), so "how hurt is the player"
// has to be read the same way. Returns false when nothing could be read.
static bool ReadPlayerHealthForBlast(APawn* Player, float& OutHealth, float& OutMaxHealth)
{
	OutHealth = 0.f;
	OutMaxHealth = 100.f;
	if (!Player) return false;

	// Native first.
	if (const ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(Player))
	{
		if (Soldier->HealthComp)
		{
			OutHealth = Soldier->HealthComp->CurrentHealth;
			if (Soldier->HealthComp->MaxHealth > 0.f) OutMaxHealth = Soldier->HealthComp->MaxHealth;
			return true;
		}
	}

	// Pack: reflection over the same property names the damage path writes.
	bool bRead = false;
	TArray<UActorComponent*> Comps;
	Player->GetComponents(Comps);
	for (UActorComponent* C : Comps)
	{
		if (!C || !C->GetClass() || !C->GetClass()->GetName().Contains(TEXT("Health"))) continue;
		for (const FName& PropName : { FName(TEXT("currentHealth")), FName(TEXT("CurrentHealth")), FName(TEXT("Health")), FName(TEXT("HP")) })
		{
			if (const FDoubleProperty* DP = FindFProperty<FDoubleProperty>(C->GetClass(), PropName))
			{
				OutHealth = static_cast<float>(DP->GetPropertyValue_InContainer(C));
				bRead = true;
				break;
			}
			if (const FFloatProperty* FP = FindFProperty<FFloatProperty>(C->GetClass(), PropName))
			{
				OutHealth = FP->GetPropertyValue_InContainer(C);
				bRead = true;
				break;
			}
		}
		if (bRead) break;
	}
	if (!bRead) return false;

	for (UActorComponent* C : Comps)
	{
		if (!C || !C->GetClass() || !C->GetClass()->GetName().Contains(TEXT("Health"))) continue;
		for (const FName& PropName : { FName(TEXT("maxHealth")), FName(TEXT("MaxHealth")), FName(TEXT("MaxHealthValue")), FName(TEXT("MaxHP")) })
		{
			if (const FDoubleProperty* DP = FindFProperty<FDoubleProperty>(C->GetClass(), PropName))
			{
				const float V = static_cast<float>(DP->GetPropertyValue_InContainer(C));
				if (V > 0.f) OutMaxHealth = V;
				return true;
			}
			if (const FFloatProperty* FP = FindFProperty<FFloatProperty>(C->GetClass(), PropName))
			{
				const float V = FP->GetPropertyValue_InContainer(C);
				if (V > 0.f) OutMaxHealth = V;
				return true;
			}
		}
	}
	return true;
}

// S19-BLASTGUARD: the live log had four deaths in 76 s, every one of them a barrage that
// was called on the player's own position: 76.5 -> 0 in two shells (38.0 + 55.8), then
// 65.8 -> 0 in one (80.0), then 100 -> 0 in three. A salvo that lands on your head and
// deletes you between two frames reads as a bug, not as artillery. The rule now:
//   * one artillery hit can take at most MaxHitFraction of the player's maximum health;
//   * a hit may not take the player from above the floor to zero - it leaves him at the
//     floor instead, and opens a short grace window so the REST of that salvo cannot
//     finish him either;
//   * the grace window is the difference between "punished" and "immune": the next
//     barrage (or a hit after the window) kills a player who stayed put.
static constexpr float GBlastMaxHitFraction = 0.35f;
static constexpr float GBlastFloorFraction  = 0.12f;
static float GBlastGraceUntil = -1000.f;
static TWeakObjectPtr<UWorld> GBlastGraceWorld;

float USquadAIExplosiveDamageLibrary::ApplyExplosiveDamageToPlayer(
	const UObject* WorldContextObject, FVector ImpactLocation, float BaseDamage,
	float InnerRadius, float OuterRadius, float MinDamageFraction,
	float PlayerDamageMultiplier, AActor* DamageCauser, bool bRequireLineOfSight)
{
	UWorld* World = BoomWorld(WorldContextObject);
	if (!World || BaseDamage <= 0.f || OuterRadius <= 0.f || PlayerDamageMultiplier <= 0.f)
	{
		return 0.f;
	}

	APawn* Player = UGameplayStatics::GetPlayerPawn(World, 0);
	if (!Player)
	{
		return 0.f;
	}

	const FVector PlayerCenter = Player->GetActorLocation();
	const float Dist = FVector::Dist(PlayerCenter, ImpactLocation);
	if (Dist > OuterRadius)
	{
		return 0.f;
	}

	// Falloff identical to ApplyRadialDamageWithFalloff's linear form.
	float Damage = BaseDamage;
	if (Dist > InnerRadius && OuterRadius > InnerRadius)
	{
		const float Alpha = (Dist - InnerRadius) / (OuterRadius - InnerRadius);
		Damage = FMath::Lerp(BaseDamage, BaseDamage * FMath::Clamp(MinDamageFraction, 0.f, 1.f), Alpha);
	}
	Damage *= PlayerDamageMultiplier;
	if (Damage <= 0.f)
	{
		return 0.f;
	}

	if (bRequireLineOfSight)
	{
		FCollisionQueryParams Params(SCENE_QUERY_STAT(S18BoomLOS), false);
		Params.AddIgnoredActor(Player);
		if (DamageCauser) Params.AddIgnoredActor(DamageCauser);
		FHitResult Blocker;
		// Aim at the chest so a kerb or duckboard does not shield the whole body.
		const FVector Target = PlayerCenter + FVector(0.f, 0.f, 40.f);
		if (World->LineTraceSingleByChannel(Blocker, ImpactLocation, Target, ECC_Visibility, Params))
		{
			// Something solid between the blast and the player: heavy cover.
			Damage *= 0.25f;
		}
	}

	// ---- S19-BLASTGUARD (artillery only) ----------------------------------
	// Scoped on purpose: the player's own grenade and exploding barrels keep their full
	// "you did that to yourself" lethality (that is the S18-BOOM feature), and allies keep
	// the designed risk of being downed by a salvo - SQUAD-REVIVE picks them back up. Only
	// the artillery that lands on the player unannounced is gated.
	const bool bIsArtillery = DamageCauser && DamageCauser->IsA<ATacticalMortarBarrageActor>();
	if (bIsArtillery)
	{
		const float Now = World->GetTimeSeconds();
		if (GBlastGraceWorld.Get() != World)
		{
			GBlastGraceWorld = World;
			GBlastGraceUntil = -1000.f;
		}

		float HP = 0.f, MaxHP = 100.f;
		const bool bReadHP = ReadPlayerHealthForBlast(Player, HP, MaxHP);

		if (bReadHP && HP > 0.f)
		{
			const float Floor = FMath::Max(MaxHP * GBlastFloorFraction, 5.f);

			// Still inside the window opened by the hit that nearly killed him.
			if (Now < GBlastGraceUntil)
			{
				UE_LOG(LogTemp, Warning, TEXT("[S19-BLASTGUARD] Artillery hit of %.1f ignored: grace window active (%.1fs left, hp %.1f/%.1f) — the player gets a chance to move"),
					Damage, GBlastGraceUntil - Now, HP, MaxHP);
				return 0.f;
			}

			// One hit may not remove most of a full health bar.
			const float PerHitCap = MaxHP * GBlastMaxHitFraction;
			if (Damage > PerHitCap)
			{
				UE_LOG(LogTemp, Warning, TEXT("[S19-BLASTGUARD] Artillery hit capped %.1f -> %.1f (%.0f%% of max health per shell)"),
					Damage, PerHitCap, GBlastMaxHitFraction * 100.f);
				Damage = PerHitCap;
			}

			// And it may not finish a player who was above the floor.
			if (HP > Floor && HP - Damage <= 0.f)
			{
				const float SurviveDamage = FMath::Max(0.f, HP - Floor);
				GBlastGraceUntil = Now + 2.5f;
				UE_LOG(LogTemp, Warning, TEXT("[S19-BLASTGUARD] This shell would have killed the player (%.1f dmg at %.1f hp) — left at %.1f hp instead, 2.5s grace so the salvo cannot finish him"),
					Damage, HP, HP - SurviveDamage);
				Damage = SurviveDamage;

				if (AQuestNativeHUD* GuardHUD = AQuestNativeHUD::Get(Player))
				{
					GuardHUD->ShowAlertBanner(
						AQuestNativeHUD::LocalizeHUDText(Player, TEXT("PlayerDeath"), TEXT("Pinned"),
							TEXT("توپخانه شما را زمین‌گیر کرد — پناه بگیرید!"),
							TEXT("Artillery pinned you — get to cover!")),
						FLinearColor(0.85f, 0.18f, 0.12f), 4.f);
				}
			}
		}
	}

	if (!ApplyDamageToPlayerPawn(Player, Damage, DamageCauser))
	{
		return 0.f;
	}

	// Screen feedback, matching what nearby AI soldiers already get.
	if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(Player))
	{
		HUD->AddPlayerSuppression(0.85f);
	}

	return Damage;
}

bool USquadAIExplosiveDamageLibrary::IsPlayerWithinBlastRadius(const UObject* WorldContextObject, FVector Center, float Radius)
{
	UWorld* World = BoomWorld(WorldContextObject);
	if (!World) return false;
	if (const APawn* Player = UGameplayStatics::GetPlayerPawn(World, 0))
	{
		return FVector::Dist(Player->GetActorLocation(), Center) <= Radius;
	}
	return false;
}

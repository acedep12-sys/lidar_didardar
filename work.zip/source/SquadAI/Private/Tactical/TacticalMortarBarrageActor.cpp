#include "Tactical/TacticalMortarBarrageActor.h"
#include "Performance/SquadAIAudioSubsystem.h"
#include "Performance/SquadAIFXManagerSubsystem.h"
#include "Actors/SquadAIAudioManager.h"
#include "Performance/SoldierRegistrySubsystem.h"
#include "Characters/SoldierCharacter.h"
#include "HUD/QuestNativeHUD.h"
#include "Kismet/GameplayStatics.h"
#include "Tactical/SquadAIExplosiveDamage.h" // S18-BOOM
#include "Engine/World.h"
#include "TimerManager.h"
#include "Perception/AISense_Hearing.h" // F-G13: explosion hearing stimuli.

ATacticalMortarBarrageActor::ATacticalMortarBarrageActor()
{
	PrimaryActorTick.bCanEverTick = false;
}

void ATacticalMortarBarrageActor::BeginPlay()
{
	Super::BeginPlay();
}

void ATacticalMortarBarrageActor::StartBarrage(const FVector& TargetLocation)
{
	TargetCenter = TargetLocation;
	ShellsFired = 0;

	UWorld* World = GetWorld();
	if (!World) return;

	UE_LOG(LogTemp, Warning, TEXT("[MortarBarrage] Inbound artillery barrage called on %s (%d shells)"), *TargetCenter.ToString(), ShellCount);

	// Register high-visibility warning danger zone on player HUD
	if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this))
	{
		const float TotalSalvoTime = InitialDelaySeconds + (ShellCount * ShellIntervalSeconds);
		HUD->RegisterIncomingMortarWarning(TargetCenter, ExplosionRadius + DispersionRadius, TotalSalvoTime, InitialDelaySeconds);
	}

	World->GetTimerManager().SetTimer(SalvoTimerHandle, this, &ATacticalMortarBarrageActor::DetonateSingleShell, ShellIntervalSeconds, true, InitialDelaySeconds);
}

void ATacticalMortarBarrageActor::DetonateSingleShell()
{
	UWorld* World = GetWorld();
	if (!World) return;

	ShellsFired++;

	// Calculate random dispersion impact point
	const float Angle = FMath::FRandRange(0.f, 2.f * PI);
	const float Dist = FMath::FRandRange(0.f, DispersionRadius);
	FVector ImpactLoc = TargetCenter + FVector(FMath::Cos(Angle) * Dist, FMath::Sin(Angle) * Dist, 10.f);

	// Snap to ground
	FHitResult Hit;
	FCollisionQueryParams Params;
	Params.AddIgnoredActor(this);
	if (World->LineTraceSingleByChannel(Hit, ImpactLoc + FVector(0.f, 0.f, 1500.f), ImpactLoc - FVector(0.f, 0.f, 3000.f), ECC_Visibility, Params))
	{
		ImpactLoc = Hit.ImpactPoint;
	}

	// 1. Spawn High-Caliber Niagara Explosion VFX
	if (USquadAIFXManagerSubsystem* FXSys = USquadAIFXManagerSubsystem::Get(this))
	{
		FXSys->SpawnExplosionFX(ImpactLoc, ExplosionRadius, true);
	}

	// 2. Radial High-Explosive Damage
	TArray<AActor*> IgnoreActors;
	IgnoreActors.Add(this);
	// S18-BOOM: the engine radial damage below cannot hurt the player (pack BP
	// health lives on a Blueprint component), so he stood in his own barrage
	// untouched. Ignore him here and damage him explicitly afterwards.
	APawn* BoomPlayer = UGameplayStatics::GetPlayerPawn(World, 0);
	if (BoomPlayer)
	{
		IgnoreActors.Add(BoomPlayer);
	}

	UAISense_Hearing::ReportNoiseEvent(World, ImpactLoc, 1.0f, nullptr, 7000.0, FName(TEXT("Explosion"))); // F-G13: blasts stimulate AI hearing (was: silent to AI).
	UGameplayStatics::ApplyRadialDamageWithFalloff(
		World,
		ShellDamage,
		ShellDamage * 0.3f,
		ImpactLoc,
		ExplosionRadius * 0.35f,
		ExplosionRadius,
		1.0f,
		UDamageType::StaticClass(),
		IgnoreActors,
		this,
		nullptr,
		ECC_Visibility
	);

	// S18-BOOM: friendly fire on the player, scaled by PlayerDamageMultiplier.
	const float PlayerHit = USquadAIExplosiveDamageLibrary::ApplyExplosiveDamageToPlayer(
		this, ImpactLoc, ShellDamage, ExplosionRadius * 0.35f, ExplosionRadius,
		0.3f, PlayerDamageMultiplier, this, true);
	if (PlayerHit > 0.f)
	{
		UE_LOG(LogTemp, Warning, TEXT("[S18-BOOM] Mortar shell hit the player for %.1f (DANGER CLOSE)."), PlayerHit);
	}

	// 3. Heavy Screen Suppression & Shockwave
	if (USoldierRegistrySubsystem* Reg = World->GetSubsystem<USoldierRegistrySubsystem>())
	{
		TArray<ASoldierCharacter*> Nearby = Reg->QueryRadius(ImpactLoc, ExplosionRadius * 1.5f);
		for (ASoldierCharacter* S : Nearby)
		{
			if (S && S->IsAlive())
			{
				if (APlayerController* PC = Cast<APlayerController>(S->GetController()))
				{
					if (AQuestNativeHUD* HUD = Cast<AQuestNativeHUD>(PC->GetHUD()))
					{
						HUD->AddPlayerSuppression(0.85f);
					}
				}
			}
		}
	}

	// 4. Audio Detonation
	USoundBase* Snd = DetonationSound;
	if (!Snd)
	{
		if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
		{
			if (ASquadAIAudioManager* Mgr = AudioSys->GetActiveAudioManager())
			{
				Snd = Mgr->LargeExplosionCloseSound.Get();
			}
		}
	}

	if (Snd)
	{
		UGameplayStatics::PlaySoundAtLocation(World, Snd, ImpactLoc, 1.4f);
	}

	if (ShellsFired >= ShellCount)
	{
		World->GetTimerManager().ClearTimer(SalvoTimerHandle);
		OnMortarBarrageFinished.Broadcast(this);
		Destroy();
	}
}

#include "Tactical/SquadAICommandSubsystem.h"
#include "Performance/SquadAIAudioSubsystem.h"
#include "Performance/SoldierRegistrySubsystem.h"
#include "Characters/SoldierCharacter.h"
#include "Characters/AllySoldier.h"
#include "AI/SoldierAIController.h"
#include "Actors/SquadAIAudioManager.h"
#include "Localization/SquadAILocalizationSubsystem.h"
#include "Engine/World.h"
#include "Engine/GameInstance.h"
#include "Kismet/GameplayStatics.h"

void USquadAICommandSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
	CurrentCommand = ETacticalSquadCommand::FollowLeader;
}

void USquadAICommandSubsystem::Deinitialize()
{
	Super::Deinitialize();
}

USquadAICommandSubsystem* USquadAICommandSubsystem::Get(const UObject* WorldContextObject)
{
	if (!WorldContextObject) return nullptr;
	UWorld* World = GEngine ? GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::ReturnNull) : nullptr;
	return World ? World->GetSubsystem<USquadAICommandSubsystem>() : nullptr;
}

void USquadAICommandSubsystem::IssueSquadCommand(ETacticalSquadCommand Command, FVector TargetLocation)
{
	CurrentCommand = Command;
	CurrentCommandTarget = TargetLocation;

	UWorld* World = GetWorld();
	if (!World) return;

	// Notify all active ally soldiers and adjust their AI state
	if (USoldierRegistrySubsystem* Reg = World->GetSubsystem<USoldierRegistrySubsystem>())
	{
		for (const TWeakObjectPtr<ASoldierCharacter>& WeakSoldier : Reg->GetAllSoldiers())
		{
			ASoldierCharacter* Soldier = WeakSoldier.Get();
			if (!Soldier || !Soldier->IsAlive() || !Soldier->IsAlly()) continue;

			if (ASoldierAIController* AIC = Cast<ASoldierAIController>(Soldier->GetController()))
			{
				switch (Command)
				{
				case ETacticalSquadCommand::HoldCover:
					AIC->RequestCover(TargetLocation.IsNearlyZero() ? Soldier->GetActorLocation() : TargetLocation);
					break;

				case ETacticalSquadCommand::SuppressSector:
					if (!TargetLocation.IsNearlyZero())
					{
						AIC->SetCombatAimTarget(TargetLocation, ESquadAIAimMode::InvestigateLocation, nullptr);
						AIC->TryStartBurstAtCurrentAim();
					}
					break;

				case ETacticalSquadCommand::RegroupOnPlayer:
					if (APawn* Player = UGameplayStatics::GetPlayerPawn(World, 0))
					{
						AIC->MoveToActor(Player, 250.f);
					}
					break;

				case ETacticalSquadCommand::Assault:
				case ETacticalSquadCommand::FollowLeader:
				default:
					break;
				}
			}
		}
	}

	// Trigger Leader voice confirmation
	if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
	{
		if (Command == ETacticalSquadCommand::SuppressSector || Command == ETacticalSquadCommand::Assault)
		{
			AudioSys->PlayTacticalVoiceline(ETacticalVoicelineType::Leader_OrderEngage);
		}
		else
		{
			AudioSys->PlayTacticalVoiceline(ETacticalVoicelineType::Leader_OrderMove);
		}
	}

	OnCommandExecuted.Broadcast(Command, TargetLocation);
	UE_LOG(LogTemp, Warning, TEXT("[SquadCommand] Issued squad command: %s at %s"), *GetCommandDisplayName(Command), *TargetLocation.ToString());
}

FString USquadAICommandSubsystem::GetCommandDisplayName(ETacticalSquadCommand Command) const
{
	bool bEnglish = false;
	if (UWorld* World = GetWorld())
	{
		if (UGameInstance* GI = World->GetGameInstance())
		{
			if (const USquadAILocalizationSubsystem* Loc = GI->GetSubsystem<USquadAILocalizationSubsystem>())
			{
				bEnglish = Loc->GetCurrentLanguage().StartsWith(TEXT("en"), ESearchCase::IgnoreCase);
			}
		}
	}

	switch (Command)
	{
	case ETacticalSquadCommand::HoldCover:
		return bEnglish ? TEXT("Hold Cover") : TEXT("سنگرگیری و دفاع (HOLD COVER)");
	case ETacticalSquadCommand::SuppressSector:
		return bEnglish ? TEXT("Suppress Sector") : TEXT("آتش سرکوبگر سنگین (SUPPRESS)");
	case ETacticalSquadCommand::RegroupOnPlayer:
		return bEnglish ? TEXT("Regroup on Player") : TEXT("تجمع مجدد نیروها (REGROUP)");
	case ETacticalSquadCommand::Assault:
		return bEnglish ? TEXT("Assault") : TEXT("حمله و تک سراسری (ASSAULT)");
	case ETacticalSquadCommand::FollowLeader:
	default:
		return bEnglish ? TEXT("Follow Major Rostami") : TEXT("پیشروی با سرگرد رستمی (FOLLOW)");
	}
}

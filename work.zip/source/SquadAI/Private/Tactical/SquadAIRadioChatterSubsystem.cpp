#include "Tactical/SquadAIRadioChatterSubsystem.h"
#include "Performance/SquadAIAudioSubsystem.h"
#include "Actors/SquadAIAudioManager.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/World.h"
#include "Engine/Engine.h"
#include "Localization/SquadAILocalizationSubsystem.h"

void USquadAIRadioChatterSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
	UE_LOG(LogTemp, Log, TEXT("[SquadAIRadioChatterSubsystem] Tactical Radio Comms Subsystem Initialized"));
}

void USquadAIRadioChatterSubsystem::Deinitialize()
{
	Super::Deinitialize();
}

USquadAIRadioChatterSubsystem* USquadAIRadioChatterSubsystem::Get(const UObject* WorldContextObject)
{
	if (!WorldContextObject) return nullptr;
	UWorld* World = GEngine ? GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::ReturnNull) : nullptr;
	return World ? World->GetSubsystem<USquadAIRadioChatterSubsystem>() : nullptr;
}

void USquadAIRadioChatterSubsystem::TickRadio(float DeltaTime)
{
	if (MessageDisplayTimeRemaining > 0.0f)
	{
		MessageDisplayTimeRemaining -= DeltaTime;
	}
}

void USquadAIRadioChatterSubsystem::BroadcastRadioChatter(const FString& CallSign, ETacticalRadioContext Context)
{
	if (!bEnableRadioChatter || !GetWorld()) return;

	const float CurrentTime = GetWorld()->GetTimeSeconds();
	if (CurrentTime - LastTransmissionTime < MinChatterIntervalSeconds) return;

	LastTransmissionTime = CurrentTime;
	const bool bEnglishRadio = USquadAILocalizationSubsystem::Get(this)
		&& USquadAILocalizationSubsystem::Get(this)->GetCurrentLanguage().StartsWith(TEXT("en"), ESearchCase::IgnoreCase);
	LastCallSign = CallSign.IsEmpty()
		? (bEnglishRadio ? TEXT("Command / Major Rostami") : TEXT("فرماندهی / سرگرد رستمی"))
		: CallSign;
	if (bEnglishRadio)
	{
		if (LastCallSign.Contains(TEXT("رستمی"), ESearchCase::IgnoreCase) || LastCallSign.Contains(TEXT("ایرج"), ESearchCase::IgnoreCase))
		{
			LastCallSign = TEXT("Command / Major Rostami");
		}
		else if (LastCallSign.Contains(TEXT("رزمنده"), ESearchCase::IgnoreCase))
		{
			LastCallSign = TEXT("Squad Fighter");
		}
	}

	switch (Context)
	{
	case ETacticalRadioContext::SpotHostile:
		LastMessageFarsi = TEXT("دشمن در تیررس! سنگر بگیرید!");
		LastMessageEnglish = TEXT("Hostiles in sight! Take cover!");
		break;
	case ETacticalRadioContext::SuppressingFire:
		LastMessageFarsi = TEXT("آتش پوششی باز شد! سرکوبشون کنید!");
		LastMessageEnglish = TEXT("Laying down suppressing fire! Keep them pinned!");
		break;
	case ETacticalRadioContext::FlankingManeuver:
		LastMessageFarsi = TEXT("از جناح دور می‌زنیم، پوشش بدید!");
		LastMessageEnglish = TEXT("Flanking around their position! Cover us!");
		break;
	case ETacticalRadioContext::TargetNeutralized:
		LastMessageFarsi = TEXT("هدف خنثی شد! موقعیت تثبیت شد!");
		LastMessageEnglish = TEXT("Target eliminated! Sector secure!");
		break;
	case ETacticalRadioContext::HeavyMGActive:
		LastMessageFarsi = TEXT("تیربار سنگین مستقر شد! آتش باز!");
		LastMessageEnglish = TEXT("Heavy machine gun operational! Laying fire!");
		break;
	case ETacticalRadioContext::FirstAidApplied:
		LastMessageFarsi = TEXT("درمان انجام شد! آماده پیشروی!");
		LastMessageEnglish = TEXT("First aid applied! Ready to advance!");
		break;
	case ETacticalRadioContext::MortarInbound:
		LastMessageFarsi = TEXT("آتش خمپاره در راهه! سرها پایین!");
		LastMessageEnglish = TEXT("Mortar salvo inbound! Keep heads down!");
		break;
	case ETacticalRadioContext::ObjectiveSecured:
		LastMessageFarsi = TEXT("منطقه پاکسازی شد! مأموریت انجام شد!");
		LastMessageEnglish = TEXT("Zone cleared! Objective completed!");
		break;
	}

	MessageDisplayTimeRemaining = 3.5f;

	// Radio squelch / click sound
	if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
	{
		if (ASquadAIAudioManager* Mgr = AudioSys->GetActiveAudioManager())
		{
			if (Mgr->TacticalRadioClick)
			{
				UGameplayStatics::PlaySound2D(GetWorld(), Mgr->TacticalRadioClick.Get(), 0.9f);
			}
		}
	}

	OnRadioTransmission.Broadcast(LastCallSign, LastMessageFarsi, LastMessageEnglish, Context);

	UE_LOG(LogTemp, Log, TEXT("[RadioComms] [%s]: %s (%s)"), *LastCallSign, *LastMessageFarsi, *LastMessageEnglish);
}

void USquadAIRadioChatterSubsystem::BroadcastStoryTransmission(const FString& MessageEnglish, const FString& MessageFarsi)
{
	if (!bEnableRadioChatter || !GetWorld()) return;
	if (MessageEnglish.IsEmpty() && MessageFarsi.IsEmpty()) return;

	const float CurrentTime = GetWorld()->GetTimeSeconds();
	LastTransmissionTime = CurrentTime;   // the story preempts the chatter cadence

	const bool bEnglishRadio = USquadAILocalizationSubsystem::Get(this)
		&& USquadAILocalizationSubsystem::Get(this)->GetCurrentLanguage().StartsWith(TEXT("en"), ESearchCase::IgnoreCase);
	LastCallSign = bEnglishRadio ? TEXT("Command / Major Rostami") : TEXT("فرماندهی / سرگرد رستمی");

	LastMessageEnglish = MessageEnglish.IsEmpty() ? MessageFarsi : MessageEnglish;
	LastMessageFarsi = MessageFarsi.IsEmpty() ? MessageEnglish : MessageFarsi;
	MessageDisplayTimeRemaining = 4.5f;   // a story line holds a beat longer than chatter

	if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
	{
		if (ASquadAIAudioManager* Mgr = AudioSys->GetActiveAudioManager())
		{
			if (Mgr->TacticalRadioClick)
			{
				UGameplayStatics::PlaySound2D(GetWorld(), Mgr->TacticalRadioClick.Get(), 0.9f);
			}
		}
	}

	OnRadioTransmission.Broadcast(LastCallSign, LastMessageFarsi, LastMessageEnglish, ETacticalRadioContext::StoryBeat);

	UE_LOG(LogTemp, Log, TEXT("[RadioComms] [STORY] [%s]: %s (%s)"), *LastCallSign, *LastMessageFarsi, *LastMessageEnglish);
}

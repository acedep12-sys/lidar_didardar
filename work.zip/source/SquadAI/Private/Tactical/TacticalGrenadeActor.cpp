#include "Tactical/TacticalGrenadeActor.h"
#include "EngineUtils.h"                      // S19-EXFIL: find extraction pads
#include "Quest/ExtractionZoneActor.h"
#include "Tactical/SquadAIAlarmSubsystem.h" // S19-ALARM         // S19-EXFIL
#include "Components/SphereComponent.h"
#include "Components/StaticMeshComponent.h"
#include "GameFramework/ProjectileMovementComponent.h"
#include "Performance/SoldierRegistrySubsystem.h"
#include "Performance/SquadAIAudioSubsystem.h"
#include "Performance/SquadAIFXManagerSubsystem.h"
#include "Actors/SquadAIAudioManager.h"
#include "Characters/SoldierCharacter.h"
#include "HUD/QuestNativeHUD.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Kismet/GameplayStatics.h"
#include "Tactical/SquadAIExplosiveDamage.h" // S18-BOOM
#include "Engine/World.h"
#include "TimerManager.h"
#include "Perception/AISense_Hearing.h" // F-G13: explosion hearing stimuli.

ATacticalGrenadeActor::ATacticalGrenadeActor()
{
	PrimaryActorTick.bCanEverTick = false;

	CollisionComp = CreateDefaultSubobject<USphereComponent>(TEXT("CollisionComp"));
	CollisionComp->InitSphereRadius(8.0f);
	CollisionComp->SetCollisionProfileName(TEXT("PhysicsActor"));
	CollisionComp->SetWalkableSlopeOverride(FWalkableSlopeOverride(WalkableSlope_Unwalkable, 0.f));
	CollisionComp->CanCharacterStepUpOn = ECB_No;
	SetRootComponent(CollisionComp);

	GrenadeMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("GrenadeMesh"));
	GrenadeMesh->SetupAttachment(CollisionComp);
	GrenadeMesh->SetCollisionProfileName(TEXT("NoCollision"));

	// Load mesh - cylinder / sphere with tactical proportions
	UStaticMesh* Mesh = LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cylinder.Cylinder"));
	if (!Mesh)
	{
		Mesh = LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Sphere.Sphere"));
	}
	if (Mesh)
	{
		GrenadeMesh->SetStaticMesh(Mesh);
		GrenadeMesh->SetRelativeScale3D(FVector(0.09f, 0.09f, 0.16f));
	}

	ProjectileMovement = CreateDefaultSubobject<UProjectileMovementComponent>(TEXT("ProjectileMovement"));
	ProjectileMovement->UpdatedComponent = CollisionComp;
	ProjectileMovement->InitialSpeed = 1600.f;
	ProjectileMovement->MaxSpeed = 2500.f;
	ProjectileMovement->bRotationFollowsVelocity = true;
	ProjectileMovement->bShouldBounce = true;
	ProjectileMovement->Bounciness = 0.42f;
	ProjectileMovement->Friction = 0.55f;
	ProjectileMovement->BounceVelocityStopSimulatingThreshold = 80.f;
}

void ATacticalGrenadeActor::BeginPlay()
{
	Super::BeginPlay();

	// Apply dark olive military paint material with metallic finish to grenade body
	if (GrenadeMesh)
	{
		UMaterialInterface* BaseMat = GrenadeMesh->GetMaterial(0);
		if (!BaseMat)
		{
			BaseMat = LoadObject<UMaterialInterface>(nullptr, TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"));
		}
		if (!BaseMat)
		{
			BaseMat = LoadObject<UMaterialInterface>(nullptr, TEXT("/Engine/EngineMaterials/DefaultMaterial.DefaultMaterial"));
		}
		if (BaseMat)
		{
			UMaterialInstanceDynamic* DynMat = UMaterialInstanceDynamic::Create(BaseMat, this);
			if (DynMat)
			{
				const FLinearColor OliveGreen(0.12f, 0.16f, 0.10f, 1.0f);
				DynMat->SetVectorParameterValue(TEXT("Color"), OliveGreen);
				DynMat->SetVectorParameterValue(TEXT("BaseColor"), OliveGreen);
				DynMat->SetVectorParameterValue(TEXT("Tint"), OliveGreen);
				DynMat->SetScalarParameterValue(TEXT("Roughness"), 0.35f);
				DynMat->SetScalarParameterValue(TEXT("Metallic"), 0.85f);
				GrenadeMesh->SetMaterial(0, DynMat);
			}
		}
	}

	CollisionComp->OnComponentHit.AddDynamic(this, &ATacticalGrenadeActor::OnHit);

	if (GetWorld())
	{
		GetWorld()->GetTimerManager().SetTimer(FuseTimerHandle, this, &ATacticalGrenadeActor::Detonate, FuseTime, false);
	}
}

void ATacticalGrenadeActor::LaunchGrenade(const FVector& LaunchVelocity, AActor* InInstigator)
{
	GrenadeInstigator = InInstigator;
	if (InInstigator && CollisionComp)
	{
		CollisionComp->IgnoreActorWhenMoving(InInstigator, true);
	}
	if (ProjectileMovement)
	{
		ProjectileMovement->Velocity = LaunchVelocity;
	}
}

void ATacticalGrenadeActor::OnHit(UPrimitiveComponent* HitComponent, AActor* OtherActor,
	UPrimitiveComponent* OtherComp, FVector NormalImpulse, const FHitResult& Hit)
{
	if (BounceSound && NormalImpulse.Size() > 200.f)
	{
		UGameplayStatics::PlaySoundAtLocation(GetWorld(), BounceSound, Hit.ImpactPoint, 0.6f);
	}
}

void ATacticalGrenadeActor::Detonate()
{
	if (bHasDetonated) return;
	bHasDetonated = true;

	if (GrenadeType == EGrenadeType::Fragmentation)
	{
		ExplodeFrag();
		// S19-ALARM: a frag detonation raises the world alarm IF a hostile is in
		// earshot (25 m) - an explosion nobody hears is nobody's business.
		if (USquadAIAlarmSubsystem* AlarmSys = USquadAIAlarmSubsystem::Get(this))
		{
			AlarmSys->RaiseEvent(EMissionAlarmEvent::Explosion, GetActorLocation(), 2500.f);
		}
	}
	else
	{
		DeploySmokeScreen();
		// S19-EXFIL: a smoke marker ON an extraction pad is how the player CALLS the
		// exfil. Only smoke looks for pads, and each pad decides whether the marker
		// landed close enough - there is nothing to configure here.
		if (UWorld* SmokeWorld = GetWorld())
		{
			for (TActorIterator<AExtractionZoneActor> It(SmokeWorld); It; ++It)
			{
				if (AExtractionZoneActor* Pad = *It)
				{
					Pad->NotifySmokeMarker(GetActorLocation());
				}
			}
		}
	}

	OnGrenadeDetonated.Broadcast(this, GrenadeType);
}

void ATacticalGrenadeActor::ExplodeFrag()
{
	UWorld* World = GetWorld();
	if (!World) return;

	const FVector BlastLoc = GetActorLocation();

	// 1. Spawn High-Impact Niagara / Cascade Explosion VFX
	if (USquadAIFXManagerSubsystem* FXSys = USquadAIFXManagerSubsystem::Get(this))
	{
		FXSys->SpawnExplosionFX(BlastLoc, BlastRadius, true);
	}

	// 2. Radial Impulse to rigid bodies and ragdolls
	TArray<FHitResult> OverlapHits;
	FCollisionShape SphereShape = FCollisionShape::MakeSphere(BlastRadius);
	if (World->SweepMultiByChannel(OverlapHits, BlastLoc, BlastLoc, FQuat::Identity, ECC_WorldDynamic, SphereShape))
	{
		for (const FHitResult& H : OverlapHits)
		{
			if (UPrimitiveComponent* Prim = H.GetComponent())
			{
				if (Prim->IsSimulatingPhysics())
				{
					// S14-STAB: downed-but-ALIVE soldiers are ragdolled — the full
					// radial impulse launched injured allies into the sky (they
					// must stay revivable where they fell). Corpses may still fly.
					if (const ASoldierCharacter* Sol = Cast<ASoldierCharacter>(Prim->GetOwner()))
					{
						if (Sol->bIsDowned && Sol->IsAlive())
						{
							continue;
						}
					}
					Prim->AddRadialImpulse(BlastLoc, BlastRadius, ExplosionImpulse, ERadialImpulseFalloff::RIF_Linear, true);
				}
			}
		}
	}

	// 2. Radial Lethal Damage
	TArray<AActor*> IgnoreActors;
	IgnoreActors.Add(this);
	if (GrenadeInstigator.IsValid())
	{
		IgnoreActors.Add(GrenadeInstigator.Get());
	}
	// S18-BOOM: engine radial damage never reaches the pack-BP player.
	APawn* BoomPlayer = UGameplayStatics::GetPlayerPawn(World, 0);
	const bool bPlayerThrewIt = BoomPlayer && GrenadeInstigator.Get() == BoomPlayer;
	if (BoomPlayer)
	{
		IgnoreActors.AddUnique(BoomPlayer);
	}

	UAISense_Hearing::ReportNoiseEvent(World, BlastLoc, 1.0f, nullptr, 4500.0, FName(TEXT("Explosion"))); // F-G13: blasts stimulate AI hearing (was: silent to AI).
	UGameplayStatics::ApplyRadialDamageWithFalloff(
		World,
		ExplosionDamage,
		ExplosionDamage * 0.2f,
		BlastLoc,
		BlastRadius * 0.35f,
		BlastRadius,
		1.0f,
		UDamageType::StaticClass(),
		IgnoreActors,
		this,
		GrenadeInstigator.IsValid() ? Cast<APawn>(GrenadeInstigator.Get())->GetController() : nullptr,
		ECC_Visibility
	);

	// S18-BOOM: your own grenade can hurt you too (same multiplier).
	const float PlayerHit = USquadAIExplosiveDamageLibrary::ApplyExplosiveDamageToPlayer(
		this, BlastLoc, ExplosionDamage, BlastRadius * 0.35f, BlastRadius,
		0.2f, PlayerDamageMultiplier, this, true);
	if (PlayerHit > 0.f)
	{
		UE_LOG(LogTemp, Warning, TEXT("[S18-BOOM] Grenade caught the player for %.1f (own throw=%d)."), PlayerHit, bPlayerThrewIt ? 1 : 0);
	}

	// 3. Heavy Concussive Suppression on Survivors
	if (USoldierRegistrySubsystem* Reg = World->GetSubsystem<USoldierRegistrySubsystem>())
	{
		TArray<ASoldierCharacter*> Nearby = Reg->QueryRadius(BlastLoc, SuppressionRadius);
		for (ASoldierCharacter* S : Nearby)
		{
			if (S && S->IsAlive())
			{
				const float Dist = FVector::Dist(BlastLoc, S->GetActorLocation());
				const float SuppressAmount = FMath::Clamp(1.0f - (Dist / SuppressionRadius), 0.4f, 1.0f);
				if (APlayerController* PC = Cast<APlayerController>(S->GetController()))
				{
					if (AQuestNativeHUD* HUD = Cast<AQuestNativeHUD>(PC->GetHUD()))
					{
						HUD->AddPlayerSuppression(SuppressAmount);
					}
				}
			}
		}
	}

	// 4. Audio & Haptics
	USoundBase* Snd = DetonationSound;
	if (!Snd)
	{
		if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
		{
			if (ASquadAIAudioManager* Mgr = AudioSys->GetActiveAudioManager())
			{
				Snd = Mgr->MediumExplosionCloseSound.Get();
			}
		}
	}

	if (Snd)
	{
		UGameplayStatics::PlaySoundAtLocation(World, Snd, BlastLoc, 1.15f);
	}

	Destroy();
}

void ATacticalGrenadeActor::DeploySmokeScreen()
{
	UWorld* World = GetWorld();
	if (!World) return;

	const FVector SmokeLoc = GetActorLocation();

	// Register smoke cloud in registry subsystem to block AI sight traces
	if (USoldierRegistrySubsystem* Reg = World->GetSubsystem<USoldierRegistrySubsystem>())
	{
		Reg->RegisterSmokeCloud(SmokeLoc, BlastRadius * 1.25f, SmokeDuration);
	}

	// Play hissing smoke deployment sound
	USoundBase* Snd = DetonationSound;
	if (Snd)
	{
		UGameplayStatics::PlaySoundAtLocation(World, Snd, SmokeLoc, 1.0f);
	}

	// Hide grenade body but linger for smoke duration
	SetActorHiddenInGame(true);
	SetActorEnableCollision(false);
	if (ProjectileMovement) ProjectileMovement->StopMovementImmediately();

	SetLifeSpan(SmokeDuration + 1.0f);
}

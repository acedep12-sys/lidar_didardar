#include "Tactical/SquadAIMortarPressureSubsystem.h"
#include "Tactical/TacticalMortarBarrageActor.h"
#include "Tactical/SquadAIRadioChatterSubsystem.h"
#include "Performance/DifficultySubsystem.h"
#include "Characters/SoldierCharacter.h"
#include "Engine/World.h"
#include "TimerManager.h"
#include "GameFramework/PlayerController.h"
#include "GameFramework/Pawn.h"
#include "GameFramework/Character.h"

void USquadAIMortarPressureSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
	// 0.5s cadence state machine. FTimerManager runs on game time, so the whole
	// scheduler freezes correctly while the game is paused.
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().SetTimer(SchedulerTimerHandle, this, &USquadAIMortarPressureSubsystem::EvaluateScheduler, 0.5f, true, 0.5f);
	}
}

void USquadAIMortarPressureSubsystem::Deinitialize()
{
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(SchedulerTimerHandle);
	}
	Super::Deinitialize();
}

USquadAIMortarPressureSubsystem* USquadAIMortarPressureSubsystem::Get(const UObject* WorldContextObject)
{
	if (!WorldContextObject) return nullptr;
	UWorld* World = GEngine ? GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::ReturnNull) : nullptr;
	return World ? World->GetSubsystem<USquadAIMortarPressureSubsystem>() : nullptr;
}

// S19-PIEMENUGATE: artillery pressure is gameplay-only; never acquire the menu's
// generic DefaultPawn or shell a menu camera/player while PIE is idle.
APawn* USquadAIMortarPressureSubsystem::FindLocalPlayerPawn() const
{
	const UWorld* World = GetWorld();
	if (!World) return nullptr;

	const FString MapName = World->GetMapName();
	if (MapName.Contains(TEXT("MainMenu"), ESearchCase::IgnoreCase))
	{
		return nullptr;
	}

	APlayerController* PC = World->GetFirstPlayerController();
	APawn* Pawn = PC ? PC->GetPawn() : nullptr;
	// ADefaultPawn / ASpectatorPawn are not combatants. The gameplay player is a
	// character; this also preserves external ACharacter-based pack player BPs.
	if (!Pawn || !Cast<ACharacter>(Pawn)) return nullptr;

	// Dead SquadAI soldiers don't get shelled — the loop resumes for the respawned pawn.
	if (const ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(Pawn))
	{
		if (!Soldier->IsAlive()) return nullptr;
	}
	return Pawn;
}

float USquadAIMortarPressureSubsystem::GetRestSecondsForCurrentDifficulty() const
{
	EGameDifficulty Diff = EGameDifficulty::Normal;
	if (const UDifficultySubsystem* DiffSys = UDifficultySubsystem::Get(this))
	{
		Diff = DiffSys->GetCurrentDifficulty();
	}
	switch (Diff)
	{
	case EGameDifficulty::Easy:		return RestSecondsEasy;		// owner spec: 15s cadence IS the easy setting
	case EGameDifficulty::Normal:	return RestSecondsNormal;
	case EGameDifficulty::Hard:		return RestSecondsHard;
	case EGameDifficulty::Lethal:	return RestSecondsLethal;
	default:						return RestSecondsNormal;
	}
}

float USquadAIMortarPressureSubsystem::GetTimeUntilNextVolley() const
{
	const UWorld* World = GetWorld();
	if (!World || !bEnabled || NextVolleyTimeSeconds < 0.0f) return 0.0f;
	return FMath::Max(0.0f, NextVolleyTimeSeconds - World->GetTimeSeconds());
}

void USquadAIMortarPressureSubsystem::EvaluateScheduler()
{
	UWorld* World = GetWorld();
	if (!World) return;

	if (!bEnabled)
	{
		if (!bLoggedDormant)
		{
			bLoggedDormant = true;
			UE_LOG(LogTemp, Log, TEXT("[MortarPressure] Dormant (bEnabled=false)."));
		}
		return;
	}

	APawn* PlayerPawn = FindLocalPlayerPawn();
	if (!PlayerPawn)
	{
		// No living pawn (main-menu world, dead, or seamless travel): hold position —
		// timers are absolute game-time, so the cycle simply waits for a valid pawn.
		return;
	}

	const float Now = World->GetTimeSeconds();

	if (!bPlayerSeenOnce)
	{
		bPlayerSeenOnce = true;
		NextVolleyTimeSeconds = Now + EntryGraceSeconds;
		UE_LOG(LogTemp, Log, TEXT("[MortarPressure] Player acquired — first volley in %.1fs."), EntryGraceSeconds);
		return;
	}

	if (NextVolleyTimeSeconds < 0.0f)
	{
		NextVolleyTimeSeconds = Now + GetRestSecondsForCurrentDifficulty();
		return;
	}

	if (Now < NextVolleyTimeSeconds || Now < VolleyBusyUntilSeconds)
	{
		return;
	}

	FireVolleyAtPlayer();

	// Next cycle = volley duration + difficulty-scaled rest (rest shrinks on higher
	// difficulty per owner spec).
	const float VolleyTotal = VolleyInitialDelaySeconds + (ShellsPerVolley * ShellIntervalSeconds);
	VolleyBusyUntilSeconds = Now + VolleyTotal;
	NextVolleyTimeSeconds = Now + VolleyTotal + GetRestSecondsForCurrentDifficulty();
}

void USquadAIMortarPressureSubsystem::FireVolleyAtPlayer()
{
	UWorld* World = GetWorld();
	APawn* PlayerPawn = FindLocalPlayerPawn();
	if (!World || !PlayerPawn) return;

	// Anchor the barrage on the player's CURRENT position; the fixed center + the HUD
	// warning window is what makes "run and avoid" possible (owner spec).
	const FVector Target = PlayerPawn->GetActorLocation();

	FActorSpawnParameters SpawnParams;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	ATacticalMortarBarrageActor* Barrage = World->SpawnActor<ATacticalMortarBarrageActor>(ATacticalMortarBarrageActor::StaticClass(), Target, FRotator::ZeroRotator, SpawnParams);
	if (!Barrage) return;

	Barrage->ShellCount = ShellsPerVolley;
	Barrage->ShellIntervalSeconds = ShellIntervalSeconds;			// owner spec: 0.1s between shells
	Barrage->InitialDelaySeconds = VolleyInitialDelaySeconds;		// warning window before impacts
	Barrage->DispersionRadius = DispersionRadiusCm;
	Barrage->ShellDamage = ShellDamage;
	Barrage->ExplosionRadius = ExplosionRadiusCm;
	Barrage->StartBarrage(Target);

	// Immersion tie-in: reuse the radio chatter system for the "artillery inbound"
	// callout when it is available (safe no-op otherwise). دیده‌بان = spotter.
	if (USquadAIRadioChatterSubsystem* Radio = USquadAIRadioChatterSubsystem::Get(this))
	{
		Radio->BroadcastRadioChatter(TEXT("دیده‌بان"), ETacticalRadioContext::MortarInbound);
	}

	UE_LOG(LogTemp, Log, TEXT("[MortarPressure] Volley inbound on player position (%d shells @ %.2fs)."), ShellsPerVolley, ShellIntervalSeconds);
}

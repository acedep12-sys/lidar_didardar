// SquadAIAlarmSubsystem.cpp - S19-ALARM: the state holder; the rules are in AlarmModel.h.

#include "Tactical/SquadAIAlarmSubsystem.h"

#include "Characters/SoldierCharacter.h"
#include "Engine/World.h"
#include "GameFramework/Pawn.h"
#include "TimerManager.h"
#include "EngineUtils.h"

void USquadAIAlarmSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);

	if (UWorld* World = GetWorld())
	{
		if (World->IsGameWorld())
		{
			World->GetTimerManager().SetTimer(AlarmTickTimerHandle, this,
				&USquadAIAlarmSubsystem::TickAlarm, 0.1f, true);
		}
	}
}

void USquadAIAlarmSubsystem::Deinitialize()
{
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(AlarmTickTimerHandle);
	}
	Super::Deinitialize();
}

USquadAIAlarmSubsystem* USquadAIAlarmSubsystem::Get(const UObject* WorldContextObject)
{
	if (!WorldContextObject) return nullptr;
	UWorld* World = GEngine ? GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::ReturnNull) : nullptr;
	return World ? World->GetSubsystem<USquadAIAlarmSubsystem>() : nullptr;
}

const TCHAR* USquadAIAlarmSubsystem::LevelName(EAlarmLevel L)
{
	switch (L)
	{
	case EAlarmLevel::Suspicious: return TEXT("Suspicious");
	case EAlarmLevel::Searching:  return TEXT("Searching");
	case EAlarmLevel::FullAlarm:  return TEXT("Full alarm");
	default:                      return TEXT("Calm");
	}
}

void USquadAIAlarmSubsystem::RaiseEvent(EMissionAlarmEvent Event, const FVector& Location,
	float WitnessRadiusCm)
{
	const int32 EventIndex = static_cast<int32>(Event);
	if (EventIndex < 0 || EventIndex >= 5)
	{
		return;
	}

	// -- the witness test -------------------------------------------------------
	// An event with a radius only counts when a hostile soldier is alive inside it.
	// (Radius-only on purpose: line-of-sight checks per event would cost more than
	// the feature is worth, and sound ignores sight anyway.)
	if (WitnessRadiusCm > 0.f)
	{
		const float RadiusSq = WitnessRadiusCm * WitnessRadiusCm;
		bool bWitnessed = false;
		for (TActorIterator<APawn> It(GetWorld()); It; ++It)
		{
			const ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(*It);
			if (!Soldier || !Soldier->IsAlive() || Soldier->IsAlly())
			{
				continue;   // only a hostile of the player can witness
			}
			if (FVector::DistSquared(It->GetActorLocation(), Location) <= RadiusSq)
			{
				bWitnessed = true;
				break;
			}
		}
		if (!bWitnessed)
		{
			return;
		}
	}

	// -- the per-event cooldown ---------------------------------------------------
	const UWorld* World = GetWorld();
	const float Now = World ? World->GetTimeSeconds() : 0.f;
	if (Now - LastRaiseSeconds[EventIndex] < FAlarmModel::CooldownSecondsFor(Event))
	{
		return;
	}
	LastRaiseSeconds[EventIndex] = Now;

	SetValue(Value + FAlarmModel::RaiseAmountFor(Event));
}

void USquadAIAlarmSubsystem::SetValue(float NewValue)
{
	const float Old = Value;
	Value = FAlarmModel::ClampValue(NewValue);
	if (Value == Old)
	{
		return;
	}

	const EAlarmLevel OldLevel = FAlarmModel::LevelForValue(Old);
	const EAlarmLevel NewLevel = FAlarmModel::LevelForValue(Value);
	if (OldLevel != NewLevel)
	{
		UE_LOG(LogTemp, Warning, TEXT("[SquadAIAlarm] %s -> %s (%.0f)"),
			LevelName(OldLevel), LevelName(NewLevel), Value);
		OnAlarmLevelChanged.Broadcast(NewLevel, OldLevel);
	}
}

void USquadAIAlarmSubsystem::TickAlarm()
{
	SetValue(FAlarmModel::ApplyDecay(Value, 0.1f));
}

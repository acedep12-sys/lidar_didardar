// SquadAIInventorySubsystem.cpp — Tactical Military Backpack & Inventory Manager
#include "GameFramework/SquadAIInventorySubsystem.h"
#include "GameFramework/SquadAIProgressionSubsystem.h"
#include "Utilities/SquadAIAssetHelper.h"
#include "Localization/SquadAILocalizationSubsystem.h"
#include "Characters/SoldierCharacter.h"
#include "Components/WeaponComponent.h"
#include "Components/TacticalGrenadeComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/World.h"
#include "UObject/UnrealType.h"

void USquadAIInventorySubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
	PopulateDefaultArsenal();
	ReloadNotesFromLocalization();
	ReloadRadioStations();
	ReloadQuranVerses();
	SelectedWeaponIndex = 0;
	if (const USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(this))
	{
		SelectWeaponByID(Prog->GetEquippedWeaponID());
	}
	CurrentNoteIndex = 0;
	CurrentStationIndex = 0;
	CurrentQuranIndex = 0;
	bRadioIsPlaying = true;
	UE_LOG(LogTemp, Log, TEXT("[SquadAIInventory] Tactical Backpack Subsystem Initialized."));
}

void USquadAIInventorySubsystem::Deinitialize()
{
	Weapons.Empty();
	FallenNotes.Empty();
	RadioStations.Empty();
	QuranVerses.Empty();
	Super::Deinitialize();
}

USquadAIInventorySubsystem* USquadAIInventorySubsystem::Get(const UObject* WorldContextObject)
{
	if (!WorldContextObject) return nullptr;
	UGameInstance* GI = UGameplayStatics::GetGameInstance(WorldContextObject);
	return GI ? GI->GetSubsystem<USquadAIInventorySubsystem>() : nullptr;
}

void USquadAIInventorySubsystem::PopulateDefaultArsenal()
{
	Weapons.Empty();

	USquadAILocalizationSubsystem* LocSys = USquadAILocalizationSubsystem::Get(this);

	auto MakeWep = [&](FName ID, const FString& LocKeyPrefix, const FString& DefaultName, const FString& DefaultDesc, const FString& Caliber, int32 Clip, int32 MaxClip, int32 Reserve, float Dmg, float Acc, float Rate, float Range)
	{
		FSquadInventoryWeaponItem W;
		W.WeaponID = ID;
		W.DisplayName = (LocSys && !LocKeyPrefix.IsEmpty()) ? LocSys->GetString(TEXT("Armory"), LocKeyPrefix + TEXT("_Name"), DefaultName) : DefaultName;
		W.Description = (LocSys && !LocKeyPrefix.IsEmpty()) ? LocSys->GetString(TEXT("Armory"), LocKeyPrefix + TEXT("_Desc"), DefaultDesc) : DefaultDesc;
		W.Caliber = Caliber;
		W.ClipAmmo = Clip;
		W.MaxClipAmmo = MaxClip;
		W.ReserveAmmo = Reserve;
		W.DamageRating = Dmg;
		W.AccuracyRating = Acc;
		W.FireRateRating = Rate;
		W.RangeRating = Range;
		W.bIsUnlocked = true;
		Weapons.Add(W);
	};

	// Note: In [Armory], Weapon1=AK47, Weapon2=G3A3, Weapon3=RPG7, Weapon4=MG3, Weapon5=SVD, Weapon6=Knife
	MakeWep(FName("G3A3"),   TEXT("Weapon2"), TEXT("تفنگ ژ۳ G3A3"),          TEXT("سلاح سازمانی ۷.۶۲ ناتو با برد موثر بالا و قدرت نفوذ سنگین در سنگرها"), TEXT("7.62x51mm NATO"), 20,  20,  120, 0.92f, 0.88f, 0.65f, 0.90f);
	MakeWep(FName("AK47"),   TEXT("Weapon1"), TEXT("کلاشینکف AK-47"),         TEXT("سلاح هجومی ۷.۶۲ میلی‌متری با قابلیت اطمینان بالا در شرایط شن و گردوغبار"), TEXT("7.62x39mm"),      30,  30,  150, 0.85f, 0.78f, 0.82f, 0.75f);
	MakeWep(FName("RPG7"),   TEXT("Weapon3"), TEXT("راکت‌انداز RPG-7"),       TEXT("سلاح ضدزره پیاده‌نظام موثر در انهدام تانک‌های متجاوز و سنگرهای تیربار"), TEXT("85mm PG-7V"),     1,   1,   6,   1.00f, 0.70f, 0.25f, 0.80f);
	MakeWep(FName("MG3"),    TEXT("Weapon4"), TEXT("تیربار گرینوف / MG3"),    TEXT("تیربار سنگین با نواخت تیر بالا جهت اجرای آتش سرکوبگر بر روی دشمن"),       TEXT("7.62x51mm"),      100, 100, 300, 0.88f, 0.68f, 0.95f, 0.85f);
	MakeWep(FName("SVD"),    TEXT("Weapon5"), TEXT("دراگونوف SVD"),           TEXT("تفنگ تک‌تیرانداز دقیق جهت شکار دیده‌بان‌ها و فرماندهان دشمن"),             TEXT("7.62x54mmR"),     10,  10,  40,  0.96f, 0.98f, 0.40f, 1.00f);
	MakeWep(FName("Pistol"), TEXT(""),        TEXT("کلت سازمانی / طارق"),     TEXT("سلاح کمری ۹ میلی‌متری سازمانی جهت دفاع نزدیک در سنگر"),                   TEXT("9x19mm"),         9,   9,   48,  0.65f, 0.84f, 0.72f, 0.42f);
	MakeWep(FName("Knife"),  TEXT("Weapon6"), TEXT("خنجر رزمی / سرنیزه"),     TEXT("سلاح سرد جهت خنثی‌سازی بی‌صدا در نبردهای تن‌به‌تن شبانه"),                 TEXT("Melee Steel"),    1,   1,   1,   0.70f, 1.00f, 0.80f, 0.15f);
}

void USquadAIInventorySubsystem::ReloadNotesFromLocalization()
{
	FallenNotes.Empty();
	USquadAILocalizationSubsystem* LocSys = USquadAILocalizationSubsystem::Get(this);

	const int32 Count = LocSys ? FCString::Atoi(*LocSys->GetString(TEXT("FallenTroopNotes"), TEXT("NoteCount"), TEXT("6"))) : 6;

	for (int32 i = 1; i <= Count; ++i)
	{
		const FString KeyTitle = FString::Printf(TEXT("Note%d_Title"), i);
		const FString KeyBody = FString::Printf(TEXT("Note%d_Body"), i);

		FSquadFallenTroopNote Note;
		if (LocSys)
		{
			Note.NoteID = FName(*FString::Printf(TEXT("Note%d"), i));
			Note.ImageFile = LocSys->GetString(TEXT("FallenTroopNotes"), FString::Printf(TEXT("Note%d_Image"), i), FString::Printf(TEXT("Note%d"), i));
			Note.Title = LocSys->GetString(TEXT("FallenTroopNotes"), KeyTitle, FString::Printf(TEXT("دست‌نوشته همرزم شهید %d"), i));
			Note.Content = LocSys->GetString(TEXT("FallenTroopNotes"), KeyBody, TEXT("شهادت هنر مردان خداست. از خاک پاک وطن دفاع کنید."));
		}
		else
		{
			Note.Title = FString::Printf(TEXT("دست‌نوشته همرزم شهید %d"), i);
			Note.Content = TEXT("برادرانم! سلاح مرا بر زمین نگذارید و تا آخرین نفس از این آب و خاک دفاع کنید.");
		}
		FallenNotes.Add(Note);
	}
}

UTexture2D* USquadAIInventorySubsystem::GetNoteImage(const FSquadFallenTroopNote& Note)
{
	// 1. Designer-wired scan.
	if (Note.NoteImage) return Note.NoteImage.Get();
	// 2. Drop-in loose file (user-supplied handwritten scans).
	const FString Stem = Note.ImageFile.IsEmpty() ? Note.NoteID.ToString() : Note.ImageFile;
	if (Stem.IsEmpty()) return nullptr;
	if (TWeakObjectPtr<UTexture2D>* Cached = NoteImageCache.Find(Stem))
	{
		return Cached->Get();
	}
	UTexture2D* Loaded = FSquadAIAssetHelper::LoadTextureSafe(nullptr, *FString::Printf(TEXT("Textures/Notes/%s.png"), *Stem));
	NoteImageCache.Add(Stem, Loaded);
	return Loaded;
}

void USquadAIInventorySubsystem::ReloadRadioStations()
{
	RadioStations.Empty();
	USquadAILocalizationSubsystem* LocSys = USquadAILocalizationSubsystem::Get(this);

	const int32 Count = LocSys ? FCString::Atoi(*LocSys->GetString(TEXT("RadioStations"), TEXT("StationCount"), TEXT("5"))) : 5;

	for (int32 i = 1; i <= Count; ++i)
	{
		const FString KeyFreq = FString::Printf(TEXT("Station%d_Freq"), i);
		const FString KeyName = FString::Printf(TEXT("Station%d_Name"), i);

		FSquadRadioStation Station;
		if (LocSys)
		{
			Station.Frequency = FCString::Atof(*LocSys->GetString(TEXT("RadioStations"), KeyFreq, TEXT("88.5")));
			Station.StationName = LocSys->GetString(TEXT("RadioStations"), KeyName, TEXT("نوای حماسی دفاع مقدس"));
		}
		else
		{
			Station.Frequency = 88.5f + (i - 1) * 4.5f;
			Station.StationName = TEXT("نوای حماسی دفاع مقدس");
		}
		RadioStations.Add(Station);
	}
}

void USquadAIInventorySubsystem::ReloadQuranVerses()
{
	QuranVerses.Empty();
	USquadAILocalizationSubsystem* LocSys = USquadAILocalizationSubsystem::Get(this);

	const int32 Count = LocSys ? FCString::Atoi(*LocSys->GetString(TEXT("QuranVerses"), TEXT("VerseCount"), TEXT("4"))) : 4;

	for (int32 i = 1; i <= Count; ++i)
	{
		const FString KeyArab = FString::Printf(TEXT("Verse%d_Arabic"), i);
		const FString KeyTrans = FString::Printf(TEXT("Verse%d_Translation"), i);

		FQuranEntry E;
		if (LocSys)
		{
			E.Arabic = LocSys->GetString(TEXT("QuranVerses"), KeyArab, TEXT("وَمَا النَّصْرُ إِلَّا مِنْ عِنْدِ اللَّهِ"));
			E.Translation = LocSys->GetString(TEXT("QuranVerses"), KeyTrans, TEXT("و پیروزی جز از جانب خدای پیروزمند حکیم نیست."));
		}
		else
		{
			E.Arabic = TEXT("وَمَا النَّصْرُ إِلَّا مِنْ عِنْدِ اللَّهِ");
			E.Translation = TEXT("و پیروزی جز از جانب خدای پیروزمند حکیم نیست.");
		}
		QuranVerses.Add(E);
	}
}

void USquadAIInventorySubsystem::OnInventoryOpened()
{
	// Reload language-backed data every time the Canvas inventory opens so the
	// Settings language switch affects weapon names, relic notes, radio names, and verses immediately,
	// while preserving live ClipAmmo and ReserveAmmo consumed during gameplay.
	const int32 PreviousWeaponIndex = SelectedWeaponIndex;
	const int32 PreviousStationIndex = CurrentStationIndex;
	const int32 PreviousQuranIndex = CurrentQuranIndex;
	TMap<FName, TPair<int32, int32>> SavedAmmoByWeapon;
	for (const FSquadInventoryWeaponItem& Existing : Weapons)
	{
		SavedAmmoByWeapon.Add(Existing.WeaponID, TPair<int32, int32>(Existing.ClipAmmo, Existing.ReserveAmmo));
	}
	PopulateDefaultArsenal();
	for (FSquadInventoryWeaponItem& W : Weapons)
	{
		if (const TPair<int32, int32>* Saved = SavedAmmoByWeapon.Find(W.WeaponID))
		{
			W.ClipAmmo = FMath::Clamp(Saved->Key, 0, W.MaxClipAmmo);
			W.ReserveAmmo = FMath::Max(0, Saved->Value);
		}
	}
	ReloadNotesFromLocalization();
	ReloadRadioStations();
	ReloadQuranVerses();
	if (Weapons.Num() > 0) SelectedWeaponIndex = FMath::Clamp(PreviousWeaponIndex, 0, Weapons.Num() - 1);
	if (RadioStations.Num() > 0) CurrentStationIndex = FMath::Clamp(PreviousStationIndex, 0, RadioStations.Num() - 1);
	if (QuranVerses.Num() > 0) CurrentQuranIndex = FMath::Clamp(PreviousQuranIndex, 0, QuranVerses.Num() - 1);

	// Pick next note randomly or sequentially
	if (FallenNotes.Num() > 0)
	{
		CurrentNoteIndex = (CurrentNoteIndex + 1) % FallenNotes.Num();
	}

	// Update supplies from player pawn if available
	if (APawn* Player = UGameplayStatics::GetPlayerPawn(GetWorld(), 0))
	{
		if (UTacticalGrenadeComponent* GrenadeComp = Player->FindComponentByClass<UTacticalGrenadeComponent>())
		{
			FragGrenades = GrenadeComp->GetFragCount();
			SmokeGrenades = GrenadeComp->GetSmokeCount();
		}
	}
}

void USquadAIInventorySubsystem::NextWeapon()
{
	if (Weapons.Num() == 0) return;
	SelectedWeaponIndex = (SelectedWeaponIndex + 1) % Weapons.Num();
	if (USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(this))
	{
		Prog->EquipWeapon(Weapons[SelectedWeaponIndex].WeaponID);
	}
}

void USquadAIInventorySubsystem::PreviousWeapon()
{
	if (Weapons.Num() == 0) return;
	SelectedWeaponIndex = (SelectedWeaponIndex - 1 + Weapons.Num()) % Weapons.Num();
	if (USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(this))
	{
		Prog->EquipWeapon(Weapons[SelectedWeaponIndex].WeaponID);
	}
}

void USquadAIInventorySubsystem::SelectWeaponByIndex(int32 Index)
{
	if (Index >= 0 && Index < Weapons.Num())
	{
		SelectedWeaponIndex = Index;
		if (USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(this))
		{
			Prog->EquipWeapon(Weapons[SelectedWeaponIndex].WeaponID);
		}
	}
}

void USquadAIInventorySubsystem::SelectWeaponByID(FName WeaponID)
{
	if (WeaponID.IsNone() || Weapons.Num() == 0) return;
	const FString KeyStr = WeaponID.ToString();
	for (int32 i = 0; i < Weapons.Num(); ++i)
	{
		if (Weapons[i].WeaponID == WeaponID ||
			Weapons[i].WeaponID.ToString().Equals(KeyStr, ESearchCase::IgnoreCase) ||
			(KeyStr.Contains(TEXT("AK"), ESearchCase::IgnoreCase) && Weapons[i].WeaponID == FName("AK47")) ||
			(KeyStr.Contains(TEXT("G3"), ESearchCase::IgnoreCase) && Weapons[i].WeaponID == FName("G3A3")) ||
			(KeyStr.Contains(TEXT("RPG"), ESearchCase::IgnoreCase) && Weapons[i].WeaponID == FName("RPG7")) ||
			(KeyStr.Contains(TEXT("MG"), ESearchCase::IgnoreCase) && Weapons[i].WeaponID == FName("MG3")) ||
			(KeyStr.Contains(TEXT("SVD"), ESearchCase::IgnoreCase) && Weapons[i].WeaponID == FName("SVD")) ||
			(KeyStr.Contains(TEXT("Pistol"), ESearchCase::IgnoreCase) && Weapons[i].WeaponID == FName("Pistol")) ||
			(KeyStr.Contains(TEXT("Knife"), ESearchCase::IgnoreCase) && Weapons[i].WeaponID == FName("Knife")))
		{
			SelectedWeaponIndex = i;
			return;
		}
	}
}

bool USquadAIInventorySubsystem::EquipSelectedWeapon(APawn* PlayerPawn)
{
	if (!PlayerPawn || SelectedWeaponIndex < 0 || SelectedWeaponIndex >= Weapons.Num()) return false;

	const FSquadInventoryWeaponItem& W = Weapons[SelectedWeaponIndex];
	if (USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(this))
	{
		Prog->EquipWeapon(W.WeaponID);
	}

	bool bMatchedAny = false;

	// 1. If ASoldierCharacter, update weapon component
	if (ASoldierCharacter* SC = Cast<ASoldierCharacter>(PlayerPawn))
	{
		if (SC->WeaponComp)
		{
			SC->WeaponComp->WeaponDisplayName = FText::FromString(W.WeaponID.ToString());
			SC->WeaponComp->CurrentClipAmmo = W.ClipAmmo;
			SC->WeaponComp->ReserveAmmo = W.ReserveAmmo;
			SC->WeaponComp->Damage = W.DamageRating * 40.f;
			UE_LOG(LogTemp, Log, TEXT("[SquadAIInventory] Equipped weapon %s on SoldierCharacter"), *W.DisplayName);
			bMatchedAny = true;
		}
	}

	// 2. If TPWCS character, set Active Weapon and live Clip/Reserve ammo properties via reflection
	TArray<UActorComponent*> Comps;
	PlayerPawn->GetComponents(Comps);
	for (UActorComponent* C : Comps)
	{
		if (!C) continue;
		const FString N = C->GetName();
		if (N.Contains(TEXT("Weapon")) || N.Contains(TEXT("Combat")))
		{
			for (const FName& PropName : { FName(TEXT("Active Weapon")), FName(TEXT("ActiveWeapon")), FName(TEXT("CurrentWeapon")) })
			{
				if (FStrProperty* SP = FindFProperty<FStrProperty>(C->GetClass(), PropName))
				{
					SP->SetPropertyValue_InContainer(C, W.WeaponID.ToString());
					bMatchedAny = true;
				}
				if (FNameProperty* NP = FindFProperty<FNameProperty>(C->GetClass(), PropName))
				{
					NP->SetPropertyValue_InContainer(C, W.WeaponID);
					bMatchedAny = true;
				}
			}
			for (const FName& ClipName : { FName(TEXT("Ammo Clip Current")), FName(TEXT("AmmoClipCurrent")), FName(TEXT("ClipAmmo")), FName(TEXT("currentAmmo")), FName(TEXT("CurrentAmmo")) })
			{
				if (FIntProperty* IP = FindFProperty<FIntProperty>(C->GetClass(), ClipName))
				{
					IP->SetPropertyValue_InContainer(C, W.ClipAmmo);
					bMatchedAny = true;
				}
			}
			for (const FName& ResName : { FName(TEXT("Ammo Current")), FName(TEXT("AmmoCurrent")), FName(TEXT("ReserveAmmo")), FName(TEXT("reserveAmmo")), FName(TEXT("Ammo Total Current")), FName(TEXT("Ammo Reserve Current")) })
			{
				if (FIntProperty* IP = FindFProperty<FIntProperty>(C->GetClass(), ResName))
				{
					IP->SetPropertyValue_InContainer(C, W.ReserveAmmo);
					bMatchedAny = true;
				}
			}
		}
	}

	return bMatchedAny;
}

FSquadInventoryWeaponItem USquadAIInventorySubsystem::GetSelectedWeapon() const
{
	if (SelectedWeaponIndex >= 0 && SelectedWeaponIndex < Weapons.Num())
	{
		return Weapons[SelectedWeaponIndex];
	}
	return FSquadInventoryWeaponItem();
}

void USquadAIInventorySubsystem::NextFallenNote()
{
	if (FallenNotes.Num() == 0) return;
	CurrentNoteIndex = (CurrentNoteIndex + 1) % FallenNotes.Num();
}

void USquadAIInventorySubsystem::PreviousFallenNote()
{
	if (FallenNotes.Num() == 0) return;
	CurrentNoteIndex = (CurrentNoteIndex - 1 + FallenNotes.Num()) % FallenNotes.Num();
}

FSquadFallenTroopNote USquadAIInventorySubsystem::GetCurrentFallenNote() const
{
	if (CurrentNoteIndex >= 0 && CurrentNoteIndex < FallenNotes.Num())
	{
		return FallenNotes[CurrentNoteIndex];
	}
	return FSquadFallenTroopNote();
}

FSquadFallenTroopNote USquadAIInventorySubsystem::GetFallenNoteByIndex(int32 Index) const
{
	if (FallenNotes.IsValidIndex(Index))
	{
		return FallenNotes[Index];
	}
	return FSquadFallenTroopNote();
}

void USquadAIInventorySubsystem::NextRadioStation()
{
	if (RadioStations.Num() == 0) return;
	CurrentStationIndex = (CurrentStationIndex + 1) % RadioStations.Num();
}

void USquadAIInventorySubsystem::PreviousRadioStation()
{
	if (RadioStations.Num() == 0) return;
	CurrentStationIndex = (CurrentStationIndex - 1 + RadioStations.Num()) % RadioStations.Num();
}

void USquadAIInventorySubsystem::ToggleRadioPower()
{
	bRadioIsPlaying = !bRadioIsPlaying;
}

FSquadRadioStation USquadAIInventorySubsystem::GetCurrentRadioStation() const
{
	if (CurrentStationIndex >= 0 && CurrentStationIndex < RadioStations.Num())
	{
		return RadioStations[CurrentStationIndex];
	}
	return FSquadRadioStation();
}

void USquadAIInventorySubsystem::NextQuranVerse()
{
	if (QuranVerses.Num() == 0) return;
	CurrentQuranIndex = (CurrentQuranIndex + 1) % QuranVerses.Num();
}

void USquadAIInventorySubsystem::GetCurrentQuranVerse(FString& OutArabic, FString& OutTranslation) const
{
	if (CurrentQuranIndex >= 0 && CurrentQuranIndex < QuranVerses.Num())
	{
		OutArabic = QuranVerses[CurrentQuranIndex].Arabic;
		OutTranslation = QuranVerses[CurrentQuranIndex].Translation;
	}
	else
	{
		OutArabic = TEXT("وَمَا النَّصْرُ إِلَّا مِنْ عِنْدِ اللَّهِ");
		OutTranslation = TEXT("و پیروزی جز از جانب خدای پیروزمند نیست.");
	}
}

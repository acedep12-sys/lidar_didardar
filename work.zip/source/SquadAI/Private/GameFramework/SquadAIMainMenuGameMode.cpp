#include "GameFramework/SquadAIMainMenuGameMode.h"
#include "HUD/SquadAIMainMenuHUD.h"
#include "GameFramework/SpectatorPawn.h"

ASquadAIMainMenuGameMode::ASquadAIMainMenuGameMode()
{
	HUDClass = ASquadAIMainMenuHUD::StaticClass();
	DefaultPawnClass = ASpectatorPawn::StaticClass();
}

void ASquadAIMainMenuGameMode::BeginPlay()
{
	Super::BeginPlay();
	UE_LOG(LogTemp, Log, TEXT("[SquadAIMainMenu] Main Menu GameMode initialized"));
}

#include "GameFramework/SquadAIProgressionSubsystem.h"
#include "GameFramework/SquadAIInventorySubsystem.h"
#include "SquadAITuning.h"
#include "Utilities/SquadAIAssetHelper.h"
#include "SaveSystem/SquadAISaveGame.h"
#include "SaveSystem/SquadAISaveLoadSubsystem.h"
#include "HUD/FarsiTextHelper.h"
#include "Localization/SquadAILocalizationSubsystem.h"
#include "Engine/World.h"
#include "Engine/Engine.h"
#include "Kismet/GameplayStatics.h"

namespace
{
	bool SquadAIProgressionIsEnglish(const UObject* Context)
	{
		if (const USquadAILocalizationSubsystem* Loc = USquadAILocalizationSubsystem::Get(Context))
		{
			return Loc->GetCurrentLanguage().StartsWith(TEXT("en"), ESearchCase::IgnoreCase);
		}
		return false;
	}
}

void USquadAIProgressionSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);

	InitializeDefaultProfile();
	InitializeCatalogs();
	LoadProgressionFromDisk();

	UE_LOG(LogTemp, Log, TEXT("[SquadAIProgression] Progression Subsystem Initialized. Active Profile: %s, Level: %d, XP: %d"),
		*ActiveProfile.PlayerName, ActiveProfile.PlayerLevel, ActiveProfile.TotalXP);
}

void USquadAIProgressionSubsystem::Deinitialize()
{
	SaveProgressionToDisk();
	Super::Deinitialize();
}

USquadAIProgressionSubsystem* USquadAIProgressionSubsystem::Get(const UObject* WorldContextObject)
{
	if (!WorldContextObject) return nullptr;
	UGameInstance* GI = UGameplayStatics::GetGameInstance(WorldContextObject);
	return GI ? GI->GetSubsystem<USquadAIProgressionSubsystem>() : nullptr;
}

void USquadAIProgressionSubsystem::InitializeDefaultProfile()
{
	ActiveProfile.ProfileID = TEXT("Profile_1");
	ActiveProfile.PlayerName = SquadAIProgressionIsEnglish(this) ? TEXT("Line-Breaker Fighter") : TEXT("رزمنده خط‌شکن");
	ActiveProfile.SelectedAvatarID = FName("Avatar_Rostami");
	ActiveProfile.PlayerLevel = 1;
	ActiveProfile.CurrentLevel = 1; // dup sync: PlayerLevel is authoritative (Step2 residual)
	ActiveProfile.TotalXP = 0;
	ActiveProfile.CurrentLevelXP = 0;
	ActiveProfile.AvailableSkillPoints = 0;
	ActiveProfile.EnemiesHunted = 0;
	ActiveProfile.TanksDemolished = 0;
	ActiveProfile.TotalPlaytimeSeconds = 0.0f;
	ActiveProfile.MissionsCompleted = 0;
	ActiveProfile.TriageRevives = 0;
	ActiveProfile.EquippedWeaponID = FName("G3A3");

	ActiveProfile.AttributeRanks.Empty();
	ActiveProfile.AttributeRanks.Add(static_cast<uint8>(EPlayerAttributeType::MovementSpeed), 0);
	ActiveProfile.AttributeRanks.Add(static_cast<uint8>(EPlayerAttributeType::MaxHealth), 0);
	ActiveProfile.AttributeRanks.Add(static_cast<uint8>(EPlayerAttributeType::Stamina), 0);
	ActiveProfile.AttributeRanks.Add(static_cast<uint8>(EPlayerAttributeType::RecoilControl), 0);
	ActiveProfile.AttributeRanks.Add(static_cast<uint8>(EPlayerAttributeType::ReloadSpeed), 0);
	ActiveProfile.AttributeRanks.Add(static_cast<uint8>(EPlayerAttributeType::FieldReviveSpeed), 0);
	ActiveProfile.AttributeRanks.Add(static_cast<uint8>(EPlayerAttributeType::OrdnanceCapacity), 0);

	ActiveProfile.UnlockedWeaponIDs.Empty();
	ActiveProfile.UnlockedWeaponIDs.Add(FName("G3A3"));
	ActiveProfile.UnlockedWeaponIDs.Add(FName("AK47"));

	SavedProfiles.Empty();
	SavedProfiles.Add(ActiveProfile);
	ActiveProfileIndex = 0;
}

// =============================================================================
//  PROFILE MANAGEMENT
// =============================================================================

void USquadAIProgressionSubsystem::CreateNewProfile(const FString& ProfileName, FName AvatarID)
{
	FSquadPlayerProfile NewProf;
	NewProf.ProfileID = FString::Printf(TEXT("Profile_%d"), SavedProfiles.Num() + 1);
	NewProf.PlayerName = ProfileName.IsEmpty()
		? (SquadAIProgressionIsEnglish(this) ? FString::Printf(TEXT("Fighter %d"), SavedProfiles.Num() + 1) : FString::Printf(TEXT("رزمنده %d"), SavedProfiles.Num() + 1))
		: ProfileName;
	NewProf.SelectedAvatarID = AvatarID.IsNone() ? FName("Avatar_Rostami") : AvatarID;
	NewProf.PlayerLevel = 1;
	NewProf.CurrentLevel = 1;
	NewProf.TotalXP = 0;
	NewProf.CurrentLevelXP = 0;
	NewProf.AvailableSkillPoints = 0;
	NewProf.EquippedWeaponID = FName("G3A3");

	NewProf.AttributeRanks.Add(static_cast<uint8>(EPlayerAttributeType::MovementSpeed), 0);
	NewProf.AttributeRanks.Add(static_cast<uint8>(EPlayerAttributeType::MaxHealth), 0);
	NewProf.AttributeRanks.Add(static_cast<uint8>(EPlayerAttributeType::Stamina), 0);
	NewProf.AttributeRanks.Add(static_cast<uint8>(EPlayerAttributeType::RecoilControl), 0);
	NewProf.AttributeRanks.Add(static_cast<uint8>(EPlayerAttributeType::ReloadSpeed), 0);
	NewProf.AttributeRanks.Add(static_cast<uint8>(EPlayerAttributeType::FieldReviveSpeed), 0);
	NewProf.AttributeRanks.Add(static_cast<uint8>(EPlayerAttributeType::OrdnanceCapacity), 0);

	NewProf.UnlockedWeaponIDs.Add(FName("G3A3"));
	NewProf.UnlockedWeaponIDs.Add(FName("AK47"));

	SavedProfiles.Add(NewProf);
	SwitchProfile(SavedProfiles.Num() - 1);
}

bool USquadAIProgressionSubsystem::SwitchProfile(int32 ProfileIndex)
{
	if (!SavedProfiles.IsValidIndex(ProfileIndex)) return false;

	// Save current
	if (SavedProfiles.IsValidIndex(ActiveProfileIndex))
	{
		SavedProfiles[ActiveProfileIndex] = ActiveProfile;
	}

	ActiveProfileIndex = ProfileIndex;
	ActiveProfile = SavedProfiles[ProfileIndex];

	OnProfileChanged.Broadcast(ActiveProfile);
	SaveProgressionToDisk();

	UE_LOG(LogTemp, Log, TEXT("[SquadAIProgression] Switched to profile: %s (Index %d)"), *ActiveProfile.PlayerName, ActiveProfileIndex);
	return true;
}

void USquadAIProgressionSubsystem::DeleteProfile(int32 ProfileIndex)
{
	if (SavedProfiles.Num() <= 1 || !SavedProfiles.IsValidIndex(ProfileIndex)) return;

	SavedProfiles.RemoveAt(ProfileIndex);
	ActiveProfileIndex = FMath::Clamp(ActiveProfileIndex, 0, SavedProfiles.Num() - 1);
	ActiveProfile = SavedProfiles[ActiveProfileIndex];

	OnProfileChanged.Broadcast(ActiveProfile);
	SaveProgressionToDisk();
}

void USquadAIProgressionSubsystem::SetActiveAvatar(FName AvatarID)
{
	ActiveProfile.SelectedAvatarID = AvatarID;
	if (SavedProfiles.IsValidIndex(ActiveProfileIndex))
	{
		SavedProfiles[ActiveProfileIndex].SelectedAvatarID = AvatarID;
	}
	SaveProgressionToDisk();
	OnProfileChanged.Broadcast(ActiveProfile);
}

void USquadAIProgressionSubsystem::SetActivePlayerName(const FString& NewName)
{
	if (NewName.IsEmpty()) return;
	ActiveProfile.PlayerName = NewName;
	if (SavedProfiles.IsValidIndex(ActiveProfileIndex))
	{
		SavedProfiles[ActiveProfileIndex].PlayerName = NewName;
	}
	SaveProgressionToDisk();
	OnProfileChanged.Broadcast(ActiveProfile);
	UE_LOG(LogTemp, Log, TEXT("[SquadAIProgression] Profile name updated to: %s"), *NewName);
}

FString USquadAIProgressionSubsystem::CyclePresetCallsign()
{
	static const TCHAR* PresetCallsignsFa[] = {
		TEXT("سرگرد شهید ایرج رستمی"),
		TEXT("دلاور محور دهلاویه"),
		TEXT("تکاور تیپ ۵۵ هوابرد"),
		TEXT("شکارچی تانک‌های کرخه"),
		TEXT("رزمنده خط‌شکن سوسنگرد"),
		TEXT("دیده‌بان چمران"),
		TEXT("پاسدار پدافند بستان")
	};
	static const TCHAR* PresetCallsignsEn[] = {
		TEXT("Major Shahid Iraj Rostami"),
		TEXT("Dehlavieh Axis Defender"),
		TEXT("55th Airborne Commando"),
		TEXT("Karkheh Tank Hunter"),
		TEXT("Susangerd Line-Breaker"),
		TEXT("Chamran Scout"),
		TEXT("Bostan Defense Guard")
	};
	static int32 PresetIdx = 0;
	PresetIdx = (PresetIdx + 1) % UE_ARRAY_COUNT(PresetCallsignsFa);
	const bool bEnglish = SquadAIProgressionIsEnglish(this);
	const FString ChosenName = bEnglish ? FString(PresetCallsignsEn[PresetIdx]) : FString(PresetCallsignsFa[PresetIdx]);
	SetActivePlayerName(ChosenName);
	return ChosenName;
}

// =============================================================================
//  COMBAT STATS
// =============================================================================

void USquadAIProgressionSubsystem::RecordEnemyEliminated()
{
	// 0-XP kills FIXED: single choke bumps both counters (HUD prefers EnemiesEliminated)
	// and awards Tuning-owned kill XP (persists via AwardXP).
	ActiveProfile.EnemiesHunted++;
	ActiveProfile.EnemiesEliminated++;
	if (SavedProfiles.IsValidIndex(ActiveProfileIndex))
	{
		SavedProfiles[ActiveProfileIndex].EnemiesHunted = ActiveProfile.EnemiesHunted;
		SavedProfiles[ActiveProfileIndex].EnemiesEliminated = ActiveProfile.EnemiesEliminated;
	}
	AwardXP(USquadAITuning::Get()->KillXP, TEXT("Enemy Eliminated"));
}

void USquadAIProgressionSubsystem::RegisterHeadshot()
{
	ActiveProfile.HeadshotCount++;
	if (SavedProfiles.IsValidIndex(ActiveProfileIndex))
	{
		SavedProfiles[ActiveProfileIndex].HeadshotCount = ActiveProfile.HeadshotCount;
	}
	AwardXP(USquadAITuning::Get()->HeadshotBonusXP, TEXT("Headshot Bonus"));
}

void USquadAIProgressionSubsystem::RecordTankDemolished()
{
	ActiveProfile.TanksDemolished++;
	if (SavedProfiles.IsValidIndex(ActiveProfileIndex))
	{
		SavedProfiles[ActiveProfileIndex].TanksDemolished = ActiveProfile.TanksDemolished;
	}
	AwardXP(300, TEXT("Tank Destroyed"));
}

void USquadAIProgressionSubsystem::RecordTriageRevive()
{
	ActiveProfile.TriageRevives++;
	if (SavedProfiles.IsValidIndex(ActiveProfileIndex))
	{
		SavedProfiles[ActiveProfileIndex].TriageRevives = ActiveProfile.TriageRevives;
	}
	UpdateAchievementProgress(FName("HeroicMedic"), 1.0f);
	AwardXP(150, TEXT("Squadmate Revived"));
}

void USquadAIProgressionSubsystem::AddPlaytime(float DeltaSeconds)
{
	ActiveProfile.TotalPlaytimeSeconds += DeltaSeconds;
	if (SavedProfiles.IsValidIndex(ActiveProfileIndex))
	{
		SavedProfiles[ActiveProfileIndex].TotalPlaytimeSeconds = ActiveProfile.TotalPlaytimeSeconds;
	}
}

FString USquadAIProgressionSubsystem::GetFormattedPlaytime() const
{
	const int32 TotalMins = FMath::FloorToInt(ActiveProfile.TotalPlaytimeSeconds / 60.0f);
	const int32 Hours = TotalMins / 60;
	const int32 Mins = TotalMins % 60;
	const bool bEnglish = SquadAIProgressionIsEnglish(this);

	if (Hours > 0)
	{
		return bEnglish ? FString::Printf(TEXT("%d hours and %d minutes"), Hours, Mins) : FString::Printf(TEXT("%d ساعت و %d دقیقه"), Hours, Mins);
	}
	return bEnglish ? FString::Printf(TEXT("%d minutes"), Mins) : FString::Printf(TEXT("%d دقیقه"), Mins);
}

// =============================================================================
//  LEVELING & XP
// =============================================================================

int32 USquadAIProgressionSubsystem::CalculateXPRequirement(int32 Level) const
{
	return FMath::RoundToInt(800.0f * FMath::Pow(static_cast<float>(Level), 1.25f) + (Level * 400.0f));
}

int32 USquadAIProgressionSubsystem::GetXPRequiredForNextLevel() const
{
	return CalculateXPRequirement(ActiveProfile.PlayerLevel);
}

float USquadAIProgressionSubsystem::GetLevelProgressFraction() const
{
	const int32 Req = GetXPRequiredForNextLevel();
	return Req > 0 ? FMath::Clamp(static_cast<float>(ActiveProfile.CurrentLevelXP) / static_cast<float>(Req), 0.0f, 1.0f) : 1.0f;
}

void USquadAIProgressionSubsystem::AwardXP(int32 Amount, const FString& Reason)
{
	if (Amount <= 0) return;

	ActiveProfile.TotalXP += Amount;
	ActiveProfile.CurrentLevelXP += Amount;

	UE_LOG(LogTemp, Log, TEXT("[SquadAIProgression] Awarded %d XP (%s). Total XP: %d"), Amount, *Reason, ActiveProfile.TotalXP);
	OnXPGained.Broadcast(Amount, ActiveProfile.TotalXP, Reason);

	CheckLevelUp();
	SaveProgressionToDisk();
}

void USquadAIProgressionSubsystem::AwardQuestCompletionXP(FName QuestID, int32 Amount)
{
	ActiveProfile.MissionsCompleted++;
	const FString Reason = FString::Printf(TEXT("Quest '%s' Cleared"), *QuestID.ToString());
	AwardXP(Amount, Reason);

	UpdateAchievementProgress(FName("DehlaviehDefender"), 1.0f);
	UpdateAchievementProgress(FName("FirstBlood"), 1.0f);
}

void USquadAIProgressionSubsystem::CheckLevelUp()
{
	int32 RequiredXP = GetXPRequiredForNextLevel();
	while (ActiveProfile.CurrentLevelXP >= RequiredXP)
	{
		ActiveProfile.CurrentLevelXP -= RequiredXP;
		ActiveProfile.PlayerLevel++;
		ActiveProfile.CurrentLevel = ActiveProfile.PlayerLevel; // dup sync (profile screen reads CurrentLevel)
		ActiveProfile.AvailableSkillPoints++;

		UE_LOG(LogTemp, Warning, TEXT("[SquadAIProgression] *** LEVEL UP! New Level: %d, Skill Points: %d ***"),
			ActiveProfile.PlayerLevel, ActiveProfile.AvailableSkillPoints);
		OnPlayerLevelUp.Broadcast(ActiveProfile.PlayerLevel, ActiveProfile.AvailableSkillPoints);

		RequiredXP = GetXPRequiredForNextLevel();
	}
}

// =============================================================================
//  ATTRIBUTE UPGRADES
// =============================================================================

bool USquadAIProgressionSubsystem::UpgradeAttribute(EPlayerAttributeType Attribute)
{
	if (ActiveProfile.AvailableSkillPoints <= 0) return false;

	const uint8 Key = static_cast<uint8>(Attribute);
	int32 CurrentRank = ActiveProfile.AttributeRanks.Contains(Key) ? ActiveProfile.AttributeRanks[Key] : 0;

	if (CurrentRank >= 10) return false;

	CurrentRank++;
	ActiveProfile.AttributeRanks.Add(Key, CurrentRank);
	ActiveProfile.AvailableSkillPoints--;

	OnAttributeUpgraded.Broadcast(Attribute, CurrentRank);
	SaveProgressionToDisk();

	return true;
}

int32 USquadAIProgressionSubsystem::GetAttributeRank(EPlayerAttributeType Attribute) const
{
	const uint8 Key = static_cast<uint8>(Attribute);
	const int32* Rank = ActiveProfile.AttributeRanks.Find(Key);
	return Rank ? *Rank : 0;
}

float USquadAIProgressionSubsystem::GetSpeedMultiplier() const
{
	const int32 Rank = GetAttributeRank(EPlayerAttributeType::MovementSpeed);
	return 1.0f + (Rank * 0.04f);
}

float USquadAIProgressionSubsystem::GetMaxHealthBonus() const
{
	const int32 Rank = GetAttributeRank(EPlayerAttributeType::MaxHealth);
	return Rank * 10.0f;
}

float USquadAIProgressionSubsystem::GetStaminaMultiplier() const
{
	const int32 Rank = GetAttributeRank(EPlayerAttributeType::Stamina);
	return 1.0f + (Rank * 0.10f);
}

float USquadAIProgressionSubsystem::GetRecoilMultiplier() const
{
	const int32 Rank = GetAttributeRank(EPlayerAttributeType::RecoilControl);
	return FMath::Max(0.50f, 1.0f - (Rank * 0.05f));
}

float USquadAIProgressionSubsystem::GetReloadSpeedMultiplier() const
{
	const int32 Rank = GetAttributeRank(EPlayerAttributeType::ReloadSpeed);
	return 1.0f + (Rank * 0.06f);
}

float USquadAIProgressionSubsystem::GetReviveSpeedMultiplier() const
{
	const int32 Rank = GetAttributeRank(EPlayerAttributeType::FieldReviveSpeed);
	return 1.0f + (Rank * 0.08f);
}

int32 USquadAIProgressionSubsystem::GetExtraOrdnanceCapacity() const
{
	const int32 Rank = GetAttributeRank(EPlayerAttributeType::OrdnanceCapacity);
	return Rank / 2;
}

// =============================================================================
//  WEAPON ARMORY & UNLOCKS
// =============================================================================

TArray<FSquadWeaponDefinition> USquadAIProgressionSubsystem::GetArmoryCatalog() const
{
	TArray<FSquadWeaponDefinition> DynamicList = ArmoryCatalog;
	for (FSquadWeaponDefinition& W : DynamicList)
	{
		W.bIsUnlocked = IsWeaponUnlocked(W.WeaponID);
	}
	return DynamicList;
}

TArray<FSquadWeaponDefinition> USquadAIProgressionSubsystem::GetAvailableWeapons() const
{
	return GetArmoryCatalog();
}

bool USquadAIProgressionSubsystem::IsWeaponUnlocked(FName WeaponID) const
{
	if (WeaponID == FName("G3A3") || WeaponID == FName("AK47") || WeaponID.IsNone())
	{
		return true;
	}
	for (const FSquadWeaponDefinition& W : ArmoryCatalog)
	{
		if (W.WeaponID == WeaponID && W.bDefaultUnlocked)
		{
			return true;
		}
	}
	return ActiveProfile.UnlockedWeaponIDs.Contains(WeaponID);
}

bool USquadAIProgressionSubsystem::CanUnlockWeapon(FName WeaponID, FText& OutFailReason) const
{
	const bool bEnglish = SquadAIProgressionIsEnglish(this);
	if (IsWeaponUnlocked(WeaponID))
	{
		OutFailReason = FText::FromString(bEnglish ? TEXT("This weapon is already unlocked.") : TEXT("این سلاح قبلاً آزاد شده است."));
		return false;
	}

	FSquadWeaponDefinition Wep;
	if (!FindWeaponDefinition(WeaponID, Wep))
	{
		OutFailReason = FText::FromString(bEnglish ? TEXT("The requested weapon was not found in the armory.") : TEXT("سلاح مورد نظر در زرادخانه یافت نشد."));
		return false;
	}

	if (ActiveProfile.PlayerLevel < Wep.RequiredPlayerLevel)
	{
		OutFailReason = FText::FromString(bEnglish
			? FString::Printf(TEXT("Requires level %d (current level: %d)"), Wep.RequiredPlayerLevel, ActiveProfile.PlayerLevel)
			: FString::Printf(TEXT("نیازمند رسیدن به سطح %d است (سطح فعلی: %d)"), Wep.RequiredPlayerLevel, ActiveProfile.PlayerLevel));
		return false;
	}

	// F-G1: XP costs are real — TotalXP is the wallet (level-ups run off CurrentLevelXP, so spending never de-levels).
	if (ActiveProfile.TotalXP < Wep.XPCostToUnlock)
	{
		OutFailReason = FText::FromString(bEnglish
			? FString::Printf(TEXT("Not enough XP (required: %d, available: %d)"), Wep.XPCostToUnlock, ActiveProfile.TotalXP)
			: FString::Printf(TEXT("امتیاز کافی نیست (لازم: %d، موجود: %d)"), Wep.XPCostToUnlock, ActiveProfile.TotalXP));
		return false;
	}

	return true;
}

bool USquadAIProgressionSubsystem::UnlockWeapon(FName WeaponID)
{
	// F-G1: gate on CanUnlockWeapon (level + XP) and deduct the cost — was unconditional + free.
	FText FailReason;
	if (!CanUnlockWeapon(WeaponID, FailReason)) return false;

	FSquadWeaponDefinition Wep;
	const int32 Cost = (FindWeaponDefinition(WeaponID, Wep)) ? Wep.XPCostToUnlock : 0;
	ActiveProfile.TotalXP = FMath::Max(0, ActiveProfile.TotalXP - Cost);

	ActiveProfile.UnlockedWeaponIDs.AddUnique(WeaponID);
	if (SavedProfiles.IsValidIndex(ActiveProfileIndex))
	{
		SavedProfiles[ActiveProfileIndex].TotalXP = ActiveProfile.TotalXP;
		SavedProfiles[ActiveProfileIndex].UnlockedWeaponIDs = ActiveProfile.UnlockedWeaponIDs;
	}
	OnWeaponUnlocked.Broadcast(WeaponID);
	SaveProgressionToDisk();
	return true;
}

bool USquadAIProgressionSubsystem::EquipWeapon(FName WeaponID)
{
	if (!IsWeaponUnlocked(WeaponID)) return false;

	ActiveProfile.EquippedWeaponID = WeaponID;
	if (USquadAIInventorySubsystem* Inv = USquadAIInventorySubsystem::Get(this))
	{
		Inv->SelectWeaponByID(WeaponID);
	}
	SaveProgressionToDisk();
	return true;
}

bool USquadAIProgressionSubsystem::FindWeaponDefinition(FName WeaponID, FSquadWeaponDefinition& OutWeapon) const
{
	for (const FSquadWeaponDefinition& W : ArmoryCatalog)
	{
		if (W.WeaponID == WeaponID)
		{
			OutWeapon = W;
			return true;
		}
	}
	return false;
}

// =============================================================================
//  ACHIEVEMENTS
// =============================================================================

void USquadAIProgressionSubsystem::UpdateAchievementProgress(FName AchievementID, float ProgressDelta)
{
	for (FSquadAchievement& Ach : AchievementsCatalog)
	{
		if (Ach.AchievementID == AchievementID && !Ach.bIsUnlocked)
		{
			Ach.CurrentProgress = FMath::Min(Ach.CurrentProgress + ProgressDelta, Ach.TargetProgress);
			if (Ach.CurrentProgress >= Ach.TargetProgress)
			{
				UnlockAchievement(AchievementID);
			}
			return;
		}
	}
}

void USquadAIProgressionSubsystem::UnlockAchievement(FName AchievementID)
{
	for (FSquadAchievement& Ach : AchievementsCatalog)
	{
		if (Ach.AchievementID == AchievementID && !Ach.bIsUnlocked)
		{
			Ach.bIsUnlocked = true;
			Ach.CurrentProgress = Ach.TargetProgress;
			Ach.UnlockTimestamp = FDateTime::UtcNow();

			AwardXP(Ach.XPReward, FString::Printf(TEXT("Achievement: %s"), *Ach.TitleEnglish.ToString()));
			OnAchievementUnlocked.Broadcast(Ach);
			SaveProgressionToDisk();
			return;
		}
	}
}

// =============================================================================
//  CATALOG INITIALIZATIONS & SPECIALITY TRAITS
// =============================================================================

void USquadAIProgressionSubsystem::InitializeCatalogs()
{
	// 1. Available Maps
	AvailableMaps.Empty();

	FSquadMapDefinition Map1;
	Map1.MapID = FName("Dehlavieh_Karkheh");
	Map1.LevelPackageName = FName("L_Khuzestan");
	Map1.DisplayNameFarsi = FText::FromString(TEXT("محور دهلاویه و رودخانه کرخه"));
	Map1.DisplayNameEnglish = FText::FromString(TEXT("Dehlavieh & Karkheh River Frontline"));
	Map1.Subtitle = FText::FromString(SquadAIProgressionIsEnglish(this) ? TEXT("Khuzestan frontline — defense against hostile armored columns") : TEXT("خط مقدم نبرد خوزستان — دفاع در برابر ادوات زرهی دشمن"));
	Map1.SituationBriefingFarsi = FText::FromString(TEXT(
		"موقعیت تاکتیکی: نبرد سنگین در حاشیه رودخانه پرآب کرخه و دشت‌های تفتیده دهلاویه.\n"
		"ستون‌های زرهی و تانک‌های متخاصم در حال پیشروی به سمت روستای خشتی در عقبه خط هستند.\n"
		"ماموریت جوخه با فرماندهی سرگرد شهید ایرج رستمی: استقرار در سنگرهای شنی، انهدام تانک‌ها با آرپی‌جی-۷ و تثبیت خط پدافندی."
	));
	Map1.SituationBriefingEnglish = FText::FromString(TEXT(
		"Tactical situation: heavy fighting along the Karkheh riverbanks and the scorched Dehlavieh plains.\n"
		"Hostile armored columns are advancing toward the rear mudbrick village.\n"
		"Mission: under Major Shahid Iraj Rostami, occupy the sand trenches, destroy armor with RPG-7s, and stabilize the defensive line."
	));
	Map1.PreviewTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Map_Preview_Dehlavieh_Karkheh.Map_Preview_Dehlavieh_Karkheh"), TEXT("Textures/Map_Preview_Dehlavieh_Karkheh.png"));
	Map1.bIsSelectable = true;
	Map1.RequiredPlayerLevel = 1;
	Map1.CompletionXPReward = 1200;
	Map1.EstimatedPlaytime = SquadAIProgressionIsEnglish(this) ? TEXT("20 to 30 minutes") : TEXT("۲۰ الی ۳۰ دقیقه");
	AvailableMaps.Add(Map1);

	FSquadMapDefinition Map2;
	Map2.MapID = FName("Bostan_Chazzabeh");
	Map2.LevelPackageName = FName("L_Bostan");
	Map2.DisplayNameFarsi = FText::FromString(TEXT("محور بستان و تنگه چزابه"));
	Map2.DisplayNameEnglish = FText::FromString(TEXT("Bostan & Chazzabeh Marshes"));
	Map2.Subtitle = FText::FromString(SquadAIProgressionIsEnglish(this) ? TEXT("Dune fields and Hoor al-Hawizeh waterways") : TEXT("تپه‌های رملی و آبراهه‌های هورالهویزه"));
	Map2.SituationBriefingFarsi = FText::FromString(TEXT(
		"موقعیت تاکتیکی: دشت‌های رملی و آبراهه‌های باتلاقی هورالهویزه در غرب سوسنگرد.\n"
		"دشمن خطوط پدافندی متراکم ایجاد کرده است. عملیات شناسایی و نفوذ شبانه در حال برنامه‌ریزی است."
	));
	Map2.SituationBriefingEnglish = FText::FromString(TEXT(
		"Tactical situation: dune fields and marsh waterways west of Susangerd.\n"
		"The enemy has built dense defensive lines. Recon and night infiltration are being planned."
	));
	Map2.PreviewTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Map_Preview_Bostan_Chazzabeh.Map_Preview_Bostan_Chazzabeh"), TEXT("Textures/Map_Preview_Bostan_Chazzabeh.png"));
	Map2.bIsSelectable = false;
	Map2.LockReasonFarsi = FText::FromString(TEXT("در دست آماده‌سازی و بهینه‌سازی عملیاتی (Undergoing)"));
	Map2.RequiredPlayerLevel = 4;
	Map2.CompletionXPReward = 2000;
	Map2.EstimatedPlaytime = SquadAIProgressionIsEnglish(this) ? TEXT("25 to 35 minutes") : TEXT("۲۵ الی ۳۵ دقیقه");
	AvailableMaps.Add(Map2);

	FSquadMapDefinition Map3;
	Map3.MapID = FName("Khorramshahr_Arvand");
	Map3.LevelPackageName = FName("L_Khorramshahr");
	Map3.DisplayNameFarsi = FText::FromString(TEXT("خرمشهر و اروندکنار"));
	Map3.DisplayNameEnglish = FText::FromString(TEXT("Khorramshahr & Arvand River"));
	Map3.Subtitle = FText::FromString(SquadAIProgressionIsEnglish(this) ? TEXT("Urban combat through alleys, palms, and Arvand riverfront") : TEXT("نبرد شهری در کوچه‌ها و نخلستان‌های اروند"));
	Map3.SituationBriefingFarsi = FText::FromString(TEXT(
		"موقعیت تاکتیکی: نبرد تن‌به‌تن شهری در میان ساختمان‌های خشتی و نخلستان‌های حاشیه اروندکنار.\n"
		"حماسه مقاومت ۳۴ روزه رزمندگان و مدافعان شهر در برابر لشکرهای زرهی متجاوز."
	));
	Map3.SituationBriefingEnglish = FText::FromString(TEXT(
		"Tactical situation: close urban fighting among mudbrick buildings and palm groves near Arvandkenar.\n"
		"A 34-day stand by the city defenders against invading armored divisions."
	));
	Map3.PreviewTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Map_Preview_Khorramshahr_Arvand.Map_Preview_Khorramshahr_Arvand"), TEXT("Textures/Map_Preview_Khorramshahr_Arvand.png"));
	Map3.bIsSelectable = false;
	Map3.LockReasonFarsi = FText::FromString(TEXT("در دست آماده‌سازی و بهینه‌سازی عملیاتی (Undergoing)"));
	Map3.RequiredPlayerLevel = 8;
	Map3.CompletionXPReward = 3500;
	Map3.EstimatedPlaytime = SquadAIProgressionIsEnglish(this) ? TEXT("35 to 45 minutes") : TEXT("۳۵ الی ۴۵ دقیقه");
	AvailableMaps.Add(Map3);

	// 2. Armory Weapons & Speciality Traits
	ArmoryCatalog.Empty();

	// Weapon 1: G3A3
	FSquadWeaponDefinition W1;
	W1.WeaponID = FName("G3A3");
	W1.DisplayNameFarsi = FText::FromString(TEXT("تفنگ جنگی ژ-۳ (G3A3)"));
	W1.DisplayNameEnglish = FText::FromString(TEXT("H&K G3A3 Battle Rifle"));
	W1.Caliber = FText::FromString(TEXT("۷.۶۲×۵۱ میلی‌متر ناتو"));
	W1.HistoricalRoleFarsi = FText::FromString(TEXT("سلاح سازمانی و استاندارد ارتش"));
	W1.HistoricalRoleEnglish = FText::FromString(TEXT("Standard Service Rifle"));
	W1.Category = ESquadWeaponCategory::BattleRifle;
	W1.DescriptionFarsi = FText::FromString(TEXT("سلاح سازمانی و کالیبر پرقدرت ارتش (۷.۶۲×۵۱)، کشندگی بسیار بالا و برد موثر عالی در دشت‌های باز."));
	W1.DescriptionEnglish = FText::FromString(TEXT("Standard high-power 7.62x51 service rifle with excellent lethality and range in open terrain."));
	W1.PreviewTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Weapon_Preview_G3A3.Weapon_Preview_G3A3"), TEXT("Textures/Weapon_Preview_G3A3.png"));
	W1.DamageRating = 0.88f;
	W1.FireRateRating = 0.55f;
	W1.AccuracyRating = 0.86f;
	W1.RangeRating = 0.90f;
	W1.RecoilControlRating = 0.65f;
	W1.MobilityRating = 0.70f;
	W1.ArmorPenetrationRating = 0.75f;
	W1.MagazineCapacity = 20;
	W1.MaxReserveAmmo = 140;
	W1.RequiredPlayerLevel = 1;
	W1.XPCostToUnlock = 0;
	W1.bDefaultUnlocked = true;

	FSquadWeaponSpecialityTrait T1_1;
	T1_1.TraitID = FName("HeavyCaliber");
	T1_1.BadgeTag = TEXT("💥 کالیبر سنگین ۷.۶۲");
	T1_1.TitleFarsi = FText::FromString(TEXT("قدرت کشندگی و نفوذ بالا"));
	T1_1.TitleEnglish = FText::FromString(TEXT("High Lethality & Penetration"));
	T1_1.DescriptionFarsi = FText::FromString(TEXT("کالیبر پرقدرت ۷.۶۲ میلی‌متری ناتو با شلیک‌های سنگین و بازدارندگی کامل در برابر پیاده‌نظام متخاصم."));
	T1_1.DescriptionEnglish = FText::FromString(TEXT("Powerful 7.62mm NATO caliber with heavy stopping fire against hostile infantry."));
	W1.SpecialityTraits.Add(T1_1);

	FSquadWeaponSpecialityTrait T1_2;
	T1_2.TraitID = FName("LongRangePrecision");
	T1_2.BadgeTag = TEXT("🎯 تیراندازی دوربرد");
	T1_2.TitleFarsi = FText::FromString(TEXT("دقت بالا در دشت‌های باز"));
	T1_2.TitleEnglish = FText::FromString(TEXT("Open-Desert Precision"));
	T1_2.DescriptionFarsi = FText::FromString(TEXT("برد موثر تا ۸۰۰ متر؛ ایده‌آل برای هدف‌گیری نیروهای متخاصم پیش از رسیدن به سنگرها."));
	T1_2.DescriptionEnglish = FText::FromString(TEXT("Effective range up to 800 meters; ideal for engaging hostiles before they reach the trenches."));
	W1.SpecialityTraits.Add(T1_2);
	ArmoryCatalog.Add(W1);

	// Weapon 2: AK-47
	FSquadWeaponDefinition W2;
	W2.WeaponID = FName("AK47");
	W2.DisplayNameFarsi = FText::FromString(TEXT("تفنگ هجومی کلاشینکف (AK-47 / AKM)"));
	W2.DisplayNameEnglish = FText::FromString(TEXT("Kalashnikov AK-47 / AKM"));
	W2.Caliber = FText::FromString(TEXT("۷.۶۲×۳۹ میلی‌متر"));
	W2.HistoricalRoleFarsi = FText::FromString(TEXT("سلاح محبوب نیروهای نامنظم"));
	W2.HistoricalRoleEnglish = FText::FromString(TEXT("Irregular Forces Assault Rifle"));
	W2.Category = ESquadWeaponCategory::AssaultRifle;
	W2.DescriptionFarsi = FText::FromString(TEXT("سلاح محبوب نیروهای نامنظم و چریکی (۷.۶۲×۳۹)، پایداری افسانه‌ای در گرد و غبار بیابان و نواخت تیر سریع."));
	W2.DescriptionEnglish = FText::FromString(TEXT("Favored guerrilla 7.62x39 rifle with legendary dust reliability and a fast rate of fire."));
	W2.PreviewTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Weapon_Preview_AK47.Weapon_Preview_AK47"), TEXT("Textures/Weapon_Preview_AK47.png"));
	W2.DamageRating = 0.78f;
	W2.FireRateRating = 0.78f;
	W2.AccuracyRating = 0.72f;
	W2.RangeRating = 0.75f;
	W2.RecoilControlRating = 0.75f;
	W2.MobilityRating = 0.88f;
	W2.ArmorPenetrationRating = 0.65f;
	W2.MagazineCapacity = 30;
	W2.MaxReserveAmmo = 180;
	W2.RequiredPlayerLevel = 1;
	W2.XPCostToUnlock = 0;
	W2.bDefaultUnlocked = true;

	FSquadWeaponSpecialityTrait T2_1;
	T2_1.TraitID = FName("DesertReliability");
	T2_1.BadgeTag = TEXT("🌪️ پایداری در طوفان شن");
	T2_1.TitleFarsi = FText::FromString(TEXT("عدم افت کیفیت در شن"));
	T2_1.TitleEnglish = FText::FromString(TEXT("Desert Reliability"));
	T2_1.DescriptionFarsi = FText::FromString(TEXT("مکانیزم گاز پیستون مطمئن؛ شلیک ممتد در گل‌ولای و ریزگردهای خوزستان بدون گیر کردن."));
	T2_1.DescriptionEnglish = FText::FromString(TEXT("Reliable gas-piston action; sustained fire through mud and Khuzestan dust without jamming."));
	W2.SpecialityTraits.Add(T2_1);

	FSquadWeaponSpecialityTrait T2_2;
	T2_2.TraitID = FName("HighMobility");
	T2_2.BadgeTag = TEXT("⚡ تحرک و تهاجم سریع");
	T2_2.TitleFarsi = FText::FromString(TEXT("سرعت بالای پیشروی"));
	T2_2.TitleEnglish = FText::FromString(TEXT("High Mobility Assault"));
	T2_2.DescriptionFarsi = FText::FromString(TEXT("وزن سبک و بالانس عالی؛ افزایش سرعت مانور و پاکسازی کانال‌ها و سنگرها."));
	T2_2.DescriptionEnglish = FText::FromString(TEXT("Light, well-balanced handling improves maneuver speed and trench clearing."));
	W2.SpecialityTraits.Add(T2_2);
	ArmoryCatalog.Add(W2);

	// Weapon 3: RPG-7
	FSquadWeaponDefinition W3;
	W3.WeaponID = FName("RPG7");
	W3.DisplayNameFarsi = FText::FromString(TEXT("راکت‌انداز ضدتانک آرپی‌جی-۷ (RPG-7)"));
	W3.DisplayNameEnglish = FText::FromString(TEXT("RPG-7 Tank Destroyer"));
	W3.Caliber = FText::FromString(TEXT("راکت ضدزره PG-7V"));
	W3.HistoricalRoleFarsi = FText::FromString(TEXT("شکارچی تانک و زره‌پوش"));
	W3.HistoricalRoleEnglish = FText::FromString(TEXT("Anti-Armor Tank Hunter"));
	W3.Category = ESquadWeaponCategory::AntiTankRocket;
	W3.DescriptionFarsi = FText::FromString(TEXT("شکارچی زره‌پوش‌ها و تانک‌های دشمن با سر جنگی شدیدالانفجار، سلاح اصلی خط‌شکنان و رزمندگان ستاد جنگ‌های نامنظم."));
	W3.DescriptionEnglish = FText::FromString(TEXT("High-explosive anti-armor launcher used by frontline assault fighters and irregular units."));
	W3.PreviewTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Weapon_Preview_RPG7.Weapon_Preview_RPG7"), TEXT("Textures/Weapon_Preview_RPG7.png"));
	W3.DamageRating = 1.00f;
	W3.FireRateRating = 0.20f;
	W3.AccuracyRating = 0.65f;
	W3.RangeRating = 0.80f;
	W3.RecoilControlRating = 0.40f;
	W3.MobilityRating = 0.55f;
	W3.ArmorPenetrationRating = 1.00f;
	W3.MagazineCapacity = 1;
	W3.MaxReserveAmmo = 6;
	W3.RequiredPlayerLevel = 3;
	W3.XPCostToUnlock = 2500;
	W3.bDefaultUnlocked = false;

	FSquadWeaponSpecialityTrait T3_1;
	T3_1.TraitID = FName("TankDestroyer");
	T3_1.BadgeTag = TEXT("🛡️ شکارچی تانک و زره‌پوش");
	T3_1.TitleFarsi = FText::FromString(TEXT("شکارچی قطعی تانک‌ها"));
	T3_1.TitleEnglish = FText::FromString(TEXT("Tank Killer"));
	T3_1.DescriptionFarsi = FText::FromString(TEXT("شلیک راکت شدیدالانفجار خرج گود PG-7V؛ انهدام کامل تانک‌ها و نفربرهای زرهی دشمن در یک شلیک دقیق."));
	T3_1.DescriptionEnglish = FText::FromString(TEXT("PG-7V shaped-charge rocket; destroys enemy tanks and APCs with one accurate shot."));
	W3.SpecialityTraits.Add(T3_1);

	FSquadWeaponSpecialityTrait T3_2;
	T3_2.TraitID = FName("BunkerBreaker");
	T3_2.BadgeTag = TEXT("💣 تخریب سنگرهای بتنی");
	T3_2.TitleFarsi = FText::FromString(TEXT("انهدام استحکامات و دوشکا"));
	T3_2.TitleEnglish = FText::FromString(TEXT("Bunker & DShK Breaker"));
	T3_2.DescriptionFarsi = FText::FromString(TEXT("تخریب آنی مواضع تیربار سنگین دوشکا و دیوارهای خشتی مستحکم دشمن با شعاع انفجار وسیع."));
	T3_2.DescriptionEnglish = FText::FromString(TEXT("Rapidly destroys heavy machine-gun nests and fortified mudbrick walls with a wide blast."));
	W3.SpecialityTraits.Add(T3_2);
	ArmoryCatalog.Add(W3);

	// Weapon 4: MG3
	FSquadWeaponDefinition W4;
	W4.WeaponID = FName("MG3");
	W4.DisplayNameFarsi = FText::FromString(TEXT("تیربار سنگین ام‌جی-۳ (MG3 Machine Gun)"));
	W4.DisplayNameEnglish = FText::FromString(TEXT("Rheinmetall MG3 Machine Gun"));
	W4.Caliber = FText::FromString(TEXT("۷.۶۲×۵۱ ناتو نواری"));
	W4.HistoricalRoleFarsi = FText::FromString(TEXT("تیربار سرکوبگر خط دفاعی"));
	W4.HistoricalRoleEnglish = FText::FromString(TEXT("Defensive Suppression Machine Gun"));
	W4.Category = ESquadWeaponCategory::MachineGun;
	W4.DescriptionFarsi = FText::FromString(TEXT("قدرت آتش سرکوبگر ویرانگر با نواخت ۱۲۰۰ تیر در دقیقه، برتری آتش مطلق در تثبیت خطوط دفاعی سنگرها."));
	W4.DescriptionEnglish = FText::FromString(TEXT("Devastating suppressive fire at 1200 rounds per minute for holding trench defense lines."));
	W4.PreviewTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Weapon_Preview_MG3.Weapon_Preview_MG3"), TEXT("Textures/Weapon_Preview_MG3.png"));
	W4.DamageRating = 0.82f;
	W4.FireRateRating = 0.98f;
	W4.AccuracyRating = 0.68f;
	W4.RangeRating = 0.88f;
	W4.RecoilControlRating = 0.50f;
	W4.MobilityRating = 0.45f;
	W4.ArmorPenetrationRating = 0.70f;
	W4.MagazineCapacity = 100;
	W4.MaxReserveAmmo = 300;
	W4.RequiredPlayerLevel = 5;
	W4.XPCostToUnlock = 4500;
	W4.bDefaultUnlocked = false;

	FSquadWeaponSpecialityTrait T4_1;
	T4_1.TraitID = FName("AreaSuppression");
	T4_1.BadgeTag = TEXT("🔥 آتش سرکوبگر ۱۲۰۰ تیر");
	T4_1.TitleFarsi = FText::FromString(TEXT("زمین‌گیر کردن سراسری"));
	T4_1.TitleEnglish = FText::FromString(TEXT("Area Suppression"));
	T4_1.DescriptionFarsi = FText::FromString(TEXT("نواخت آتش فوق‌العاده؛ پرده آتش سرکوبگر متراکم که تمام امواج پیاده دشمن را در سنگرها زمین‌گیر می‌کند."));
	T4_1.DescriptionEnglish = FText::FromString(TEXT("Extreme fire rate creates a dense suppressive curtain against infantry waves."));
	W4.SpecialityTraits.Add(T4_1);
	ArmoryCatalog.Add(W4);

	// Weapon 5: SVD
	FSquadWeaponDefinition W5;
	W5.WeaponID = FName("SVD");
	W5.DisplayNameFarsi = FText::FromString(TEXT("تفنگ تک‌تیرانداز دراگونوف (SVD Dragunov)"));
	W5.DisplayNameEnglish = FText::FromString(TEXT("SVD Dragunov Marksman"));
	W5.Caliber = FText::FromString(TEXT("۷.۶۲×۵۴R تک‌تیرانداز"));
	W5.HistoricalRoleFarsi = FText::FromString(TEXT("تفنگ تک‌تیرانداز دقیق"));
	W5.HistoricalRoleEnglish = FText::FromString(TEXT("Designated Marksman Rifle"));
	W5.Category = ESquadWeaponCategory::SniperRifle;
	W5.DescriptionFarsi = FText::FromString(TEXT("دقت مرگبار دوربرد مجهز به دوربین اپتیکی، شکار تک‌تیراندازان و تیربارچی‌های سنگرنشین متخاصم."));
	W5.DescriptionEnglish = FText::FromString(TEXT("Long-range optic-equipped precision rifle for counter-sniper and machine-gunner elimination."));
	W5.PreviewTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Weapon_Preview_SVD.Weapon_Preview_SVD"), TEXT("Textures/Weapon_Preview_SVD.png"));
	W5.DamageRating = 0.96f;
	W5.FireRateRating = 0.35f;
	W5.AccuracyRating = 0.98f;
	W5.RangeRating = 1.00f;
	W5.RecoilControlRating = 0.70f;
	W5.MobilityRating = 0.65f;
	W5.ArmorPenetrationRating = 0.85f;
	W5.MagazineCapacity = 10;
	W5.MaxReserveAmmo = 60;
	W5.RequiredPlayerLevel = 7;
	W5.XPCostToUnlock = 6500;
	W5.bDefaultUnlocked = false;

	FSquadWeaponSpecialityTrait T5_1;
	T5_1.TraitID = FName("SilentMarksman");
	T5_1.BadgeTag = TEXT("👁️ تک‌تیراندازی استتاری");
	T5_1.TitleFarsi = FText::FromString(TEXT("شکار اهداف حساس"));
	T5_1.TitleEnglish = FText::FromString(TEXT("High-Value Target Hunter"));
	T5_1.DescriptionFarsi = FText::FromString(TEXT("مجهز به دوربین اپتیکی PSO-1؛ حذف آنی تیربارچی‌ها، تک‌تیراندازان و فرماندهان دشمن در فواصل ۱۰۰۰ متری."));
	T5_1.DescriptionEnglish = FText::FromString(TEXT("PSO-1 optic; eliminates machine gunners, snipers, and commanders at up to 1000 meters."));
	W5.SpecialityTraits.Add(T5_1);
	ArmoryCatalog.Add(W5);

	// 3. Achievements Catalog
	AchievementsCatalog.Empty();

	FSquadAchievement A1;
	A1.AchievementID = FName("FirstBlood");
	A1.TitleFarsi = FText::FromString(TEXT("اولین پیروزی خط‌شکن"));
	A1.TitleEnglish = FText::FromString(TEXT("First Blood"));
	A1.DisplayNameFarsi = A1.TitleFarsi;
	A1.DisplayNameEnglish = A1.TitleEnglish;
	A1.DescriptionFarsi = FText::FromString(TEXT("اولین موج متخاصم را در سنگرهای خط مقدم خنثی کنید."));
	A1.DescriptionEnglish = FText::FromString(TEXT("Neutralize the first hostile wave in the frontline trenches."));
	A1.XPReward = 350;
	A1.TargetProgress = 1.0f;
	AchievementsCatalog.Add(A1);

	FSquadAchievement A2;
	A2.AchievementID = FName("DehlaviehDefender");
	A2.TitleFarsi = FText::FromString(TEXT("مدافع غیور دهلاویه"));
	A2.TitleEnglish = FText::FromString(TEXT("Defender of Dehlavieh"));
	A2.DisplayNameFarsi = A2.TitleFarsi;
	A2.DisplayNameEnglish = A2.TitleEnglish;
	A2.DescriptionFarsi = FText::FromString(TEXT("تمام ماموریت‌های محور رودخانه کرخه و دهلاویه را با موفقیت به پایان برسانید."));
	A2.DescriptionEnglish = FText::FromString(TEXT("Complete all Karkheh and Dehlavieh front missions successfully."));
	A2.XPReward = 1500;
	A2.TargetProgress = 3.0f;
	AchievementsCatalog.Add(A2);

	FSquadAchievement A3;
	A3.AchievementID = FName("HeroicMedic");
	A3.TitleFarsi = FText::FromString(TEXT("امدادگر قهرمان میدان"));
	A3.TitleEnglish = FText::FromString(TEXT("Heroic Combat Medic"));
	A3.DisplayNameFarsi = A3.TitleFarsi;
	A3.DisplayNameEnglish = A3.TitleEnglish;
	A3.DescriptionFarsi = FText::FromString(TEXT("۵ بار همرزمان مجروح را در حین درگیری با نگه داشتن کلید E مداوا و احیا کنید."));
	A3.DescriptionEnglish = FText::FromString(TEXT("Revive wounded squadmates 5 times during combat by holding E."));
	A3.XPReward = 800;
	A3.TargetProgress = 5.0f;
	AchievementsCatalog.Add(A3);

	FSquadAchievement A4;
	A4.AchievementID = FName("RostamiHonor");
	A4.TitleFarsi = FText::FromString(TEXT("مدال افتخار سرگرد رستمی"));
	A4.TitleEnglish = FText::FromString(TEXT("Major Rostami's Medal of Honor"));
	A4.DisplayNameFarsi = A4.TitleFarsi;
	A4.DisplayNameEnglish = A4.TitleEnglish;
	A4.DescriptionFarsi = FText::FromString(TEXT("رسیدن به سطح ۵ و آزادسازی سلاح‌های سنگین زرادخانه."));
	A4.DescriptionEnglish = FText::FromString(TEXT("Reach level 5 and unlock heavy armory weapons."));
	A4.XPReward = 2500;
	A4.TargetProgress = 5.0f;
	AchievementsCatalog.Add(A4);

	// =========================================================================
	// L2-INI: [MapSelection] and [Traits] sections are now LIVE.
	// Each language slot is queried explicitly (GetStringForLanguage), so an .ar/.en
	// override never leaks Persian into English slots and vice versa; missing keys
	// keep the compiled-in defaults above.
	// =========================================================================
	if (USquadAILocalizationSubsystem* LocSys = USquadAILocalizationSubsystem::Get(this))
	{
		for (int32 mi = 0; mi < AvailableMaps.Num(); ++mi)
		{
			FSquadMapDefinition& M = AvailableMaps[mi];
			const FString Kb = FString::Printf(TEXT("Map%d"), mi + 1);
			M.DisplayNameFarsi          = FText::FromString(LocSys->GetStringForLanguage(TEXT("MapSelection"), Kb + TEXT("_Title"),    TEXT("fa"), M.DisplayNameFarsi.ToString()));
			M.DisplayNameEnglish        = FText::FromString(LocSys->GetStringForLanguage(TEXT("MapSelection"), Kb + TEXT("_Title"),    TEXT("en"), M.DisplayNameEnglish.ToString()));
			M.SituationBriefingFarsi    = FText::FromString(LocSys->GetStringForLanguage(TEXT("MapSelection"), Kb + TEXT("_Briefing"), TEXT("fa"), M.SituationBriefingFarsi.ToString()));
			M.SituationBriefingEnglish  = FText::FromString(LocSys->GetStringForLanguage(TEXT("MapSelection"), Kb + TEXT("_Briefing"), TEXT("en"), M.SituationBriefingEnglish.ToString()));
		}

		// Traits: user's Trait1..5 rows map to the signature (first) speciality trait of
		// each catalog weapon by combat role: 1=MG3 suppression, 2=AK47 desert reliability,
		// 3=G3A3 heavy caliber, 4=RPG7 tank hunter, 5=SVD marksman.
		static const int32 SignatureTraitWeapon[5] = { 3, 1, 0, 2, 4 };
		for (int32 ti = 0; ti < 5; ++ti)
		{
			const int32 wi = SignatureTraitWeapon[ti];
			if (!ArmoryCatalog.IsValidIndex(wi) || ArmoryCatalog[wi].SpecialityTraits.Num() == 0) continue;
			FSquadWeaponSpecialityTrait& T = ArmoryCatalog[wi].SpecialityTraits[0];
			const FString Kb = FString::Printf(TEXT("Trait%d"), ti + 1);
			T.TitleFarsi        = FText::FromString(LocSys->GetStringForLanguage(TEXT("Traits"), Kb + TEXT("_Name"), TEXT("fa"), T.TitleFarsi.ToString()));
			T.TitleEnglish      = FText::FromString(LocSys->GetStringForLanguage(TEXT("Traits"), Kb + TEXT("_Name"), TEXT("en"), T.TitleEnglish.ToString()));
			T.DescriptionFarsi  = FText::FromString(LocSys->GetStringForLanguage(TEXT("Traits"), Kb + TEXT("_Desc"), TEXT("fa"), T.DescriptionFarsi.ToString()));
			T.DescriptionEnglish= FText::FromString(LocSys->GetStringForLanguage(TEXT("Traits"), Kb + TEXT("_Desc"), TEXT("en"), T.DescriptionEnglish.ToString()));
		}
	}
}

TArray<FSquadProgressionNode> USquadAIProgressionSubsystem::GetProgressionNodes() const
{
	TArray<FSquadProgressionNode> Nodes;

	FSquadProgressionNode N1;
	N1.NodeID = FName("LeadershipTactics");
	N1.DisplayNameFarsi = FText::FromString(TEXT("فرماندهی و رهبری میدان"));
	N1.DisplayNameEnglish = FText::FromString(TEXT("Field Leadership"));
	N1.DescriptionFarsi = FText::FromString(TEXT("افزایش استقامت، روحیه نبرد و سرعت عکس‌العمل تمام رزمندگان جوخه در زیر آتش سنگین."));
	N1.DescriptionEnglish = FText::FromString(TEXT("Boosts stamina, morale, and reaction speed for squad members under heavy fire."));
	N1.Cost = 1;
	N1.bUnlocked = (GetAttributeRank(EPlayerAttributeType::Stamina) > 0);
	Nodes.Add(N1);

	FSquadProgressionNode N2;
	N2.NodeID = FName("PrecisionMarksmanship");
	N2.DisplayNameFarsi = FText::FromString(TEXT("دقت تیراندازی و کالیبر سنگین"));
	N2.DisplayNameEnglish = FText::FromString(TEXT("Precision Marksmanship"));
	N2.DescriptionFarsi = FText::FromString(TEXT("کاهش خطای دید، تثبیت لگد سلاح و افزایش دقت آتش دوربرد در دشت‌های باز دهلاویه."));
	N2.DescriptionEnglish = FText::FromString(TEXT("Reduces sight drift, stabilizes recoil, and improves long-range accuracy in open terrain."));
	N2.Cost = 1;
	N2.bUnlocked = (GetAttributeRank(EPlayerAttributeType::RecoilControl) > 0);
	Nodes.Add(N2);

	FSquadProgressionNode N3;
	N3.NodeID = FName("CombatEndurance");
	N3.DisplayNameFarsi = FText::FromString(TEXT("استقامت رزمنده و امدادگری"));
	N3.DisplayNameEnglish = FText::FromString(TEXT("Combat Endurance"));
	N3.DescriptionFarsi = FText::FromString(TEXT("افزایش ظرفیت سلامت، مقاومت در برابر موج انفجار و تسریع پانسمان و احیای همرزمان."));
	N3.DescriptionEnglish = FText::FromString(TEXT("Increases health capacity, blast resistance, and speeds up field revive actions."));
	N3.Cost = 1;
	N3.bUnlocked = (GetAttributeRank(EPlayerAttributeType::MaxHealth) > 0 || GetAttributeRank(EPlayerAttributeType::FieldReviveSpeed) > 0);
	Nodes.Add(N3);

	FSquadProgressionNode N4;
	N4.NodeID = FName("IrregularTactics");
	N4.DisplayNameFarsi = FText::FromString(TEXT("تاکتیک‌های نامنظم و شبیخون"));
	N4.DisplayNameEnglish = FText::FromString(TEXT("Irregular Warfare Tactics"));
	N4.DescriptionFarsi = FText::FromString(TEXT("افزایش ظرفیت حمل نارنجک‌ها و فشنگ‌های ذخیره، سرعت پیشروی و مانورهای چریکی."));
	N4.DescriptionEnglish = FText::FromString(TEXT("Increases grenade/ammo capacity, advance speed, and guerrilla maneuver ability."));
	N4.Cost = 2;
	N4.bUnlocked = (GetAttributeRank(EPlayerAttributeType::OrdnanceCapacity) > 0 || GetAttributeRank(EPlayerAttributeType::MovementSpeed) > 0);
	Nodes.Add(N4);

	FSquadProgressionNode N5;
	N5.NodeID = FName("FieldEngineering");
	N5.DisplayNameFarsi = FText::FromString(TEXT("مهندسی رزمی و استحکامات"));
	N5.DisplayNameEnglish = FText::FromString(TEXT("Combat Engineering"));
	N5.DescriptionFarsi = FText::FromString(TEXT("سرعت تعویض خشاب تاکتیکی در سنگرها و استحکام‌بخشی به جان‌پناه‌های پدافندی."));
	N5.DescriptionEnglish = FText::FromString(TEXT("Improves tactical reload speed and reinforces defensive cover positions."));
	N5.Cost = 2;
	N5.bUnlocked = (GetAttributeRank(EPlayerAttributeType::ReloadSpeed) > 0);
	Nodes.Add(N5);

	return Nodes;
}

bool USquadAIProgressionSubsystem::UnlockProgressionNode(FName NodeID)
{
	int32 Cost = 1;
	EPlayerAttributeType TargetAttr = EPlayerAttributeType::MaxHealth;

	if (NodeID == FName("LeadershipTactics"))
	{
		Cost = 1;
		TargetAttr = EPlayerAttributeType::Stamina;
	}
	else if (NodeID == FName("PrecisionMarksmanship"))
	{
		Cost = 1;
		TargetAttr = EPlayerAttributeType::RecoilControl;
	}
	else if (NodeID == FName("CombatEndurance"))
	{
		Cost = 1;
		TargetAttr = EPlayerAttributeType::MaxHealth;
	}
	else if (NodeID == FName("IrregularTactics"))
	{
		Cost = 2;
		TargetAttr = EPlayerAttributeType::OrdnanceCapacity;
	}
	else if (NodeID == FName("FieldEngineering"))
	{
		Cost = 2;
		TargetAttr = EPlayerAttributeType::ReloadSpeed;
	}

	if (ActiveProfile.AvailableSkillPoints >= Cost)
	{
		ActiveProfile.AvailableSkillPoints -= Cost;
		const uint8 AttrKey = static_cast<uint8>(TargetAttr);
		int32 CurrentRank = ActiveProfile.AttributeRanks.FindRef(AttrKey);
		ActiveProfile.AttributeRanks.Add(AttrKey, CurrentRank + 1);

		SaveProgressionToDisk();
		OnAttributeUpgraded.Broadcast(TargetAttr, CurrentRank + 1);
		OnProfileChanged.Broadcast(ActiveProfile);
		return true;
	}

	return false;
}

// =============================================================================
//  SAVE / LOAD PERSISTENCE
// =============================================================================

void USquadAIProgressionSubsystem::SaveProgressionToDisk()
{
// F-G14: removed dead SaveSys fetch (only a null-guard; the body uses UGameplayStatics directly).
	USquadAISaveGame* SaveObj = Cast<USquadAISaveGame>(UGameplayStatics::CreateSaveGameObject(USquadAISaveGame::StaticClass()));
	if (!SaveObj) return;

	SaveObj->PlayerLevel = ActiveProfile.PlayerLevel;
	SaveObj->PlayerTotalXP = ActiveProfile.TotalXP;
	SaveObj->PlayerCurrentLevelXP = ActiveProfile.CurrentLevelXP;
	SaveObj->AvailableSkillPoints = ActiveProfile.AvailableSkillPoints;
	SaveObj->EquippedWeaponID = ActiveProfile.EquippedWeaponID;
	SaveObj->AttributeUpgradeRanks = ActiveProfile.AttributeRanks;
	SaveObj->UnlockedWeaponIDs = ActiveProfile.UnlockedWeaponIDs;
	SaveObj->SavedPlayerName = ActiveProfile.PlayerName;
	SaveObj->SavedAvatarID = ActiveProfile.SelectedAvatarID;
	SaveObj->SavedBloodType = ActiveProfile.BloodType;
	SaveObj->SavedDogTagNumber = ActiveProfile.DogTagNumber;

	SaveObj->UnlockedAchievementIDs.Empty();
	for (const FSquadAchievement& Ach : AchievementsCatalog)
	{
		if (Ach.bIsUnlocked)
		{
			SaveObj->UnlockedAchievementIDs.Add(Ach.AchievementID);
		}
	}

	UGameplayStatics::SaveGameToSlot(SaveObj, TEXT("SquadAI_PlayerProgression"), 0);
	UE_LOG(LogTemp, Log, TEXT("[SquadAIProgression] Saved progression state to disk"));
}

void USquadAIProgressionSubsystem::LoadProgressionFromDisk()
{
	if (!UGameplayStatics::DoesSaveGameExist(TEXT("SquadAI_PlayerProgression"), 0)) return;

	USquadAISaveGame* Loaded = Cast<USquadAISaveGame>(UGameplayStatics::LoadGameFromSlot(TEXT("SquadAI_PlayerProgression"), 0));
	if (!Loaded) return;

	ActiveProfile.PlayerLevel = FMath::Max(1, Loaded->PlayerLevel);
	ActiveProfile.TotalXP = Loaded->PlayerTotalXP;
	ActiveProfile.CurrentLevelXP = Loaded->PlayerCurrentLevelXP;
	ActiveProfile.AvailableSkillPoints = Loaded->AvailableSkillPoints;
	if (!Loaded->SavedPlayerName.IsEmpty())
	{
		ActiveProfile.PlayerName = Loaded->SavedPlayerName;
	}
	if (!Loaded->SavedAvatarID.IsNone())
	{
		ActiveProfile.SelectedAvatarID = Loaded->SavedAvatarID;
	}
	if (!Loaded->SavedBloodType.IsEmpty())
	{
		ActiveProfile.BloodType = Loaded->SavedBloodType;
	}
	if (!Loaded->SavedDogTagNumber.IsEmpty())
	{
		ActiveProfile.DogTagNumber = Loaded->SavedDogTagNumber;
	}

	if (!Loaded->EquippedWeaponID.IsNone())
	{
		ActiveProfile.EquippedWeaponID = Loaded->EquippedWeaponID;
		if (USquadAIInventorySubsystem* Inv = USquadAIInventorySubsystem::Get(this))
		{
			Inv->SelectWeaponByID(Loaded->EquippedWeaponID);
		}
	}

	for (const auto& Pair : Loaded->AttributeUpgradeRanks)
	{
		ActiveProfile.AttributeRanks.Add(Pair.Key, Pair.Value);
	}

	for (const FName& WepID : Loaded->UnlockedWeaponIDs)
	{
		ActiveProfile.UnlockedWeaponIDs.AddUnique(WepID);
	}

	for (const FName& AchID : Loaded->UnlockedAchievementIDs)
	{
		for (FSquadAchievement& Ach : AchievementsCatalog)
		{
			if (Ach.AchievementID == AchID)
			{
				Ach.bIsUnlocked = true;
				Ach.CurrentProgress = Ach.TargetProgress;
				break;
			}
		}
	}

	if (SavedProfiles.IsValidIndex(ActiveProfileIndex))
	{
		SavedProfiles[ActiveProfileIndex] = ActiveProfile;
	}
}

#include "HUD/QuestNativeHUD.h"
#include "Utilities/SquadAIAssetHelper.h"
#include "Performance/SquadAIAssetCacheSubsystem.h"   // S26-MMAT: default minimap material
#include "AssetRegistry/AssetRegistryModule.h"
#include "AssetRegistry/AssetData.h"
#include "Modules/ModuleManager.h"
#include "Misc/PackageName.h"
#include "Blueprint/UserWidget.h"
#include "UObject/UObjectIterator.h"
#include "HUD/FarsiTextHelper.h"
#include "HAL/PlatformTime.h" // P6-5: FPlatformTime::Seconds for art-retry throttling
#include "Components/TacticalGrenadeComponent.h"
#include "Components/WeaponComponent.h"
#include "Quest/QuestChain.h"
#include "Quest/MissionZone.h"
#include "Quest/EnemyWaveSpawner.h"
#include "Characters/SoldierCharacter.h"
#include "Characters/LeaderCharacter.h"
#include "Characters/AllySoldier.h"
#include "Characters/EnemyCommander.h"           // S19-ELITE
#include "Characters/EnemyCommanderAssistant.h"
#include "Components/HealthComponent.h"
#include "Engine/Canvas.h"
#include "Engine/Font.h"
#include "Engine/Texture2D.h"
#include "Engine/TextureRenderTarget2D.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Materials/MaterialInterface.h"
#include "Components/SceneCaptureComponent2D.h"
#include "Kismet/GameplayStatics.h"
#include "Components/DecalComponent.h"
#include "Performance/SquadAILoadingScreenSubsystem.h"
#include "Kismet/KismetSystemLibrary.h"
#include "HAL/IConsoleManager.h" // S17-HINT2: replay cvar
#include "EngineUtils.h"

// ---------------------------------------------------------------------------
// S9-FIX: runtime (localised) format strings.
//
// UE 5.7 validates FString::Printf format strings at COMPILE time
// (Core/Public/String/FormatStringSan.h). Its TCheckedFormatString can only be
// consteval-constructed from a string literal, so every
//     SquadAIFormatRuntime(*SomeRuntimeFString, Args...)
// call - i.e. all of our formats coming out of SquadAILocalization.ini - is now
// a hard error. FCString::GetVarArgs still accepts a plain runtime const TCHAR*,
// so localised formats are routed through this helper instead. Behaviour and
// the %s/%d/%f placeholders in the INI are unchanged.
// ---------------------------------------------------------------------------
static FString SquadAIFormatRuntime(const TCHAR* Fmt, ...)
{
	if (!Fmt)
	{
		return FString();
	}
	TArray<TCHAR> Buffer;
	Buffer.AddUninitialized(512);
	while (true)
	{
		va_list ArgPtr;
		va_start(ArgPtr, Fmt);
		const int32 Written = FCString::GetVarArgs(Buffer.GetData(), Buffer.Num(), Fmt, ArgPtr);
		va_end(ArgPtr);

		if (Written >= 0 && Written < Buffer.Num() - 1)
		{
			break;              // fitted
		}
		if (Buffer.Num() >= 32768)
		{
			Buffer[Buffer.Num() - 1] = TEXT('\0');   // pathological format: bail out safely
			break;
		}
		Buffer.AddUninitialized(Buffer.Num());        // grow and retry
	}
	return FString(Buffer.GetData());
}
#include "SquadAITuning.h"
#include "Performance/SoldierRegistrySubsystem.h"
#include "Diagnostics/SquadAISituationLog.h"   // S19-GRENARC: the aim line
#include "Tactical/SquadAIPingSubsystem.h"
#include "Tactical/MissionClockModel.h" // S19-CLOCK (the notice banner + card readout)
#include "Tactical/SquadAICommandSubsystem.h"
#include "Actors/AmmoCrateActor.h"
#include "Actors/FirstAidKitActor.h"
#include "Actors/MedicalStationActor.h"
#include "Actors/MountedTurretActor.h"
#include "Actors/ExplosiveBarrelActor.h"
#include "Tactical/TacticalMortarBarrageActor.h"
#include "Performance/SquadAIAudioSubsystem.h"
#include "Performance/SquadAIDevDebugSubsystem.h"
#include "Tactical/SquadAIRadioChatterSubsystem.h"
#include "Localization/SquadAILocalizationSubsystem.h"
#include "SaveSystem/SquadAISaveLoadSubsystem.h"
#include "Tutorial/SquadAITutorialSubsystem.h"
#include "Tutorial/TutorialGuideActor.h"
#include "Tutorial/TutorialIntroSequence.h" // S18-INTRO // S18-TUT
#include "GameFramework/SquadAIInventorySubsystem.h"
#include "GameFramework/SquadAIProgressionSubsystem.h"
#include "GameFramework/PlayerController.h"
#include "TimerManager.h"
#include "UObject/UnrealType.h"

namespace
{
	bool SquadAIHUDIsEnglish(const UObject* Context)
	{
		if (const USquadAILocalizationSubsystem* Loc = USquadAILocalizationSubsystem::Get(Context))
		{
			// P7-L4: Arabic (and any non-Persian language) uses the English-facing defaults
			// for the hardcoded bilingual strings; INI [Section.ar] overrides localize fully.
			return !Loc->GetCurrentLanguage().StartsWith(TEXT("fa"), ESearchCase::IgnoreCase);
		}
		return false;
	}

	FString SquadAIHUDLocal(const UObject* Context, const TCHAR* Section, const TCHAR* Key, const TCHAR* PersianText, const TCHAR* EnglishText)
	{
		const bool bEnglish = SquadAIHUDIsEnglish(Context);
		if (const USquadAILocalizationSubsystem* Loc = USquadAILocalizationSubsystem::Get(Context))
		{
			return Loc->GetString(Section, Key, bEnglish ? FString(EnglishText) : FString(PersianText));
		}
		return bEnglish ? FString(EnglishText) : FString(PersianText);
	}
}

FString AQuestNativeHUD::LocalizeHUDText(const UObject* Context, const TCHAR* Section, const TCHAR* Key,
	const TCHAR* PersianText, const TCHAR* EnglishText)
{
	// SquadAIHUDLocal is in this file's anonymous namespace; this wrapper is the supported
	// way for other translation units to get the same FA/EN string.
	return SquadAIHUDLocal(Context, Section, Key, PersianText, EnglishText);
}

AQuestNativeHUD* AQuestNativeHUD::Get(const UObject* WorldContextObject)
{
	if (!WorldContextObject) return nullptr;
	UWorld* World = GEngine ? GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::ReturnNull) : nullptr;
	if (!World) return nullptr;
	APlayerController* PC = UGameplayStatics::GetPlayerController(World, 0);
	if (!PC) return nullptr;
	return Cast<AQuestNativeHUD>(PC->GetHUD());
}

void AQuestNativeHUD::BeginPlay()
{
	Super::BeginPlay();

	// Auto-resolve high-resolution vector silhouette weapon textures
	if (!HUDWeaponG3Texture) HUDWeaponG3Texture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/HUD_Weapon_G3A3.HUD_Weapon_G3A3"), TEXT("Textures/HUD_Weapon_G3A3.png"));
	if (!HUDHealthCardTexture) HUDHealthCardTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/HUD_Health_Card.HUD_Health_Card"), TEXT("Textures/HUD_Health_Card.png")); // G-12
	if (!HUDWeaponAKTexture) HUDWeaponAKTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/HUD_Weapon_AK47.HUD_Weapon_AK47"), TEXT("Textures/HUD_Weapon_AK47.png"));
	if (!HUDWeaponRPGTexture) HUDWeaponRPGTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/HUD_Weapon_RPG7.HUD_Weapon_RPG7"), TEXT("Textures/HUD_Weapon_RPG7.png"));
	if (!HUDWeaponMG3Texture) HUDWeaponMG3Texture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/HUD_Weapon_MG3.HUD_Weapon_MG3"), TEXT("Textures/HUD_Weapon_MG3.png"));
	if (!HUDWeaponSVDTexture) HUDWeaponSVDTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/HUD_Weapon_SVD.HUD_Weapon_SVD"), TEXT("Textures/HUD_Weapon_SVD.png"));
	if (!HUDWeaponUnarmedTexture) HUDWeaponUnarmedTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/HUD_Weapon_Fist.HUD_Weapon_Fist"), TEXT("Textures/HUD_Weapon_Fist.png"));
	if (!HUDWeaponUnarmedTexture) HUDWeaponUnarmedTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/HUD_Weapon_Unarmed.HUD_Weapon_Unarmed"), TEXT("Textures/HUD_Weapon_Unarmed.png"));
	if (!DeploymentVeilArtwork) DeploymentVeilArtwork = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Loading_Background_TrenchAssault.Loading_Background_TrenchAssault"), TEXT("Textures/Loading_Background_TrenchAssault.png"));
	if (!ButtonNormalTexture) ButtonNormalTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Button_Tactical_Normal.UI_Button_Tactical_Normal"), TEXT("Textures/UI_Button_Tactical_Normal.png"));
	if (!ButtonHoverTexture) ButtonHoverTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Button_Tactical_Hover.UI_Button_Tactical_Hover"), TEXT("Textures/UI_Button_Tactical_Hover.png"));
	if (!LoadingBarFrameTexture) LoadingBarFrameTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_LoadingBar_Frame.UI_LoadingBar_Frame"), TEXT("Textures/UI_LoadingBar_Frame.png"));
	if (!LoadingBarFillTexture) LoadingBarFillTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_LoadingBar_Fill.UI_LoadingBar_Fill"), TEXT("Textures/UI_LoadingBar_Fill.png"));
	if (!ItemPocketQuranTexture) ItemPocketQuranTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Item_PocketQuran.UI_Item_PocketQuran"), TEXT("Textures/UI_Item_PocketQuran.png"));
	if (!ItemPocketRadioTexture) ItemPocketRadioTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Item_PocketRadio.UI_Item_PocketRadio"), TEXT("Textures/UI_Item_PocketRadio.png"));
	if (!ItemCombatWalletTexture) ItemCombatWalletTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Item_CombatWallet.UI_Item_CombatWallet"), TEXT("Textures/UI_Item_CombatWallet.png"));
	if (!ItemFirstAidPouchTexture) ItemFirstAidPouchTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Item_FirstAidPouch.UI_Item_FirstAidPouch"), TEXT("Textures/UI_Item_FirstAidPouch.png"));
	if (!ItemCanteenTexture) ItemCanteenTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Item_Canteen.UI_Item_Canteen"), TEXT("Textures/UI_Item_Canteen.png"));
	if (!ItemDogTagTexture) ItemDogTagTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Item_DogTag.UI_Item_DogTag"), TEXT("Textures/UI_Item_DogTag.png"));
	if (!FallenNotesArtwork) FallenNotesArtwork = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_FallenNotes_Background.UI_FallenNotes_Background"), TEXT("Textures/UI_FallenNotes_Background.png"));

	// S27-CRASHFIX: Pre-warm HUD font and all UI textures during BeginPlay on the
	// Game Thread so nothing needs to load lazily inside StreamingPauseRendering / DrawHUD.
	GetHUDFont();
	static const TCHAR* PrewarmUIKeys[] = {
		TEXT("GlassPanel"), TEXT("OpBanner"), TEXT("FocusCard"),
		TEXT("StepTile"), TEXT("StepTileCurrent"), TEXT("ObjectiveWash"),
		TEXT("VitalsTile"), TEXT("SlotActive"),
		TEXT("RadarMap"), TEXT("MedallionIdle"), TEXT("MedallionActive"), TEXT("MedallionDone"),
		TEXT("TaskforceInsignia"), TEXT("IconRunner3D"), TEXT("ArmorShield3D"),
		TEXT("IconReticle3D"), TEXT("IconFlag3D"), TEXT("IconObjectiveFire3D"),
		TEXT("IconObjectives3D"), TEXT("IconSettings3D"), TEXT("IconRifle3D"),
		TEXT("IconSidearm3D"), TEXT("IconStance3D"), TEXT("HealthCrest3D"),
		TEXT("KeycapFrame"), TEXT("SquadAlpha1"), TEXT("SquadAlpha2"), TEXT("SquadAlpha3")
	};
	for (const TCHAR* KeyName : PrewarmUIKeys)
	{
		GetUITexture(FName(KeyName));
	}

	// Ensure all reference HUD plates are enabled even if an older Blueprint CDO serialized false
	bEnableTacticalCompassRibbon = true;
	bEnableSquadStatusPanel = true;
	bEnableNativeWeaponStatusPlate = true;
	bEnableMissionObjectiveCard = true;
	bShowTutorialChecklist = true;

	// NO-UMG-QUESTHUD: gameplay HUD is Canvas-native only. Do not spawn/call WBP_QuestHUD
	// or the older QuestHUDWidget stack from code; if a map/Blueprint still adds one, collapse it.
	bSuppressLegacyUMG = true;
	if (UWorld* World = GetWorld())
	{
		// P6-6/P7-UI1: deny-by-default startup sweep (see periodic sweep for the full rationale).
		SquadAISuppressForeignViewportWidgets(World);
	}
}

// ===== P6-6: viewport-widget ownership allow-list + deny-default suppression =====
static TSet<TWeakObjectPtr<UUserWidget>>& SquadAIAllowedViewportWidgets()
{
	static TSet<TWeakObjectPtr<UUserWidget>> Allowed;
	return Allowed;
}

void AQuestNativeHUD::RegisterAllowedViewportWidget(UUserWidget* W)
{
	if (W) SquadAIAllowedViewportWidgets().Add(W);
}

bool AQuestNativeHUD::IsAllowedViewportWidget(const UUserWidget* W)
{
	if (!W) return false;
	const TSet<TWeakObjectPtr<UUserWidget>>& Allowed = SquadAIAllowedViewportWidgets();
	for (const TWeakObjectPtr<UUserWidget>& Entry : Allowed)
	{
		if (Entry.Get() == W) return true;
	}
	// SquadAI's own C++ widget classes stay allowed (named ClassName, e.g. loading screen
	// without a Blueprint wrapper). Legacy SquadAI widgets (QuestHUDWidget, CompassWidget,
	// ...) intentionally do NOT match this prefix, so the Canvas-only policy still applies.
	const FString ClassName = W->GetClass() ? W->GetClass()->GetName() : FString();
	return ClassName.StartsWith(TEXT("SquadAI"));
}

int32 AQuestNativeHUD::SquadAISuppressForeignViewportWidgets(UWorld* World)
{
	if (!World) return 0;
	int32 NeutralizedCount = 0;
	for (TObjectIterator<UUserWidget> It; It; ++It)
	{
		UUserWidget* W = *It;
		if (!W || W->GetWorld() != World) continue;
		if (IsAllowedViewportWidget(W)) continue;
		if (!W->IsInViewport()) continue; // offscreen widgets are invisible anyway
		if (W->GetVisibility() == ESlateVisibility::Collapsed) continue; // already neutralized — lets the periodic sweep go idle
		// Collapse (not RemoveFromParent): pack UIs re-add their HUD when it is destroyed;
		// a collapsed widget keeps its state but never renders over the Canvas HUD again.
		W->SetVisibility(ESlateVisibility::Collapsed);
		++NeutralizedCount;
	}
	return NeutralizedCount;
}

UTexture2D* AQuestNativeHUD::GetHUDWeaponIcon(const FString& WeaponName) const
{
	if (WeaponName.Contains(TEXT("AK")) || WeaponName.Contains(TEXT("کلاش")) || WeaponName.Contains(TEXT("AK47")) || WeaponName.Contains(TEXT("AKM"))) return HUDWeaponAKTexture.Get();
	if (WeaponName.Contains(TEXT("RPG")) || WeaponName.Contains(TEXT("آرپی‌جی")) || WeaponName.Contains(TEXT("Rocket"))) return HUDWeaponRPGTexture.Get();
	if (WeaponName.Contains(TEXT("MG3")) || WeaponName.Contains(TEXT("ام‌جی")) || WeaponName.Contains(TEXT("تیربار")) || WeaponName.Contains(TEXT("MachineGun"))) return HUDWeaponMG3Texture.Get();
	if (WeaponName.Contains(TEXT("SVD")) || WeaponName.Contains(TEXT("دراگونوف")) || WeaponName.Contains(TEXT("Sniper"))) return HUDWeaponSVDTexture.Get();
	if (WeaponName.Contains(TEXT("Unarmed")) || WeaponName.Contains(TEXT("Fist")) || WeaponName.Contains(TEXT("بدون")) || WeaponName.Contains(TEXT("تن‌به‌تن")) || WeaponName.Contains(TEXT("Knife"))) return HUDWeaponUnarmedTexture.Get();
	if (WeaponName.Contains(TEXT("G3")) || WeaponName.Contains(TEXT("ژ-۳")) || WeaponName.Contains(TEXT("G3A3")) || WeaponName.Contains(TEXT("Rifle"))) return HUDWeaponG3Texture.Get();
	return HUDWeaponG3Texture.Get();
}

void AQuestNativeHUD::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(MinimapCaptureTimer);
	}
	Super::EndPlay(EndPlayReason);
}

void AQuestNativeHUD::NotifyDamageReceived(const FVector& DamageSourceLocation, float DamageAmount)
{
	if (DamageAmount > 0.f)
	{
		HUDDamageAccumulated = FMath::Clamp(HUDDamageAccumulated + (DamageAmount / 100.f), 0.f, 0.95f);
	}
	if (!bEnableDamageDirectionIndicators) return;
	if (DamageSourceLocation.IsNearlyZero()) return; // Discard invalid/zero origin coordinates!

	FDamageHitIndicator NewIndicator;
	NewIndicator.WorldSourceLocation = DamageSourceLocation;
	NewIndicator.DamageAmount = DamageAmount;
	NewIndicator.MaxLifetime = 1.25f;
	NewIndicator.TimeRemaining = 1.25f;

	ActiveDamageIndicators.Add(NewIndicator);

	if (ActiveDamageIndicators.Num() > 8)
	{
		ActiveDamageIndicators.RemoveAt(0);
	}
}

void AQuestNativeHUD::NotifyHitConfirmed(bool bKilledTarget)
{
	if (!bEnableHitMarkers) return;

	HitMarkerTimeRemaining = HitMarkerDuration;
	bHitMarkerIsKill = bKilledTarget;

	// S18-FEED: confirmed kills are worth a line; plain hits are not.
	if (bKilledTarget)
	{
		AddFeedEntry(SquadAIHUDLocal(this, TEXT("Feed"), TEXT("EnemyKilled"),
			TEXT("دشمن از پا درآمد"), TEXT("Enemy neutralised")), ESquadAIFeedKind::Kill);
	}
}

void AQuestNativeHUD::NotifyAllyDowned(const FVector& Location, const FText& AllyName)
{
	AllyDownedAlertTime = 6.0f;
	FString CleanName = AllyName.ToString();
	if (SquadAIHUDIsEnglish(this))
	{
		if (CleanName.IsEmpty() || CleanName.Contains(TEXT("رزمنده"), ESearchCase::IgnoreCase))
		{
			CleanName = TEXT("Squad Fighter");
		}
		else if (CleanName.Contains(TEXT("رستمی"), ESearchCase::IgnoreCase) || CleanName.Contains(TEXT("ایرج"), ESearchCase::IgnoreCase))
		{
			CleanName = TEXT("Major Rostami");
		}
	}
	LastDownedAllyName = FText::FromString(CleanName);
	LastDownedAllyLocation = Location;

	// S18-FEED
	{
		const FString AllyFmt = SquadAIHUDLocal(this, TEXT("Feed"), TEXT("AllyDownFmt"),
			TEXT("%s مجروح شد"), TEXT("%s is down"));
		// Printf with a runtime format string is unsafe, so substitute by hand.
		FString AllyLine = AllyFmt;
		if (AllyLine.Contains(TEXT("%s"))) { AllyLine = AllyLine.Replace(TEXT("%s"), *CleanName); }
		else { AllyLine = CleanName + TEXT(" ") + AllyLine; }
		AddFeedEntry(AllyLine, ESquadAIFeedKind::Ally);
	}
}

void AQuestNativeHUD::SetPlayerBurning(bool bBurning)
{
	bIsPlayerBurning = bBurning;
}

void AQuestNativeHUD::AddPlayerSuppression(float Amount)
{
	PlayerSuppression = FMath::Clamp(PlayerSuppression + Amount, 0.f, 1.f);
}

void AQuestNativeHUD::RebuildSoldierDots()
{
	CachedSoldierDots.Reset();
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}

	auto AddDot = [this](ASoldierCharacter* S)
	{
		if (!S || !S->IsAlive())
		{
			return;
		}
		FMinimapSoldierDot Dot;
		Dot.WorldLoc = S->GetActorLocation();
		Dot.bIsDowned = S->IsDowned();
		if (S->IsAlly())
		{
			Dot.bAlly = true;
		}
		else if (S->IsEnemy())
		{
			Dot.bAlly = false;
		}
		else
		{
			return;
		}

		// S19-ELITE: elites get their own marker shape on the minimap.
		if (const AEnemyCommander* Cmd = Cast<AEnemyCommander>(S))
		{
			Dot.bIsCommander = true;
		}
		else if (Cast<AEnemyCommanderAssistant>(S))
		{
			Dot.bIsAssistant = true;
		}

		CachedSoldierDots.Add(Dot);
	};

	if (USoldierRegistrySubsystem* Reg = World->GetSubsystem<USoldierRegistrySubsystem>())
	{
		for (const TWeakObjectPtr<ASoldierCharacter>& WeakS : Reg->GetAllSoldiers())
		{
			AddDot(WeakS.Get());
		}
	}
	else
	{
		for (TActorIterator<ASoldierCharacter> It(World); It; ++It)
		{
			AddDot(*It);
		}
	}
}

AQuestChain* AQuestNativeHUD::FindQuestChain()
{
	// S5-11a: the cached chain used to stick forever — a finished chain kept the card bound
	// even when another mission authority became active. Re-resolve whenever it completes.
	if (AQuestChain* C = CachedChain.Get())
	{
		if (!C->bIsCompleted) return C;
		CachedChain.Reset();
	}
	if (!GetWorld()) return nullptr;
	if (AQuestChain* Chain = AQuestChain::FindPreferred(GetWorld(), false))
	{
		CachedChain = Chain;
		return Chain;
	}
	return nullptr;
}

AActor* AQuestNativeHUD::FindCachedLeader()
{
	if (AActor* L = CachedLeader.Get())
	{
		return L;
	}
	UWorld* World = GetWorld();
	if (!World)
	{
		return nullptr;
	}
	if (USoldierRegistrySubsystem* Reg = World->GetSubsystem<USoldierRegistrySubsystem>())
	{
		for (const TWeakObjectPtr<ASoldierCharacter>& W : Reg->GetAllSoldiers())
		{
			if (ALeaderCharacter* Leader = Cast<ALeaderCharacter>(W.Get()))
			{
				CachedLeader = Leader;
				return Leader;
			}
		}
	}
	for (TActorIterator<ALeaderCharacter> It(World); It; ++It)
	{
		CachedLeader = *It;
		return *It;
	}
	return nullptr;
}

UFont* AQuestNativeHUD::GetHUDFont() const
{
	const USquadAITuning* T = USquadAITuning::Get();
	const FString DesiredPath = (T && !T->HUDFontPath.IsEmpty())
		? T->HUDFontPath
		: FString(TEXT("/Game/Fonts/SquadAI_HUD.SquadAI_HUD"));

	static UFont* CachedFont = nullptr;
	static FString CachedPath;
	static bool bResolveAttempted = false;

	if (!bResolveAttempted || CachedPath != DesiredPath || (CachedFont && !IsValid(CachedFont)))
	{
		bResolveAttempted = true;
		CachedPath = DesiredPath;
		CachedFont = FSquadAIAssetHelper::LoadFontSafe(*DesiredPath, TEXT("Fonts/SquadAI_HUD.ttf"));
		if (!CachedFont)
		{
			UE_LOG(LogTemp, Warning, TEXT("[SquadAIHUD] HUD font '%s' not found and no TTF in Content/Fonts - falling back to the engine font."), *DesiredPath);
		}
		else
		{
			UE_LOG(LogTemp, Log, TEXT("[SquadAIHUD] HUD font resolved: %s (%s)"), *DesiredPath, *CachedFont->GetName());
		}
	}
	if (CachedFont && IsValid(CachedFont))
	{
		return CachedFont;
	}
	if (T && T->HUDFont && IsValid(T->HUDFont))
	{
		return T->HUDFont;
	}
	return GEngine ? GEngine->GetMediumFont() : nullptr;
}

void AQuestNativeHUD::DrawFarsiText(const FString& Text, const FLinearColor& Color, float X, float Y, UFont* Font, float Scale, bool bScalePosition)
{
	if (!Canvas || Text.IsEmpty()) return;
	FString Shaped;
	if (const FString* Cached = ShapedTextFrameCache.Find(Text)) { Shaped = *Cached; }
	else { Shaped = UFarsiTextHelper::ShapeAndOrder(Text); ShapedTextFrameCache.Add(Text, Shaped); }
	UFont* BaseFont = Font ? Font : GetHUDFont();
	const float EffectiveScale = Scale * HUDFontScale;
	const int32 TargetPt = FMath::Clamp(FMath::RoundToInt(13.0f * EffectiveScale), 7, 36);
	UFont* SizedFont = FSquadAIAssetHelper::GetHUDFontAtSize(TargetPt, BaseFont);
	if (!SizedFont) SizedFont = BaseFont;
	const float DrawX = FMath::RoundToFloat(X);
	const float DrawY = FMath::RoundToFloat(Y);
	{
		FLinearColor DS(0.f, 0.f, 0.f, Color.A * 0.72f);
		DrawText(Shaped, DS, DrawX, DrawY + 1.0f, SizedFont, 1.0f, bScalePosition);
	}
	DrawText(Shaped, Color, DrawX, DrawY, SizedFont, 1.0f, bScalePosition);
}

void AQuestNativeHUD::GetFarsiTextSize(const FString& Text, UFont* Font, float Scale, float& OutW, float& OutH) const
{
	OutW = 0.f;
	OutH = 0.f;
	if (!Canvas || Text.IsEmpty()) return;

	FString ShapedText;
	if (const FString* Cached = ShapedTextFrameCache.Find(Text)) { ShapedText = *Cached; }
	else { ShapedText = UFarsiTextHelper::ShapeAndOrder(Text); ShapedTextFrameCache.Add(Text, ShapedText); }
	UFont* BaseFont = Font ? Font : GetHUDFont();
	if (!BaseFont) return;
	const float HUDS = Scale * HUDFontScale;
	const int32 TargetPt = FMath::Clamp(FMath::RoundToInt(13.0f * HUDS), 7, 36);
	UFont* SizedFont = FSquadAIAssetHelper::GetHUDFontAtSize(TargetPt, BaseFont);
	if (!SizedFont) SizedFont = BaseFont;

	Canvas->TextSize(SizedFont, ShapedText, OutW, OutH, 1.0f, 1.0f);
	if (OutW <= 0.f) OutW = ShapedText.Len() * 10.f * HUDS;
	if (OutH <= 0.f) OutH = 16.f * HUDS;
}

void AQuestNativeHUD::DrawFarsiTextBounded(const FString& Text, const FLinearColor& Color, float X, float Y, float MaxWidth, UFont* Font, float PreferredScale, bool bDropShadow, bool bCenterHorizontal, float BoxHeight, bool bRightAlign)
{
	if (!Canvas || Text.IsEmpty() || MaxWidth <= 0.f) return;

	FString ShapedText;
	if (const FString* Cached = ShapedTextFrameCache.Find(Text)) { ShapedText = *Cached; }
	else { ShapedText = UFarsiTextHelper::ShapeAndOrder(Text); ShapedTextFrameCache.Add(Text, ShapedText); }
	UFont* BaseFont = Font ? Font : GetHUDFont();
	if (!BaseFont) return;

	const float RequestedScale = PreferredScale * HUDFontScale;
	int32 TargetPt = FMath::Clamp(FMath::RoundToInt(13.0f * RequestedScale), 7, 36);
	UFont* SizedFont = FSquadAIAssetHelper::GetHUDFontAtSize(TargetPt, BaseFont);
	if (!SizedFont) SizedFont = BaseFont;

	float RenderW = 0.f, RenderH = 0.f;
	Canvas->TextSize(SizedFont, ShapedText, RenderW, RenderH, 1.0f, 1.0f);
	if (RenderW <= 0.f) RenderW = ShapedText.Len() * 10.f * RequestedScale;
	if (RenderH <= 0.f) RenderH = 16.f * RequestedScale;

	float DrawScale = 1.0f;
	if (RenderW > MaxWidth)
	{
		const int32 FittedPt = FMath::Clamp(FMath::FloorToInt(TargetPt * (MaxWidth / RenderW)), 6, TargetPt);
		if (FittedPt < TargetPt)
		{
			TargetPt = FittedPt;
			if (UFont* SmallerFont = FSquadAIAssetHelper::GetHUDFontAtSize(TargetPt, BaseFont))
			{
				SizedFont = SmallerFont;
			}
			Canvas->TextSize(SizedFont, ShapedText, RenderW, RenderH, 1.0f, 1.0f);
		}
		if (RenderW > MaxWidth && RenderW > 0.f)
		{
			DrawScale = MaxWidth / RenderW;
			RenderW *= DrawScale;
			RenderH *= DrawScale;
		}
	}

	float DrawX = X;
	if (bCenterHorizontal)
	{
		DrawX = X + (MaxWidth - RenderW) * 0.5f;
	}
	else if (bRightAlign)
	{
		DrawX = X + (MaxWidth - RenderW);
	}

	float DrawY = Y;
	if (BoxHeight > 0.f)
	{
		DrawY = Y + (BoxHeight - RenderH) * 0.5f;
	}

	// Snap to integer screen coordinates so 1:1 FreeType glyphs never undergo GPU bilinear texel smearing
	DrawX = FMath::RoundToFloat(DrawX);
	DrawY = FMath::RoundToFloat(DrawY);

	if (bDropShadow)
	{
		Canvas->SetDrawColor(FLinearColor(0.f, 0.f, 0.f, Color.A * 0.68f).ToFColor(true));
		Canvas->DrawText(SizedFont, ShapedText, DrawX, DrawY + 1.0f, DrawScale, DrawScale);
	}

	Canvas->SetDrawColor(Color.ToFColor(true));
	Canvas->DrawText(SizedFont, ShapedText, DrawX, DrawY, DrawScale, DrawScale);
}

void AQuestNativeHUD::EnsureHUDBackdropBlur(APlayerController* PC, APawn* PlayerPawn)
{
	UWorld* World = GetWorld();
	if (!World || !World->IsGameWorld() || !PC)
	{
		return;
	}

	if (!HUDBlurRT || !IsValid(HUDBlurRT))
	{
		HUDBlurRT = NewObject<UTextureRenderTarget2D>(this, TEXT("HUDBlurRT"));
		if (HUDBlurRT)
		{
			HUDBlurRT->RenderTargetFormat = ETextureRenderTargetFormat::RTF_RGBA8_SRGB;
			HUDBlurRT->Filter = TF_Bilinear;
			HUDBlurRT->AddressX = TA_Clamp;
			HUDBlurRT->AddressY = TA_Clamp;
			HUDBlurRT->ClearColor = FLinearColor(0.08f, 0.08f, 0.07f, 1.0f);
			// 160x90 is 12x downsampled from 1920x1080: hardware bilinear filtering gives an
			// immediate 12px pre-blur at negligible GPU cost (<0.08 ms).
			HUDBlurRT->InitCustomFormat(160, 90, PF_B8G8R8A8, false);
			HUDBlurRT->UpdateResourceImmediate(true);
		}
	}

	if (!HUDBlurMID || !IsValid(HUDBlurMID))
	{
		if (USquadAIAssetCacheSubsystem* Cache = USquadAIAssetCacheSubsystem::Get(this))
		{
			if (UMaterial* BlurMat = Cache->EnsureHUDFrostedBlurMaterial())
			{
				HUDBlurMID = UMaterialInstanceDynamic::Create(BlurMat, this);
			}
		}
	}
	if (HUDBlurMID && HUDBlurRT)
	{
		HUDBlurMID->SetTextureParameterValue(FName("BlurTexture"), HUDBlurRT);
		HUDBlurMID->SetVectorParameterValue(FName("BlurTint"), FLinearColor(0.80f, 0.82f, 0.79f, 1.0f));
		HUDBlurMID->SetScalarParameterValue(FName("BlurOpacity"), 0.46f);
	}

	AActor* OwnerActor = PlayerPawn ? static_cast<AActor*>(PlayerPawn) : static_cast<AActor*>(PC);
	if (!HUDBlurCapture || !IsValid(HUDBlurCapture) || HUDBlurCapture->IsBeingDestroyed() || HUDBlurCapturePawn.Get() != PlayerPawn)
	{
		if (HUDBlurCapture && !HUDBlurCapture->IsBeingDestroyed())
		{
			HUDBlurCapture->DestroyComponent();
		}
		HUDBlurCapture = NewObject<USceneCaptureComponent2D>(OwnerActor, TEXT("HUDBlurCapture"));
		if (HUDBlurCapture)
		{
			HUDBlurCapture->RegisterComponent();
			HUDBlurCapture->TextureTarget = HUDBlurRT;
			HUDBlurCapture->ProjectionType = ECameraProjectionMode::Perspective;
			HUDBlurCapture->CaptureSource = ESceneCaptureSource::SCS_FinalColorLDR;
			HUDBlurCapture->bCaptureEveryFrame = false;
			HUDBlurCapture->bCaptureOnMovement = false;
			HUDBlurCapture->bAlwaysPersistRenderingState = true;
			// Keep Atmosphere, Fog, Lighting, PostProcessing, and EyeAdaptation enabled so the
			// captured scene exposure matches the player's viewport camera.
			HUDBlurCapture->ShowFlags.SetAtmosphere(true);
			HUDBlurCapture->ShowFlags.SetFog(true);
			HUDBlurCapture->ShowFlags.SetLighting(true);
			HUDBlurCapture->ShowFlags.SetPostProcessing(true);
			HUDBlurCapture->ShowFlags.SetEyeAdaptation(true);
			HUDBlurCapture->ShowFlags.SetDynamicShadows(false);
			HUDBlurCapture->ShowFlags.SetParticles(false);
			HUDBlurCapture->ShowFlags.SetVolumetricFog(false);
			HUDBlurCapture->ShowFlags.SetMotionBlur(false);
			HUDBlurCapture->ShowFlags.SetDepthOfField(false);
			HUDBlurCapture->ShowFlags.SetBloom(false);
			HUDBlurCapture->ShowFlags.SetAmbientOcclusion(false);
			HUDBlurCapture->ShowFlags.SetTemporalAA(false);
			HUDBlurCapturePawn = PlayerPawn;
			LastHUDBlurCaptureTime = -100.0;
		}
	}

	if (!HUDBlurCapture || !HUDBlurRT)
	{
		return;
	}

	FVector CamLoc = FVector::ZeroVector;
	FRotator CamRot = FRotator::ZeroRotator;
	PC->GetPlayerViewPoint(CamLoc, CamRot);
	float CamFOV = 90.f;
	if (PC->PlayerCameraManager)
	{
		if (PC->PlayerCameraManager->GetFOVAngle() > 10.f)
		{
			CamFOV = PC->PlayerCameraManager->GetFOVAngle();
		}
		HUDBlurCapture->PostProcessSettings = PC->PlayerCameraManager->GetCameraCacheView().PostProcessSettings;
		HUDBlurCapture->PostProcessBlendWeight = 1.0f;
	}

	const double NowReal = FPlatformTime::Seconds();
	const bool bMoved = FVector::DistSquared(CamLoc, LastHUDBlurCamLoc) > 9.f
		|| !CamRot.Equals(LastHUDBlurCamRot, 0.25f);
	if (bMoved || (NowReal - LastHUDBlurCaptureTime) > 0.033)
	{
		HUDBlurCapture->SetWorldLocationAndRotation(CamLoc, CamRot);
		HUDBlurCapture->FOVAngle = CamFOV;
		HUDBlurCapture->CaptureScene();
		LastHUDBlurCamLoc = CamLoc;
		LastHUDBlurCamRot = CamRot;
		LastHUDBlurCaptureTime = NowReal;
	}
}

void AQuestNativeHUD::DrawFrostedGlassBackdrop(float X, float Y, float W, float H, float Alpha)
{
	if (!Canvas || W <= 6.f || H <= 6.f || Alpha <= 0.001f)
	{
		return;
	}
	const float SW = FMath::Max(1.f, static_cast<float>(Canvas->ClipX));
	const float SH = FMath::Max(1.f, static_cast<float>(Canvas->ClipY));

	if (HUDBlurRT && HUDBlurRT->GetResource())
	{
		const float RX = FMath::RoundToFloat(X);
		const float RY = FMath::RoundToFloat(Y);
		const float RW = FMath::RoundToFloat(W);
		const float RH = FMath::RoundToFloat(H);
		const float dU1 = 6.0f / SW;
		const float dV1 = 6.0f / SH;
		const float dU2 = 12.0f / SW;
		const float dV2 = 12.0f / SH;

		const FLinearColor BaseOpaqueTint(0.82f, 0.84f, 0.81f, 1.0f);

		auto DrawBlurStrip = [&](float SX, float SY, float SWid, float SHei)
		{
			if (SWid <= 0.f || SHei <= 0.f) return;
			const float U0 = FMath::Clamp(SX / SW, 0.f, 1.f);
			const float V0 = FMath::Clamp(SY / SH, 0.f, 1.f);
			const float ULen = FMath::Clamp(SWid / SW, 0.001f, 1.f - U0);
			const float VLen = FMath::Clamp(SHei / SH, 0.001f, 1.f - V0);

			// Pass 0 (EBlendMode::BLEND_Opaque): completely replaces the sharp 3D viewport pixels
			// inside the HUD box with the 12x downsampled bilinearly-filtered scene capture,
			// ignoring SceneCapture's inverse/zero alpha channel!
			DrawTexture(HUDBlurRT, SX, SY, SWid, SHei, U0, V0, ULen, VLen, BaseOpaqueTint, EBlendMode::BLEND_Opaque);

			// Passes 1..4: 5-tap diagonal Gaussian blur material convolved across 4 orthogonal
			// anti-diagonal offsets (5x5 = 25-tap 2D Gaussian blur kernel, ~24px radius).
			if (HUDBlurMID)
			{
				Canvas->K2_DrawMaterial(HUDBlurMID, FVector2D(SX, SY), FVector2D(SWid, SHei),
					FVector2D(FMath::Clamp(U0 - dU1, 0.f, 1.f), FMath::Clamp(V0 + dV1, 0.f, 1.f)), FVector2D(ULen, VLen));
				Canvas->K2_DrawMaterial(HUDBlurMID, FVector2D(SX, SY), FVector2D(SWid, SHei),
					FVector2D(FMath::Clamp(U0 + dU1, 0.f, 1.f), FMath::Clamp(V0 - dV1, 0.f, 1.f)), FVector2D(ULen, VLen));
				Canvas->K2_DrawMaterial(HUDBlurMID, FVector2D(SX, SY), FVector2D(SWid, SHei),
					FVector2D(FMath::Clamp(U0 - dU2, 0.f, 1.f), FMath::Clamp(V0 + dV2, 0.f, 1.f)), FVector2D(ULen, VLen));
				Canvas->K2_DrawMaterial(HUDBlurMID, FVector2D(SX, SY), FVector2D(SWid, SHei),
					FVector2D(FMath::Clamp(U0 + dU2, 0.f, 1.f), FMath::Clamp(V0 - dV2, 0.f, 1.f)), FVector2D(ULen, VLen));
			}
		};

		// 3 non-overlapping integer-aligned horizontal strips clipped inside the 8px rounded corners
		if (RH > 10.f && RW > 10.f)
		{
			DrawBlurStrip(RX + 4.f, RY + 2.f, RW - 8.f, 2.f);
			DrawBlurStrip(RX + 2.f, RY + 4.f, RW - 4.f, RH - 8.f);
			DrawBlurStrip(RX + 4.f, RY + RH - 4.f, RW - 8.f, 2.f);
		}
		else
		{
			DrawBlurStrip(RX + 1.f, RY + 1.f, RW - 2.f, RH - 2.f);
		}
	}
}

void AQuestNativeHUD::DrawCleanPanelBorder(float X, float Y, float W, float H, const FLinearColor& BorderCol, const FLinearColor& TopInnerCol, const FLinearColor& BotInnerCol, float S)
{
	if (!Canvas || W <= 2.f || H <= 2.f)
	{
		return;
	}
	const float RX = FMath::RoundToFloat(X);
	const float RY = FMath::RoundToFloat(Y);
	const float RW = FMath::RoundToFloat(W);
	const float RH = FMath::RoundToFloat(H);

	if (TopInnerCol.A > 0.001f)
	{
		DrawRect(TopInnerCol, RX + 1.f, RY + 1.f, RW - 2.f, 1.f);
	}
	if (BotInnerCol.A > 0.001f)
	{
		DrawRect(BotInnerCol, RX + 1.f, RY + RH - 2.f, RW - 2.f, 1.f);
	}
	if (BorderCol.A > 0.001f)
	{
		DrawRect(BorderCol, RX, RY, RW, 1.f);
		DrawRect(BorderCol, RX, RY + RH - 1.f, RW, 1.f);
		DrawRect(BorderCol, RX, RY, 1.f, RH);
		DrawRect(BorderCol, RX + RW - 1.f, RY, 1.f, RH);
	}
}

void AQuestNativeHUD::Draw9SliceRoundedBox(float X, float Y, float W, float H, const FName& TexKey, float Alpha, float S,
	float CornerRadiusScale, bool bFrostedBlur, float BlurAlpha)
{
	if (!Canvas || W <= 2.f || H <= 2.f || Alpha <= 0.001f)
	{
		return;
	}

	if (bFrostedBlur && BlurAlpha > 0.001f)
	{
		DrawFrostedGlassBackdrop(X, Y, W, H, BlurAlpha * FMath::Clamp(Alpha, 0.f, 1.f));
	}

	UTexture2D* Tex = GetUITexture(TexKey);
	if (!Tex)
	{
		DrawRect(FSquadAIHUDPalette::SRGB(20, 23, 22, 0.78f * Alpha), X, Y, W, H);
		DrawCleanPanelBorder(X, Y, W, H,
			FSquadAIHUDPalette::SRGB(226, 216, 196, 0.45f * Alpha),
			FSquadAIHUDPalette::SRGB(255, 255, 255, 0.18f * Alpha),
			FSquadAIHUDPalette::SRGB(0, 0, 0, 0.65f * Alpha), S);
		return;
	}

	// Snap box to integer pixel grid; M is an even integer so P = M/2 is also an exact integer
	// and P / (P + M) == 1/3 identically (matching the 16-texel outer pad : 32-texel inner corner in our 256x256 9-slice textures).
	const float RX = FMath::RoundToFloat(X);
	const float RY = FMath::RoundToFloat(Y);
	const float RW = FMath::Max(4.f, FMath::RoundToFloat(W));
	const float RH = FMath::Max(4.f, FMath::RoundToFloat(H));

	const float RawM = FMath::Min3(8.0f * S * CornerRadiusScale, RW * 0.48f, RH * 0.48f);
	const float M = FMath::Max(2.0f, FMath::RoundToFloat(RawM * 0.5f) * 2.0f);
	const float P = M * 0.5f;

	const float XCoords[4] = { RX - P, RX + M, RX + RW - M, RX + RW + P };
	const float YCoords[4] = { RY - P, RY + M, RY + RH - M, RY + RH + P };
	const float UVs[4]     = { 0.0f, 0.1875f, 0.8125f, 1.0f }; // 48/256 = 0.1875, 208/256 = 0.8125

	const FLinearColor Tint(1.f, 1.f, 1.f, FMath::Clamp(Alpha, 0.f, 1.f));
	for (int32 Row = 0; Row < 3; ++Row)
	{
		const float DY = YCoords[Row + 1] - YCoords[Row];
		if (DY <= 0.f) continue;
		const float V0 = UVs[Row];
		const float VL = UVs[Row + 1] - V0;
		for (int32 Col = 0; Col < 3; ++Col)
		{
			const float DX = XCoords[Col + 1] - XCoords[Col];
			if (DX <= 0.f) continue;
			const float U0 = UVs[Col];
			const float UL = UVs[Col + 1] - U0;
			DrawTexture(Tex, XCoords[Col], YCoords[Row], DX, DY, U0, V0, UL, VL, Tint);
		}
	}
}

void AQuestNativeHUD::InitMinimap(APawn* PlayerPawn)
{
	// B6-20: the capture component is outered to the pawn — after a respawn/possess
	// change (or a destroyed component) tear down and re-init instead of freezing
	// on a stale render target.
	if (bMinimapInitialized)
	{
		if (PlayerPawn && MinimapCapturePawn == PlayerPawn && MinimapCapture && !MinimapCapture->IsBeingDestroyed())
		{
			return;
		}
		if (MinimapCapture)
		{
			MinimapCapture->DestroyComponent();
			MinimapCapture = nullptr;
		}
		bMinimapInitialized = false;
	}
	if (!PlayerPawn || !GetWorld()) return;
	MinimapRT = NewObject<UTextureRenderTarget2D>(this);
	const int32 Res = FMath::Clamp(MinimapResolution, 64, 512);
	MinimapRT->InitCustomFormat(Res, Res, PF_B8G8R8A8, false);
	MinimapRT->UpdateResourceImmediate(true);
	MinimapCapture = NewObject<USceneCaptureComponent2D>(PlayerPawn, TEXT("MinimapCapture"));
	MinimapCapture->RegisterComponent();
	MinimapCapture->AttachToComponent(PlayerPawn->GetRootComponent(), FAttachmentTransformRules::SnapToTargetNotIncludingScale);
	MinimapCapture->SetRelativeLocation(FVector(0.f, 0.f, MinimapCaptureHeight));
	MinimapCapture->SetRelativeRotation(FRotator(-90.f, 0.f, 0.f));
	MinimapCapture->ProjectionType = ECameraProjectionMode::Orthographic;
	MinimapCapture->OrthoWidth = MinimapCaptureWidth;
	MinimapCapture->TextureTarget = MinimapRT;
	MinimapCapture->CaptureSource = ESceneCaptureSource::SCS_BaseColor;
	MinimapCapture->bCaptureEveryFrame = false;
	MinimapCapture->bCaptureOnMovement = false;
	MinimapCapture->bAlwaysPersistRenderingState = true;
	MinimapCapture->MaxViewDistanceOverride = MinimapCaptureHeight * 1.5f;
	MinimapCapture->ShowFlags.SetParticles(false);
	MinimapCapture->ShowFlags.SetFog(false);
	MinimapCapture->ShowFlags.SetAtmosphere(false);
	MinimapCapture->ShowFlags.SetDynamicShadows(false);
	MinimapCapture->ShowFlags.SetVolumetricFog(false);
	MinimapCapture->ShowFlags.SetMotionBlur(false);
	MinimapCapture->ShowFlags.SetDepthOfField(false);
	MinimapCapture->ShowFlags.SetBloom(false);
	MinimapCapture->ShowFlags.SetLighting(false);
	MinimapCapture->ShowFlags.SetPostProcessing(false);
	MinimapCapture->ShowFlags.SetAmbientOcclusion(false);
	MinimapCapture->ShowFlags.SetTemporalAA(false);
	const USquadAITuning* T = USquadAITuning::Get();
	UMaterialInterface* BaseMat = nullptr;
	if (T)
	{
		if (!T->MinimapMaterialPath.IsEmpty())
			BaseMat = LoadObject<UMaterialInterface>(nullptr, *T->MinimapMaterialPath);
		if (!BaseMat && T->MinimapMaterial)
			BaseMat = T->MinimapMaterial.Get();
	}
	if (!BaseMat)
	{
		// S26-MMAT: no tuned material -> the AUTHORED default. The rotating-map
		// draw path needs a material (a DrawTile cannot rotate); without this
		// the fallback drew the map north-up while the icons turned with the
		// camera - a desync introduced by the rotation-stutter fix.
		if (USquadAIAssetCacheSubsystem* Cache = USquadAIAssetCacheSubsystem::Get(this))
		{
			BaseMat = Cache->EnsureMinimapMaterial();
		}
	}
	if (BaseMat)
	{
		MinimapMID = UMaterialInstanceDynamic::Create(BaseMat, this);
		MinimapMID->SetTextureParameterValue(FName("MinimapTexture"), MinimapRT);
	}
	MinimapCapturePawn = PlayerPawn;
	bMinimapInitialized = true;
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().SetTimer(
			MinimapCaptureTimer, this, &AQuestNativeHUD::CaptureMinimapIfNeeded,
			FMath::Max(0.5f, RefreshInterval), true, 0.25f);
	}
}

void AQuestNativeHUD::CaptureMinimapIfNeeded()
{
	if (!MinimapCapture || !GetWorld() || !GetWorld()->IsGameWorld())
	{
		return;
	}
	APawn* PlayerPawn = CachedPlayerPawn.Get();
	if (!PlayerPawn)
	{
		PlayerPawn = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
		CachedPlayerPawn = PlayerPawn;
	}
	if (!PlayerPawn)
	{
		return;
	}
	const FVector PL = PlayerPawn->GetActorLocation();
	const float MoveSq = FVector::DistSquared2D(PL, LastMinimapCaptureLoc);
	// S26-FIXPERF: THE rotation stutter fix. The capture used to follow the
	// camera's yaw and re-capture on every 10 deg of turning - and each
	// CaptureScene() renders the whole scene a second time. Looking around
	// fast fired capture after capture: that was the stutter. The capture now
	// stays NORTH-UP and only refreshes when the player MOVES (~4 m); the
	// rotation the player sees happens at DRAW time (see DrawMinimap), which
	// is a cheap canvas rotation, not a scene render.
	const bool bMoved = LastMinimapCaptureLoc.IsNearlyZero() || MoveSq > 160000.f;
	if (!bMoved)
	{
		return;
	}
	MinimapCapture->SetWorldRotation(FRotator(-90.f, 0.f, 0.f));   // north-up, always
	MinimapCapture->SetWorldLocation(PL + FVector(0.f, 0.f, MinimapCaptureHeight));
	MinimapCapture->CaptureScene();
	LastMinimapCaptureLoc = PL;
}

float AQuestNativeHUD::GetActorHealthPercent(AActor* Actor)
{
	if (!Actor) return 1.0f;

	float MinPercent = 1.0f;
	bool bFoundAny = false;

	// 1. Authoritative SquadAI HealthComp (on ASoldierCharacter or any Blueprint actor)
	if (UHealthComponent* HC = Actor->FindComponentByClass<UHealthComponent>())
	{
		MinPercent = FMath::Clamp(HC->GetHealthPercent(), 0.0f, 1.0f);
		bFoundAny = true;
	}

	auto ReadNumericProp = [](UObject* Obj, std::initializer_list<const TCHAR*> Names, double& OutVal) -> bool
	{
		if (!Obj || !Obj->GetClass()) return false;
		for (const TCHAR* RawName : Names)
		{
			const FName PropName(RawName);
			if (FDoubleProperty* DP = FindFProperty<FDoubleProperty>(Obj->GetClass(), PropName))
			{
				OutVal = DP->GetPropertyValue_InContainer(Obj);
				return true;
			}
			if (FFloatProperty* FP = FindFProperty<FFloatProperty>(Obj->GetClass(), PropName))
			{
				OutVal = static_cast<double>(FP->GetPropertyValue_InContainer(Obj));
				return true;
			}
			if (FIntProperty* IP = FindFProperty<FIntProperty>(Obj->GetClass(), PropName))
			{
				OutVal = static_cast<double>(IP->GetPropertyValue_InContainer(Obj));
				return true;
			}
		}
		return false;
	};

	// 2. Comprehensive Component Search (TPWCS BPC_Health, BPC_HealthPlayer, BPC_HealthAI, etc.)
	TArray<UActorComponent*> Comps;
	Actor->GetComponents(Comps);
	for (UActorComponent* C : Comps)
	{
		if (!C || C->IsA<UHealthComponent>()) continue;
		const FString CName = C->GetName();
		const FString ClassName = C->GetClass() ? C->GetClass()->GetName() : FString();

		if (CName.Contains(TEXT("Health"), ESearchCase::IgnoreCase) || ClassName.Contains(TEXT("Health"), ESearchCase::IgnoreCase))
		{
			double CurHP = -1.0;
			double MaxHP = -1.0;
			const bool bHasCur = ReadNumericProp(C, { TEXT("currentHealth"), TEXT("CurrentHealth"), TEXT("Current Health"), TEXT("Health"), TEXT("HP"), TEXT("currentHP"), TEXT("CurrentHP") }, CurHP);
			const bool bHasMax = ReadNumericProp(C, { TEXT("maxHealth"), TEXT("MaxHealth"), TEXT("Max Health"), TEXT("MaxHP"), TEXT("DefaultHealth") }, MaxHP);

			if (bHasCur && CurHP >= 0.0)
			{
				// S19-PACKHP guard: if the component has an explicit maxHealth (e.g. 100.0) and
				// currentHealth spawned inflated (e.g. 1998.338), clamp currentHealth to maxHealth
				// instead of caching 1998.338 as Known max health!
				if (bHasMax && MaxHP > 0.0 && CurHP > MaxHP)
				{
					CurHP = MaxHP;
					for (const TCHAR* RawName : { TEXT("currentHealth"), TEXT("CurrentHealth"), TEXT("Current Health"), TEXT("Health"), TEXT("HP") })
					{
						const FName PropName(RawName);
						if (FDoubleProperty* DP = FindFProperty<FDoubleProperty>(C->GetClass(), PropName)) { DP->SetPropertyValue_InContainer(C, MaxHP); break; }
						if (FFloatProperty* FP = FindFProperty<FFloatProperty>(C->GetClass(), PropName)) { FP->SetPropertyValue_InContainer(C, static_cast<float>(MaxHP)); break; }
						if (FIntProperty* IP = FindFProperty<FIntProperty>(C->GetClass(), PropName)) { IP->SetPropertyValue_InContainer(C, FMath::RoundToInt(MaxHP)); break; }
					}
				}

				TWeakObjectPtr<UActorComponent> CompKey(C);
				if (bHasMax && MaxHP > 0.0)
				{
					PackMaxHPByComp.FindOrAdd(CompKey) = MaxHP;
				}
				else if (const double* Known = PackMaxHPByComp.Find(CompKey))
				{
					MaxHP = *Known;
				}
				else
				{
					MaxHP = (CurHP > 0.0) ? CurHP : 100.0;
					PackMaxHPByComp.Add(CompKey, MaxHP);
					if (PackMaxHPByComp.Num() > 128)
					{
						TArray<TWeakObjectPtr<UActorComponent>> DeadKeys;
						for (auto& P : PackMaxHPByComp) { if (!P.Key.IsValid()) DeadKeys.Add(P.Key); }
						for (auto& K : DeadKeys) { PackMaxHPByComp.Remove(K); }
					}
				}
				const float Pct = FMath::Clamp(static_cast<float>(CurHP / FMath::Max(1.0, MaxHP)), 0.0f, 1.0f);
				MinPercent = bFoundAny ? FMath::Min(MinPercent, Pct) : Pct;
				bFoundAny = true;
			}
		}
	}

	// 3. Actor-level health property fallback (for Blueprint pawns storing Health directly on the Pawn)
	if (!bFoundAny)
	{
		double ActorCurHP = -1.0, ActorMaxHP = 100.0;
		if (ReadNumericProp(Actor, { TEXT("currentHealth"), TEXT("CurrentHealth"), TEXT("Current Health"), TEXT("Health"), TEXT("HP") }, ActorCurHP) && ActorCurHP >= 0.0)
		{
			ReadNumericProp(Actor, { TEXT("maxHealth"), TEXT("MaxHealth"), TEXT("Max Health"), TEXT("MaxHP") }, ActorMaxHP);
			if (ActorMaxHP <= 0.0) ActorMaxHP = 100.0;
			MinPercent = FMath::Clamp(static_cast<float>(ActorCurHP / ActorMaxHP), 0.0f, 1.0f);
			bFoundAny = true;
		}
	}

	return bFoundAny ? MinPercent : 1.0f;
}

float AQuestNativeHUD::GetPlayerHealthPercent(APawn* PlayerPawn)
{
	if (!PlayerPawn) return 1.0f;

	const float CompPercent = GetActorHealthPercent(PlayerPawn);

	// Reset accumulated HUD damage when component health heals or resets to full
	if (CompPercent > HUDLastHealthRaw + 0.05f || CompPercent >= 0.999f)
	{
		if (CompPercent > HUDLastHealthRaw + 0.05f)
		{
			HUDDamageAccumulated = 0.0f;
		}
	}
	HUDLastHealthRaw = CompPercent;

	if (CompPercent < 0.999f)
	{
		return CompPercent;
	}
	return FMath::Clamp(1.0f - HUDDamageAccumulated, 0.0f, 1.0f);
}

float AQuestNativeHUD::GetPlayerArmorPercent(APawn* PlayerPawn)
{
	if (!PlayerPawn) return 0.50f;

	auto ReadNumericProp = [](UObject* Obj, std::initializer_list<const TCHAR*> Names, double& OutVal) -> bool
	{
		if (!Obj || !Obj->GetClass()) return false;
		for (const TCHAR* RawName : Names)
		{
			const FName PropName(RawName);
			if (FDoubleProperty* DP = FindFProperty<FDoubleProperty>(Obj->GetClass(), PropName))
			{
				OutVal = DP->GetPropertyValue_InContainer(Obj);
				return true;
			}
			if (FFloatProperty* FP = FindFProperty<FFloatProperty>(Obj->GetClass(), PropName))
			{
				OutVal = static_cast<double>(FP->GetPropertyValue_InContainer(Obj));
				return true;
			}
			if (FIntProperty* IP = FindFProperty<FIntProperty>(Obj->GetClass(), PropName))
			{
				OutVal = static_cast<double>(IP->GetPropertyValue_InContainer(Obj));
				return true;
			}
		}
		return false;
	};

	// 1. Check components & pawn for explicit Armor / Shield properties
	TArray<UActorComponent*> Comps;
	PlayerPawn->GetComponents(Comps);
	for (UActorComponent* C : Comps)
	{
		if (!C) continue;
		double CurArm = -1.0, MaxArm = 100.0;
		if (ReadNumericProp(C, { TEXT("currentArmor"), TEXT("CurrentArmor"), TEXT("Current Armor"), TEXT("Armor"), TEXT("armor"), TEXT("CurrentShield"), TEXT("Shield") }, CurArm) && CurArm >= 0.0)
		{
			ReadNumericProp(C, { TEXT("maxArmor"), TEXT("MaxArmor"), TEXT("Max Armor"), TEXT("MaxShield") }, MaxArm);
			if (MaxArm <= 0.0) MaxArm = 100.0;
			return FMath::Clamp(static_cast<float>(CurArm / MaxArm), 0.0f, 1.0f);
		}
	}
	{
		double PawnArm = -1.0, PawnMaxArm = 100.0;
		if (ReadNumericProp(PlayerPawn, { TEXT("currentArmor"), TEXT("CurrentArmor"), TEXT("Current Armor"), TEXT("Armor"), TEXT("armor") }, PawnArm) && PawnArm >= 0.0)
		{
			ReadNumericProp(PlayerPawn, { TEXT("maxArmor"), TEXT("MaxArmor"), TEXT("Max Armor") }, PawnMaxArm);
			if (PawnMaxArm <= 0.0) PawnMaxArm = 100.0;
			return FMath::Clamp(static_cast<float>(PawnArm / PawnMaxArm), 0.0f, 1.0f);
		}
	}

	// 2. Period-correct 1980s M1 helmet + tactical webbing protection (50% base at full health,
	//    depleting as the player takes combat damage or consumes field dressings)
	const float HPPercent = GetPlayerHealthPercent(PlayerPawn);
	float BaseArmor = 0.50f * HPPercent;
	if (const USquadAIInventorySubsystem* Inv = USquadAIInventorySubsystem::Get(PlayerPawn))
	{
		if (Inv->FirstAidKits > 2)
		{
			BaseArmor += (Inv->FirstAidKits - 2) * 0.15f;
		}
		else if (Inv->FirstAidKits == 0)
		{
			BaseArmor *= 0.65f;
		}
	}
	return FMath::Clamp(BaseArmor, 0.0f, 1.0f);
}

float AQuestNativeHUD::GetPlayerStaminaPercent(APawn* PlayerPawn, float DeltaTime)
{
	if (!PlayerPawn) return HUDLiveStamina;

	// 1. Check if the pawn or any movement/stamina component exposes a live Stamina property
	TArray<UActorComponent*> Comps;
	PlayerPawn->GetComponents(Comps);
	for (UActorComponent* C : Comps)
	{
		if (!C || !C->GetClass()) continue;
		for (const TCHAR* RawName : { TEXT("currentStamina"), TEXT("CurrentStamina"), TEXT("Current Stamina"), TEXT("Stamina"), TEXT("stamina") })
		{
			const FName PropName(RawName);
			double CurStam = -1.0, MaxStam = 100.0;
			bool bFound = false;
			if (FDoubleProperty* DP = FindFProperty<FDoubleProperty>(C->GetClass(), PropName)) { CurStam = DP->GetPropertyValue_InContainer(C); bFound = true; }
			else if (FFloatProperty* FP = FindFProperty<FFloatProperty>(C->GetClass(), PropName)) { CurStam = FP->GetPropertyValue_InContainer(C); bFound = true; }
			if (bFound && CurStam >= 0.0)
			{
				for (const TCHAR* MName : { TEXT("maxStamina"), TEXT("MaxStamina"), TEXT("Max Stamina") })
				{
					if (FDoubleProperty* MDP = FindFProperty<FDoubleProperty>(C->GetClass(), FName(MName))) { MaxStam = MDP->GetPropertyValue_InContainer(C); break; }
					if (FFloatProperty* MFP = FindFProperty<FFloatProperty>(C->GetClass(), FName(MName))) { MaxStam = MFP->GetPropertyValue_InContainer(C); break; }
				}
				if (MaxStam <= 0.0) MaxStam = 100.0;
				HUDLiveStamina = FMath::Clamp(static_cast<float>(CurStam / MaxStam), 0.0f, 1.0f);
				return HUDLiveStamina;
			}
		}
	}

	// 2. Dynamic stamina simulation driven by real player velocity, sprint key, jump & crouch state
	const float Speed2D = PlayerPawn->GetVelocity().Size2D();
	bool bShiftHeld = false;
	bool bIsFalling = false;
	bool bIsCrouched = false;
	if (APlayerController* PC = GetOwningPlayerController())
	{
		bShiftHeld = PC->IsInputKeyDown(EKeys::LeftShift) || PC->IsInputKeyDown(EKeys::RightShift);
	}
	if (const ACharacter* Char = Cast<ACharacter>(PlayerPawn))
	{
		bIsCrouched = Char->bIsCrouched;
		if (const UCharacterMovementComponent* MoveComp = Char->GetCharacterMovement())
		{
			bIsFalling = MoveComp->IsFalling();
		}
	}

	const float ClampedDT = FMath::Clamp(DeltaTime, 0.0f, 0.1f);
	if (bIsFalling)
	{
		HUDLiveStamina = FMath::Max(0.10f, HUDLiveStamina - ClampedDT * 0.28f);
	}
	else if ((bShiftHeld && Speed2D > 120.f) || Speed2D > 430.f)
	{
		HUDLiveStamina = FMath::Max(0.08f, HUDLiveStamina - ClampedDT * 0.20f);
	}
	else if (Speed2D > 30.f && !bIsCrouched)
	{
		// Steady combat pace settles around 68%-85% stamina
		const float TargetWalkStamina = 0.78f;
		HUDLiveStamina = FMath::FInterpTo(HUDLiveStamina, TargetWalkStamina, ClampedDT, 1.2f);
	}
	else
	{
		// Resting or crouched recovers stamina up to 100%
		HUDLiveStamina = FMath::Min(1.0f, HUDLiveStamina + ClampedDT * 0.22f);
	}
	return HUDLiveStamina;
}

void AQuestNativeHUD::DrawLowHealthVignette(float ScreenW, float ScreenH, float HealthPercent)
{
	if (!bEnableLowHealthVignette || HealthPercent >= 0.35f || HealthPercent <= 0.0f) return;
	const float S = GameUIScale; // B6-14: resolution scale (menu-HUD parity).


	const float Intensity = FMath::Clamp(1.0f - (HealthPercent / 0.35f), 0.0f, 1.0f);
	const float TimeSec = GetWorld() ? GetWorld()->GetTimeSeconds() : 0.f;
	// MEGA-9 AAA: double-thump heartbeat (sharp systolic peak, not simple sine) + layered vignette falloff.
	const float HBfreq = 4.2f + Intensity * 7.0f;
	const float RawA = FMath::Sin(TimeSec * HBfreq);
	const float RawB = FMath::Sin(TimeSec * HBfreq * 1.85f + 0.9f);
	const float Heart = 0.58f + 0.28f * RawA + 0.14f * RawB * FMath::Max(0.f, RawA);
	const float Pulse = FMath::Clamp(Heart, 0.35f, 1.0f);
	const float Alpha = Intensity * Pulse * 0.78f;
	// Outer blood wash — 3 layers = soft falloff, not a hard rectangle.
	const float T0 = 42.f * S + Intensity * 78.f * S;
	const float T1 = T0 * 0.62f;
	const float T2 = T0 * 0.35f;
	DrawRect(FLinearColor(0.55f, 0.02f, 0.02f, Alpha * 0.55f), 0.f, 0.f, ScreenW, T0);
	DrawRect(FLinearColor(0.55f, 0.02f, 0.02f, Alpha * 0.55f), 0.f, ScreenH - T0, ScreenW, T0);
	DrawRect(FLinearColor(0.55f, 0.02f, 0.02f, Alpha * 0.55f), 0.f, T0, T0, ScreenH - T0*2.f);
	DrawRect(FLinearColor(0.55f, 0.02f, 0.02f, Alpha * 0.55f), ScreenW - T0, T0, T0, ScreenH - T0*2.f);
	DrawRect(FLinearColor(0.62f, 0.06f, 0.06f, Alpha * 0.32f), 0.f, 0.f, ScreenW, T1);
	DrawRect(FLinearColor(0.62f, 0.06f, 0.06f, Alpha * 0.32f), 0.f, ScreenH - T1, ScreenW, T1);
	DrawRect(FLinearColor(0.62f, 0.06f, 0.06f, Alpha * 0.32f), 0.f, T1, T1, ScreenH - T1*2.f);
	DrawRect(FLinearColor(0.62f, 0.06f, 0.06f, Alpha * 0.32f), ScreenW - T1, T1, T1, ScreenH - T1*2.f);
	// Critical inner desaturation when <15% — tunnel vision hint.
	if (HealthPercent < 0.15f) { const float DA = (0.15f - HealthPercent)/0.15f * 0.18f * Pulse; DrawRect(FLinearColor(0.06f,0.02f,0.02f,DA), T2, T2, ScreenW-T2*2.f, ScreenH-T2*2.f); }
	const FLinearColor RimColor(0.88f, 0.04f, 0.04f, Alpha);
	DrawRect(RimColor, 0.f, 0.f, ScreenW, 5.f * S);
	DrawRect(RimColor, 0.f, ScreenH - 5.f * S, ScreenW, 5.f * S);
	DrawRect(RimColor, 0.f, 0.f, 5.f * S, ScreenH);
	DrawRect(RimColor, ScreenW - 5.f * S, 0.f, 5.f * S, ScreenH);
	// Corner crows-feet — subliminal radial vignette without a texture.
	DrawRect(FLinearColor(0.5f,0.0f,0.0f, Alpha*0.18f), 0.f, 0.f, T2*1.4f, T2*1.4f);
	DrawRect(FLinearColor(0.5f,0.0f,0.0f, Alpha*0.18f), ScreenW-T2*1.4f, 0.f, T2*1.4f, T2*1.4f);
	DrawRect(FLinearColor(0.5f,0.0f,0.0f, Alpha*0.18f), 0.f, ScreenH-T2*1.4f, T2*1.4f, T2*1.4f);
	DrawRect(FLinearColor(0.5f,0.0f,0.0f, Alpha*0.18f), ScreenW-T2*1.4f, ScreenH-T2*1.4f, T2*1.4f, T2*1.4f);
}

void AQuestNativeHUD::DrawFireBurnVignette(float ScreenW, float ScreenH, float DeltaTime)
{
	if (!bEnableFireBurnVignette || !bIsPlayerBurning) return;
	const float S = GameUIScale; // B6-14: resolution scale (menu-HUD parity).


	const float TimeSec = GetWorld() ? GetWorld()->GetTimeSeconds() : 0.f;
	// MEGA-9 AAA: fire has two flicker bands (fast lick + slow bloom) — no longer a flat tint.
	const float FireFast = 0.55f + 0.30f * FMath::Sin(TimeSec * 14.0f) + 0.15f * FMath::Cos(TimeSec * 23.0f);
	const float FireSlow = 0.60f + 0.22f * FMath::Sin(TimeSec * 3.1f + 0.7f);
	const float FireAlpha = FMath::Clamp(FireFast * 0.55f + FireSlow * 0.35f, 0.18f, 0.88f);
	const float BorderThick = 58.f * S;
	const float InnerThick = 34.f * S;
	DrawRect(FLinearColor(0.85f, 0.22f, 0.03f, FireAlpha * 0.42f), 0.f, 0.f, ScreenW, BorderThick);
	DrawRect(FLinearColor(0.85f, 0.22f, 0.03f, FireAlpha * 0.42f), 0.f, ScreenH - BorderThick, ScreenW, BorderThick);
	DrawRect(FLinearColor(0.85f, 0.22f, 0.03f, FireAlpha * 0.42f), 0.f, BorderThick, BorderThick, ScreenH - BorderThick*2.f);
	DrawRect(FLinearColor(0.85f, 0.22f, 0.03f, FireAlpha * 0.42f), ScreenW - BorderThick, BorderThick, BorderThick, ScreenH - BorderThick*2.f);
	DrawRect(FLinearColor(1.0f, 0.52f, 0.08f, FireAlpha * 0.65f), 0.f, 0.f, ScreenW, InnerThick);
	DrawRect(FLinearColor(1.0f, 0.52f, 0.08f, FireAlpha * 0.65f), 0.f, ScreenH - InnerThick, ScreenW, InnerThick);
	DrawRect(FLinearColor(1.0f, 0.52f, 0.08f, FireAlpha * 0.65f), 0.f, InnerThick, InnerThick, ScreenH - InnerThick*2.f);
	DrawRect(FLinearColor(1.0f, 0.52f, 0.08f, FireAlpha * 0.65f), ScreenW - InnerThick, InnerThick, InnerThick, ScreenH - InnerThick*2.f);
	DrawRect(FLinearColor(1.0f, 0.70f, 0.18f, FireAlpha), 0.f, 0.f, ScreenW, 4.f * S);
	DrawRect(FLinearColor(1.0f, 0.70f, 0.18f, FireAlpha), 0.f, ScreenH - 4.f * S, ScreenW, 4.f * S);
	DrawRect(FLinearColor(1.0f, 0.70f, 0.18f, FireAlpha), 0.f, 0.f, 4.f * S, ScreenH);
	DrawRect(FLinearColor(1.0f, 0.70f, 0.18f, FireAlpha), ScreenW - 4.f * S, 0.f, 4.f * S, ScreenH);
	// Ember speckles along the rim — cheap, no texture.
	for(int32 ei=0; ei<7; ++ei){ float ex = FMath::Fmod(TimeSec* (90.f+ei*37.f) + ei* 191.f, ScreenW); float ey = (ei%2==0)? 6.f*S: ScreenH - 10.f*S; float ea = 0.35f + 0.35f*FMath::Sin(TimeSec* (9.f+ei)+ei); DrawRect(FLinearColor(1.f,0.85f,0.35f, ea*FireAlpha*0.55f), ex, ey, 3.f*S, 3.f*S); }
}

void AQuestNativeHUD::DrawSuppressionVignette(float ScreenW, float ScreenH, float DeltaTime)
{
	if (!bEnableSuppressionVignette || PlayerSuppression <= 0.01f) return;
	const float S = GameUIScale; // B6-14: resolution scale (menu-HUD parity).


	PlayerSuppression = FMath::FInterpTo(PlayerSuppression, 0.f, DeltaTime, 1.25f);
	const float Alpha = FMath::Clamp(PlayerSuppression * 0.62f, 0.f, 0.72f);
	const float BorderThick = 46.f * S + PlayerSuppression * 68.f * S;
	// MEGA-9 AAA: tunnel is two layers (hard + soft falloff) + subtle sway — reads as pressure, not a flat box.
	const float TOuter = BorderThick;
	const float TInner = BorderThick * 0.58f;
	const float Sway = 4.f * S * PlayerSuppression * FMath::Sin((GetWorld()?GetWorld()->GetTimeSeconds():0.f) * 5.5f);
	DrawRect(FLinearColor(0.02f, 0.03f, 0.065f, Alpha * 0.95f), 0.f, 0.f, ScreenW, TOuter);
	DrawRect(FLinearColor(0.02f, 0.03f, 0.065f, Alpha * 0.95f), 0.f, ScreenH - TOuter, ScreenW, TOuter);
	DrawRect(FLinearColor(0.02f, 0.03f, 0.065f, Alpha * 0.95f), Sway, TOuter, TOuter, ScreenH - TOuter*2.f);
	DrawRect(FLinearColor(0.02f, 0.03f, 0.065f, Alpha * 0.95f), ScreenW - TOuter + Sway, TOuter, TOuter, ScreenH - TOuter*2.f);
	DrawRect(FLinearColor(0.04f, 0.06f, 0.10f, Alpha * 0.45f), 0.f, 0.f, ScreenW, TInner);
	DrawRect(FLinearColor(0.04f, 0.06f, 0.10f, Alpha * 0.45f), 0.f, ScreenH - TInner, ScreenW, TInner);
	DrawRect(FLinearColor(0.04f, 0.06f, 0.10f, Alpha * 0.45f), Sway*0.6f, TInner, TInner, ScreenH - TInner*2.f);
	DrawRect(FLinearColor(0.04f, 0.06f, 0.10f, Alpha * 0.45f), ScreenW - TInner + Sway*0.6f, TInner, TInner, ScreenH - TInner*2.f);
}

void AQuestNativeHUD::DrawDirectionalDamageIndicators(float CX, float CY, const FVector& PlayerLoc, float PlayerYaw, float DeltaTime)
{
	if (!bEnableDamageDirectionIndicators || ActiveDamageIndicators.Num() == 0) return;

	const float S = GameUIScale; // B6-14: resolution scale (menu-HUD parity).
	const float ReticleRadius = 85.f * S;

	for (int32 i = ActiveDamageIndicators.Num() - 1; i >= 0; --i)
	{
		FDamageHitIndicator& Ind = ActiveDamageIndicators[i];
		Ind.TimeRemaining -= DeltaTime;

		if (Ind.TimeRemaining <= 0.f)
		{
			ActiveDamageIndicators.RemoveAt(i);
			continue;
		}

		const float LifeA = FMath::Clamp(Ind.TimeRemaining / Ind.MaxLifetime, 0.f, 1.f);
		const float Alpha = LifeA * LifeA; // MEGA-9: ease-out fade (quick peak, soft tail)
		const FLinearColor ArcColor(1.0f, 0.08f, 0.08f, Alpha * 0.92f);
		const FLinearColor ArcGlow(1.0f, 0.18f, 0.12f, Alpha * 0.28f);

		const FVector Dir = (Ind.WorldSourceLocation - PlayerLoc).GetSafeNormal2D();
		const float CosY = FMath::Cos(-FMath::DegreesToRadians(PlayerYaw));
		const float SinY = FMath::Sin(-FMath::DegreesToRadians(PlayerYaw));
		const float RotX = Dir.X * CosY - Dir.Y * SinY;
		const float RotY = Dir.X * SinY + Dir.Y * CosY;
		const float Angle = FMath::Atan2(-RotX, RotY);

		for (int32 seg = -2; seg <= 2; ++seg)
		{
			const float A0 = Angle + FMath::DegreesToRadians(seg * 8.f);
			const float A1 = Angle + FMath::DegreesToRadians((seg + 1) * 8.f);
			DrawLine(CX + FMath::Cos(A0) * ReticleRadius, CY + FMath::Sin(A0) * ReticleRadius,
					 CX + FMath::Cos(A1) * ReticleRadius, CY + FMath::Sin(A1) * ReticleRadius,
					 ArcGlow, 6.5f * S);
			DrawLine(CX + FMath::Cos(A0) * ReticleRadius, CY + FMath::Sin(A0) * ReticleRadius,
					 CX + FMath::Cos(A1) * ReticleRadius, CY + FMath::Sin(A1) * ReticleRadius,
					 ArcColor, 3.5f * S);
		}
	}
}

void AQuestNativeHUD::DrawHitMarker(float CX, float CY, float DeltaTime)
{
	if (!bEnableHitMarkers || HitMarkerTimeRemaining <= 0.f) return;

	HitMarkerTimeRemaining -= DeltaTime;
	const float Alpha = FMath::Clamp(HitMarkerTimeRemaining / HitMarkerDuration, 0.f, 1.f);
	// MEGA-9 AAA: hitmarker punches outward (fast expand, settle) — kill is larger, hotter, with a burst ring.
	const float Life01 = 1.f - Alpha; // 0 at hit, 1 at fade
	const float Punch = 1.f + (bHitMarkerIsKill ? 0.45f : 0.28f) * FMath::Clamp(1.f - Life01 * 3.5f, 0.f, 1.f);
	const float Settle = 1.f + 0.08f * FMath::Sin(Life01 * 18.f) * (1.f - Life01);
	const float ScaleHM = Punch * Settle;
	const FLinearColor MarkerColor = bHitMarkerIsKill ? FLinearColor(1.0f, 0.18f, 0.14f, Alpha) : FLinearColor(1.0f, 1.0f, 1.0f, Alpha);
	const FLinearColor MarkerGlow = bHitMarkerIsKill ? FLinearColor(1.0f, 0.35f, 0.22f, Alpha*0.38f) : FLinearColor(1.f,1.f,1.f, Alpha*0.22f);
	const float S = GameUIScale;
	const float Gap = 5.f * S * ScaleHM;
	const float Length = 9.f * S * ScaleHM;
	const float Thick = 2.0f * S;
	const float GlowThick = 4.2f * S;
	// Glow underlay
	DrawLine(CX - Gap - Length, CY - Gap - Length, CX - Gap, CY - Gap, MarkerGlow, GlowThick);
	DrawLine(CX + Gap, CY - Gap, CX + Gap + Length, CY - Gap - Length, MarkerGlow, GlowThick);
	DrawLine(CX - Gap - Length, CY + Gap + Length, CX - Gap, CY + Gap, MarkerGlow, GlowThick);
	DrawLine(CX + Gap, CY + Gap, CX + Gap + Length, CY + Gap + Length, MarkerGlow, GlowThick);
	DrawLine(CX - Gap - Length, CY - Gap - Length, CX - Gap, CY - Gap, MarkerColor, Thick);
	DrawLine(CX + Gap, CY - Gap, CX + Gap + Length, CY - Gap - Length, MarkerColor, Thick);
	DrawLine(CX - Gap - Length, CY + Gap + Length, CX - Gap, CY + Gap, MarkerColor, Thick);
	DrawLine(CX + Gap, CY + Gap, CX + Gap + Length, CY + Gap + Length, MarkerColor, Thick);
	if (bHitMarkerIsKill) { const float R = (12.f + Life01*10.f)*S; DrawCircleLines(FLinearColor(1.f,0.2f,0.15f, Alpha*0.55f), CX, CY, R, 2.2f*S); }
}

bool AQuestNativeHUD::IsDefendBannerActive()
{
	if (AQuestChain* Chain = FindQuestChain())
	{
		if (AMissionZone* M = Chain->GetCurrentMission())
		{
			return Chain->bIsActive && M->MissionType == EMissionType::Defend && M->IsActive();
		}
	}
	return false;
}

void AQuestNativeHUD::DrawTacticalCompassRibbon(float CX, float StartY, float PlayerYaw, UFont* Font, const FVector& PlayerLoc)
{
	if (!bEnableTacticalCompassRibbon || !Canvas) return;

	const float S = GameUIScale;
	const float SW = Canvas->ClipX;
	const float SH = Canvas->ClipY;
	const bool bEnglish = SquadAIHUDIsEnglish(this);

	// S27-REFUI: Match index.html .compass { top: 3%; left: 42%; width: 22%; height: 42px }
	// When the tutorial is active (so .operation-banner occupies top-left 2.35%..39%),
	// the compass centers at 53% of screen width (42%..64%) so it never touches the
	// operation banner on the left or .topright on the right.
	bool bTutRunning = false;
	if (const USquadAITutorialSubsystem* Tut = USquadAITutorialSubsystem::Get(this))
	{
		bTutRunning = Tut->IsTutorialActive();
	}
	const float RibbonW = FMath::Clamp(SW * 0.22f, 340.f * S, 460.f * S);
	const float RibbonH = 42.f * S;
	const float RibbonX = bTutRunning ? (SW * 0.42f) : (CX - RibbonW * 0.5f);
	const float RibbonY = FMath::Max(StartY, SH * 0.03f);
	const float ActualCX = RibbonX + RibbonW * 0.5f;

	RegisterTutorialUIRect(TEXT("Compass"), RibbonX, RibbonY, RibbonW, RibbonH);

	// 9-slice rounded-bevel frosted glass/metal instrument body (.compass: border-radius: 9px + inset: 3px keyline)
	Draw9SliceRoundedBox(RibbonX, RibbonY, RibbonW, RibbonH, FName(TEXT("OpBanner")), 0.92f, S, 1.0f, true, 0.85f);

	// .compass:before bottom glowing line (left: 10px; right: 10px; bottom: 5px; height: 1px; linear-gradient(90deg, transparent, #f2e8d155, transparent))
	const float GlowLineW = RibbonW - 20.f * S;
	const float GlowLineX = RibbonX + 10.f * S;
	const float GlowLineY = FMath::RoundToFloat(RibbonY + RibbonH - 6.f * S);
	DrawRect(FSquadAIHUDPalette::SRGB(242, 232, 209, 0.14f), GlowLineX, GlowLineY, GlowLineW, 1.0f);
	DrawRect(FSquadAIHUDPalette::SRGB(242, 232, 209, 0.36f), GlowLineX + GlowLineW * 0.18f, GlowLineY, GlowLineW * 0.64f, 1.0f);

	// Helper to format cardinal / degree label in Farsi or English
	const int32 CenterDeg = ((FMath::RoundToInt(PlayerYaw) % 360) + 360) % 360;
	auto GetCardinalName = [&](int32 NormDeg, bool bCenterPill) -> FString
	{
		if (bCenterPill)
		{
			if (NormDeg >= 338 || NormDeg < 23)  return bEnglish ? TEXT("N")  : TEXT("شمال");
			if (NormDeg >= 23  && NormDeg < 68)  return bEnglish ? TEXT("NE") : TEXT("ش‌شرق");
			if (NormDeg >= 68  && NormDeg < 113) return bEnglish ? TEXT("E")  : TEXT("شرق");
			if (NormDeg >= 113 && NormDeg < 158) return bEnglish ? TEXT("SE") : TEXT("ج‌شرق");
			if (NormDeg >= 158 && NormDeg < 203) return bEnglish ? TEXT("S")  : TEXT("جنوب");
			if (NormDeg >= 203 && NormDeg < 248) return bEnglish ? TEXT("SW") : TEXT("ج‌غرب");
			if (NormDeg >= 248 && NormDeg < 293) return bEnglish ? TEXT("W")  : TEXT("غرب");
			return bEnglish ? TEXT("NW") : TEXT("ش‌غرب");
		}
		if (NormDeg == 0)   return TEXT("N");
		if (NormDeg == 45)  return TEXT("NE");
		if (NormDeg == 90)  return TEXT("E");
		if (NormDeg == 135) return TEXT("SE");
		if (NormDeg == 180) return TEXT("S");
		if (NormDeg == 225) return TEXT("SW");
		if (NormDeg == 270) return TEXT("W");
		if (NormDeg == 315) return TEXT("NW");
		const FString NumStr = FString::FromInt(NormDeg);
		return bEnglish ? NumStr : UFarsiTextHelper::ToPersianDigits(NumStr);
	};

	const int32 Base15 = ((FMath::RoundToInt(PlayerYaw / 15.f) * 15) % 360 + 360) % 360;
	const int32 Offsets[9] = { -60, -45, -30, -15, 0, 15, 30, 45, 60 };
	const float InnerPad = 14.f * S;
	const float SlotSpan = (RibbonW - InnerPad * 2.f) / 8.f;

	for (int32 Idx = 0; Idx < 9; ++Idx)
	{
		const float SlotX = RibbonX + InnerPad + Idx * SlotSpan;
		if (Idx == 4)
		{
			// Center 9-slice rounded 3D copper-bronze .bearing pill (index.html lines 107, 118, 128:
			// height: 31px; border: 1px solid #e9a14c; border-radius: 5px;
			// background: linear-gradient(180deg, #f2b85e, #b56c2d 12%, #482d1b 100%);
			// box-shadow: inset 0 2px 0 #ffe6b8, inset 0 -3px 0 #23150d, 0 0 8px #ed9b4388; color: #fff1d3)
			const float PillW = 54.f * S;
			const float PillH = 31.f * S;
			const float PillX = ActualCX - PillW * 0.5f;
			const float PillY = RibbonY + (RibbonH - PillH) * 0.5f - 1.f * S;

			Draw9SliceRoundedBox(PillX, PillY, PillW, PillH, FName(TEXT("CompassBearing")), 0.98f, S, 0.70f, false, 0.f);

			// .compass .bearing:before — top 1x4px #ffd58d graduation tick at top center
			DrawRect(FSquadAIHUDPalette::SRGB(255, 213, 141, 0.95f), ActualCX - 0.6f * S, PillY + 1.5f * S, 1.2f * S, 4.0f * S);

			const FString CenterLbl = GetCardinalName(CenterDeg, true);
			DrawFarsiText3D(CenterLbl, FSquadAIHUDPalette::SRGB(255, 241, 211, 1.0f),
				PillX + 3.f * S, PillY + 2.f * S, PillW - 6.f * S, Font, 0.68f * S, true, false, PillH - 2.f * S, 1.0f * S);

			// Downward amber pointer triangle at bottom center (.bearing:after)
			const float TriY = PillY + PillH + 1.f * S;
			for (int32 Row = 0; Row < 5; ++Row)
			{
				const float HalfSpan = (5 - Row) * 1.0f * S;
				DrawRect(FSquadAIHUDPalette::BracketGold(), ActualCX - HalfSpan, TriY + Row * 1.1f * S, HalfSpan * 2.f, 1.2f * S);
			}
		}
		else
		{
			// Top tick mark (span::before: 1x4px #f2ead9)
			DrawRect(FLinearColor(0.949f, 0.918f, 0.851f, 0.85f), SlotX - 0.5f * S, RibbonY + 6.f * S, 1.2f * S, 4.5f * S);

			// Degree / Cardinal label
			int32 SlotDeg = (Base15 + Offsets[Idx] + 360) % 360;
			FString SlotLbl;
			if (Base15 == 0)
			{
				// Exact match to index.html default sequence: NW, 300, 315, 330, [شمال], 15, 30, NE, 60
				static const TCHAR* DefaultFa[9] = { TEXT("NW"), TEXT("۳۰۰"), TEXT("۳۱۵"), TEXT("۳۳۰"), TEXT("شمال"), TEXT("۱۵"), TEXT("۳۰"), TEXT("NE"), TEXT("۶۰") };
				static const TCHAR* DefaultEn[9] = { TEXT("NW"), TEXT("300"), TEXT("315"), TEXT("330"), TEXT("N"),    TEXT("15"), TEXT("30"), TEXT("NE"), TEXT("60") };
				SlotLbl = bEnglish ? DefaultEn[Idx] : DefaultFa[Idx];
			}
			else
			{
				SlotLbl = GetCardinalName(SlotDeg, false);
			}
			const bool bIsCardinal = (SlotLbl == TEXT("N") || SlotLbl == TEXT("NE") || SlotLbl == TEXT("E") || SlotLbl == TEXT("SE")
				|| SlotLbl == TEXT("S") || SlotLbl == TEXT("SW") || SlotLbl == TEXT("W") || SlotLbl == TEXT("NW"));
			const FLinearColor LblCol = bIsCardinal
				? FLinearColor(0.98f, 0.95f, 0.88f, 0.96f)
				: FLinearColor(0.91f, 0.89f, 0.84f, 0.88f);
			DrawFarsiTextBounded(SlotLbl, LblCol, SlotX - 18.f * S, RibbonY + 12.f * S, 36.f * S,
				Font, 0.68f * S, true, true, 22.f * S);
		}
	}

	// Dynamic Objective & Leader Pips on Ribbon
	const float PixelsPerDegree = RibbonW / 120.f;
	if (AQuestChain* Chain = FindQuestChain())
	{
		if (AMissionZone* Cur = Chain->GetCurrentMission())
		{
			FVector ToMission = Cur->GetActorLocation() - PlayerLoc;
			ToMission.Z = 0.f;
			const float MissionYaw = ToMission.Rotation().Yaw;
			const float DeltaYaw = FMath::FindDeltaAngleDegrees(PlayerYaw, MissionYaw);
			if (FMath::Abs(DeltaYaw) <= 55.f)
			{
				const float PipX = ActualCX + DeltaYaw * PixelsPerDegree;
				const float PipY = RibbonY + RibbonH + 4.f * S + (IsDefendBannerActive() ? 38.f * S : 0.f);
				DrawFilledCircleArea(FSquadAIHUDPalette::GoldText(), PipX, PipY, 3.8f * S);
			}
		}
	}

	if (AActor* LeaderActor = FindCachedLeader())
	{
		FVector ToLeader = LeaderActor->GetActorLocation() - PlayerLoc;
		ToLeader.Z = 0.f;
		const float LeaderYaw = ToLeader.Rotation().Yaw;
		const float DeltaYaw = FMath::FindDeltaAngleDegrees(PlayerYaw, LeaderYaw);
		if (FMath::Abs(DeltaYaw) <= 55.f)
		{
			const float PipX = ActualCX + DeltaYaw * PixelsPerDegree;
			const float PipY = RibbonY + RibbonH + 4.f * S + (IsDefendBannerActive() ? 38.f * S : 0.f);
			DrawFilledCircleArea(FSquadAIHUDPalette::ArmorBlue(), PipX, PipY, 3.4f * S);
		}
	}
}

void AQuestNativeHUD::DrawTactical3DPings(UFont* Font, APawn* PlayerPawn)
{
	if (!bEnableTactical3DPings || !Canvas || !GetWorld()) return;
	const float S = GameUIScale; // B6-14: resolution scale (menu-HUD parity).


	USquadAIPingSubsystem* PingSys = USquadAIPingSubsystem::Get(this);
	if (!PingSys) return;

	const TArray<FTacticalPing>& Pings = PingSys->GetActivePings();
	if (Pings.Num() == 0) return;

	APlayerController* PC = UGameplayStatics::GetPlayerController(GetWorld(), 0);
	if (!PC) return;

	const FVector PlayerLoc = PlayerPawn ? PlayerPawn->GetActorLocation() : FVector::ZeroVector;
	const float TimeSec = GetWorld()->GetTimeSeconds();

	for (const FTacticalPing& Ping : Pings)
	{
		FVector2D ScreenPos;
		const bool bOnScreen = PC->ProjectWorldLocationToScreen(Ping.WorldLocation + FVector(0.f, 0.f, 40.f * S), ScreenPos);
		if (!bOnScreen) continue;

		if (ScreenPos.X < 20.f * S || ScreenPos.X > Canvas->ClipX - 20.f * S ||
			ScreenPos.Y < 20.f * S || ScreenPos.Y > Canvas->ClipY - 20.f * S)
		{
			continue;
		}

		FLinearColor PingColor = FLinearColor(1.0f, 0.85f, 0.1f, 0.95f);
		FString PingLabel = TEXT("MOVE");

		switch (Ping.Type)
		{
		case ETacticalPingType::Danger:
			PingColor = FLinearColor(1.0f, 0.15f, 0.15f, 0.95f);
			PingLabel = TEXT("DANGER");
			break;
		case ETacticalPingType::Hostile:
			PingColor = FLinearColor(1.0f, 0.25f, 0.05f, 0.95f);
			PingLabel = TEXT("HOSTILE");
			break;
		case ETacticalPingType::Defend:
			PingColor = FLinearColor(0.2f, 0.75f, 1.0f, 0.95f);
			PingLabel = TEXT("DEFEND");
			break;
		case ETacticalPingType::MoveTo:
		default:
			PingColor = FLinearColor(1.0f, 0.85f, 0.1f, 0.95f);
			PingLabel = TEXT("MOVE");
			break;
		}

		const float DistMeters = FVector::Dist(PlayerLoc, Ping.WorldLocation) / 100.f;
		const float Pulse = 1.0f + 0.12f * FMath::Sin(TimeSec * 8.f);
		const float DiamondSize = 10.f * S * Pulse;

		DrawLine(ScreenPos.X, ScreenPos.Y - DiamondSize, ScreenPos.X + DiamondSize, ScreenPos.Y, PingColor, 2.5f * S);
		DrawLine(ScreenPos.X + DiamondSize, ScreenPos.Y, ScreenPos.X, ScreenPos.Y + DiamondSize, PingColor, 2.5f * S);
		DrawLine(ScreenPos.X, ScreenPos.Y + DiamondSize, ScreenPos.X - DiamondSize, ScreenPos.Y, PingColor, 2.5f * S);
		DrawLine(ScreenPos.X - DiamondSize, ScreenPos.Y, ScreenPos.X, ScreenPos.Y - DiamondSize, PingColor, 2.5f * S);

		DrawRect(PingColor, ScreenPos.X - 2.f * S, ScreenPos.Y - 2.f * S, 4.f * S, 4.f * S);

		const FString InfoText = FString::Printf(TEXT("%s [%.0fm]"), *PingLabel, DistMeters);
		DrawRect(FLinearColor(0.02f, 0.04f, 0.07f, 0.85f), ScreenPos.X - 35.f * S, ScreenPos.Y + DiamondSize + 4.f * S, 70.f * S, 16.f * S);
		DrawFarsiText(InfoText, PingColor, ScreenPos.X - 30.f * S, ScreenPos.Y + DiamondSize + 5.f * S, Font, 0.65f * S, false);
	}
}

void AQuestNativeHUD::DrawObjectiveGuidanceVision(float ScreenW, float ScreenH, float DeltaTime, APawn* PlayerPawn, UFont* Font)
{
	if (!bEnableObjectiveGuidanceVision || !Canvas || !GetWorld()) return;
	const float UIS = GameUIScale; // B6-14: resolution scale (UIS: S is a soldier ptr here).


	APlayerController* PC = UGameplayStatics::GetPlayerController(GetWorld(), 0);
	const bool bHoldingKey = PC && GuidanceVisionKey.IsValid() && PC->IsInputKeyDown(GuidanceVisionKey);
	const bool bTargetActive = bGuidanceVisionActive || bHoldingKey;
	const float DesiredAlpha = bTargetActive ? 1.0f : 0.0f;

	GuidanceVisionBlendAlpha = FMath::FInterpTo(GuidanceVisionBlendAlpha, DesiredAlpha, DeltaTime, 6.0f);
	if (GuidanceVisionBlendAlpha <= 0.01f) return;

	// 1. Cinematic Desaturation Veil & Soft Warm Tone
	const FLinearColor DesatVeil(0.012f, 0.018f, 0.03f, 0.45f * GuidanceVisionBlendAlpha);
	DrawRect(DesatVeil, 0.f, 0.f, ScreenW, ScreenH);

	// Glowing Golden Border Frame
	const FLinearColor RimGlow(1.0f, 0.82f, 0.25f, 0.35f * GuidanceVisionBlendAlpha);
	DrawRect(RimGlow, 0.f, 0.f, ScreenW, 2.f * UIS);
	DrawRect(RimGlow, 0.f, ScreenH - 2.f * UIS, ScreenW, 2.f * UIS);
	DrawRect(RimGlow, 0.f, 0.f, 2.f * UIS, ScreenH);
	DrawRect(RimGlow, ScreenW - 2.f * UIS, 0.f, 2.f * UIS, ScreenH);

	// 2. Compute Objective Target Location
	const bool bEnglishHUD = SquadAIHUDIsEnglish(this);
	FVector GoalLoc = FVector::ZeroVector;
	FString GoalName = SquadAIHUDLocal(this, TEXT("HUD"), TEXT("ObjectiveGoalDefault"), TEXT("نقطه هدف عملیاتی"), TEXT("Operational objective"));

	AQuestChain* Chain = FindQuestChain();
	if (Chain && Chain->bIsActive)
	{
		if (AMissionZone* Cur = Chain->GetCurrentMission())
		{
			GoalLoc = Cur->GetActorLocation();
			GoalName = Cur->CustomBadgeText.IsEmpty() ? SquadAIHUDLocal(this, TEXT("HUD"), TEXT("ObjectivePosition"), TEXT("موضع عملیاتی"), TEXT("Operational position")) : Cur->CustomBadgeText.ToString();
		}
	}

	if (GoalLoc.IsNearlyZero())
	{
		if (AActor* Leader = FindCachedLeader())
		{
			GoalLoc = Leader->GetActorLocation();
			GoalName = SquadAIHUDLocal(this, TEXT("HUD"), TEXT("ObjectiveLeader"), TEXT("فرمانده سرگرد رستمی"), TEXT("Commander Major Rostami"));
		}
	}

	const FVector PlayerLoc = PlayerPawn ? PlayerPawn->GetActorLocation() : FVector::ZeroVector;
	const float DistToGoal = FVector::Dist(PlayerLoc, GoalLoc);

	// 3. Atmospheric Desert Guiding Ribbon / Ground Laser Track
	if (!GoalLoc.IsNearlyZero() && PC)
	{
		constexpr int32 NumSteps = 24;
		const float TimeSec = GetWorld()->GetTimeSeconds();
		// B6-15: ground-clamp traces (24/frame) refresh at 4 Hz; projection stays per-frame.
		GuidanceSampleTimer -= DeltaTime;
		if (GuidanceSampleTimer <= 0.f || CachedGuidanceSamples.Num() != NumSteps + 1)
		{
			GuidanceSampleTimer = 0.25f;
			CachedGuidanceSamples.Reset(NumSteps + 1);
			for (int32 s = 0; s <= NumSteps; ++s)
			{
				const float CacheAlpha = static_cast<float>(s) / static_cast<float>(NumSteps);
				FVector CacheLoc = FMath::Lerp(PlayerLoc, GoalLoc, CacheAlpha);
				FHitResult GroundHit;
				FCollisionQueryParams TraceParams(SCENE_QUERY_STAT(GuidanceGroundTrace), false, PlayerPawn);
				if (GetWorld()->LineTraceSingleByChannel(GroundHit, CacheLoc + FVector(0.f, 0.f, 250.f), CacheLoc - FVector(0.f, 0.f, 600.f), ECC_Visibility, TraceParams))
				{
					CacheLoc = GroundHit.ImpactPoint + FVector(0.f, 0.f, 10.f);
				}
				CachedGuidanceSamples.Add(CacheLoc);
			}
		}
		FVector2D PrevScreenPoint(0.f, 0.f);
		bool bHasPrev = false;

		for (int32 i = 1; i <= NumSteps; ++i)
		{
			const float AlphaAlong = static_cast<float>(i) / static_cast<float>(NumSteps);
			const FVector SampleLoc = CachedGuidanceSamples[i];

			FVector2D ScreenPos;
			if (PC->ProjectWorldLocationToScreen(SampleLoc, ScreenPos))
			{
				if (ScreenPos.X >= 0.f && ScreenPos.X <= ScreenW && ScreenPos.Y >= 0.f && ScreenPos.Y <= ScreenH)
				{
					const float FlowPhase = FMath::Fmod(TimeSec * 2.0f - AlphaAlong * 2.5f, 1.0f);
					const float FlowGlow = (FlowPhase > 0.0f && FlowPhase < 0.30f) ? 1.35f : 0.75f;

					if (bHasPrev)
					{
						const FLinearColor SoftGlowColor(1.0f, 0.80f, 0.25f, 0.20f * GuidanceVisionBlendAlpha * FlowGlow);
						DrawLine(PrevScreenPoint.X, PrevScreenPoint.Y, ScreenPos.X, ScreenPos.Y, SoftGlowColor, 2.5f * UIS);

						const FLinearColor CoreLaserColor(1.0f, 0.88f, 0.40f, 0.65f * GuidanceVisionBlendAlpha * FlowGlow);
						DrawLine(PrevScreenPoint.X, PrevScreenPoint.Y, ScreenPos.X, ScreenPos.Y, CoreLaserColor, 1.0f * UIS);

						// Sleek directional chevron pointing along the tactical path
						if (i % 4 == 0)
						{
							const FVector2D Dir = (ScreenPos - PrevScreenPoint).GetSafeNormal();
							const FVector2D Normal(-Dir.Y, Dir.X);
							const float ChevSize = 7.f * UIS;
							const FVector2D ChevTip = ScreenPos;
							const FVector2D ChevL = ScreenPos - Dir * ChevSize + Normal * (ChevSize * 0.7f);
							const FVector2D ChevR = ScreenPos - Dir * ChevSize - Normal * (ChevSize * 0.7f);

							const FLinearColor ChevColor(1.0f, 0.82f, 0.25f, 0.75f * GuidanceVisionBlendAlpha * FlowGlow);
							DrawLine(ChevTip.X, ChevTip.Y, ChevL.X, ChevL.Y, ChevColor, 1.5f * UIS);
							DrawLine(ChevTip.X, ChevTip.Y, ChevR.X, ChevR.Y, ChevColor, 1.5f * UIS);
						}
					}

					PrevScreenPoint = ScreenPos;
					bHasPrev = true;
				}
			}
		}

		// Top Tactical Guidance Header
		// L2-INI: HUD.GuidancePrompt is the banner label (user key, now live).
		const FString GuidanceLbl = SquadAIHUDLocal(this, TEXT("HUD"), TEXT("GuidancePrompt"), TEXT("هدایت مسیر [V]"), TEXT("Route guidance [V]"));
		const FString DistanceLbl = SquadAIHUDLocal(this, TEXT("HUD"), TEXT("DistanceLabel"), TEXT("فاصله"), TEXT("Distance"));
		const FString GuidanceMeter = SquadAIHUDLocal(this, TEXT("HUD"), TEXT("UnitsMeterShort"), TEXT("متر"), TEXT("m"));
		const FString BannerStr = FString::Printf(TEXT("%s — %s  |  %s: %.0f %s"), *GuidanceLbl, *GoalName, *DistanceLbl, DistToGoal / 100.f, *GuidanceMeter);
		// S19-MISSUI: measured plate and bounded text, in the shared top-centre lane
		// (it used to be a fixed 440-wide plate at a fixed Y of 48 with an unbounded
		// DrawFarsiText - and both collided with the tutorial header strip).
		const float GuidS = 0.85f * UIS;
		float GuidTW = 0.f, GuidTH = 0.f;
		GetFarsiTextSize(BannerStr, Font, GuidS, GuidTW, GuidTH);
		const float BannerW = FMath::Min(ScreenW * 0.72f, GuidTW + 36.f * UIS);
		const float BannerH = 30.f * UIS;
		const float BannerX = (ScreenW - BannerW) * 0.5f;
		const float BannerY = ReserveTopNotice(BannerH);

		DrawChiseledTacticalBox(BannerX, BannerY, BannerW, BannerH,
			FLinearColor(0.035f, 0.045f, 0.065f, 0.92f * GuidanceVisionBlendAlpha),
			FLinearColor(1.0f, 0.82f, 0.25f, 0.95f * GuidanceVisionBlendAlpha), 1.0f, 6.0f);

		DrawFarsiTextBounded(BannerStr, FLinearColor(1.0f, 0.90f, 0.60f, GuidanceVisionBlendAlpha),
			BannerX + 16.f * UIS, BannerY, BannerW - 32.f * UIS, Font, GuidS, true, false, BannerH);

		// Tactical Intel Markers: Highlight downed allies with pulsing rescue beacons
		if (USoldierRegistrySubsystem* Reg = GetWorld()->GetSubsystem<USoldierRegistrySubsystem>())
		{
			for (const TWeakObjectPtr<ASoldierCharacter>& WeakS : Reg->GetAllSoldiers())
			{
				ASoldierCharacter* S = WeakS.Get();
				if (!S || !S->IsAlive() || S == PlayerPawn) continue;

				FVector2D DotScreen;
				if (PC->ProjectWorldLocationToScreen(S->GetActorLocation() + FVector(0.f, 0.f, 60.f * UIS), DotScreen))
				{
					if (DotScreen.X > 20.f * UIS && DotScreen.X < ScreenW - 20.f * UIS && DotScreen.Y > 20.f * UIS && DotScreen.Y < ScreenH - 20.f * UIS)
					{
						if (S->IsAlly() && S->IsDowned())
						{
							const float PulseR = 12.f * UIS + 4.f * UIS * FMath::Sin(TimeSec * 10.f);
							DrawCircleLines(FLinearColor(1.0f, 0.15f, 0.15f, 0.95f * GuidanceVisionBlendAlpha), DotScreen.X, DotScreen.Y, PulseR, 2.0f * UIS);
							DrawFarsiText(SquadAIHUDLocal(this, TEXT("HUD"), TEXT("DownedAllyAidMarker"), TEXT("همرزم مجروح - امدادرسانی"), TEXT("Wounded ally - aid")), FLinearColor(1.0f, 0.35f, 0.35f, GuidanceVisionBlendAlpha), DotScreen.X - 50.f * UIS, DotScreen.Y - 22.f * UIS, Font, 0.75f * UIS, true);
						}
						else
						{
							const FLinearColor DotCol = S->IsAlly() ? FLinearColor(0.2f, 0.65f, 1.0f, 0.85f * GuidanceVisionBlendAlpha) : FLinearColor(1.0f, 0.2f, 0.2f, 0.85f * GuidanceVisionBlendAlpha);
							DrawFilledCircleArea(DotCol, DotScreen.X, DotScreen.Y, 3.5f * UIS);
						}
					}
				}
			}
		}
	}
}

const TArray<TWeakObjectPtr<AActor>>& AQuestNativeHUD::GetCachedActorsOfClass(TSubclassOf<AActor> Class, float RefreshSeconds) const
{
	// S18-PERF: one scan per class per RefreshSeconds instead of per frame.
	static const TArray<TWeakObjectPtr<AActor>> Empty;
	UWorld* World = GetWorld();
	if (!World || !*Class)
	{
		return Empty;
	}

	FSquadAIActorCache& Cache = ActorCaches.FindOrAdd(Class.Get());
	const float Now = World->GetTimeSeconds();
	if (Now >= Cache.NextRefreshTime)
	{
		Cache.Actors.Reset();
		for (TActorIterator<AActor> It(World, Class); It; ++It)
		{
			Cache.Actors.Add(*It);
		}
		// Jitter the refresh so several caches never rebuild on the same frame.
		Cache.NextRefreshTime = Now + FMath::Max(0.1f, RefreshSeconds) + FMath::FRandRange(0.f, 0.15f);
	}
	return Cache.Actors;
}

FString AQuestNativeHUD::StripKeyTokens(const FString& In)
{
	// S18-PROMPT: legacy prompts bake the key into the sentence ("[E] Resupply",
	// "[Hold E] Revive"). The keycap is drawn separately now, so cut the token.
	FString Out = In;
	int32 Open = INDEX_NONE;
	while (Out.FindChar(TEXT('['), Open))
	{
		int32 Close = INDEX_NONE;
		if (!Out.FindChar(TEXT(']'), Close) || Close < Open) break;
		Out.RemoveAt(Open, Close - Open + 1, EAllowShrinking::Yes);
	}
	return Out.TrimStartAndEnd();
}

float AQuestNativeHUD::DrawWorldPrompt(const FVector2D& ScreenPos, const FString& KeyLabel, const FString& Text,
	UFont* Font, float Alpha, float HoldPct, bool bActive, const FString& SubText)
{
	const float S = GameUIScale;
	const float CapH = 24.f * S;
	const float PlateH = SubText.IsEmpty() ? 38.f * S : 54.f * S;
	// S26-FIXUI SWEEP: every width here used to be GUESSED from the character
	// count. Farsi glyphs run wider than 7.6 px a character, so the bounded
	// draw shrank real words into tiny grey smudges - the "ugly text" report.
	// MEASURE the keycap label, the prompt and the sub-line, then size the
	// plate to what they actually need (DrawKeycap measures with the same
	// helper at the same 0.74*S scale, so cap and plate always agree).
	float CapLabelW = 0.f, CapLabelH = 0.f;
	if (Font && !KeyLabel.IsEmpty())
	{
		GetFarsiTextSize(KeyLabel, Font, 0.74f * S, CapLabelW, CapLabelH);
	}
	if (CapLabelW <= 0.f)
	{
		CapLabelW = KeyLabel.Len() * 8.5f * S;
	}
	const float CapW = FMath::Max(CapH, CapLabelW + 18.f * S);
	float MainW = 0.f, MainH = 0.f;
	if (Font && !Text.IsEmpty())
	{
		GetFarsiTextSize(Text, Font, 0.80f * S, MainW, MainH);
	}
	if (MainW <= 0.f)
	{
		MainW = Text.Len() * 7.6f * S;
	}
	float SubW = 0.f, SubH = 0.f;
	if (Font && !SubText.IsEmpty())
	{
		GetFarsiTextSize(SubText, Font, 0.68f * S, SubW, SubH);
	}
	if (SubW <= 0.f && !SubText.IsEmpty())
	{
		SubW = SubText.Len() * 7.0f * S;
	}
	const float TextW = FMath::Clamp(FMath::Max(MainW, SubW) + 12.f * S, 90.f * S, 520.f * S);
	const float PlateW = CapW + TextW + 26.f * S;

	const float X = ScreenPos.X - PlateW * 0.5f;
	const float Y = ScreenPos.Y - PlateH * 0.5f;

	const FLinearColor Edge = bActive ? FLinearColor(1.0f, 0.84f, 0.3f, 0.85f * Alpha)
									  : FLinearColor(0.62f, 0.68f, 0.76f, 0.45f * Alpha);

	// Soft plate: shadow, body, gold left rule — same family as the tutorial banner.
	DrawRect(FLinearColor(0.f, 0.f, 0.f, 0.35f * Alpha), X + 2.f * S, Y + 3.f * S, PlateW, PlateH);
	DrawRect(FLinearColor(0.02f, 0.03f, 0.045f, 0.72f * Alpha), X, Y, PlateW, PlateH);
	DrawRect(Edge, X, Y, 2.5f * S, PlateH);
	DrawRect(FLinearColor(1.f, 1.f, 1.f, 0.06f * Alpha), X, Y, PlateW, 1.f * S);

	// Keycap, vertically centred in the plate.
	if (!KeyLabel.IsEmpty())
	{
		DrawKeycap(X + 10.f * S, Y + (PlateH - CapH) * 0.5f, KeyLabel, S, Font, CapH);
	}

	const float TX = X + 10.f * S + CapW + 10.f * S;
	DrawFarsiTextBounded(Text, FLinearColor(0.96f, 0.96f, 0.98f, Alpha),
		TX, Y + (SubText.IsEmpty() ? 0.f : -6.f * S), TextW, Font, 0.80f * S, true, true, PlateH);
	if (!SubText.IsEmpty())
	{
		DrawFarsiTextBounded(SubText, FLinearColor(0.78f, 0.82f, 0.88f, 0.9f * Alpha),
			TX, Y + PlateH - 20.f * S, TextW, Font, 0.68f * S, true, true, 16.f * S);
	}

	// Hold progress: a clean bar across the bottom edge of the plate.
	if (HoldPct >= 0.f)
	{
		const float BarH = 3.f * S;
		DrawRect(FLinearColor(1.f, 1.f, 1.f, 0.18f * Alpha), X, Y + PlateH - BarH, PlateW, BarH);
		DrawRect(FLinearColor(0.25f, 0.95f, 0.45f, 0.95f * Alpha), X, Y + PlateH - BarH, PlateW * FMath::Clamp(HoldPct, 0.f, 1.f), BarH);
	}
	return PlateW;
}

void AQuestNativeHUD::DrawBattlefieldInteractionPrompts(UFont* Font, APawn* PlayerPawn)
{
	if (!Canvas || !GetWorld() || !PlayerPawn) return;
	const float S = GameUIScale; // B6-14: resolution scale (menu-HUD parity).


	APlayerController* PC = UGameplayStatics::GetPlayerController(GetWorld(), 0);
	if (!PC) return;

	const FVector PlayerLoc = PlayerPawn->GetActorLocation();

	// E-arbitration: recomputed below; world actors read last frame's value (1-frame stale, fine).
	bReviveAvailableCache = false;

	// 1. Ammo Crates
	for (const TWeakObjectPtr<AActor>& WeakIt : GetCachedActorsOfClass(AAmmoCrateActor::StaticClass())) // S18-PERF
	{
		AAmmoCrateActor* Crate = Cast<AAmmoCrateActor>(WeakIt.Get());
		if (!Crate || !Crate->IsAvailable()) continue;

		const float Dist = FVector::Dist(PlayerLoc, Crate->GetActorLocation());
		if (Dist > 400.f) continue;

		FVector2D ScreenPos;
		const FVector PromptWorldLoc = Crate->GetActorLocation() + FVector(0.f, 0.f, 45.f * S);
		if (PC->ProjectWorldLocationToScreen(PromptWorldLoc, ScreenPos))
		{
			if (ScreenPos.X < 20.f * S || ScreenPos.X > Canvas->ClipX - 20.f * S ||
				ScreenPos.Y < 20.f * S || ScreenPos.Y > Canvas->ClipY - 20.f * S)
			{
				continue;
			}

			const bool bInRange = Dist <= 220.f;
			const FLinearColor BgColor = FLinearColor(0.04f, 0.05f, 0.07f, 0.90f);
			const FLinearColor AccentColor = bInRange ? FLinearColor(1.0f, 0.85f, 0.25f, 1.0f) : FLinearColor(0.6f, 0.65f, 0.7f, 0.75f);

			// S18-PROMPT: unified keycap prompt.
			const FString Prompt = SquadAIHUDLocal(this, TEXT("HUD"), TEXT("AmmoCratePrompt"), Crate->PromptText.IsEmpty() ? TEXT("[E] دریافت مهمات") : *Crate->PromptText, TEXT("[E] Resupply ammo"));
			DrawWorldPrompt(ScreenPos, bInRange ? TEXT("E") : FString(), StripKeyTokens(Prompt), Font,
				bInRange ? 1.f : 0.55f, -1.f, bInRange);
		}
	}

	// 2. Downed Allies & Revive Prompts (Followers ONLY — Squad Leader Shahid Rostami is heroic/invincible)
	if (USoldierRegistrySubsystem* Reg = GetWorld()->GetSubsystem<USoldierRegistrySubsystem>())
	{
		for (const TWeakObjectPtr<ASoldierCharacter>& WeakSoldier : Reg->GetAllSoldiers())
		{
			ASoldierCharacter* Soldier = WeakSoldier.Get();
			if (!Soldier || !Soldier->IsAlly() || !Soldier->IsDowned() || Soldier->IsSquadLeader())
			{
				continue;
			}

			// S12-DOWN v2: measure to the BODY, not the abandoned capsule.
			const FVector BodyLoc = Soldier->GetBodyLocation();
			const float Dist = FVector::Dist(PlayerLoc, BodyLoc);
			if (Dist > 800.f) continue; // B6-14: revive prompt was visible to 2000 cm.

			FVector2D ScreenPos;
			const FVector PromptWorldLoc = BodyLoc + FVector(0.f, 0.f, 55.f * S);
			if (PC->ProjectWorldLocationToScreen(PromptWorldLoc, ScreenPos))
			{
				if (ScreenPos.X < 20.f * S || ScreenPos.X > Canvas->ClipX - 20.f * S ||
					ScreenPos.Y < 20.f * S || ScreenPos.Y > Canvas->ClipY - 20.f * S)
				{
					continue;
				}

				const bool bInRange = Dist <= 220.f;
				if (bInRange) bReviveAvailableCache = true;
				const float BleedPct = FMath::Clamp(Soldier->BleedoutTimeRemaining / FMath::Max(1.0f, Soldier->MaxBleedoutTime), 0.f, 1.f);
				const FLinearColor BgColor = FLinearColor(0.12f, 0.02f, 0.02f, 0.95f);
				const FLinearColor AccentColor = bInRange ? FLinearColor(1.0f, 0.25f, 0.20f, 1.0f) : FLinearColor(1.0f, 0.75f, 0.25f, 0.90f);

				const float BoxW = 210.f * S;
				const float BoxH = 42.f * S;
				DrawRect(BgColor, ScreenPos.X - BoxW * 0.5f, ScreenPos.Y - BoxH * 0.5f, BoxW, BoxH);
				DrawRect(AccentColor, ScreenPos.X - BoxW * 0.5f, ScreenPos.Y - BoxH * 0.5f, 4.f * S, BoxH);

				// Bleedout time bar
				DrawRect(FLinearColor(0.25f, 0.25f, 0.25f, 0.8f), ScreenPos.X - BoxW * 0.5f + 6.f * S, ScreenPos.Y + BoxH * 0.5f - 6.f * S, BoxW - 12.f * S, 4.f * S);
				DrawRect(AccentColor, ScreenPos.X - BoxW * 0.5f + 6.f * S, ScreenPos.Y + BoxH * 0.5f - 6.f * S, (BoxW - 12.f * S) * BleedPct, 4.f * S);

				// S18-PROMPT: hold-to-revive in the shared prompt language — the
				// keycap tells you WHAT, the bar tells you HOW LONG.
				float RevivePct = -1.f;
				if (bInRange && !WasWorldEConsumedThisFrame() && PC->IsInputKeyDown(EKeys::E))
				{
					Soldier->ApplyReviveProgress(GetWorld()->GetDeltaSeconds(), PlayerPawn);
					RevivePct = FMath::Clamp(Soldier->CurrentReviveProgress / FMath::Max(0.1f, Soldier->RequiredReviveTime), 0.f, 1.f);
				}
				const FString Prompt = bInRange
					? SquadAIHUDLocal(this, TEXT("HUD"), TEXT("ReviveHoldPrompt"), TEXT("نگه‌دار: مداوا و احیای همرزم"), TEXT("Hold to heal and revive"))
					: (SquadAIHUDIsEnglish(this) ? FString::Printf(TEXT("Wounded ally (%.0f m)"), Dist / 100.f) : FString::Printf(TEXT("همرزم مجروح (%.0f متر)"), Dist / 100.f));
				const FString Sub = (RevivePct >= 0.f)
					? SquadAIHUDLocal(this, TEXT("HUD"), TEXT("ReviveProgress"), TEXT("در حال پانسمان و مداوا..."), TEXT("Bandaging and treating..."))
					: FString();
				DrawWorldPrompt(ScreenPos, bInRange ? TEXT("E") : FString(), StripKeyTokens(Prompt), Font,
					bInRange ? 1.f : 0.6f, bInRange ? FMath::Max(RevivePct, 0.f) : -1.f, bInRange, Sub);
			}
		}
	}

	// 3. Field First Aid Kits & Medical Stations
	for (const TWeakObjectPtr<AActor>& WeakIt : GetCachedActorsOfClass(AFirstAidKitActor::StaticClass())) // S18-PERF
	{
		AFirstAidKitActor* Kit = Cast<AFirstAidKitActor>(WeakIt.Get());
		if (!Kit || !Kit->IsAvailable()) continue;

		const float Dist = FVector::Dist(PlayerLoc, Kit->GetActorLocation());
		if (Dist > 400.f) continue;

		FVector2D ScreenPos;
		const FVector PromptWorldLoc = Kit->GetActorLocation() + FVector(0.f, 0.f, 45.f * S);
		if (PC->ProjectWorldLocationToScreen(PromptWorldLoc, ScreenPos))
		{
			if (ScreenPos.X < 20.f * S || ScreenPos.X > Canvas->ClipX - 20.f * S ||
				ScreenPos.Y < 20.f * S || ScreenPos.Y > Canvas->ClipY - 20.f * S)
			{
				continue;
			}

			const bool bInRange = Dist <= 200.f;
			const FLinearColor BgColor = FLinearColor(0.04f, 0.08f, 0.05f, 0.92f);
			const FLinearColor AccentColor = bInRange ? FLinearColor(0.2f, 0.85f, 0.4f, 1.0f) : FLinearColor(0.5f, 0.75f, 0.6f, 0.8f);

			const float BoxW = 180.f * S;
			const float BoxH = 34.f * S;
			DrawRect(BgColor, ScreenPos.X - BoxW * 0.5f, ScreenPos.Y - BoxH * 0.5f, BoxW, BoxH);
			DrawRect(AccentColor, ScreenPos.X - BoxW * 0.5f, ScreenPos.Y - BoxH * 0.5f, 3.f * S, BoxH);

			DrawWorldPrompt(ScreenPos, TEXT("E"), StripKeyTokens(SquadAIHUDLocal(this, TEXT("HUD"), TEXT("PickupFirstAid"), TEXT("[E] برداشتن بسته امدادی"), TEXT("[E] Pick up first-aid kit"))), Font); // S18-PROMPT
		}
	}

	// 4. Medical Stations (B6-17/B7-18: prompt-less until now).
	for (const TWeakObjectPtr<AActor>& WeakIt : GetCachedActorsOfClass(AMedicalStationActor::StaticClass())) // S18-PERF
	{
		AMedicalStationActor* Station = Cast<AMedicalStationActor>(WeakIt.Get());
		if (!Station) continue;

		const float Dist = FVector::Dist(PlayerLoc, Station->GetActorLocation());
		if (Dist > 400.f) continue;

		FVector2D ScreenPos;
		const FVector PromptWorldLoc = Station->GetActorLocation() + FVector(0.f, 0.f, 55.f * S);
		if (PC->ProjectWorldLocationToScreen(PromptWorldLoc, ScreenPos))
		{
			if (ScreenPos.X < 20.f * S || ScreenPos.X > Canvas->ClipX - 20.f * S ||
				ScreenPos.Y < 20.f * S || ScreenPos.Y > Canvas->ClipY - 20.f * S)
			{
				continue;
			}

			const bool bInRange = Dist <= Station->InteractionRadius;
			const bool bReady = Station->IsReady();
			const FLinearColor BgColor = FLinearColor(0.05f, 0.08f, 0.08f, 0.92f);
			const FLinearColor AccentColor = (bInRange && bReady) ? FLinearColor(0.25f, 0.85f, 0.85f, 1.0f) : FLinearColor(0.5f, 0.65f, 0.65f, 0.8f);

			const float BoxW = 190.f * S;
			const float BoxH = 34.f * S;
			DrawRect(BgColor, ScreenPos.X - BoxW * 0.5f, ScreenPos.Y - BoxH * 0.5f, BoxW, BoxH);
			DrawRect(AccentColor, ScreenPos.X - BoxW * 0.5f, ScreenPos.Y - BoxH * 0.5f, 3.f * S, BoxH);

			const FString Prompt = bReady
			? (SquadAIHUDIsEnglish(this) ? SquadAIHUDLocal(this, TEXT("HUD"), TEXT("MedicalStationPrompt"), Station->PromptText.IsEmpty() ? TEXT("ایستگاه امداد") : *Station->PromptText, TEXT("Use medical station [E]")) : Station->PromptText)
			: SquadAIHUDLocal(this, TEXT("HUD"), TEXT("MedicalStationPreparing"), TEXT("ایستگاه امداد (آماده‌سازی...)"), TEXT("Medical station preparing..."));
			DrawWorldPrompt(ScreenPos, bInRange ? TEXT("E") : FString(), StripKeyTokens(Prompt), Font, bInRange ? 1.f : 0.6f, -1.f, bInRange); // S18-PROMPT
		}
	}

	// 5. Mounted Turrets (B6-17/B7-18 + B7-20 mounted state).
	for (const TWeakObjectPtr<AActor>& WeakIt : GetCachedActorsOfClass(AMountedTurretActor::StaticClass())) // S18-PERF
	{
		AMountedTurretActor* Turret = Cast<AMountedTurretActor>(WeakIt.Get());
		if (!Turret) continue;

		const bool bMountedByPlayer = Turret->bIsMounted && Turret->GetMountedPawn() == PlayerPawn;
		const float Dist = FVector::Dist(PlayerLoc, Turret->GetActorLocation());
		if (Dist > 400.f) continue;

		FVector2D ScreenPos;
		const FVector PromptWorldLoc = Turret->GetActorLocation() + FVector(0.f, 0.f, 70.f * S);
		if (PC->ProjectWorldLocationToScreen(PromptWorldLoc, ScreenPos))
		{
			if (ScreenPos.X < 20.f * S || ScreenPos.X > Canvas->ClipX - 20.f * S ||
				ScreenPos.Y < 20.f * S || ScreenPos.Y > Canvas->ClipY - 20.f * S)
			{
				continue;
			}

			const bool bInRange = Dist <= 220.f;
			const FLinearColor BgColor = bMountedByPlayer ? FLinearColor(0.10f, 0.07f, 0.02f, 0.95f) : FLinearColor(0.07f, 0.06f, 0.03f, 0.92f);
			const FLinearColor AccentColor = (bMountedByPlayer || bInRange) ? FLinearColor(1.0f, 0.70f, 0.20f, 1.0f) : FLinearColor(0.65f, 0.55f, 0.40f, 0.8f);

			const float BoxW = 250.f * S;
			const float BoxH = 34.f * S;
			DrawRect(BgColor, ScreenPos.X - BoxW * 0.5f, ScreenPos.Y - BoxH * 0.5f, BoxW, BoxH);
			DrawRect(AccentColor, ScreenPos.X - BoxW * 0.5f, ScreenPos.Y - BoxH * 0.5f, 3.f * S, BoxH);

			const FString Prompt = bMountedByPlayer
			? SquadAIHUDLocal(this, TEXT("HUD"), TEXT("MountedTurretExit"), TEXT("مستقر پشت تیربار [E] ترک | آتش: کلیک چپ"), TEXT("Mounted on machine gun [E] Exit | Fire: Left Click"))
			: (SquadAIHUDIsEnglish(this) ? SquadAIHUDLocal(this, TEXT("HUD"), TEXT("MountedTurretEnter"), Turret->MountPromptText.IsEmpty() ? TEXT("تیربار") : *Turret->MountPromptText, TEXT("Mount machine gun [E]")) : Turret->MountPromptText);
			DrawWorldPrompt(ScreenPos, bInRange ? TEXT("E") : FString(), StripKeyTokens(Prompt), Font, bInRange ? 1.f : 0.6f, -1.f, bInRange); // S18-PROMPT
		}
	}

	// 6. Explosive Barrels (B7-18: hazard marker only — deliberately NO [E] prompt,
	// they detonate by damage, not interaction).
	for (const TWeakObjectPtr<AActor>& WeakIt : GetCachedActorsOfClass(AExplosiveBarrelActor::StaticClass())) // S18-PERF
	{
		AExplosiveBarrelActor* Barrel = Cast<AExplosiveBarrelActor>(WeakIt.Get());
		if (!Barrel || Barrel->IsDetonated()) continue;

		const float Dist = FVector::Dist(PlayerLoc, Barrel->GetActorLocation());
		if (Dist > 800.f) continue;

		FVector2D ScreenPos;
		const FVector PromptWorldLoc = Barrel->GetActorLocation() + FVector(0.f, 0.f, 50.f * S);
		if (PC->ProjectWorldLocationToScreen(PromptWorldLoc, ScreenPos))
		{
			if (ScreenPos.X < 20.f * S || ScreenPos.X > Canvas->ClipX - 20.f * S ||
				ScreenPos.Y < 20.f * S || ScreenPos.Y > Canvas->ClipY - 20.f * S)
			{
				continue;
			}

			const bool bClose = Dist <= Barrel->ExplosionRadius;
			const FLinearColor MarkCol = bClose ? FLinearColor(1.0f, 0.15f, 0.10f, 1.0f) : FLinearColor(1.0f, 0.45f, 0.15f, 0.85f);
			DrawFilledCircleArea(MarkCol, ScreenPos.X, ScreenPos.Y, 5.f * S);
			if (bClose)
			{
				DrawFarsiText(SquadAIHUDLocal(this, TEXT("HUD"), TEXT("ExplosionDanger"), TEXT("خطر انفجار!"), TEXT("Explosion danger!")), MarkCol, ScreenPos.X + 10.f * S, ScreenPos.Y - 8.f * S, Font, 0.78f * S, true);
			}
		}
	}
}

void AQuestNativeHUD::DrawChiseledTacticalBox(float X, float Y, float W, float H, const FLinearColor& FillColor, const FLinearColor& BorderColor, float Thickness, float Chamfer)
{
	if (!Canvas) return;
	// MEGA-10 AAA: drop shadow + inner highlight + double frame — kill flat 2D.
	DrawRect(FLinearColor(0.f,0.f,0.f,0.45f), X+4.f, Y+4.f, W, H);
	DrawRect(FillColor, X, Y, W, H);
	DrawRect(FLinearColor(1.f,0.94f,0.62f,0.08f), X, Y, W, H*0.33f);
	DrawRect(FLinearColor(0.f,0.f,0.f,0.16f), X, Y+H*0.75f, W, H*0.25f);
	const float C = FMath::Clamp(Chamfer, 2.0f, FMath::Min(W, H) * 0.3f);
	DrawLine(X + C, Y, X + W - C, Y, BorderColor, Thickness*1.4f);
	DrawLine(X + W, Y + C, X + W, Y + H - C, BorderColor, Thickness*1.4f);
	DrawLine(X + W - C, Y + H, X + C, Y + H, BorderColor, Thickness*1.4f);
	DrawLine(X, Y + H - C, X, Y + C, BorderColor, Thickness*1.4f);
	DrawLine(X, Y + C, X + C, Y, BorderColor, Thickness*1.4f);
	DrawLine(X + W - C, Y, X + W, Y + C, BorderColor, Thickness*1.4f);
	DrawLine(X + W, Y + H - C, X + W - C, Y + H, BorderColor, Thickness*1.4f);
	DrawLine(X + C, Y + H, X, Y + H - C, BorderColor, Thickness*1.4f);
	const float TickLen = 5.5f;
	const FLinearColor TickCol(BorderColor.R, BorderColor.G, BorderColor.B, FMath::Min(1.0f, BorderColor.A * 1.35f));
	DrawLine(X - 2.f, Y + C, X + TickLen, Y + C, TickCol, Thickness*1.2f);
	DrawLine(X + W - TickLen, Y + C, X + W + 2.f, Y + C, TickCol, Thickness*1.2f);
}

void AQuestNativeHUD::DrawWeaponSilhouette(const FString& WeaponName, float X, float Y, float Scale, const FLinearColor& Color)
{
	if (!Canvas) return;
	const float S = Scale;
	const float Thick = 1.5f;

	if (WeaponName.Contains(TEXT("RPG")) || WeaponName.Contains(TEXT("آرپی‌جی")))
	{
		DrawLine(X + 5.f * S, Y, X + 22.f * S, Y - 7.f * S, Color, Thick);
		DrawLine(X + 5.f * S, Y, X + 22.f * S, Y + 7.f * S, Color, Thick);
		DrawLine(X + 22.f * S, Y - 7.f * S, X + 22.f * S, Y + 7.f * S, Color, Thick);
		DrawLine(X + 22.f * S, Y - 3.5f * S, X + 75.f * S, Y - 3.5f * S, Color, Thick);
		DrawLine(X + 22.f * S, Y + 3.5f * S, X + 75.f * S, Y + 3.5f * S, Color, Thick);
		DrawLine(X + 75.f * S, Y - 3.5f * S, X + 92.f * S, Y - 7.f * S, Color, Thick);
		DrawLine(X + 75.f * S, Y + 3.5f * S, X + 92.f * S, Y + 7.f * S, Color, Thick);
		DrawLine(X + 92.f * S, Y - 7.f * S, X + 92.f * S, Y + 7.f * S, Color, Thick);
		DrawLine(X + 42.f * S, Y + 3.5f * S, X + 45.f * S, Y + 16.f * S, Color, Thick);
		DrawLine(X + 60.f * S, Y + 3.5f * S, X + 63.f * S, Y + 15.f * S, Color, Thick);
		DrawLine(X + 46.f * S, Y - 3.5f * S, X + 50.f * S, Y - 11.f * S, Color, Thick);
		DrawLine(X + 44.f * S, Y - 11.f * S, X + 56.f * S, Y - 11.f * S, Color, Thick);
	}
	else if (WeaponName.Contains(TEXT("AK")) || WeaponName.Contains(TEXT("کلاش")))
	{
		DrawLine(X, Y, X + 45.f * S, Y, Color, Thick);
		DrawLine(X + 8.f * S, Y - 6.f * S, X + 8.f * S, Y, Color, Thick);
		DrawLine(X + 12.f * S, Y - 3.f * S, X + 42.f * S, Y - 3.f * S, Color, Thick);
		DrawLine(X + 42.f * S, Y - 4.f * S, X + 68.f * S, Y - 4.f * S, Color, Thick);
		DrawLine(X + 42.f * S, Y + 4.f * S, X + 68.f * S, Y + 4.f * S, Color, Thick);
		DrawLine(X + 68.f * S, Y - 4.f * S, X + 68.f * S, Y + 4.f * S, Color, Thick);
		DrawLine(X + 48.f * S, Y + 4.f * S, X + 44.f * S, Y + 18.f * S, Color, Thick);
		DrawLine(X + 54.f * S, Y + 4.f * S, X + 51.f * S, Y + 19.f * S, Color, Thick);
		DrawLine(X + 44.f * S, Y + 18.f * S, X + 51.f * S, Y + 19.f * S, Color, Thick);
		DrawLine(X + 63.f * S, Y + 4.f * S, X + 67.f * S, Y + 16.f * S, Color, Thick);
		DrawLine(X + 68.f * S, Y - 2.f * S, X + 92.f * S, Y + 5.f * S, Color, Thick);
		DrawLine(X + 68.f * S, Y + 3.f * S, X + 92.f * S, Y + 10.f * S, Color, Thick);
		DrawLine(X + 92.f * S, Y + 5.f * S, X + 92.f * S, Y + 10.f * S, Color, Thick);
	}
	else if (WeaponName.Contains(TEXT("SVD")) || WeaponName.Contains(TEXT("دراگونوف")) || WeaponName.Contains(TEXT("Sniper")))
	{
		DrawLine(X - 8.f * S, Y, X + 45.f * S, Y, Color, Thick);
		DrawLine(X, Y - 5.f * S, X, Y, Color, Thick);
		DrawLine(X + 15.f * S, Y - 3.f * S, X + 45.f * S, Y - 3.f * S, Color, Thick);
		DrawLine(X + 15.f * S, Y + 3.f * S, X + 45.f * S, Y + 3.f * S, Color, Thick);
		DrawLine(X + 45.f * S, Y - 4.f * S, X + 70.f * S, Y - 4.f * S, Color, Thick);
		DrawLine(X + 45.f * S, Y + 4.f * S, X + 70.f * S, Y + 4.f * S, Color, Thick);
		DrawLine(X + 50.f * S, Y - 4.f * S, X + 53.f * S, Y - 11.f * S, Color, Thick);
		DrawLine(X + 42.f * S, Y - 11.f * S, X + 64.f * S, Y - 11.f * S, Color, Thick);
		DrawLine(X + 49.f * S, Y + 4.f * S, X + 49.f * S, Y + 13.f * S, Color, Thick);
		DrawLine(X + 56.f * S, Y + 4.f * S, X + 56.f * S, Y + 13.f * S, Color, Thick);
		DrawLine(X + 49.f * S, Y + 13.f * S, X + 56.f * S, Y + 13.f * S, Color, Thick);
		DrawLine(X + 70.f * S, Y - 3.f * S, X + 98.f * S, Y + 4.f * S, Color, Thick);
		DrawLine(X + 70.f * S, Y + 4.f * S, X + 75.f * S, Y + 15.f * S, Color, Thick);
		DrawLine(X + 75.f * S, Y + 15.f * S, X + 98.f * S, Y + 12.f * S, Color, Thick);
		DrawLine(X + 98.f * S, Y + 4.f * S, X + 98.f * S, Y + 12.f * S, Color, Thick);
	}
	else
	{
		DrawLine(X, Y, X + 48.f * S, Y, Color, Thick);
		DrawLine(X + 6.f * S, Y - 5.f * S, X + 6.f * S, Y, Color, Thick);
		DrawLine(X + 12.f * S, Y - 3.5f * S, X + 45.f * S, Y - 3.5f * S, Color, Thick);
		DrawLine(X + 12.f * S, Y + 3.5f * S, X + 45.f * S, Y + 3.5f * S, Color, Thick);
		DrawLine(X + 45.f * S, Y - 4.5f * S, X + 72.f * S, Y - 4.5f * S, Color, Thick);
		DrawLine(X + 45.f * S, Y + 4.5f * S, X + 72.f * S, Y + 4.5f * S, Color, Thick);
		DrawLine(X + 72.f * S, Y - 4.5f * S, X + 72.f * S, Y + 4.5f * S, Color, Thick);
		DrawLine(X + 65.f * S, Y - 4.5f * S, X + 65.f * S, Y - 8.5f * S, Color, Thick);
		DrawLine(X + 49.f * S, Y + 4.5f * S, X + 49.f * S, Y + 17.f * S, Color, Thick);
		DrawLine(X + 57.f * S, Y + 4.5f * S, X + 57.f * S, Y + 17.f * S, Color, Thick);
		DrawLine(X + 49.f * S, Y + 17.f * S, X + 57.f * S, Y + 17.f * S, Color, Thick);
		DrawLine(X + 66.f * S, Y + 4.5f * S, X + 70.f * S, Y + 16.f * S, Color, Thick);
		DrawLine(X + 72.f * S, Y - 3.f * S, X + 96.f * S, Y + 4.f * S, Color, Thick);
		DrawLine(X + 72.f * S, Y + 3.f * S, X + 96.f * S, Y + 9.f * S, Color, Thick);
		DrawLine(X + 96.f * S, Y + 4.f * S, X + 96.f * S, Y + 9.f * S, Color, Thick);
	}
}

void AQuestNativeHUD::DrawDeploymentVeil(float ScreenW, float ScreenH, float DeltaTime, UFont* Font)
{
	if (!Canvas) return;
	const float S = GameUIScale; // B6-14: resolution scale (menu-HUD parity).


	USquadAILocalizationSubsystem* LocSys = USquadAILocalizationSubsystem::Get(this);
	const FString TitleStr = LocSys ? LocSys->GetString(TEXT("Loading"), TEXT("LoadingTitle"), TEXT("منطقه عملیاتی خوزستان — خط مقدم دهلاویه")) : TEXT("منطقه عملیاتی خوزستان — خط مقدم دهلاویه");
	const FString DescStr = LocSys ? LocSys->GetString(TEXT("Loading"), TEXT("LoadingDesc"), TEXT("در حال بارگذاری تجهیزات، تثبیت فرکانس بی‌سیم و هماهنگی جوخه...")) : TEXT("در حال بارگذاری تجهیزات، تثبیت فرکانس بی‌سیم و هماهنگی جوخه...");
	const FString EnterPromptStr = LocSys ? LocSys->GetString(TEXT("Loading"), TEXT("PressEnterPrompt"), TEXT("برای ورود به میدان نبرد کلید [Enter] یا [Space] را فشار دهید")) : TEXT("برای ورود به میدان نبرد کلید [Enter] یا [Space] را فشار دهید");

	// Auto-resolve textures if not yet bound
	// P6-5: was per-frame (disk re-stat storm while art missing); throttled to one retry
	// per 2 s of wall time. See the pause-menu block for details — same fix.
	if (!DeploymentVeilArtwork || !LoadingBarFrameTexture || !LoadingBarFillTexture)
	{
		const double NowWallSec = FPlatformTime::Seconds();
		if ((NowWallSec - DeploymentVeilArtRetryTime) >= 2.0)
		{
			DeploymentVeilArtRetryTime = NowWallSec;
			if (!DeploymentVeilArtwork) DeploymentVeilArtwork = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Loading_Background_TrenchAssault.Loading_Background_TrenchAssault"), TEXT("Textures/Loading_Background_TrenchAssault.png"));
			if (!LoadingBarFrameTexture) LoadingBarFrameTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_LoadingBar_Frame.UI_LoadingBar_Frame"), TEXT("Textures/UI_LoadingBar_Frame.png"));
			if (!LoadingBarFillTexture) LoadingBarFillTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_LoadingBar_Fill.UI_LoadingBar_Fill"), TEXT("Textures/UI_LoadingBar_Fill.png"));
		}
	}

	// 1. Full Screen Artwork / Background
	if (DeploymentVeilArtwork)
	{
		DrawTexture(DeploymentVeilArtwork, 0.f, 0.f, ScreenW, ScreenH, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
	}
	else
	{
		DrawRect(FLinearColor(0.035f, 0.045f, 0.065f, 1.0f), 0.f, 0.f, ScreenW, ScreenH);
	}

	// 2. Cinematic Vignette & Ambient Darkness
	DrawRect(FLinearColor(0.0f, 0.0f, 0.0f, 0.40f), 0.f, 0.f, ScreenW, ScreenH);

	// Advance loading progress smoothly.
	//
	// S19-INSTANT: on the first frame of the veil, adopt the bar the MENU had already
	// filled during the blocking travel, so the progress the player watched in the menu
	// continues here instead of snapping back to zero. Whoever is on screen, the same
	// ramp (0.42/s), the same cap - one transition, one bar.
	if (!bDeploymentVeilAdoptedHandoff)
	{
		bDeploymentVeilAdoptedHandoff = true;
		if (USquadAILoadingScreenSubsystem* LoadSys = USquadAILoadingScreenSubsystem::Get(this))
		{
			// The travel has already fired by the time this world draws, so the value is
			// read from the handoff rather than gated on "pending".
			DeploymentProgress = FMath::Max(DeploymentProgress, LoadSys->GetTransitionProgress());
			// This world's first paint also tells the subsystem the destination is really
			// up (the travel gate ignores it once travelled; the HUD handshake reads it).
			LoadSys->NotifyDepartureScreenPainted();
		}
	}
	if (DeploymentProgress < 1.0f)
	{
		DeploymentProgress = FMath::Min(1.0f, DeploymentProgress + (DeltaTime * 0.42f));
		if (DeploymentProgress >= 1.0f)
		{
			bDeploymentVeilReadyToDeploy = true;
		}
	}

	// Check for Enter / Space / Gamepad Accept / Left Mouse Click when 100% loaded
	if (bDeploymentVeilReadyToDeploy)
	{
		EnterPromptPulseTimer += DeltaTime * 4.0f;

		APlayerController* PC = UGameplayStatics::GetPlayerController(GetWorld(), 0);
		if (PC)
		{
			if (PC->WasInputKeyJustPressed(EKeys::Enter) ||
				PC->WasInputKeyJustPressed(EKeys::SpaceBar) ||
				PC->WasInputKeyJustPressed(EKeys::Gamepad_FaceButton_Bottom) ||
				PC->WasInputKeyJustPressed(EKeys::LeftMouseButton))
			{
				bDeploymentVeilActive = false;
				OnDeploymentVeilDismissed(); // S17-STORY: fade-in + onboarding + queued briefing
				if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
				{
					AudioSys->PlayTacticalVoiceline(ETacticalVoicelineType::Leader_OrderMove, UGameplayStatics::GetPlayerPawn(GetWorld(), 0));
				}
				return;
			}
		}
	}

	// 3. Tactical Loading Dossier Card (Bottom-Center, Generous Padding)
	const float CardW = FMath::Min(880.f * S, ScreenW - 60.f * S);
	const float CardH = 220.f * S;
	const float CardX = (ScreenW - CardW) * 0.5f;
	const float CardY = ScreenH - CardH - 40.f * S;

	DrawChiseledTacticalBox(CardX, CardY, CardW, CardH,
		FLinearColor(0.03f, 0.04f, 0.06f, 0.96f),
		FLinearColor(1.0f, 0.82f, 0.25f, 0.95f), 1.5f * S, 10.0f * S);

	DrawFarsiTextBounded(TitleStr,
		FLinearColor(1.0f, 0.88f, 0.35f, 1.0f), CardX + 24.f * S, CardY + 16.f * S, CardW - 48.f * S, Font, 1.45f * S, true);

	DrawFarsiTextBounded(DescStr,
		FLinearColor(0.92f, 0.95f, 0.98f, 1.0f), CardX + 24.f * S, CardY + 54.f * S, CardW - 48.f * S, Font, 1.10f * S, true);

	// 4. Graphical 3D Styled Tactical Progress Bar
	const float BarW = CardW - 48.f * S;
	const float BarH = 18.f * S;
	const float BarX = CardX + 24.f * S;
	const float BarY = CardY + 92.f * S;

	// Outer frame
	DrawRect(FLinearColor(0.06f, 0.08f, 0.12f, 0.98f), BarX, BarY, BarW, BarH);
	DrawRect(FLinearColor(0.40f, 0.48f, 0.60f, 0.85f), BarX, BarY, BarW, 1.5f * S);
	DrawRect(FLinearColor(0.40f, 0.48f, 0.60f, 0.85f), BarX, BarY + BarH - 1.5f * S, BarW, 1.5f * S);

	// Fill with 3D metallic and amber pulse
	const float FillW = BarW * FMath::Clamp(DeploymentProgress, 0.02f, 1.0f);
	if (LoadingBarFillTexture)
	{
		DrawTexture(LoadingBarFillTexture, BarX, BarY, FillW, BarH, 0.f, 0.f, DeploymentProgress, 1.f, FLinearColor(1.0f, 0.85f, 0.25f, 1.0f));
	}
	else
	{
		DrawRect(FLinearColor(0.95f, 0.72f, 0.15f, 1.0f), BarX, BarY, FillW, BarH);
		DrawRect(FLinearColor(1.0f, 0.95f, 0.65f, 0.85f), BarX, BarY + 2.f * S, FillW, 4.f * S);
		DrawRect(FLinearColor(0.45f, 0.25f, 0.05f, 0.70f), BarX, BarY + BarH - 4.f * S, FillW, 3.f * S);
	}

	// Percentage Text
	const int32 PctInt = FMath::RoundToInt(DeploymentProgress * 100.f);
	const FString PctStr = FString::Printf(TEXT("%%%d"), PctInt);
	DrawFarsiTextBounded(PctStr, FLinearColor(1.0f, 0.90f, 0.40f, 1.0f), BarX + BarW - 85.f * S, BarY - 26.f * S, 80.f * S, Font, 1.05f * S, true, true);

	// 5. Distinct Enter Prompt Action Box (Spaced cleanly below progress bar with PNG Plate)
	const float PromptBoxW = CardW - 48.f * S;
	const float PromptBoxH = 48.f * S;
	const float PromptBoxX = CardX + 24.f * S;
	const float PromptBoxY = CardY + 130.f * S;

	if (bDeploymentVeilReadyToDeploy)
	{
		const float Alpha = 0.65f + 0.35f * FMath::Sin(EnterPromptPulseTimer);
		if (ButtonHoverTexture)
		{
			DrawTexture(ButtonHoverTexture, PromptBoxX, PromptBoxY, PromptBoxW, PromptBoxH, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
		}
		else
		{
			DrawChiseledTacticalBox(PromptBoxX, PromptBoxY, PromptBoxW, PromptBoxH,
				FLinearColor(0.08f, 0.22f, 0.12f, 0.95f),
				FLinearColor(0.30f, 1.0f, 0.45f, Alpha), 1.5f * S, 6.0f * S);
		}

		DrawFarsiTextBounded(EnterPromptStr,
			FLinearColor(1.0f, 1.0f, 1.0f, 1.0f), PromptBoxX, PromptBoxY, PromptBoxW, Font, 1.20f * S, true, true, PromptBoxH);
	}
	else
	{
		if (ButtonNormalTexture)
		{
			DrawTexture(ButtonNormalTexture, PromptBoxX, PromptBoxY, PromptBoxW, PromptBoxH, 0.f, 0.f, 1.f, 1.f, FLinearColor(0.7f, 0.7f, 0.75f, 0.85f));
		}
		else
		{
			DrawChiseledTacticalBox(PromptBoxX, PromptBoxY, PromptBoxW, PromptBoxH,
				FLinearColor(0.05f, 0.06f, 0.08f, 0.80f),
				FLinearColor(0.30f, 0.35f, 0.42f, 0.60f), 1.0f * S, 6.0f * S);
		}

		DrawFarsiTextBounded(SquadAIHUDLocal(this, TEXT("Loading"), TEXT("DeploymentVeil"), TEXT("در حال استقرار نیروها و هماهنگی بی‌سیم..."), TEXT("Deploying forces and coordinating radio...")),
			FLinearColor(0.80f, 0.85f, 0.90f, 0.95f), PromptBoxX, PromptBoxY, PromptBoxW, Font, 1.00f * S, true, true, PromptBoxH);
	}
}

void AQuestNativeHUD::DrawDynamicTacticalReticle(float CX, float CY, APawn* PlayerPawn, float DeltaTime, UFont* Font)
{
	if (!Canvas) return;
	const float S = GameUIScale; // B6-14: resolution scale (menu-HUD parity).


	float TargetSpread = 14.0f * S;
	if (PlayerPawn)
	{
		const float Speed = PlayerPawn->GetVelocity().Size2D();
		if (ASoldierCharacter* SC = Cast<ASoldierCharacter>(PlayerPawn))
		{
			if (SC->bIsCrouched)
			{
				TargetSpread = (Speed > 10.f) ? 14.0f * S : 8.0f * S;
			}
			else if (Speed > 450.f)
			{
				TargetSpread = 32.0f * S;
			}
			else if (Speed > 20.f)
			{
				TargetSpread = 22.0f * S;
			}
			else
			{
				TargetSpread = 12.0f * S;
			}
		}
	}

	ReticleSpreadCurrent = FMath::FInterpTo(ReticleSpreadCurrent, TargetSpread, DeltaTime, 12.0f);

	const float Sp = ReticleSpreadCurrent;
	const float PipLen = 6.0f * S;
	const float Thick = 1.5f * S;
	const FLinearColor ReticleCol(0.92f, 0.94f, 0.96f, 0.70f);

	DrawFilledCircleArea(FLinearColor(1.0f, 0.85f, 0.35f, 0.85f), CX, CY, 1.5f * S);

	DrawLine(CX, CY - Sp - PipLen, CX, CY - Sp, ReticleCol, Thick);
	DrawLine(CX, CY + Sp, CX, CY + Sp + PipLen, ReticleCol, Thick);
	DrawLine(CX - Sp - PipLen, CY, CX - Sp, CY, ReticleCol, Thick);
	DrawLine(CX + Sp, CY, CX + Sp + PipLen, CY, ReticleCol, Thick);

	DrawLine(CX - Sp - 2.f * S, CY - 2.f * S, CX - Sp - 2.f * S, CY + 2.f * S, ReticleCol, 1.0f * S);
	DrawLine(CX + Sp + 2.f * S, CY - 2.f * S, CX + Sp + 2.f * S, CY + 2.f * S, ReticleCol, 1.0f * S);
}
void AQuestNativeHUD::RegisterIncomingMortarWarning(const FVector& Location, float Radius, float Duration, float TimeUntilImpact)
{
	FIncomingMortarThreat Threat;
	Threat.ImpactCenter = Location;
	Threat.BlastRadius = Radius;
	Threat.TimeRemaining = TimeUntilImpact;
	Threat.TotalDuration = Duration;
	ActiveMortarThreats.Add(Threat);
}

void AQuestNativeHUD::SetMortarAimingActive(bool bActive, const FVector& AimLocation)
{
	bMortarAimingActive = bActive;
	if (bActive)
	{
		MortarAimTargetLocation = AimLocation;
	}
}

UDecalComponent* AQuestNativeHUD::EnsureMortarDecal(FIncomingMortarThreat& Threat)
{
	// S13-FX: the danger zone used to be drawn with Canvas DrawLine. Canvas lines
	// are flat, unshaded, constant-width screen-space polylines - they receive no
	// light, no depth and no ground contact, so however they are arranged they
	// read as "drawn in Paint" (a stack of concentric ones reads as a contour
	// map, which is what testing reported). A projected decal is the only way to
	// get a marker that actually sits ON the terrain, follows every bump and
	// crater, and is shaded by the scene.
	if (Threat.Decal.IsValid())
	{
		return Threat.Decal.Get();
	}

	UWorld* World = GetWorld();
	if (!World)
	{
		return nullptr;
	}

	// Loaded by path so a missing asset degrades to the canvas fallback rather
	// than breaking the build.
	UMaterialInterface* Base = LoadObject<UMaterialInterface>(
		nullptr, TEXT("/Game/SquadAI/Materials/Village/M_MortarDangerDecal.M_MortarDangerDecal"));
	if (!Base)
	{
		return nullptr;
	}

	// Decals project along -X of their own rotation, so pitch -90 aims down. X is
	// the projection depth: generous, so the marker still lands on slopes and in
	// shell craters instead of floating.
	UDecalComponent* Decal = UGameplayStatics::SpawnDecalAtLocation(
		World, Base,
		FVector(Threat.BlastRadius * 1.2f, Threat.BlastRadius, Threat.BlastRadius),
		Threat.ImpactCenter + FVector(0.f, 0.f, 200.f),
		FRotator(-90.f, 0.f, 0.f),
		0.f);

	if (!Decal)
	{
		return nullptr;
	}

	Decal->SetFadeScreenSize(0.0f);   // never pop out at distance
	Threat.Decal = Decal;
	if (UMaterialInstanceDynamic* MID = Decal->CreateDynamicMaterialInstance())
	{
		Threat.DecalMID = MID;
	}
	return Decal;
}

void AQuestNativeHUD::DrawMortarDangerZones(APawn* PlayerPawn, float DeltaTime, UFont* Font)
{
	if (!Canvas || !GetWorld()) return;
	const float S = GameUIScale; // B6-14: resolution scale (menu-HUD parity).

	APlayerController* PC = PlayerPawn ? Cast<APlayerController>(PlayerPawn->GetController()) : nullptr;
	if (!PC) return;

	const float TimeNow = GetWorld()->GetTimeSeconds();

	for (int32 i = ActiveMortarThreats.Num() - 1; i >= 0; --i)
	{
		FIncomingMortarThreat& Threat = ActiveMortarThreats[i];
		Threat.TimeRemaining -= DeltaTime;
		Threat.TotalDuration -= DeltaTime;

		if (Threat.TotalDuration <= 0.0f)
		{
			// S13-FX: decals are real components - clean them up.
			if (UDecalComponent* Dead = Threat.Decal.Get())
			{
				Dead->DestroyComponent();
			}
			ActiveMortarThreats.RemoveAt(i);
			continue;
		}

		// 1. Draw 3D Ground Danger Ring (Accurately Snapped to Terrain)
		constexpr int32 Segments = 28;
		const float Step = (2.0f * PI) / Segments;
		
		auto SnapToGround = [&](const FVector& InPt) -> FVector
		{
			FHitResult GroundHit;
			FCollisionQueryParams TraceParams(SCENE_QUERY_STAT(MortarRing), false);
			if (GetWorld()->LineTraceSingleByChannel(GroundHit, InPt + FVector(0.f, 0.f, 800.f), InPt - FVector(0.f, 0.f, 1500.f), ECC_Visibility, TraceParams))
			{
				return GroundHit.ImpactPoint + FVector(0.f, 0.f, 6.f);
			}
			return InPt;
		};

		// B6-15: terrain snap (~43 traces/ring) refreshes at 10 Hz; projection stays per-frame.
		Threat.RingSnapTimer -= DeltaTime;
		if (Threat.RingSnapTimer <= 0.f || Threat.CachedRingPoints.Num() != Segments + 1)
		{
			Threat.RingSnapTimer = 0.1f;
			Threat.CachedRingPoints.Reset(Segments + 1);
			for (int32 s = 0; s <= Segments; ++s)
			{
				const float CacheAngle = s * Step;
				Threat.CachedRingPoints.Add(SnapToGround(Threat.ImpactCenter + FVector(FMath::Cos(CacheAngle) * Threat.BlastRadius, FMath::Sin(CacheAngle) * Threat.BlastRadius, 10.f)));
			}
		}

		// S13-FX: prefer a real ground decal; the canvas ring is only a fallback.
		const float Urgency = FMath::Clamp(1.0f - (Threat.TimeRemaining / 6.0f), 0.0f, 1.0f);
		const FLinearColor CalmCol(1.00f, 0.62f, 0.10f, 1.0f);   // amber: incoming
		const FLinearColor HotCol (1.00f, 0.10f, 0.05f, 1.0f);   // red: imminent
		const FLinearColor BaseCol = FMath::Lerp(CalmCol, HotCol, Urgency);

		UDecalComponent* Decal = EnsureMortarDecal(Threat);
		if (Decal)
		{
			// Keep the decal glued to the impact point and drive its look from the
			// same urgency value the badge uses.
			Decal->SetWorldLocation(Threat.ImpactCenter + FVector(0.f, 0.f, 200.f));
			if (UMaterialInstanceDynamic* MID = Threat.DecalMID.Get())
			{
				MID->SetScalarParameterValue(TEXT("Urgency"), Urgency);
				MID->SetScalarParameterValue(TEXT("TimeRemaining"), FMath::Max(0.f, Threat.TimeRemaining));
				// Fade in on spawn and out after the shell lands, so it never pops.
				const float FadeIn  = FMath::Clamp(Threat.TotalDuration * 4.0f, 0.f, 1.f);
				MID->SetScalarParameterValue(TEXT("Opacity"), FadeIn);
				MID->SetVectorParameterValue(TEXT("DangerColor"), BaseCol);
			}
		}
		else
		{
			// Fallback only: ONE soft ground-snapped ring. The previous six
			// concentric lines read as a contour map.
			const float Pulse = 0.82f + 0.18f * FMath::Sin(TimeNow * (2.0f + 4.5f * Urgency) * 2.0f * PI);
			// S19-WARN: MSVC C4701. PrevPt is only ever read when bPrevOk is
			// true, which is set only after PrevPt is assigned, so this is
			// safe - but the compiler cannot prove it. Initialising is a no-op.
			FVector2D PrevPt = FVector2D::ZeroVector;
			bool bPrevOk = false;
			for (int32 s = 0; s <= Segments; ++s)
			{
				FVector2D ScreenPt = FVector2D::ZeroVector;
				const bool bOk = PC->ProjectWorldLocationToScreen(Threat.CachedRingPoints[s], ScreenPt);
				if (bPrevOk && bOk)
				{
					FLinearColor C = BaseCol;
					C.A = 0.85f * Pulse;
					DrawLine(PrevPt.X, PrevPt.Y, ScreenPt.X, ScreenPt.Y, C, 3.0f * S);
				}
				PrevPt = ScreenPt;
				bPrevOk = bOk;
			}
		}

		// 2. Projected Floating Hazard Badge & Countdown
		FVector2D CenterScreen;
		if (PC->ProjectWorldLocationToScreen(Threat.ImpactCenter + FVector(0.f, 0.f, 60.f * S), CenterScreen))
		{
			if (CenterScreen.X >= 0 && CenterScreen.X <= Canvas->ClipX &&
				CenterScreen.Y >= 0 && CenterScreen.Y <= Canvas->ClipY)
			{
				const float BadgeW = 220.f * S;
				const float BadgeH = 38.f * S;
				DrawRect(FLinearColor(0.15f, 0.02f, 0.02f, 0.95f), CenterScreen.X - BadgeW * 0.5f, CenterScreen.Y - BadgeH * 0.5f, BadgeW, BadgeH);
				const FLinearColor BadgeAccent = BaseCol;
				DrawRect(BadgeAccent, CenterScreen.X - BadgeW * 0.5f, CenterScreen.Y - BadgeH * 0.5f, 5.f * S, BadgeH);
				DrawRect(BadgeAccent, CenterScreen.X + BadgeW * 0.5f - 5.f * S, CenterScreen.Y - BadgeH * 0.5f, 5.f * S, BadgeH);

					const bool bEnglishHUD = SquadAIHUDIsEnglish(this);
					const FString TimeLabel = Threat.TimeRemaining > 0.0f
						? (bEnglishHUD ? FString::Printf(TEXT("⚠️ Mortar impact danger: %.1f seconds"), Threat.TimeRemaining) : FString::Printf(TEXT("⚠️ خطر اصابت خمپاره: %.1f ثانیه"), Threat.TimeRemaining))
						: (bEnglishHUD ? FString(TEXT("⚠️ Heavy mortar impact!")) : FString(TEXT("⚠️ اصابت آتش سنگین خمپاره!")));

				DrawFarsiText(TimeLabel, FLinearColor(1.0f, 0.92f, 0.35f, 1.0f), CenterScreen.X - BadgeW * 0.5f + 14.f * S, CenterScreen.Y - 10.f * S, Font, 0.85f * S, true);
			}
		}
	}
}

void AQuestNativeHUD::DrawMortarTargetingMarker(APawn* PlayerPawn, float DeltaTime, UFont* Font)
{
	if (!bMortarAimingActive || !Canvas || !GetWorld()) return;
	const float S = GameUIScale; // B6-14: resolution scale (menu-HUD parity).

	APlayerController* PC = PlayerPawn ? Cast<APlayerController>(PlayerPawn->GetController()) : nullptr;
	if (!PC) return;

	const float TimeNow = GetWorld()->GetTimeSeconds();
	const float ReticleAlpha = 0.85f + 0.15f * FMath::Sin(TimeNow * 8.0f);
	const FLinearColor MarkerCol(0.20f, 0.85f, 1.0f, ReticleAlpha);
	const FLinearColor OuterCol(1.0f, 0.75f, 0.20f, ReticleAlpha * 0.8f);

	const float BlastRadius = 750.f;
	const float DispersionRadius = 450.f;

	// 1. Draw Outer Blast Circle & Inner Dispersion Circle on Ground
	constexpr int32 Segments = 24;
	const float Step = (2.0f * PI) / Segments;

	auto DrawWorldGroundCircle = [&](float Radius, const FLinearColor& LineColor, float LineThick)
	{
		FVector PrevWorldPt = MortarAimTargetLocation + FVector(FMath::Cos(0.f) * Radius, FMath::Sin(0.f) * Radius, 10.f);
		FVector2D PrevScreenPt;
		bool bPrevVisible = PC->ProjectWorldLocationToScreen(PrevWorldPt, PrevScreenPt);

		for (int32 s = 1; s <= Segments; ++s)
		{
			const float Angle = s * Step;
			FVector WorldPt = MortarAimTargetLocation + FVector(FMath::Cos(Angle) * Radius, FMath::Sin(Angle) * Radius, 10.f);
			FVector2D ScreenPt;
			const bool bVisible = PC->ProjectWorldLocationToScreen(WorldPt, ScreenPt);

			if (bPrevVisible && bVisible)
			{
				DrawLine(PrevScreenPt.X, PrevScreenPt.Y, ScreenPt.X, ScreenPt.Y, LineColor, LineThick);
			}

			PrevWorldPt = WorldPt;
			PrevScreenPt = ScreenPt;
			bPrevVisible = bVisible;
		}
	};

	DrawWorldGroundCircle(BlastRadius, OuterCol, 1.5f * S);
	DrawWorldGroundCircle(DispersionRadius, MarkerCol, 2.5f * S);

	// 2. Animated Downward Holographic Guidance Arrows
	const float BobOffset = FMath::Sin(TimeNow * 6.0f) * 30.f;
	const FVector TopWorldLoc = MortarAimTargetLocation + FVector(0.f, 0.f, 220.f + BobOffset);
	const FVector BotWorldLoc = MortarAimTargetLocation + FVector(0.f, 0.f, 40.f);

	FVector2D TopScreen, BotScreen;
	if (PC->ProjectWorldLocationToScreen(TopWorldLoc, TopScreen) && PC->ProjectWorldLocationToScreen(BotWorldLoc, BotScreen))
	{
		DrawLine(TopScreen.X, TopScreen.Y, BotScreen.X, BotScreen.Y, MarkerCol, 3.0f * S);
		// Arrowhead
		DrawLine(BotScreen.X - 12.f * S, BotScreen.Y - 18.f * S, BotScreen.X, BotScreen.Y, MarkerCol, 3.0f * S);
		DrawLine(BotScreen.X + 12.f * S, BotScreen.Y - 18.f * S, BotScreen.X, BotScreen.Y, MarkerCol, 3.0f * S);
	}

	// 3. Projected HUD Target Coordinates & Fire Order Card
	FVector2D CenterScreen;
	if (PC->ProjectWorldLocationToScreen(MortarAimTargetLocation + FVector(0.f, 0.f, 80.f * S), CenterScreen))
	{
		const float CardW = 280.f * S;
		const float CardH = 54.f * S;
		const float CardX = CenterScreen.X - CardW * 0.5f;
		const float CardY = CenterScreen.Y - CardH - 25.f * S;

		DrawChiseledTacticalBox(CardX, CardY, CardW, CardH,
			FLinearColor(0.02f, 0.04f, 0.08f, 0.95f),
			MarkerCol, 1.5f * S, 6.0f * S);

		const float DistM = PlayerPawn ? (FVector::Dist(PlayerPawn->GetActorLocation(), MortarAimTargetLocation) / 100.f) : 0.f;
		const FString MortarFmt = SquadAIHUDLocal(this, TEXT("HUD"), TEXT("MortarTargetHeaderFmt"), TEXT("هدف‌گیری خمپاره‌انداز ۱۲۰ میلی‌متری (%.0f متر)"), TEXT("120 mm artillery targeting (%.0f m)"));
		const FString HeaderStr = SquadAIFormatRuntime(*MortarFmt, DistM);
		DrawFarsiText(HeaderStr, MarkerCol, CardX + 12.f * S, CardY + 6.f * S, Font, 0.82f * S, true);

		DrawFarsiText(SquadAIHUDLocal(this, TEXT("HUD"), TEXT("MortarReleasePrompt"), TEXT("[رها کردن کلید وسط] شلیک آتشبار پشتیبانی"), TEXT("[Release Middle Mouse] Fire artillery support")), FLinearColor::White, CardX + 12.f * S, CardY + 28.f * S, Font, 0.78f * S, true);
	}
}

void AQuestNativeHUD::DrawTacticalWeaponStatusPlate(float ScreenW, float ScreenH, APawn* PlayerPawn, UFont* Font)
{
	if (!Canvas) return;
	const float S = GameUIScale;
	const bool bEnglishHUD = SquadAIHUDIsEnglish(this);

	// S27-REFUI: Matches index.html .weapons { right: 2.5%; bottom: calc(3% + 48px); width: min(33vw, 390px); height: 110px }
	// and .weapon-foot { right: 2.5%; bottom: 3%; 5 quick-slot tiles of 44x42px }
	const float RightEdge = ScreenW * 0.975f;
	const float FootH = 42.f * S;
	const float FootY = ScreenH * 0.97f - FootH;
	const float PlateW = FMath::Min(390.f * S, ScreenW * 0.33f);
	const float PlateH = 110.f * S;
	const float PlateX = RightEdge - PlateW;
	const float PlateY = FootY - 6.f * S - PlateH;

	RegisterTutorialUIRect(TEXT("Weapon"), PlateX, PlateY, PlateW, PlateH + 6.f * S + FootH);
	RegisterTutorialUIRect(TEXT("Artillery"), PlateX, PlateY + PlateH - 32.f * S, PlateW, 32.f * S);

	// Resolve live weapon & ammo state across InventorySubsystem, native WeaponComp, and TPWCS reflected components
	int32 ClipAmmo = 20;
	int32 ReserveAmmo = 120;
	int32 SidearmTotalAmmo = 57;
	FString WepName = bEnglishHUD ? TEXT("SERVICE RIFLE / G3A3") : TEXT("سلاح سازمانی / ژ-۳ (G3A3)");
	FString WepKeyForIcon = TEXT("G3A3");
	FString CaliberLabel = bEnglishHUD ? TEXT("7.62 NATO") : TEXT("۷.۶۲ ناتو");
	FString SubCaption = bEnglishHUD
		? TEXT("H&K G3A3 BATTLE RIFLE • IRON SIGHTS • 7.62 NATO")
		: TEXT("تفنگ جنگی ژ-۳ • مگسک آهنی • کالیبر ۷.۶۲ ناتو");
	bool bIsAutoFire = true;
	bool bSidearmSelected = false;

	auto ApplyWeaponMetadata = [&](const FString& InKey)
	{
		if (InKey.Contains(TEXT("AK"), ESearchCase::IgnoreCase))
		{
			WepKeyForIcon = TEXT("AK47");
			WepName = bEnglishHUD ? TEXT("ASSAULT RIFLE / AK-47") : TEXT("سلاح هجومی / کلاشینکف AK-47");
			CaliberLabel = bEnglishHUD ? TEXT("7.62x39") : TEXT("۷.۶۲×۳۹");
			SubCaption = bEnglishHUD
				? TEXT("KALASHNIKOV AK-47 • IRON SIGHTS • 7.62x39MM")
				: TEXT("سلاح هجومی کلاشینکف • مگسک آهنی • کالیبر ۷.۶۲×۳۹");
			bIsAutoFire = true;
		}
		else if (InKey.Contains(TEXT("RPG"), ESearchCase::IgnoreCase))
		{
			WepKeyForIcon = TEXT("RPG7");
			WepName = bEnglishHUD ? TEXT("ANTI-ARMOR / RPG-7") : TEXT("ضدزره / راکت‌انداز RPG-7");
			CaliberLabel = bEnglishHUD ? TEXT("85MM PG-7V") : TEXT("۸۵ میلی‌متری");
			SubCaption = bEnglishHUD
				? TEXT("RPG-7 LAUNCHER • IRON SIGHTS • 85MM HEAT")
				: TEXT("راکت‌انداز آرپی‌جی-۷ • خرج گود ضدزره • ۸۵ میلی‌متری");
			bIsAutoFire = false;
		}
		else if (InKey.Contains(TEXT("MG3"), ESearchCase::IgnoreCase) || InKey.Contains(TEXT("PKM"), ESearchCase::IgnoreCase))
		{
			WepKeyForIcon = TEXT("MG3");
			WepName = bEnglishHUD ? TEXT("MACHINE GUN / MG3") : TEXT("تیربار پشتیبانی / MG3");
			CaliberLabel = bEnglishHUD ? TEXT("7.62 NATO") : TEXT("۷.۶۲ ناتو");
			SubCaption = bEnglishHUD
				? TEXT("MG3 GENERAL PURPOSE MG • BELT FED • 7.62 NATO")
				: TEXT("تیربار سنگین پشتیبانی • نوار فشنگ • کالیبر ۷.۶۲ ناتو");
			bIsAutoFire = true;
		}
		else if (InKey.Contains(TEXT("SVD"), ESearchCase::IgnoreCase))
		{
			WepKeyForIcon = TEXT("SVD");
			WepName = bEnglishHUD ? TEXT("MARKSMAN / SVD DRAGUNOV") : TEXT("تک‌تیرانداز / دراگونوف SVD");
			CaliberLabel = bEnglishHUD ? TEXT("7.62x54R") : TEXT("۷.۶۲×۵۴");
			SubCaption = bEnglishHUD
				? TEXT("SVD DRAGUNOV RIFLE • SEMI-AUTO • 7.62x54MMR")
				: TEXT("تفنگ تک‌تیرانداز دراگونوف • نیمه‌خودکار • کالیبر ۷.۶۲×۵۴");
			bIsAutoFire = false;
		}
		else if (InKey.Contains(TEXT("Pistol"), ESearchCase::IgnoreCase) || InKey.Contains(TEXT("Tariq"), ESearchCase::IgnoreCase) || InKey.Contains(TEXT("Colt"), ESearchCase::IgnoreCase))
		{
			WepKeyForIcon = TEXT("Pistol");
			WepName = bEnglishHUD ? TEXT("SIDEARM / TARIQ 9MM") : TEXT("سلاح کمری / طارق ۹ میلی‌متری");
			CaliberLabel = bEnglishHUD ? TEXT("9x19MM") : TEXT("۹ میلی‌متری");
			SubCaption = bEnglishHUD
				? TEXT("SERVICE PISTOL • IRON SIGHTS • 9x19MM PARABELLUM")
				: TEXT("سلاح کمری سازمانی • مگسک آهنی • کالیبر ۹ میلی‌متری");
			bIsAutoFire = false;
			bSidearmSelected = true;
		}
		else if (InKey.Contains(TEXT("Knife"), ESearchCase::IgnoreCase) || InKey.Contains(TEXT("Melee"), ESearchCase::IgnoreCase) || InKey.Contains(TEXT("خنجر"), ESearchCase::IgnoreCase) || InKey.Contains(TEXT("سرنیزه"), ESearchCase::IgnoreCase))
		{
			WepKeyForIcon = TEXT("Knife");
			WepName = bEnglishHUD ? TEXT("COMBAT BLADE / BAYONET") : TEXT("سلاح سرد / خنجر رزمی و سرنیزه");
			CaliberLabel = bEnglishHUD ? TEXT("MELEE STEEL") : TEXT("نبرد تن‌به‌تن");
			SubCaption = bEnglishHUD
				? TEXT("TRENCH COMBAT KNIFE • CLOSE QUARTERS")
				: TEXT("خنجر رزمی سنگر • نبرد تن‌به‌تن و بی‌صدا");
			bIsAutoFire = false;
		}
		else
		{
			WepKeyForIcon = TEXT("G3A3");
			WepName = bEnglishHUD ? TEXT("SERVICE RIFLE / G3A3") : TEXT("سلاح سازمانی / ژ-۳ (G3A3)");
			CaliberLabel = bEnglishHUD ? TEXT("7.62 NATO") : TEXT("۷.۶۲ ناتو");
			SubCaption = bEnglishHUD
				? TEXT("H&K G3A3 BATTLE RIFLE • IRON SIGHTS • 7.62 NATO")
				: TEXT("تفنگ جنگی ژ-۳ • مگسک آهنی • کالیبر ۷.۶۲ ناتو");
			bIsAutoFire = true;
		}
	};

	// 1. Read from USquadAIInventorySubsystem (updated live by USquadAIPlayerCombatBridge, Backpack, and Armory)
	USquadAIInventorySubsystem* Inv = USquadAIInventorySubsystem::Get(PlayerPawn ? static_cast<const UObject*>(PlayerPawn) : static_cast<const UObject*>(this));
	if (Inv)
	{
		const FSquadInventoryWeaponItem CurWep = Inv->GetSelectedWeapon();
		if (!CurWep.WeaponID.IsNone())
		{
			ClipAmmo = FMath::Max(0, CurWep.ClipAmmo);
			ReserveAmmo = FMath::Max(0, CurWep.ReserveAmmo);
			ApplyWeaponMetadata(CurWep.WeaponID.ToString());
		}
		for (const FSquadInventoryWeaponItem& W : Inv->Weapons)
		{
			if (W.WeaponID == FName("Pistol"))
			{
				SidearmTotalAmmo = FMath::Max(0, W.ClipAmmo + W.ReserveAmmo);
				break;
			}
		}
	}

	// 2. Override with native UWeaponComponent or reflected TPWCS weapon component if actively tracking weapon/ammo
	if (PlayerPawn)
	{
		if (UWeaponComponent* NativeWC = PlayerPawn->FindComponentByClass<UWeaponComponent>())
		{
			if (NativeWC->CurrentClipAmmo > 0 || NativeWC->ReserveAmmo > 0 || !NativeWC->WeaponDisplayName.IsEmpty())
			{
				ClipAmmo = NativeWC->CurrentClipAmmo;
				ReserveAmmo = NativeWC->ReserveAmmo;
				if (!NativeWC->WeaponDisplayName.IsEmpty())
				{
					ApplyWeaponMetadata(NativeWC->WeaponDisplayName.ToString());
				}
			}
		}

		auto TryReadIntOrFloat = [](UObject* Obj, std::initializer_list<const TCHAR*> Names, int32& OutVal) -> bool
		{
			if (!Obj || !Obj->GetClass()) return false;
			for (const TCHAR* RawName : Names)
			{
				const FName PropName(RawName);
				if (FIntProperty* IP = FindFProperty<FIntProperty>(Obj->GetClass(), PropName))
				{
					OutVal = IP->GetPropertyValue_InContainer(Obj);
					return true;
				}
				if (FFloatProperty* FP = FindFProperty<FFloatProperty>(Obj->GetClass(), PropName))
				{
					OutVal = FMath::RoundToInt(FP->GetPropertyValue_InContainer(Obj));
					return true;
				}
				if (FDoubleProperty* DP = FindFProperty<FDoubleProperty>(Obj->GetClass(), PropName))
				{
					OutVal = FMath::RoundToInt(DP->GetPropertyValue_InContainer(Obj));
					return true;
				}
			}
			return false;
		};

		TArray<UObject*> WeaponSources;
		TArray<UActorComponent*> Comps;
		PlayerPawn->GetComponents(Comps);
		for (UActorComponent* C : Comps)
		{
			if (!C || C->IsA<UWeaponComponent>()) continue;
			const FString CN = C->GetName();
			if (CN.Contains(TEXT("Weapon"), ESearchCase::IgnoreCase) || CN.Contains(TEXT("Combat"), ESearchCase::IgnoreCase))
			{
				WeaponSources.Add(C);
				for (const TCHAR* WObjPropName : { TEXT("Active Weapon"), TEXT("ActiveWeapon"), TEXT("CurrentWeapon"), TEXT("EquippedWeapon") })
				{
					if (FObjectPropertyBase* OP = FindFProperty<FObjectPropertyBase>(C->GetClass(), FName(WObjPropName)))
					{
						if (UObject* SubWep = OP->GetObjectPropertyValue_InContainer(C))
						{
							WeaponSources.Add(SubWep);
						}
					}
				}
			}
		}
		TArray<AActor*> AttachedActors;
		PlayerPawn->GetAttachedActors(AttachedActors);
		for (AActor* Att : AttachedActors)
		{
			if (Att) WeaponSources.Add(Att);
		}

		const int32 MaxExpectedClip = (Inv && Inv->Weapons.IsValidIndex(Inv->SelectedWeaponIndex))
			? FMath::Max(1, Inv->Weapons[Inv->SelectedWeaponIndex].MaxClipAmmo)
			: 200;
		for (UObject* WSrc : WeaponSources)
		{
			for (const TCHAR* WepNameProp : { TEXT("Active Weapon"), TEXT("ActiveWeapon"), TEXT("CurrentWeapon") })
			{
				if (FNameProperty* NP = FindFProperty<FNameProperty>(WSrc->GetClass(), FName(WepNameProp)))
				{
					const FName PackWepID = NP->GetPropertyValue_InContainer(WSrc);
					if (!PackWepID.IsNone() && PackWepID != FName(TEXT("default")))
					{
						ApplyWeaponMetadata(PackWepID.ToString());
					}
				}
				else if (FStrProperty* SP = FindFProperty<FStrProperty>(WSrc->GetClass(), FName(WepNameProp)))
				{
					const FString PackWepStr = SP->GetPropertyValue_InContainer(WSrc);
					if (!PackWepStr.IsEmpty() && !PackWepStr.Equals(TEXT("default"), ESearchCase::IgnoreCase))
					{
						ApplyWeaponMetadata(PackWepStr);
					}
				}
			}
			int32 PackClip = -1, PackRes = -1;
			const bool bGotClip = TryReadIntOrFloat(WSrc, { TEXT("Ammo Clip Current"), TEXT("AmmoClipCurrent"), TEXT("currentAmmo"), TEXT("CurrentAmmo"), TEXT("ClipAmmo"), TEXT("AmmoInClip"), TEXT("MagAmmo") }, PackClip);
			const bool bGotRes  = TryReadIntOrFloat(WSrc, { TEXT("Ammo Current"), TEXT("AmmoCurrent"), TEXT("Ammo Total Current"), TEXT("AmmoTotalCurrent"), TEXT("Ammo Reserve Current"), TEXT("AmmoReserveCurrent"), TEXT("reserveAmmo"), TEXT("ReserveAmmo"), TEXT("TotalAmmo") }, PackRes);
			if (bGotClip && PackClip >= 0 && PackClip <= MaxExpectedClip)
			{
				ClipAmmo = PackClip;
				if (bGotRes && PackRes >= 0 && PackRes <= 999) ReserveAmmo = PackRes;
				if (Inv && Inv->Weapons.IsValidIndex(Inv->SelectedWeaponIndex))
				{
					Inv->Weapons[Inv->SelectedWeaponIndex].ClipAmmo = ClipAmmo;
					Inv->Weapons[Inv->SelectedWeaponIndex].ReserveAmmo = ReserveAmmo;
				}
				break;
			}
		}
	}

	int32 FragN = 2, SmokeN = 2;
	bool bAimingFrag = false, bAimingSmoke = false;
	UTacticalGrenadeComponent* GrenComp = PlayerPawn ? PlayerPawn->FindComponentByClass<UTacticalGrenadeComponent>() : nullptr;
	if (USquadAIInventorySubsystem* Inv = USquadAIInventorySubsystem::Get(PlayerPawn ? static_cast<const UObject*>(PlayerPawn) : static_cast<const UObject*>(this)))
	{
		FragN = FMath::Max(0, Inv->FragGrenades);
		SmokeN = FMath::Max(0, Inv->SmokeGrenades);
		if (GrenComp)
		{
			FragN = FMath::Min(FragN, FMath::Max(0, GrenComp->GetFragCount()));
			SmokeN = FMath::Min(SmokeN, FMath::Max(0, GrenComp->GetSmokeCount()));
		}
	}
	else if (GrenComp)
	{
		FragN = FMath::Max(0, GrenComp->GetFragCount());
		SmokeN = FMath::Max(0, GrenComp->GetSmokeCount());
	}
	if (GrenComp && GrenComp->IsAimingGrenade())
	{
		bAimingFrag  = (GrenComp->GetAimingGrenadeType() == EGrenadeType::Fragmentation);
		bAimingSmoke = (GrenComp->GetAimingGrenadeType() == EGrenadeType::SmokeScreen);
	}

	const float HPPercent = GetPlayerHealthPercent(PlayerPawn);
	const int32 HPInt = FMath::Clamp(FMath::RoundToInt(HPPercent * 100.f), 0, 100);
	const float ArmorPercent = GetPlayerArmorPercent(PlayerPawn);
	const int32 FilledArmorPips = FMath::Clamp(FMath::RoundToInt(ArmorPercent * 5.f), 0, 5);

	// 1. Main .weapons 9-slice rounded-bevel frosted glass housing (matches index.html line 157 .weapons: border-radius: 7px + inset: 3px keyline)
	Draw9SliceRoundedBox(PlateX, PlateY, PlateW, PlateH, FName(TEXT("GlassPanel")), 0.94f, S, 0.88f, true, 0.85f);

	const float TopSecH = 76.f * S;
	const float PadX = 8.f * S;
	const float WHealthW = 70.f * S;
	const float AmmoColW = 96.f * S;
	const float ArtColX = PlateX + PadX + WHealthW + 6.f * S;
	const float DivX = PlateX + PlateW - PadX - AmmoColW - 6.f * S;
	const float ArtColW = FMath::Max(80.f * S, DivX - ArtColX - 6.f * S);

	// 1a. Left column (.whealth): live HP + live Armor 5-pip bar (زره ▰ ▰ ▰ ▱ ▱ tightly grouped)
	{
		const float WX = PlateX + PadX;
		const float WY = PlateY + 10.f * S;
		const FString HPStr = bEnglishHUD
			? FString::Printf(TEXT("%d HP"), HPInt)
			: FString::Printf(TEXT("%s HP"), *UFarsiTextHelper::ToPersianDigits(FString::FromInt(HPInt)));
		const FLinearColor WepHPCol = (HPPercent < 0.30f)
			? FSquadAIHUDPalette::Danger()
			: ((HPPercent < 0.60f) ? FSquadAIHUDPalette::Warm() : FSquadAIHUDPalette::TextWhite());
		DrawFarsiText3D(HPStr, WepHPCol, WX, WY, WHealthW - 6.f * S, Font, 0.82f * S, true, false, 20.f * S, 1.2f * S);

		const float PipY = WY + 26.f * S;
		auto DrawParallelogramPip = [&](float PX, float PY, bool bFilled)
		{
			const FLinearColor Col = bFilled
				? FSquadAIHUDPalette::SRGB(232, 198, 138, 0.96f)
				: FSquadAIHUDPalette::SRGB(255, 255, 255, 0.28f);
			if (bFilled)
			{
				for (int32 r = 0; r < 6; ++r)
				{
					const float Skew = (5 - r) * 0.35f * S;
					DrawRect(Col, PX + Skew, PY + r * 1.0f * S, 4.6f * S, 1.15f * S);
				}
			}
			else
			{
				DrawLine(PX + 1.8f * S, PY, PX + 6.2f * S, PY, Col, 1.1f * S);
				DrawLine(PX + 6.2f * S, PY, PX + 4.4f * S, PY + 5.8f * S, Col, 1.1f * S);
				DrawLine(PX + 4.4f * S, PY + 5.8f * S, PX, PY + 5.8f * S, Col, 1.1f * S);
				DrawLine(PX, PY + 5.8f * S, PX + 1.8f * S, PY, Col, 1.1f * S);
			}
		};

		if (bEnglishHUD)
		{
			DrawFarsiTextBounded(TEXT("ARM"), FSquadAIHUDPalette::TextDim(),
				WX + 2.f * S, PipY - 2.f * S, 22.f * S, Font, 0.54f * S, true, false, 14.f * S);
			for (int32 Pi = 0; Pi < 5; ++Pi)
			{
				DrawParallelogramPip(WX + 25.f * S + Pi * 7.2f * S, PipY + 2.f * S, Pi < FilledArmorPips);
			}
		}
		else
		{
			// RTL: "زره" on the right, 5 sheared parallelogram pips (▰ ▰ ▰ ▱ ▱) filling right-to-left immediately to its left
			for (int32 Pi = 0; Pi < 5; ++Pi)
			{
				DrawParallelogramPip(WX + 4.f * S + Pi * 7.2f * S, PipY + 2.f * S, Pi >= (5 - FilledArmorPips));
			}
			DrawFarsiTextBounded(TEXT("زره"), FSquadAIHUDPalette::TextDim(),
				WX + 41.f * S, PipY - 2.f * S, 22.f * S, Font, 0.56f * S, true, false, 14.f * S, false);
		}
		DrawRect(FSquadAIHUDPalette::Hairline(), WX + WHealthW - 1.f * S, PlateY + 10.f * S, 1.f * S, TopSecH - 18.f * S);
	}

	// 1b. Center column (.weapon-art): live weapon caption + 3D weapon icon + attachment caption
	{
		DrawFarsiTextBounded(WepName, FSquadAIHUDPalette::SRGB(210, 202, 189, 0.96f),
			ArtColX, PlateY + 5.f * S, ArtColW, Font, 0.60f * S, true, true, 14.f * S);

		UTexture2D* RifleTex = nullptr;
		if (bSidearmSelected)
		{
			RifleTex = GetUITexture(FName(TEXT("IconSidearm3D")));
		}
		else if (WepKeyForIcon == TEXT("G3A3"))
		{
			RifleTex = GetUITexture(FName(TEXT("IconRifle3D")));
			if (!RifleTex) RifleTex = GetHUDWeaponIcon(WepKeyForIcon);
		}
		else
		{
			RifleTex = GetHUDWeaponIcon(WepKeyForIcon);
			if (!RifleTex) RifleTex = GetUITexture(FName(TEXT("IconRifle3D")));
		}
		if (RifleTex)
		{
			const float IconW = bSidearmSelected ? FMath::Min(ArtColW - 24.f * S, 76.f * S) : FMath::Min(ArtColW - 8.f * S, 138.f * S);
			const float IconH = bSidearmSelected ? 36.f * S : 42.f * S;
			const float IconX = ArtColX + (ArtColW - IconW) * 0.5f;
			const float IconY = PlateY + 18.f * S + (42.f * S - IconH) * 0.5f;
			DrawTexture(RifleTex, IconX + 1.5f * S, IconY + 2.f * S, IconW, IconH, 0.f, 0.f, 1.f, 1.f, FLinearColor(0.f, 0.f, 0.f, 0.65f));
			DrawTexture(RifleTex, IconX, IconY, IconW, IconH, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
		}
		else
		{
			DrawWeaponSilhouette(WepKeyForIcon, ArtColX + 18.f * S, PlateY + 36.f * S, 1.0f * S, FSquadAIHUDPalette::GoldText());
		}

		DrawFarsiTextBounded(SubCaption, FSquadAIHUDPalette::SRGB(198, 191, 178, 0.94f),
			ArtColX - 4.f * S, PlateY + TopSecH - 16.f * S, ArtColW + 8.f * S, Font, 0.54f * S, true, true, 14.f * S);
	}

	// Vertical divider (.divider)
	DrawRect(FSquadAIHUDPalette::Hairline(), DivX, PlateY + 8.f * S, 1.f * S, TopSecH - 14.f * S);

	// 1c. Right column (.ammo): live fire mode + live magazine count + live reserve ammo • caliber
	{
		const float AX = DivX + 6.f * S;
		const float AW = AmmoColW;
		const float PillW = 36.f * S, PillH = 14.f * S;
		DrawFarsiTextBounded(bEnglishHUD ? TEXT("FIRE") : TEXT("حالت شلیک"),
			FSquadAIHUDPalette::TextDim(),
			AX, PlateY + 6.f * S, AW - PillW - 4.f * S, Font, 0.50f * S, true, false, 14.f * S);
		const float PillX = AX + AW - PillW;
		const float PillY = PlateY + 6.f * S;
		Draw9SliceRoundedBox(PillX, PillY, PillW, PillH, FName(TEXT("StepTileCurrent")), 0.85f, S, 0.45f, false, 0.f);
		const FString FireModeLbl = bIsAutoFire
			? (bEnglishHUD ? TEXT("AUTO") : TEXT("خودکار"))
			: (bEnglishHUD ? TEXT("SEMI") : TEXT("تک‌تیر"));
		DrawFarsiTextBounded(FireModeLbl,
			FSquadAIHUDPalette::GoldText(), PillX + 2.f * S, PillY, PillW - 4.f * S, Font, 0.50f * S, false, true, PillH);

		const FString MagStr = bEnglishHUD
			? FString::FromInt(ClipAmmo)
			: UFarsiTextHelper::ToPersianDigits(FString::FromInt(ClipAmmo));
		const FLinearColor MagCol = (ClipAmmo <= 4)
			? FSquadAIHUDPalette::Warm()
			: FSquadAIHUDPalette::TextWhite();
		DrawFarsiText3D(MagStr, MagCol,
			AX, PlateY + 20.f * S, AW, Font, 1.34f * S, true, false, 36.f * S, 1.4f * S);

		const FString ResStr = bEnglishHUD
			? FString::Printf(TEXT("%d • %s"), ReserveAmmo, *CaliberLabel)
			: FString::Printf(TEXT("%s • %s"), *UFarsiTextHelper::ToPersianDigits(FString::FromInt(ReserveAmmo)), *CaliberLabel);
		DrawFarsiTextBounded(ResStr, FSquadAIHUDPalette::TextDim(),
			AX, PlateY + TopSecH - 17.f * S, AW, Font, 0.58f * S, true, true, 15.f * S);
	}

	// 2. Bottom secondary inventory strip (.weapon-extra, 3 compartments matching index.html line 71 & 193 SVG icons)
	{
		const float ExtraY = PlateY + TopSecH;
		const float ExtraH = PlateH - TopSecH;
		DrawRect(FSquadAIHUDPalette::SRGB(10, 12, 11, 0.36f), PlateX + 5.f * S, ExtraY, PlateW - 10.f * S, ExtraH - 4.f * S);
		DrawRect(FSquadAIHUDPalette::Hairline(), PlateX + 4.f * S, ExtraY, PlateW - 8.f * S, 1.f * S);

		const float CellW = (PlateW - 12.f * S) / 3.f;
		const FLinearColor SvgStroke = FSquadAIHUDPalette::SRGB(238, 233, 222, 0.94f);
		for (int32 Ci = 0; Ci < 3; ++Ci)
		{
			const float CX0 = PlateX + 6.f * S + Ci * CellW;
			if (Ci > 0)
			{
				DrawRect(FSquadAIHUDPalette::Hairline(), CX0, ExtraY + 5.f * S, 1.f * S, ExtraH - 10.f * S);
			}
			if (Ci == 0)
			{
				// .weapon-extra .pistol: display:grid; grid-template-columns:28px auto; column-gap:4px (svg spans 2 rows; live sidearm rounds on row 1, ثانویه on row 2)
				const float GroupX = CX0 + (CellW - 76.f * S) * 0.5f;
				if (UTexture2D* SideTex = GetUITexture(FName(TEXT("IconSidearm3D"))))
				{
					DrawTexture(SideTex, GroupX, ExtraY + (ExtraH - 17.f * S) * 0.5f, 27.f * S, 17.f * S, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
				}
				const FString SidearmCntStr = bEnglishHUD
					? FString::FromInt(SidearmTotalAmmo)
					: UFarsiTextHelper::ToPersianDigits(FString::FromInt(SidearmTotalAmmo));
				DrawFarsiText3D(SidearmCntStr, bSidearmSelected ? FSquadAIHUDPalette::GoldText() : FSquadAIHUDPalette::TextWhite(),
					GroupX + 31.f * S, ExtraY + 3.f * S, 44.f * S, Font, 0.66f * S, false, false, 15.f * S, 1.0f * S);
				DrawFarsiTextBounded(bEnglishHUD ? TEXT("SIDEARM") : TEXT("ثانویه"), FSquadAIHUDPalette::TextDim(),
					GroupX + 31.f * S, ExtraY + 17.f * S, 46.f * S, Font, 0.50f * S, true, false, 13.f * S, false);
			}
			else if (Ci == 1)
			{
				// Exact pineapple frag grenade SVG (index.html line 193: viewBox="0 0 20 22" M8 2h5v3H8zM10 5c4 0 6 3 6 7s-2 8-6 8-6-4-6-8 2-7 6-7Zm-3 4h6m-6 4h6m-3-6v11)
				const float GX = CX0 + 18.f * S;
				const float GY = ExtraY + (ExtraH - 18.f * S) * 0.5f;
				const float U = 0.80f * S;
				const FLinearColor FragStroke = bAimingFrag ? FSquadAIHUDPalette::GoldText() : SvgStroke;
				// Fuze cap (M8 2h5v3H8z)
				DrawLine(GX + 7.5f*U, GY + 2*U, GX + 12.5f*U, GY + 2*U, FragStroke, 1.35f * S);
				DrawLine(GX + 12.5f*U, GY + 2*U, GX + 12.5f*U, GY + 5*U, FragStroke, 1.35f * S);
				DrawLine(GX + 7.5f*U, GY + 2*U, GX + 7.5f*U, GY + 5*U, FragStroke, 1.35f * S);
				// Oval body (cx=10*U, cy=12.5*U, rx=5.6*U, ry=7.2*U)
				constexpr int32 NSeg = 14;
				for (int32 s = 0; s < NSeg; ++s)
				{
					const float A0 = (2.f * PI * s) / NSeg;
					const float A1 = (2.f * PI * (s + 1)) / NSeg;
					DrawLine(GX + (10.f + 5.6f * FMath::Cos(A0)) * U, GY + (12.5f + 7.2f * FMath::Sin(A0)) * U,
						GX + (10.f + 5.6f * FMath::Cos(A1)) * U, GY + (12.5f + 7.2f * FMath::Sin(A1)) * U, FragStroke, 1.35f * S);
				}
				// Waffle ribs (m-3 4h6m-6 4h6m-3-6v11)
				DrawLine(GX + 5.2f*U, GY + 9.5f*U, GX + 14.8f*U, GY + 9.5f*U, FragStroke, 1.2f * S);
				DrawLine(GX + 5.2f*U, GY + 14.5f*U, GX + 14.8f*U, GY + 14.5f*U, FragStroke, 1.2f * S);
				DrawLine(GX + 10.f*U, GY + 6.5f*U, GX + 10.f*U, GY + 18.5f*U, FragStroke, 1.2f * S);

				const FString FragCnt = bEnglishHUD
					? FString::Printf(TEXT("x%d"), FragN)
					: FString::Printf(TEXT("×%s"), *UFarsiTextHelper::ToPersianDigits(FString::FromInt(FragN)));
				DrawFarsiText3D(FragCnt, bAimingFrag ? FSquadAIHUDPalette::GoldText() : FSquadAIHUDPalette::TextWhite(),
					GX + 19.f * S, ExtraY, 26.f * S, Font, 0.68f * S, false, false, ExtraH, 1.0f * S);
				DrawFarsiTextBounded(bEnglishHUD ? TEXT("FRAG") : TEXT("نارنجک"), FSquadAIHUDPalette::TextDim(),
					GX + 45.f * S, ExtraY, CellW - 64.f * S, Font, 0.54f * S, true, false, ExtraH, false);
			}
			else
			{
				// Exact cylindrical smoke grenade SVG (index.html line 193: viewBox="0 0 20 22" M7 2h6v3H7zM6 5h8v14H6zM6 9h8M6 14h8)
				const float SX0 = CX0 + 18.f * S;
				const float SY0 = ExtraY + (ExtraH - 18.f * S) * 0.5f;
				const float U = 0.80f * S;
				const FLinearColor SmokeStroke = bAimingSmoke ? FSquadAIHUDPalette::GoldText() : SvgStroke;
				// Top fuze cap (M7 2h6v3H7z)
				DrawLine(SX0 + 7*U, SY0 + 2*U, SX0 + 13*U, SY0 + 2*U, SmokeStroke, 1.35f * S);
				DrawLine(SX0 + 13*U, SY0 + 2*U, SX0 + 13*U, SY0 + 5*U, SmokeStroke, 1.35f * S);
				DrawLine(SX0 + 7*U, SY0 + 2*U, SX0 + 7*U, SY0 + 5*U, SmokeStroke, 1.35f * S);
				// Cylindrical body (M6 5h8v14H6z)
				DrawLine(SX0 + 6*U, SY0 + 5*U, SX0 + 14*U, SY0 + 5*U, SmokeStroke, 1.35f * S);
				DrawLine(SX0 + 14*U, SY0 + 5*U, SX0 + 14*U, SY0 + 19*U, SmokeStroke, 1.35f * S);
				DrawLine(SX0 + 14*U, SY0 + 19*U, SX0 + 6*U, SY0 + 19*U, SmokeStroke, 1.35f * S);
				DrawLine(SX0 + 6*U, SY0 + 19*U, SX0 + 6*U, SY0 + 5*U, SmokeStroke, 1.35f * S);
				// Horizontal canister bands (M6 9h8M6 14h8)
				DrawLine(SX0 + 6*U, SY0 + 9.5f*U, SX0 + 14*U, SY0 + 9.5f*U, SmokeStroke, 1.2f * S);
				DrawLine(SX0 + 6*U, SY0 + 14.5f*U, SX0 + 14*U, SY0 + 14.5f*U, SmokeStroke, 1.2f * S);

				const FString SmokeCnt = bEnglishHUD
					? FString::Printf(TEXT("x%d"), SmokeN)
					: FString::Printf(TEXT("×%s"), *UFarsiTextHelper::ToPersianDigits(FString::FromInt(SmokeN)));
				DrawFarsiText3D(SmokeCnt, bAimingSmoke ? FSquadAIHUDPalette::GoldText() : FSquadAIHUDPalette::TextWhite(),
					SX0 + 19.f * S, ExtraY, 26.f * S, Font, 0.68f * S, false, false, ExtraH, 1.0f * S);
				DrawFarsiTextBounded(bEnglishHUD ? TEXT("SMOKE") : TEXT("دودزا"), FSquadAIHUDPalette::TextDim(),
					SX0 + 45.f * S, ExtraY, CellW - 64.f * S, Font, 0.54f * S, true, false, ExtraH, false);
			}
		}
	}

	// 3. Five Raised 3D Quick-Slot Tiles (.weapon-foot: 44x42px each, gap 5px, border-radius: 6px)
	//    Connected to live player movement speed tier (SPD 1..3), stance (crouch), grenade/medkit state, and active weapon slot!
	{
		const float SlotW = 44.f * S;
		const float SlotGap = 5.f * S;
		const float TotalFootW = 5 * SlotW + 4 * SlotGap;
		const float FootStartX = RightEdge - TotalFootW;

		const float Speed2D = PlayerPawn ? PlayerPawn->GetVelocity().Size2D() : 0.f;
		bool bIsCrouched = false;
		bool bSprintHeld = false;
		if (const ACharacter* Char = Cast<ACharacter>(PlayerPawn))
		{
			bIsCrouched = Char->bIsCrouched;
		}
		if (const APlayerController* PC = GetOwningPlayerController())
		{
			bIsCrouched = bIsCrouched || PC->IsInputKeyDown(EKeys::C);
			bSprintHeld = PC->IsInputKeyDown(EKeys::LeftShift) || PC->IsInputKeyDown(EKeys::RightShift);
		}
		// Speed tier: 1 when crouched, 2 when walking, 3 when running/default combat pace
		const int32 SpdTier = bIsCrouched ? 1 : ((Speed2D > 10.f && Speed2D < 260.f && !bSprintHeld) ? 2 : 3);
		const FString SpdFa = UFarsiTextHelper::ToPersianDigits(FString::FromInt(SpdTier));
		const FString SpdEn = FString::FromInt(SpdTier);

		struct FQuickSlotInfo
		{
			const TCHAR* TexKey;
			FString LabelFa;
			FString LabelEn;
			bool bActive;
		};
		const FQuickSlotInfo Slots[5] = {
			{ TEXT("IconRunner3D"),  SpdFa,      SpdEn,     bSprintHeld && Speed2D > 100.f },
			{ TEXT("IconStance3D"),  TEXT("۲"), TEXT("2"), bIsCrouched },
			{ TEXT("IconRunner3D"),  TEXT("۳"), TEXT("3"), bAimingFrag || bAimingSmoke },
			{ TEXT("IconRifle3D"),   TEXT("۴"), TEXT("4"), !bSidearmSelected },
			{ TEXT("IconSidearm3D"), TEXT("۵"), TEXT("5"), bSidearmSelected }
		};

		for (int32 Si = 0; Si < 5; ++Si)
		{
			const float SX = FootStartX + Si * (SlotW + SlotGap);
			const bool bAct = Slots[Si].bActive;
			Draw9SliceRoundedBox(SX, FootY, SlotW, FootH,
				bAct ? FName(TEXT("StepTileCurrent")) : FName(TEXT("VitalsTile")),
				0.96f, S, 0.75f, true, 0.85f);
			DrawRect(bAct ? FSquadAIHUDPalette::GoldText() : FSquadAIHUDPalette::SRGB(255, 255, 255, 0.22f),
				SX + 8.f * S, FootY + FootH - 3.f * S, SlotW - 16.f * S, 1.0f);

			if (UTexture2D* STex = GetUITexture(FName(Slots[Si].TexKey)))
			{
				const float IW = (Si == 3) ? 31.f * S : ((Si == 1) ? 16.f * S : 22.f * S);
				const float IH = (Si == 3) ? 20.f * S : 22.f * S;
				DrawTexture(STex, SX + (SlotW - IW) * 0.5f, FootY + 5.f * S, IW, IH, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
			}
			const FString SLbl = bEnglishHUD ? Slots[Si].LabelEn : Slots[Si].LabelFa;
			if (Si == 0)
			{
				DrawFarsiTextBounded(SLbl, bAct ? FSquadAIHUDPalette::GoldText() : FSquadAIHUDPalette::TextWhite(),
					SX + 4.f * S, FootY + FootH - 15.f * S, 12.f * S, Font, 0.52f * S, true, false, 12.f * S, false);
				DrawFarsiTextBounded(TEXT("SPD"), FSquadAIHUDPalette::TextDim(),
					SX + 14.f * S, FootY + FootH - 14.f * S, 24.f * S, Font, 0.44f * S, true, false, 11.f * S, false);
			}
			else
			{
				DrawFarsiTextBounded(SLbl, bAct ? FSquadAIHUDPalette::GoldText() : FSquadAIHUDPalette::TextDim(),
					SX + 4.f * S, FootY + FootH - 16.f * S, SlotW - 9.f * S, Font, 0.52f * S, true, false, 13.f * S, true);
			}
		}
	}
}

void AQuestNativeHUD::DrawAllyDownedAlertBanner(float ScreenW, float ScreenH, float DeltaTime, UFont* Font)
{
	if (AllyDownedAlertTime <= 0.0f) return;
	const float S = GameUIScale; // B6-14: resolution scale (menu-HUD parity).

	AllyDownedAlertTime -= DeltaTime;

	const float BannerW = 480.f * S;
	const float BannerH = 42.f * S;
	const float BannerX = (ScreenW - BannerW) * 0.5f;
	const float BannerY = 95.f * S;

	const float PulseAlpha = 0.75f + 0.25f * FMath::Sin(GetWorld()->GetTimeSeconds() * 8.0f);
	const FLinearColor AlertCol(1.0f, 0.20f, 0.15f, PulseAlpha);

	DrawChiseledTacticalBox(BannerX, BannerY, BannerW, BannerH,
		FLinearColor(0.16f, 0.02f, 0.02f, 0.95f), AlertCol, 1.5f * S, 6.0f * S);
	DrawRect(AlertCol, BannerX + 2.f * S, BannerY + 4.f * S, 4.f * S, BannerH - 8.f * S);
	DrawRect(AlertCol, BannerX + BannerW - 6.f * S, BannerY + 4.f * S, 4.f * S, BannerH - 8.f * S);

	const FString BannerFmt = SquadAIHUDLocal(this, TEXT("HUD"), TEXT("AllyDownedBannerFmt"), TEXT("⚠️ همرزم جوخه (%s) مجروح شد! سریعاً برای امداد اقدام کنید [E]"), TEXT("Squadmate (%s) is wounded! Move in for aid [E]"));
	const FString AlertMsg = SquadAIFormatRuntime(*BannerFmt, *LastDownedAllyName.ToString());
	DrawFarsiTextBounded(AlertMsg, FLinearColor::White, BannerX + 14.f * S, BannerY, BannerW - 28.f * S, Font, 0.95f * S, true, true, BannerH);
}

void AQuestNativeHUD::DrawRadioChatterSubtitle(float ScreenW, float ScreenH, float DeltaTime, UFont* Font)
{
	if (!Canvas || !GetWorld()) return;
	const float S = GameUIScale; // B6-14: resolution scale (menu-HUD parity).


	USquadAIRadioChatterSubsystem* RadioSys = USquadAIRadioChatterSubsystem::Get(this);
	if (!RadioSys) return;

	// B6-9: subtitles setting gates the chatter box (cached read — no disk I/O per frame).
	if (USquadAISaveLoadSubsystem* SaveSys = USquadAISaveLoadSubsystem::Get(this))
	{
		if (!SaveSys->GetCachedSettings().bEnableSubtitles) return;
	}

	RadioSys->TickRadio(DeltaTime);

	const float TimeRemaining = RadioSys->GetLastRadioTimeRemaining();
	if (TimeRemaining <= 0.0f) return;

	const float Alpha = FMath::Clamp(TimeRemaining / 0.5f, 0.0f, 1.0f);
	// S24-UISWEEP: the box was a fixed 460 px and the message was ONE line that
	// shrank to fit - a long story beat (70-90 characters) rendered at half
	// size or worse, exactly the shrink-this-codebase-banned defect. The box
	// widens with the screen, the message WRAPS (2 lines max), and the box
	// grows one line taller when it needs to - the tutorial stack's radio
	// reservation grew to match, so nothing above the slot moves.
	const float BoxW = FMath::Min(620.f * S, ScreenW - 80.f * S);
	const FString Msg = RadioSys->GetLastRadioMessageForLanguage(SquadAIHUDIsEnglish(this));
	const FTutorialTextBlock MsgBlock = WrapTutorialText(Msg, Font, 0.90f * S, BoxW - 24.f * S, 2);
	const float ExtraH = FMath::Max(0.f, MsgBlock.Lines.Num() - 1) * MsgBlock.LineH;
	const float BoxH = 48.f * S + ExtraH;
	const float BoxX = (ScreenW - BoxW) * 0.5f;
	const float BoxY = ScreenH - 120.f * S - ExtraH;

	// Background box & green tactical radio frame
	DrawRect(FLinearColor(0.02f, 0.04f, 0.03f, 0.88f * Alpha), BoxX, BoxY, BoxW, BoxH);
	DrawRect(FLinearColor(0.2f, 0.85f, 0.4f, 0.95f * Alpha), BoxX, BoxY, 4.f * S, BoxH);
	DrawRect(FLinearColor(0.2f, 0.85f, 0.4f, 0.5f * Alpha), BoxX, BoxY, BoxW, 1.5f * S);

	// Radio Header
	DrawFarsiTextBounded(SquadAIHUDLocal(this, TEXT("HUD"), TEXT("RadioHeader"), TEXT("بیسیم تاکتیکی // ستاد جنگ‌های نامنظم"), TEXT("Tactical radio // Irregular Warfare HQ")), FLinearColor(0.2f, 0.85f, 0.4f, Alpha), BoxX + 12.f * S, BoxY + 6.f * S, BoxW - 24.f * S, Font, 0.70f * S, false);

	// Dialogue Message (wrapped - never shrunk)
	DrawTutorialTextBlock(MsgBlock, FLinearColor(1.0f, 1.0f, 1.0f, Alpha),
		BoxX + 12.f * S, BoxY + 22.f * S, BoxW - 24.f * S, Font, 0.90f * S);
}

void AQuestNativeHUD::DrawTopRightSquadAndClockCluster(float RightEdgeX, float TopY, float S, UFont* Font, APawn* PlayerPawn,
	float& OutMinimapCX, float& OutMinimapCY, float& OutMinimapR)
{
	if (!Canvas || !GetWorld()) return;
	const bool bEnglishHUD = SquadAIHUDIsEnglish(this);

	// 1. Rightmost .elapsed box (69x92 * S, border-radius: 6px + inset: 3px keyline): elapsed clock + 3D settings gear
	const float ElapsedW = 69.f * S;
	const float ElapsedH = 92.f * S;
	const float ElapsedX = RightEdgeX - ElapsedW;
	const float ElapsedY = TopY;

	Draw9SliceRoundedBox(ElapsedX, ElapsedY, ElapsedW, ElapsedH, FName(TEXT("VitalsTile")), 0.92f, S, 0.75f, true, 0.85f);
	int32 TotalSec = FMath::Max(0, FMath::FloorToInt(GetWorld()->GetTimeSeconds()));
	if (AQuestChain* ActiveChain = FindQuestChain())
	{
		if (AMissionZone* ActiveMZ = ActiveChain->GetCurrentMission())
		{
			if (ActiveMZ->IsActive() && ActiveMZ->RemainingTime > 0.f)
			{
				TotalSec = FMath::Max(0, FMath::CeilToInt(ActiveMZ->RemainingTime));
			}
		}
	}
	const FString ClockAscii = FString::Printf(TEXT("%02d:%02d"), (TotalSec / 60) % 60, TotalSec % 60);
	const FString ClockStr = bEnglishHUD ? ClockAscii : UFarsiTextHelper::ToPersianDigits(ClockAscii);
	DrawFarsiText3D(ClockStr, FSquadAIHUDPalette::TextWhite(),
		ElapsedX + 4.f * S, ElapsedY + 8.f * S, ElapsedW - 8.f * S, Font, 0.88f * S, true, false, 22.f * S, 1.2f * S);
	DrawFarsiTextBounded(bEnglishHUD ? TEXT("ELAPSED") : TEXT("زمان سپری‌شده"),
		FSquadAIHUDPalette::TextDim(),
		ElapsedX + 3.f * S, ElapsedY + 31.f * S, ElapsedW - 6.f * S, Font, 0.54f * S, true, true, 15.f * S);

	// Horizontal divider + 3D settings gear icon (.gear)
	const float GearRowY = ElapsedY + 52.f * S;
	DrawRect(FSquadAIHUDPalette::Hairline(), ElapsedX + 6.f * S, GearRowY, ElapsedW - 12.f * S, 1.f * S);
	if (UTexture2D* GearTex = GetUITexture(FName(TEXT("IconSettings3D"))))
	{
		const float GS = 23.f * S;
		DrawTexture(GearTex, ElapsedX + (ElapsedW - GS) * 0.5f, GearRowY + (ElapsedH - 52.f * S - GS) * 0.5f,
			GS, GS, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
	}
	else
	{
		DrawCircleLines(FSquadAIHUDPalette::GoldText(), ElapsedX + ElapsedW * 0.5f, GearRowY + 19.f * S, 8.f * S, 1.8f * S);
	}

	// 2. Middle .squad group: 3 photoreal 3D portrait cards (62x99 * S each, gap 4 * S, border-radius: 6px)
	const float CardW = 62.f * S;
	const float CardH = 99.f * S;
	const float CardGap = 4.f * S;
	const float SquadTotalW = 3.f * CardW + 2.f * CardGap;
	const float SquadStartX = ElapsedX - 7.f * S - SquadTotalW;
	const float SquadY = TopY;

	RegisterTutorialUIRect(TEXT("Squad"), SquadStartX, SquadY, SquadTotalW, CardH);

	float HPs[3] = { 1.00f, 0.92f, 0.96f };
	bool bDowned[3] = { false, false, false };
	if (AActor* LeaderActor = FindCachedLeader())
	{
		HPs[0] = FMath::Clamp(GetActorHealthPercent(LeaderActor), 0.05f, 1.0f);
		if (ASoldierCharacter* LS = Cast<ASoldierCharacter>(LeaderActor))
		{
			bDowned[0] = LS->IsDowned();
		}
	}
	int32 SlotIdx = 1;
	if (USoldierRegistrySubsystem* Reg = GetWorld()->GetSubsystem<USoldierRegistrySubsystem>())
	{
		for (const TWeakObjectPtr<ASoldierCharacter>& WeakS : Reg->GetAllSoldiers())
		{
			ASoldierCharacter* Ally = WeakS.Get();
			if (!Ally || !Ally->IsAlly() || Ally->IsSquadLeader() || Ally == PlayerPawn) continue;
			if (SlotIdx <= 2)
			{
				HPs[SlotIdx] = FMath::Clamp(GetActorHealthPercent(Ally), 0.05f, 1.0f);
				bDowned[SlotIdx] = Ally->IsDowned();
				++SlotIdx;
			}
		}
	}
	// Fallback to friendly actors in CachedSoldierDots if fewer than 2 non-leader ASoldierCharacters registered
	if (SlotIdx <= 2)
	{
		for (const FMinimapSoldierDot& Dot : CachedSoldierDots)
		{
			if (!Dot.bIsAlly || Dot.bIsLeader || SlotIdx > 2) continue;
			if (AActor* AllyAct = Dot.Actor.Get())
			{
				if (AllyAct == PlayerPawn) continue;
				HPs[SlotIdx] = FMath::Clamp(GetActorHealthPercent(AllyAct), 0.05f, 1.0f);
				bDowned[SlotIdx] = Dot.bIsDowned;
				++SlotIdx;
			}
		}
	}

	struct FSquadCardSpec
	{
		const TCHAR* TexKey;
		const TCHAR* NameFa;
		const TCHAR* NameEn;
		const TCHAR* RoleFa;
		const TCHAR* RoleEn;
		bool bActive;
	};
	static const FSquadCardSpec Specs[3] = {
		{ TEXT("SquadAlpha1"), TEXT("سرگرد رستمی"), TEXT("MAJ. ROSTAMI"), TEXT("فرمانده جوخه"), TEXT("SQUAD LEADER"), true  },
		{ TEXT("SquadAlpha2"), TEXT("رزمنده مهدی"), TEXT("MEHDI"),        TEXT("آرپی‌جی‌زن"),   TEXT("RPG-7 GUNNER"), false },
		{ TEXT("SquadAlpha3"), TEXT("رزمنده علی"),  TEXT("ALI"),          TEXT("تیرانداز ژ-۳"), TEXT("G3 MARKSMAN"),  false }
	};

	for (int32 i = 0; i < 3; ++i)
	{
		const float CX0 = SquadStartX + i * (CardW + CardGap);
		const bool bAct = Specs[i].bActive;

		// 9-slice rounded-bevel card housing (.soldier / .soldier.active: border-radius: 6px)
		Draw9SliceRoundedBox(CX0, SquadY, CardW, CardH,
			bAct ? FName(TEXT("StepTileCurrent")) : FName(TEXT("StepTile")),
			0.94f, S, 0.75f, true, 0.85f);

		// Portrait image (top 58% of card, inset 2px so rounded corners stay crisp)
		const float PortH = CardH * 0.58f;
		if (UTexture2D* PortTex = GetUITexture(FName(Specs[i].TexKey)))
		{
			DrawTexture(PortTex, CX0 + 2.f * S, SquadY + 2.f * S, CardW - 4.f * S, PortH - 2.f * S, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
		}
		DrawRect(FLinearColor(0.f, 0.f, 0.f, 0.28f), CX0 + 2.f * S, SquadY + PortH - 8.f * S, CardW - 4.f * S, 8.f * S);

		const FLinearColor DotCol = bDowned[i]
			? FSquadAIHUDPalette::Danger()
			: ((HPs[i] < 0.45f) ? FSquadAIHUDPalette::Warm() : FSquadAIHUDPalette::Success());

		// .soldier.active:after — top-right glowing green status dot (top: 5px; right: 5px; width: 6px; height: 6px; box-shadow: 0 0 7px var(--green))
		if (bAct)
		{
			DrawRect(FSquadAIHUDPalette::WithAlpha(DotCol, 0.35f), CX0 + CardW - 12.f * S, SquadY + 4.f * S, 8.f * S, 8.f * S);
			DrawRect(DotCol, CX0 + CardW - 10.5f * S, SquadY + 5.5f * S, 5.f * S, 5.f * S);
		}

		// Bottom label housing (.label: height 42%)
		const float LblY = SquadY + PortH;
		const float LblH = CardH - PortH;
		const FLinearColor LblBg = bAct
			? FSquadAIHUDPalette::SRGB(44, 34, 22, 0.88f)
			: FSquadAIHUDPalette::SRGB(21, 24, 23, 0.86f);
		DrawRect(LblBg, CX0 + 2.f * S, LblY, CardW - 4.f * S, LblH - 3.f * S);
		DrawRect(FSquadAIHUDPalette::Hairline(), CX0 + 2.f * S, LblY, CardW - 4.f * S, 1.f * S);

		// In RTL, green .memberdot is on the RIGHT of the name; in LTR, on the LEFT
		if (bEnglishHUD)
		{
			DrawRect(FSquadAIHUDPalette::WithAlpha(DotCol, 0.35f), CX0 + 4.f * S, LblY + 6.f * S, 6.f * S, 6.f * S);
			DrawRect(DotCol, CX0 + 5.f * S, LblY + 7.f * S, 4.f * S, 4.f * S);
			DrawFarsiTextBounded(Specs[i].NameEn, FSquadAIHUDPalette::TextWhite(),
				CX0 + 11.f * S, LblY + 2.f * S, CardW - 14.f * S, Font, 0.58f * S, true, false, 15.f * S, false);
		}
		else
		{
			DrawRect(FSquadAIHUDPalette::WithAlpha(DotCol, 0.35f), CX0 + CardW - 9.f * S, LblY + 6.f * S, 6.f * S, 6.f * S);
			DrawRect(DotCol, CX0 + CardW - 8.f * S, LblY + 7.f * S, 4.f * S, 4.f * S);
			DrawFarsiTextBounded(Specs[i].NameFa, FSquadAIHUDPalette::TextWhite(),
				CX0 + 3.f * S, LblY + 2.f * S, CardW - 13.f * S, Font, 0.58f * S, true, false, 15.f * S, true);
		}
		DrawFarsiTextBounded(bEnglishHUD ? Specs[i].RoleEn : Specs[i].RoleFa,
			FSquadAIHUDPalette::TextDim(),
			CX0 + 3.f * S, LblY + 17.f * S, CardW - 6.f * S, Font, 0.48f * S, true, true, 12.f * S);

		// Bottom 2px green health bar (.teamhealth)
		const float BarW = CardW - 10.f * S;
		const float BarX = CX0 + 5.f * S;
		const float BarY = SquadY + CardH - 6.f * S;
		DrawRect(FSquadAIHUDPalette::SRGB(255, 255, 255, 0.16f), BarX, BarY, BarW, 2.2f * S);
		DrawRect(DotCol, BarX, BarY, BarW * HPs[i], 2.2f * S);
	}

	// 3. Left of .squad: Circular Tactical Minimap (.mapbox: 132x132 * S + .map-caption below)
	OutMinimapR = 66.f * S;
	const float MapBoxW = OutMinimapR * 2.f;
	const float MapBoxX = SquadStartX - 8.f * S - MapBoxW;
	OutMinimapCX = MapBoxX + OutMinimapR;
	OutMinimapCY = TopY + OutMinimapR;

	// .map-caption below the radar circle: <kbd>نگه‌دار [M]</kbd> نقشه تاکتیکی (9-slice rounded 3D keycap pill + floating text)
	const float CapY = TopY + MapBoxW + 5.f * S;
	const float CapH = 18.f * S;
	const float KbdW = 58.f * S;
	const bool bMKeyHeld = GetOwningPlayerController() && GetOwningPlayerController()->IsInputKeyDown(EKeys::M);
	if (bEnglishHUD)
	{
		DrawKeycapGlyph(MapBoxX + 4.f * S, CapY, CapH, TEXT("HOLD [M]"), Font, FSquadAIHUDPalette::GoldText(), bMKeyHeld);
		DrawFarsiTextBounded(TEXT("TAC-MAP"), FSquadAIHUDPalette::TextDim(),
			MapBoxX + KbdW + 8.f * S, CapY, MapBoxW - KbdW - 8.f * S, Font, 0.54f * S, true, false, CapH, false);
	}
	else
	{
		const float KbdX = MapBoxX + MapBoxW - KbdW - 2.f * S;
		Draw9SliceRoundedBox(KbdX, CapY, KbdW, CapH, bMKeyHeld ? FName(TEXT("SlotActive")) : FName(TEXT("VitalsTile")), 0.94f, S, 0.50f, false, 0.f);
		DrawFarsiTextBounded(TEXT("نگه‌دار [M]"), bMKeyHeld ? FSquadAIHUDPalette::DarkInk() : FSquadAIHUDPalette::GoldText(),
			KbdX + 3.f * S, CapY, KbdW - 6.f * S, Font, 0.50f * S, false, true, CapH);
		DrawFarsiTextBounded(TEXT("نقشه تاکتیکی"), FSquadAIHUDPalette::TextDim(),
			MapBoxX, CapY, KbdX - MapBoxX - 5.f * S, Font, 0.54f * S, true, false, CapH, true);
	}
}

void AQuestNativeHUD::DrawSquadStatusPanel(float StartX, float StartY, UFont* Font, APawn* PlayerPawn)
{
	if (!bEnableSquadStatusPanel || !Canvas || !GetWorld()) return;

	const float S = GameUIScale;
	const float SW = Canvas->ClipX;
	const float SH = Canvas->ClipY;
	const bool bEnglishHUD = SquadAIHUDIsEnglish(this);

	const float LeftX = FMath::Max(24.f * S, SW * 0.0235f);
	const float BottomEdge = SH * 0.97f;

	const float StaminaPercent = FMath::Clamp(GetPlayerStaminaPercent(PlayerPawn, GetWorld()->GetDeltaSeconds()), 0.05f, 1.0f);
	const float HPPercent = FMath::Clamp(GetPlayerHealthPercent(PlayerPawn), 0.f, 1.f);
	const int32 HPInt = FMath::Clamp(FMath::RoundToInt(HPPercent * 100.f), 0, 100);
	const float ArmorPercent = FMath::Clamp(GetPlayerArmorPercent(PlayerPawn), 0.f, 1.f);
	const int32 ArmorInt = FMath::Clamp(FMath::RoundToInt(ArmorPercent * 100.f), 0, 100);

	// 1. Stamina bar (.stamina) at bottom-left: recessed track (#22201c, inset 0 1px 2px #000) + warm gold gradient fill driven by live StaminaPercent
	const float StamH = 14.f * S;
	const float StamY = BottomEdge - StamH;
	DrawFarsiTextBounded(bEnglishHUD ? TEXT("STAMINA") : TEXT("استقامت"),
		FSquadAIHUDPalette::TextDim(),
		LeftX, StamY - 1.f * S, 48.f * S, Font, 0.56f * S, true, false, StamH);
	const float SBarX = LeftX + 52.f * S;
	const float SBarY = StamY + 4.f * S;
	const float SBarW = 82.f * S;
	const float SBarH = 5.0f * S;
	DrawRect(FSquadAIHUDPalette::SRGB(20, 18, 15, 0.94f), SBarX, SBarY, SBarW, SBarH);
	DrawRect(FSquadAIHUDPalette::SRGB(0, 0, 0, 0.65f), SBarX, SBarY, SBarW, 1.0f);
	DrawRect(FSquadAIHUDPalette::SRGB(255, 255, 255, 0.14f), SBarX, SBarY + SBarH - 1.f, SBarW, 1.0f);
	const float StamFillW = SBarW * StaminaPercent;
	DrawRect(FSquadAIHUDPalette::SRGB(170, 132, 80, 0.96f), SBarX, SBarY + 1.f, StamFillW * 0.45f, SBarH - 1.f);
	DrawRect(FSquadAIHUDPalette::SRGB(235, 208, 155, 0.96f), SBarX + StamFillW * 0.45f, SBarY + 1.f, StamFillW * 0.55f, SBarH - 1.f);
	DrawRect(FSquadAIHUDPalette::SRGB(255, 245, 215, 0.40f), SBarX, SBarY + 1.f, StamFillW, 1.0f);

	// 2. Twin 9-slice rounded-bevel vitals housings (.stats -> .stat.health & .stat.armor: border-radius: 6px + inset: 2px keyline)
	const float StatsW = FMath::Min(318.f * S, SW * 0.245f);
	const float StatCardH = 54.f * S;
	const float StatGap = 6.f * S;
	const float SingleStatW = (StatsW - StatGap) * 0.5f;
	const float StatsY = StamY - 5.f * S - StatCardH;

	// 2a. Left housing: .stat.health (live HPInt & HPPercent meter)
	{
		const float HX = LeftX;
		Draw9SliceRoundedBox(HX, StatsY, SingleStatW, StatCardH, FName(TEXT("VitalsTile")), 0.96f, S, 0.75f, true, 0.88f);

		if (UTexture2D* HCrest = GetUITexture(FName(TEXT("HealthCrest3D"))))
		{
			DrawTexture(HCrest, HX + 6.f * S, StatsY + (StatCardH - 36.f * S) * 0.5f, 32.f * S, 36.f * S, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
		}
		const float InfoX = HX + 42.f * S;
		const float InfoW = SingleStatW - 48.f * S;
		const FString HPStr = bEnglishHUD
			? FString::FromInt(HPInt)
			: UFarsiTextHelper::ToPersianDigits(FString::FromInt(HPInt));
		const FLinearColor HPNumCol = (HPPercent < 0.30f)
			? FSquadAIHUDPalette::Danger()
			: ((HPPercent < 0.60f) ? FSquadAIHUDPalette::Warm() : FSquadAIHUDPalette::SuccessText());
		DrawFarsiText3D(HPStr, HPNumCol,
			InfoX, StatsY + 3.f * S, InfoW, Font, 1.12f * S, false, false, 20.f * S, 1.2f * S);
		DrawFarsiTextBounded(bEnglishHUD ? TEXT("HEALTH") : TEXT("سلامت"),
			FSquadAIHUDPalette::TextDim(),
			InfoX, StatsY + 23.f * S, InfoW, Font, 0.56f * S, true, false, 12.f * S, false);
		DrawRecessedSegmentedMeter(InfoX, StatsY + 38.f * S, InfoW, 9.f * S, HPPercent, false, 1.0f, S);
	}

	// 2b. Right housing: .stat.armor (live ArmorInt & ArmorPercent meter)
	{
		const float AX = LeftX + SingleStatW + StatGap;
		Draw9SliceRoundedBox(AX, StatsY, SingleStatW, StatCardH, FName(TEXT("VitalsTile")), 0.96f, S, 0.75f, true, 0.88f);

		UTexture2D* AShield = GetUITexture(FName(TEXT("ArmorEmblem")));
		if (!AShield) AShield = GetUITexture(FName(TEXT("ArmorShield3D")));
		if (AShield)
		{
			DrawTexture(AShield, AX + 5.f * S, StatsY + (StatCardH - 36.f * S) * 0.5f, 32.f * S, 36.f * S, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
		}
		const float InfoX = AX + 40.f * S;
		const float InfoW = SingleStatW - 46.f * S;
		const FString ArmStr = bEnglishHUD
			? FString::FromInt(ArmorInt)
			: UFarsiTextHelper::ToPersianDigits(FString::FromInt(ArmorInt));
		DrawFarsiText3D(ArmStr, FSquadAIHUDPalette::ArmorText(),
			InfoX, StatsY + 3.f * S, InfoW, Font, 1.12f * S, false, false, 20.f * S, 1.2f * S);
		DrawFarsiTextBounded(bEnglishHUD ? TEXT("ARMOR") : TEXT("زره"),
			FSquadAIHUDPalette::TextDim(),
			InfoX, StatsY + 23.f * S, InfoW, Font, 0.56f * S, true, false, 12.f * S, false);
		DrawRecessedSegmentedMeter(InfoX, StatsY + 38.f * S, InfoW, 9.f * S, ArmorPercent, true, 1.0f, S);
	}

	// 3. Controls strip (.controls: border-radius: 6px + border-right: 2px solid #e9953b88): [C] خم‌شدن • [SHIFT] دویدن • [SPACE] پرش از مانع
	//    Connected to live player crouch, sprint, and jump/vault state!
	const float CtrlH = 31.f * S;
	const float CtrlY = StatsY - 6.f * S - CtrlH;
	Draw9SliceRoundedBox(LeftX, CtrlY, StatsW, CtrlH, FName(TEXT("VitalsTile")), 0.92f, S, 0.75f, true, 0.85f);
	// Right-edge 2px amber accent bar (.controls border-right: 2px solid #e9953b88, inset from rounded corners)
	DrawRect(FSquadAIHUDPalette::SRGB(233, 149, 59, 0.68f), LeftX + StatsW - 3.f * S, CtrlY + 5.f * S, 2.0f * S, CtrlH - 10.f * S);
	{
		bool bCrouchActive = false;
		bool bSprintActive = false;
		bool bJumpActive = false;
		if (const ACharacter* Char = Cast<ACharacter>(PlayerPawn))
		{
			bCrouchActive = Char->bIsCrouched;
			if (const UCharacterMovementComponent* MoveComp = Char->GetCharacterMovement())
			{
				bJumpActive = MoveComp->IsFalling();
			}
		}
		if (const APlayerController* PC = GetOwningPlayerController())
		{
			bCrouchActive = bCrouchActive || PC->IsInputKeyDown(EKeys::C);
			bSprintActive = PC->IsInputKeyDown(EKeys::LeftShift) || PC->IsInputKeyDown(EKeys::RightShift);
			bJumpActive   = bJumpActive || PC->IsInputKeyDown(EKeys::SpaceBar);
		}
		const bool bKeyActive[3] = { bCrouchActive, bSprintActive, bJumpActive };
		const float SegW = (StatsW - 14.f * S) / 3.f;
		const TCHAR* Keys[3] = { TEXT("C"), TEXT("SHIFT"), TEXT("SPACE") };
		const TCHAR* LblFa[3] = { TEXT("خم‌شدن"), TEXT("دویدن"), TEXT("پرش از مانع") };
		const TCHAR* LblEn[3] = { TEXT("CROUCH"), TEXT("SPRINT"), TEXT("VAULT") };
		for (int32 Ci = 0; Ci < 3; ++Ci)
		{
			const float CX0 = LeftX + 7.f * S + Ci * SegW;
			if (Ci > 0)
			{
				DrawFarsiTextBounded(TEXT("•"), FSquadAIHUDPalette::Muted(),
					CX0 - 5.f * S, CtrlY, 8.f * S, Font, 0.56f * S, false, true, CtrlH);
			}
			const float CapH = 18.f * S;
			const float CapY = CtrlY + (CtrlH - CapH) * 0.5f;
			const float CapW = DrawKeycapGlyph(CX0 + 2.f * S, CapY, CapH, Keys[Ci], Font, FSquadAIHUDPalette::GoldText(), bKeyActive[Ci]);
			const FString Lbl = bEnglishHUD ? LblEn[Ci] : LblFa[Ci];
			DrawFarsiTextBounded(Lbl, bKeyActive[Ci] ? FSquadAIHUDPalette::GoldText() : FSquadAIHUDPalette::TextWhite(),
				CX0 + CapW + 5.f * S, CtrlY, SegW - CapW - 8.f * S, Font, 0.56f * S, true, false, CtrlH);
		}
	}

	// 4. Footer action strip (.footer-actions: border-radius: 6px): [TAB] هدف‌ها | [?] راهنما | [ESC] رد کردن آموزش
	// Placed directly BETWEEN .controls ([C] خم‌شدن • [SHIFT] دویدن • [SPACE] پرش از مانع) and .solo-badge (شما آموزش انفرادی)
	bool bTutRunningNow = true;
	if (const USquadAITutorialSubsystem* TutSys = USquadAITutorialSubsystem::Get(this))
	{
		bTutRunningNow = TutSys->IsTutorialActive();
	}
	const float FootActX = LeftX;
	const float FootActH = 28.f * S;
	const float FootActY = CtrlY - 6.f * S - FootActH;
	const float FootActW = StatsW;
	Draw9SliceRoundedBox(FootActX, FootActY, FootActW, FootActH, FName(TEXT("GlassPanel")), 0.90f, S, 0.75f, true, 0.85f);
	{
		const APlayerController* PC = GetOwningPlayerController();
		const bool bFKeyHeld[3] = {
			bInventoryOpen || (PC && PC->IsInputKeyDown(EKeys::Tab)),
			PC && (bTutRunningNow ? (PC->IsInputKeyDown(EKeys::Slash) || PC->IsInputKeyDown(EKeys::F1)) : PC->IsInputKeyDown(EKeys::V)),
			bPauseMenuActive || (PC && PC->IsInputKeyDown(EKeys::Escape))
		};
		const float ItemW = FootActW / 3.f;
		const TCHAR* FKeys[3] = { TEXT("TAB"), bTutRunningNow ? TEXT("?") : TEXT("V"), TEXT("ESC") };
		const TCHAR* FLblFa[3] = {
			bTutRunningNow ? TEXT("هدف‌ها") : TEXT("کوله‌پشتی"),
			bTutRunningNow ? TEXT("راهنما") : TEXT("مسیرنما"),
			bTutRunningNow ? TEXT("رد کردن آموزش") : TEXT("توقف عملیات")
		};
		const TCHAR* FLblEn[3] = {
			bTutRunningNow ? TEXT("OBJECTIVES") : TEXT("BACKPACK"),
			bTutRunningNow ? TEXT("HELP") : TEXT("PATH"),
			bTutRunningNow ? TEXT("SKIP TUTORIAL") : TEXT("PAUSE")
		};
		for (int32 Fi = 0; Fi < 3; ++Fi)
		{
			const float FX = FootActX + Fi * ItemW;
			if (Fi > 0)
			{
				DrawRect(FSquadAIHUDPalette::Hairline(), FX, FootActY + 5.f * S, 1.f * S, FootActH - 10.f * S);
			}
			const float CapH = 16.f * S;
			const float CapW = DrawKeycapGlyph(FX + 6.f * S, FootActY + (FootActH - CapH) * 0.5f, CapH, FKeys[Fi], Font, FSquadAIHUDPalette::GoldText(), bFKeyHeld[Fi]);
			DrawFarsiTextBounded(bEnglishHUD ? FLblEn[Fi] : FLblFa[Fi],
				bFKeyHeld[Fi] ? FSquadAIHUDPalette::TextWhite() : FSquadAIHUDPalette::TextDim(),
				FX + CapW + 9.f * S, FootActY, ItemW - CapW - 12.f * S, Font, 0.52f * S, true, false, FootActH);
		}
	}

	// 5. Solo status badge (.solo-badge: border-radius: 6px + inset: 3px keyline, 20x20 #b8b9ae circular avatar on left with #72756f inner dot + 7x7 #79d273 online dot, 34x3px ready bar on right)
	// Placed directly above .footer-actions and connected to live player readiness & tutorial/combat mode
	const float SoloW = 148.f * S;
	const float SoloH = 34.f * S;
	const float SoloY = FootActY - 6.f * S - SoloH;
	Draw9SliceRoundedBox(LeftX, SoloY, SoloW, SoloH, FName(TEXT("VitalsTile")), 0.90f, S, 0.75f, true, 0.85f);
	const FLinearColor StatusDotCol = (HPPercent < 0.30f)
		? FSquadAIHUDPalette::Danger()
		: ((HPPercent < 0.60f) ? FSquadAIHUDPalette::Warm() : FSquadAIHUDPalette::SRGB(121, 210, 115, 0.98f));
	{
		const float AvCX = LeftX + 17.f * S;
		const float AvCY = SoloY + SoloH * 0.5f;
		DrawFilledCircleArea(FSquadAIHUDPalette::SRGB(184, 185, 174, 0.96f), AvCX, AvCY, 10.0f * S);
		DrawFilledCircleArea(FSquadAIHUDPalette::SRGB(114, 117, 111, 0.96f), AvCX, AvCY, 4.5f * S);
		// Bottom-right online indicator (.avatar:after: 7x7px with 1px solid #1b201d border)
		DrawFilledCircleArea(FSquadAIHUDPalette::SRGB(27, 32, 29, 0.98f), AvCX + 7.5f * S, AvCY + 7.5f * S, 4.2f * S);
		DrawFilledCircleArea(StatusDotCol, AvCX + 7.5f * S, AvCY + 7.5f * S, 3.0f * S);
	}
	DrawFarsiTextBounded(bEnglishHUD ? TEXT("YOU") : TEXT("شما"), FSquadAIHUDPalette::TextWhite(),
		LeftX + 33.f * S, SoloY + 4.f * S, 70.f * S, Font, 0.60f * S, true, false, 14.f * S, false);
	const FString ModeSubStr = bTutRunningNow
		? (bEnglishHUD ? TEXT("SOLO TRAINING") : TEXT("آموزش انفرادی"))
		: (bEnglishHUD ? TEXT("SQUAD COMBAT") : TEXT("نبرد با جوخه"));
	DrawFarsiTextBounded(ModeSubStr, FSquadAIHUDPalette::TextDim(),
		LeftX + 33.f * S, SoloY + 17.f * S, 74.f * S, Font, 0.50f * S, true, false, 13.f * S, false);
	// Right-side 34x3px readiness bar (.ready: driven by live HP & Stamina readiness)
	const float ReadyPct = FMath::Clamp(HPPercent * 0.65f + StaminaPercent * 0.35f, 0.12f, 1.0f);
	const float ReadyW = 34.f * S;
	const float ReadyX = LeftX + SoloW - ReadyW - 7.f * S;
	const float ReadyY = SoloY + (SoloH - 3.f * S) * 0.5f;
	DrawRect(FSquadAIHUDPalette::SRGB(82, 99, 77, 0.92f), ReadyX, ReadyY, ReadyW, 3.f * S);
	DrawRect(StatusDotCol, ReadyX, ReadyY, ReadyW * ReadyPct, 3.f * S);
}

void AQuestNativeHUD::DrawMissionObjectiveCard(float StartX, float StartY, AQuestChain* Chain, UFont* Font)
{
	if (!bEnableMissionObjectiveCard || !Canvas) return;

	const float S = GameUIScale;
	const float SW = Canvas->ClipX;
	const float SH = Canvas->ClipY;
	const bool bEnglishHUD = SquadAIHUDIsEnglish(this);

	AQuestChain* ActiveChain = Chain ? Chain : FindQuestChain();
	AMissionZone* CurrentMission = (ActiveChain && ActiveChain->bIsActive) ? ActiveChain->GetCurrentMission() : nullptr;
	if (!CurrentMission && ActiveChain)
	{
		for (AMissionZone* MZ : ActiveChain->Missions)
		{
			if (MZ && (MZ->IsActive() || !MZ->IsCompleted()))
			{
				CurrentMission = MZ;
				break;
			}
		}
		if (!CurrentMission && ActiveChain->Missions.Num() > 0)
		{
			CurrentMission = ActiveChain->Missions.Last();
		}
	}
	USquadAITutorialSubsystem* Tut = USquadAITutorialSubsystem::Get(this);
	const bool bTutActive = Tut && Tut->IsTutorialActive();

	// S27-REFUI: Matches index.html .mission { right: 2.35%; top: 25.5%; width: min(28.5vw, 380px); border-radius: 8px }
	const float CardW = FMath::Min(380.f * S, SW * 0.285f);
	const float CardX = SW * 0.9765f - CardW;
	const float CardY = SH * 0.255f;
	const float CardH = 190.f * S;

	RegisterTutorialUIRect(TEXT("Objective"), CardX, CardY, CardW, CardH);

	Draw9SliceRoundedBox(CardX, CardY, CardW, CardH, FName(TEXT("GlassPanel")), 0.90f, S, 1.0f, true, 0.85f);
	DrawAsymmetricCornerBrackets(CardX, CardY, CardW, CardH, S, 0.90f);

	// 2. Header row (.head.mission-title): in RTL, 3x17px glowing amber .stripe + 3D clipboard icon + هدف‌ها on RIGHT, ماموریت جاری on LEFT
	const float HeadH = 30.f * S;
	DrawRect(FSquadAIHUDPalette::Hairline(), CardX + 4.f * S, CardY + HeadH, CardW - 8.f * S, 1.f * S);

	const FString HeaderMainLbl = bTutActive
		? (bEnglishHUD ? TEXT("OBJECTIVES") : TEXT("هدف‌ها"))
		: SquadAIHUDLocal(this, TEXT("HUD"), TEXT("MissionObjectiveHeader"), TEXT("هدف ماموریت"), TEXT("MISSION OBJECTIVE"));
	const FString HeaderSubLbl = bTutActive
		? (bEnglishHUD ? TEXT("CURRENT MISSION") : TEXT("ماموریت جاری"))
		: (ActiveChain && ActiveChain->TotalMissionCount > 0
			? (bEnglishHUD
				? FString::Printf(TEXT("STAGE %d OF %d"), FMath::Clamp(ActiveChain->CurrentMissionIndex + 1, 1, ActiveChain->TotalMissionCount), ActiveChain->TotalMissionCount)
				: FString::Printf(TEXT("مرحله %s از %s"),
					*UFarsiTextHelper::ToPersianDigits(FString::FromInt(FMath::Clamp(ActiveChain->CurrentMissionIndex + 1, 1, ActiveChain->TotalMissionCount))),
					*UFarsiTextHelper::ToPersianDigits(FString::FromInt(ActiveChain->TotalMissionCount))))
			: (bEnglishHUD ? TEXT("ACTIVE OPERATION") : TEXT("عملیات جاری")));

	if (bEnglishHUD)
	{
		DrawRect(FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::BracketGold(), 0.28f), CardX + 8.5f * S, CardY + 5.5f * S, 6.f * S, 20.f * S);
		DrawRect(FSquadAIHUDPalette::BracketGold(), CardX + 10.f * S, CardY + 7.f * S, 3.2f * S, 17.f * S);
		if (UTexture2D* ObjIcon = GetUITexture(FName(TEXT("IconObjectives3D"))))
		{
			DrawTexture(ObjIcon, CardX + 17.f * S, CardY + 4.f * S, 20.f * S, 22.f * S, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
		}
		DrawFarsiText3D(HeaderMainLbl, FSquadAIHUDPalette::TextWhite(),
			CardX + 42.f * S, CardY + 2.f * S, CardW * 0.48f, Font, 0.80f * S, false, false, HeadH, 1.4f * S);
		DrawFarsiTextBounded(HeaderSubLbl, FSquadAIHUDPalette::TextDim(),
			CardX + CardW * 0.52f, CardY + 2.f * S, CardW * 0.44f, Font, 0.56f * S, true, false, HeadH, true);
	}
	else
	{
		const float StripeX = CardX + CardW - 13.f * S;
		DrawRect(FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::BracketGold(), 0.28f), StripeX - 1.5f * S, CardY + 5.5f * S, 6.f * S, 20.f * S);
		DrawRect(FSquadAIHUDPalette::BracketGold(), StripeX, CardY + 7.f * S, 3.0f * S, 17.f * S);
		if (UTexture2D* ObjIcon = GetUITexture(FName(TEXT("IconObjectives3D"))))
		{
			DrawTexture(ObjIcon, StripeX - 28.f * S, CardY + 4.f * S, 20.f * S, 22.f * S, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
		}
		DrawFarsiText3D(HeaderMainLbl, FSquadAIHUDPalette::TextWhite(),
			CardX + CardW * 0.44f, CardY + 2.f * S, StripeX - 34.f * S - CardX - CardW * 0.44f, Font, 0.80f * S, false, true, HeadH, 1.4f * S);
		DrawFarsiTextBounded(HeaderSubLbl, FSquadAIHUDPalette::TextDim(),
			CardX + 12.f * S, CardY + 2.f * S, CardW * 0.42f, Font, 0.56f * S, true, false, HeadH, false);
	}

	// Resolve live objective strings, distance & progress from CurrentMission or active Tutorial beat
	FString ObjTitle = bEnglishHUD ? TEXT("DEHLAVIEH TRENCH RANGE") : TEXT("میدان تیر سنگر دهلاویه");
	FString ObjSub   = bEnglishHUD ? TEXT("Complete movement, G3A3 shooting, grenade & mortar training") : TEXT("تکمیل مراحل حرکت، تیراندازی ژ-۳، نارنجک و توپخانه");
	FString TagText  = bEnglishHUD ? TEXT("FRONT LINE") : TEXT("خط مقدم");
	FString DistLbl  = bEnglishHUD ? TEXT("Reach the trench firing position") : TEXT("رسیدن به موضع تمرین در سنگر");
	int32 DistMeters = 45;
	float Progress01 = 0.68f;

	if (!bTutActive)
	{
		// Canonical 5-stage Dehlavieh campaign mission texts from SquadAIAutoSetupEditorLibrary & SquadAILocalizationSubsystem
		static const TCHAR* StageTitleFa[5] = {
			TEXT("پیشروی در محور دهلاویه"),
			TEXT("حمله به خط سنگر و پاکسازی"),
			TEXT("پدافند مقر فرماندهی"),
			TEXT("شناسایی و گشت نخلستان"),
			TEXT("تثبیت معبر رودخانه کرخه")
		};
		static const TCHAR* StageTitleEn[5] = {
			TEXT("ADVANCE ON DEHLAVIEH AXIS"),
			TEXT("TRENCH ASSAULT & CLEAR"),
			TEXT("HQ — HOLD THE LINE"),
			TEXT("GROVE RECON & INTEL"),
			TEXT("KARKHEH RIVER CROSSING")
		};
		static const TCHAR* StageSubFa[5] = {
			TEXT("حرکت با جوخه سرگرد رستمی تا خط اول سنگرهای دهلاویه"),
			TEXT("انهدام سنگرهای تیربار دشمن و پاکسازی مواضع خط مقدم"),
			TEXT("حفظ خط دفاعی دهلاویه و دفع موج‌های پاتک دشمن"),
			TEXT("شناسایی مواضع دیده‌بان و جمع‌آوری اطلاعات عملیاتی"),
			TEXT("پاکسازی کامل محور کرخه و تامین منطقه تخلیه جوخه")
		};
		static const TCHAR* StageSubEn[5] = {
			TEXT("Advance with Major Rostami's squad to forward trenches"),
			TEXT("Destroy enemy machine-gun bunkers and clear forward positions"),
			TEXT("Hold the defensive line and repel enemy counterattack waves"),
			TEXT("Locate artillery spotters and secure operational intel sites"),
			TEXT("Secure the Karkheh river crossing and hold extraction zone")
		};
		static const TCHAR* StageDistFa[5] = {
			TEXT("رسیدن به خط اول سنگرهای دهلاویه"),
			TEXT("پاکسازی نیروهای دشمن در خط سنگر"),
			TEXT("پدافند و پایداری در برابر پاتک دشمن"),
			TEXT("پاکسازی دیده‌بان‌ها و ثبت اطلاعات"),
			TEXT("تامین معبر رودخانه و منطقه تخلیه")
		};
		static const TCHAR* StageDistEn[5] = {
			TEXT("Reach the Dehlavieh forward trench line"),
			TEXT("Eliminate hostiles in trench sector"),
			TEXT("Hold position against enemy counterattack"),
			TEXT("Neutralize spotters & gather intel"),
			TEXT("Secure river crossing & extraction pad")
		};

		const int32 StageIdx = (ActiveChain && ActiveChain->CurrentMissionIndex >= 0)
			? FMath::Clamp(ActiveChain->CurrentMissionIndex, 0, 4)
			: (ActiveChain ? FMath::Clamp(ActiveChain->CompletedMissionCount, 0, 4) : 0);

		ObjTitle = bEnglishHUD ? StageTitleEn[StageIdx] : StageTitleFa[StageIdx];
		ObjSub   = bEnglishHUD ? StageSubEn[StageIdx]   : StageSubFa[StageIdx];
		DistLbl  = bEnglishHUD ? StageDistEn[StageIdx]  : StageDistFa[StageIdx];
		TagText  = SquadAIHUDLocal(this, TEXT("HUD"), TEXT("BadgeAdvance"), TEXT("پیشروی"), TEXT("ADVANCE"));

		if (CurrentMission)
		{
			switch (CurrentMission->MissionType)
			{
			case EMissionType::Reach:
				TagText = SquadAIHUDLocal(this, TEXT("HUD"), TEXT("BadgeAdvance"), TEXT("پیشروی"), TEXT("ADVANCE"));
				break;
			case EMissionType::Clear:
				TagText = SquadAIHUDLocal(this, TEXT("HUD"), TEXT("BadgeClear"), TEXT("پاکسازی"), TEXT("CLEAR"));
				break;
			case EMissionType::Defend:
				TagText = SquadAIHUDLocal(this, TEXT("HUD"), TEXT("BadgeDefend"), TEXT("پدافند"), TEXT("DEFEND"));
				break;
			}
			if (!CurrentMission->MissionBriefingTitle.IsEmpty())
			{
				const FString BriefT = CurrentMission->MissionBriefingTitle.ToString();
				if (bEnglishHUD || UFarsiTextHelper::ContainsFarsiCharacters(BriefT))
				{
					ObjTitle = BriefT;
				}
			}
			else if (!CurrentMission->CustomBadgeText.IsEmpty())
			{
				const FString CustomT = CurrentMission->CustomBadgeText.ToString();
				if (bEnglishHUD || UFarsiTextHelper::ContainsFarsiCharacters(CustomT))
				{
					ObjTitle = CustomT;
				}
			}
			if (!CurrentMission->MissionDescription.IsEmpty())
			{
				const FString DescStr = CurrentMission->MissionDescription.ToString();
				if (bEnglishHUD || UFarsiTextHelper::ContainsFarsiCharacters(DescStr))
				{
					ObjSub = DescStr;
				}
			}
			if (CurrentMission->MissionType == EMissionType::Defend && CurrentMission->DefendTimeRemaining > 0.f)
			{
				const FString TimerStr = bEnglishHUD
					? FString::Printf(TEXT("%02d:%02d"), FMath::CeilToInt(CurrentMission->DefendTimeRemaining) / 60, FMath::CeilToInt(CurrentMission->DefendTimeRemaining) % 60)
					: UFarsiTextHelper::FormatTimerPersian(CurrentMission->DefendTimeRemaining);
				DistLbl = bEnglishHUD
					? FString::Printf(TEXT("Defense timer: %s"), *TimerStr)
					: FString::Printf(TEXT("پدافند و پایداری: %s"), *TimerStr);
			}
			else if (CurrentMission->TotalEnemiesSpawned > 0)
			{
				const int32 Killed = FMath::Max(0, CurrentMission->TotalEnemiesSpawned - CurrentMission->AliveEnemies);
				DistLbl = bEnglishHUD
					? FString::Printf(TEXT("Hostiles cleared: %d / %d"), Killed, CurrentMission->TotalEnemiesSpawned)
					: FString::Printf(TEXT("پاکسازی دشمن: %s از %s"),
						*UFarsiTextHelper::ToPersianDigits(FString::FromInt(Killed)),
						*UFarsiTextHelper::ToPersianDigits(FString::FromInt(CurrentMission->TotalEnemiesSpawned)));
			}
			if (APawn* P = CachedPlayerPawn.Get())
			{
				DistMeters = FMath::Max(1, FMath::RoundToInt(FVector::Dist(P->GetActorLocation(), CurrentMission->GetActorLocation()) / 100.f));
			}
			if (CurrentMission->MissionProgress > 0.01f)
			{
				Progress01 = FMath::Clamp(CurrentMission->MissionProgress, 0.08f, 1.0f);
			}
			else
			{
				Progress01 = FMath::Clamp(1.0f - (static_cast<float>(DistMeters) / 140.0f), 0.15f, 0.95f);
			}
		}
		else if (APawn* P = CachedPlayerPawn.Get())
		{
			if (AActor* Leader = FindCachedLeader())
			{
				DistMeters = FMath::Max(1, FMath::RoundToInt(FVector::Dist(P->GetActorLocation(), Leader->GetActorLocation()) / 100.f));
			}
			if (ActiveChain && ActiveChain->TotalMissionCount > 0)
			{
				Progress01 = FMath::Clamp(static_cast<float>(ActiveChain->CompletedMissionCount) / static_cast<float>(ActiveChain->TotalMissionCount), 0.20f, 1.0f);
			}
		}
	}
	else if (bTutActive && Tut)
	{
		if (!Tut->CurrentTaskWorldFocus.IsNearlyZero())
		{
			if (APawn* P = CachedPlayerPawn.Get())
			{
				DistMeters = FMath::Max(1, FMath::RoundToInt(FVector::Dist(P->GetActorLocation(), Tut->CurrentTaskWorldFocus) / 100.f));
			}
		}
		FSquadAITutorialBeat TutBeat;
		if (!Tut->IsAwaitingSkipAnswer() && Tut->GetCurrentBeat(TutBeat))
		{
			const int32 CurProg = FMath::Max(0, Tut->GetCurrentProgress());
			const int32 ReqCnt  = FMath::Max(1, TutBeat.RequiredCount);
			const float SubFrac = FMath::Clamp(static_cast<float>(CurProg) / static_cast<float>(ReqCnt), 0.f, 1.f);
			switch (TutBeat.Step)
			{
			case ESquadAITutorialStep::Task_Move:
				DistLbl = bEnglishHUD ? TEXT("Advance along the trench to range") : TEXT("پیشروی در سنگر تا موضع میدان تیر");
				Progress01 = FMath::Clamp(1.0f - (static_cast<float>(DistMeters) / 65.0f), 0.21f, 0.95f);
				break;
			case ESquadAITutorialStep::UI_Squad:
				DistLbl = bEnglishHUD ? TEXT("Review squad status & take cover") : TEXT("بررسی وضعیت جوخه و پناه‌گیری");
				Progress01 = 0.40f;
				break;
			case ESquadAITutorialStep::UI_Weapon:
			case ESquadAITutorialStep::Task_ShootCans:
				TagText = bEnglishHUD ? TEXT("LIVE FIRE") : TEXT("آتش واقعی");
				DistLbl = bEnglishHUD
					? FString::Printf(TEXT("Shoot target cans (%d / %d)"), CurProg, ReqCnt)
					: FString::Printf(TEXT("تیراندازی به قوطی‌ها (%s از %s)"),
						*UFarsiTextHelper::ToPersianDigits(FString::FromInt(CurProg)),
						*UFarsiTextHelper::ToPersianDigits(FString::FromInt(ReqCnt)));
				Progress01 = FMath::Clamp(0.45f + 0.30f * SubFrac, 0.45f, 0.75f);
				break;
			case ESquadAITutorialStep::Task_Grenade:
				TagText = bEnglishHUD ? TEXT("ORDNANCE") : TEXT("پرتاب نارنجک");
				DistLbl = bEnglishHUD ? TEXT("Arc grenade into target drum [G]") : TEXT("پرتاب نارنجک به درون بشکه هدف [G]");
				Progress01 = FMath::Clamp(0.75f + 0.15f * SubFrac, 0.75f, 0.90f);
				break;
			case ESquadAITutorialStep::UI_Artillery:
			case ESquadAITutorialStep::Task_Artillery:
				TagText = bEnglishHUD ? TEXT("FIRE SUPPORT") : TEXT("پشتیبانی آتش");
				DistLbl = bEnglishHUD ? TEXT("Call 120mm mortar strike [MMB]") : TEXT("فراخوانی آتش خمپاره ۱۲۰ میلی‌متری [MMB]");
				Progress01 = FMath::Clamp(0.88f + 0.12f * SubFrac, 0.88f, 1.0f);
				break;
			default:
				break;
			}
		}
	}

	// 3. Highlighted Objective Row (.objective): 9-slice warm amber-washed box + 3D fire sigil on RIGHT + rounded tag at top-left
	const float ObjY = CardY + HeadH + 2.f * S;
	const float ObjH = 58.f * S;
	Draw9SliceRoundedBox(CardX + 4.f * S, ObjY, CardW - 8.f * S, ObjH, FName(TEXT("ObjectiveWash")), 0.94f, S, 0.75f, false, 0.f);

	const float SigSz = 40.f * S;
	const float SigX = bEnglishHUD ? (CardX + 10.f * S) : (CardX + CardW - 10.f * S - SigSz);
	if (UTexture2D* FireSigil = GetUITexture(FName(TEXT("IconObjectiveFire3D"))))
	{
		DrawTexture(FireSigil, SigX, ObjY + (ObjH - SigSz) * 0.5f, SigSz, SigSz, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
	}

	const float TagW = 64.f * S, TagH = 15.f * S;
	const float TagX = bEnglishHUD ? (CardX + CardW - TagW - 10.f * S) : (CardX + 11.f * S);
	const float TagY = ObjY + 7.f * S;
	Draw9SliceRoundedBox(TagX, TagY, TagW, TagH, FName(TEXT("StepTileCurrent")), 0.85f, S, 0.45f, false, 0.f);
	DrawFarsiTextBounded(TagText, FSquadAIHUDPalette::Warm(), TagX + 3.f * S, TagY, TagW - 6.f * S, Font, 0.50f * S, false, true, TagH);

	const float ObjTextX = bEnglishHUD ? (CardX + 58.f * S) : (TagX + TagW + 8.f * S);
	const float ObjTextW = FMath::Max(80.f * S, bEnglishHUD ? (TagX - ObjTextX - 6.f * S) : (SigX - 8.f * S - ObjTextX));
	const float ObjSubX  = bEnglishHUD ? ObjTextX : (CardX + 10.f * S);
	const float ObjSubW  = bEnglishHUD ? (CardW - 68.f * S) : (SigX - 8.f * S - ObjSubX);
	DrawFarsiText3D(ObjTitle, FLinearColor(1.0f, 0.906f, 0.741f, 1.0f),
		ObjTextX, ObjY + 6.f * S, ObjTextW, Font, 0.86f * S, false, !bEnglishHUD, 22.f * S, 1.5f * S);
	DrawFarsiTextBounded(ObjSub, FLinearColor(0.788f, 0.757f, 0.710f, 0.96f),
		ObjSubX, ObjY + 30.f * S, ObjSubW, Font, 0.64f * S, true, false, 24.f * S, !bEnglishHUD);

	// 4. Distance row (.distance: in RTL, label on RIGHT, "۴۵ متر" on LEFT) + segmented gold progress track (.track)
	const float BodyY = ObjY + ObjH + 7.f * S;
	const float InnerX = CardX + 11.f * S;
	const float InnerW = CardW - 22.f * S;

	const FString DistValStr = bEnglishHUD
		? FString::Printf(TEXT("%d m"), DistMeters)
		: FString::Printf(TEXT("%s متر"), *UFarsiTextHelper::ToPersianDigits(FString::FromInt(DistMeters)));
	if (bEnglishHUD)
	{
		DrawFarsiTextBounded(DistLbl, FLinearColor(0.847f, 0.820f, 0.773f, 0.96f),
			InnerX, BodyY, InnerW * 0.68f, Font, 0.68f * S, true, false, 20.f * S, false);
		DrawFarsiText3D(DistValStr, FSquadAIHUDPalette::TextWhite(),
			InnerX + InnerW * 0.68f, BodyY, InnerW * 0.32f, Font, 0.74f * S, false, true, 20.f * S, 1.3f * S);
	}
	else
	{
		DrawFarsiTextBounded(DistLbl, FLinearColor(0.847f, 0.820f, 0.773f, 0.96f),
			InnerX + InnerW * 0.32f, BodyY, InnerW * 0.68f, Font, 0.68f * S, true, false, 20.f * S, true);
		DrawFarsiText3D(DistValStr, FSquadAIHUDPalette::TextWhite(),
			InnerX, BodyY, InnerW * 0.32f, Font, 0.74f * S, false, false, 20.f * S, 1.3f * S);
	}

	// Segmented gold progress bar (.track: fill on RIGHT in RTL)
	const float TrackY = BodyY + 21.f * S;
	const float TrackH = 3.2f * S;
	DrawRect(FLinearColor(1.f, 1.f, 1.f, 0.16f), InnerX, TrackY, InnerW, TrackH);
	const float TFillW = InnerW * Progress01;
	const float TFillX = bEnglishHUD ? InnerX : (InnerX + InnerW - TFillW);
	DrawRect(FSquadAIHUDPalette::BracketGold(), TFillX, TrackY, TFillW, TrackH);
	DrawRect(FSquadAIHUDPalette::GoldText(), TFillX, TrackY, TFillW * 0.65f, TrackH);
	for (float TickX = InnerX + 14.f * S; TickX < InnerX + InnerW - 4.f * S; TickX += 14.f * S)
	{
		DrawRect(FLinearColor(0.05f, 0.06f, 0.06f, 0.65f), TickX, TrackY, 1.5f * S, TrackH);
	}

	// 5. Ping prompt box (.ping: 9-slice rounded recessed box, border-radius: 5px, connected to live [V] GuidanceVision state)
	const float PingY = TrackY + 9.f * S;
	const float PingH = 26.f * S;
	const bool bVActive = bGuidanceVisionActive || (GetOwningPlayerController() && GetOwningPlayerController()->IsInputKeyDown(EKeys::V));
	Draw9SliceRoundedBox(InnerX, PingY, InnerW, PingH, bVActive ? FName(TEXT("StepTileCurrent")) : FName(TEXT("StepTile")), 0.68f, S, 0.65f, false, 0.f);
	if (bEnglishHUD)
	{
		DrawFarsiTextBounded(TEXT("Reveal illuminated path to objective"),
			bVActive ? FSquadAIHUDPalette::GoldText() : FLinearColor(0.831f, 0.800f, 0.745f, 0.95f),
			InnerX + 8.f * S, PingY, InnerW - 42.f * S, Font, 0.62f * S, true, false, PingH, false);
		DrawKeycapGlyph(InnerX + InnerW - 28.f * S, PingY + (PingH - 18.f * S) * 0.5f, 18.f * S, TEXT("V"), Font, FSquadAIHUDPalette::GoldText(), bVActive);
	}
	else
	{
		DrawKeycapGlyph(InnerX + 6.f * S, PingY + (PingH - 18.f * S) * 0.5f, 18.f * S, TEXT("V"), Font, FSquadAIHUDPalette::GoldText(), bVActive);
		DrawFarsiTextBounded(TEXT("نمایش مسیر نورانی تا هدف"),
			bVActive ? FSquadAIHUDPalette::GoldText() : FLinearColor(0.831f, 0.800f, 0.745f, 0.95f),
			InnerX + 34.f * S, PingY, InnerW - 42.f * S, Font, 0.62f * S, true, false, PingH, true);
	}

	// 6. Mission metadata footer (.missionmeta: live 34T grid coordinates from PlayerPawn + live radio/artillery link state)
	const float MetaY = PingY + PingH + 5.f * S;
	int32 GridCode = 428;
	if (APawn* P = CachedPlayerPawn.Get())
	{
		const FVector Loc = P->GetActorLocation();
		const int32 OffsetM = FMath::RoundToInt((Loc.X + Loc.Y) / 500.f);
		GridCode = ((428 + OffsetM) % 900 + 900) % 900 + 100;
	}
	const FString CoordStrEn = FString::Printf(TEXT("KARKHEH AXIS · 34T %d"), GridCode);
	const FString CoordStrFa = FString::Printf(TEXT("مختصات محور کرخه · 34T %d"), GridCode);

	bool bRadioTxActive = false;
	if (const USquadAIRadioChatterSubsystem* RadioSys = USquadAIRadioChatterSubsystem::Get(this))
	{
		bRadioTxActive = (RadioSys->GetLastRadioTimeRemaining() > 0.f);
	}
	const FLinearColor RadioCol = bRadioTxActive ? FSquadAIHUDPalette::GoldText() : FSquadAIHUDPalette::Success();
	const FString RadioStatusEn = bRadioTxActive ? TEXT("RADIO TX ACTIVE") : TEXT("RADIO STABLE");
	const FString RadioStatusFa = bRadioTxActive ? TEXT("دریافت پیام بی‌سیم") : TEXT("بی‌سیم برقرار");

	if (bEnglishHUD)
	{
		DrawFarsiTextBounded(CoordStrEn, FSquadAIHUDPalette::Muted(),
			InnerX, MetaY, InnerW * 0.58f, Font, 0.54f * S, false, false, 16.f * S, false);
		DrawRect(FSquadAIHUDPalette::WithAlpha(RadioCol, 0.35f), InnerX + InnerW - 85.f * S, MetaY + 4.f * S, 7.f * S, 7.f * S);
		DrawRect(RadioCol, InnerX + InnerW - 84.f * S, MetaY + 5.f * S, 5.f * S, 5.f * S);
		DrawFarsiTextBounded(RadioStatusEn, RadioCol,
			InnerX + InnerW * 0.58f, MetaY, InnerW * 0.42f, Font, 0.54f * S, false, false, 16.f * S, true);
	}
	else
	{
		DrawFarsiTextBounded(CoordStrFa, FSquadAIHUDPalette::Muted(),
			InnerX + InnerW * 0.42f, MetaY, InnerW * 0.58f, Font, 0.54f * S, false, false, 16.f * S, true);
		DrawRect(FSquadAIHUDPalette::WithAlpha(RadioCol, 0.35f), InnerX + 63.f * S, MetaY + 5.f * S, 7.f * S, 7.f * S);
		DrawRect(RadioCol, InnerX + 64.f * S, MetaY + 6.f * S, 5.f * S, 5.f * S);
		DrawFarsiTextBounded(RadioStatusFa, RadioCol,
			InnerX, MetaY, 60.f * S, Font, 0.54f * S, false, false, 16.f * S, false);
	}
}

void AQuestNativeHUD::DrawHUD()
{
	Super::DrawHUD();
	if (!Canvas) return;
	if (!GetWorld() || !GetWorld()->IsGameWorld()) return;
	UWorld* World = GetWorld();
	if (!World) return;

	const float DeltaTime = World->GetDeltaSeconds();
	TimeSinceRefresh += DeltaTime;
	if (TimeSinceRefresh >= RefreshInterval) { TimeSinceRefresh = 0.f; }

	if (HUDEntranceStartTime < 0.f) { HUDEntranceStartTime = World->GetTimeSeconds(); } // S18-FEEL

	ShapedTextFrameCache.Reset(); // B6-15: per-frame shape cache starts empty.
	GameUIScale = Canvas ? FMath::Clamp(Canvas->ClipY / 1080.f, 0.70f, 1.35f) : 1.f; // B6-14: menu-HUD parity.
	HUDFontScale = SquadAIHUDIsEnglish(this) ? 1.f : 1.15f;
	TopNoticeBottomY = -1.f; // S19-MISSUI: the top-centre notice lane is rebuilt every frame.
	UFont* Font = GetHUDFont();

	if (!bMissionAlertsBound)
	{
		bMissionAlertsBound = true;
		BindMissionZoneAlerts();
	}
	APawn* PlayerPawn = CachedPlayerPawn.Get();
	if (!PlayerPawn)
	{
		PlayerPawn = UGameplayStatics::GetPlayerPawn(World, 0);
		CachedPlayerPawn = PlayerPawn;
	}

	// Poll Developer Hotkeys (F1-F7) and update the low-res camera-synced frosted-glass backdrop blur RT
	if (APlayerController* PC = Cast<APlayerController>(PlayerPawn ? PlayerPawn->GetController() : UGameplayStatics::GetPlayerController(World, 0)))
	{
		EnsureHUDBackdropBlur(PC, PlayerPawn);
		if (USquadAIDevDebugSubsystem* DevSys = USquadAIDevDebugSubsystem::Get(this))
		{
			DevSys->PollDeveloperHotkeys(PC);
		}
	}

	if (TimeSinceRefresh == 0.f || CachedSoldierDots.Num() == 0)
	{
		RebuildSoldierDots();
	}

	// Periodically suppress any legacy / third-party-pack viewport widgets.
	// P6-6/P7-UI1: DENY-BY-DEFAULT. The old class-name substring allow-list leaked any pack
	// widget whose class name didn't match (e.g. the TPW health bar) — and viewport widgets
	// draw ON TOP of the Canvas HUD, covering the tactical weapon plate and sitting above
	// the loading screen. Everything not explicitly registered (loading screen) is collapsed.
	// Backoff: once every foreign widget is already collapsed the sweep idles at 10 s
	// (B6-15: the global TObjectIterator pass is the expensive part).
	static float LegacyWidgetCleanTimer = 999.f;
	static int32 ConsecutiveEmptySweeps = 0;
	LegacyWidgetCleanTimer += DeltaTime;
	const float SweepInterval = (ConsecutiveEmptySweeps >= 3) ? 10.f : 1.0f;
	if (bSuppressLegacyUMG && LegacyWidgetCleanTimer >= SweepInterval)
	{
		LegacyWidgetCleanTimer = 0.f;
		const int32 Neutralized = SquadAISuppressForeignViewportWidgets(World);
		ConsecutiveEmptySweeps = (Neutralized == 0) ? ConsecutiveEmptySweeps + 1 : 0;
	}

	const float SW = Canvas->ClipX;
	const float SH = Canvas->ClipY;

	// ===== TACTICAL PAUSE MENU =====
	if (bPauseMenuActive)
	{
		DrawPauseMenu(SW, SH, DeltaTime, Font);
		return;
	}

	// ===== TACTICAL INVENTORY & BACKPACK =====
	if (bInventoryOpen)
	{
		DrawInventoryScreen(SW, SH, DeltaTime, Font, PlayerPawn);
		return;
	}

	// ===== DEPLOYMENT WARMUP VEIL =====
	if (bDeploymentVeilActive)
	{
		DrawDeploymentVeil(SW, SH, DeltaTime, Font);
		return;
	}

	const float CX_Screen = SW * 0.5f;
	const float CY_Screen = SH * 0.5f;
	const FVector PL = PlayerPawn ? PlayerPawn->GetActorLocation() : FVector::ZeroVector;
	const float PY = PlayerPawn ? PlayerPawn->GetControlRotation().Yaw : 0.f;

	// ===== 1. SCREEN OVERLAYS (Low HP Blood, Fire Burn, & Suppression) & .stage:after VIEWPORT FRAME =====
	const float HealthPercent = GetPlayerHealthPercent(PlayerPawn);
	DrawLowHealthVignette(SW, SH, HealthPercent);
	DrawFireBurnVignette(SW, SH, DeltaTime);
	DrawSuppressionVignette(SW, SH, DeltaTime);
	{
		// Matches .stage:after in index.html line 32: inset: 8px; border: 1px solid #ffffff18
		const float StagePad = FMath::RoundToFloat(8.f * GameUIScale);
		const FLinearColor StageFrameCol = FSquadAIHUDPalette::SRGB(255, 255, 255, 0.095f);
		DrawRect(StageFrameCol, StagePad, StagePad, SW - StagePad * 2.f, 1.f);
		DrawRect(StageFrameCol, StagePad, SH - StagePad - 1.f, SW - StagePad * 2.f, 1.f);
		DrawRect(StageFrameCol, StagePad, StagePad, 1.f, SH - StagePad * 2.f);
		DrawRect(StageFrameCol, SW - StagePad - 1.f, StagePad, 1.f, SH - StagePad * 2.f);
	}

	// ===== 2. DIRECTIONAL DAMAGE HIT INDICATORS =====
	DrawDirectionalDamageIndicators(CX_Screen, CY_Screen, PL, PY, DeltaTime);

	// ===== 3. CROSSHAIR HIT CONFIRMATION MARKER =====
	DrawHitMarker(CX_Screen, CY_Screen, DeltaTime);

	// ===== 3B. DYNAMIC OPTICAL TACTICAL RETICLE & SPREAD =====
	DrawDynamicTacticalReticle(CX_Screen, CY_Screen, PlayerPawn, DeltaTime, Font);

	// ===== 4. TACTICAL COMPASS RIBBON (Top-Center) =====
	bEnableTacticalCompassRibbon = true;
	bEnableSquadStatusPanel = true;
	bEnableNativeWeaponStatusPlate = true;
	bEnableMissionObjectiveCard = true;
	bShowTutorialChecklist = true;

	DrawTacticalCompassRibbon(CX_Screen, 12.f * GameUIScale, PY, Font, PL);

	// ===== 4B. TACTICAL WEAPON & HEALTH STATUS PLATE (Bottom-Right) =====
	DrawTacticalWeaponStatusPlate(SW, SH, PlayerPawn, Font);

	// ===== 4C. ALLY DOWNED CRITICAL ALERT BANNER =====
	DrawAllyDownedAlertBanner(SW, SH, DeltaTime, Font);

	// ===== 4D. MORTAR INCOMING DANGER ZONES & FIRE SUPPORT AIMING =====
	if (APlayerController* PC = Cast<APlayerController>(PlayerPawn ? PlayerPawn->GetController() : nullptr))
	{
		if (PC->IsInputKeyDown(EKeys::MiddleMouseButton))
		{
			FVector CamLoc;
			FRotator CamRot;
			PC->GetPlayerViewPoint(CamLoc, CamRot);
			FHitResult Hit;
			FCollisionQueryParams TraceParams(SCENE_QUERY_STAT(MortarAim), false, PlayerPawn);
			if (GetWorld()->LineTraceSingleByChannel(Hit, CamLoc, CamLoc + CamRot.Vector() * 20000.f, ECC_Visibility, TraceParams))
			{
				SetMortarAimingActive(true, Hit.ImpactPoint);
			}
		}
		else if (bMortarAimingActive)
		{
			SetMortarAimingActive(false, FVector::ZeroVector);
		}
	}

	DrawMortarDangerZones(PlayerPawn, DeltaTime, Font);
	DrawMortarTargetingMarker(PlayerPawn, DeltaTime, Font);

	// ===== 5. TACTICAL 3D WORLD PINGS & SPOTTING =====
	DrawTactical3DPings(Font, PlayerPawn);

	// ===== 6. BATTLEFIELD INTERACTION PROMPTS (Ammo, First Aid & Heavy Turrets) =====
	DrawBattlefieldInteractionPrompts(Font, PlayerPawn);

	// ===== 6c. THE COMMANDER LAYER (S19-ELITE) =====
	DrawCommanderLayer(SW, SH, Font);

	// ===== 7. OBJECTIVE GUIDANCE VISION (Hold 'V' to Desaturate World & Illuminate Path) =====
	DrawObjectiveGuidanceVision(SW, SH, DeltaTime, PlayerPawn, Font);

	// ===== 8. TOP-RIGHT TACTICAL CLUSTER: MINIMAP (.mapbox) + SQUAD CARDS (.squad) + ELAPSED CLOCK (.elapsed) =====
	InitMinimap(PlayerPawn); // B6-20: no-op unless the pawn changed or the comp died.
	float R = 66.f * GameUIScale;
	float CX = SW - R - MinimapMargin * GameUIScale;
	float CY = SH * 0.024f + R;
	DrawTopRightSquadAndClockCluster(SW * 0.975f, SH * 0.024f, GameUIScale, Font, PlayerPawn, CX, CY, R);

	AQuestChain* Chain = FindQuestChain();
	const USquadAITuning* Tuning = USquadAITuning::Get();

	DrawMinimap(CX, CY, R, PL, PY, Font);

	// ===== 6. BORDER INDICATORS =====
	const float WR = MinimapCaptureWidth * 0.5f;
	if (Chain && Chain->bIsActive)
	{
		AMissionZone* Cur = Chain->GetCurrentMission();
		if (Cur && FVector::Dist(PL, Cur->GetActorLocation()) > WR)
		{
			DrawBorderIndicator(CX, CY, R, Cur->GetActorLocation(), PL, PY,
				Tuning ? Tuning->MissionBorderIcon.Get() : nullptr, FLinearColor(1.f, 0.9f, 0.2f));
		}
	}
	// B6-18: the leader pip is navigation, not mission state — draw it with no active chain too.
	AActor* LeaderActor = FindCachedLeader();
	if (LeaderActor && FVector::Dist(PL, LeaderActor->GetActorLocation()) > WR)
	{
		DrawBorderIndicator(CX, CY, R, LeaderActor->GetActorLocation(), PL, PY,
			Tuning ? Tuning->LeaderBorderIcon.Get() : nullptr, FLinearColor(0.2f, 0.4f, 1.f));
	}

	// ===== 7. TACTICAL SQUAD STATUS PANEL (Bottom-Left) =====
	{
		const float Life = GetWorld() ? (GetWorld()->GetTimeSeconds() - HUDEntranceStartTime) : 10.f;
		const float In01 = FMath::Clamp(Life / 0.55f, 0.f, 1.f);
		const float Ease = 1.f - FMath::Pow(1.f - In01, 3.f);
		const float SquadSlide = (1.f - Ease) * -260.f * GameUIScale;
		DrawSquadStatusPanel(30.f * GameUIScale + SquadSlide, SH - 240.f * GameUIScale, Font, PlayerPawn);
	}

	// ===== 9. MISSION OBJECTIVE CARD (Right-Middle .mission) =====
	{
		const float Life = GetWorld() ? (GetWorld()->GetTimeSeconds() - HUDEntranceStartTime) : 10.f;
		const float In01 = FMath::Clamp((Life - 0.12f) / 0.55f, 0.f, 0.55f);
		const float Ease = 1.f - FMath::Pow(1.f - In01, 3.f);
		const float CardSlide = (1.f - Ease) * -320.f * GameUIScale;
		DrawMissionObjectiveCard(30.f * GameUIScale + CardSlide, 48.f * GameUIScale, Chain, Font);
	}

	// ===== 10. DEATH PROMPT & COMBAT FEED =====
	if (AlertBannerEndTime > 0.f && World->GetTimeSeconds() >= AlertBannerEndTime)
	{
		AlertBannerEndTime = -1.f;
	}
	if (NoteDisplayEndTime > 0.f && World->GetTimeSeconds() >= NoteDisplayEndTime)
	{
		NoteDisplayEndTime = -1.f;
	}
	DrawDeathPrompt(SW, SH, Font);
	DrawCombatFeed(SW, SH, Font);

	// ===== 13. POST-DEPLOYMENT FADE-IN (S17-STORY, always last) =====
	DrawPostVeilFade(SW, SH);

	// ===== 13b. GRENADE THROW PREVIEW (S19-TUT, under the tutorial layer) =====
	DrawGrenadeThrowPreview(PlayerPawn, Font);

	// ===== 14. UNIFIED TUTORIAL & MISSION OVERLAY (S18-TUT / S27-REFUI) =====
	// Renders .operation-banner, .tutorial, .focus-instruction, .training-panel, .movehint, .waypoint, and .ally
	// in both Tutorial Mode and Post-Tutorial Mission Mode with the exact same index.html style!
	DrawTutorialOverlay(SW, SH, DeltaTime, Font);
}

// ==========================================================================
//  S19-TUT: grenade throw preview
//  "Put the grenade in the barrel" is unanswerable when you cannot judge the
//  throw. This draws the real arc — the same origin, launch bias and gravity
//  the component uses — plus a ring on the ground where it will land, so you
//  can sweep the cursor and watch the ring walk onto the barrel.
//  Canvas-only: no meshes, no Niagara, no materials, works in every build.
// ==========================================================================
void AQuestNativeHUD::DrawGrenadeThrowPreview(APawn* PlayerPawn, UFont* Font)
{
	if (!bDrawGrenadeThrowPreview || !Canvas || !PlayerPawn)
	{
		return;
	}

	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}

	APlayerController* PC = Cast<APlayerController>(PlayerPawn->GetController());
	if (!PC)
	{
		return;
	}

	UTacticalGrenadeComponent* Gren = PlayerPawn->FindComponentByClass<UTacticalGrenadeComponent>();
	if (!Gren)
	{
		return;
	}

	// Three ways in: the component flag (designer / always-on), the tutorial asking for
	// it during the grenade lesson, or the player holding [G]/[H] to aim a throw.
	// S19-GRENARC: the last one is the feature - hold to aim, release to throw, with a
	// landing arrow the whole time the key is down.
	const bool bAiming = Gren->IsAimingGrenade();
	bool bWanted = Gren->bShowThrowPreview || bAiming;
	if (!bWanted)
	{
		if (const USquadAITutorialSubsystem* Tut = USquadAITutorialSubsystem::Get(this))
		{
			bWanted = Tut->IsGrenadePreviewWanted();
		}
	}

	const float DeltaTime = FMath::Max(World->GetDeltaSeconds(), 0.f);
	const float Rate = (GrenadePreviewFadeOutSeconds > KINDA_SMALL_NUMBER)
		? (DeltaTime / GrenadePreviewFadeOutSeconds) : 1.f;
	GrenadePreviewAlpha = FMath::Clamp(GrenadePreviewAlpha + (bWanted ? Rate : -Rate), 0.f, 1.f);

	const EGrenadeType PreviewType = Gren->GetAimingGrenadeType();

	if (bWanted)
	{
		const FVector Dir = Gren->GetCurrentThrowDirection();
		TArray<FVector> Path, Tail;
		FGrenadeFlightResult Result;
		// S19-GRENBLAST: the inputs as well as the outputs - the blast radius and the frag
		// flag live on the params struct.
		GrenadePreviewParams = Gren->GetFlightParams(PreviewType);
		if (Gren->PredictThrowDetailed(PreviewType, Dir, Path, Tail, Result) && Path.Num() >= 2)
		{
			GrenadePreviewPath = MoveTemp(Path);
			GrenadePreviewTail = MoveTemp(Tail);
			GrenadePreviewResult = Result;
			GrenadePreviewImpact = Result.DetonationPoint;
			bGrenadePreviewImpacted = Result.bHit;
		}
		else
		{
			// S19-DEEPREVIEW: a failed prediction must not leave the LAST
			// session's answer on the books - the aim log reads GrenadePreviewResult on the
			// frame the aim starts, and the danger tint reads GrenadePreviewImpact. Stale
			// values from the previous throw would be reported as this one's.
			GrenadePreviewResult = FGrenadeFlightResult();
			GrenadePreviewImpact = FVector::ZeroVector;
			bGrenadePreviewImpacted = false;
		}
	}

	// One line per aim session in the situation log: the flight model's answer, which is
	// what the arrow is showing. If the arrow ever looks wrong in PIE, this is the number
	// to compare it against.
	if (bAiming && !bGrenadePreviewWasAiming)
	{
		const float Dist = FVector::Dist(PlayerPawn->GetActorLocation(), GrenadePreviewImpact);
		SquadAISituation::Note(FString::Printf(
			TEXT("GRENADE aim: %s, predicted detonation %.0f m away at t=%.2fs (first contact %s at %.2fs, %d bounce(s), fuse %.1fs)"),
			PreviewType == EGrenadeType::SmokeScreen ? TEXT("smoke") : TEXT("frag"),
			Dist / 100.f, GrenadePreviewResult.DetonationTime,
			GrenadePreviewResult.bHit ? TEXT("yes") : TEXT("no"),
			GrenadePreviewResult.FirstImpactTime,
			GrenadePreviewResult.BounceCount, GrenadePreviewResult.FuseTime));
	}
	bGrenadePreviewWasAiming = bAiming;

	if (GrenadePreviewAlpha <= KINDA_SMALL_NUMBER || GrenadePreviewPath.Num() < 2)
	{
		return;
	}

	const float S = GameUIScale;
	const float Alpha = GrenadePreviewAlpha;
	const float TimeNow = World->GetTimeSeconds();

	// ---- shared projection helpers -----------------------------------------
	TWeakObjectPtr<APlayerController> WeakPC(PC);
	// (The parameter is WorldPoint, not World: it would otherwise shadow the UWorld*
	// above, which is the kind of hidden-declaration warning that hides real bugs.)
	auto ProjectW = [&WeakPC](const FVector& WorldPoint, FVector2D& OutScreen) -> bool
	{
		APlayerController* P = WeakPC.Get();
		return P ? P->ProjectWorldLocationToScreen(WorldPoint, OutScreen) : false;
	};

	auto WorldSeg = [&](const FVector& A, const FVector& B, const FLinearColor& Color, float Thickness) -> bool
	{
		FVector2D SA, SB;
		if (!ProjectW(A, SA) || !ProjectW(B, SB))
		{
			return false;
		}
		DrawLine(SA.X, SA.Y, SB.X, SB.Y, Color, Thickness);
		return true;
	};

	// A filled arrow head whose tip sits on the arc, pointing along the direction of
	// travel: the "angry bird" read. Screen-space, so it never deforms with the camera.
	// This HUD has no triangle primitive, so the head is filled with five parallel ribs
	// (a scanline fill) plus one bright centre rib for the two-tone shading.
	auto ScreenArrowHead = [&](const FVector2D& Tip, const FVector2D& Dir2D, float Len, float Width, const FLinearColor& Color)
	{
		FVector2D D = Dir2D;
		if (!D.Normalize())
		{
			return;
		}
		const FVector2D Perp(-D.Y, D.X);
		const FVector2D Base = Tip - D * Len;
		constexpr int32 Ribs = 5;
		for (int32 i = 0; i < Ribs; ++i)
		{
			const float T = static_cast<float>(i) / static_cast<float>(Ribs - 1);
			const FVector2D P = FMath::Lerp(Tip, Base, T);
			const float HalfW = Width * 0.5f * T;
			DrawLine(P.X - Perp.X * HalfW, P.Y - Perp.Y * HalfW,
				P.X + Perp.X * HalfW, P.Y + Perp.Y * HalfW, Color, 2.2f * S);
		}
		const FLinearColor Inner(
			FMath::Min(Color.R * 1.35f, 1.f), FMath::Min(Color.G * 1.35f, 1.f),
			FMath::Min(Color.B * 1.35f, 1.f), Color.A);
		DrawLine(Tip.X, Tip.Y, Base.X, Base.Y, Inner, 1.4f * S);
	};

	// ---- 1. aim vignette (COD-style focus; HUD-only, no lighting) -----------
	if (bGrenadePreviewAimVignette && bAiming)
	{
		const float V = FMath::Clamp(GrenadeAimVignetteStrength, 0.f, 1.f) * Alpha;
		const float BX = Canvas->ClipX;
		const float BY = Canvas->ClipY;
		const float Band = FMath::Min(BX, BY) * 0.16f;
		for (int32 i = 0; i < 5; ++i)
		{
			const float T = static_cast<float>(i) / 5.f;
			const float A = V * 0.20f * (1.f - T);
			DrawRect(FLinearColor(0.f, 0.f, 0.f, A), 0.f, 0.f, BX, Band * (1.f - T) * 0.5f);
			DrawRect(FLinearColor(0.f, 0.f, 0.f, A), 0.f, BY - Band * (1.f - T) * 0.5f, BX, Band * (1.f - T) * 0.5f);
			DrawRect(FLinearColor(0.f, 0.f, 0.f, A), 0.f, 0.f, Band * (1.f - T) * 0.5f, BY);
			DrawRect(FLinearColor(0.f, 0.f, 0.f, A), BX - Band * (1.f - T) * 0.5f, 0.f, Band * (1.f - T) * 0.5f, BY);
		}
	}

	// ---- 2. the bounce tail (after the first contact) -----------------------
	if (bGrenadePreviewDrawBounces && GrenadePreviewTail.Num() >= 2)
	{
		FLinearColor TailCol = GrenadeBounceTailColor;
		TailCol.A *= Alpha;
		const float TailThick = FMath::Max(0.5f, GrenadeBounceTailThickness) * S;
		const int32 N = GrenadePreviewTail.Num();
		// Dotted: a tail that reads as "this part is approximate", which it is.
		for (int32 i = 0; i + 1 < N; i += 2)
		{
			const float T = static_cast<float>(i) / static_cast<float>(N - 1);
			FLinearColor C = TailCol;
			C.A *= (1.f - 0.55f * T) * 0.9f;
			WorldSeg(GrenadePreviewTail[i], GrenadePreviewTail[i + 1], C, TailThick * (1.f - 0.35f * T));
		}
	}

	// ---- 3. the trajectory: dark core + bright edge (COD shading) ----------
	const int32 N = GrenadePreviewPath.Num();
	{
		// pass 1: the dark outline, slightly thicker
		for (int32 i = 0; i + 1 < N; ++i)
		{
			const float T = static_cast<float>(i) / static_cast<float>(N - 1);
			FLinearColor Core(0.03f, 0.05f, 0.06f, 0.55f * Alpha * (1.f - 0.25f * T));
			const float Thick = FMath::Lerp(6.4f, 3.6f, T) * S;
			WorldSeg(GrenadePreviewPath[i], GrenadePreviewPath[i + 1], Core, Thick);
		}

		// pass 2: the lit body, warm near the hand bleeding into green at the far end
		const int32 Stride = FMath::Max(1, GrenadeArcDotStride);
		for (int32 i = 0; i + Stride < N + Stride; i += Stride)
		{
			const int32 A = FMath::Min(i, N - 1);
			const int32 B = FMath::Min(i + Stride, N - 1);
			if (A == B) break;
			const float T = static_cast<float>(A) / static_cast<float>(N - 1);
			FLinearColor C = FMath::Lerp(GrenadeArcNearColor, GrenadeArcFarColor, T);
			C.A *= Alpha * (1.f - 0.25f * T);
			const float Thick = FMath::Lerp(3.4f, 1.8f, T) * S;
			WorldSeg(GrenadePreviewPath[A], GrenadePreviewPath[B], C, Thick);
		}
	}

	// ---- 4. chevrons along the arc (the arrow rhythm) ----------------------
	const int32 ChevStride = FMath::Max(0, GrenadeArrowChevronStride);
	if (ChevStride > 0 && N >= ChevStride + 1)
	{
		for (int32 i = ChevStride; i < N - 1; i += ChevStride)
		{
			FVector2D P, P0, P1;
			if (!ProjectW(GrenadePreviewPath[i], P)) continue;
			if (!ProjectW(GrenadePreviewPath[FMath::Max(0, i - 1)], P0)) continue;
			if (!ProjectW(GrenadePreviewPath[FMath::Min(N - 1, i + 1)], P1)) continue;

			FVector2D Dir2D = (P1 - P0);
			if (!Dir2D.Normalize()) continue;
			const float T = static_cast<float>(i) / static_cast<float>(N - 1);
			FLinearColor C = FMath::Lerp(GrenadeArcNearColor, GrenadeArcFarColor, T);
			C.A *= Alpha * 0.92f;

			const float Sz = GrenadeArrowChevronSize * S * FMath::Lerp(1.0f, 0.7f, T);
			const FVector2D Perp(-Dir2D.Y, Dir2D.X);
			// A chevron opening backwards along the flight path: "->"
			const FVector2D TipP = P + Dir2D * (Sz * 0.45f);
			const FVector2D Back = P - Dir2D * (Sz * 0.45f);
			DrawLine(Back.X + Perp.X * Sz * 0.6f, Back.Y + Perp.Y * Sz * 0.6f, TipP.X, TipP.Y, C, 2.0f * S);
			DrawLine(Back.X - Perp.X * Sz * 0.6f, Back.Y - Perp.Y * Sz * 0.6f, TipP.X, TipP.Y, C, 2.0f * S);
		}
	}

	// ---- 5. the arrow head at the end of the arc --------------------------
	{
		const int32 Last = N - 1;
		FVector2D Tip, Prev;
		if (ProjectW(GrenadePreviewPath[Last], Tip) && ProjectW(GrenadePreviewPath[FMath::Max(0, Last - 2)], Prev))
		{
			FVector2D Dir2D = (Tip - Prev);
			const float Len = 17.f * S;
			const float Wid = 13.f * S;
			FLinearColor HeadCol = GrenadeArcFarColor;
			HeadCol.A *= Alpha;
			ScreenArrowHead(Tip, Dir2D, Len, Wid, HeadCol);
		}
	}

	// ---- 6. the reticle at the detonation point ---------------------------
	const FVector& Impact = GrenadePreviewImpact;

	// Threat read: is anything alive and hostile inside the blast? The reticle answers
	// the only question that matters while aiming - "will this kill them".
	bool bEnemyInBlast = false;
	if (bGrenadePreviewDangerTint && GrenadePreviewParams.bIsFrag)   // S19-GRENBLAST
	{
		if (const USoldierRegistrySubsystem* Reg = World->GetSubsystem<USoldierRegistrySubsystem>())
		{
			for (const TWeakObjectPtr<ASoldierCharacter>& Weak : Reg->GetAllSoldiers())
			{
				const ASoldierCharacter* S2 = Weak.Get();
				if (!S2 || !S2->IsAlive() || !S2->IsEnemy())
				{
					continue;
				}
				if (FVector::Dist(S2->GetActorLocation(), Impact) <= GrenadePreviewParams.BlastRadius)   // S19-GRENBLAST
				{
					bEnemyInBlast = true;
					break;
				}
			}
		}
	}

	FLinearColor Ring = bEnemyInBlast ? GrenadeDangerTintColor : GrenadeImpactRingColor;
	Ring.A *= Alpha;

	auto ProjectGroundRing = [&](float Radius, const FLinearColor& Color, float Thickness, float ZOffset)
	{
		constexpr int32 Segs = 32;
		const float Step = (2.f * PI) / static_cast<float>(Segs);
		FVector2D PrevPt(0.f, 0.f);
		bool bPrevOk = false;
		for (int32 i = 0; i <= Segs; ++i)
		{
			const float Ang = i * Step;
			const FVector P = Impact + FVector(FMath::Cos(Ang) * Radius, FMath::Sin(Ang) * Radius, ZOffset);
			FVector2D SP(0.f, 0.f);
			const bool bOk = ProjectW(P, SP);
			if (bPrevOk && bOk)
			{
				DrawLine(PrevPt.X, PrevPt.Y, SP.X, SP.Y, Color, Thickness);
			}
			PrevPt = SP;
			bPrevOk = bOk;
		}
	};

	// ---- 6b. no contact under the arc ------------------------------------
	// Aiming over a wall or off a cliff: a ghost reticle marks where the simulation
	// stopped, and none of the "it lands here" furniture is drawn, because it would be a
	// promise the throw does not keep. The aim panel below still appears - the player is
	// still aiming and still needs to be told what the key does.
	const float Pulse = 0.5f + 0.5f * FMath::Sin(TimeNow * 6.f);

	if (!bGrenadePreviewImpacted)
	{
		FVector2D Ghost(0.f, 0.f);
		if (ProjectW(Impact, Ghost))
		{
			const float R = 9.f * S;
			FLinearColor Dim = Ring;
			Dim.A *= 0.6f;
			DrawLine(Ghost.X - R, Ghost.Y - R, Ghost.X + R, Ghost.Y + R, Dim, 1.6f * S);
			DrawLine(Ghost.X - R, Ghost.Y + R, Ghost.X + R, Ghost.Y - R, Dim, 1.6f * S);
		}
	}
	else
	{
		ProjectGroundRing(GrenadeImpactRingRadiusCm, Ring, 2.4f * S, 8.f);
		ProjectGroundRing(GrenadeImpactRingRadiusCm * (0.42f + 0.18f * Pulse), Ring, 1.5f * S, 8.f);

		// The blast footprint itself, very faint: 6 m of frag has an edge, and the player
		// is entitled to see roughly where it is (to throw it AT something, or to not be
		// in it).
		{
			FLinearColor Blast = Ring;
			Blast.A *= 0.22f;
			ProjectGroundRing(GrenadePreviewParams.BlastRadius, Blast, 1.2f * S, 6.f);   // S19-GRENBLAST
		}

		// Short post so the point reads on flat sand.
		{
			FVector2D Bot(0.f, 0.f), Top(0.f, 0.f);
			if (ProjectW(Impact + FVector(0.f, 0.f, 6.f), Bot) && ProjectW(Impact + FVector(0.f, 0.f, 85.f), Top))
			{
				DrawLine(Bot.X, Bot.Y, Top.X, Top.Y, Ring, 2.f * S);
			}
		}

		// COD-style corner brackets around the reticle.
		{
			FVector2D SP(0.f, 0.f);
			if (ProjectW(Impact, SP))
			{
				const float Half = (bEnemyInBlast ? 26.f : 22.f) * S;
				const float Arm = Half * 0.42f;
				const float Th = 2.0f * S;
				DrawRect(Ring, SP.X - Half, SP.Y - Half, Arm, Th);
				DrawRect(Ring, SP.X - Half, SP.Y - Half, Th, Arm);
				DrawRect(Ring, SP.X + Half - Arm, SP.Y - Half, Arm, Th);
				DrawRect(Ring, SP.X + Half - Th, SP.Y - Half, Th, Arm);
				DrawRect(Ring, SP.X - Half, SP.Y + Half - Th, Arm, Th);
				DrawRect(Ring, SP.X - Half, SP.Y + Half - Arm, Th, Arm);
				DrawRect(Ring, SP.X + Half - Arm, SP.Y + Half - Th, Arm, Th);
				DrawRect(Ring, SP.X + Half - Th, SP.Y + Half - Arm, Th, Arm);

				// A dot at the exact point, breathing with the ring.
				const float DotR = (1.6f + 0.9f * Pulse) * S;
				DrawRect(Ring, SP.X - DotR, SP.Y - DotR, DotR * 2.f, DotR * 2.f);
			}
		}

		// ---- 7. distance readout ------------------------------------------
		if (bShowGrenadeThrowDistance && Font)
		{
			FVector2D SP(0.f, 0.f);
			if (ProjectW(Impact + FVector(0.f, 0.f, 46.f), SP))
			{
				const int32 Metres = FMath::RoundToInt(FVector::Dist(PlayerPawn->GetActorLocation(), Impact) / 100.f);
				// S19-COMPILEFIX: one literal format, the unit word is the argument -
				// UE 5.7 type-checks Printf formats at compile time.
				const FString Txt = FString::Printf(TEXT("%d %s"), Metres,
					SquadAIHUDIsEnglish(this) ? TEXT("m") : TEXT("متر"));

				FLinearColor TxtCol = bEnemyInBlast ? GrenadeDangerTintColor : FLinearColor(1.f, 0.93f, 0.72f, 1.f);
				TxtCol.A *= Alpha;
				DrawFarsiTextBounded(Txt, TxtCol, SP.X - 60.f * S, SP.Y + 8.f * S,
					120.f * S, Font, 0.78f * S, true, true);
			}
		}
	}

	// ---- 8. the aiming legend --------------------------------------------
	if (bGrenadePreviewLegend && bAiming && Font)
	{
		// S19-GRENARC: the aim panel. Positioned centre-low so it never fights the
		// reticle, and built from the same FA/EN table as the rest of the HUD.
		const FString Title = SquadAIHUDLocal(this, TEXT("HUD"), TEXT("GrenadeAimTitle"),
			TEXT("نارنجک — نشانه‌گیری"), TEXT("GRENADE - AIMING"));
		const FString Hint = SquadAIHUDLocal(this, TEXT("HUD"), TEXT("GrenadeAimHint"),
			TEXT("رها کنید تا پرتاب شود"), TEXT("Release to throw"));
		const FString Danger = SquadAIHUDLocal(this, TEXT("HUD"), TEXT("GrenadeAimDanger"),
			TEXT("دشمن داخل شعاع انفجار"), TEXT("ENEMY INSIDE BLAST"));
		const int32 Metres = FMath::RoundToInt(FVector::Dist(PlayerPawn->GetActorLocation(), Impact) / 100.f);
		// One literal per language: UE 5.4+ type-checks Printf formats at compile time, so
		// the format may never be a variable (C2664 - the lint caught this build of it).
		const FString Stats = SquadAIHUDIsEnglish(this)
			? FString::Printf(TEXT("%d m  |  boom %.1f s  |  %d bounce(s)"),
				Metres, GrenadePreviewResult.DetonationTime, GrenadePreviewResult.BounceCount)
			: FString::Printf(TEXT("%d متر  |  انفجار %.1f ثانیه  |  %d پرش"),
				Metres, GrenadePreviewResult.DetonationTime, GrenadePreviewResult.BounceCount);
		const FString TypeName = (PreviewType == EGrenadeType::SmokeScreen)
			? SquadAIHUDLocal(this, TEXT("HUD"), TEXT("GrenadeSmoke"), TEXT("دودزا"), TEXT("SMOKE"))
			: SquadAIHUDLocal(this, TEXT("HUD"), TEXT("GrenadeFrag"), TEXT("ترکش‌زا"), TEXT("FRAG"));

		const float PanelW = 268.f * S;
		const float PanelH = 74.f * S;
		const float PX = (Canvas->ClipX - PanelW) * 0.5f;
		const float PY = Canvas->ClipY * 0.78f;

		FLinearColor Accent = bEnemyInBlast ? GrenadeDangerTintColor : GrenadeImpactRingColor;
		DrawTacticalPlate3D(PX, PY, PanelW, PanelH,
			FLinearColor(0.06f, 0.07f, 0.07f, 0.86f * Alpha),
			FLinearColor(0.02f, 0.03f, 0.03f, 0.90f * Alpha),
			Accent, Alpha, 8.f * S, 2.f * S, 3.f * S);

		DrawFarsiTextBounded(FString::Printf(TEXT("%s  %s"), *TypeName, *Title),
			FLinearColor(1.f, 0.94f, 0.80f, Alpha), PX + 12.f * S, PY + 8.f * S,
			PanelW - 24.f * S, Font, 0.86f * S, true, false);
		DrawFarsiTextBounded(Hint, Accent, PX + 12.f * S, PY + 28.f * S,
			PanelW - 24.f * S, Font, 0.80f * S, true, false);
		DrawFarsiTextBounded(Stats, FLinearColor(0.82f, 0.86f, 0.88f, Alpha),
			PX + 12.f * S, PY + 48.f * S, PanelW - 24.f * S, Font, 0.72f * S, true, false);

		if (bEnemyInBlast)
		{
			// Blink the warning so it reads as a warning at a glance.
			FLinearColor Warn = GrenadeDangerTintColor;
			Warn.A *= Alpha * (0.55f + 0.45f * Pulse);
			DrawFarsiTextBounded(Danger, Warn, PX + 12.f * S, PY - 20.f * S,
				PanelW - 24.f * S, Font, 0.78f * S, true, false);
		}
	}
}

// ==========================================================================
//  S19-UI3D: bevelled panel primitives
//  The tutorial panels were flat rectangles with a single hard drop shadow,
//  which is what made them read as "developer UI" rather than as part of the
//  game. These draw a plate with a graded shadow, a smooth body gradient and
//  a real emboss, plus the raised keycap glyphs COD/BF use for prompts.
// ==========================================================================
void AQuestNativeHUD::DrawCornerBrackets(float X, float Y, float W, float H,
	const FLinearColor& Color, float ArmLen, float Thickness)
{
	if (!Canvas || W <= 0.f || H <= 0.f || Color.A <= 0.001f)
	{
		return;
	}
	const float L = FMath::Max(2.f, FMath::Min(ArmLen, FMath::Min(W, H) * 0.45f));
	const float T = FMath::Max(1.f, Thickness);

	// top-left
	DrawRect(Color, X, Y, L, T);
	DrawRect(Color, X, Y, T, L);
	// top-right
	DrawRect(Color, X + W - L, Y, L, T);
	DrawRect(Color, X + W - T, Y, T, L);
	// bottom-left
	DrawRect(Color, X, Y + H - T, L, T);
	DrawRect(Color, X, Y + H - L, T, L);
	// bottom-right
	DrawRect(Color, X + W - L, Y + H - T, L, T);
	DrawRect(Color, X + W - T, Y + H - L, T, L);
}

void AQuestNativeHUD::DrawTacticalPlate3D(float X, float Y, float W, float H,
	const FLinearColor& BodyTop, const FLinearColor& BodyBottom,
	const FLinearColor& Accent, float Alpha, float Chamfer, float Bevel, float Shadow)
{
	if (!Canvas || W <= 0.f || H <= 0.f || Alpha <= 0.001f)
	{
		return;
	}

	const float C = FMath::Clamp(Chamfer, 1.f, FMath::Min(W, H) * 0.35f);
	const float Sh = FMath::Max(0.f, Shadow);

	// ---- 1. graded drop shadow: three passes, wider and fainter each time.
	// One hard offset rect is what makes a panel look pasted on.
	if (Sh > 0.5f)
	{
		const float ShadowAlpha = 0.30f * Alpha;
		DrawRect(FLinearColor(0.f, 0.f, 0.f, ShadowAlpha * 0.35f),
			X + Sh * 0.75f, Y + Sh * 0.75f, W, H);
		DrawRect(FLinearColor(0.f, 0.f, 0.f, ShadowAlpha * 0.30f),
			X + Sh * 0.45f, Y + Sh * 0.45f, W, H);
		DrawRect(FLinearColor(0.f, 0.f, 0.f, ShadowAlpha * 0.35f),
			X + Sh * 0.20f, Y + Sh * 0.20f, W, H);
	}

	// ---- 2. body: smooth vertical gradient, inset so the chamfer is visible.
	// Drawn as strips rather than one rect so the lighting reads as a surface.
	{
		constexpr int32 Steps = 10;
		const float Inset = C * 0.55f;
		const float BodyH = FMath::Max(1.f, H - Inset * 2.f);
		const float Strip = BodyH / static_cast<float>(Steps);
		for (int32 i = 0; i < Steps; ++i)
		{
			const float T = static_cast<float>(i) / static_cast<float>(Steps - 1);
			FLinearColor C0 = FMath::Lerp(BodyTop, BodyBottom, T);
			C0.A *= Alpha;
			DrawRect(C0, X + Inset, Y + Inset + i * Strip, W - Inset * 2.f, Strip + 0.5f);
		}
	}

	// ---- 3. emboss: light along the top + left, dark along the bottom + right.
	{
		const float B = FMath::Max(0.5f, Bevel);
		// S19-UIBEVEL: the old emboss used a FIXED alpha, so asking for a thicker
		// bevel only made a wider flat band - it never looked any more raised.
		// Scale the contrast with the requested thickness so "heavy" actually
		// reads as heavy.
		const float Weight = FMath::Clamp(B / 1.6f, 0.6f, 2.6f);
		FLinearColor Lit = FLinearColor(1.f, 1.f, 1.f, FMath::Clamp(0.13f * Weight, 0.f, 0.42f) * Alpha);
		FLinearColor Dim = FLinearColor(0.f, 0.f, 0.f, FMath::Clamp(0.28f * Weight, 0.f, 0.58f) * Alpha);

		DrawRect(Lit, X + C, Y + 0.5f, W - C * 2.f, B);              // top
		DrawRect(Lit, X + 0.5f, Y + C, B, H - C * 2.f);              // left
		DrawRect(Dim, X + C, Y + H - B - 0.5f, W - C * 2.f, B);      // bottom
		DrawRect(Dim, X + W - B - 0.5f, Y + C, B, H - C * 2.f);      // right

		// S19-UIBEVEL: second step under the lit edge. Real chamfered metal
		// catches light twice - once on the chamfer face, once on the flat top.
		// One band alone always reads as a painted border.
		if (B > 1.2f)
		{
			const float Inner = B * 0.45f;
			FLinearColor Lit2 = FLinearColor(1.f, 1.f, 1.f, FMath::Clamp(0.07f * Weight, 0.f, 0.22f) * Alpha);
			FLinearColor Dim2 = FLinearColor(0.f, 0.f, 0.f, FMath::Clamp(0.16f * Weight, 0.f, 0.34f) * Alpha);
			DrawRect(Lit2, X + C + B, Y + 0.5f + B, W - (C + B) * 2.f, Inner);
			DrawRect(Lit2, X + 0.5f + B, Y + C + B, Inner, H - (C + B) * 2.f);
			DrawRect(Dim2, X + C + B, Y + H - B - Inner - 0.5f, W - (C + B) * 2.f, Inner);
			DrawRect(Dim2, X + W - B - Inner - 0.5f, Y + C + B, Inner, H - (C + B) * 2.f);
		}
	}

	// ---- 4. mitred border -------------------------------------------------
	{
		const FLinearColor Edge = FLinearColor(Accent.R, Accent.G, Accent.B, 0.85f * Alpha);
		const float T = FMath::Max(1.f, Bevel * 0.9f);
		DrawLine(X + C, Y, X + W - C, Y, Edge, T);
		DrawLine(X + W, Y + C, X + W, Y + H - C, Edge, T);
		DrawLine(X + W - C, Y + H, X + C, Y + H, Edge, T);
		DrawLine(X, Y + H - C, X, Y + C, Edge, T);
		// mitres
		DrawLine(X, Y + C, X + C, Y, Edge, T);
		DrawLine(X + W - C, Y, X + W, Y + C, Edge, T);
		DrawLine(X + W, Y + H - C, X + W - C, Y + H, Edge, T);
		DrawLine(X + C, Y + H, X, Y + H - C, Edge, T);
	}

	// ---- 5. accent bar down the leading edge, with a soft bleed -----------
	{
		const float BarW = FMath::Max(2.f, Bevel * 1.6f);
		FLinearColor Bar = Accent; Bar.A = 0.95f * Alpha;
		FLinearColor Bleed = Accent; Bleed.A = 0.16f * Alpha;
		DrawRect(Bleed, X, Y + C, BarW * 3.f, H - C * 2.f);
		DrawRect(Bar, X, Y + C, BarW, H - C * 2.f);
	}
}

float AQuestNativeHUD::DrawKeycapGlyph(float X, float Y, float H, const FString& Label,
	UFont* Font, const FLinearColor& Tint, bool bHeld)
{
	if (!Canvas) return 0.f;

	const float W = MeasureKeycapGlyphW(Label, H);
	const float YOff = bHeld ? 1.f : 0.f;
	const float S = GameUIScale;

	// Matches <kbd> in index.html:
	// border-radius: 3px; border: 1px solid #b8a78b88; background: linear-gradient(145deg, #4d4c46, #1c1e1b);
	// box-shadow: inset 0 1px #fff5, 0 1px 2px #000; color: #ffd18d; font-size: 9px;
	Draw9SliceRoundedBox(X, Y + YOff, W, H,
		bHeld ? FName(TEXT("SlotActive")) : FName(TEXT("VitalsTile")),
		0.96f, S, 0.45f, false, 0.f);

	if (Font)
	{
		const FString DisplayLbl = Label.StartsWith(TEXT("[")) ? Label : FString::Printf(TEXT("[%s]"), *Label);
		const float NormalScale = (H / 18.0f) * 0.52f;
		const FLinearColor TxtCol = bHeld ? FSquadAIHUDPalette::DarkInk() : FSquadAIHUDPalette::GoldText();
		DrawFarsiTextBounded(DisplayLbl, TxtCol,
			X + 2.f, Y + YOff, FMath::Max(6.f, W - 4.f), Font, NormalScale, false, true, H);
	}
	return W;
}

void AQuestNativeHUD::DrawKeycapGlyphRow(float X, float Y, float H, const FString& Hint,
	UFont* Font, const FLinearColor& Tint, float MaxWidth)
{
	if (!Canvas || Hint.IsEmpty())
	{
		return;
	}

	// Split on whitespace. Tokens wrapped in [ ] become caps; anything else is
	// drawn as plain label text between them.
	TArray<FString> Tokens;
	Hint.ParseIntoArray(Tokens, TEXT(" "), true);

	float Cursor = X;
	for (const FString& Tok : Tokens)
	{
		if (Cursor - X > MaxWidth)
		{
			return; // out of room - drop the rest rather than run off the panel
		}

		FString Cap = Tok;
		const bool bBracketed = Cap.StartsWith(TEXT("[")) && Cap.EndsWith(TEXT("]"));
		if (bBracketed)
		{
			Cap = Cap.Mid(1, Cap.Len() - 2);
		}

		if (bBracketed || Cap.Len() <= 3)
		{
			Cursor += DrawKeycapGlyph(Cursor, Y, H, Cap, Font, Tint, false) + H * 0.25f;
		}
		else if (Font)
		{
			// S26-FIXUI: this width used to be GUESSED from the character count.
			// Farsi glyphs are wider than chars * 0.40 * H, so labels either got
			// crushed to fit a box that never held them (tiny, ugly text) or ran
			// past their keycap. Measure the shaped text and use what it needs.
			float TextW = 0.f, TextH = 0.f;
			GetFarsiTextSize(Cap, Font, H * 0.40f, TextW, TextH);
			if (TextW <= 0.f)
				{
				TextW = Cap.Len() * H * 0.40f;
				}
			DrawFarsiTextBounded(Cap, FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::TextWhite(), 0.95f),
				Cursor, Y + H * 0.16f, TextW + H * 0.35f, Font, H * 0.40f, true, false, H * 0.7f);
			Cursor += TextW + H * 0.30f;
		}
	}
}

// ===== S18-TUT =====
void AQuestNativeHUD::RegisterTutorialUIRect(FName ElementId, float X, float Y, float W, float H)
{
	TutorialUIRects.Add(ElementId, FVector4(X, Y, W, H));
}

namespace
{
	// S18-TUT4: AAA games draw inputs as keycaps, not as the word "Space".
	// Dark rounded cap, light border, label centred. Returns the width used.
	struct FKeycapStyle
	{
		FLinearColor Fill  = FLinearColor(0.07f, 0.09f, 0.12f, 0.95f);
		FLinearColor Edge  = FLinearColor(0.92f, 0.88f, 0.72f, 0.95f);
		FLinearColor Text  = FLinearColor(1.0f, 0.95f, 0.78f, 1.0f);
	};
}

float AQuestNativeHUD::DrawKeycap(float X, float Y, const FString& Label, float S, UFont* Font, float Height)
{
	// Width follows the label so "LMB" and "W" both look deliberate.
	// S26-FIXUI: MEASURED, not guessed - the old chars * 8.5 * S estimate let
	// wide labels run past the cap edge.
	const float Pad = 9.f * S;
	float LabelW = 0.f, LabelH = 0.f;
	if (Font)
	{
		GetFarsiTextSize(Label, Font, 0.74f * S, LabelW, LabelH);
	}
	if (LabelW <= 0.f)
	{
		LabelW = Label.Len() * 8.5f * S;
	}
	const float W = FMath::Max(Height, LabelW + Pad * 2.f);

	const FKeycapStyle St;
	DrawRect(FLinearColor(0.f, 0.f, 0.f, 0.55f), X + 1.5f * S, Y + 2.0f * S, W, Height); // drop shadow
	DrawChiseledTacticalBox(X, Y, W, Height, St.Fill, St.Edge, 1.2f * S, 4.f * S);
	// Top highlight line: makes it read as a physical key.
	DrawRect(FLinearColor(1.f, 1.f, 1.f, 0.10f), X + 3.f * S, Y + 2.f * S, W - 6.f * S, 1.5f * S);
	DrawFarsiTextBounded(Label, St.Text, X, Y, W, Font, 0.74f * S, true, true, Height);
	return W;
}

UTexture2D* AQuestNativeHUD::GetTutorialIllustration(FName Key) const
{
	// S18-TUT: cached soft load. A missing asset caches nullptr so we only try once.
	if (Key.IsNone())
	{
		return nullptr;
	}
	if (TObjectPtr<UTexture2D>* Found = TutorialIllustrations.Find(Key))
	{
		return Found->Get();
	}
	const FString Name = FString::Printf(TEXT("T_Tut_%s"), *Key.ToString());
	const FString Path = FString::Printf(TEXT("/Game/SquadAI/UI/Tutorial/%s.%s"), *Name, *Name);
	// S26-TUTART: the imported asset first, then the loose PNG in the project's
	// Content folder - the same LoadTextureSafe pattern the prop textures use,
	// so shipping T_Tut_*.png files needs no editor import step at all.
	UTexture2D* Tex = FSquadAIAssetHelper::LoadTextureSafe(*Path,
		*FString::Printf(TEXT("SquadAI/UI/Tutorial/%s.png"), *Name));
	TutorialIllustrations.Add(Key, Tex);
	UE_LOG(LogTemp, Log, TEXT("[S18-TUT] Illustration '%s' -> %s"), *Path, Tex ? TEXT("loaded") : TEXT("MISSING (card draws text only)"));
	return Tex;
}

UTexture2D* AQuestNativeHUD::GetUITexture(FName Key) const
{
	// S26-TUT3D / S27-REFUI: cached soft load for UI surface materials & 3D icons.
	// Checks imported asset first, then SquadAI/UI/T_UI_<Key>.png, then SquadAI/UI/<Key>.png.
	if (Key.IsNone())
	{
		return nullptr;
	}
	if (TObjectPtr<UTexture2D>* Found = UITextureCache.Find(Key))
	{
		if (!Found->Get() || IsValid(Found->Get()))
		{
			return Found->Get();
		}
	}
	const FString KeyStr = Key.ToString();
	const FString Name = KeyStr.StartsWith(TEXT("T_UI_")) ? KeyStr : FString::Printf(TEXT("T_UI_%s"), *KeyStr);
	const FString Path = FString::Printf(TEXT("/Game/SquadAI/UI/%s.%s"), *Name, *Name);
	UTexture2D* Tex = FSquadAIAssetHelper::LoadTextureSafe(*Path,
		*FString::Printf(TEXT("SquadAI/UI/%s.png"), *Name));
	if (!Tex)
	{
		Tex = FSquadAIAssetHelper::LoadTextureSafe(*Path,
			*FString::Printf(TEXT("SquadAI/UI/%s.png"), *KeyStr));
	}
	UITextureCache.Add(Key, Tex);
	return Tex;
}

void AQuestNativeHUD::DrawAsymmetricCornerBrackets(float X, float Y, float W, float H, float S, float Alpha)
{
	if (!Canvas || W <= 16.f || H <= 16.f || Alpha <= 0.001f)
	{
		return;
	}
	// Matches .glass in index.html (with border-radius: 8px and overflow: hidden):
	// Top-Left corner: 19x19px (2px thick) warm amber (#f2a64b)
	// Top-Right, Bottom-Right, Bottom-Left corners: 15x15px (2px thick) metallic sand-taupe (#a9a395)
	// Each bracket hugs the 8px rounded corner curve so no sharp 90-degree spike sticks outside the curve.
	const float RX = FMath::RoundToFloat(X);
	const float RY = FMath::RoundToFloat(Y);
	const float RW = FMath::RoundToFloat(W);
	const float RH = FMath::RoundToFloat(H);

	const float ArmTL = FMath::Min(19.f * S, FMath::Min(RW, RH) * 0.45f);
	const float ArmOther = FMath::Min(15.f * S, FMath::Min(RW, RH) * 0.40f);
	const float T = FMath::Max(1.5f, 2.0f * S);
	const float C = FMath::RoundToFloat(5.0f * S);

	const FLinearColor AmberTL = FSquadAIHUDPalette::SRGB(242, 166, 75, Alpha);
	const FLinearColor Taupe   = FSquadAIHUDPalette::SRGB(169, 163, 149, 0.90f * Alpha);

	// Top-Left (Amber, hugging rounded corner)
	DrawRect(AmberTL, RX + C, RY, ArmTL - C, T);
	DrawRect(AmberTL, RX, RY + C, T, ArmTL - C);
	DrawLine(RX + 1.f * S, RY + C, RX + C, RY + 1.f * S, AmberTL, T);

	// Top-Right (Taupe, hugging rounded corner)
	DrawRect(Taupe, RX + RW - ArmOther, RY, ArmOther - C, T);
	DrawRect(Taupe, RX + RW - T, RY + C, T, ArmOther - C);
	DrawLine(RX + RW - C, RY + 1.f * S, RX + RW - 1.f * S, RY + C, Taupe, T);

	// Bottom-Right (Taupe, hugging rounded corner)
	DrawRect(Taupe, RX + RW - ArmOther, RY + RH - T, ArmOther - C, T);
	DrawRect(Taupe, RX + RW - T, RY + RH - ArmOther, T, ArmOther - C);
	DrawLine(RX + RW - C, RY + RH - 1.f * S, RX + RW - 1.f * S, RY + RH - C, Taupe, T);

	// Bottom-Left (Taupe, hugging rounded corner)
	DrawRect(Taupe, RX + C, RY + RH - T, ArmOther - C, T);
	DrawRect(Taupe, RX, RY + RH - ArmOther, T, ArmOther - C);
	DrawLine(RX + 1.f * S, RY + RH - C, RX + C, RY + RH - 1.f * S, Taupe, T);
}

void AQuestNativeHUD::DrawMachinedMetalTile(float X, float Y, float W, float H, bool bCurrent, float Alpha, float S, bool bLeadingAmberBar)
{
	if (!Canvas || W <= 0.f || H <= 0.f || Alpha <= 0.001f)
	{
		return;
	}

	// S27-REFUI: Raised 9-slice rounded-bevel choice tile (.step / .mini in index.html: border-radius: 6px).
	// The parent container (.tutorial / .training-panel) is more transparent (0.60),
	// while each inner choice box is MORE SOLID (0.94-0.98) with a 3D machined bevel and inner recessed keyline.
	const float TileAlpha = FMath::Clamp(Alpha * 1.12f, 0.f, 0.98f);

	Draw9SliceRoundedBox(X, Y, W, H,
		bCurrent ? FName(TEXT("StepTileCurrent")) : FName(TEXT("StepTile")),
		TileAlpha, S, 0.75f, false, 0.f);

	if (bLeadingAmberBar)
	{
		// Matches .step.current:after in index.html line 130 & 186:
		// position: absolute; inset-inline-start: 0; top: 5px; bottom: 5px; width: 3px; border-radius: 2px;
		// background: linear-gradient(180deg, #ffd58c, #ee8e35 50%, #9e4b1e)
		const float BarW = bCurrent ? (3.0f * S) : (2.0f * S);
		const float BarX = SquadAIHUDIsEnglish(this) ? (X + 1.f * S) : (X + W - BarW - 1.f * S);
		const float BarY = Y + 5.f * S;
		const float BarH = FMath::Max(4.f * S, H - 10.f * S);
		DrawRect(FSquadAIHUDPalette::SRGB(255, 213, 140, 0.96f * Alpha), BarX, BarY, BarW, BarH * 0.34f);
		DrawRect(FSquadAIHUDPalette::SRGB(238, 142, 53,  0.96f * Alpha), BarX, BarY + BarH * 0.34f, BarW, BarH * 0.33f);
		DrawRect(FSquadAIHUDPalette::SRGB(158, 75,  30,  0.96f * Alpha), BarX, BarY + BarH * 0.67f, BarW, BarH * 0.33f);
	}
}

void AQuestNativeHUD::Draw3DRaisedMedallion(float CX, float CY, float R, const FString& Label, bool bCurrent, bool bCompleted, float Alpha, float S, UFont* Font)
{
	if (!Canvas || R <= 0.f || Alpha <= 0.001f)
	{
		return;
	}

	const FName MedKey = bCurrent
		? FName(TEXT("MedallionActive"))
		: (bCompleted ? FName(TEXT("MedallionDone")) : FName(TEXT("MedallionIdle")));
	if (UTexture2D* MedTex = GetUITexture(MedKey))
	{
		// Our 128x128 medallion textures include a 4px outer glow/shadow margin around the 32x32 (r=16) circle (40/32 = 1.25x)
		const float DrawR = R * 1.24f;
		DrawTexture(MedTex, CX - DrawR, CY - DrawR, DrawR * 2.f, DrawR * 2.f, 0.f, 0.f, 1.f, 1.f, FLinearColor(1.f, 1.f, 1.f, Alpha));
	}
	else
	{
		DrawFilledCircleArea(FSquadAIHUDPalette::SRGB(35, 39, 36, 0.94f * Alpha), CX, CY, R);
	}

	const FLinearColor LblCol = bCurrent
		? FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::GoldText(), Alpha)
		: (bCompleted ? FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::SuccessText(), Alpha)
		              : FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::TextWhite(), 0.95f * Alpha));
	DrawFarsiTextBounded(Label, LblCol, CX - R, CY - R, R * 2.f, Font, 0.72f * S, true, true, R * 2.f);
}

void AQuestNativeHUD::Draw3DRaisedAmberButton(float X, float Y, float W, float H, const FString& Label, bool bHovered, float Alpha, float S, UFont* Font)
{
	if (!Canvas || W <= 0.f || H <= 0.f || Alpha <= 0.001f)
	{
		return;
	}
	// Matches .focus-bottom .next in index.html line 142:
	// border-radius: 5px; border: 1px solid #ffd389; background: linear-gradient(180deg, #ffe3a8 0%, #f0ad52 38%, #c96e22 100%);
	// box-shadow: inset 0 1px #fff, inset 0 -2px #6b3512, 0 2px 6px #000a; color: #21170f;
	Draw9SliceRoundedBox(X, Y, W, H, FName(TEXT("SlotActive")), FMath::Clamp(Alpha * (bHovered ? 1.0f : 0.98f), 0.f, 1.f), S, 0.65f, false, 0.f);
	if (bHovered)
	{
		DrawRect(FSquadAIHUDPalette::SRGB(255, 240, 200, 0.14f * Alpha), X + 3.f * S, Y + 2.f * S, W - 6.f * S, H - 4.f * S);
	}

	const FLinearColor DarkInk = FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::DarkInk(), Alpha);
	DrawFarsiTextBounded(Label, DarkInk, X + 6.f * S, Y, W - 12.f * S, Font, 0.66f * S, false, true, H);
}

void AQuestNativeHUD::DrawRecessedSegmentedMeter(float X, float Y, float W, float H, float Pct, bool bIsArmor, float Alpha, float S)
{
	if (!Canvas || W <= 0.f || H <= 0.f || Alpha <= 0.001f)
	{
		return;
	}
	DrawRect(FSquadAIHUDPalette::SRGB(12, 15, 14, 0.95f * Alpha), X, Y, W, H);
	DrawCleanPanelBorder(X, Y, W, H,
		FSquadAIHUDPalette::SRGB(7, 9, 8, 0.90f * Alpha),
		FSquadAIHUDPalette::SRGB(0, 0, 0, 0.70f * Alpha),
		FSquadAIHUDPalette::SRGB(255, 255, 255, 0.20f * Alpha), S);

	const float Clamped = FMath::Clamp(Pct, 0.f, 1.f);
	const float FillW = (W - 2.f * S) * Clamped;
	if (FillW > 1.f)
	{
		const float FX = X + 1.f * S;
		const float FY = Y + 1.f * S;
		const float FH = FMath::Max(2.f, H - 2.f * S);
		if (!bIsArmor)
		{
			DrawRect(FSquadAIHUDPalette::SRGB(121, 217, 110, 0.96f * Alpha), FX, FY, FillW, FH * 0.55f);
			DrawRect(FSquadAIHUDPalette::SRGB(53, 165, 61, 0.96f * Alpha), FX, FY + FH * 0.55f, FillW, FH * 0.45f);
			DrawRect(FSquadAIHUDPalette::SRGB(224, 255, 198, 0.75f * Alpha), FX, FY, FillW, 1.0f);
		}
		else
		{
			DrawRect(FSquadAIHUDPalette::SRGB(98, 200, 240, 0.96f * Alpha), FX, FY, FillW, FH * 0.55f);
			DrawRect(FSquadAIHUDPalette::SRGB(24, 131, 180, 0.96f * Alpha), FX, FY + FH * 0.55f, FillW, FH * 0.45f);
			DrawRect(FSquadAIHUDPalette::SRGB(216, 247, 255, 0.75f * Alpha), FX, FY, FillW, 1.0f);
		}
	}

	for (float SegX = X + 14.f * S; SegX < X + W - 3.f * S; SegX += 14.f * S)
	{
		DrawRect(FSquadAIHUDPalette::SRGB(6, 8, 8, 0.68f * Alpha), SegX, Y + 1.f, 1.5f * S, H - 2.f);
	}
}

void AQuestNativeHUD::DrawBigKeycap3D(float X, float Y, float W, float H, const FString& KeyLabel, bool bHeld, float Alpha, float S, UFont* Font)
{
	if (!Canvas || W <= 0.f || H <= 0.f || Alpha <= 0.001f)
	{
		return;
	}
	const float OffY = bHeld ? 2.f * S : 0.f;

	if (UTexture2D* KeyTex = GetUITexture(FName(TEXT("KeycapFrame"))))
	{
		DrawTexture(KeyTex, X, Y + OffY, W, H, 0.f, 0.f, 1.f, 1.f, FLinearColor(1.f, 1.f, 1.f, Alpha));
	}
	else
	{
		DrawMachinedMetalTile(X, Y + OffY, W, H, true, Alpha, S, false);
	}

	// .bigkey:after bottom amber underline glow (left: 9px; right: 9px; bottom: 4px; height: 2px; background: #f2a24b; box-shadow: 0 0 6px #f2a24b)
	DrawRect(FSquadAIHUDPalette::SRGB(242, 162, 75, 0.28f * Alpha), X + 7.f * S, Y + OffY + H - 6.5f * S, W - 14.f * S, 5.0f * S);
	DrawRect(FSquadAIHUDPalette::SRGB(242, 162, 75, 0.96f * Alpha), X + 9.f * S, Y + OffY + H - 5.f * S, W - 18.f * S, 2.0f * S);

	const float FontScale = (KeyLabel.Len() <= 1) ? (1.22f * S) : (0.78f * S);
	DrawFarsiText3D(KeyLabel, FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::TextWhite(), Alpha),
		X + 6.f * S, Y + OffY + 4.f * S, W - 12.f * S, Font, FontScale, true, false, H - 12.f * S, 1.2f * S);
}

void AQuestNativeHUD::DrawOperationBanner(float X, float Y, float W, float H, float ProgressPct, bool bEnglish, float Alpha, float S, UFont* Font)
{
	if (!Canvas || W <= 0.f || H <= 0.f || Alpha <= 0.001f)
	{
		return;
	}
	// Matches .operation-banner in index.html lines 113-124 (border-radius: 8px, 3D inner bevel, inset: 3px keyline)
	Draw9SliceRoundedBox(X, Y, W, H, FName(TEXT("OpBanner")), Alpha * 0.92f, S, 1.0f, true, 0.88f);
	DrawAsymmetricCornerBrackets(X, Y, W, H, S, Alpha);

	// 2px vertical amber bar on right edge (in RTL), inset 6px from top/bottom rounded corners
	const float BarX = bEnglish ? (X + 1.f * S) : (X + W - 3.0f * S);
	DrawRect(FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::BracketGold(), Alpha), BarX, Y + 6.f * S, 2.0f * S, H - 12.f * S);

	const float CrestW = 57.f * S;
	const float CrestH = 54.f * S;
	const float CrestX = bEnglish ? (X + 13.f * S) : (X + W - 13.f * S - CrestW);
	const float CrestY = Y + 10.f * S;
	if (UTexture2D* CrestTex = GetUITexture(FName(TEXT("TaskforceInsignia"))))
	{
		DrawTexture(CrestTex, CrestX, CrestY, CrestW, CrestH, 0.f, 0.f, 1.f, 1.f, FLinearColor(1.f, 1.f, 1.f, Alpha));
	}
	else
	{
		Draw3DRaisedMedallion(CrestX + CrestW * 0.5f, CrestY + CrestH * 0.5f, CrestH * 0.45f, TEXT("★"), true, false, Alpha, S, Font);
	}

	const float TextX = bEnglish ? (CrestX + CrestW + 10.f * S) : (X + 13.f * S);
	const float TextW = FMath::Max(100.f * S, bEnglish ? (X + W - 13.f * S - TextX) : (CrestX - 10.f * S - TextX));

	bool bTutActive = false;
	if (const USquadAITutorialSubsystem* TutSys = USquadAITutorialSubsystem::Get(this))
	{
		bTutActive = TutSys->IsTutorialActive();
	}

	FString Eyebrow = bEnglish ? TEXT("IRREGULAR WARFARE HQ // COMBAT TRAINING") : TEXT("ستاد جنگ‌های نامنظم // آموزش رزم");
	FString OpTitle = bEnglish ? TEXT("OPERATION: DEHLAVIEH LINE OF FIRE") : TEXT("عملیات: خط آتش دهلاویه");
	FString OpSub   = bEnglish ? TEXT("SECTOR: DEHLAVIEH & KARKHEH AXIS • COMBAT TUTORIAL") : TEXT("محور دهلاویه و رودخانه کرخه • آموزش رزمنده");

	if (!bTutActive)
	{
		Eyebrow = SquadAIHUDLocal(this, TEXT("MainMenu"), TEXT("Watermark"),
			TEXT("ستاد جنگ‌های نامنظم — سرگرد شهید ایرج رستمی"),
			TEXT("IRREGULAR WARFARE HQ — MAJOR SHAHID IRAJ ROSTAMI"));
		OpTitle = SquadAIHUDLocal(this, TEXT("MainMenu"), TEXT("GameTitle"),
			TEXT("دفاع مقدس: خط آتش دهلاویه"),
			TEXT("SACRED DEFENSE: DEHLAVIEH FIRE LINE"));
		const FString SectorName = SquadAIHUDLocal(this, TEXT("MapSelection"), TEXT("Map1_Title"),
			TEXT("محور دهلاویه و رودخانه کرخه"),
			TEXT("DEHLAVIEH & KARKHEH RIVER AXIS"));

		AQuestChain* Chain = FindQuestChain();
		const int32 TotalStg = (Chain && Chain->TotalMissionCount > 0) ? Chain->TotalMissionCount : 5;
		const int32 CurStg   = (Chain && Chain->CurrentMissionIndex >= 0)
			? FMath::Clamp(Chain->CurrentMissionIndex + 1, 1, TotalStg)
			: FMath::Clamp((Chain ? Chain->CompletedMissionCount : 0) + 1, 1, TotalStg);
		const FString StagePart = bEnglish
			? FString::Printf(TEXT("STAGE %d OF %d"), CurStg, TotalStg)
			: FString::Printf(TEXT("مرحله %s از %s"),
				*UFarsiTextHelper::ToPersianDigits(FString::FromInt(CurStg)),
				*UFarsiTextHelper::ToPersianDigits(FString::FromInt(TotalStg)));
		OpSub = SectorName + TEXT(" • ") + StagePart;

		if (Chain)
		{
			if (AMissionZone* ActiveMZ = Chain->GetCurrentMission())
			{
				if (!ActiveMZ->TitleCardPlace.IsEmpty())
				{
					const FString PlaceStr = ActiveMZ->TitleCardPlace.ToString();
					if (bEnglish || UFarsiTextHelper::ContainsFarsiCharacters(PlaceStr))
					{
						OpTitle = PlaceStr;
					}
				}
				if (!ActiveMZ->TitleCardUnit.IsEmpty())
				{
					const FString UnitStr = ActiveMZ->TitleCardUnit.ToString();
					if (bEnglish || UFarsiTextHelper::ContainsFarsiCharacters(UnitStr))
					{
						Eyebrow = UnitStr;
					}
				}
			}
		}
	}

	DrawFarsiText3D(Eyebrow, FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::GoldText(), Alpha),
		TextX, Y + 8.f * S, TextW, Font, 0.64f * S, false, !bEnglish, 16.f * S, 1.0f * S);

	DrawFarsiText3D(OpTitle, FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::TextWhite(), Alpha),
		TextX, Y + 25.f * S, TextW, Font, 1.12f * S, false, !bEnglish, 28.f * S, 1.2f * S);

	DrawFarsiTextBounded(OpSub, FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::TextDim(), Alpha),
		TextX, Y + 53.f * S, TextW, Font, 0.64f * S, true, false, 16.f * S, !bEnglish);

	const float ProgX = X + 13.f * S;
	const float ProgW = W - 26.f * S;
	const float ProgY = Y + H - 10.f * S;
	const float ProgH = 2.0f * S;
	DrawRect(FSquadAIHUDPalette::SRGB(255, 255, 255, 0.12f * Alpha), ProgX, ProgY, ProgW, ProgH);
	const float FillW = ProgW * FMath::Clamp(ProgressPct, 0.08f, 1.0f);
	const float FillX = bEnglish ? ProgX : (ProgX + ProgW - FillW);
	DrawRect(FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::BracketGold(), 0.28f * Alpha), FillX, ProgY - 1.f * S, FillW, ProgH + 2.f * S);
	DrawRect(FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::BracketGold(), Alpha), FillX, ProgY, FillW, ProgH);
}

void AQuestNativeHUD::DrawTutorialStepsPanel(float X, float Y, float W, int32 ActiveStageOneBased, bool bEnglish, float Alpha, float S, UFont* Font, float& OutBottomY)
{
	if (!Canvas || W <= 0.f || Alpha <= 0.001f)
	{
		OutBottomY = Y;
		return;
	}
	// Matches .tutorial in index.html:
	// MORE TRANSPARENT outer 9-slice rounded-bevel frosted-glass container (0.62 * Alpha) over blurred backdrop,
	// with 5 MORE SOLID 3D beveled .step choice boxes (border-radius: 6px) inside!
	const float Pad = 6.f * S;
	const float HeadH = 27.f * S;
	const float RowH = 54.f * S;
	const float RowGap = 5.f * S;
	const float TotalH = Pad + HeadH + 3.f * S + 5 * RowH + 4 * RowGap + Pad;

	Draw9SliceRoundedBox(X, Y, W, TotalH, FName(TEXT("GlassPanel")), Alpha * 0.62f, S, 1.0f, true, 0.80f);
	DrawAsymmetricCornerBrackets(X, Y, W, TotalH, S, 0.85f * Alpha);

	const float HX = X + Pad;
	const float HY = Y + Pad;
	const float HW = W - Pad * 2.f;

	// Subtle .panel-head fill (#12151452) + 1px bottom hairline (#ffffff14) matching index.html line 127
	DrawRect(FSquadAIHUDPalette::SRGB(18, 21, 20, 0.34f * Alpha), HX, HY, HW, HeadH - 1.f);
	DrawRect(FSquadAIHUDPalette::SRGB(255, 255, 255, 0.09f * Alpha), HX + 2.f * S, HY + HeadH - 1.f, HW - 4.f * S, 1.f);

	bool bTutActive = false;
	if (const USquadAITutorialSubsystem* TutSys = USquadAITutorialSubsystem::Get(this))
	{
		bTutActive = TutSys->IsTutorialActive();
	}
	AQuestChain* Chain = !bTutActive ? FindQuestChain() : nullptr;

	const int32 StageClamped = FMath::Clamp(ActiveStageOneBased, 1, 5);
	const FString HeadTitle = bTutActive
		? (bEnglish ? TEXT("TUTORIAL PROGRESS") : TEXT("روند آموزش"))
		: (bEnglish ? TEXT("MISSION SEQUENCE") : TEXT("روند ماموریت‌ها"));
	const FString HeadCount = bTutActive
		? (bEnglish
			? FString::Printf(TEXT("STEP %d OF 5"), StageClamped)
			: FString::Printf(TEXT("مرحله %s از ۵"), *UFarsiTextHelper::ToPersianDigits(FString::FromInt(StageClamped))))
		: (bEnglish
			? FString::Printf(TEXT("STAGE %d OF 5"), StageClamped)
			: FString::Printf(TEXT("مرحله %s از ۵"), *UFarsiTextHelper::ToPersianDigits(FString::FromInt(StageClamped))));

	if (bEnglish)
	{
		DrawFarsiText3D(HeadTitle, FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::TextWhite(), Alpha),
			HX + 6.f * S, HY, HW * 0.55f, Font, 0.76f * S, false, false, HeadH, 1.0f * S);
		DrawFarsiTextBounded(HeadCount, FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::TextDim(), Alpha),
			HX + HW * 0.52f, HY, HW * 0.48f - 6.f * S, Font, 0.62f * S, true, false, HeadH, true);
	}
	else
	{
		DrawFarsiText3D(HeadTitle, FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::TextWhite(), Alpha),
			HX + HW * 0.45f, HY, HW * 0.55f - 6.f * S, Font, 0.76f * S, false, true, HeadH, 1.0f * S);
		DrawFarsiTextBounded(HeadCount, FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::TextDim(), Alpha),
			HX + 6.f * S, HY, HW * 0.45f, Font, 0.62f * S, true, false, HeadH, false);
	}

	struct FStepRowDef
	{
		const TCHAR* IconKey;
		const TCHAR* NumFa;
		const TCHAR* NumEn;
		const TCHAR* TitleFa;
		const TCHAR* TitleEn;
		const TCHAR* SubFa;
		const TCHAR* SubEn;
	};
	static const FStepRowDef TutRows[5] = {
		{ TEXT("IconRunner3D"),        TEXT("۱"), TEXT("1"), TEXT("حرکت در سنگر"),          TEXT("TRENCH MOVEMENT"),    TEXT("با [WASD] پشت سر فرمانده در سنگر حرکت کنید"),       TEXT("Move along the trench boards behind the commander") },
		{ TEXT("ArmorShield3D"),       TEXT("۲"), TEXT("2"), TEXT("پناه‌گیری و وضعیت جوخه"), TEXT("COVER & SQUAD"),      TEXT("پشت کیسه شن پناه بگیرید و سلامت هم‌رزمان را بپایید"), TEXT("Take sandbag cover and monitor squad health") },
		{ TEXT("IconReticle3D"),       TEXT("۳"), TEXT("3"), TEXT("تیراندازی با ژ-۳"),       TEXT("G3A3 MARKSMANSHIP"),  TEXT("با مگسک آهنی نشانه بگیرید و ۳ قوطی خاکریز را بزنید"), TEXT("Aim down iron sights and shoot the 3 cans on the berm") },
		{ TEXT("IconFlag3D"),          TEXT("۴"), TEXT("4"), TEXT("پرتاب نارنجک در بشکه"),   TEXT("GRENADE ACCURACY"),   TEXT("با کلید [G] نارنجک را از دهانه باز داخل بشکه بیندازید"), TEXT("Arc a grenade through the open top of the drum") },
		{ TEXT("IconObjectiveFire3D"), TEXT("۵"), TEXT("5"), TEXT("درخواست آتش توپخانه"),    TEXT("CALL FOR FIRE"),      TEXT("موضع هدف را نشانه بگیرید و با [MMB] آتش خمپاره بخواهید"), TEXT("Mark target and call 120mm mortar fire with [MMB]") }
	};
	static const FStepRowDef MissionRows[5] = {
		{ TEXT("IconRunner3D"),        TEXT("۱"), TEXT("1"), TEXT("پیشروی در محور دهلاویه"),    TEXT("ADVANCE ON DEHLAVIEH"),   TEXT("حرکت با جوخه سرگرد رستمی تا خط اول سنگرهای دهلاویه"),  TEXT("Advance with Major Rostami's squad to forward trenches") },
		{ TEXT("IconReticle3D"),       TEXT("۲"), TEXT("2"), TEXT("حمله به خط سنگر و پاکسازی"), TEXT("TRENCH ASSAULT & CLEAR"), TEXT("انهدام سنگرهای تیربار دشمن و پاکسازی مواضع خط مقدم"), TEXT("Destroy enemy bunkers and clear forward trench line") },
		{ TEXT("ArmorShield3D"),       TEXT("۳"), TEXT("3"), TEXT("پدافند مقر فرماندهی"),       TEXT("HQ — HOLD THE LINE"),     TEXT("حفظ خط دفاعی دهلاویه و دفع موج‌های پاتک دشمن"),        TEXT("Hold the defensive line and repel enemy counterattacks") },
		{ TEXT("IconFlag3D"),          TEXT("۴"), TEXT("4"), TEXT("شناسایی و گشت نخلستان"),     TEXT("GROVE RECON & INTEL"),    TEXT("شناسایی مواضع دیده‌بان و جمع‌آوری اطلاعات عملیاتی"),    TEXT("Locate artillery spotters and gather tactical intel") },
		{ TEXT("IconObjectiveFire3D"), TEXT("۵"), TEXT("5"), TEXT("تثبیت معبر رودخانه کرخه"),   TEXT("KARKHEH CROSSING"),       TEXT("پاکسازی کامل محور کرخه و تامین منطقه تخلیه جوخه"),     TEXT("Secure the Karkheh river crossing and extraction zone") }
	};
	const FStepRowDef* Rows = bTutActive ? TutRows : MissionRows;

	float CurY = HY + HeadH + 3.f * S;
	for (int32 i = 0; i < 5; ++i)
	{
		const int32 StepNum = i + 1;
		bool bCur = (StepNum == StageClamped);
		bool bDone = (StepNum < StageClamped);
		AMissionZone* RowMZ = (!bTutActive && Chain && Chain->Missions.IsValidIndex(i)) ? Chain->Missions[i] : nullptr;
		if (!bTutActive && RowMZ)
		{
			if (RowMZ->IsCompleted())
			{
				bDone = true;
				bCur = false;
			}
			else if (RowMZ->IsActive())
			{
				bCur = true;
			}
		}

		DrawMachinedMetalTile(HX, CurY, HW, RowH, bCur, Alpha, S, bCur);

		const float IconSz = 26.f * S;
		const float IconX = bEnglish ? (HX + 8.f * S) : (HX + HW - 10.f * S - IconSz);
		const float IconY = CurY + (RowH - IconSz) * 0.5f;
		if (UTexture2D* STex = GetUITexture(FName(Rows[i].IconKey)))
		{
			DrawTexture(STex, IconX, IconY, IconSz, IconSz, 0.f, 0.f, 1.f, 1.f, FLinearColor(1.f, 1.f, 1.f, Alpha));
		}

		// Anti-aliased 3D Circular Step Number Medallion (.n: shows ✓ when completed, ۱..۵ otherwise)
		const float MedR = 15.f * S;
		const float MedCX = bEnglish ? (IconX + IconSz + 8.f * S + MedR) : (IconX - 8.f * S - MedR);
		const float MedCY = CurY + RowH * 0.5f;
		const FString NumLbl = bDone ? FString(TEXT("✓")) : FString(bEnglish ? Rows[i].NumEn : Rows[i].NumFa);
		Draw3DRaisedMedallion(MedCX, MedCY, MedR, NumLbl, bCur, bDone, Alpha, S, Font);

		float BadgeReserveW = 0.f;
		if (bCur || bDone)
		{
			const float BW = 68.f * S;
			const float BH = 16.f * S;
			const float BX = bEnglish ? (HX + HW - BW - 8.f * S) : (HX + 9.f * S);
			const float BY = CurY + 6.f * S;
			Draw9SliceRoundedBox(BX, BY, BW, BH, bCur ? FName(TEXT("StepTileCurrent")) : FName(TEXT("StepTile")), 0.88f * Alpha, S, 0.45f, false, 0.f);
			FString BadgeStr = bCur
				? (bEnglish ? TEXT("IN PROGRESS") : TEXT("در حال انجام"))
				: (bEnglish ? TEXT("COMPLETED") : TEXT("تکمیل شد"));
			if (bTutActive && bCur && StepNum == 3)
			{
				if (const USquadAITutorialSubsystem* TutSys = USquadAITutorialSubsystem::Get(this))
				{
					const int32 CansHit = FMath::Max(0, TutSys->GetCurrentProgress());
					if (CansHit > 0)
					{
						BadgeStr = bEnglish
							? FString::Printf(TEXT("%d / 3 CANS"), CansHit)
							: FString::Printf(TEXT("%s از ۳ هدف"), *UFarsiTextHelper::ToPersianDigits(FString::FromInt(CansHit)));
					}
				}
			}
			else if (!bTutActive && bCur && RowMZ)
			{
				if (RowMZ->MissionType == EMissionType::Defend && RowMZ->DefendTimeRemaining > 0.f)
				{
					BadgeStr = bEnglish
						? FString::Printf(TEXT("%02d:%02d"), FMath::CeilToInt(RowMZ->DefendTimeRemaining) / 60, FMath::CeilToInt(RowMZ->DefendTimeRemaining) % 60)
						: UFarsiTextHelper::FormatTimerPersian(RowMZ->DefendTimeRemaining);
				}
				else if (RowMZ->TotalEnemiesSpawned > 0)
				{
					const int32 Killed = FMath::Max(0, RowMZ->TotalEnemiesSpawned - RowMZ->AliveEnemies);
					BadgeStr = bEnglish
						? FString::Printf(TEXT("%d / %d HOSTILES"), Killed, RowMZ->TotalEnemiesSpawned)
						: FString::Printf(TEXT("%s از %s دشمن"),
							*UFarsiTextHelper::ToPersianDigits(FString::FromInt(Killed)),
							*UFarsiTextHelper::ToPersianDigits(FString::FromInt(RowMZ->TotalEnemiesSpawned)));
				}
			}
			const FLinearColor BadgeCol = bCur
				? FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::GoldText(), Alpha)
				: FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::SuccessText(), Alpha);
			DrawFarsiTextBounded(BadgeStr, BadgeCol,
				BX + 3.f * S, BY, BW - 6.f * S, Font, 0.50f * S, false, true, BH);
			BadgeReserveW = BW + 10.f * S;
		}

		FString RowTitleStr = bEnglish ? Rows[i].TitleEn : Rows[i].TitleFa;
		FString RowSubStr   = bEnglish ? Rows[i].SubEn   : Rows[i].SubFa;
		if (!bTutActive && RowMZ)
		{
			if (!RowMZ->MissionBriefingTitle.IsEmpty())
			{
				const FString BT = RowMZ->MissionBriefingTitle.ToString();
				if (bEnglish || UFarsiTextHelper::ContainsFarsiCharacters(BT)) RowTitleStr = BT;
			}
			if (!RowMZ->MissionDescription.IsEmpty())
			{
				const FString BD = RowMZ->MissionDescription.ToString();
				if (bEnglish || UFarsiTextHelper::ContainsFarsiCharacters(BD)) RowSubStr = BD;
			}
		}

		const float TX = bEnglish ? (MedCX + MedR + 10.f * S) : (HX + 10.f * S + BadgeReserveW);
		const float TW = FMath::Max(80.f * S, bEnglish ? (HX + HW - 10.f * S - BadgeReserveW - TX) : (MedCX - MedR - 10.f * S - TX));
		const float SubX = bEnglish ? TX : (HX + 10.f * S);
		const float SubW = bEnglish ? (HX + HW - 10.f * S - TX) : (MedCX - MedR - 10.f * S - SubX);
		DrawFarsiText3D(RowTitleStr,
			FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::TextWhite(), Alpha),
			TX, CurY + 6.f * S, TW, Font, 0.80f * S, false, !bEnglish, 20.f * S, 1.0f * S);
		DrawFarsiTextBounded(RowSubStr,
			FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::TextDim(), Alpha),
			SubX, CurY + 28.f * S, SubW, Font, 0.60f * S, true, false, 18.f * S, !bEnglish);

		CurY += RowH + RowGap;
	}

	OutBottomY = Y + TotalH;
}

void AQuestNativeHUD::DrawFocusInstructionCard(float X, float Y, float W, int32 ActiveStageOneBased, const FString& Title, const FString& Body,
	bool bEnglish, float Alpha, float S, UFont* Font, float MouseX, float MouseY, bool bLeftClick, bool& bOutContinueClicked, float& OutBottomY)
{
	bOutContinueClicked = false;
	if (!Canvas || W <= 0.f || Alpha <= 0.001f)
	{
		OutBottomY = Y;
		return;
	}

	bool bTutActive = false;
	if (const USquadAITutorialSubsystem* TutSys = USquadAITutorialSubsystem::Get(this))
	{
		bTutActive = TutSys->IsTutorialActive();
	}

	const float Pad = 11.f * S;
	const float TopRowH = 38.f * S;
	const float BotRowH = 34.f * S;
	const float InnerW = W - Pad * 2.f;

	const FTutorialTextBlock BodyBlock = WrapTutorialText(Body, Font, 0.68f * S, InnerW, 3);
	const float BodyH = FMath::Max(22.f * S, BodyBlock.BlockH);
	const float TotalH = TopRowH + 6.f * S + BodyH + 8.f * S + BotRowH;

	// Matches .focus-instruction in index.html lines 136-142 (border-radius: 8px, 3D inner bevel, inset: 3px keyline)
	Draw9SliceRoundedBox(X, Y, W, TotalH, FName(TEXT("FocusCard")), Alpha * 0.92f, S, 1.0f, true, 0.88f);
	DrawAsymmetricCornerBrackets(X, Y, W, TotalH, S, 0.92f * Alpha);

	const float BarX = bEnglish ? (X + 1.f * S) : (X + W - 3.5f * S);
	DrawRect(FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::BracketGold(), 0.92f * Alpha), BarX, Y + 6.f * S, 2.5f * S, TotalH - 12.f * S);

	const int32 StageClamped = FMath::Clamp(ActiveStageOneBased, 1, 5);

	// 1. Top row (.focus-top — filled 3D rotated .diamond + title + 9-slice rounded .progress-pill)
	const float DR = 12.f * S;
	const float DCX = bEnglish ? (X + Pad + 14.f * S) : (X + W - Pad - 14.f * S);
	const float DCY = Y + TopRowH * 0.5f + 2.f * S;
	// Fill rotated diamond interior (linear-gradient(145deg, #4b3119, #1f1711))
	const int32 DSteps = FMath::Max(6, FMath::RoundToInt(DR));
	for (int32 dy = -DSteps + 1; dy < DSteps; ++dy)
	{
		const float Frac = 1.0f - FMath::Abs(static_cast<float>(dy)) / static_cast<float>(DSteps);
		const float HalfW = Frac * (DR - 1.f * S);
		const FLinearColor FillC = (dy < 0)
			? FSquadAIHUDPalette::SRGB(68, 44, 22, 0.92f * Alpha)
			: FSquadAIHUDPalette::SRGB(31, 23, 17, 0.92f * Alpha);
		DrawRect(FillC, DCX - HalfW, DCY + dy * (DR / DSteps), HalfW * 2.f, (DR / DSteps) + 0.5f);
	}
	const FLinearColor DCol = FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::BracketGold(), 0.92f * Alpha);
	DrawLine(DCX, DCY - DR, DCX + DR, DCY, DCol, 1.5f * S);
	DrawLine(DCX + DR, DCY, DCX, DCY + DR, DCol, 1.5f * S);
	DrawLine(DCX, DCY + DR, DCX - DR, DCY, DCol, 1.5f * S);
	DrawLine(DCX - DR, DCY, DCX, DCY - DR, DCol, 1.5f * S);
	const FString Num02 = bEnglish
		? FString::Printf(TEXT("0%d"), StageClamped)
		: UFarsiTextHelper::ToPersianDigits(FString::Printf(TEXT("0%d"), StageClamped));
	DrawFarsiTextBounded(Num02, FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::GoldText(), Alpha),
		DCX - DR, DCY - DR, DR * 2.f, Font, 0.58f * S, false, true, DR * 2.f);

	const float PillW = 42.f * S, PillH = 18.f * S;
	const float PillX = bEnglish ? (X + W - Pad - PillW) : (X + Pad);
	const float PillY = Y + (TopRowH - PillH) * 0.5f + 2.f * S;
	Draw9SliceRoundedBox(PillX, PillY, PillW, PillH, FName(TEXT("StepTile")), 0.84f * Alpha, S, 0.45f, false, 0.f);
	const FString ProgPillTxt = bEnglish
		? FString::Printf(TEXT("%d / 5"), StageClamped)
		: FString::Printf(TEXT("%s / ۵"), *UFarsiTextHelper::ToPersianDigits(FString::FromInt(StageClamped)));
	DrawFarsiTextBounded(ProgPillTxt, FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::TextDim(), Alpha),
		PillX + 2.f * S, PillY, PillW - 4.f * S, Font, 0.54f * S, false, true, PillH);

	const float TitleX = bEnglish ? (DCX + DR + 10.f * S) : (PillX + PillW + 8.f * S);
	const float TitleW = FMath::Max(60.f * S, bEnglish ? (PillX - 8.f * S - TitleX) : (DCX - DR - 10.f * S - TitleX));
	const FString FocusEyebrow = bTutActive
		? (bEnglish ? TEXT("STEP GUIDE") : TEXT("راهنمای گام"))
		: (bEnglish ? TEXT("TACTICAL DIRECTIVE") : TEXT("فرمان عملیاتی"));
	DrawFarsiTextBounded(FocusEyebrow,
		FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::TextDim(), Alpha),
		TitleX, Y + 5.f * S, TitleW, Font, 0.52f * S, false, false, 13.f * S, !bEnglish);
	DrawFarsiText3D(Title, FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::TextWhite(), Alpha),
		TitleX, Y + 18.f * S, TitleW, Font, 0.76f * S, false, !bEnglish, 20.f * S, 1.0f * S);

	// .focus-top bottom separator line (index.html line 65: border-bottom: 1px solid #ffffff20)
	DrawRect(FSquadAIHUDPalette::SRGB(255, 255, 255, 0.125f * Alpha), X + Pad, Y + TopRowH + 1.f * S, InnerW, 1.f);

	// 2. Wrapped body paragraph
	DrawTutorialTextBlock(BodyBlock, FSquadAIHUDPalette::SRGB(221, 214, 202, Alpha),
		X + Pad, Y + TopRowH + 5.f * S, InnerW, Font, 0.68f * S);

	// 3. Bottom action bar (.focus-bottom: 1px subtle top border #ffffff1a)
	const float BotY = Y + TotalH - BotRowH;
	DrawRect(FSquadAIHUDPalette::SRGB(255, 255, 255, 0.10f * Alpha), X + Pad, BotY, InnerW, 1.f);

	const float BtnW = 92.f * S;
	const float BtnH = 24.f * S;
	const float BtnX = bEnglish ? (X + W - Pad - BtnW) : (X + Pad);
	const float BtnY = BotY + (BotRowH - BtnH) * 0.5f;

	if (bEnglish)
	{
		const float QCapH = 18.f * S;
		const float QCapW = DrawKeycapGlyph(X + Pad, BotY + (BotRowH - QCapH) * 0.5f, QCapH, TEXT("V"), Font, FSquadAIHUDPalette::GoldText(), false);
		DrawFarsiTextBounded(TEXT("Path guidance"),
			FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::TextDim(), Alpha),
			X + Pad + QCapW + 6.f * S, BotY, InnerW * 0.52f, Font, 0.56f * S, true, false, BotRowH);
	}
	else
	{
		// In RTL (index.html line 187: <span>علامت‌گذاری هدف <kbd>[Q]</kbd></span>):
		// Farsi text is on the right edge (X + W - Pad), and <kbd>[V]</kbd> sits immediately to its left!
		const FString GuideHint = TEXT("هدایت مسیر تا هدف");
		float HintW = 0.f, HintH = 0.f;
		GetFarsiTextSize(GuideHint, Font, 0.56f * S, HintW, HintH);
		HintW = FMath::Clamp(HintW, 72.f * S, 130.f * S);
		const float HintRightX = X + W - Pad;
		DrawFarsiTextBounded(GuideHint,
			FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::TextDim(), Alpha),
			HintRightX - HintW, BotY, HintW, Font, 0.56f * S, true, false, BotRowH, true);
		const float QCapH = 18.f * S;
		const float QCapW = MeasureKeycapGlyphW(TEXT("V"), QCapH);
		const float QCapX = FMath::Max(BtnX + BtnW + 6.f * S, HintRightX - HintW - QCapW - 5.f * S);
		DrawKeycapGlyph(QCapX, BotY + (BotRowH - QCapH) * 0.5f, QCapH, TEXT("V"), Font, FSquadAIHUDPalette::GoldText(), false);
	}

	const bool bHov = (MouseX >= BtnX && MouseX <= BtnX + BtnW && MouseY >= BtnY && MouseY <= BtnY + BtnH);
	const FString BtnText = bTutActive
		? (bEnglish ? TEXT("[F] CONTINUE ›") : TEXT("[F] ادامه ›"))
		: (bEnglish ? TEXT("[I] BACKPACK ›") : TEXT("[I] کوله‌پشتی ›"));
	Draw3DRaisedAmberButton(BtnX, BtnY, BtnW, BtnH,
		BtnText,
		bHov, Alpha, S, Font);

	if (bHov && bLeftClick)
	{
		bOutContinueClicked = true;
	}
	OutBottomY = Y + TotalH;
}

void AQuestNativeHUD::DrawTrainingProgressPanel(float X, float Y, float W, int32 ActiveStageOneBased, bool bEnglish, float Alpha, float S, UFont* Font)
{
	if (!Canvas || W <= 0.f || Alpha <= 0.001f)
	{
		return;
	}
	// Matches .training-panel in index.html:
	// MORE TRANSPARENT outer 9-slice rounded-bevel frosted-glass container (0.62 * Alpha) over blurred backdrop,
	// with 3 MORE SOLID 3D beveled .mini choice boxes (border-radius: 6px) showing ۱, ۲, ۳ on the right and "اکنون" on the left!
	const float Pad = 5.f * S;
	const float HeadH = 26.f * S;
	const float TileH = 36.f * S;
	const float TileGap = 4.f * S;
	const float TotalH = 158.f * S;

	Draw9SliceRoundedBox(X, Y, W, TotalH, FName(TEXT("GlassPanel")), Alpha * 0.62f, S, 1.0f, true, 0.80f);
	DrawAsymmetricCornerBrackets(X, Y, W, TotalH, S, 0.85f * Alpha);

	bool bTutActive = false;
	if (const USquadAITutorialSubsystem* TutSys = USquadAITutorialSubsystem::Get(this))
	{
		bTutActive = TutSys->IsTutorialActive();
	}
	AQuestChain* Chain = !bTutActive ? FindQuestChain() : nullptr;
	AMissionZone* CurMission = (Chain && Chain->bIsActive) ? Chain->GetCurrentMission() : nullptr;

	const int32 StageClamped = FMath::Clamp(ActiveStageOneBased, 1, 5);
	const float HX = X + Pad;
	const float HY = Y + Pad;
	const float HW = W - Pad * 2.f;

	// Subtle .panel-head fill (#12151452) + 1px bottom hairline (#ffffff14)
	DrawRect(FSquadAIHUDPalette::SRGB(18, 21, 20, 0.34f * Alpha), HX, HY, HW, HeadH - 1.f);
	DrawRect(FSquadAIHUDPalette::SRGB(255, 255, 255, 0.09f * Alpha), HX + 2.f * S, HY + HeadH - 1.f, HW - 4.f * S, 1.f);

	const FString PanelTitle = bTutActive
		? (bEnglish ? TEXT("TRAINING PROGRESS") : TEXT("پیشرفت آموزش"))
		: (bEnglish ? TEXT("MISSION PROGRESS") : TEXT("پیشرفت ماموریت"));
	const FString StepStr = bTutActive
		? (bEnglish
			? FString::Printf(TEXT("STEP %d OF 5"), StageClamped)
			: FString::Printf(TEXT("مرحله %s از ۵"), *UFarsiTextHelper::ToPersianDigits(FString::FromInt(StageClamped))))
		: (bEnglish
			? FString::Printf(TEXT("STAGE %d OF 5"), StageClamped)
			: FString::Printf(TEXT("مرحله %s از ۵"), *UFarsiTextHelper::ToPersianDigits(FString::FromInt(StageClamped))));
	if (bEnglish)
	{
		DrawFarsiText3D(PanelTitle,
			FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::TextWhite(), Alpha),
			HX + 6.f * S, HY, HW * 0.58f, Font, 0.66f * S, false, false, HeadH, 1.0f * S);
		DrawFarsiTextBounded(StepStr, FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::TextDim(), Alpha),
			HX + HW * 0.56f, HY, HW * 0.44f - 6.f * S, Font, 0.54f * S, true, false, HeadH, true);
	}
	else
	{
		DrawFarsiText3D(PanelTitle,
			FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::TextWhite(), Alpha),
			HX + HW * 0.42f, HY, HW * 0.58f - 6.f * S, Font, 0.66f * S, false, true, HeadH, 1.0f * S);
		DrawFarsiTextBounded(StepStr, FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::TextDim(), Alpha),
			HX + 6.f * S, HY, HW * 0.42f, Font, 0.54f * S, true, false, HeadH, false);
	}

	static const TCHAR* NumFa[3]   = { TEXT("۱"), TEXT("۲"), TEXT("۳") };
	static const TCHAR* NumEn[3]   = { TEXT("1"), TEXT("2"), TEXT("3") };
	static const TCHAR* TutTitleFa[3] = { TEXT("حرکت و پناه‌گیری در سنگر"), TEXT("تیراندازی به قوطی‌ها (۳ هدف)"), TEXT("پرتاب نارنجک و آتش خمپاره") };
	static const TCHAR* TutTitleEn[3] = { TEXT("TRENCH MOVE & COVER"), TEXT("SHOOT TARGET CANS (3)"), TEXT("GRENADE & MORTAR FIRE") };

	FString MissionMiniFa[3] = {
		TEXT("پیشروی و ورود به موضع عملیاتی"),
		TEXT("پاکسازی کامل سنگرهای دشمن"),
		TEXT("تثبیت موضع با جوخه سرگرد رستمی")
	};
	FString MissionMiniEn[3] = {
		TEXT("REACH TACTICAL SECTOR"),
		TEXT("CLEAR FORWARD TRENCHES"),
		TEXT("SECURE SECTOR WITH SQUAD")
	};
	int32 ActiveMiniIdx = 0;
	if (!bTutActive && CurMission)
	{
		float DistToZone = 0.f;
		if (APawn* P = CachedPlayerPawn.Get())
		{
			DistToZone = FVector::Dist(P->GetActorLocation(), CurMission->GetActorLocation()) / 100.f;
		}
		if (CurMission->MissionType == EMissionType::Defend && CurMission->DefendTimeRemaining > 0.f)
		{
			const FString TStr = bEnglish
				? FString::Printf(TEXT("%02d:%02d"), FMath::CeilToInt(CurMission->DefendTimeRemaining) / 60, FMath::CeilToInt(CurMission->DefendTimeRemaining) % 60)
				: UFarsiTextHelper::FormatTimerPersian(CurMission->DefendTimeRemaining);
			MissionMiniFa[1] = FString::Printf(TEXT("پدافند و حفظ خط (%s)"), *TStr);
			MissionMiniEn[1] = FString::Printf(TEXT("HOLD DEFENSIVE LINE (%s)"), *TStr);
		}
		else if (CurMission->TotalEnemiesSpawned > 0)
		{
			const int32 Killed = FMath::Max(0, CurMission->TotalEnemiesSpawned - CurMission->AliveEnemies);
			MissionMiniFa[1] = FString::Printf(TEXT("پاکسازی نیروهای دشمن (%s/%s)"),
				*UFarsiTextHelper::ToPersianDigits(FString::FromInt(Killed)),
				*UFarsiTextHelper::ToPersianDigits(FString::FromInt(CurMission->TotalEnemiesSpawned)));
			MissionMiniEn[1] = FString::Printf(TEXT("CLEAR HOSTILES (%d/%d)"), Killed, CurMission->TotalEnemiesSpawned);
		}
		if (CurMission->SabotageTargets.Num() > 0)
		{
			MissionMiniFa[2] = TEXT("انهدام اهداف و مهمات دشمن");
			MissionMiniEn[2] = TEXT("DESTROY SABOTAGE TARGETS");
		}
		else if (CurMission->IntelSites.Num() > 0)
		{
			MissionMiniFa[2] = TEXT("جمع‌آوری مدارک و اطلاعات");
			MissionMiniEn[2] = TEXT("GATHER TACTICAL INTEL");
		}
		else if (CurMission->POWCaptives.Num() > 0)
		{
			MissionMiniFa[2] = TEXT("آزادسازی همرزمان اسیر");
			MissionMiniEn[2] = TEXT("RESCUE CAPTIVE ALLIES");
		}
		else if (CurMission->SupplyCrates.Num() > 0)
		{
			MissionMiniFa[2] = TEXT("انتقال صندوق‌های تدارکات");
			MissionMiniEn[2] = TEXT("DELIVER SUPPLY CRATES");
		}

		if (CurMission->MissionProgress >= 0.80f || (CurMission->TotalEnemiesSpawned > 0 && CurMission->AliveEnemies == 0))
		{
			ActiveMiniIdx = 2;
		}
		else if (DistToZone < 35.f || CurMission->TotalEnemiesSpawned > 0 || CurMission->MissionProgress > 0.15f)
		{
			ActiveMiniIdx = 1;
		}
		else
		{
			ActiveMiniIdx = 0;
		}
	}

	float CurY = HY + HeadH + 3.f * S;
	for (int32 i = 0; i < 3; ++i)
	{
		const int32 StepNum = i + 1;
		const bool bCur = bTutActive
			? ((StepNum == StageClamped) || (StageClamped > 3 && i == 2))
			: (i == ActiveMiniIdx);

		DrawMachinedMetalTile(HX, CurY, HW, TileH, bCur, Alpha, S, bCur);

		// Rounded .count badge ("۱", "۲", "۳") on RIGHT in RTL
		const float CountSz = 17.f * S;
		const float CountX = bEnglish ? (HX + 8.f * S) : (HX + HW - 8.f * S - CountSz);
		const float CountY = CurY + (TileH - CountSz) * 0.5f;
		Draw9SliceRoundedBox(CountX, CountY, CountSz, CountSz, FName(TEXT("StepTileCurrent")), 0.85f * Alpha, S, 0.40f, false, 0.f);
		const FString NLbl = bEnglish ? NumEn[i] : NumFa[i];
		DrawFarsiTextBounded(NLbl, FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::GoldText(), Alpha),
			CountX, CountY, CountSz, Font, 0.58f * S, false, true, CountSz);

		float NowReserveW = 0.f;
		if (bCur)
		{
			const float NW = 36.f * S, NH = 15.f * S;
			const float NX = bEnglish ? (HX + HW - NW - 8.f * S) : (HX + 8.f * S);
			const float NY = CurY + (TileH - NH) * 0.5f;
			Draw9SliceRoundedBox(NX, NY, NW, NH, FName(TEXT("StepTileCurrent")), 0.85f * Alpha, S, 0.40f, false, 0.f);
			DrawFarsiTextBounded(bEnglish ? TEXT("NOW") : TEXT("اکنون"),
				FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::Warm(), Alpha),
				NX + 2.f * S, NY, NW - 4.f * S, Font, 0.50f * S, false, true, NH);
			NowReserveW = NW + 8.f * S;
		}

		const float TX = bEnglish ? (CountX + CountSz + 6.f * S) : (HX + 8.f * S + NowReserveW);
		const float TW = FMath::Max(60.f * S, bEnglish ? (HX + HW - 8.f * S - NowReserveW - TX) : (CountX - 6.f * S - TX));
		FString RowTitle = bTutActive
			? FString(bEnglish ? TutTitleEn[i] : TutTitleFa[i])
			: (bEnglish ? MissionMiniEn[i] : MissionMiniFa[i]);
		if (bTutActive && i == 1 && StageClamped == 3)
		{
			if (const USquadAITutorialSubsystem* TutSys = USquadAITutorialSubsystem::Get(this))
			{
				const int32 CansHit = FMath::Max(0, TutSys->GetCurrentProgress());
				RowTitle = bEnglish
					? FString::Printf(TEXT("SHOOT TARGET CANS (%d/3)"), CansHit)
					: FString::Printf(TEXT("تیراندازی به قوطی‌ها (%s/۳)"), *UFarsiTextHelper::ToPersianDigits(FString::FromInt(CansHit)));
			}
		}
		DrawFarsiTextBounded(RowTitle,
			FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::TextWhite(), Alpha),
			TX, CurY, TW, Font, 0.64f * S, true, false, TileH, !bEnglish);

		CurY += TileH + TileGap;
	}
}

void AQuestNativeHUD::DrawMoveHintBanner(float CX, float BottomY, const FString& Headline, const FString& Subline, const FString& KeyToken,
	bool bEnglish, float Alpha, float S, UFont* Font, APlayerController* PC)
{
	if (!Canvas || Alpha <= 0.001f)
	{
		return;
	}
	const float BanW = 416.f * S;
	const float BanH = 74.f * S;
	const float BanX = CX - BanW * 0.5f;
	const float BanY = BottomY - BanH;

	// Matches .movehint in index.html lines 104-112 (border-radius: 8px, 3D inner bevel, inset: 3px keyline)
	Draw9SliceRoundedBox(BanX, BanY, BanW, BanH, FName(TEXT("FocusCard")), Alpha * 0.92f, S, 1.0f, true, 0.88f);
	DrawAsymmetricCornerBrackets(BanX, BanY, BanW, BanH, S, 0.92f * Alpha);
	DrawRect(FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::BracketGold(), Alpha), BanX + 1.f * S, BanY + 6.f * S, 3.0f * S, BanH - 12.f * S);

	const float KCellW = 20.f * S;
	const float KCellH = 19.f * S;
	const float KGap = 2.5f * S;
	const float KCTotalW = 3.f * KCellW + 2.f * KGap;
	const float KCLeft = bEnglish ? (BanX + 12.f * S) : (BanX + BanW - 12.f * S - KCTotalW);
	const float KCTop = BanY + (BanH - (2.f * KCellH + KGap)) * 0.5f;

	auto DrawClusterKey = [&](int32 Col, int32 Row, const FString& K, bool bDefaultActive)
	{
		const float KX = KCLeft + Col * (KCellW + KGap);
		const float KY = KCTop + Row * (KCellH + KGap);
		bool bHeld = bDefaultActive;
		if (PC && K.Len() == 1 && FChar::IsAlpha(K[0]))
		{
			if (PC->IsInputKeyDown(FKey(*K.ToUpper()))) bHeld = true;
		}
		Draw9SliceRoundedBox(KX, KY, KCellW, KCellH,
			bHeld ? FName(TEXT("SlotActive")) : FName(TEXT("VitalsTile")),
			0.96f * Alpha, S, 0.45f, false, 0.f);
		DrawFarsiTextBounded(K,
			bHeld ? FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::DarkInk(), Alpha)
			      : FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::TextWhite(), Alpha),
			KX, KY, KCellW, Font, bHeld ? (0.56f * S) : (0.54f * S), false, true, KCellH);
	};

	DrawClusterKey(1, 0, TEXT("W"), KeyToken.Equals(TEXT("W"), ESearchCase::IgnoreCase));
	DrawClusterKey(0, 1, TEXT("A"), false);
	DrawClusterKey(1, 1, TEXT("S"), false);
	DrawClusterKey(2, 1, TEXT("D"), false);

	const float DivX = bEnglish ? (KCLeft + KCTotalW + 8.f * S) : (KCLeft - 9.f * S);
	DrawRect(FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::Hairline(), Alpha), DivX, BanY + 12.f * S, 1.f * S, BanH - 24.f * S);

	const float BigW = 56.f * S;
	const float BigH = 54.f * S;
	const float BigX = bEnglish ? (BanX + BanW - 26.f * S - BigW) : (BanX + 26.f * S);
	const float BigY = BanY + (BanH - BigH) * 0.5f;
	bool bPrimaryHeld = false;
	if (PC)
	{
		if (KeyToken == TEXT("RMB")) bPrimaryHeld = PC->IsInputKeyDown(EKeys::RightMouseButton);
		else if (KeyToken == TEXT("LMB")) bPrimaryHeld = PC->IsInputKeyDown(EKeys::LeftMouseButton);
		else if (KeyToken == TEXT("MMB")) bPrimaryHeld = PC->IsInputKeyDown(EKeys::MiddleMouseButton);
		else if (KeyToken.Len() == 1 && FChar::IsAlpha(KeyToken[0])) bPrimaryHeld = PC->IsInputKeyDown(FKey(*KeyToken.ToUpper()));
	}
	DrawBigKeycap3D(BigX, BigY, BigW, BigH, KeyToken.IsEmpty() ? TEXT("W") : KeyToken, bPrimaryHeld, Alpha, S, Font);

	// Amber chevron arrow (.hint-arrow: in RTL transform: scaleX(-1) points LEFT ◄)
	const float ArrX = bEnglish ? (BanX + BanW - 15.f * S) : (BanX + 14.f * S);
	const float ArrY = BanY + BanH * 0.5f;
	const FLinearColor ArrCol = FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::BracketGold(), Alpha);
	if (bEnglish)
	{
		DrawLine(ArrX - 3.f * S, ArrY - 5.f * S, ArrX + 3.f * S, ArrY, ArrCol, 2.0f * S);
		DrawLine(ArrX + 3.f * S, ArrY, ArrX - 3.f * S, ArrY + 5.f * S, ArrCol, 2.0f * S);
	}
	else
	{
		DrawLine(ArrX + 3.f * S, ArrY - 5.f * S, ArrX - 3.f * S, ArrY, ArrCol, 2.0f * S);
		DrawLine(ArrX - 3.f * S, ArrY, ArrX + 3.f * S, ArrY + 5.f * S, ArrCol, 2.0f * S);
	}

	// Center copy (.move-copy) + tiny mouse icon (.move-copy small:after: 7x12px rounded pill with scroll wheel right next to subtitle)
	const float CopyX = bEnglish ? (DivX + 10.f * S) : (BigX + BigW + 10.f * S);
	const float CopyW = FMath::Max(90.f * S, bEnglish ? (BigX - 10.f * S - CopyX) : (DivX - 10.f * S - CopyX));
	DrawFarsiText3D(Headline, FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::TextWhite(), Alpha),
		CopyX, BanY + 12.f * S, CopyW, Font, 0.88f * S, false, !bEnglish, 24.f * S, 1.0f * S);

	const float MouseW = 8.f * S, MouseH = 12.f * S;
	const float SubW = CopyW - MouseW - 6.f * S;
	const float SubX = bEnglish ? CopyX : (CopyX + MouseW + 5.f * S);
	DrawFarsiTextBounded(Subline, FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::TextDim(), Alpha),
		SubX, BanY + 39.f * S, SubW, Font, 0.62f * S, true, false, 20.f * S, !bEnglish);

	float SubMeasuredW = 0.f, SubMeasuredH = 0.f;
	GetFarsiTextSize(Subline, Font, 0.62f * S, SubMeasuredW, SubMeasuredH);
	SubMeasuredW = FMath::Clamp(SubMeasuredW, 40.f * S, SubW);
	const float MouseX = bEnglish
		? FMath::Min(CopyX + CopyW - MouseW, CopyX + SubMeasuredW + 5.f * S)
		: FMath::Max(CopyX, (SubX + SubW) - SubMeasuredW - MouseW - 5.f * S);
	const float MouseY = BanY + 43.f * S;
	const FLinearColor MouseBdr = FSquadAIHUDPalette::SRGB(212, 202, 184, 0.68f * Alpha);
	DrawRect(FSquadAIHUDPalette::SRGB(24, 27, 25, 0.78f * Alpha), MouseX + 1.f, MouseY + 1.f, MouseW - 2.f, MouseH - 2.f);
	DrawRect(MouseBdr, MouseX + 1.f, MouseY, MouseW - 2.f, 1.f);
	DrawRect(MouseBdr, MouseX + 1.f, MouseY + MouseH - 1.f, MouseW - 2.f, 1.f);
	DrawRect(MouseBdr, MouseX, MouseY + 1.f, 1.f, MouseH - 2.f);
	DrawRect(MouseBdr, MouseX + MouseW - 1.f, MouseY + 1.f, 1.f, MouseH - 2.f);
	DrawRect(FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::GoldText(), 0.90f * Alpha),
		MouseX + MouseW * 0.5f - 0.8f * S, MouseY + 2.5f * S, 1.6f * S, 3.0f * S);
}

void AQuestNativeHUD::DrawFarsiText3D(const FString& Text, const FLinearColor& Color, float X, float Y,
	float MaxWidth, UFont* Font, float PreferredScale, bool bCenterHorizontal, bool bRightAlign,
	float BoxHeight, float Depth)
{
	if (!Canvas || Text.IsEmpty() || MaxWidth <= 0.f)
	{
		return;
	}
	// Matches index.html line 125:
	// text-shadow: 0 1px 0 #0007; -webkit-text-stroke: 0;
	// Single crisp 1px dark drop shadow below + single razor-sharp 1:1 foreground glyph pass (no -1.1px white double-vision halo!).
	const FLinearColor Shade(0.0f, 0.0f, 0.0f, Color.A * 0.72f);
	DrawFarsiTextBounded(Text, Shade, FMath::RoundToFloat(X), FMath::RoundToFloat(Y) + 1.0f, MaxWidth, Font,
		PreferredScale, false, bCenterHorizontal, BoxHeight, bRightAlign);
	DrawFarsiTextBounded(Text, Color, FMath::RoundToFloat(X), FMath::RoundToFloat(Y), MaxWidth, Font,
		PreferredScale, false, bCenterHorizontal, BoxHeight, bRightAlign);
}

void AQuestNativeHUD::AddFeedEntry(const FString& Text, ESquadAIFeedKind Kind)
{
	// S18-FEED: one short line per battlefield event. Capped so a firefight
	// cannot flood the corner of the screen.
	if (!bShowCombatFeed || Text.IsEmpty() || !GetWorld()) return;

	FSquadAIFeedEntry E;
	E.Text = Text;
	E.Kind = Kind;
	E.SpawnTime = GetWorld()->GetTimeSeconds();
	FeedEntries.Add(MoveTemp(E));

	while (FeedEntries.Num() > 5)
	{
		FeedEntries.RemoveAt(0);
	}
}

void AQuestNativeHUD::DrawCombatFeed(float SW, float SH, UFont* Font)
{
	if (!bShowCombatFeed || FeedEntries.Num() == 0 || !Canvas || !GetWorld()) return;

	const float S = GameUIScale;
	const float Now = GetWorld()->GetTimeSeconds();

	// Age out expired lines first (back to front so indices stay valid).
	for (int32 i = FeedEntries.Num() - 1; i >= 0; --i)
	{
		if (Now - FeedEntries[i].SpawnTime > FeedEntryLifetime)
		{
			FeedEntries.RemoveAt(i);
		}
	}
	if (FeedEntries.Num() == 0) return;

	const float RowH = 26.f * S;
	const float RowW = FMath::Min(330.f * S, SW * 0.28f);
	const float X = SW - RowW - 26.f * S;
	float Y = 150.f * S; // clear of the compass ribbon

	for (const FSquadAIFeedEntry& E : FeedEntries)
	{
		const float Age = Now - E.SpawnTime;
		float In = FMath::Clamp(Age / 0.22f, 0.f, 1.f);
		In = 1.f - FMath::Pow(1.f - In, 3.f);
		const float Out = FMath::Clamp((FeedEntryLifetime - Age) / 0.8f, 0.f, 1.f);
		const float A = In * Out;
		if (A <= 0.f) { Y += RowH + 4.f * S; continue; }

		// Slide in from the right as it appears.
		const float RX = X + (1.f - In) * 26.f * S;

		FLinearColor Accent;
		switch (E.Kind)
		{
		case ESquadAIFeedKind::Kill:      Accent = FLinearColor(0.95f, 0.30f, 0.22f, 1.f); break;
		case ESquadAIFeedKind::Ally:      Accent = FLinearColor(0.95f, 0.62f, 0.20f, 1.f); break;
		case ESquadAIFeedKind::Objective: Accent = FLinearColor(0.35f, 0.85f, 0.95f, 1.f); break;
		case ESquadAIFeedKind::Supply:    Accent = FLinearColor(0.35f, 0.90f, 0.45f, 1.f); break;
		default:                          Accent = FLinearColor(0.95f, 0.85f, 0.35f, 1.f); break;
		}

		DrawRect(FLinearColor(0.f, 0.f, 0.f, 0.30f * A), RX + 2.f * S, Y + 2.f * S, RowW, RowH);
		DrawRect(FLinearColor(0.02f, 0.03f, 0.045f, 0.62f * A), RX, Y, RowW, RowH);
		DrawRect(FLinearColor(Accent.R, Accent.G, Accent.B, 0.85f * A), RX, Y, 2.5f * S, RowH);

		// Tiny glyph in the accent colour so the kind reads without reading.
		const float GX = RX + 12.f * S;
		const float GY = Y + RowH * 0.5f;
		const FLinearColor G(Accent.R, Accent.G, Accent.B, A);
		switch (E.Kind)
		{
		case ESquadAIFeedKind::Kill: // X
			DrawLine(GX - 4.f * S, GY - 4.f * S, GX + 4.f * S, GY + 4.f * S, G, 1.8f * S);
			DrawLine(GX - 4.f * S, GY + 4.f * S, GX + 4.f * S, GY - 4.f * S, G, 1.8f * S);
			break;
		case ESquadAIFeedKind::Objective: // diamond
			DrawLine(GX, GY - 5.f * S, GX + 5.f * S, GY, G, 1.6f * S);
			DrawLine(GX + 5.f * S, GY, GX, GY + 5.f * S, G, 1.6f * S);
			DrawLine(GX, GY + 5.f * S, GX - 5.f * S, GY, G, 1.6f * S);
			DrawLine(GX - 5.f * S, GY, GX, GY - 5.f * S, G, 1.6f * S);
			break;
		case ESquadAIFeedKind::Supply: // plus
		case ESquadAIFeedKind::Ally:
			DrawLine(GX - 5.f * S, GY, GX + 5.f * S, GY, G, 1.8f * S);
			DrawLine(GX, GY - 5.f * S, GX, GY + 5.f * S, G, 1.8f * S);
			break;
		default: // warning bar
			DrawLine(GX, GY - 5.f * S, GX, GY + 2.f * S, G, 2.0f * S);
			DrawLine(GX, GY + 4.f * S, GX, GY + 5.f * S, G, 2.0f * S);
			break;
		}

		DrawFarsiTextBounded(E.Text, FLinearColor(0.95f, 0.96f, 0.98f, A),
			RX + 24.f * S, Y, RowW - 34.f * S, Font, 0.74f * S, true, true, RowH);

		Y += RowH + 4.f * S;
	}
}

void AQuestNativeHUD::DrawLocationTitleCard(float SW, float SH, UFont* Font)
{
	// S18-TITLE: the stamp every Call of Duty mission opens on — place, date,
	// unit, typed into the lower-left over live gameplay. No letterbox, no
	// pause, no black frame (he has banned those): it simply fades over the
	// world while the player is already walking.
	if (!bShowTitleCard || bTitleCardDone || !Canvas || !GetWorld()) return;

	const float Now = GetWorld()->GetTimeSeconds();
	if (TitleCardStartTime < 0.f)
	{
		// S18-INTRO2: a reloaded save drops you mid-mission — stamping the
		// place and date again there would be wrong, so swallow it once.
		if (USquadAISaveLoadSubsystem* SaveSys = USquadAISaveLoadSubsystem::Get(this))
		{
			if (SaveSys->ConsumeEnteredLevelFromLoad())
			{
				bTitleCardDone = true;
				UE_LOG(LogTemp, Log, TEXT("[S18-TITLE] Entered via save load — opening stamp suppressed."));
				return;
			}
		}
		TitleCardStartTime = Now + 1.2f; // let the first frames settle
		return;
	}
	const float T = Now - TitleCardStartTime;
	if (T < 0.f) return;

	constexpr float Hold = 5.2f;
	if (T > Hold)
	{
		bTitleCardDone = true;
		return;
	}

	const float S = GameUIScale;
	const bool bEnglish = SquadAIHUDIsEnglish(this);
	const float FadeOut = FMath::Clamp((Hold - T) / 0.9f, 0.f, 1.f);

	// S18-LOC: every stamp line goes through the localisation subsystem, so the
	// external SquadAILocalization.ini (section [TitleCard]) can override all
	// three in any language — Arabic included — without touching C++.
	FString L1 = SquadAIHUDLocal(this, TEXT("TitleCard"), TEXT("Place"), *TitleCardPlaceFa, *TitleCardPlaceEn);
	FString L2 = SquadAIHUDLocal(this, TEXT("TitleCard"), TEXT("Date"),  *TitleCardDateFa,  *TitleCardDateEn);
	FString L3 = SquadAIHUDLocal(this, TEXT("TitleCard"), TEXT("Unit"),  *TitleCardUnitFa,  *TitleCardUnitEn);

	// S18-TITLE: a mission can override any of the three lines, so each level
	// (or each mission inside a level) stamps its own place and date without a
	// code change. Empty fields fall through to the HUD defaults above.
	if (AQuestChain* Chain = FindQuestChain())
	{
		if (const AMissionZone* Mission = Chain->GetCurrentMission())
		{
			if (!Mission->TitleCardPlace.IsEmpty()) L1 = Mission->TitleCardPlace.ToString();
			if (!Mission->TitleCardDate.IsEmpty())  L2 = Mission->TitleCardDate.ToString();
			if (!Mission->TitleCardUnit.IsEmpty())  L3 = Mission->TitleCardUnit.ToString();
		}
	}

	// S19-MISSUI: the stamp is mission text and it shared the bottom-left corner
	// with the squad panel. Three lines at +0/+52/+80 from SH-300 put the date and
	// unit lines straight through the panel's header (the panel owns
	// SH-240 .. SH-20), and the 620-wide block reached into the briefing note's
	// centre column. It now sits wholly above the panel and stops short of the
	// centre strip.
	const float X = 54.f * S;
	const float StampH = 96.f * S;                     // +0 / +52 / +80 lines
	const float BaseY = SH - 240.f * S - 12.f * S - StampH;
	float RailX = 0.f, RailW = 0.f;
	ComputeTutorialRailMetrics(SW, S, RailX, RailW);
	const float Width = FMath::Min3(620.f * S, SW * 0.5f, RailX - X - 12.f * S);

	auto Line = [&](const FString& Text, float YOff, float Delay, float Scale, const FLinearColor& Col)
	{
		float In = FMath::Clamp((T - Delay) / 0.5f, 0.f, 1.f);
		In = 1.f - FMath::Pow(1.f - In, 3.f);
		const float A = In * FadeOut;
		if (A <= 0.f) return;
		const float Slide = (1.f - In) * 18.f * S;
		FLinearColor C = Col;
		C.A *= A;
		DrawFarsiTextBounded(Text, C, X + Slide, BaseY + YOff, Width, Font, Scale * S, true, true);
	};

	// Gold rule that wipes open under the place name.
	{
		float RuleIn = FMath::Clamp((T - 0.15f) / 0.6f, 0.f, 1.f);
		RuleIn = 1.f - FMath::Pow(1.f - RuleIn, 3.f);
		DrawRect(FLinearColor(0.95f, 0.78f, 0.30f, 0.85f * RuleIn * FadeOut),
			X, BaseY + 42.f * S, Width * 0.55f * RuleIn, 2.f * S);
	}

	Line(L1, 0.f, 0.00f, 1.45f, FLinearColor(1.0f, 0.95f, 0.86f, 1.f));
	Line(L2, 52.f * S, 0.45f, 0.92f, FLinearColor(0.93f, 0.86f, 0.70f, 1.f));
	Line(L3, 80.f * S, 0.75f, 0.82f, FLinearColor(0.78f, 0.80f, 0.84f, 1.f));
}

void AQuestNativeHUD::DrawGuideSubtitle(float ScreenW, float ScreenH, UFont* Font, bool bEnglish)
{
	const float S = GameUIScale;
	APlayerController* PC = UGameplayStatics::GetPlayerController(GetWorld(), 0); // S18-FIX: own PC, the caller's is out of scope
	ATutorialGuideActor* Guide = nullptr;
	for (const TWeakObjectPtr<AActor>& WeakIt : GetCachedActorsOfClass(ATutorialGuideActor::StaticClass(), 1.0f)) // S18-PERF
	{
		if (ATutorialGuideActor* G = Cast<ATutorialGuideActor>(WeakIt.Get())) { Guide = G; break; }
	}
	if (!Guide)
	{
		return;
	}

	const float A = Guide->GetSubtitleAlpha();
	const FString Sub = Guide->GetActiveSubtitleFor(bEnglish);
	if (A <= 0.f || Sub.IsEmpty())
	{
		return;
	}

	// S19-TUTLAYOUT: the band is as wide as the rail and its Y comes from the
	// measured bottom stack, so it can no longer overlap the cinematic banner
	// (it sat at "bottom - 118" while the banner sat at "bottom - 148..92") or the
	// onboarding card. The speaker name and the line are WRAPPED, not shrunk -
	// a long line used to render at a fraction of its intended size.
	const float BandW = (TutRailW > 0.f) ? TutRailW : FMath::Min(900.f * S, ScreenW - 120.f * S);
	const float Pad = 14.f * S;
	// S26-TUTFEEL: portrait column (measured by the same rules as the band)
	UTexture2D* Av = GetTutorialIllustration(FName(TEXT("Guide")));
	const float TextW0 = FMath::Max(80.f * S, BandW - Pad * 2.f);
	const float SpeakerH0 = FMath::Max(12.f * S,
		WrapTutorialText(Guide->GetSpeakerName(bEnglish), Font, 0.86f * S, TextW0, 1).LineH);
	const FTutorialTextBlock SubBlock0 = WrapTutorialText(Sub, Font, 1.00f * S, TextW0, 3);
	const float BandH0 = FMath::Max(48.f * S, Pad + SpeakerH0 + 2.f * S + SubBlock0.BlockH + Pad * 0.6f);
	const float AvW = Av ? FMath::Max(46.f * S, BandH0 - Pad) : 0.f;
	const float AvGap = Av ? Pad * 0.8f : 0.f;
	const float TextW = FMath::Max(80.f * S, BandW - Pad * 2.f - AvW - AvGap);
	const float SpeakerH = FMath::Max(12.f * S,
		WrapTutorialText(Guide->GetSpeakerName(bEnglish), Font, 0.86f * S, TextW, 1).LineH);
	const FTutorialTextBlock SubBlock = WrapTutorialText(Sub, Font, 1.00f * S, TextW, 3);
	const float BandH = FMath::Max(FMath::Max(48.f * S, Pad + SpeakerH + 2.f * S + SubBlock.BlockH + Pad * 0.6f),
		Av ? (AvW + Pad * 1.2f) : 0.f);
	const float BandX = (ScreenW - BandW) * 0.5f;
	const float BandY = (TutSubtitleY >= 0.f) ? TutSubtitleY : (ScreenH - 140.f * S - BandH);

	DrawTutorialPlate(BandX, BandY, BandW, BandH, A, S, false);

	// The gold bar on the leading edge marks who is talking.
	DrawRect(FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::BracketGold(), 0.75f * A), BandX, BandY, 3.f * S, BandH);

	// The guide's portrait: slab, image, corner brackets - the narrator is a
	// face now, not a colour bar. (1980s-period line art, key "Guide".)
	if (Av)
	{
		const float AvX = BandX + Pad * 0.7f;
		const float AvY = BandY + (BandH - AvW) * 0.5f;
		DrawRect(FLinearColor(0.f, 0.f, 0.f, 0.55f * A), AvX - 2.f * S, AvY - 2.f * S, AvW + 4.f * S, AvW + 4.f * S);
		DrawTexture(Av, AvX, AvY, AvW, AvW, 0.f, 0.f, 1.f, 1.f, FLinearColor(1.f, 1.f, 1.f, A));
		DrawCornerBrackets(AvX, AvY, AvW, AvW,
			FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::BracketGold(), 0.95f * A), 8.f * S, 1.4f * S);
	}

	const float TextX = BandX + Pad + AvW + AvGap;
	// S26-TUTTEXT: brighter gold and flush right - the speaker LEADS the
	// line in Farsi, from the right edge of the column.
	DrawFarsiText3D(Guide->GetSpeakerName(bEnglish), FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::GoldText(), A),
		TextX, BandY + Pad * 0.5f, TextW, Font, 0.86f * S, false, true, SpeakerH, 1.7f * S); // S26-TUT3D: raised brass

	// S26-TUTLOOK: a live radio waveform beside the speaker name - five gold
	// bars breathing with the line being spoken. The guide talks over a
	// backpack radio; this is the period-correct way to say "he is talking".
	{
		const FString SpeakerName = Guide->GetSpeakerName(bEnglish);
		float SpkW = 0.f, SpkH = 0.f;
		GetFarsiTextSize(SpeakerName, Font, 0.86f * S, SpkW, SpkH);
		// Left of the right-flush name: Farsi reads right-to-left, so the
		// waveform trails the speaker's name toward the left.
		const float WaveX = TextX + TextW - SpkW - 10.f * S - 25.f * S;
		if (WaveX >= TextX)
		{
			const float T = GetWorld()->GetTimeSeconds();
			const float MidY = BandY + Pad * 0.5f + SpeakerH * 0.5f;
			for (int32 Bi = 0; Bi < 5; ++Bi)
			{
				const float WaveBarH = SpeakerH * (0.30f + 0.34f * FMath::Abs(FMath::Sin(T * 7.f + Bi * 1.7f)));
				DrawRect(FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::BracketGold(), 0.85f * A),
					WaveX + Bi * 5.f * S, MidY - WaveBarH * 0.5f, 2.5f * S, WaveBarH);
			}
		}
	}
	DrawTutorialTextBlock(SubBlock, FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::TextWhite(), A),
		TextX, BandY + Pad * 0.5f + SpeakerH + 2.f * S, TextW, Font, 1.00f * S);

	// Small chevron over the speaker so you know who is talking.
	FVector2D GS;
	if (PC && PC->ProjectWorldLocationToScreen(Guide->GetGuideLocation() + FVector(0.f, 0.f, 120.f), GS))
	{
		const FLinearColor Gold = FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::BracketGold(), A);
		DrawLine(GS.X - 10.f * S, GS.Y - 10.f * S, GS.X, GS.Y, Gold, 2.f * S);
		DrawLine(GS.X, GS.Y, GS.X + 10.f * S, GS.Y - 10.f * S, Gold, 2.f * S);
	}
}

//   SquadAI.Tutorial.CardScale 1.3     bigger/smaller card
//   SquadAI.Tutorial.CardWidth 720     px wide at scale 1
//   SquadAI.Tutorial.CardY 0.50        centre as a fraction of screen height (0.5 = dead centre)
static TAutoConsoleVariable<float> CVarSquadAITutorialCardScale(
	TEXT("SquadAI.Tutorial.CardScale"), 1.0f,
	TEXT("Scales the tutorial card. 1 = default size. 0.5 = half, 2 = double."));
static TAutoConsoleVariable<float> CVarSquadAITutorialCardWidth(
	TEXT("SquadAI.Tutorial.CardWidth"), 700.f,
	TEXT("Tutorial card width (the rail) in pixels at CardScale 1. The rail is clamped against "
	     "the top-corner HUD blocks, so a very large value cannot make it overlap them."));
static TAutoConsoleVariable<float> CVarSquadAITutorialCardY(
	TEXT("SquadAI.Tutorial.CardY"), 0.42f,
	TEXT("Preferred tutorial card centre as a fraction of screen height (0 = top, 1 = bottom). "
	     "0.42 keeps the card just above the crosshair. The value is a preference: the card is "
	     "clamped between the header strip and the bottom stack, so it can never overlap them."));

// =========================================================================
//  S19-TUTLAYOUT - the tutorial's geometry, computed once, then drawn from
// =========================================================================

AQuestNativeHUD::FTutorialTextBlock AQuestNativeHUD::WrapTutorialText(const FString& Text, UFont* Font,
	float Scale, float MaxWidth, int32 MaxLines) const
{
	FTutorialTextBlock Out;
	if (Text.IsEmpty() || MaxWidth <= 1.f || !Canvas)
	{
		return Out;
	}

	// One line height, measured once (the sizer applies HUDFontScale exactly like the
	// bounded draw does, so a line that measures inside MaxWidth will not be shrunk).
	{
		float W = 0.f, H = 0.f;
		GetFarsiTextSize(TEXT("Ag"), Font, Scale, W, H);
		Out.LineH = FMath::Max(4.f, H);
	}

	// Explicit newlines are hard breaks; within a paragraph, greedy word wrap.
	TArray<FString> Paragraphs;
	Text.ParseIntoArray(Paragraphs, TEXT("\n"), false);

	for (const FString& Para : Paragraphs)
	{
		TArray<FString> Words;
		Para.ParseIntoArray(Words, TEXT(" "), true);
		if (Words.Num() == 0)
		{
			continue;
		}

		FString Line;
		for (const FString& Word : Words)
		{
			const FString Candidate = Line.IsEmpty() ? Word : (Line + TEXT(" ") + Word);
			float W = 0.f, H = 0.f;
			GetFarsiTextSize(Candidate, Font, Scale, W, H);

			if (!Line.IsEmpty() && W > MaxWidth)
			{
				Out.Lines.Add(Line);
				Line = Word;
				if (MaxLines > 0 && Out.Lines.Num() >= MaxLines)
				{
					break;
				}
			}
			else
			{
				Line = Candidate;
			}
		}

		if (MaxLines > 0 && Out.Lines.Num() >= MaxLines)
		{
			break;
		}
		if (!Line.IsEmpty())
		{
			Out.Lines.Add(Line);
			if (MaxLines > 0 && Out.Lines.Num() >= MaxLines)
			{
				break;
			}
		}
	}

	if (Out.Lines.Num() > 0)
	{
		// 1.14 line spacing reads as set type rather than as stacked text.
		Out.BlockH = Out.LineH * 1.18f * Out.Lines.Num(); // S26-TUTTEXT: matches DrawTutorialTextBlock's step
	}
	return Out;
}

float AQuestNativeHUD::DrawTutorialTextBlock(const FTutorialTextBlock& Block, const FLinearColor& Color,
	float X, float Y, float MaxWidth, UFont* Font, float Scale, bool bCentre)
{
	if (Block.IsEmpty())
	{
		return 0.f;
	}
	// S26-TUTTEXT: 1.18 line spacing (1.14 was tight at the larger body size)
	// and Farsi paragraphs are flush right - the card, banner and subtitle
	// now read as set type, not stacked strings.
	const bool bRTLFlush = !SquadAIHUDIsEnglish(this);
	const float Step = Block.LineH * 1.18f;
	float Cursor = Y;
	for (const FString& Line : Block.Lines)
	{
		DrawFarsiTextBounded(Line, Color, X, Cursor, MaxWidth, Font, Scale, true, bCentre, 0.f, bRTLFlush && !bCentre);
		Cursor += Step;
	}
	return Block.BlockH;
}

void AQuestNativeHUD::ComputeTutorialRailMetrics(float ScreenW, float S, float& OutX, float& OutW)
{
	// The one rail: a single width and a single centre line, clamped against the
	// objective card (top-left) and the weapon plate (top-right).
	const float Margin  = FMath::Max(24.f * S, ScreenW * 0.02f);
	const float RailMax = FMath::Max(260.f * S, ScreenW - 2.f * (376.f * S + 18.f * S));
	const float Want    = CVarSquadAITutorialCardWidth.GetValueOnGameThread() * CVarSquadAITutorialCardScale.GetValueOnGameThread();
	OutW = FMath::Clamp(Want, FMath::Min(300.f * S, RailMax), FMath::Min3(RailMax, 860.f * S, ScreenW - 2.f * Margin));
	OutX = (ScreenW - OutW) * 0.5f;
}

void AQuestNativeHUD::ComputeTutorialRail(float ScreenW, float S)
{
	ComputeTutorialRailMetrics(ScreenW, S, TutRailX, TutRailW);
}

void AQuestNativeHUD::ComputeTutorialStack(float ScreenH, float S, float HelpBlockH,
	float BannerBlockH, float SubtitleBlockH)
{
	// The radio chatter box owns SH-120 .. SH-72 (460 x 48, bottom centre) and is drawn by
	// another subsystem. Reserve that slot plus a gap, then stack the tutorial's own chrome
	// upward from it: help line, then the banner (or the legacy key chip), then the guide
	// subtitle, then the onboarding card. Every element's top edge is derived from the one
	// below it, so no two can ever overlap - the previous code had the subtitle band
	// overlapping both the banner and the onboarding card at 1080p.
	const float SideMargin = FMath::Max(20.f * S, ScreenH * 0.02f);
	const float Gap        = 10.f * S;
	float Cursor           = ScreenH - 140.f * S;   // top of the reserved radio slot (S24-UISWEEP: the radio box can grow one wrapped line)

	// S19-TUTCOLOR (found on the colour/mis-placement re-read): the banner is
	// subtracted FIRST, so it is pinned to the reserved radio slot and does not
	// move when the help line appears. It used to be the other way round - the
	// help line took the bottom slot and the banner was pushed up by the help
	// height whenever the hint escalated, which shifted the one element the
	// player is actually reading (and put the hint BELOW the banner, the
	// opposite of what the code said it did).
	TutBannerY = -1.f;
	TutChipY = -1.f;
	if (BannerBlockH > 0.f)
	{
		Cursor -= BannerBlockH;
		TutBannerY = Cursor;
		TutBannerH = BannerBlockH;
		Cursor -= Gap;
	}

	TutHelpY = -1.f;
	if (HelpBlockH > 0.f)
	{
		Cursor -= HelpBlockH;
		TutHelpY = Cursor;
		Cursor -= Gap;
	}

	TutSubtitleY = -1.f;
	if (SubtitleBlockH > 0.f)
	{
		Cursor -= SubtitleBlockH;
		TutSubtitleY = Cursor;
		TutSubtitleH = SubtitleBlockH;
		Cursor -= Gap;
	}

	// The onboarding card (a separate system, drawn earlier in the frame) sits above all of
	// it when the tutorial is not running its own stack; when it is, its own geometry uses
	// this line. Clamp so it never rides into the header strip.
	TutStackTopY = FMath::Max(Cursor, TutHeaderY + TutHeaderH + 12.f * S);
	bTutLayoutValid = true;
}

void AQuestNativeHUD::DrawTutorialPlate(float X, float Y, float W, float H, float Alpha, float S,
	bool bBrackets)
{
	if (Alpha <= 0.001f || W <= 0.f || H <= 0.f || !Canvas)
	{
		return;
	}

	// S27-REFUI: 9-slice rounded-bevel surface texture (T_UI_OpBanner.png when bBrackets=true,
	// T_UI_GlassPanel.png otherwise) with anti-aliased rounded corners, 3D inner bevel, and inner keyline.
	const FName GlassTexName = bBrackets ? FName(TEXT("OpBanner")) : FName(TEXT("GlassPanel"));
	Draw9SliceRoundedBox(X, Y, W, H, GlassTexName, Alpha, S, 1.0f, false, 0.f);

	if (bBrackets)
	{
		DrawAsymmetricCornerBrackets(X, Y, W, H, S, Alpha);
	}
}

void AQuestNativeHUD::DrawTutorialHeaderStrip(float ScreenW, float ScreenH, float S, UFont* Font,
	const FString& Title, int32 StepIndex, int32 StepCount, bool bEnglish,
	float MouseX, float MouseY, bool bLeftClick, bool& bOutSkipPressed)
{
	bOutSkipPressed = false;
	// S27-REFUI: The deprecated top-center diamond header strip is replaced by the
	// top-left Operation Masthead Plaque (.operation-banner) and 5-Step Tutorial
	// Sequence Panel (.tutorial) matching index.html. When called during the
	// scripted intro sequence before Tut->IsTutorialActive(), draw the Operation Banner!
	const float LeftX = FMath::Max(24.f * S, ScreenW * 0.0235f);
	const float TopY  = ScreenH * 0.028f;
	const float BanW  = FMath::Min(500.f * S, ScreenW * 0.38f);
	const float BanH  = 88.f * S;
	const float Pct   = FMath::Clamp(static_cast<float>(StepIndex + 1) / static_cast<float>(FMath::Max(1, StepCount)), 0.21f, 1.0f);
	DrawOperationBanner(LeftX, TopY, BanW, BanH, Pct, bEnglish, 0.96f, S, Font);
}

FString AQuestNativeHUD::BuildTutorialHelpText(const FSquadAITutorialBeat& Beat, bool bEnglish) const
{
	switch (Beat.Step)
	{
	case ESquadAITutorialStep::Task_Move:
		return bEnglish ? TEXT("Hold W to walk, hold SHIFT to sprint, and look with the mouse.")
			: TEXT("برای راه رفتن W را نگه دار، برای دویدن SHIFT و با ماوس نگاه کن.");
	case ESquadAITutorialStep::Task_ShootCans:
		return SquadAIHUDLocal(this, TEXT("Tutorial"), TEXT("HelpShoot"),
			TEXT("برای نشانه‌روی کلیک راست را نگه دار، سپس کلیک چپ بزن."),
			TEXT("Hold the right mouse button to aim down the sights, then click to fire."));
	case ESquadAITutorialStep::Task_Grenade:
		return bEnglish ? TEXT("Aim at the open top of the drum, then hold G and release — grenades arc.")
			: TEXT("دهانه باز بشکه را نشانه بگیر، G را نگه دار و رها کن — نارنجک قوس می‌خورد.");
	case ESquadAITutorialStep::Task_Artillery:
		return bEnglish ? TEXT("Press the middle mouse button while looking at the target area.")
			: TEXT("در حالی که به منطقه هدف نگاه می‌کنی کلیک وسط را بزن.");
	default:
		break;
	}
	return FString();
}

float AQuestNativeHUD::MeasureGuideSubtitleBlock(UFont* Font, bool bEnglish) const
{
	if (!GetWorld())
	{
		return 0.f;
	}
	for (const TWeakObjectPtr<AActor>& WeakIt : GetCachedActorsOfClass(ATutorialGuideActor::StaticClass(), 1.0f))
	{
		ATutorialGuideActor* Guide = Cast<ATutorialGuideActor>(WeakIt.Get());
		if (!Guide)
		{
			continue;
		}
		const float A = Guide->GetSubtitleAlpha();
		const FString Sub = Guide->GetActiveSubtitleFor(bEnglish);
		if (A <= 0.f || Sub.IsEmpty())
		{
			return 0.f;
		}
		const float S = GameUIScale;
		const float BandW = TutRailW > 0.f ? TutRailW : FMath::Min(900.f * S, Canvas ? Canvas->ClipX - 120.f * S : 900.f * S);
		const float Pad = 14.f * S;
		UTexture2D* Av = GetTutorialIllustration(FName(TEXT("Guide")));
		const float TextW0 = FMath::Max(80.f * S, BandW - Pad * 2.f);
		const float SpeakerH0 = FMath::Max(12.f * S,
			WrapTutorialText(Guide->GetSpeakerName(bEnglish), Font, 0.86f * S, TextW0, 1).LineH);
		const float SubH0 = WrapTutorialText(Sub, Font, 1.00f * S, TextW0, 3).BlockH;
		const float BandH0 = FMath::Max(48.f * S, Pad + SpeakerH0 + 2.f * S + SubH0 + Pad * 0.6f);
		const float AvW = Av ? FMath::Max(46.f * S, BandH0 - Pad) : 0.f;
		const float AvGap = Av ? Pad * 0.8f : 0.f;
		const float TextW = FMath::Max(80.f * S, BandW - Pad * 2.f - AvW - AvGap);
		const float SpeakerH = WrapTutorialText(Guide->GetSpeakerName(bEnglish), Font, 0.86f * S, TextW, 1).BlockH;
		const float SubH = WrapTutorialText(Sub, Font, 1.00f * S, TextW, 3).BlockH;
		return FMath::Max(FMath::Max(48.f * S, Pad + SpeakerH + 2.f * S + SubH + Pad * 0.6f),
			Av ? (AvW + Pad * 1.2f) : 0.f);
	}
	return 0.f;
}

void AQuestNativeHUD::DrawTutorialOverlay(float ScreenW, float ScreenH, float DeltaTime, UFont* Font)
{
	if (!Canvas || bPauseMenuActive)
	{
		return;
	}

	USquadAITutorialSubsystem* Tut = USquadAITutorialSubsystem::Get(this);
	const bool bTutActive = Tut && Tut->IsTutorialActive();
	const float S = GameUIScale;
	const bool bEnglish = SquadAIHUDIsEnglish(this);

	APlayerController* PC = UGameplayStatics::GetPlayerController(GetWorld(), 0);
	float MouseX = 0.f, MouseY = 0.f;
	bool bLeftClick = false;
	if (PC)
	{
		PC->GetMousePosition(MouseX, MouseY);
		bLeftClick = PC->WasInputKeyJustPressed(EKeys::LeftMouseButton);
	}

	// Check if scripted intro is running before tutorial goes active, or if tutorial has ended (Mission Mode)
	if (!bTutActive)
	{
		ATutorialIntroSequence* IntroOnly = nullptr;
		for (const TWeakObjectPtr<AActor>& WeakIt : GetCachedActorsOfClass(ATutorialIntroSequence::StaticClass(), 0.5f))
		{
			ATutorialIntroSequence* C = Cast<ATutorialIntroSequence>(WeakIt.Get());
			if (C && C->IsIntroRunning()) { IntroOnly = C; break; }
		}
		if (IntroOnly)
		{
			ComputeTutorialRail(ScreenW, S);
			const float SubH = MeasureGuideSubtitleBlock(Font, bEnglish);
			ComputeTutorialStack(ScreenH, S, 0.f, 80.f * S, SubH);

			const float LeftX = FMath::Max(24.f * S, ScreenW * 0.0235f);
			DrawOperationBanner(LeftX, ScreenH * 0.028f, FMath::Min(500.f * S, ScreenW * 0.38f), 88.f * S, 0.21f, bEnglish, 0.96f, S, Font);
			DrawGuideSubtitle(ScreenW, ScreenH, Font, bEnglish);
			return;
		}

		// =========================================================================
		// POST-TUTORIAL MISSION MODE:
		// Keep the exact same index.html HUD style & panels, with live mission texts!
		// =========================================================================
		AQuestChain* Chain = FindQuestChain();
		AMissionZone* CurMission = (Chain && Chain->bIsActive) ? Chain->GetCurrentMission() : nullptr;
		if (!CurMission && Chain)
		{
			for (AMissionZone* MZ : Chain->Missions)
			{
				if (MZ && (MZ->IsActive() || !MZ->IsCompleted()))
				{
					CurMission = MZ;
					break;
				}
			}
			if (!CurMission && Chain->Missions.Num() > 0)
			{
				CurMission = Chain->Missions.Last();
			}
		}

		const int32 TotalStages = (Chain && Chain->TotalMissionCount > 0) ? Chain->TotalMissionCount : 5;
		const int32 ActiveMissionStage = (Chain && Chain->CurrentMissionIndex >= 0)
			? FMath::Clamp(Chain->CurrentMissionIndex + 1, 1, 5)
			: FMath::Clamp((Chain ? Chain->CompletedMissionCount : 0) + 1, 1, 5);
		float MissionProgPct = FMath::Clamp(
			(static_cast<float>(ActiveMissionStage - 1) + (CurMission ? FMath::Clamp(CurMission->MissionProgress, 0.15f, 1.0f) : 0.25f))
			/ static_cast<float>(FMath::Max(1, TotalStages)),
			0.20f, 1.0f);
		if (Chain && Chain->bIsCompleted)
		{
			MissionProgPct = 1.0f;
		}

		const float LeftX = FMath::Max(24.f * S, ScreenW * 0.0235f);

		// 1. TOP-LEFT OPERATION MASTHEAD PLAQUE (.operation-banner)
		const float OpY = ScreenH * 0.028f;
		const float OpW = FMath::Min(510.f * S, ScreenW * 0.39f);
		const float OpH = 83.f * S;
		DrawOperationBanner(LeftX, OpY, OpW, OpH, MissionProgPct, bEnglish, 0.96f, S, Font);

		// 2. LEFT 5-STAGE MISSION SEQUENCE PANEL (.tutorial)
		const float StepsY = FMath::Max(OpY + OpH + 10.f * S, ScreenH * 0.178f);
		const float StepsW = FMath::Min(460.f * S, ScreenW * 0.358f);
		float StepsBottomY = StepsY;
		if (bShowTutorialChecklist)
		{
			DrawTutorialStepsPanel(LeftX, StepsY, StepsW, ActiveMissionStage, bEnglish, 0.95f, S, Font, StepsBottomY);
		}

		// 3. LEFT-MIDDLE FOCUS DIRECTIVE CARD (.focus-instruction)
		//    Sourced from live Mission Briefing / Story Card, Mission Alert, Radio Chatter, or Stage Directive
		const float FocusY = FMath::Max(StepsBottomY + 10.f * S, ScreenH * 0.565f);
		const float FocusW = FMath::Min(365.f * S, ScreenW * 0.285f);

		static const TCHAR* StageDirectiveTitleFa[5] = {
			TEXT("پیشروی در محور دهلاویه"),
			TEXT("حمله به خط سنگر و پاکسازی"),
			TEXT("پدافند مقر فرماندهی"),
			TEXT("شناسایی و گشت نخلستان"),
			TEXT("تثبیت معبر رودخانه کرخه")
		};
		static const TCHAR* StageDirectiveTitleEn[5] = {
			TEXT("ADVANCE ON DEHLAVIEH AXIS"),
			TEXT("TRENCH ASSAULT & CLEAR"),
			TEXT("HQ — HOLD THE LINE"),
			TEXT("GROVE RECON & INTEL"),
			TEXT("KARKHEH RIVER CROSSING")
		};
		static const TCHAR* StageDirectiveBodyFa[5] = {
			TEXT("همراه جوخه سرگرد رستمی در امتداد خاکریز پیشروی کنید، سنگرها را پاکسازی کرده و موضع خط اول دهلاویه را تثبیت نمایید."),
			TEXT("با استفاده از سلاح سازمانی و نارنجک، سنگرهای تیربار دشمن را منهدم کرده و نیروهای متجاوز را عقب برانید."),
			TEXT("در برابر موج‌های پاتک دشمن مقاومت کنید، مهمات جوخه را مدیریت کرده و با کلید وسط [MMB] آتش خمپاره بخواهید."),
			TEXT("دیده‌بان‌های توپخانه دشمن را در نخلستان شناسایی و منهدم کرده و مدارک اطلاعاتی محور را جمع‌آوری کنید."),
			TEXT("معبر رودخانه کرخه را از نیروهای دشمن پاکسازی کرده و منطقه تخلیه جوخه را تا پایان عملیات حفظ کنید.")
		};
		static const TCHAR* StageDirectiveBodyEn[5] = {
			TEXT("Advance alongside Major Rostami's squad along the berm, clear forward trenches, and secure the Dehlavieh sector."),
			TEXT("Use your service rifle and grenades to neutralize enemy machine-gun bunkers and clear the trench line."),
			TEXT("Hold the defensive line against enemy counterattack waves and call 120mm mortar fire with [MMB]."),
			TEXT("Locate and neutralize enemy artillery spotters in the palm grove and secure operational intel."),
			TEXT("Clear hostile forces from the Karkheh river crossing and hold the squad extraction zone.")
		};

		const int32 StgIdx = FMath::Clamp(ActiveMissionStage - 1, 0, 4);
		FString FocusTitle = bEnglish ? StageDirectiveTitleEn[StgIdx] : StageDirectiveTitleFa[StgIdx];
		FString FocusBody  = bEnglish ? StageDirectiveBodyEn[StgIdx]  : StageDirectiveBodyFa[StgIdx];

		if (CurMission)
		{
			if (!CurMission->MissionBriefingTitle.IsEmpty())
			{
				const FString BT = CurMission->MissionBriefingTitle.ToString();
				if (bEnglish || UFarsiTextHelper::ContainsFarsiCharacters(BT)) FocusTitle = BT;
			}
			if (!CurMission->MissionBriefingText.IsEmpty())
			{
				const FString BB = CurMission->MissionBriefingText.ToString();
				if (bEnglish || UFarsiTextHelper::ContainsFarsiCharacters(BB)) FocusBody = BB;
			}
			else if (!CurMission->MissionDescription.IsEmpty())
			{
				const FString BD = CurMission->MissionDescription.ToString();
				if (bEnglish || UFarsiTextHelper::ContainsFarsiCharacters(BD)) FocusBody = BD;
			}
		}

		// Override with active Squad Command if recently issued
		if (UWorld* W = GetWorld())
		{
			if (USquadAICommandSubsystem* CmdSys = W->GetSubsystem<USquadAICommandSubsystem>())
			{
				if (CmdSys->GetActiveCommand() != ESquadTacticalCommand::None)
				{
					const FString CmdName = CmdSys->GetCommandDisplayName(CmdSys->GetActiveCommand());
					if (!CmdName.IsEmpty() && (bEnglish || UFarsiTextHelper::ContainsFarsiCharacters(CmdName)))
					{
						FocusTitle = bEnglish
							? FString::Printf(TEXT("SQUAD ORDER: %s"), *CmdName)
							: FString::Printf(TEXT("فرمان جوخه: %s"), *CmdName);
					}
				}
			}
		}

		// Override with live Radio Chatter when transmitting
		if (USquadAIRadioChatterSubsystem* RadioSys = USquadAIRadioChatterSubsystem::Get(this))
		{
			if (RadioSys->IsTransmitting())
			{
				const FString Msg = bEnglish ? RadioSys->LastMessageEnglish : RadioSys->LastMessageFarsi;
				if (!Msg.IsEmpty())
				{
					FocusTitle = bEnglish
						? FString::Printf(TEXT("RADIO // %s"), *RadioSys->LastCallSign)
						: FString::Printf(TEXT("بی‌سیم // %s"), *RadioSys->LastCallSign);
					FocusBody = Msg;
				}
			}
		}

		// Override with live Mission Zone Alert when active
		const float NowTime = GetWorld() ? GetWorld()->GetTimeSeconds() : 0.f;
		if (AlertBannerEndTime > 0.f && NowTime < AlertBannerEndTime && !AlertBannerText.IsEmpty())
		{
			if (bEnglish || UFarsiTextHelper::ContainsFarsiCharacters(AlertBannerText))
			{
				FocusTitle = bEnglish ? TEXT("TACTICAL SECTOR ALERT") : TEXT("هشدار عملیاتی محور");
				FocusBody  = AlertBannerText;
			}
		}

		// Override with active Story / Briefing / Debrief Card while NoteDisplayEndTime is active
		if (NoteDisplayEndTime > 0.f && NowTime < NoteDisplayEndTime)
		{
			if (!ActiveNoteTitle.IsEmpty() && (bEnglish || UFarsiTextHelper::ContainsFarsiCharacters(ActiveNoteTitle)))
			{
				FocusTitle = ActiveNoteTitle;
			}
			if (bActiveCardIsBriefing && BriefingSections.Num() > 0)
			{
				FString CombinedBrief;
				for (const FMissionSection& Sec : BriefingSections)
				{
					if (!Sec.Text.IsEmpty() && (bEnglish || UFarsiTextHelper::ContainsFarsiCharacters(Sec.Text)))
					{
						if (!CombinedBrief.IsEmpty()) CombinedBrief += TEXT(" • ");
						CombinedBrief += Sec.Text;
					}
				}
				if (!CombinedBrief.IsEmpty())
				{
					FocusBody = CombinedBrief;
				}
			}
			else if (ActiveNoteLines.Num() > 0)
			{
				FString CombinedLines;
				for (const FString& L : ActiveNoteLines)
				{
					if (!L.IsEmpty() && (bEnglish || UFarsiTextHelper::ContainsFarsiCharacters(L)))
					{
						if (!CombinedLines.IsEmpty()) CombinedLines += TEXT(" ");
						CombinedLines += L;
					}
				}
				if (!CombinedLines.IsEmpty())
				{
					FocusBody = CombinedLines;
				}
			}
		}

		bool bBackpackClicked = false;
		float FocusBottomY = FocusY;
		DrawFocusInstructionCard(LeftX, FocusY, FocusW, ActiveMissionStage, FocusTitle, FocusBody,
			bEnglish, 0.95f, S, Font, MouseX, MouseY, bLeftClick, bBackpackClicked, FocusBottomY);
		if (bBackpackClicked)
		{
			ToggleInventory();
		}

		// 4. RIGHT-LOWER MISSION PROGRESS MINI-CARD (.training-panel)
		if (bShowTutorialChecklist)
		{
			const float TrainW = FMath::Min(280.f * S, ScreenW * 0.213f);
			const float TrainX = ScreenW * 0.975f - TrainW;
			const float TrainY = ScreenH * 0.73f - 160.f * S;
			DrawTrainingProgressPanel(TrainX, TrainY, TrainW, ActiveMissionStage, bEnglish, 0.94f, S, Font);
		}

		// 5. BOTTOM-CENTER TACTICAL ACTION KEYCAP BANNER (.movehint)
		{
			FString MoveHeadline = bEnglish ? TEXT("ADVANCE TO MISSION SECTOR") : TEXT("پیشروی تاکتیکی به موضع ماموریت");
			FString MoveSubline  = bEnglish ? TEXT("Move with [WASD] • Press [V] for tactical path") : TEXT("با [WASD] حرکت کنید و برای نمایش مسیر کلید [V] را بزنید");
			FString MoveKey      = TEXT("V");

			APawn* PlayerPawn = CachedPlayerPawn.Get();
			if (PlayerPawn)
			{
				const FVector PLoc = PlayerPawn->GetActorLocation();
				bool bPromptFound = false;

				// 5a. Check downed ally nearby
				if (UWorld* W = GetWorld())
				{
					if (USoldierRegistrySubsystem* Reg = W->GetSubsystem<USoldierRegistrySubsystem>())
					{
						for (const TWeakObjectPtr<ASoldierCharacter>& WeakS : Reg->GetAllSoldiers())
						{
							ASoldierCharacter* SChar = WeakS.Get();
							if (SChar && SChar->IsAlly() && SChar->IsDowned() && FVector::Dist(PLoc, SChar->GetActorLocation()) < 360.f)
							{
								MoveHeadline = SquadAIHUDLocal(this, TEXT("Interaction"), TEXT("RevivePrompt"),
									TEXT("احیای همرزم مجروح در میدان"), TEXT("REVIVE WOUNDED ALLY"));
								MoveSubline  = bEnglish ? TEXT("Hold [E] near your wounded squadmate to revive") : TEXT("کلید [E] را نزدیک همرزم مجروح نگه دارید تا احیا شود");
								MoveKey      = TEXT("E");
								bPromptFound = true;
								break;
							}
						}
					}
				}
				// 5b. Check Ammo Crate nearby
				if (!bPromptFound)
				{
					for (const TWeakObjectPtr<AActor>& WeakCrate : GetCachedActorsOfClass(AAmmoCrateActor::StaticClass(), 0.5f))
					{
						if (AAmmoCrateActor* Crate = Cast<AAmmoCrateActor>(WeakCrate.Get()))
						{
							if (Crate->IsReady() && FVector::Dist(PLoc, Crate->GetActorLocation()) <= Crate->InteractionRadius)
							{
								MoveHeadline = SquadAIHUDLocal(this, TEXT("Interaction"), TEXT("ResupplyPrompt"),
									TEXT("برداشتن مهمات و تجدید خشاب"), TEXT("RESUPPLY AMMO & GRENADES"));
								MoveSubline  = bEnglish ? TEXT("Press [E] to refill magazines and grenades") : TEXT("برای پر کردن فشنگ و نارنجک کلید [E] را بزنید");
								MoveKey      = TEXT("E");
								bPromptFound = true;
								break;
							}
						}
					}
				}
				// 5c. Check Heavy Turret nearby
				if (!bPromptFound)
				{
					for (const TWeakObjectPtr<AActor>& WeakTurret : GetCachedActorsOfClass(AMountedTurretActor::StaticClass(), 0.5f))
					{
						if (AMountedTurretActor* Turret = Cast<AMountedTurretActor>(WeakTurret.Get()))
						{
							if (FVector::Dist(PLoc, Turret->GetActorLocation()) <= 300.f)
							{
								MoveHeadline = SquadAIHUDLocal(this, TEXT("Interaction"), TEXT("MountTurretPrompt"),
									TEXT("استقرار پشت تیربار سنگین دوشکا"), TEXT("MOUNT HEAVY DSHK TURRET"));
								MoveSubline  = bEnglish ? TEXT("Press [E] to man or exit the heavy machine gun") : TEXT("برای کنترل تیربار سنگین کلید [E] را بزنید");
								MoveKey      = TEXT("E");
								bPromptFound = true;
								break;
							}
						}
					}
				}
				// 5d. Check low player health with medkit
				if (!bPromptFound && GetPlayerHealthPercent(PlayerPawn) < 0.55f)
				{
					MoveHeadline = SquadAIHUDLocal(this, TEXT("Interaction"), TEXT("HealPrompt"),
						TEXT("استفاده از بسته کمک‌های اولیه"), TEXT("USE FIELD FIRST-AID KIT"));
					MoveSubline  = bEnglish ? TEXT("Press [F] to apply field dressing and restore health") : TEXT("برای مداوای فوری جراحات کلید [F] را بزنید");
					MoveKey      = TEXT("F");
					bPromptFound = true;
				}
				// 5e. Check low magazine ammo
				if (!bPromptFound)
				{
					if (USquadAIInventorySubsystem* Inv = USquadAIInventorySubsystem::Get(this))
					{
						const FSquadInventoryWeaponItem CurW = Inv->GetSelectedWeapon();
						if (CurW.WeaponID != FName("Knife") && CurW.ClipAmmo <= FMath::Max(1, CurW.MaxClipAmmo / 4) && CurW.ReserveAmmo > 0)
						{
							MoveHeadline = bEnglish ? TEXT("RELOAD SERVICE WEAPON") : TEXT("تعویض خشاب سلاح سازمانی");
							MoveSubline  = bEnglish ? TEXT("Press [R] to reload before your magazine runs dry") : TEXT("قبل از اتمام فشنگ کلید [R] را برای تعویض خشاب بزنید");
							MoveKey      = TEXT("R");
							bPromptFound = true;
						}
					}
				}
				// 5f. Check active combat in mission zone
				if (!bPromptFound && CurMission && CurMission->AliveEnemies > 0)
				{
					MoveHeadline = bEnglish ? TEXT("ENGAGE HOSTILES & CALL FIRE SUPPORT") : TEXT("سنگرگیری و اجرای آتش روی دشمن");
					MoveSubline  = bEnglish
						? TEXT("Hold [RMB] to aim, [LMB] to fire, [G] grenade, [MMB] mortar")
						: TEXT("کلیک راست مگسک، کلیک چپ شلیک، [G] نارنجک و [MMB] آتش خمپاره");
					MoveKey      = TEXT("RMB");
					bPromptFound = true;
				}
			}

			DrawMoveHintBanner(ScreenW * 0.50f, ScreenH * 0.85f, MoveHeadline, MoveSubline, MoveKey,
				bEnglish, 0.95f, S, Font, PC);
		}

		// 6. 3D WORLD WAYPOINT (.waypoint) & ALLY MARKER (.ally) IN MISSION MODE
		{
			const float SafeMinX = LeftX + StepsW + 85.f * S;
			const float SafeMaxX = ScreenW - 430.f * S;
			const float SafeMinY = 120.f * S;
			const float SafeMaxY = ScreenH - 255.f * S;

			FVector2D WayScreen(ScreenW * 0.54f, ScreenH * 0.50f);
			int32 WayMetres = 45;
			bool bDrawWaypoint = (CurMission != nullptr);

			if (PC && CurMission)
			{
				const FVector Focus = CurMission->GetActorLocation() + FVector(0.f, 0.f, 110.f);
				FVector2D Projected;
				if (PC->ProjectWorldLocationToScreen(Focus, Projected))
				{
					WayScreen.X = FMath::Clamp(Projected.X, SafeMinX, SafeMaxX);
					WayScreen.Y = FMath::Clamp(Projected.Y, SafeMinY, SafeMaxY);
				}
				if (APawn* P = PC->GetPawn())
				{
					WayMetres = FMath::Max(1, FMath::RoundToInt(FVector::Dist(P->GetActorLocation(), CurMission->GetActorLocation()) / 100.f));
				}
			}

			if (bDrawWaypoint)
			{
				const float PinSz = 40.f * S;
				const float PinX = WayScreen.X - PinSz * 0.5f;
				const float PinY = WayScreen.Y - PinSz - 12.f * S;

				if (UTexture2D* FirePin = GetUITexture(FName(TEXT("IconObjectiveFire3D"))))
				{
					DrawTexture(FirePin, PinX + 1.5f * S, PinY + 3.0f * S, PinSz, PinSz, 0.f, 0.f, 1.f, 1.f, FLinearColor(0.f, 0.f, 0.f, 0.65f));
					DrawTexture(FirePin, PinX, PinY, PinSz, PinSz, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
				}
				else
				{
					Draw3DRaisedMedallion(WayScreen.X, PinY + PinSz * 0.5f, PinSz * 0.45f, TEXT("◆"), true, false, 1.f, S, Font);
				}

				const FString WayName = bEnglish ? StageDirectiveTitleEn[StgIdx] : StageDirectiveTitleFa[StgIdx];
				const FString WayDist = bEnglish
					? FString::Printf(TEXT("%d m"), WayMetres)
					: FString::Printf(TEXT("%s متر"), *UFarsiTextHelper::ToPersianDigits(FString::FromInt(WayMetres)));
				DrawFarsiText3D(WayName, FSquadAIHUDPalette::TextWhite(),
					WayScreen.X - 85.f * S, WayScreen.Y - 10.f * S, 170.f * S, Font, 0.68f * S, true, false, 18.f * S, 1.0f * S);
				DrawFarsiText3D(WayDist, FSquadAIHUDPalette::SRGB(233, 223, 201, 0.98f),
					WayScreen.X - 50.f * S, WayScreen.Y + 7.f * S, 100.f * S, Font, 0.64f * S, true, false, 16.f * S, 1.0f * S);
			}

			// Friendly ally world tag (.ally: ◆ فرمانده · سرگرد رستمی / ۱۸ متر)
			FVector2D AllyScreen(ScreenW * 0.39f, ScreenH * 0.50f);
			int32 AllyMetres = 18;
			bool bDrawAlly = false;
			AActor* AllyActor = FindCachedLeader();
			if (PC && AllyActor)
			{
				const FVector AllyPos = AllyActor->GetActorLocation() + FVector(0.f, 0.f, 110.f);
				FVector2D ProjAlly;
				if (PC->ProjectWorldLocationToScreen(AllyPos, ProjAlly))
				{
					AllyScreen = ProjAlly;
					bDrawAlly = true;
					if (APawn* P = PC->GetPawn())
					{
						AllyMetres = FMath::Max(1, FMath::RoundToInt(FVector::Dist(P->GetActorLocation(), AllyActor->GetActorLocation()) / 100.f));
					}
				}
			}
			if (AllyScreen.X < SafeMinX || AllyScreen.X > SafeMaxX || AllyScreen.Y < SafeMinY || AllyScreen.Y > SafeMaxY
				|| (bDrawWaypoint && FVector2D::Distance(AllyScreen, WayScreen) < 110.f * S))
			{
				bDrawAlly = false;
			}
			if (bDrawAlly)
			{
				const FString AllyName = bEnglish ? TEXT("◆ CMD · MAJ. ROSTAMI") : TEXT("◆ فرمانده · سرگرد رستمی");
				const FString AllyDist = bEnglish
					? FString::Printf(TEXT("%d m"), AllyMetres)
					: FString::Printf(TEXT("%s متر"), *UFarsiTextHelper::ToPersianDigits(FString::FromInt(AllyMetres)));
				DrawFarsiText3D(AllyName, FSquadAIHUDPalette::CyanAlly(),
					AllyScreen.X - 80.f * S, AllyScreen.Y - 10.f * S, 160.f * S, Font, 0.62f * S, true, false, 16.f * S, 1.0f * S);
				DrawFarsiText3D(AllyDist, FSquadAIHUDPalette::TextWhite(),
					AllyScreen.X - 45.f * S, AllyScreen.Y + 6.f * S, 90.f * S, Font, 0.58f * S, true, false, 14.f * S, 1.0f * S);
			}
		}
		return;
	}

	const bool bSpaceAllowed = !Tut || Tut->bAllowSpaceToAdvance;
	const bool bAdvanceKeyPressed = PC && (
		PC->WasInputKeyJustPressed(EKeys::F)
		|| PC->WasInputKeyJustPressed(EKeys::Enter)
		|| (bSpaceAllowed && PC->WasInputKeyJustPressed(EKeys::SpaceBar)));

	// Resolve current tutorial beat and map to the 5 reference stages in index.html
	const bool bAwaitingSkip = Tut->IsAwaitingSkipAnswer();
	FSquadAITutorialBeat Beat;
	const bool bHasBeat = !bAwaitingSkip && Tut->GetCurrentBeat(Beat);

	int32 ActiveStage = 1;
	float ProgressPct = 0.21f;
	if (bHasBeat)
	{
		const float SubFrac = FMath::Clamp(
			static_cast<float>(FMath::Max(0, Tut->GetCurrentProgress())) / static_cast<float>(FMath::Max(1, Beat.RequiredCount)),
			0.0f, 1.0f);
		switch (Beat.Step)
		{
		case ESquadAITutorialStep::UI_Objective:
		case ESquadAITutorialStep::UI_Compass:
		case ESquadAITutorialStep::Task_Move:
			ActiveStage = 1;
			ProgressPct = 0.21f + 0.17f * SubFrac;
			break;
		case ESquadAITutorialStep::UI_Squad:
			ActiveStage = 2;
			ProgressPct = 0.40f + 0.15f * SubFrac;
			break;
		case ESquadAITutorialStep::UI_Weapon:
		case ESquadAITutorialStep::Task_ShootCans:
			ActiveStage = 3;
			ProgressPct = 0.60f + 0.18f * SubFrac;
			break;
		case ESquadAITutorialStep::Task_Grenade:
			ActiveStage = 4;
			ProgressPct = 0.80f + 0.12f * SubFrac;
			break;
		case ESquadAITutorialStep::UI_Artillery:
		case ESquadAITutorialStep::Task_Artillery:
			ActiveStage = 5;
			ProgressPct = 0.92f + 0.08f * SubFrac;
			break;
		default:
			ActiveStage = 1;
			ProgressPct = 0.21f;
			break;
		}
	}

	// Smooth slide/fade-in when beat changes
	const int32 StepKey = bAwaitingSkip ? 0 : static_cast<int32>(Beat.Step);
	if (TutLastStepSeen != StepKey)
	{
		TutLastStepSeen = StepKey;
		TutCardIntroT = 0.f;
	}
	else if (TutCardIntroT < 1.f)
	{
		TutCardIntroT = FMath::Min(1.f, TutCardIntroT + DeltaTime / 0.28f);
	}
	const float IntroEase = TutCardIntroT * TutCardIntroT * (3.f - 2.f * TutCardIntroT);
	const float PanelAlpha = 0.75f + 0.25f * IntroEase;

	// Compute center rail & bottom stack so guide subtitle sits cleanly above .movehint
	ComputeTutorialRail(ScreenW, S);
	const float SubBlockH = MeasureGuideSubtitleBlock(Font, bEnglish);
	ComputeTutorialStack(ScreenH, S, 0.f, 96.f * S, SubBlockH);

	const float LeftX = FMath::Max(24.f * S, ScreenW * 0.0235f);

	// =========================================================================
	// 1. TOP-LEFT OPERATION MASTHEAD PLAQUE (.operation-banner)
	// =========================================================================
	const float OpY = ScreenH * 0.028f;
	const float OpW = FMath::Min(510.f * S, ScreenW * 0.39f);
	const float OpH = 83.f * S;
	DrawOperationBanner(LeftX, OpY, OpW, OpH, ProgressPct, bEnglish, 0.96f, S, Font);

	// =========================================================================
	// 2. LEFT 5-STEP TUTORIAL SEQUENCE PANEL (.tutorial)
	// =========================================================================
	const float StepsY = FMath::Max(OpY + OpH + 10.f * S, ScreenH * 0.178f);
	const float StepsW = FMath::Min(460.f * S, ScreenW * 0.358f);
	float StepsBottomY = StepsY;
	if (bShowTutorialChecklist)
	{
		DrawTutorialStepsPanel(LeftX, StepsY, StepsW, ActiveStage, bEnglish, 0.95f, S, Font, StepsBottomY);
	}

	// =========================================================================
	// 3. LEFT-MIDDLE FOCUS STEP INSTRUCTION CARD (.focus-instruction)
	// =========================================================================
	const float FocusY = FMath::Max(StepsBottomY + 10.f * S, ScreenH * 0.565f);
	const float FocusW = FMath::Min(365.f * S, ScreenW * 0.285f);
	FString FocusTitle = bEnglish ? TEXT("ADVANCE IN FORWARD TRENCH") : TEXT("حرکت در سنگر خط مقدم");
	FString FocusBody  = bEnglish
		? TEXT("Follow Major Rostami along the trench boards to reach the firing range position.")
		: TEXT("پشت سر سرگرد رستمی روی تخته‌های سنگر حرکت کنید و به موضع میدان تیر برسید.");
	if (bAwaitingSkip)
	{
		FocusTitle = bEnglish ? TEXT("SKIP COMBAT TUTORIAL?") : TEXT("رد کردن آموزش رزم؟");
		FocusBody  = bEnglish
			? TEXT("Press [Y] or click SKIP TUTORIAL below to skip, or press [F] to continue training.")
			: TEXT("برای رد کردن آموزش کلید [Y] یا دکمه رد کردن را بزنید، و برای ادامه آموزش کلید [F] را فشار دهید.");
	}
	else if (bHasBeat && !Beat.TitleFa.IsEmpty())
	{
		FocusTitle = bEnglish ? Beat.TitleEn : Beat.TitleFa;
		FocusBody  = bEnglish ? Beat.BodyEn  : Beat.BodyFa;
	}
	bool bContinueClicked = false;
	float FocusBottomY = FocusY;
	DrawFocusInstructionCard(LeftX, FocusY, FocusW, ActiveStage, FocusTitle, FocusBody,
		bEnglish, PanelAlpha, S, Font, MouseX, MouseY, bLeftClick, bContinueClicked, FocusBottomY);

	// =========================================================================
	// 4. RIGHT-LOWER TRAINING PROGRESS MINI-CARD (.training-panel)
	// =========================================================================
	if (bShowTutorialChecklist)
	{
		const float TrainW = FMath::Min(280.f * S, ScreenW * 0.213f);
		const float TrainX = ScreenW * 0.975f - TrainW;
		const float TrainY = ScreenH * 0.73f - 160.f * S;
		DrawTrainingProgressPanel(TrainX, TrainY, TrainW, ActiveStage, bEnglish, 0.94f, S, Font);
	}

	// =========================================================================
	// 5. BOTTOM-CENTER MOVEMENT / ACTION KEYCAP BANNER (.movehint)
	// =========================================================================
	{
		FString MoveHeadline = bEnglish ? TEXT("ADVANCE THROUGH THE TRENCH") : TEXT("در سنگر به‌سوی هدف حرکت کنید");
		FString MoveSubline  = bEnglish ? TEXT("Hold [W] to advance along the trench boards") : TEXT("برای پیشروی روی تخته‌های سنگر، [W] را نگه دارید");
		FString MoveKey      = TEXT("W");

		if (bHasBeat)
		{
			if (Beat.Step == ESquadAITutorialStep::Task_ShootCans || Beat.Step == ESquadAITutorialStep::UI_Weapon)
			{
				MoveHeadline = bEnglish ? TEXT("AIM G3A3 & SHOOT CANS") : TEXT("قوطی‌های روی خاکریز را هدف بگیرید");
				MoveSubline  = bEnglish ? TEXT("Hold [RMB] for iron sights, click [LMB] to fire") : TEXT("کلیک راست برای مگسک ژ-۳ و کلیک چپ برای شلیک");
				MoveKey      = TEXT("RMB");
			}
			else if (Beat.Step == ESquadAITutorialStep::Task_Grenade)
			{
				MoveHeadline = bEnglish ? TEXT("THROW GRENADE INTO DRUM") : TEXT("نارنجک را به درون بشکه پرتاب کنید");
				MoveSubline  = bEnglish ? TEXT("Hold [G] to aim arc, release into open drum") : TEXT("کلید [G] را نگه دارید و در دهانه بشکه رها کنید");
				MoveKey      = TEXT("G");
			}
			else if (Beat.Step == ESquadAITutorialStep::Task_Artillery || Beat.Step == ESquadAITutorialStep::UI_Artillery)
			{
				MoveHeadline = bEnglish ? TEXT("CALL 120MM MORTAR FIRE") : TEXT("پشتیبانی آتش خمپاره را فراخوانی کنید");
				MoveSubline  = bEnglish ? TEXT("Aim at target area and press [MMB]") : TEXT("روی موضع هدف نگاه کنید و کلید وسط [MMB] را بزنید");
				MoveKey      = TEXT("MMB");
			}
		}

		DrawMoveHintBanner(ScreenW * 0.50f, ScreenH * 0.85f, MoveHeadline, MoveSubline, MoveKey,
			bEnglish, PanelAlpha, S, Font, PC);
	}

	// =========================================================================
	// 6. HIGHLIGHT CALLOUT FRAME ON REFERENCED HUD WIDGET (if UI beat)
	// =========================================================================
	if (bHasBeat && !Beat.HighlightElement.IsNone() && TutorialUIRects.Contains(Beat.HighlightElement))
	{
		const FVector4 R = TutorialUIRects[Beat.HighlightElement];
		const float Pad = 5.f * S;
		const float HX = R.X - Pad, HY = R.Y - Pad, HW = R.Z + Pad * 2.f, HH = R.W + Pad * 2.f;
		const float Pulse = 0.65f + 0.35f * FMath::Sin(GetWorld()->GetTimeSeconds() * 4.5f);
		const FLinearColor Gold = FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::BracketGold(), Pulse);
		DrawCornerBrackets(HX, HY, HW, HH, Gold, 16.f * S, 2.2f * S);
		DrawRect(FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::BracketGold(), 0.12f * Pulse), HX, HY, HW, HH);
	}

	// =========================================================================
	// 7. 3D WORLD WAYPOINT (.waypoint) & ALLY MARKER (.ally)
	// =========================================================================
	{
		const float SafeMinX = LeftX + StepsW + 85.f * S;
		const float SafeMaxX = ScreenW - 430.f * S;
		const float SafeMinY = 120.f * S;
		const float SafeMaxY = ScreenH - 255.f * S;

		FVector2D WayScreen(ScreenW * 0.54f, ScreenH * 0.50f);
		int32 WayMetres = 45;
		bool bDrawWaypoint = true;

		if (PC && !Tut->CurrentTaskWorldFocus.IsNearlyZero())
		{
			const FVector Focus = Tut->CurrentTaskWorldFocus + FVector(0.f, 0.f, 90.f);
			FVector2D Projected;
			if (PC->ProjectWorldLocationToScreen(Focus, Projected))
			{
				WayScreen.X = FMath::Clamp(Projected.X, SafeMinX, SafeMaxX);
				WayScreen.Y = FMath::Clamp(Projected.Y, SafeMinY, SafeMaxY);
			}
			if (APawn* P = PC->GetPawn())
			{
				WayMetres = FMath::Max(1, FMath::RoundToInt(FVector::Dist(P->GetActorLocation(), Tut->CurrentTaskWorldFocus) / 100.f));
			}
		}

		if (bDrawWaypoint)
		{
			const float PinSz = 40.f * S;
			const float PinX = WayScreen.X - PinSz * 0.5f;
			const float PinY = WayScreen.Y - PinSz - 12.f * S;

			if (UTexture2D* FirePin = GetUITexture(FName(TEXT("IconObjectiveFire3D"))))
			{
				DrawTexture(FirePin, PinX + 1.5f * S, PinY + 3.0f * S, PinSz, PinSz, 0.f, 0.f, 1.f, 1.f, FLinearColor(0.f, 0.f, 0.f, 0.65f));
				DrawTexture(FirePin, PinX, PinY, PinSz, PinSz, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
			}
			else
			{
				Draw3DRaisedMedallion(WayScreen.X, PinY + PinSz * 0.5f, PinSz * 0.45f, TEXT("◆"), true, false, 1.f, S, Font);
			}

			FString WayName = bEnglish ? TEXT("TRENCH FIRING RANGE") : TEXT("موضع تمرین سنگر");
			if (bHasBeat)
			{
				const int32 CurProg = FMath::Max(0, Tut->GetCurrentProgress());
				if (Beat.Step == ESquadAITutorialStep::Task_ShootCans || Beat.Step == ESquadAITutorialStep::UI_Weapon)
				{
					WayName = bEnglish
						? FString::Printf(TEXT("TARGET CANS (%d/3)"), CurProg)
						: FString::Printf(TEXT("قوطی‌های هدف (%s/۳)"), *UFarsiTextHelper::ToPersianDigits(FString::FromInt(CurProg)));
				}
				else if (Beat.Step == ESquadAITutorialStep::Task_Grenade)
				{
					WayName = bEnglish ? TEXT("GRENADE TARGET DRUM") : TEXT("بشکه هدف نارنجک");
				}
				else if (Beat.Step == ESquadAITutorialStep::Task_Artillery || Beat.Step == ESquadAITutorialStep::UI_Artillery)
				{
					WayName = bEnglish ? TEXT("MORTAR TARGET ZONE") : TEXT("موضع هدف خمپاره");
				}
			}
			const FString WayDist = bEnglish
				? FString::Printf(TEXT("%d m"), WayMetres)
				: FString::Printf(TEXT("%s متر"), *UFarsiTextHelper::ToPersianDigits(FString::FromInt(WayMetres)));
			DrawFarsiText3D(WayName, FSquadAIHUDPalette::TextWhite(),
				WayScreen.X - 75.f * S, WayScreen.Y - 10.f * S, 150.f * S, Font, 0.70f * S, true, false, 18.f * S, 1.0f * S);
			DrawFarsiText3D(WayDist, FSquadAIHUDPalette::SRGB(233, 223, 201, 0.98f),
				WayScreen.X - 50.f * S, WayScreen.Y + 7.f * S, 100.f * S, Font, 0.64f * S, true, false, 16.f * S, 1.0f * S);
		}

		// Friendly ally world tag (.ally: ◆ فرمانده · سرگرد رستمی / ۱۸ متر)
		FVector2D AllyScreen(ScreenW * 0.39f, ScreenH * 0.50f);
		int32 AllyMetres = 18;
		bool bDrawAlly = true;
		AActor* AllyActor = FindCachedLeader();
		if (!AllyActor)
		{
			for (const TWeakObjectPtr<AActor>& WeakIt : GetCachedActorsOfClass(ATutorialGuideActor::StaticClass(), 1.0f))
			{
				if (AActor* G = WeakIt.Get()) { AllyActor = G; break; }
			}
		}
		if (PC && AllyActor)
		{
			const FVector AllyPos = AllyActor->GetActorLocation() + FVector(0.f, 0.f, 110.f);
			FVector2D ProjAlly;
			if (PC->ProjectWorldLocationToScreen(AllyPos, ProjAlly))
			{
				AllyScreen = ProjAlly;
				if (APawn* P = PC->GetPawn())
				{
					AllyMetres = FMath::Max(1, FMath::RoundToInt(FVector::Dist(P->GetActorLocation(), AllyActor->GetActorLocation()) / 100.f));
				}
			}
		}
		// Never draw AllyScreen if it projects over any left/right/top/bottom HUD panel or within 120px of WayScreen
		if (AllyScreen.X < SafeMinX || AllyScreen.X > SafeMaxX || AllyScreen.Y < SafeMinY || AllyScreen.Y > SafeMaxY
			|| FVector2D::Distance(AllyScreen, WayScreen) < 110.f * S)
		{
			bDrawAlly = false;
		}
		if (bDrawAlly)
		{
			const FString AllyName = bEnglish ? TEXT("◆ CMD · MAJ. ROSTAMI") : TEXT("◆ فرمانده · سرگرد رستمی");
			const FString AllyDist = bEnglish
				? FString::Printf(TEXT("%d m"), AllyMetres)
				: FString::Printf(TEXT("%s متر"), *UFarsiTextHelper::ToPersianDigits(FString::FromInt(AllyMetres)));
			DrawFarsiText3D(AllyName, FSquadAIHUDPalette::CyanAlly(),
				AllyScreen.X - 80.f * S, AllyScreen.Y - 10.f * S, 160.f * S, Font, 0.62f * S, true, false, 16.f * S, 1.0f * S);
			DrawFarsiText3D(AllyDist, FSquadAIHUDPalette::TextWhite(),
				AllyScreen.X - 45.f * S, AllyScreen.Y + 6.f * S, 90.f * S, Font, 0.58f * S, true, false, 14.f * S, 1.0f * S);
		}
	}

	// =========================================================================
	// 8. GUIDE SUBTITLE BAND & BUTTON / KEY INTERACTION HANDLING
	// =========================================================================
	DrawGuideSubtitle(ScreenW, ScreenH, Font, bEnglish);

	// Check click on [ESC] SKIP TUTORIAL in .footer-actions (positioned between .controls and .solo-badge)
	const float StatsW = FMath::Min(318.f * S, ScreenW * 0.245f);
	const float StamY = ScreenH * 0.97f - 14.f * S;
	const float StatsY = StamY - 5.f * S - 54.f * S;
	const float CtrlY = StatsY - 6.f * S - 31.f * S;
	const float FootActX = LeftX;
	const float FootActH = 28.f * S;
	const float FootActY = CtrlY - 6.f * S - FootActH;
	const float FootActW = StatsW;
	const float SkipSlotX = FootActX + (FootActW * 2.f / 3.f);
	const bool bSkipClicked = bLeftClick
		&& (MouseX >= SkipSlotX && MouseX <= FootActX + FootActW && MouseY >= FootActY && MouseY <= FootActY + FootActH);

	const bool bConfirmSkipKey = bAwaitingSkip && PC && PC->WasInputKeyJustPressed(EKeys::Y);
	const bool bCancelSkipKey  = bAwaitingSkip && PC && PC->WasInputKeyJustPressed(EKeys::N);

	if (bSkipClicked || bConfirmSkipKey)
	{
		if (bAwaitingSkip)
		{
			Tut->AnswerSkipPrompt(true);
		}
		else
		{
			Tut->SkipTutorial();
		}
		return;
	}

	if (bContinueClicked || bAdvanceKeyPressed || bCancelSkipKey)
	{
		if (bAwaitingSkip)
		{
			Tut->AnswerSkipPrompt(false);
			return;
		}
		if (bHasBeat && Beat.bFullPause)
		{
			Tut->AcknowledgeCurrentBeat();
			return;
		}
	}

	// Custom high-visibility gold tactical cursor when mouse cursor is active
	if (PC && PC->bShowMouseCursor)
	{
		const float CX = MouseX;
		const float CY = MouseY;
		const float A = 18.f * S;
		auto Arrow = [&](float Off, const FLinearColor& Col, float Thick)
		{
			DrawLine(CX + Off, CY + Off, CX + Off, CY + A + Off, Col, Thick);
			DrawLine(CX + Off, CY + A + Off, CX + A * 0.62f + Off, CY + A * 0.72f + Off, Col, Thick);
			DrawLine(CX + A * 0.62f + Off, CY + A * 0.72f + Off, CX + Off, CY + Off, Col, Thick);
			DrawLine(CX + A * 0.36f + Off, CY + A * 0.70f + Off, CX + A * 0.62f + Off, CY + A * 1.18f + Off, Col, Thick);
		};
		Arrow(1.5f * S, FLinearColor(0.f, 0.f, 0.f, 0.85f), 3.4f * S);
		Arrow(0.f, FSquadAIHUDPalette::BracketGold(), 2.2f * S);
	}
}

// ===== S17-NOTE =====
void AQuestNativeHUD::ShowFallenNote(const FText& Title, const FText& Body, float Duration, int32 FoundCount, int32 TotalCount)
{
	const bool bEnglish = SquadAIHUDIsEnglish(this);
	ActiveNoteTitle = Title.IsEmpty()
		? (bEnglish ? FString(TEXT("A fallen soldier's note")) : FString(TEXT("یادداشت یک سرباز")))
		: Title.ToString();
	ActiveNoteLines.Reset();
	Body.ToString().ParseIntoArrayLines(ActiveNoteLines, false);
	if (ActiveNoteLines.Num() > 8) ActiveNoteLines.SetNum(8); // keep the card readable
	ActiveNoteCounter = bEnglish
		? FString::Printf(TEXT("Note %d of %d"), FoundCount, TotalCount)
		: FString::Printf(TEXT("یادداشت %d از %d"), FoundCount, TotalCount);
	bActiveCardIsBriefing = false; // S17-STORY
	BriefingSections.Reset();      // S23-BRIEF: a fallen note is never a staged briefing
	bActiveCardIsDebrief = false;  // S23-BRIEF: and never a debrief
	DebriefGradeLetter.Empty();
	const float Now = GetWorld() ? GetWorld()->GetTimeSeconds() : 0.f;
	NoteDisplayStartTime = Now;
	NoteDisplayEndTime = Now + FMath::Max(3.f, Duration);
}

bool AQuestNativeHUD::IsReaderCardOpen() const
{
	// S18-INTRO3: NoteDisplayEndTime covers both the fallen-note card and the
	// S17-STORY mission briefing, which share the overlay.
	const UWorld* World = GetWorld();
	if (!World || NoteDisplayEndTime <= 0.f) return false;
	return World->GetTimeSeconds() < NoteDisplayEndTime;
}

void AQuestNativeHUD::DrawFallenNoteOverlay(float SW, float SH, UFont* Font)
{
	UWorld* World = GetWorld();
	if (!World || NoteDisplayEndTime <= 0.f) return;
	const float Now = World->GetTimeSeconds();
	if (Now >= NoteDisplayEndTime)
	{
		NoteDisplayEndTime = -1.f;
		return;
	}

	// Fade in fast, fade out on the last stretch.
	const float Shown = Now - NoteDisplayStartTime;
	const float Remaining = NoteDisplayEndTime - Now;
	float Alpha = 1.f;
	if (Shown < 0.35f) Alpha = Shown / 0.35f;
	else if (Remaining < 1.2f) Alpha = Remaining / 1.2f;
	Alpha = FMath::Clamp(Alpha, 0.f, 1.f);

	// S19-MISSUI: the note/briefing body wrapped instead of being squeezed into a
	// fixed 26 px slot per line. A long sentence in the designer's note was
	// shrink-to-fit inside one slot (the same defect as the lesson card), and the
	// panel's height never matched what the text actually occupied. Each source
	// line now wraps to the panel width and the cursor advances by the height it
	// really used.
	const float S = GameUIScale;
	const float Pad = 18.f * S;
	const float TitleH = 34.f * S;
	const float PanelW = FMath::Min(660.f * S, SW * 0.62f);
	const float TxtW = PanelW - Pad * 2.f;
	const float BodyScale = 1.05f * S;
	const float LineGap = 6.f * S;
	const float CounterH = 24.f * S;

	TArray<FTutorialTextBlock> NoteBlocks;
	float BodyH = 0.f;
	for (const FString& Line : ActiveNoteLines)
	{
		if (Line.IsEmpty())
		{
			NoteBlocks.Add(FTutorialTextBlock());
			continue;
		}
		const FTutorialTextBlock B = WrapTutorialText(Line, Font, BodyScale, TxtW, 3);
		NoteBlocks.Add(B);
		BodyH += B.BlockH + LineGap;
	}
	if (!NoteBlocks.IsEmpty())
	{
		BodyH -= LineGap; // no trailing gap
	}

	const float PanelH = Pad * 2.f + TitleH + 8.f * S + BodyH + (ActiveNoteCounter.IsEmpty() ? 0.f : CounterH);
	const float X = (SW - PanelW) * 0.5f;
	// S19-MISSUI: the note is a centre-column panel, so it obeys the two things
	// that already own that column: it stays below whatever the top-centre notice
	// lane is using this frame, and above the onboarding reel. It used to be
	// pinned to 60% of the screen height, which put it straight through the
	// onboarding card whenever a story note fired during the opening hints.
	float Y = FMath::Max(SH * 0.60f - PanelH * 0.5f, SH * 0.18f);
	Y = FMath::Max(Y, (TopNoticeBottomY > 0.f) ? (TopNoticeBottomY + 12.f * S) : 0.f);
	if (OnboardingCardY > 0.f)
	{
		Y = FMath::Min(Y, FMath::Max(SH * 0.18f, OnboardingCardY - PanelH - 12.f * S));
	}

	// Aged-paper dark card + brass spine (matches the defend banner styling).
	DrawRect(FLinearColor(0.055f, 0.048f, 0.036f, 0.84f * Alpha), X, Y, PanelW, PanelH);
	const FLinearColor Spine = bActiveCardIsBriefing
		? FLinearColor(0.42f, 0.55f, 0.22f, 0.92f * Alpha)  // military green: briefing
		: FLinearColor(0.85f, 0.68f, 0.25f, 0.92f * Alpha); // brass: fallen note
	DrawRect(Spine, X, Y, 4.f * GameUIScale, PanelH);

	float CursorY = Y + Pad;
	DrawFarsiTextBounded(ActiveNoteTitle, FLinearColor(0.95f, 0.80f, 0.35f, Alpha), X + Pad, CursorY, TxtW, Font, 1.35f * S, true, true);
	CursorY += TitleH + 8.f * S;
	for (const FTutorialTextBlock& B : NoteBlocks)
	{
		if (!B.IsEmpty())
		{
			DrawTutorialTextBlock(B, FLinearColor(0.93f, 0.90f, 0.82f, Alpha), X + Pad, CursorY, TxtW, Font, BodyScale);
			CursorY += B.BlockH + LineGap;
		}
	}
	if (!ActiveNoteCounter.IsEmpty())
	{
		// S19-MISSUI: bounded and right-aligned like the rest of the mission text,
		// instead of an unbounded run off the panel's padding.
		float CW = 0.f, CH = 0.f;
		GetFarsiTextSize(ActiveNoteCounter, Font, 0.9f * S, CW, CH);
		DrawFarsiTextBounded(ActiveNoteCounter, FLinearColor(0.62f, 0.58f, 0.50f, Alpha * 0.9f),
			X + PanelW - Pad - CW - 4.f * S, Y + PanelH - Pad - CH, CW + 8.f * S, Font, 0.9f * S, true, false);
	}
}

// ===== S23-BRIEF: the staged mission briefing =====
// Not one flat paragraph: the briefing lands section by section. Each section
// arrives with a small slide+fade, its header first and then the line typing
// itself out with a blinking cursor, on a scanlined field-radio panel with a
// green spine and a live progress bar. The card owns the frame (letterbox
// veil) while it plays, self-paces from the section count, and clears with
// the same note timer as everything else. Plain bodies never come here - they
// keep the classic DrawFallenNoteOverlay card.
void AQuestNativeHUD::DrawMissionBriefingOverlay(float SW, float SH, UFont* Font)
{
	UWorld* World = GetWorld();
	if (!World || NoteDisplayEndTime <= 0.f) return;
	const float Now = World->GetTimeSeconds();
	if (Now >= NoteDisplayEndTime)
	{
		NoteDisplayEndTime = -1.f;
		BriefingSections.Reset();
		return;
	}
	const float Shown = Now - NoteDisplayStartTime;
	const float Remaining = NoteDisplayEndTime - Now;
	float Alpha = 1.f;
	if (Shown < 0.35f) Alpha = Shown / 0.35f;
	else if (Remaining < 1.0f) Alpha = Remaining / 1.0f;
	Alpha = FMath::Clamp(Alpha, 0.f, 1.f);

	const bool bBrass = bActiveCardIsDebrief;   // the debrief wears brass, the briefing green
	const float S = GameUIScale;
	const float Pad = 20.f * S;
	const float PanelW = FMath::Min(680.f * S, SW * 0.62f);
	const float TxtW = PanelW - Pad * 2.f;
	const float HeaderH = 30.f * S;
	const float HeadScale = 0.95f * S;
	const float BodyScale = 1.05f * S;
	const float SectionGap = 10.f * S;

	// The ACT section (when the land wrote one) rides the header band as the
	// act counter; everything else is body copy, staged in order.
	FString ActTag;
	TArray<FMissionSection> Body;
	for (const FMissionSection& Sec : BriefingSections)
	{
		if (Sec.Header == TEXT("ACT")) { ActTag = Sec.Text.ToUpper(); }
		else { Body.Add(Sec); }
	}

	// Geometry pass: every section's real wrapped height, measured with the
	// same sizer the drawing uses (S19-MISSUI rule - never guess a slot).
	struct FStaged { int32 Idx; float Y; float RevealAt; };
	TArray<FStaged> Staged;
	float CursorY = 0.f;
	for (int32 Idx = 0; Idx < Body.Num(); ++Idx)
	{
		float HW = 0.f, HH = 0.f;
		GetFarsiTextSize(Body[Idx].Header, Font, HeadScale, HW, HH);
		const FTutorialTextBlock Block = WrapTutorialText(Body[Idx].Text, Font, BodyScale, TxtW, 3);
		FStaged St;
		St.Idx = Idx;
		St.Y = CursorY;
		St.RevealAt = 0.45f + Idx * 1.15f;
		Staged.Add(St);
		CursorY += HH + 3.f * S + Block.BlockH + SectionGap;
	}
	const float BodyH = FMath::Max(0.f, CursorY - SectionGap);

	const float PanelH = Pad * 2.f + HeaderH + 8.f * S + BodyH + 10.f * S;
	const float X = (SW - PanelW) * 0.5f;
	float Y = FMath::Max(SH * 0.58f - PanelH * 0.5f, SH * 0.16f);
	Y = FMath::Max(Y, (TopNoticeBottomY > 0.f) ? (TopNoticeBottomY + 12.f * S) : 0.f);

	// The card owns the frame while it plays: letterbox veil for readability.
	DrawRect(FLinearColor(0.f, 0.f, 0.f, 0.42f * Alpha), 0.f, 0.f, SW, SH);

	// Panel, green briefing spine, scanlines (the field-radio feel).
	DrawRect(FLinearColor(0.045f, 0.055f, 0.040f, 0.92f * Alpha), X, Y, PanelW, PanelH);
	DrawRect(bBrass ? FLinearColor(0.80f, 0.62f, 0.22f, 0.95f * Alpha)
		: FLinearColor(0.42f, 0.55f, 0.22f, 0.95f * Alpha), X, Y, 4.f * S, PanelH);
	for (float Sy = Y + 4.f * S; Sy < Y + PanelH; Sy += 7.f * S)
	{
		DrawRect(FLinearColor(0.f, 0.f, 0.f, 0.05f * Alpha), X, Sy, PanelW, 1.f * S);
	}

	// Header band: mission title (brass), the act counter right-aligned.
	DrawFarsiTextBounded(ActiveNoteTitle, FLinearColor(0.95f, 0.80f, 0.35f, Alpha),
		X + Pad + 4.f * S, Y + Pad, TxtW * 0.66f, Font, 1.25f * S, true, false);
	if (!ActTag.IsEmpty())
	{
		float AW = 0.f, AH = 0.f;
		GetFarsiTextSize(ActTag, Font, 0.9f * S, AW, AH);
		DrawFarsiTextBounded(ActTag, FLinearColor(0.62f, 0.66f, 0.58f, Alpha),
			X + PanelW - Pad - AW, Y + Pad + 4.f * S, AW + 8.f * S, Font, 0.9f * S, true, false);
	}
	else if (bBrass && !DebriefGradeLetter.IsEmpty())
	{
		// S23-BRIEF: the grade STAMP - it slams in (big to rest) once the last
		// line has typed out, in the band the ACT counter uses on briefings
		const float StampAt = 0.45f + (Body.Num() > 0 ? (Body.Num() - 1) * 1.15f : 0.f) + 0.95f;
		const float ST = Shown - StampAt;
		if (ST > 0.f)
		{
			const float Slam = FMath::Clamp(ST / 0.25f, 0.f, 1.f);
			// S24-UISWEEP: the slam scale is clamped to the header band - a 2x
			// letter used to run ~30 px below the band into the first section's
			// text. It still slams (big to rest), it just lands inside its band.
			float Scale = (1.6f - 0.6f * Slam) * 2.0f * S;
			float GW = 0.f, GH = 0.f;
			GetFarsiTextSize(DebriefGradeLetter, Font, Scale, GW, GH);
			const float BandMax = HeaderH + 8.f * S;
			if (GH > BandMax && GH > 0.f)
			{
				Scale *= BandMax / GH;
				GetFarsiTextSize(DebriefGradeLetter, Font, Scale, GW, GH);
			}
			DrawFarsiTextBounded(DebriefGradeLetter, FLinearColor(0.95f, 0.80f, 0.35f, Alpha * Slam),
				X + PanelW - Pad - GW, Y + Pad - 2.f * S, GW + 10.f * S, Font, Scale, true, false);
		}
	}

	// Staged body: sections arrive in order; a section starts only when its
	// time comes, so the eye is led down the card instead of drowning in it.
	for (const FStaged& St : Staged)
	{
		const FMissionSection& Sec = Body[St.Idx];
		const float Local = Shown - St.RevealAt;
		if (Local < 0.f) { break; }
		const float Fade = FMath::Clamp(Local / 0.30f, 0.f, 1.f);
		const float Slide = (1.f - Fade) * 14.f * S;
		const float SY = Y + Pad + HeaderH + 8.f * S + St.Y + Slide;
		DrawFarsiTextBounded(Sec.Header, bBrass ? FLinearColor(0.90f, 0.75f, 0.35f, Alpha * Fade)
			: FLinearColor(0.62f, 0.78f, 0.45f, Alpha * Fade),
			X + Pad + 4.f * S, SY, TxtW, Font, HeadScale, true, false);
		float HW = 0.f, HH = 0.f;
		GetFarsiTextSize(Sec.Header, Font, HeadScale, HW, HH);
		const float TY = SY + HH + 3.f * S;

		// The text types itself out, ~0.85 s per section, cursor blinking.
		const float TypeT = FMath::Clamp((Local - 0.10f) / 0.85f, 0.f, 1.f);
		const int32 Chars = FMath::Min(Sec.Text.Len(), FMath::RoundToInt(TypeT * Sec.Text.Len()));
		if (Chars < Sec.Text.Len())
		{
			const FTutorialTextBlock Partial = WrapTutorialText(Sec.Text.Mid(0, Chars), Font, BodyScale, TxtW, 3);
			DrawTutorialTextBlock(Partial, FLinearColor(0.93f, 0.90f, 0.82f, Alpha * Fade),
				X + Pad + 4.f * S, TY, TxtW, Font, BodyScale);
			if (Partial.Lines.Num() > 0 && FMath::Fmod(Now * 2.5f, 1.f) < 0.6f)
			{
				const FString& LastLine = Partial.Lines[Partial.Lines.Num() - 1];
				float LW = 0.f, LH = 0.f;
				GetFarsiTextSize(LastLine, Font, BodyScale, LW, LH);
				DrawRect(bBrass ? FLinearColor(0.90f, 0.75f, 0.35f, Alpha * Fade)
					: FLinearColor(0.62f, 0.78f, 0.45f, Alpha * Fade),
					X + Pad + 6.f * S + LW, TY + (Partial.Lines.Num() - 1) * Partial.LineH,
					7.f * S, Partial.LineH * 0.8f);
			}
		}
		else
		{
			const FTutorialTextBlock Block = WrapTutorialText(Sec.Text, Font, BodyScale, TxtW, 3);
			DrawTutorialTextBlock(Block, FLinearColor(0.93f, 0.90f, 0.82f, Alpha * Fade),
				X + Pad + 4.f * S, TY, TxtW, Font, BodyScale);
		}
	}

	// Footer: classification line left, the card's life as a progress bar right.
	{
		const FString Foot = bBrass ? TEXT("SQUADAI FIELD DEBRIEF // AFTER ACTION")
			: TEXT("SQUADAI FIELD BRIEFING // CLASSIFIED");
		float FW = 0.f, FH = 0.f;
		GetFarsiTextSize(Foot, Font, 0.8f * S, FW, FH);
		DrawFarsiTextBounded(Foot, FLinearColor(0.55f, 0.58f, 0.52f, Alpha * 0.9f),
			X + Pad + 4.f * S, Y + PanelH - Pad - FH, FW + 10.f * S, Font, 0.8f * S, true, false);
		const float BarW = 150.f * S;
		const float BarX = X + PanelW - Pad - BarW;
		const float BarY = Y + PanelH - Pad - 2.f * S;
		const float Total = FMath::Max(0.1f, NoteDisplayEndTime - NoteDisplayStartTime);
		const float P = FMath::Clamp(Shown / Total, 0.f, 1.f);
		DrawRect(FLinearColor(0.15f, 0.18f, 0.14f, Alpha), BarX, BarY, BarW, 3.f * S);
		DrawRect(bBrass ? FLinearColor(0.80f, 0.62f, 0.22f, Alpha)
		: FLinearColor(0.42f, 0.55f, 0.22f, Alpha), BarX, BarY, BarW * P, 3.f * S);
	}
}

// ===== S23-BRIEF: the debrief card =====
// The act-complete card: STAGED like the briefing, but in brass - the fight
// is over and the numbers are in. The zone's real score, par, clock and ghost
// record type out section by section, and the GRADE slams in as a stamp after
// the last line has finished typing.
void AQuestNativeHUD::ShowDebriefCard(const FString& MissionTitle, const FMissionDebriefFacts& Facts)
{
	BriefingSections.Reset();
	FMissionDebriefModel::BuildDebrief(Facts, BriefingSections);
	bActiveCardIsBriefing = true;
	bActiveCardIsDebrief = true;
	DebriefGradeLetter = Facts.GradeLetter;
	ActiveNoteTitle = MissionTitle.IsEmpty()
		? FString(TEXT("MISSION COMPLETE"))
		: MissionTitle + TEXT(" - COMPLETE");
	ActiveNoteLines.Reset();
	ActiveNoteCounter.Empty();
	const float Needed = 0.45f + (BriefingSections.Num() - 1) * 1.15f + 0.9f + 3.5f;
	const float Now = GetWorld() ? GetWorld()->GetTimeSeconds() : 0.f;
	NoteDisplayStartTime = Now;
	NoteDisplayEndTime = Now + FMath::Max(6.f, Needed);
}

// ===== S17-ALRT =====
void AQuestNativeHUD::BindMissionZoneAlerts()
{
	UWorld* World = GetWorld();
	if (!World) return;
	int32 Bound = 0;
	for (TActorIterator<AMissionZone> It(World); It; ++It)
	{
		It->OnMissionAlert.AddUniqueDynamic(this, &AQuestNativeHUD::OnMissionZoneAlertReceived);
		Bound++;
	}
	UE_LOG(LogTemp, Log, TEXT("[QuestNativeHUD] S17-ALRT: bound mission alerts on %d zone(s)."), Bound);
}

void AQuestNativeHUD::OnMissionZoneAlertReceived(AMissionZone* Mission, FString AlertKey)
{
	// Style: 0 = danger (red, 6 s), 1 = info (amber, 4.5 s), 2 = success (green, 4.5 s).
	struct FAlertDef { const TCHAR* Key; const TCHAR* Fa; const TCHAR* En; uint8 Style; };
	static const FAlertDef Defs[] = {
		{ TEXT("OverrunWarning"),            TEXT("خط دارد سقوط می‌کند — دشمن را عقب برانید!"), TEXT("The line is falling — push them back!"), 0 },
		{ TEXT("OverrunCleared"),            TEXT("خط پاکسازی شد"), TEXT("Line secured"), 2 },
		{ TEXT("CounterattackIncoming"),     TEXT("پاتک دشمن! آماده باشید"), TEXT("Enemy counterattack incoming!"), 0 },
		{ TEXT("CounterattackSpawningEnded"),TEXT("موج پاتک تمام شد — پاکسازی کنید"), TEXT("Counterattack spent — mop up"), 2 },
		{ TEXT("HVTDesignated"),             TEXT("افسر دشمن شناسایی شد — او را از پای درآورید"), TEXT("Enemy officer identified — take him down"), 1 },
		{ TEXT("HVTEliminated"),             TEXT("افسر دشمن از پای درآمد"), TEXT("Enemy officer eliminated"), 2 },
		{ TEXT("HVTEscaped"),                TEXT("افسر دشمن گریخت — ماموریت شکست خورد"), TEXT("The officer escaped — mission failed"), 0 },
		{ TEXT("SabotageChargeDetonated"),   TEXT("هدف منهدم شد"), TEXT("Target destroyed"), 2 },
		{ TEXT("SabotageComplete"),          TEXT("تخریب کامل شد"), TEXT("Demolition complete"), 2 },
		{ TEXT("SpotterDesignated"),         TEXT("دیده‌بان توپخانه دشمن فعال است — او را ساکت کنید"), TEXT("Enemy artillery spotter active — silence him"), 0 },
		{ TEXT("IncomingArtillery"),         TEXT("آتش توپخانه در راه است — پناه بگیرید!"), TEXT("Incoming artillery — take cover!"), 0 },
		{ TEXT("SpotterEliminated"),         TEXT("دیده‌بان ساکت شد — آتشباری قطع شد"), TEXT("Spotter silenced — the shelling stops"), 2 },
		{ TEXT("SupplyCrateTaken"),          TEXT("مهمات برداشته شد — به نقطه تحویل ببرید"), TEXT("Supplies shouldered — get them to the drop point"), 1 },
		{ TEXT("SupplyCrateSecured"),        TEXT("مهمات تحویل شد"), TEXT("Supplies delivered"), 2 },
		{ TEXT("SupplyRunComplete"),         TEXT("همه مهمات رسید"), TEXT("All supplies delivered"), 2 },
		{ TEXT("POWFreed"),                  TEXT("اسیر آزاد شد"), TEXT("Prisoner freed"), 2 },
		{ TEXT("AllPOWsFreed"),              TEXT("همه اسرا آزاد شدند"), TEXT("All prisoners freed"), 2 },
		{ TEXT("POWKilled"),                 TEXT("اسیر کشته شد — ماموریت شکست خورد"), TEXT("A prisoner was killed — mission failed"), 0 },
		// S19-ESCORT / S19-INTEL / S19-EXFIL / S19-CLOCK: the four mission-creator groups.
		{ TEXT("EscortArrived"),             TEXT("کاروان به مقصد رسید"), TEXT("The convoy has arrived"), 2 },
		{ TEXT("EscortLost"),                TEXT("کاروان از بین رفت"), TEXT("The convoy was destroyed"), 0 },
		{ TEXT("IntelReported"),             TEXT("اطلاعات ثبت شد"), TEXT("Intel site reported"), 2 },
		{ TEXT("AllIntelGathered"),          TEXT("همه اطلاعات جمع‌آوری شد"), TEXT("All intel gathered"), 2 },
		{ TEXT("ExtractionAvailable"),       TEXT("منطقه تخلیه فعال شد — به آن برسید و آن را نگه دارید"), TEXT("Extraction armed — get to the pad and hold it"), 1 },
		{ TEXT("ExtractionComplete"),        TEXT("تخلیه کامل شد"), TEXT("Extraction complete"), 2 },
		{ TEXT("ClockWarning"),              TEXT("زمان ماموریت رو به پایان است"), TEXT("Mission clock running out"), 0 },
		{ TEXT("TimeExpired"),               TEXT("زمان ماموریت تمام شد"), TEXT("Mission clock expired"), 0 },
		{ TEXT("ParTimeBeaten"),             TEXT("زمان هدف شکسته شد"), TEXT("Par time beaten"), 2 },
		{ TEXT("ParTimeMissed"),             TEXT("از زمان هدف گذشتید"), TEXT("Par time missed"), 1 },
		// S19-CAP / S19-ASSET / S19-INTERDICT: the batch-4 creator groups.
		{ TEXT("CapturePointCaptured"),      TEXT("نقطه تصرف شد — آن را نگه دارید"), TEXT("Point captured - now hold it"), 1 },
		{ TEXT("CapturePointHeld"),          TEXT("نقطه در دست ماست"), TEXT("The point is held"), 2 },
		{ TEXT("CapturePointLost"),          TEXT("نقطه از دست رفت — پس بگیرید"), TEXT("A point was lost - take it back"), 0 },
		{ TEXT("AssetUnderAttack"),          TEXT("تجهیزات تحت حمله است!"), TEXT("The asset is under attack!"), 0 },
		{ TEXT("AssetDestroyed"),            TEXT("تجهیزات نابود شد — ماموریت شکست خورد"), TEXT("The asset was destroyed - mission failed"), 0 },
		{ TEXT("InterdictionQuotaMet"),      TEXT("قطع خط تدارکات کامل شد"), TEXT("Interdiction complete - nothing got through"), 2 },
		{ TEXT("InterdictionFailed"),        TEXT("بیش از حد تدارکات عبور کرد — ماموریت شکست خورد"), TEXT("Too many got through - mission failed"), 0 },
	};

	for (const FAlertDef& D : Defs)
	{
		if (!AlertKey.Equals(D.Key)) continue;
		// INI-overridable ([MissionAlerts] / [MissionAlerts.ar]) with FA/EN fallback.
		AlertBannerText = SquadAIHUDLocal(this, TEXT("MissionAlerts"), D.Key, D.Fa, D.En);
		switch (D.Style)
		{
		case 0:  AlertBannerColor = FLinearColor(0.85f, 0.12f, 0.08f); break;
		case 1:  AlertBannerColor = FLinearColor(0.95f, 0.70f, 0.20f); break;
		default: AlertBannerColor = FLinearColor(0.30f, 0.75f, 0.30f); break;
		}
		const float Now = GetWorld() ? GetWorld()->GetTimeSeconds() : 0.f;
		AlertBannerStartTime = Now;
		AlertBannerEndTime = Now + (D.Style == 0 ? 6.f : 4.5f);

		// S18-FEED: the banner is transient and centre-screen; the feed keeps a
		// short record of what just happened in the corner.
		// S19-COMPILEFIX: AlertBannerText is already an FString; FString has no ToString().
		AddFeedEntry(AlertBannerText,
			D.Style == 0 ? ESquadAIFeedKind::Warning
			: (D.Style == 2 ? ESquadAIFeedKind::Objective : ESquadAIFeedKind::Supply));
		return;
	}
	// Unknown keys are ignored on purpose (future content stays safe).
}

float AQuestNativeHUD::ReserveTopNotice(float Height)
{
	// S19-MISSUI: one lane for every top-centre notice. The floor is the tutorial
	// header strip when the tutorial is teaching (it owns the row under the
	// compass), otherwise the compass's own bottom edge. Each caller reserves the
	// height it is about to draw, so the next one lands underneath it.
	const float S = GameUIScale;
	const float LaneTop = (bTutLayoutValid && TutHeaderY > 0.f)
		? (TutHeaderY + TutHeaderH + 6.f * S)
		: 48.f * S;
	const float Y = (TopNoticeBottomY > 0.f) ? (TopNoticeBottomY + 6.f * S) : LaneTop;
	TopNoticeBottomY = Y + FMath::Max(0.f, Height);
	return Y;
}

void AQuestNativeHUD::DrawMissionAlertBanner(float SW, float SH, UFont* Font)
{
	UWorld* World = GetWorld();
	if (!World || AlertBannerEndTime <= 0.f) return;
	const float Now = World->GetTimeSeconds();
	if (Now >= AlertBannerEndTime)
	{
		AlertBannerEndTime = -1.f;
		return;
	}
	const float Shown = Now - AlertBannerStartTime;
	const float Remaining = AlertBannerEndTime - Now;
	float Alpha = 1.f;
	if (Shown < 0.25f) Alpha = Shown / 0.25f;
	else if (Remaining < 0.8f) Alpha = Remaining / 0.8f;
	Alpha = FMath::Clamp(Alpha, 0.f, 1.f);

	const float BannerW = FMath::Min(680.f * GameUIScale, SW * 0.70f);
	const float BannerH = 36.f * GameUIScale;
	const float X = (SW - BannerW) * 0.5f;
	// S19-MISSUI: the lane decides the row. It used to be a fixed 92 px, which put
	// it through the tutorial's header strip the moment the tutorial was running
	// (the header sits at 48..84 and the alert at 92..128 - the pop, the
	// countdown and this banner were all fighting for the same 80 px). Reserved
	// here, after the early-outs, so a hidden banner never holds a slot.
	const float Y = ReserveTopNotice(BannerH);

	DrawRect(FLinearColor(0.03f, 0.03f, 0.035f, 0.82f * Alpha), X, Y, BannerW, BannerH);
	DrawRect(FLinearColor(AlertBannerColor.R, AlertBannerColor.G, AlertBannerColor.B, Alpha), X, Y, 4.f * GameUIScale, BannerH);
	DrawFarsiTextBounded(AlertBannerText, FLinearColor(0.96f, 0.95f, 0.90f, Alpha), X + 18.f * GameUIScale, Y + 6.f * GameUIScale, BannerW - 36.f * GameUIScale, Font, 1.15f * GameUIScale, true, true, BannerH - 12.f * GameUIScale);
}

// ==========================================================================
//  S19-ELITE: the commander layer
//  Boss bar, world marker, aura ring and the medic's beam. Canvas-space only: no light,
//  no post-process, no fog - the no-lighting rule holds.
// ==========================================================================
AEnemyCommander* AQuestNativeHUD::FindNearestCommander() const
{
	UWorld* World = GetWorld();
	if (!World)
	{
		return nullptr;
	}
	APawn* Player = UGameplayStatics::GetPlayerPawn(World, 0);
	USoldierRegistrySubsystem* Registry = World->GetSubsystem<USoldierRegistrySubsystem>();
	if (!Player || !Registry)
	{
		return nullptr;
	}

	AEnemyCommander* Best = nullptr;
	float BestDist = TNumericLimits<float>::Max();
	for (const TWeakObjectPtr<ASoldierCharacter>& Weak : Registry->GetAllSoldiers())
	{
		AEnemyCommander* Cmd = Cast<AEnemyCommander>(Weak.Get());
		if (!Cmd || !Cmd->IsAlive())
		{
			continue;
		}
		// Distance to the PLAYER, not the camera: the bar is about how much of a fight
		// the player is in, and a commander 200 m behind a hill is scenery.
		const float D = FVector::Dist(Player->GetActorLocation(), Cmd->GetActorLocation());
		if (D < BestDist)
		{
			BestDist = D;
			Best = Cmd;
		}
	}
	return Best;
}

void AQuestNativeHUD::DrawCommanderMarker(AEnemyCommander* Commander, APlayerController* PC, float S, UFont* Font)
{
	if (!Commander || !PC || !Canvas)
	{
		return;
	}

	UWorld* World = GetWorld();
	const float Now = World ? World->GetTimeSeconds() : 0.f;
	const float Pulse = 0.5f + 0.5f * FMath::Sin(Now * 4.f);

	// ---- the aura ring on the ground -------------------------------------
	if (bShowCommanderAuraRing && Commander->bShowAuraRing && Commander->IsAuraActive())
	{
		const float Radius = Commander->GetCurrentAuraRadius();
		FLinearColor Ring = CommanderMarkerColor;
		Ring.A *= 0.22f;
		constexpr int32 Segs = 40;
		FVector2D Prev(0.f, 0.f);
		bool bPrevOk = false;
		const FVector Centre = Commander->GetActorLocation();
		for (int32 i = 0; i <= Segs; ++i)
		{
			const float Ang = (2.f * PI * i) / Segs;
			const FVector P = Centre + FVector(FMath::Cos(Ang) * Radius, FMath::Sin(Ang) * Radius, 12.f);
			FVector2D SP(0.f, 0.f);
			const bool bOk = PC->ProjectWorldLocationToScreen(P, SP);
			if (bPrevOk && bOk)
			{
				DrawLine(Prev.X, Prev.Y, SP.X, SP.Y, Ring, 1.6f * S);
			}
			Prev = SP;
			bPrevOk = bOk;
		}
	}

	// ---- the medic's beam -------------------------------------------------
	if (bShowCommanderHealBeam)
	{
		if (AEnemyCommanderAssistant* Medic = Commander->GetHealingAssistant())
		{
			FVector2D A(0.f, 0.f), B(0.f, 0.f);
			const bool bA = PC->ProjectWorldLocationToScreen(Medic->GetActorLocation() + FVector(0.f, 0.f, 90.f), A);
			const bool bB = PC->ProjectWorldLocationToScreen(Commander->GetActorLocation() + FVector(0.f, 0.f, 90.f), B);
			if (bA && bB)
			{
				FLinearColor Beam = CommanderHealBeamColor;
				Beam.A *= 0.55f + 0.45f * Pulse;
				DrawLine(A.X, A.Y, B.X, B.Y, Beam, (6.f + 2.f * Pulse) * S);

				// A "+" at the receiving end, so the beam reads as healing and not as a
				// laser: the player has to understand that shooting the medic is the play.
				const float R = (7.f + 2.f * Pulse) * S;
				DrawLine(B.X - R, B.Y, B.X + R, B.Y, Beam, 2.4f * S);
				DrawLine(B.X, B.Y - R, B.X, B.Y + R, Beam, 2.4f * S);
			}
		}
	}

	// ---- the world marker -------------------------------------------------
	if (!bShowCommanderMarker)
	{
		return;
	}

	const FVector Above = Commander->GetActorLocation() + FVector(0.f, 0.f, Commander->GetSimpleCollisionHalfHeight() + 60.f);
	FVector2D Screen(0.f, 0.f);
	const bool bOnScreen = PC->ProjectWorldLocationToScreen(Above, Screen);

	const float Margin = 46.f * S;
	const bool bInsideView = bOnScreen
		&& Screen.X > Margin && Screen.X < Canvas->ClipX - Margin
		&& Screen.Y > Margin && Screen.Y < Canvas->ClipY - Margin;

	FLinearColor Col = CommanderMarkerColor;
	if (Commander->bLastStandActive)
	{
		Col = FLinearColor(1.f, 0.10f, 0.08f, 0.95f);
		Col.A *= 0.65f + 0.35f * Pulse;
	}

	if (!bInsideView)
	{
		// Off-screen (or behind the camera): clamp the marker to the edge and point the
		// way he is. A boss you cannot find is not a boss.
		FVector2D Dir(0.f, 0.f);
		if (bOnScreen)
		{
			Dir = Screen - FVector2D(Canvas->ClipX * 0.5f, Canvas->ClipY * 0.5f);
		}
		else
		{
			// Behind the camera: mirror the horizontal projection so the arrow still
			// tells the truth about which way to turn.
			Dir = FVector2D(-(Screen.X - Canvas->ClipX * 0.5f), Canvas->ClipY * 0.5f - Screen.Y);
		}
		if (!Dir.Normalize())
		{
			Dir = FVector2D(1.f, 0.f);
		}
		const float CX = Canvas->ClipX * 0.5f;
		const float CY = Canvas->ClipY * 0.5f;
		const float Ex = Canvas->ClipX * 0.5f - Margin;
		const float Ey = Canvas->ClipY * 0.5f - Margin;
		const float Scale = FMath::Min(
			FMath::Abs(Ex / FMath::Max(FMath::Abs(Dir.X), KINDA_SMALL_NUMBER)),
			FMath::Abs(Ey / FMath::Max(FMath::Abs(Dir.Y), KINDA_SMALL_NUMBER)));
		const FVector2D Edge(CX + Dir.X * Scale, CY + Dir.Y * Scale);

		const float R = 13.f * S;
		const FVector2D Perp(-Dir.Y, Dir.X);
		DrawLine(Edge.X + Dir.X * R, Edge.Y + Dir.Y * R,
			Edge.X - Dir.X * R * 0.6f + Perp.X * R * 0.8f, Edge.Y - Dir.Y * R * 0.6f + Perp.Y * R * 0.8f, Col, 3.f * S);
		DrawLine(Edge.X + Dir.X * R, Edge.Y + Dir.Y * R,
			Edge.X - Dir.X * R * 0.6f - Perp.X * R * 0.8f, Edge.Y - Dir.Y * R * 0.6f - Perp.Y * R * 0.8f, Col, 3.f * S);

		if (Font)
		{
			// GetPlayerPawn is checked: the marker layer must not be the thing that
			// crashes a build (the round-7 pass added a null-deref of exactly this kind).
			APawn* LocalPlayer = UGameplayStatics::GetPlayerPawn(this, 0);
			const int32 Metres = LocalPlayer
				? FMath::RoundToInt(FVector::Dist(LocalPlayer->GetActorLocation(), Commander->GetActorLocation()) / 100.f)
				: 0;
			const FString Txt = FString::Printf(TEXT("%s  %d %s"), *Commander->CharacterDisplayName.ToString(),
				Metres, SquadAIHUDIsEnglish(this) ? TEXT("m") : TEXT("متر"));
			DrawFarsiTextBounded(Txt, Col, Edge.X - 90.f * S, Edge.Y + 16.f * S, 180.f * S, Font, 0.78f * S, true, true);
		}
		return;
	}

	// On screen: a diamond over him, brackets around it, name + distance under it.
	const float R = 12.f * S;
	DrawLine(Screen.X, Screen.Y - R, Screen.X + R, Screen.Y, Col, 2.4f * S);
	DrawLine(Screen.X + R, Screen.Y, Screen.X, Screen.Y + R, Col, 2.4f * S);
	DrawLine(Screen.X, Screen.Y + R, Screen.X - R, Screen.Y, Col, 2.4f * S);
	DrawLine(Screen.X - R, Screen.Y, Screen.X, Screen.Y - R, Col, 2.4f * S);
	DrawRect(Col, Screen.X - R, Screen.Y - R, R * 2.f, 2.f * S);
	DrawRect(Col, Screen.X - R, Screen.Y + R - 2.f * S, R * 2.f, 2.f * S);

	if (Font)
	{
		APawn* Player = UGameplayStatics::GetPlayerPawn(this, 0);
		const int32 Metres = Player ? FMath::RoundToInt(FVector::Dist(Player->GetActorLocation(), Commander->GetActorLocation()) / 100.f) : 0;
		const FString Txt = FString::Printf(TEXT("%s  %d %s"), *Commander->CharacterDisplayName.ToString(),
			Metres, SquadAIHUDIsEnglish(this) ? TEXT("m") : TEXT("متر"));
		DrawFarsiTextBounded(Txt, Col, Screen.X - 100.f * S, Screen.Y + R + 4.f * S, 200.f * S, Font, 0.76f * S, true, true);
	}
}

void AQuestNativeHUD::DrawCommanderLayer(float SW, float SH, UFont* Font)
{
	AEnemyCommander* Commander = FindNearestCommander();
	if (!Commander)
	{
		return;
	}

	APawn* Player = UGameplayStatics::GetPlayerPawn(this, 0);
	APlayerController* PC = Player ? Cast<APlayerController>(Player->GetController()) : nullptr;
	const float S = GameUIScale;
	const UWorld* World = GetWorld();
	const float Now = World ? World->GetTimeSeconds() : 0.f;
	const float Pulse = 0.5f + 0.5f * FMath::Sin(Now * 4.f);

	if (PC)
	{
		DrawCommanderMarker(Commander, PC, S, Font);
	}

	// ---- the boss bar ------------------------------------------------------
	if (!bShowCommanderBar || !Font || !Player)
	{
		return;
	}
	if (FVector::Dist(Player->GetActorLocation(), Commander->GetActorLocation()) > CommanderBarMaxDistance)
	{
		return;
	}

	// S19-MISSUI: the bar's plate is the biggest thing on the top of the screen -
	// 540 x 62 at 1080p - and it sat at a flat SH * 0.055, i.e. 59 px, which is
	// inside the compass, the tutorial's header strip AND the defend countdown.
	// It now takes a slot in the shared notice lane like every other top-centre
	// element, and the plate's own 26 px name row / 20 px pip row are what the
	// lane is asked to reserve.
	const float BarW = FMath::Min(SW * 0.42f, 520.f * S);
	const float BarH = 16.f * S;
	const float PlateH = BarH + 46.f * S;
	const float PlateY = ReserveTopNotice(PlateH);
	const float X = (SW - BarW) * 0.5f;
	const float Y = PlateY + 26.f * S;

	const FLinearColor Frame = Commander->bLastStandActive
		? FLinearColor(1.f, 0.10f, 0.08f, 0.95f)
		: CommanderMarkerColor;

	DrawTacticalPlate3D(X - 10.f * S, PlateY, BarW + 20.f * S, PlateH,
		FLinearColor(0.07f, 0.06f, 0.06f, 0.80f), FLinearColor(0.02f, 0.02f, 0.02f, 0.85f),
		Frame, 0.95f, 7.f * S, 2.f * S, 3.f * S);

	// name + role
	{
		// S19-CONST: NOT "Role" - that name hides AActor::Role, and C4458 is an error in this build.
		const FString RoleLabel = SquadAIHUDIsEnglish(this) ? TEXT("COMMANDER") : TEXT("فرمانده");
		const FString Title = FString::Printf(TEXT("%s - %s"), *Commander->CharacterDisplayName.ToString(), *RoleLabel);
		DrawFarsiTextBounded(Title, FLinearColor(1.f, 0.94f, 0.86f, 0.96f), X, Y - 22.f * S, BarW, Font, 0.82f * S, true, false);
	}

	// health
	{
		const float Frac = Commander->HealthComp ? FMath::Clamp(Commander->HealthComp->GetHealthPercent(), 0.f, 1.f) : 0.f;
		DrawRect(FLinearColor(0.f, 0.f, 0.f, 0.65f), X, Y, BarW, BarH);
		FLinearColor Fill = Commander->bLastStandActive
			? FLinearColor(1.f, 0.18f, 0.12f, 0.95f)
			: FLinearColor(0.85f, 0.22f, 0.14f, 0.92f);
		if (Commander->bLastStandActive)
		{
			Fill.A *= 0.65f + 0.35f * Pulse;
		}
		DrawRect(Fill, X + 1.f * S, Y + 1.f * S, (BarW - 2.f * S) * Frac, BarH - 2.f * S);

		// the armour the aura is giving him reads as a hatched overlay
		const float Resist = Commander->IsAuraActive() ? Commander->GetAuraResist() : 0.f;
		if (Resist > 0.f)
		{
			FLinearColor Armour(0.55f, 0.75f, 1.f, 0.20f);
			for (float Hatch = X + 4.f * S; Hatch < X + BarW * Frac; Hatch += 10.f * S)
			{
				DrawRect(Armour, Hatch, Y + 2.f * S, 2.f * S, BarH - 4.f * S);
			}
		}
		DrawRect(Frame, X, Y, BarW, 1.5f * S);
		DrawRect(Frame, X, Y + BarH - 1.5f * S, BarW, 1.5f * S);
	}

	// assistant pips: "kill these first" - they carry the relay
	{
		int32 Alive = 0, Total = 0;
		if (UWorld* W = GetWorld())
		{
			if (USoldierRegistrySubsystem* Registry = W->GetSubsystem<USoldierRegistrySubsystem>())
			{
				for (const TWeakObjectPtr<ASoldierCharacter>& Weak : Registry->GetAllSoldiers())
				{
					const AEnemyCommanderAssistant* A = Cast<AEnemyCommanderAssistant>(Weak.Get());
					if (!A)
					{
						continue;
					}
					// Only count the ones that belong to this command net.
					if (A->GetCommander() != Commander)
					{
						continue;
					}
					++Total;
					if (A->IsAlive())
					{
						++Alive;
					}
				}
			}
		}
		if (Total > 0)
		{
			const float PipY = Y + BarH + 6.f * S;
			const float PipR = 4.f * S;
			float PipX = X + PipR;
			for (int32 i = 0; i < Total; ++i)
			{
				const bool bUp = i < Alive;
				const FLinearColor C = bUp ? CommanderAssistantColor : FLinearColor(0.35f, 0.35f, 0.35f, 0.6f);
				// a small diamond per assistant
				DrawLine(PipX, PipY - PipR, PipX + PipR, PipY, C, 1.6f * S);
				DrawLine(PipX + PipR, PipY, PipX, PipY + PipR, C, 1.6f * S);
				DrawLine(PipX, PipY + PipR, PipX - PipR, PipY, C, 1.6f * S);
				DrawLine(PipX - PipR, PipY, PipX, PipY - PipR, C, 1.6f * S);
				PipX += PipR * 3.f;
			}

			if (Font)
			{
				const FString Relay = SquadAIHUDIsEnglish(this)
					? FString::Printf(TEXT("assistants %d/%d - they hold the command net"), Alive, Total)
					: FString::Printf(TEXT("کمکیار %d/%d — شبکه‌ی فرماندهی را نگه می‌دارند"), Alive, Total);
				DrawFarsiTextBounded(Relay, FLinearColor(0.86f, 0.86f, 0.90f, 0.85f),
					X + 60.f * S, PipY - 7.f * S, BarW, Font, 0.66f * S, true, false);
			}
		}
	}

	// last stand / morale state line
	if (Commander->bLastStandActive && Font)
	{
		const FString Warn = SquadAIHUDIsEnglish(this) ? TEXT("LAST STAND - he is not going down quietly")
			: TEXT("آخرین مقاومت — او به این سادگی نمی‌افتد");
		FLinearColor C(1.f, 0.20f, 0.14f, 0.9f);
		C.A *= 0.6f + 0.4f * Pulse;
		DrawFarsiTextBounded(Warn, C, X, Y + BarH + 26.f * S, BarW, Font, 0.72f * S, true, false);
	}
}

// ===== S19-DEATHPROMPT =====
void AQuestNativeHUD::ShowDeathPrompt(const FString& Title, const FString& Sub, float Duration)
{
	if (Duration <= 0.f) return;
	const float Now = GetWorld() ? GetWorld()->GetTimeSeconds() : 0.f;
	DeathPromptTitle = Title;
	DeathPromptSub = Sub;
	DeathPromptStartTime = Now;
	DeathPromptEndTime = Now + Duration;
}

void AQuestNativeHUD::ShowAlertBanner(const FString& Text, FLinearColor Color, float Duration)
{
	if (Text.IsEmpty() || Duration <= 0.f) return;
	const float Now = GetWorld() ? GetWorld()->GetTimeSeconds() : 0.f;
	AlertBannerText = Text;
	AlertBannerColor = Color;
	AlertBannerStartTime = Now;
	AlertBannerEndTime = Now + Duration;
}

void AQuestNativeHUD::DrawDeathPrompt(float SW, float SH, UFont* Font)
{
	UWorld* World = GetWorld();
	if (!World || DeathPromptEndTime <= 0.f) return;
	const float Now = World->GetTimeSeconds();
	if (Now >= DeathPromptEndTime)
	{
		DeathPromptEndTime = -1.f;
		return;
	}

	// Slow fade in, longer fade out: this appears exactly when the player is least able
	// to look at the screen, so it has to be unmissable but not a flash.
	const float Shown = Now - DeathPromptStartTime;
	const float Remaining = DeathPromptEndTime - Now;
	float Alpha = 1.f;
	if (Shown < 0.35f) Alpha = Shown / 0.35f;
	else if (Remaining < 0.9f) Alpha = Remaining / 0.9f;
	Alpha = FMath::Clamp(Alpha, 0.f, 1.f);

	// Full-screen darkening vignette (no lighting/post-process touched - HUD only).
	DrawRect(FLinearColor(0.02f, 0.01f, 0.01f, 0.55f * Alpha), 0.f, 0.f, SW, SH);

	const float BarH = 3.f * GameUIScale;
	const float CenterY = SH * 0.42f;
	DrawRect(FLinearColor(0.62f, 0.09f, 0.09f, 0.95f * Alpha), SW * 0.18f, CenterY - 34.f * GameUIScale, SW * 0.64f, BarH);

	DrawFarsiTextBounded(DeathPromptTitle, FLinearColor(0.94f, 0.24f, 0.20f, Alpha),
		SW * 0.10f, CenterY, SW * 0.80f, Font, 3.0f * GameUIScale, true, true);
	DrawFarsiTextBounded(DeathPromptSub, FLinearColor(0.93f, 0.90f, 0.84f, Alpha),
		SW * 0.12f, CenterY + 62.f * GameUIScale, SW * 0.76f, Font, 1.25f * GameUIScale, true, true);

	DrawRect(FLinearColor(0.62f, 0.09f, 0.09f, 0.95f * Alpha), SW * 0.18f, CenterY + 118.f * GameUIScale, SW * 0.64f, BarH);
}

// ===== S17-STORY =====
void AQuestNativeHUD::ShowStoryCard(const FText& Title, const FText& Body, float Duration)
{
	if (bDeploymentVeilActive)
	{
		// Player is still on the deployment screen — hold it until Enter.
		PendingStoryTitle = Title;
		PendingStoryBody = Body;
		PendingStoryDuration = Duration;
		return;
	}
	ActiveNoteTitle = Title.ToString();
	ActiveNoteLines.Reset();
	const FString BodyStr = Body.ToString();   // S23-BRIEF: one conversion, two readers
	BodyStr.ParseIntoArrayLines(ActiveNoteLines, false);
	if (ActiveNoteLines.Num() > 10) ActiveNoteLines.SetNum(10);
	ActiveNoteCounter.Empty();
	bActiveCardIsBriefing = true;
	bActiveCardIsDebrief = false;  // S23-BRIEF: a briefing wears green
	DebriefGradeLetter.Empty();
	// S23-BRIEF: a structured briefing ([TAG] lines from the land) stages its
	// sections with the typewriter; a plain body (old missions, hand-written
	// notes) keeps the classic flat card exactly as before.
	BriefingSections.Reset();
	if (FMissionBriefingModel::ParseBriefingCard(BodyStr, BriefingSections))
	{
		const float Needed = 0.45f + (BriefingSections.Num() - 1) * 1.15f + 0.9f + 3.5f;
		Duration = FMath::Max(Duration, Needed);
	}
	const float Now = GetWorld() ? GetWorld()->GetTimeSeconds() : 0.f;
	NoteDisplayStartTime = Now;
	NoteDisplayEndTime = Now + FMath::Max(4.f, Duration);
}

void AQuestNativeHUD::OnDeploymentVeilDismissed()
{
	// S17-LOOK: hard-capture the mouse for gameplay. Without this the viewport
	// keeps UI-style capture after the deployment click, so the camera only
	// rotates while a mouse button is held.
	if (APlayerController* PC = UGameplayStatics::GetPlayerController(GetWorld(), 0))
	{
		PC->bShowMouseCursor = false;
		FInputModeGameOnly InputMode;
		InputMode.SetConsumeCaptureMouseDown(false);
		PC->SetInputMode(InputMode);
	}

	const float Now = GetWorld() ? GetWorld()->GetTimeSeconds() : 0.f;
	PostVeilFadeStartTime = Now;
	if (!bOnboardingShown)
	{
		bOnboardingShown = true;
		OnboardingStartTime = Now + 2.0f; // let the fade finish first
	}
	if (!PendingStoryTitle.IsEmpty() || !PendingStoryBody.IsEmpty())
	{
		const FText T = PendingStoryTitle; const FText B = PendingStoryBody;
		PendingStoryTitle = FText::GetEmpty();
		PendingStoryBody = FText::GetEmpty();
		ShowStoryCard(T, B, PendingStoryDuration);
	}
}

void AQuestNativeHUD::DrawPostVeilFade(float SW, float SH)
{
	if (PostVeilFadeStartTime < 0.f || !GetWorld()) return;
	const float T = GetWorld()->GetTimeSeconds() - PostVeilFadeStartTime;
	const float Dur = 1.4f;
	if (T >= Dur)
	{
		PostVeilFadeStartTime = -1.f;
		return;
	}
	const float A = FMath::Clamp(1.f - T / Dur, 0.f, 1.f);
	DrawRect(FLinearColor(0.f, 0.f, 0.f, A), 0.f, 0.f, SW, SH);
}

// ===== S17-HINT2: CoD-style onboarding hint cards =====
// Replaces the old flat 28px strip. Big bottom-center card with a vector icon,
// short action label, key-cap chips, gold Sacred-Defense corner brackets,
// slide-up/fade animation and progress dots.
// Console: `SquadAI.ReplayHints 1` replays the whole sequence (testing).
// S19-UITUNE: live-tuning knobs for the tutorial card. I cannot see the
// screen from here, so rather than guess at the layout again and get it
// wrong a third time, these let you dial the card in from the console and
// tell me the numbers you land on. Changes apply on the very next frame.
static TAutoConsoleVariable<int32> CVarSquadAIReplayHints(
	TEXT("SquadAI.ReplayHints"), 0,
	TEXT("S17-HINT2: set to 1 to replay the onboarding hint cards."),
	ECVF_Default);

void AQuestNativeHUD::DrawOnboardingHints(float SW, float SH, UFont* Font)
{
	if (!GetWorld() || !Canvas) return;

	// Replay trigger (auto-resets so it acts like a one-shot command).
	if (CVarSquadAIReplayHints.GetValueOnGameThread() != 0)
	{
		CVarSquadAIReplayHints.AsVariable()->Set(0, ECVF_SetByCode);
		bOnboardingShown = true;
		OnboardingStartTime = GetWorld()->GetTimeSeconds();
	}

	OnboardingCardY = -1.f;
	if (OnboardingStartTime < 0.f) return;
	const float T = GetWorld()->GetTimeSeconds() - OnboardingStartTime;
	if (T < 0.f) return;

	enum class EHintIcon : uint8 { Move, Combat, Revive, Objective };
	struct FHint { const TCHAR* Key; const TCHAR* Fa; const TCHAR* En; EHintIcon Icon; const TCHAR* Chips[5]; };
	// INI-overridable ([OnboardingHints] / [OnboardingHints.ar]); new short keys
	// because the key names now live on the chips, not inside the sentence.
	static const FHint Hints[] = {
		{ TEXT("Hint1S"), TEXT("جابه‌جایی — برای دویدن نگه دارید"), TEXT("Move — hold to sprint"),
			EHintIcon::Move, { TEXT("W"), TEXT("A"), TEXT("S"), TEXT("D"), TEXT("SHIFT") } },
		{ TEXT("Hint2S"), TEXT("نشانه‌گیری، شلیک و تعویض خشاب"), TEXT("Aim, fire & reload"),
			EHintIcon::Combat, { TEXT("RMB"), TEXT("LMB"), TEXT("R"), nullptr, nullptr } },
		{ TEXT("Hint3S"), TEXT("احیای هم‌رزم مجروح — نزدیکش بایستید"), TEXT("Revive a downed squadmate — stand close"),
			EHintIcon::Revive, { TEXT("E"), nullptr, nullptr, nullptr, nullptr } },
		{ TEXT("Hint4S"), TEXT("اهداف را از کارت بالا-چپ و نوار هشدار دنبال کنید"), TEXT("Track objectives on the top-left card and alert banners"),
			EHintIcon::Objective, { nullptr, nullptr, nullptr, nullptr, nullptr } },
	};
	constexpr int32 NumHints = 4;
	const float HintDur = 7.0f;
	const int32 Idx = static_cast<int32>(T / HintDur);
	if (Idx >= NumHints)
	{
		OnboardingStartTime = -1.f; // done for this level
		return;
	}
	const float Local = T - Idx * HintDur;

	// Envelope: slide-up + fade in (0.45s ease-out cubic), fade + drop out (0.55s).
	float In01 = FMath::Clamp(Local / 0.45f, 0.f, 1.f);
	In01 = 1.f - FMath::Pow(1.f - In01, 3.f);
	const float Out01 = FMath::Clamp((HintDur - Local) / 0.55f, 0.f, 1.f);
	const float Alpha = In01 * Out01;
	if (Alpha <= 0.f) return;

	const float S = GameUIScale;
	const bool bEnglish = SquadAIHUDIsEnglish(this);
	const FHint& HInfo = Hints[Idx];
	const FString Text = SquadAIHUDLocal(this, TEXT("OnboardingHints"), HInfo.Key, HInfo.Fa, HInfo.En);

	int32 NumChips = 0;
	while (NumChips < 5 && HInfo.Chips[NumChips]) ++NumChips;

	// Card geometry: bottom-center — clear of squad panel (left), minimap (right)
	// and the center crosshair.
	//
	// S19-TUTCOLOR: this card is the tutorial layer's first screen, so it now
	// shares the rail with everything else - same width as the header strip and
	// the banner, same 18 px padding as the lesson card - and it is measured
	// from its contents instead of being a fixed 118 px slab. It used to be 660
	// wide (2 px off the rail's own width, so it read as "almost aligned") with
	// its own brown material, its own two golds and its own keycap chips: the
	// one card in the layer built by a different hand.
	const float CardW = (TutRailW > 0.f) ? TutRailW : FMath::Min(660.f * S, SW * 0.56f);
	const float Slide = (1.f - In01) * 30.f - (1.f - Out01) * 14.f;
	const float X = (SW - CardW) * 0.5f;

	// --- measured contents: one wrapped label row, an optional keycap row, dots.
	const float Pad     = 18.f * S;
	const float IconW   = 92.f * S;
	const float IconBoxH = 44.f * S;              // room for the 20 px icon + air
	const float LabScale = 1.02f * S;             // was a shrink-to-fit 1.30
	const float SepX    = X + Pad + IconW;
	const float TxtX    = SepX + Pad;
	const float TxtW    = CardW - (IconW + Pad * 3.f);
	const float CapH    = 22.f * S;               // the banner/chip cap height
	const float CapGap  = 8.f * S;
	const float DotsH   = 9.f * S;

	const FTutorialTextBlock LabBlock = WrapTutorialText(Text, Font, LabScale, TxtW, 2);
	const float TopRowH = FMath::Max(LabBlock.BlockH, IconBoxH);

	float CapsW = 0.f;
	for (int32 c = 0; c < NumChips; ++c)
	{
		CapsW += MeasureKeycapGlyphW(FString(HInfo.Chips[c]), CapH) + (c > 0 ? CapGap : 0.f);
	}

	const float CardH = Pad + TopRowH
		+ (NumChips > 0 ? (10.f * S + CapH) : 0.f)
		+ 8.f * S + DotsH + Pad;
	// S19-TUTLAYOUT: when the tutorial is running its own bottom stack, this card
	// hangs above it instead of at a fixed 152 px - the two used to overlap.
	const float BaseY = (bTutLayoutValid && TutStackTopY > 0.f)
		? (TutStackTopY - CardH - 12.f * S)
		: (SH - CardH - 152.f * S);
	const float Y = FMath::Max(TutHeaderY + TutHeaderH + 12.f * S, BaseY) + Slide * S;
	OnboardingCardY = Y; // S19-MISSUI: the briefing note places itself above this

	// --- the same plate every other tutorial panel uses ---
	DrawTutorialPlate(X, Y, CardW, CardH, Alpha, S, false);
	// Faint gold wash + hairline under the icon column marks it as a column, not
	// a second panel edge.
	DrawRect(FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::BracketGold(), 0.05f * Alpha), X, Y, IconW, CardH);
	DrawRect(FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::BracketGold(), 0.30f * Alpha),
		SepX, Y + Pad * 0.6f, 1.5f * S, FMath::Max(1.f, CardH - Pad * 1.2f));

	// --- "HINT" tab riding the top edge ---
	{
		const FString Tab = bEnglish ? FString(TEXT("HINT")) : FString(TEXT("راهنما"));
		float TabW = 0.f, TabH = 0.f;
		GetFarsiTextSize(Tab, Font, 0.85f * S, TabW, TabH);
		const float TabBoxW = TabW + 26.f * S;
		const float TabBoxH = TabH + 6.f * S;
		const float TabX = X + (CardW - TabBoxW) * 0.5f;
		const float TabY = Y - TabBoxH + 1.f * S;
		const float Hair = FMath::Max(1.f, 1.2f * S);
		FLinearColor TabFill = FSquadAIHUDPalette::PanelBottom();
		TabFill.A *= Alpha;
		DrawRect(TabFill, TabX, TabY, TabBoxW, TabBoxH);
		DrawRect(FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::BracketGold(), 0.45f * Alpha), TabX, TabY, TabBoxW, Hair);
		DrawRect(FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::BracketGold(), 0.45f * Alpha), TabX, TabY, Hair, TabBoxH);
		DrawRect(FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::BracketGold(), 0.45f * Alpha), TabX + TabBoxW - Hair, TabY, Hair, TabBoxH);
		DrawFarsiText(Tab, FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::BracketGold(), Alpha), TabX + (TabBoxW - TabW) * 0.5f, TabY + 3.f * S, Font, 0.85f * S, false);
	}

	// --- vector icon, centered in the icon column ---
	{
		const float IX = X + Pad + IconW * 0.5f;
		const float IY = Y + Pad + TopRowH * 0.5f;
		const FLinearColor IcoC = FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::TextWhite(), 0.95f * Alpha);
		const float R = 20.f * S;
		const float LT = FMath::Max(1.5f, 2.2f * S); // line thickness
		switch (HInfo.Icon)
		{
		case EHintIcon::Move: // 4 directional chevrons around a center dot
		{
			const float A = R, B = R * 0.55f, C = R * 0.45f;
			DrawLine(IX - C, IY - B, IX, IY - A, IcoC, LT); DrawLine(IX, IY - A, IX + C, IY - B, IcoC, LT); // up
			DrawLine(IX - C, IY + B, IX, IY + A, IcoC, LT); DrawLine(IX, IY + A, IX + C, IY + B, IcoC, LT); // down
			DrawLine(IX - B, IY - C, IX - A, IY, IcoC, LT); DrawLine(IX - A, IY, IX - B, IY + C, IcoC, LT); // left
			DrawLine(IX + B, IY - C, IX + A, IY, IcoC, LT); DrawLine(IX + A, IY, IX + B, IY + C, IcoC, LT); // right
			DrawFilledCircleArea(FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::TextWhite(), 0.85f * Alpha), IX, IY, 3.2f * S);
			break;
		}
		case EHintIcon::Combat: // reticle: ring + 4 ticks + center dot
		{
			DrawCircleLines(IcoC, IX, IY, R * 0.82f, LT);
			const float T0 = R * 0.82f - 4.f * S, T1 = R * 0.82f + 6.f * S;
			DrawLine(IX, IY - T1, IX, IY - T0, IcoC, LT); DrawLine(IX, IY + T0, IX, IY + T1, IcoC, LT);
			DrawLine(IX - T1, IY, IX - T0, IY, IcoC, LT); DrawLine(IX + T0, IY, IX + T1, IY, IcoC, LT);
			DrawFilledCircleArea(FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::TextWhite(), 0.85f * Alpha), IX, IY, 2.6f * S);
			break;
		}
		case EHintIcon::Revive: // medic cross
		{
			const FLinearColor Med = FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::Success(), 0.95f * Alpha);
			DrawRect(Med, IX - 4.5f * S, IY - 14.f * S, 9.f * S, 28.f * S);
			DrawRect(Med, IX - 14.f * S, IY - 4.5f * S, 28.f * S, 9.f * S);
			break;
		}
		case EHintIcon::Objective: // waypoint diamond + center dot
		default:
		{
			DrawLine(IX, IY - R, IX + R * 0.72f, IY, IcoC, LT); DrawLine(IX + R * 0.72f, IY, IX, IY + R, IcoC, LT);
			DrawLine(IX, IY + R, IX - R * 0.72f, IY, IcoC, LT); DrawLine(IX - R * 0.72f, IY, IX, IY - R, IcoC, LT);
			DrawFilledCircleArea(FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::BracketGold(), 0.9f * Alpha), IX, IY, 3.2f * S);
			break;
		}
		}
	}

	// --- action label: wrapped to its column and measured into the row above the
	// keycaps. It used to be one shrink-to-fit line at 1.30 - the same defect the
	// lesson card had, on the card a brand-new player sees first.
	{
		FLinearColor LabInk = FSquadAIHUDPalette::TextWhite();
		LabInk.A = Alpha;
		DrawTutorialTextBlock(LabBlock, LabInk, TxtX,
			Y + Pad + (TopRowH - LabBlock.BlockH) * 0.5f, TxtW, Font, LabScale, true);
	}

	// --- keycap row: the very same raised gold cap the banner, the chip and the
	// lesson card's footer draw. This card used to have a fourth keycap style of
	// its own (flat brown slab, cream hairline) for the same four keys.
	if (NumChips > 0)
	{
		const float ChipY = Y + Pad + TopRowH + 10.f * S;
		float CXi = TxtX + (TxtW - CapsW) * 0.5f;
		for (int32 i = 0; i < NumChips; ++i)
		{
			const FString CLabel = FString(HInfo.Chips[i]);
			CXi += DrawKeycapGlyph(CXi, ChipY, CapH, CLabel, Font,
				FSquadAIHUDPalette::BracketGold(), false) + CapGap;
		}
	}

	// --- progress dots (1 of 4) ---
	{
		const float DotY = Y + CardH - (Pad + DotsH) * 0.5f;
		const float Spacing = 18.f * S;
		float DX = X + CardW * 0.5f - Spacing * (NumHints - 1) * 0.5f;
		for (int32 i = 0; i < NumHints; ++i)
		{
			if (i == Idx) DrawFilledCircleArea(FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::BracketGold(), 0.95f * Alpha), DX, DotY, 4.f * S);
			else          DrawFilledCircleArea(FSquadAIHUDPalette::WithAlpha(FSquadAIHUDPalette::Muted(), 0.35f * Alpha), DX, DotY, 2.6f * S);
			DX += Spacing;
		}
	}
}

void AQuestNativeHUD::DrawMinimap(float CX, float CY, float R, const FVector& PL, float PY, UFont* Font)
{
	UWorld* World = GetWorld(); if (!World) return;
	const float S = GameUIScale;
	const USquadAITuning* Tuning = USquadAITuning::Get();

	// S27-REFUI: Anti-aliased circular radar plate (T_UI_RadarMap.png) matching .topright .map in index.html
	// (no jagged scanline DrawFilledCircleArea / DrawCircleLines!).
	if (UTexture2D* RadarTex = GetUITexture(FName(TEXT("RadarMap"))))
	{
		DrawTexture(RadarTex, CX - R, CY - R, R * 2.f, R * 2.f, 0.f, 0.f, 1.f, 1.f, FLinearColor(1.f, 1.f, 1.f, 0.96f));
	}
	else if (MinimapMID && MinimapRT && MinimapRT->GetResource() && MinimapRT->SizeX > 0)
	{
		MinimapMID->SetTextureParameterValue(FName("MinimapTexture"), MinimapRT);
		const float TS = R * 2.f;
		Canvas->K2_DrawMaterial(MinimapMID, FVector2D(CX - R, CY - R), FVector2D(TS, TS), FVector2D(0.f, 0.f), FVector2D(1.f, 1.f), -PY, FVector2D(0.5f, 0.5f));
	}
	else
	{
		DrawFilledCircleArea(FSquadAIHUDPalette::SRGB(18, 22, 21, 0.94f), CX, CY, R);
	}

	const float WR = MinimapCaptureWidth * 0.5f;
	const float CosY = FMath::Cos(-FMath::DegreesToRadians(PY));
	const float SinY = FMath::Sin(-FMath::DegreesToRadians(PY));
	auto W2M = [&](const FVector& WP, float& OX, float& OY) -> bool
	{
		const FVector O = WP - PL;
		const float RX = O.X * CosY - O.Y * SinY;
		const float RY = O.X * SinY + O.Y * CosY;
		const float D = FMath::Sqrt(RX * RX + RY * RY);
		if (D > WR) return false;
		OX = CX + RY * (R / WR);
		OY = CY - RX * (R / WR);
		return true;
	};

	bool bDrewObjectiveBlip = false;
	AQuestChain* Chain = FindQuestChain();
	if (Chain && Chain->bIsActive)
	{
		AMissionZone* Cur = Chain->GetCurrentMission();
		if (Cur)
		{
			float ZX, ZY;
			if (W2M(Cur->GetActorLocation(), ZX, ZY))
			{
				bDrewObjectiveBlip = true;
				if (UTexture2D* FireBlip = GetUITexture(FName(TEXT("IconObjectiveFire3D"))))
				{
					DrawTexture(FireBlip, ZX - 10.f * S, ZY - 12.f * S, 20.f * S, 20.f * S, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
				}
				else if (Tuning && Tuning->MissionZoneIcon)
				{
					DrawIcon(Tuning->MissionZoneIcon, ZX, ZY, 14.f * S);
				}
			}
		}
	}
	if (!bDrewObjectiveBlip)
	{
		// Tutorial / standalone preview objective blip (.map .blip centered at SVG (101, 42) in 132x132 viewBox -> (+0.53*R, -0.36*R))
		const float BlipX = CX + R * 0.53f;
		const float BlipY = CY - R * 0.36f;
		if (UTexture2D* FireBlip = GetUITexture(FName(TEXT("IconObjectiveFire3D"))))
		{
			DrawTexture(FireBlip, BlipX - 10.f * S, BlipY - 12.f * S, 20.f * S, 20.f * S, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
		}
	}

	AActor* LeaderActor = FindCachedLeader();
	if (LeaderActor)
	{
		float LX, LY;
		if (W2M(LeaderActor->GetActorLocation(), LX, LY))
		{
			if (Tuning && Tuning->LeaderIcon) DrawIcon(Tuning->LeaderIcon, LX, LY, 12.f * S);
			else DrawRect(FSquadAIHUDPalette::SRGB(80, 180, 255, 0.90f), LX - 4.f * S, LY - 4.f * S, 8.f * S, 8.f * S);
		}
	}

	for (const FMinimapSoldierDot& Dot : CachedSoldierDots)
	{
		float SX, SY;
		if (!W2M(Dot.WorldLoc, SX, SY)) continue;

		if (Dot.bIsCommander)
		{
			const float DiamondR = 6.5f * S;
			const FLinearColor C = CommanderMarkerColor;
			DrawLine(SX, SY - DiamondR, SX + DiamondR, SY, C, 2.0f * S);
			DrawLine(SX + DiamondR, SY, SX, SY + DiamondR, C, 2.0f * S);
			DrawLine(SX, SY + DiamondR, SX - DiamondR, SY, C, 2.0f * S);
			DrawLine(SX - DiamondR, SY, SX, SY - DiamondR, C, 2.0f * S);
			continue;
		}
		if (Dot.bIsAssistant)
		{
			const float AssistantR = 4.5f * S;
			const FLinearColor C = CommanderAssistantColor;
			DrawLine(SX, SY - AssistantR, SX + AssistantR, SY, C, 1.6f * S);
			DrawLine(SX + AssistantR, SY, SX, SY + AssistantR, C, 1.6f * S);
			DrawLine(SX, SY + AssistantR, SX - AssistantR, SY, C, 1.6f * S);
			DrawLine(SX - AssistantR, SY, SX, SY - AssistantR, C, 1.6f * S);
			continue;
		}

		if (Dot.bAlly)
		{
			if (Tuning && Tuning->AllyIcon)
			{
				DrawIcon(Tuning->AllyIcon, SX, SY, 8.f * S);
			}
			else
			{
				DrawRect(FSquadAIHUDPalette::SRGB(104, 207, 255, 0.85f), SX - 3.f * S, SY - 3.f * S, 6.f * S, 6.f * S);
			}
		}
		else
		{
			if (Tuning && Tuning->EnemyIcon) DrawIcon(Tuning->EnemyIcon, SX, SY, 8.f * S);
			else DrawRect(FSquadAIHUDPalette::SRGB(235, 70, 60, 0.90f), SX - 3.f * S, SY - 3.f * S, 6.f * S, 6.f * S);
		}
	}

	// Center cyan player chevron (.map .me: ▲ #68cfff; text-shadow: 0 0 8px #68cfff)
	const FLinearColor CyanGlow = FSquadAIHUDPalette::SRGB(104, 207, 255, 0.32f);
	const FLinearColor CyanMe   = FSquadAIHUDPalette::SRGB(104, 207, 255, 0.98f);
	DrawLine(CX, CY - 6.f * S, CX + 5.f * S, CY + 5.f * S, CyanGlow, 4.2f * S);
	DrawLine(CX, CY - 6.f * S, CX - 5.f * S, CY + 5.f * S, CyanGlow, 4.2f * S);
	DrawLine(CX - 5.f * S, CY + 5.f * S, CX + 5.f * S, CY + 5.f * S, CyanGlow, 3.8f * S);
	DrawLine(CX, CY - 6.f * S, CX + 5.f * S, CY + 5.f * S, CyanMe, 2.2f * S);
	DrawLine(CX, CY - 6.f * S, CX - 5.f * S, CY + 5.f * S, CyanMe, 2.2f * S);
	DrawLine(CX - 5.f * S, CY + 5.f * S, CX + 5.f * S, CY + 5.f * S, CyanMe, 1.8f * S);

	// North badge at top-center (.map .north: top: 5px; left: 50%; transform: translateX(-50%);
	// background: #141615dd; border: 1px solid #ffffff44; border-radius: 3px; padding: 0 5px; font-size: 9px; font-weight: 800; color: #f3eee4)
	const float NW = 17.f * S, NH = 14.f * S;
	const float NX = CX - NW * 0.5f;
	const float NY = CY - R + 5.f * S;
	Draw9SliceRoundedBox(NX, NY, NW, NH, FName(TEXT("StepTile")), 0.92f, S, 0.40f, false, 0.f);
	DrawFarsiTextBounded(TEXT("N"), FSquadAIHUDPalette::TextWhite(), NX, NY, NW, Font, 0.54f * S, false, true, NH);
}

void AQuestNativeHUD::DrawBorderIndicator(float CX, float CY, float R, const FVector& TargetLoc, const FVector& PlayerLoc, float PlayerYaw, UTexture2D* Icon, const FLinearColor& FallbackColor)
{
	const float S = GameUIScale; // B6-14: resolution scale (menu-HUD parity).
	const FVector Dir = (TargetLoc - PlayerLoc).GetSafeNormal2D();
	const float CosY = FMath::Cos(-FMath::DegreesToRadians(PlayerYaw));
	const float SinY = FMath::Sin(-FMath::DegreesToRadians(PlayerYaw));
	const float RotX = Dir.X * CosY - Dir.Y * SinY;
	const float RotY = Dir.X * SinY + Dir.Y * CosY;
	const float Angle = FMath::Atan2(-RotX, RotY);
	const float BR = R + 14.f * S;
	const float BX = CX + FMath::Cos(Angle) * BR;
	const float BY = CY + FMath::Sin(Angle) * BR;
	if (Icon) DrawIcon(Icon, BX, BY, 16.f * S);
	else DrawFilledCircleArea(FallbackColor, BX, BY, 6.f * S);
}

void AQuestNativeHUD::DrawIcon(UTexture2D* Icon, float X, float Y, float Size)
{
	if (!Icon || !Canvas) return;
	const float Half = Size * 0.5f;
	Canvas->DrawTile(Icon, X - Half, Y - Half, Size, Size, 0.f, 0.f, 1.f, 1.f, BLEND_Translucent);
}

void AQuestNativeHUD::DrawCircleLines(const FLinearColor& C, float CX, float CY, float R, float T)
{
	if (!Canvas) return;
	if (!GetWorld() || !GetWorld()->IsGameWorld()) return;
	constexpr int32 Segments = 24;
	for (int32 i = 0; i < Segments; ++i)
	{
		const float A0 = 2.f * PI * i / static_cast<float>(Segments);
		const float A1 = 2.f * PI * (i + 1) / static_cast<float>(Segments);
		DrawLine(CX + FMath::Cos(A0) * R, CY + FMath::Sin(A0) * R, CX + FMath::Cos(A1) * R, CY + FMath::Sin(A1) * R, C, T);
	}
}

void AQuestNativeHUD::DrawFilledCircleArea(const FLinearColor& C, float CX, float CY, float R)
{
	if (!Canvas) return;
	// B6-3: real scanline-filled circle (every old branch drew squares).
	if (R <= 0.f) return;
	const int32 YTop = FMath::CeilToInt(CY - R);
	const int32 YBottom = FMath::FloorToInt(CY + R);
	for (int32 Y = YTop; Y <= YBottom; ++Y)
	{
		const float DY = (static_cast<float>(Y) + 0.5f) - CY;
		const float HalfW = FMath::Sqrt(FMath::Max(0.f, R * R - DY * DY));
		if (HalfW > 0.f)
		{
			DrawRect(C, CX - HalfW, static_cast<float>(Y), HalfW * 2.f, 1.f);
		}
	}

}

bool AQuestNativeHUD::TryConsumeWorldEPress()
{
	// A downed ally in revive range always wins E over world props.
	if (IsReviveAvailable()) return false;
	if (WasWorldEConsumedThisFrame()) return false;
	WorldEConsumedFrame = GFrameCounter;
	return true;
}

bool AQuestNativeHUD::DoesMapAssetExist(FName MapName) const
{
	if (MapName.IsNone()) return false;
	// Long package names resolve directly.
	if (FPackageName::DoesPackageExist(MapName.ToString())) return true;
	// Short names: scan the cooked registry for a world asset with this name.
	if (FModuleManager::Get().IsModuleLoaded(TEXT("AssetRegistry")))
	{
		FAssetRegistryModule& ARM = FModuleManager::GetModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
		TArray<FAssetData> WorldAssets;
		ARM.Get().GetAssetsByClass(UWorld::StaticClass()->GetClassPathName(), WorldAssets);
		for (const FAssetData& A : WorldAssets)
		{
			if (A.AssetName == MapName) return true;
		}
		return false;
	}
	// Registry unavailable (cooker/early boot) — don't block travel; post-verify still guards.
	return true;
}

void AQuestNativeHUD::VerifyMenuTravel()
{
	// If the menu travel failed (wrong map name), we are still in the same level: tell the
	// player instead of silently dropping them back into combat.
	if (!PendingMenuTravelTarget.IsNone() && GetWorld())
	{
		const FString CurrentLevel = UGameplayStatics::GetCurrentLevelName(GetWorld(), true);
		if (!CurrentLevel.Equals(PendingMenuTravelTarget.ToString(), ESearchCase::IgnoreCase))
		{
			UE_LOG(LogTemp, Error, TEXT("[QuestNativeHUD] Travel to menu '%s' FAILED (still in '%s'). Check MainMenuLevelName / map exists in project."),
				*PendingMenuTravelTarget.ToString(), *CurrentLevel);
			PauseNotificationMessage = FString::Printf(TEXT("\u062e\u0637\u0627: \u0646\u0642\u0634\u0647 \u0645\u0646\u0648\u06cc \u0627\u0635\u0644\u06cc \u06cc\u0627\u0641\u062a \u0646\u0634\u062f (%s)"), *PendingMenuTravelTarget.ToString());
			PauseNotificationColor = FLinearColor(1.0f, 0.25f, 0.2f, 1.0f);
			PauseNotificationTimer = 5.0f;
			PendingMenuTravelTarget = NAME_None;
			TogglePauseMenu(true);
			return;
		}
	}
	PendingMenuTravelTarget = NAME_None;
}

void AQuestNativeHUD::TogglePauseMenu(bool bOpen)
{
	bPauseMenuActive = bOpen;
	if (!bOpen) { bPauseSaveSlotPanelActive = false; } // S18-SAVE
	UGameplayStatics::SetGamePaused(GetWorld(), bPauseMenuActive);

	if (APlayerController* PC = UGameplayStatics::GetPlayerController(GetWorld(), 0))
	{
		PC->bShowMouseCursor = bPauseMenuActive;
		if (bPauseMenuActive)
		{
			FInputModeGameAndUI InputMode;
			InputMode.SetLockMouseToViewportBehavior(EMouseLockMode::DoNotLock);
			InputMode.SetHideCursorDuringCapture(false);
			PC->SetInputMode(InputMode);
		}
		else
		{
			FInputModeGameOnly InputMode;
			PC->SetInputMode(InputMode);
		}
	}
}

void AQuestNativeHUD::ResumeGameFromPauseMenu()
{
	TogglePauseMenu(false);
}

void AQuestNativeHUD::SaveGameFromPauseMenu()
{
	USquadAISaveLoadSubsystem* SaveSys = USquadAISaveLoadSubsystem::Get(this);
	USquadAILocalizationSubsystem* LocSys = USquadAILocalizationSubsystem::Get(this);
	if (SaveSys)
	{
		// B6-1: save into the subsystem autosave slot so Continue/MostRecent can see it
		// (the old "AutoSave_SquadAI" literal matched nothing the subsystem scans).
		const bool bSuccess = SaveSys->SaveGame(SaveSys->GetAutoSaveSlotName());
		if (bSuccess)
		{
			PauseNotificationMessage = LocSys ? LocSys->GetString(TEXT("PauseMenu"), TEXT("SaveSuccessMessage"), TEXT("وضعیت عملیات و موقعیت جوخه با موفقیت ذخیره شد.")) : TEXT("وضعیت عملیات و موقعیت جوخه با موفقیت ذخیره شد.");
			PauseNotificationColor = FLinearColor(0.2f, 0.95f, 0.4f, 1.0f);
		}
		else
		{
			PauseNotificationMessage = LocSys ? LocSys->GetString(TEXT("PauseMenu"), TEXT("SaveFailedMessage"), TEXT("خطا در ذخیره‌سازی وضعیت عملیات.")) : TEXT("خطا در ذخیره‌سازی وضعیت عملیات.");
			PauseNotificationColor = FLinearColor(1.0f, 0.25f, 0.2f, 1.0f);
		}
		PauseNotificationTimer = 4.0f;
	}
}

// ===== S18-SAVE: in-game save slot picker =====
void AQuestNativeHUD::TogglePauseSaveSlotPanel(bool bOpen)
{
	bPauseSaveSlotPanelActive = bOpen;
	PauseSaveSlotHoverIndex = -1;
}

void AQuestNativeHUD::SaveGameToSlotFromPauseMenu(int32 SlotIndex)
{
	USquadAISaveLoadSubsystem* SaveSys = USquadAISaveLoadSubsystem::Get(this);
	USquadAILocalizationSubsystem* LocSys = USquadAILocalizationSubsystem::Get(this);
	const bool bEnglish = SquadAIHUDIsEnglish(this);
	if (!SaveSys)
	{
		PauseNotificationMessage = bEnglish ? TEXT("Save system unavailable.") : TEXT("سامانه ذخیره‌سازی در دسترس نیست.");
		PauseNotificationColor = FLinearColor(1.0f, 0.25f, 0.2f, 1.0f);
		PauseNotificationTimer = 4.0f;
		return;
	}

	const FString SlotName = (SlotIndex < 0)
		? SaveSys->GetAutoSaveSlotName()
		: FString::Printf(TEXT("SquadAISave_Slot%d"), SlotIndex);

	const bool bSuccess = SaveSys->SaveGame(SlotName);
	if (bSuccess)
	{
		PauseNotificationMessage = bEnglish
			? FString::Printf(TEXT("Operation saved to slot %d."), SlotIndex + 1)
			: FString::Printf(TEXT("وضعیت عملیات در موقعیت %d ذخیره شد."), SlotIndex + 1);
		PauseNotificationColor = FLinearColor(0.2f, 0.95f, 0.4f, 1.0f);
	}
	else
	{
		PauseNotificationMessage = LocSys
			? LocSys->GetString(TEXT("PauseMenu"), TEXT("SaveFailedMessage"), TEXT("خطا در ذخیره‌سازی وضعیت عملیات."))
			: TEXT("خطا در ذخیره‌سازی وضعیت عملیات.");
		PauseNotificationColor = FLinearColor(1.0f, 0.25f, 0.2f, 1.0f);
	}
	PauseNotificationTimer = 4.0f;
	UE_LOG(LogTemp, Warning, TEXT("[S18-SAVE] Pause-menu save to '%s' -> %s"), *SlotName, bSuccess ? TEXT("OK") : TEXT("FAILED"));
}

void AQuestNativeHUD::DrawPauseSaveSlotPanel(float CardX, float CardY, float CardW, float CardH, float S,
	float MouseX, float MouseY, bool bLeftClick, UFont* Font)
{
	const bool bEnglish = SquadAIHUDIsEnglish(this);
	USquadAISaveLoadSubsystem* SaveSys = USquadAISaveLoadSubsystem::Get(this);

	const FString Title = bEnglish ? TEXT("Choose a save slot") : TEXT("انتخاب موقعیت ذخیره");
	DrawFarsiTextBounded(Title, FLinearColor(1.0f, 0.85f, 0.35f, 1.0f),
		CardX + 24.f * S, CardY + 88.f * S, CardW - 48.f * S, Font, 1.0f * S, true, true);

	TArray<FSquadSaveSlotInfo> Slots;
	if (SaveSys)
	{
		Slots = SaveSys->GetAllSaveSlots();
	}

	const float RowW = CardW - 48.f * S;
	const float RowH = 52.f * S;
	const float RowX = CardX + 24.f * S;
	float RowY = CardY + 118.f * S;
	int32 ClickedSlot = -2; // -2 = nothing, -1 = autosave, >=0 = manual slot

	for (int32 i = 0; i < Slots.Num(); ++i)
	{
		const FSquadSaveSlotInfo& Info = Slots[i];
		const bool bHover = (MouseX >= RowX && MouseX <= RowX + RowW && MouseY >= RowY && MouseY <= RowY + RowH);
		if (bHover) PauseSaveSlotHoverIndex = i;

		DrawChiseledTacticalBox(RowX, RowY, RowW, RowH,
			bHover ? FLinearColor(0.20f, 0.17f, 0.08f, 1.0f) : FLinearColor(0.07f, 0.10f, 0.14f, 0.95f),
			bHover ? FLinearColor(1.0f, 0.85f, 0.35f, 1.0f) : FLinearColor(0.30f, 0.36f, 0.44f, 0.70f),
			bHover ? 1.5f * S : 1.0f * S, 6.0f * S);

		const FString SlotLabel = bEnglish
			? FString::Printf(TEXT("Slot %d"), i + 1)
			: FString::Printf(TEXT("موقعیت %d"), i + 1);
		DrawFarsiTextBounded(SlotLabel, FLinearColor(0.95f, 0.95f, 0.98f, 1.0f),
			RowX + 12.f * S, RowY + 6.f * S, RowW * 0.4f, Font, 0.90f * S, true, false);

		FString Detail;
		if (Info.bExists)
		{
			Detail = FString::Printf(TEXT("%s  —  %s"), *Info.DisplayName, *Info.Timestamp.ToString(TEXT("%Y/%m/%d %H:%M")));
		}
		else
		{
			Detail = bEnglish ? TEXT("[ empty ]") : TEXT("[ خالی ]");
		}
		DrawFarsiTextBounded(Detail,
			Info.bExists ? FLinearColor(0.70f, 0.78f, 0.86f, 0.95f) : FLinearColor(0.50f, 0.55f, 0.60f, 0.85f),
			RowX + 12.f * S, RowY + 28.f * S, RowW - 24.f * S, Font, 0.72f * S, true, false);

		if (Info.bExists)
		{
			const FString Overwrite = bEnglish ? TEXT("overwrite") : TEXT("بازنویسی");
			DrawFarsiTextBounded(Overwrite, FLinearColor(0.95f, 0.65f, 0.30f, 0.95f),
				RowX + RowW - 90.f * S, RowY + 6.f * S, 84.f * S, Font, 0.70f * S, true, true);
		}

		if (bHover && bLeftClick)
		{
			ClickedSlot = i;
		}
		RowY += RowH + 8.f * S;
	}

	// Autosave row (informational + quick overwrite)
	{
		const bool bHover = (MouseX >= RowX && MouseX <= RowX + RowW && MouseY >= RowY && MouseY <= RowY + RowH * 0.75f);
		DrawChiseledTacticalBox(RowX, RowY, RowW, RowH * 0.75f,
			bHover ? FLinearColor(0.12f, 0.20f, 0.16f, 1.0f) : FLinearColor(0.06f, 0.09f, 0.12f, 0.95f),
			bHover ? FLinearColor(0.35f, 0.95f, 0.55f, 1.0f) : FLinearColor(0.26f, 0.32f, 0.40f, 0.70f),
			1.0f * S, 6.0f * S);
		const FString AutoLabel = bEnglish ? TEXT("Autosave slot") : TEXT("ذخیره خودکار");
		DrawFarsiTextBounded(AutoLabel, FLinearColor(0.80f, 0.90f, 0.85f, 1.0f),
			RowX + 12.f * S, RowY, RowW - 24.f * S, Font, 0.80f * S, true, true, RowH * 0.75f);
		if (bHover && bLeftClick)
		{
			ClickedSlot = -1;
		}
		RowY += RowH * 0.75f + 10.f * S;
	}

	// Back button
	{
		const float BackH = 40.f * S;
		const bool bHover = (MouseX >= RowX && MouseX <= RowX + RowW && MouseY >= RowY && MouseY <= RowY + BackH);
		DrawChiseledTacticalBox(RowX, RowY, RowW, BackH,
			bHover ? FLinearColor(0.24f, 0.18f, 0.18f, 1.0f) : FLinearColor(0.08f, 0.12f, 0.16f, 0.95f),
			bHover ? FLinearColor(1.0f, 0.85f, 0.35f, 1.0f) : FLinearColor(0.30f, 0.36f, 0.44f, 0.70f),
			1.0f * S, 6.0f * S);
		const FString BackLabel = bEnglish ? TEXT("Back") : TEXT("بازگشت");
		DrawFarsiTextBounded(BackLabel, FLinearColor(0.92f, 0.94f, 0.98f, 1.0f),
			RowX + 12.f * S, RowY, RowW - 24.f * S, Font, 0.88f * S, true, true, BackH);
		if (bHover && bLeftClick)
		{
			TogglePauseSaveSlotPanel(false);
			return;
		}
	}

	if (ClickedSlot > -2)
	{
		SaveGameToSlotFromPauseMenu(ClickedSlot);
		TogglePauseSaveSlotPanel(false);
	}

	// Toast inside the picker as well
	if (PauseNotificationTimer > 0.0f && !PauseNotificationMessage.IsEmpty())
	{
		const float ToastH = 30.f * S;
		DrawChiseledTacticalBox(RowX, CardY + CardH - 42.f * S, RowW, ToastH,
			FLinearColor(0.05f, 0.08f, 0.10f, 0.95f), PauseNotificationColor, 1.0f * S, 5.0f * S);
		DrawFarsiTextBounded(PauseNotificationMessage, PauseNotificationColor,
			RowX + 10.f * S, CardY + CardH - 42.f * S, RowW - 20.f * S, Font, 0.72f * S, true, true, ToastH);
	}
}

void AQuestNativeHUD::RestartLevelFromPauseMenu()
{
	TogglePauseMenu(false);
	UGameplayStatics::OpenLevel(this, FName(*UGameplayStatics::GetCurrentLevelName(this, true)));
}

void AQuestNativeHUD::QuitToMainMenuFromPauseMenu()
{
	TogglePauseMenu(false);
	FName TargetMenu = MainMenuLevelName.IsNone() ? FName(TEXT("M_MainMenu")) : MainMenuLevelName;
	// G-3: traveling to the level we are already in shows the loading screen and lands
	// back in the game — flag the misconfig instead of fake-traveling.
	if (GetWorld())
	{
		const FString CurrentLevelNow = UGameplayStatics::GetCurrentLevelName(GetWorld(), true);
		if (TargetMenu.ToString().Equals(CurrentLevelNow, ESearchCase::IgnoreCase))
		{
			UE_LOG(LogTemp, Error, TEXT("[QuestNativeHUD] Quit-to-menu target '%s' IS the current level. Fix MainMenuLevelName on the HUD."), *TargetMenu.ToString());
			PauseNotificationMessage = SquadAIHUDIsEnglish(this) ? FString::Printf(TEXT("Error: main menu map name is invalid (%s)"), *TargetMenu.ToString()) : FString::Printf(TEXT("خطا: نام نقشه منوی اصلی اشتباه است (%s)"), *TargetMenu.ToString());
			PauseNotificationColor = FLinearColor(1.0f, 0.25f, 0.2f, 1.0f);
			PauseNotificationTimer = 5.0f;
			TogglePauseMenu(true);
			return;
		}
	}
	// Route through the loading screen (same path as menu->game) and verify the travel
	// actually happened: raw OpenLevel failures used to drop the player back into combat
	// with no explanation ("returns to game via loading").
	// G-3: pre-validate the destination — OpenLevel to a missing map fails silently.
	if (!DoesMapAssetExist(TargetMenu))
	{
		UE_LOG(LogTemp, Error, TEXT("[QuestNativeHUD] Menu map '%s' not found in project (checked package + asset registry). Staying paused."), *TargetMenu.ToString());
		PauseNotificationMessage = SquadAIHUDIsEnglish(this)
			? FString::Printf(TEXT("Error: main menu map was not found in project (%s)"), *TargetMenu.ToString())
			: FString::Printf(TEXT("\u062e\u0637\u0627: \u0646\u0642\u0634\u0647 \u0645\u0646\u0648\u06cc \u0627\u0635\u0644\u06cc \u062f\u0631 \u067e\u0631\u0648\u0698\u0647 \u06cc\u0627\u0641\u062a \u0646\u0634\u062f (%s)"), *TargetMenu.ToString());
		PauseNotificationColor = FLinearColor(1.0f, 0.25f, 0.2f, 1.0f);
		PauseNotificationTimer = 5.0f;
		TogglePauseMenu(true);
		return;
	}
	PendingMenuTravelTarget = TargetMenu;
	if (USquadAILoadingScreenSubsystem* Loading = USquadAILoadingScreenSubsystem::Get(this))
	{
		Loading->LoadLevelWithScreen(TargetMenu,
			FText::FromString(SquadAIHUDIsEnglish(this) ? TEXT("Main Menu | Command HQ") : TEXT("\u0645\u0646\u0648\u06cc \u0627\u0635\u0644\u06cc | \u0633\u062a\u0627\u062f \u0641\u0631\u0645\u0627\u0646\u062f\u0647\u06cc")),
			FText::FromString(SquadAIHUDIsEnglish(this) ? TEXT("Returning to Operation Khuzestan command headquarters.") : TEXT("\u0628\u0627\u0632\u06af\u0634\u062a \u0628\u0647 \u0633\u062a\u0627\u062f \u0641\u0631\u0645\u0627\u0646\u062f\u0647\u06cc \u0639\u0645\u0644\u06cc\u0627\u062a \u062e\u0648\u0632\u0633\u062a\u0627\u0646.")));
	}
	else
	{
		UGameplayStatics::OpenLevel(this, TargetMenu);
	}
	// One-shot verify in 2s on the core ticker (level timers die with the old world: if the
	// travel succeeded this HUD is gone and the weak ptr fails; if it failed we diagnose).
	TWeakObjectPtr<AQuestNativeHUD> WeakSelf(this);
	FTSTicker::GetCoreTicker().RemoveTicker(MenuTravelVerifyHandle);
	MenuTravelVerifyHandle = FTSTicker::GetCoreTicker().AddTicker(
		FTickerDelegate::CreateLambda([WeakSelf](float /*DeltaTime*/) -> bool
		{
			if (AQuestNativeHUD* StrongSelf = WeakSelf.Get())
			{
				StrongSelf->VerifyMenuTravel();
			}
			return false;
		}), 2.0f);
}

void AQuestNativeHUD::QuitToDesktopFromPauseMenu()
{
	if (APlayerController* PC = UGameplayStatics::GetPlayerController(GetWorld(), 0))
	{
		UKismetSystemLibrary::QuitGame(GetWorld(), PC, EQuitPreference::Quit, false);
	}
}

void AQuestNativeHUD::DrawPauseMenu(float ScreenW, float ScreenH, float DeltaTime, UFont* Font)
{
	if (!Canvas) return;

	// S12-INPUT: the P6-2 draw-side Esc/P resume handler is removed. It existed
	// only because the combat bridge stopped ticking while paused; the bridge now
	// sets PrimaryComponentTick.bTickEvenWhenPaused, so it owns Escape during
	// pause too. Keeping both made Escape fire twice in one frame.

	const float S = GameUIScale; // B6-14: resolution scale (menu-HUD parity).


	USquadAILocalizationSubsystem* LocSys = USquadAILocalizationSubsystem::Get(this);
	const FString HeaderStr = LocSys ? LocSys->GetString(TEXT("PauseMenu"), TEXT("HeaderTitle"), TEXT("توقف عملیات تاکتیکی")) : TEXT("توقف عملیات تاکتیکی");
	const FString SubHeaderStr = LocSys ? LocSys->GetString(TEXT("PauseMenu"), TEXT("SubHeader"), TEXT("منطقه عملیاتی دهلاویه — ستاد جنگ‌های نامنظم")) : TEXT("منطقه عملیاتی دهلاویه — ستاد جنگ‌های نامنظم");

	const FString BtnResumeStr = LocSys ? LocSys->GetString(TEXT("PauseMenu"), TEXT("BtnResume"), TEXT("ادامه نبرد [Esc]")) : TEXT("ادامه نبرد [Esc]");
	const FString BtnSaveStr = LocSys ? LocSys->GetString(TEXT("PauseMenu"), TEXT("BtnSave"), TEXT("ذخیره وضعیت عملیات")) : TEXT("ذخیره وضعیت عملیات");
	const FString BtnRestartStr = LocSys ? LocSys->GetString(TEXT("PauseMenu"), TEXT("BtnRestart"), TEXT("شروع مجدد عملیات")) : TEXT("شروع مجدد عملیات");
	const FString BtnTutorialStr = LocSys ? LocSys->GetString(TEXT("PauseMenu"), TEXT("BtnTutorial"), TEXT("اجرای دوباره آموزش")) : TEXT("اجرای دوباره آموزش"); // S18-TUT3
	const FString BtnQuitMenuStr = LocSys ? LocSys->GetString(TEXT("PauseMenu"), TEXT("BtnQuitMenu"), TEXT("خروج به منوی اصلی")) : TEXT("خروج به منوی اصلی");
	const FString BtnQuitDeskStr = LocSys ? LocSys->GetString(TEXT("PauseMenu"), TEXT("BtnQuitDesktop"), TEXT("خروج به دسکتاپ")) : TEXT("خروج به دسکتاپ");

	// P6-5: these lookups used to run EVERY rendered frame while art was missing — each miss
	// on the loose-PNG fallback path does a disk stat / import attempt. Throttle retries to
	// once every 2 s of wall time (world time freezes under pause, so TimeSeconds would never
	// re-arm). Art dropped in mid-session is still picked up, without the per-frame storm.
	if (!TacticalPauseCardTexture || !TacticalButtonTexture)
	{
		const double NowWallSec = FPlatformTime::Seconds();
		if ((NowWallSec - PauseMenuArtRetryTime) >= 2.0)
		{
			PauseMenuArtRetryTime = NowWallSec;
			if (!TacticalPauseCardTexture) TacticalPauseCardTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Frame_Tactical_PauseCard.UI_Frame_Tactical_PauseCard"), TEXT("Textures/UI_Frame_Tactical_PauseCard.png"));
			if (!TacticalButtonTexture) TacticalButtonTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Button_Tactical_Normal.UI_Button_Tactical_Normal"), TEXT("Textures/UI_Button_Tactical_Normal.png"));
		}
	}

	// 1. Frosted Translucent Screen Backdrop
	DrawRect(FLinearColor(0.02f, 0.035f, 0.055f, 0.88f), 0.f, 0.f, ScreenW, ScreenH);

	// 2. Modal Pause Card Dimensions
	const float CardW = FMath::Min(480.f * S, ScreenW - 40.f * S);
	const float CardH = bPauseSaveSlotPanelActive ? 520.f * S : 518.f * S; // S18-SAVE / S18-TUT3 (6 buttons)
	const float CardX = (ScreenW - CardW) * 0.5f;
	const float CardY = (ScreenH - CardH) * 0.5f;

	// Draw Background Box
	DrawChiseledTacticalBox(CardX, CardY, CardW, CardH,
		FLinearColor(0.04f, 0.055f, 0.08f, 0.98f),
		FLinearColor(1.0f, 0.82f, 0.25f, 0.90f), 1.5f * S, 10.0f * S);

	// Gold Laser Chamfer Top Accent
	DrawRect(FLinearColor(1.0f, 0.82f, 0.25f, 1.0f), CardX + 20.f * S, CardY + 2.f * S, CardW - 40.f * S, 2.f * S);

	// Header
	DrawFarsiTextBounded(HeaderStr,
		FLinearColor(1.0f, 0.85f, 0.35f, 1.0f), CardX + 24.f * S, CardY + 20.f * S, CardW - 48.f * S, Font, 1.25f * S, true, true);

	DrawFarsiTextBounded(SubHeaderStr,
		FLinearColor(0.70f, 0.75f, 0.82f, 0.90f), CardX + 24.f * S, CardY + 52.f * S, CardW - 48.f * S, Font, 0.80f * S, true, true);

	// Separator Line
	DrawRect(FLinearColor(0.25f, 0.30f, 0.38f, 0.60f), CardX + 24.f * S, CardY + 80.f * S, CardW - 48.f * S, 1.f * S);

	// Mouse Coordinates for Button Hover & Click
	APlayerController* PC = UGameplayStatics::GetPlayerController(GetWorld(), 0);
	float MouseX = 0.f, MouseY = 0.f;
	bool bLeftClick = false;
	if (PC)
	{
		PC->GetMousePosition(MouseX, MouseY);
		bLeftClick = PC->WasInputKeyJustPressed(EKeys::LeftMouseButton);
	}

	// 5 Action Buttons
	struct FPauseButtonInfo
	{
		FString Label;
		FLinearColor BaseColor;
		FLinearColor HighlightColor;
	};

	TArray<FPauseButtonInfo> Buttons = {
		{ BtnResumeStr, FLinearColor(0.08f, 0.12f, 0.16f, 0.95f), FLinearColor(0.18f, 0.32f, 0.24f, 1.0f) },
		{ BtnSaveStr, FLinearColor(0.08f, 0.12f, 0.16f, 0.95f), FLinearColor(0.28f, 0.24f, 0.12f, 1.0f) },
		{ BtnRestartStr, FLinearColor(0.08f, 0.12f, 0.16f, 0.95f), FLinearColor(0.18f, 0.22f, 0.30f, 1.0f) },
		{ BtnTutorialStr, FLinearColor(0.08f, 0.12f, 0.16f, 0.95f), FLinearColor(0.16f, 0.28f, 0.30f, 1.0f) }, // S18-TUT3
		{ BtnQuitMenuStr, FLinearColor(0.08f, 0.12f, 0.16f, 0.95f), FLinearColor(0.24f, 0.18f, 0.18f, 1.0f) },
		{ BtnQuitDeskStr, FLinearColor(0.08f, 0.12f, 0.16f, 0.95f), FLinearColor(0.35f, 0.12f, 0.12f, 1.0f) }
	};

	// S18-SAVE: the slot picker takes over the card body while it is open.
	if (bPauseSaveSlotPanelActive)
	{
		DrawPauseSaveSlotPanel(CardX, CardY, CardW, CardH, S, MouseX, MouseY, bLeftClick, Font);
		if (PauseNotificationTimer > 0.0f)
		{
			PauseNotificationTimer -= DeltaTime;
		}
		return;
	}

	const float BtnW = CardW - 48.f * S;
	const float BtnH = 46.f * S;
	const float BtnX = CardX + 24.f * S;
	float CurrentBtnY = CardY + 98.f * S;
	int32 ClickedIndex = -1;

	for (int32 i = 0; i < Buttons.Num(); ++i)
	{
		const bool bHover = (MouseX >= BtnX && MouseX <= BtnX + BtnW && MouseY >= CurrentBtnY && MouseY <= CurrentBtnY + BtnH);
		const FLinearColor BoxCol = bHover ? Buttons[i].HighlightColor : Buttons[i].BaseColor;
		const FLinearColor BorderCol = bHover ? FLinearColor(1.0f, 0.85f, 0.35f, 1.0f) : FLinearColor(0.30f, 0.36f, 0.44f, 0.70f);

		DrawChiseledTacticalBox(BtnX, CurrentBtnY, BtnW, BtnH, BoxCol, BorderCol, bHover ? 1.5f * S : 1.0f * S, 6.0f * S);

		if (bHover)
		{
			DrawRect(FLinearColor(1.0f, 0.85f, 0.35f, 1.0f), BtnX + BtnW - 4.f * S, CurrentBtnY + 4.f * S, 3.f * S, BtnH - 8.f * S);
		}

		const FLinearColor TextCol = bHover ? FLinearColor(1.0f, 0.92f, 0.45f, 1.0f) : FLinearColor(0.90f, 0.92f, 0.96f, 1.0f);
		DrawFarsiTextBounded(Buttons[i].Label, TextCol, BtnX + 16.f * S, CurrentBtnY, BtnW - 32.f * S, Font, 0.95f * S, true, true, BtnH);

		if (bHover && bLeftClick)
		{
			ClickedIndex = i;
		}

		CurrentBtnY += BtnH + 12.f * S;
	}

	// Handle button click action
	if (ClickedIndex >= 0)
	{
		switch (ClickedIndex)
		{
		case 0: ResumeGameFromPauseMenu(); break;
		// S18-SAVE: was a silent write to the autosave slot — that is why no slot
		// list ever opened in game even though the main menu shows them all.
		case 1: TogglePauseSaveSlotPanel(true); break;
		case 2: RestartLevelFromPauseMenu(); break;
		// S18-TUT3: replay the training without restarting the level.
		case 3:
			if (USquadAITutorialSubsystem* Tut = USquadAITutorialSubsystem::Get(this))
			{
				ResumeGameFromPauseMenu();
				Tut->RestartTutorial();
			}
			break;
		case 4: QuitToMainMenuFromPauseMenu(); break;
		case 5: QuitToDesktopFromPauseMenu(); break;
		}
	}

	// Save Notification Toast Message
	if (PauseNotificationTimer > 0.0f)
	{
		PauseNotificationTimer -= DeltaTime;
		const float ToastW = CardW - 48.f * S;
		const float ToastH = 34.f * S;
		const float ToastX = CardX + 24.f * S;
		const float ToastY = CardY + CardH - 46.f * S;

		DrawChiseledTacticalBox(ToastX, ToastY, ToastW, ToastH,
			FLinearColor(0.04f, 0.08f, 0.05f, 0.95f),
			PauseNotificationColor, 1.5f * S, 4.0f * S);

		DrawFarsiTextBounded(PauseNotificationMessage,
			PauseNotificationColor, ToastX + 12.f * S, ToastY, ToastW - 24.f * S, Font, 0.82f * S, true, true, ToastH);
	}
}

void AQuestNativeHUD::ToggleInventory(bool bOpen)
{
	bInventoryOpen = bOpen;
	UGameplayStatics::SetGamePaused(GetWorld(), bInventoryOpen);

	if (bInventoryOpen)
	{
		if (USquadAIInventorySubsystem* Inv = USquadAIInventorySubsystem::Get(this))
		{
			Inv->OnInventoryOpened();
		}
	}

	if (APlayerController* PC = UGameplayStatics::GetPlayerController(GetWorld(), 0))
	{
		PC->bShowMouseCursor = bInventoryOpen;
		if (bInventoryOpen)
		{
			FInputModeGameAndUI InputMode;
			InputMode.SetLockMouseToViewportBehavior(EMouseLockMode::DoNotLock);
			InputMode.SetHideCursorDuringCapture(false);
			PC->SetInputMode(InputMode);
		}
		else
		{
			FInputModeGameOnly InputMode;
			PC->SetInputMode(InputMode);
		}
	}
}

void AQuestNativeHUD::DrawInventoryScreen(float ScreenW, float ScreenH, float DeltaTime, UFont* Font, APawn* PlayerPawn)
{
	if (!Canvas) return;
	const float UIS = GameUIScale; // B6-14: resolution scale (UIS: tab-0 stats loop owns S).


	USquadAIInventorySubsystem* Inv = USquadAIInventorySubsystem::Get(this);
	USquadAILocalizationSubsystem* LocSys = USquadAILocalizationSubsystem::Get(this);

	APlayerController* PC = UGameplayStatics::GetPlayerController(GetWorld(), 0);
	float MouseX = 0.f, MouseY = 0.f;
	bool bLeftClick = false;
	if (PC)
	{
		PC->GetMousePosition(MouseX, MouseY);
		bLeftClick = PC->WasInputKeyJustPressed(EKeys::LeftMouseButton);

		// S12-INPUT: removed. Reading I/Escape here (in draw code, same frame the
		// combat bridge already toggled the panel) closed the inventory the
		// instant it opened. USquadAIPlayerCombatBridge is the single owner of
		// these keys now.

		if (PC->WasInputKeyJustPressed(EKeys::E))
		{
			if (Inv) Inv->NextWeapon();
		}
		else if (PC->WasInputKeyJustPressed(EKeys::Q))
		{
			if (Inv) Inv->PreviousWeapon();
		}
	}

	RadioWaveformAnimTimer += DeltaTime * 6.0f;

	// 1. Dark Frosted Background Backdrop
	DrawRect(FLinearColor(0.02f, 0.035f, 0.055f, 0.90f), 0.f, 0.f, ScreenW, ScreenH);

	// 2. Main Backpack Window Dimensions
	const float WinW = FMath::Min(980.f * UIS, ScreenW - 40.f * UIS);
	const float WinH = FMath::Min(640.f * UIS, ScreenH - 40.f * UIS);
	const float WinX = (ScreenW - WinW) * 0.5f;
	const float WinY = (ScreenH - WinH) * 0.5f;

	// Draw Obsidian Chassis Box with 1px Gold Laser Chamfer
	DrawChiseledTacticalBox(WinX, WinY, WinW, WinH,
		FLinearColor(0.04f, 0.055f, 0.075f, 0.98f),
		FLinearColor(1.0f, 0.82f, 0.25f, 0.95f), 1.5f * UIS, 10.0f * UIS);

	// Golden Laser Header Line
	DrawRect(FLinearColor(1.0f, 0.82f, 0.25f, 1.0f), WinX + 20.f * UIS, WinY + 2.f * UIS, WinW - 40.f * UIS, 2.f * UIS);

	// Header Titles
	const bool bEnglishHUD = SquadAIHUDIsEnglish(this);
	const FString HeaderStr = LocSys ? LocSys->GetString(TEXT("Inventory"), TEXT("HeaderTitle"), TEXT("کوله‌پشتی و تجهیزات انفرادی رزمنده")) : (bEnglishHUD ? TEXT("Backpack and Personal Equipment") : TEXT("کوله‌پشتی و تجهیزات انفرادی رزمنده"));
	const FString SubHeaderStr = LocSys ? LocSys->GetString(TEXT("Inventory"), TEXT("SubHeader"), TEXT("ستاد جنگ‌های نامنظم — جبهه خوزستان")) : (bEnglishHUD ? TEXT("Irregular Warfare HQ — Khuzestan Front") : TEXT("ستاد جنگ‌های نامنظم — جبهه خوزستان"));

	DrawFarsiTextBounded(HeaderStr, FLinearColor(1.0f, 0.85f, 0.35f, 1.0f), WinX + 24.f * UIS, WinY + 16.f * UIS, WinW - 220.f * UIS, Font, 1.25f * UIS, true);
	DrawFarsiTextBounded(SubHeaderStr, FLinearColor(0.70f, 0.75f, 0.82f, 0.90f), WinX + 24.f * UIS, WinY + 44.f * UIS, WinW - 220.f * UIS, Font, 0.78f * UIS, true);

	// Close Prompt Top-Right
	DrawFarsiTextBounded(SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("ClosePrompt"), TEXT("[I / Esc] بستن کوله‌پشتی"), TEXT("[I / Esc] Close backpack")), FLinearColor(0.85f, 0.85f, 0.85f, 0.80f), WinX + WinW - 190.f * UIS, WinY + 18.f * UIS, 170.f * UIS, Font, 0.75f * UIS, false, true);

	// 3. Tab Bar (6 Tabs)
	struct FInvTab
	{
		FString Label;
		int32 TabID;
	};

	// L2-INI: every tab label is INI-driven (Tab* keys were user decoys, now live).
	TArray<FInvTab> Tabs = {
		{ SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("TabWeapons"),  TEXT("زرادخانه و تسلیحات (Q/E)"), TEXT("Armory and Weapons (Q/E)")), 0 },
		{ SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("TabNotes"),    TEXT("دست‌نوشته همرزمان"), TEXT("Comrades' Field Notes")), 1 },
		{ SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("TabRadio"),    TEXT("بی‌سیم و رادیو جیبی"), TEXT("Pocket Radio")), 2 },
		{ SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("TabQuran"),    TEXT("قرآن و ادعیه متبرک"), TEXT("Quran and Prayers")), 3 },
		{ SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("TabWallet"),   TEXT("کیف مدارک و پلاک"), TEXT("Documents and Dog Tag")), 4 },
		{ SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("TabSupplies"), TEXT("اقلام و تدارکات"), TEXT("Supplies")), 5 }
	};

	const float TabBarY = WinY + 70.f * UIS;
	const float TabW = (WinW - 48.f * UIS) / Tabs.Num();
	const float TabH = 34.f * UIS;

	for (int32 i = 0; i < Tabs.Num(); ++i)
	{
		const float TabX = WinX + 24.f * UIS + (i * TabW);
		const bool bActive = (InventoryActiveTab == i);
		const bool bHover = (MouseX >= TabX && MouseX <= TabX + TabW - 4.f * UIS && MouseY >= TabBarY && MouseY <= TabBarY + TabH);

		const FLinearColor TabBg = bActive ? FLinearColor(0.22f, 0.17f, 0.05f, 0.98f) :
								   bHover ? FLinearColor(0.12f, 0.15f, 0.18f, 0.90f) :
								   FLinearColor(0.06f, 0.08f, 0.10f, 0.75f);

		const FLinearColor TabBorder = bActive ? FLinearColor(1.0f, 0.82f, 0.25f, 1.0f) :
									   bHover ? FLinearColor(0.60f, 0.70f, 0.80f, 0.80f) :
									   FLinearColor(0.20f, 0.25f, 0.30f, 0.50f);

		DrawChiseledTacticalBox(TabX, TabBarY, TabW - 4.f * UIS, TabH, TabBg, TabBorder, bActive ? 1.5f * UIS : 1.0f * UIS, 4.0f * UIS);

		const FLinearColor TabTextCol = bActive ? FLinearColor(1.0f, 0.88f, 0.40f, 1.0f) :
										bHover ? FLinearColor::White :
										FLinearColor(0.70f, 0.75f, 0.80f, 0.80f);

		DrawFarsiTextBounded(Tabs[i].Label, TabTextCol, TabX + 4.f * UIS, TabBarY, TabW - 12.f * UIS, Font, 0.75f * UIS, true, true, TabH);

		if (bHover && bLeftClick)
		{
			InventoryActiveTab = i;
		}
	}

	// 4. Content Area
	const float ContentX = WinX + 24.f * UIS;
	const float ContentY = TabBarY + TabH + 14.f * UIS;
	const float ContentW = WinW - 48.f * UIS;
	const float ContentH = WinH - (ContentY - WinY) - 20.f * UIS;

	DrawChiseledTacticalBox(ContentX, ContentY, ContentW, ContentH,
		FLinearColor(0.03f, 0.04f, 0.055f, 0.95f),
		FLinearColor(0.25f, 0.30f, 0.38f, 0.70f), 1.0f * UIS, 8.0f * UIS);

	// =========================================================================
	//  TAB 0: WEAPONS ARSENAL
	// =========================================================================
	if (InventoryActiveTab == 0 && Inv)
	{
		const FSquadInventoryWeaponItem W = Inv->GetSelectedWeapon();

		// Left: Weapon Showcase & Carousel (< and > arrows)
		const float LeftColW = ContentW * 0.52f;
		const float ArrowW = 38.f * UIS;
		const float ArrowH = 46.f * UIS;
		const float ArrowY = ContentY + 40.f * UIS;

		// Prev Arrow [<]
		const float LeftArrowX = ContentX + 16.f * UIS;
		const bool bLeftArrowHover = (MouseX >= LeftArrowX && MouseX <= LeftArrowX + ArrowW && MouseY >= ArrowY && MouseY <= ArrowY + ArrowH);
		DrawChiseledTacticalBox(LeftArrowX, ArrowY, ArrowW, ArrowH,
			bLeftArrowHover ? FLinearColor(0.25f, 0.20f, 0.06f, 0.95f) : FLinearColor(0.08f, 0.10f, 0.14f, 0.90f),
			bLeftArrowHover ? FLinearColor(1.0f, 0.82f, 0.25f, 1.0f) : FLinearColor(0.35f, 0.40f, 0.48f, 0.70f), 1.0f * UIS, 4.0f * UIS);
		DrawFarsiTextBounded(TEXT("<"), FLinearColor::White, LeftArrowX, ArrowY, ArrowW, Font, 1.10f * UIS, false, true, ArrowH);
		if (bLeftArrowHover && bLeftClick)
		{
			Inv->PreviousWeapon();
			if (PlayerPawn) Inv->EquipSelectedWeapon(PlayerPawn);
		}

		// Next Arrow [>]
		const float RightArrowX = ContentX + LeftColW - ArrowW - 16.f * UIS;
		const bool bRightArrowHover = (MouseX >= RightArrowX && MouseX <= RightArrowX + ArrowW && MouseY >= ArrowY && MouseY <= ArrowY + ArrowH);
		DrawChiseledTacticalBox(RightArrowX, ArrowY, ArrowW, ArrowH,
			bRightArrowHover ? FLinearColor(0.25f, 0.20f, 0.06f, 0.95f) : FLinearColor(0.08f, 0.10f, 0.14f, 0.90f),
			bRightArrowHover ? FLinearColor(1.0f, 0.82f, 0.25f, 1.0f) : FLinearColor(0.35f, 0.40f, 0.48f, 0.70f), 1.0f * UIS, 4.0f * UIS);
		DrawFarsiTextBounded(TEXT(">"), FLinearColor::White, RightArrowX, ArrowY, ArrowW, Font, 1.10f * UIS, false, true, ArrowH);
		if (bRightArrowHover && bLeftClick)
		{
			Inv->NextWeapon();
			if (PlayerPawn) Inv->EquipSelectedWeapon(PlayerPawn);
		}

		// Weapon Name & Caliber in Center
		const FSquadInventoryWeaponItem CurW = Inv->GetSelectedWeapon();
		const float NameX = LeftArrowX + ArrowW + 12.f * UIS;
		const float NameW = RightArrowX - NameX - 12.f * UIS;
		DrawFarsiTextBounded(CurW.DisplayName, FLinearColor(1.0f, 0.85f, 0.35f, 1.0f), NameX, ArrowY + 4.f * UIS, NameW, Font, 1.15f * UIS, true);
		DrawFarsiTextBounded(CurW.Caliber, FLinearColor(0.65f, 0.70f, 0.78f, 0.85f), NameX, ArrowY + 28.f * UIS, NameW, Font, 0.75f * UIS, true);

		// Weapon Silhouette Frame
		const float FrameX = ContentX + 24.f * UIS;
		const float FrameY = ArrowY + ArrowH + 16.f * UIS;
		const float FrameW = LeftColW - 48.f * UIS;
		const float FrameH = 180.f * UIS;

		DrawChiseledTacticalBox(FrameX, FrameY, FrameW, FrameH,
			FLinearColor(0.02f, 0.03f, 0.04f, 0.95f),
			FLinearColor(0.30f, 0.35f, 0.42f, 0.75f), 1.0f * UIS, 6.0f * UIS);

		UTexture2D* WepTex = (CurW.WeaponID == FName("Pistol"))
			? GetUITexture(FName(TEXT("IconSidearm3D")))
			: GetHUDWeaponIcon(CurW.WeaponID.ToString() + TEXT(" ") + CurW.DisplayName);
		if (WepTex)
		{
			DrawTexture(WepTex, FrameX + 20.f * UIS, FrameY + 20.f * UIS, FrameW - 40.f * UIS, FrameH - 40.f * UIS, 0.f, 0.f, 1.f, 1.f, FLinearColor(1.0f, 0.88f, 0.45f, 0.95f));
		}
		else
		{
			DrawWeaponSilhouette(W.DisplayName, FrameX + FrameW * 0.5f - 50.f * UIS, FrameY + FrameH * 0.5f - 15.f * UIS, 1.5f * UIS, FLinearColor(1.0f, 0.85f, 0.35f, 0.80f));
		}

		// Equip Weapon Button
		const float EquipBtnX = FrameX;
		const float EquipBtnY = FrameY + FrameH + 14.f * UIS;
		const float EquipBtnW = FrameW;
		const float EquipBtnH = 42.f * UIS;
		const bool bEquipHover = (MouseX >= EquipBtnX && MouseX <= EquipBtnX + EquipBtnW && MouseY >= EquipBtnY && MouseY <= EquipBtnY + EquipBtnH);

		DrawChiseledTacticalBox(EquipBtnX, EquipBtnY, EquipBtnW, EquipBtnH,
			bEquipHover ? FLinearColor(0.18f, 0.35f, 0.22f, 0.98f) : FLinearColor(0.08f, 0.16f, 0.10f, 0.90f),
			bEquipHover ? FLinearColor(0.35f, 1.0f, 0.50f, 1.0f) : FLinearColor(0.20f, 0.75f, 0.35f, 0.80f), 1.5f * UIS, 6.0f * UIS);

		DrawFarsiTextBounded(SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("EquipWeaponButton"), TEXT("تجهیز و آماده‌سازی سلاح [کلیک]"), TEXT("Equip and ready weapon [Click]")), FLinearColor::White, EquipBtnX, EquipBtnY, EquipBtnW, Font, 0.95f * UIS, true, true, EquipBtnH);
		if (bEquipHover && bLeftClick)
		{
			Inv->EquipSelectedWeapon(PlayerPawn);
		}

		// Right Column: Ballistic Ratings & Live Ammo
		const float RightColX = ContentX + LeftColW + 16.f * UIS;
		const float RightColW = ContentW - LeftColW - 32.f * UIS;

		DrawFarsiTextBounded(SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("BallisticsHeader"), TEXT("مشخصات بالستیک و وضعیت مهمات"), TEXT("Ballistics and ammunition status")), FLinearColor(1.0f, 0.85f, 0.35f, 1.0f), RightColX, ContentY + 20.f * UIS, RightColW, Font, 1.0f * UIS, true);

		// Ammo Box
		const float AmmoBoxY = ContentY + 48.f * UIS;
		DrawChiseledTacticalBox(RightColX, AmmoBoxY, RightColW, 48.f * UIS,
			FLinearColor(0.06f, 0.08f, 0.10f, 0.90f),
			FLinearColor(0.30f, 0.36f, 0.44f, 0.70f), 1.0f * UIS, 4.0f * UIS);

		// L2-INI: Inventory.AmmoLabel carries the full printf format (user key, now live).
		const FString AmmoFmt = SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("AmmoLabel"), TEXT("مهمات در خشاب: %d  |  ذخیره کوله‌پشتی: %d"), TEXT("Clip ammo: %d  |  Backpack reserve: %d"));
		const FString AmmoStr = SquadAIFormatRuntime(*AmmoFmt, W.ClipAmmo, W.ReserveAmmo);
		DrawFarsiTextBounded(AmmoStr, FLinearColor(0.30f, 0.95f, 0.45f, 1.0f), RightColX + 16.f * UIS, AmmoBoxY, RightColW - 32.f * UIS, Font, 0.90f * UIS, true, false, 48.f * UIS);

		// Description
		DrawFarsiTextBounded(W.Description, FLinearColor(0.80f, 0.84f, 0.90f, 0.95f), RightColX, AmmoBoxY + 56.f * UIS, RightColW, Font, 0.78f * UIS, true);

		// 4 Rating Bars
		struct FStatEntry
		{
			FString Name;
			float Value;
			FLinearColor Col;
		};

		TArray<FStatEntry> Stats = {
				{ SquadAIHUDLocal(this, TEXT("Armory"), TEXT("Stat_Damage"),   TEXT("قدرت آتش (Damage)"),    TEXT("Firepower")),       W.DamageRating,   FLinearColor(1.0f, 0.35f, 0.25f, 1.0f) },
				{ SquadAIHUDLocal(this, TEXT("Armory"), TEXT("Stat_Accuracy"), TEXT("دقت هدف‌گیری (Accuracy)"), TEXT("Accuracy")),      W.AccuracyRating, FLinearColor(0.25f, 0.85f, 1.0f, 1.0f) },
				{ SquadAIHUDLocal(this, TEXT("Armory"), TEXT("Stat_FireRate"), TEXT("نواخت تیر (Fire Rate)"),  TEXT("Fire Rate")),     W.FireRateRating, FLinearColor(1.0f, 0.75f, 0.20f, 1.0f) },
				{ SquadAIHUDLocal(this, TEXT("Armory"), TEXT("Stat_Range"),    TEXT("برد موثر (Range)"),      TEXT("Effective Range")), W.RangeRating,    FLinearColor(0.40f, 0.95f, 0.45f, 1.0f) }
		};

		float StatY = AmmoBoxY + 120.f * UIS;
		for (const auto& S : Stats)
		{
			DrawFarsiTextBounded(S.Name, FLinearColor(0.90f, 0.92f, 0.96f, 1.0f), RightColX, StatY, RightColW, Font, 0.78f * UIS, true);
			const float BarW = RightColW - 10.f * UIS;
			DrawRect(FLinearColor(0.10f, 0.12f, 0.16f, 0.90f), RightColX, StatY + 22.f * UIS, BarW, 8.f * UIS);
			DrawRect(S.Col, RightColX, StatY + 22.f * UIS, BarW * FMath::Clamp(S.Value, 0.05f, 1.0f), 8.f * UIS);
			StatY += 42.f * UIS;
		}
	}

	// =========================================================================
	//  TAB 1: FALLEN SOLDIERS' NOTES (دست‌نوشته همرزمان شهید)
	// =========================================================================
	else if (InventoryActiveTab == 1 && Inv)
	{
		const FSquadFallenTroopNote Note = Inv->GetCurrentFallenNote();

		const float NotePadX = ContentX + 30.f * UIS;
		const float NotePadY = ContentY + 20.f * UIS;
		const float NotePadW = ContentW - 60.f * UIS;
		const float NotePadH = ContentH - 90.f * UIS;

		DrawChiseledTacticalBox(NotePadX, NotePadY, NotePadW, NotePadH,
			FLinearColor(0.08f, 0.07f, 0.05f, 0.96f),
			FLinearColor(0.75f, 0.60f, 0.30f, 0.80f), 1.5f * UIS, 8.0f * UIS);

		// Left: High-Res Wartime Letter Document Placeholder (Drag-and-Drop Slot)
		const float NoteArtW = 280.f * UIS;
		const float NoteArtH = NotePadH - 40.f * UIS;
		const float NoteArtX = NotePadX + 20.f * UIS;
		const float NoteArtY = NotePadY + 20.f * UIS;

		if (FallenNotesArtwork)
		{
			DrawTexture(FallenNotesArtwork, NoteArtX, NoteArtY, NoteArtW, NoteArtH, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
			DrawChiseledTacticalBox(NoteArtX, NoteArtY, NoteArtW, NoteArtH, FLinearColor::Transparent, FLinearColor(0.75f, 0.60f, 0.30f, 0.80f), 1.0f * UIS, 4.0f * UIS);
		}

		// Right: Letter Content & Dog Tag
		const float TextStartX = FallenNotesArtwork ? (NoteArtX + NoteArtW + 24.f * UIS) : (NotePadX + 24.f * UIS);
		const float TextAvailableW = NotePadW - (FallenNotesArtwork ? (NoteArtW + 48.f * UIS) : 48.f * UIS);

		if (ItemDogTagTexture)
		{
			DrawTexture(ItemDogTagTexture, NotePadX + NotePadW - 74.f * UIS, NotePadY + 14.f * UIS, 54.f * UIS, 54.f * UIS, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
		}

		const float TitleW = ItemDogTagTexture ? (TextAvailableW - 65.f * UIS) : TextAvailableW;
		DrawFarsiTextBounded(Note.Title, FLinearColor(1.0f, 0.85f, 0.35f, 1.0f), TextStartX, NotePadY + 18.f * UIS, TitleW, Font, 1.25f * UIS, true);
		DrawRect(FLinearColor(0.75f, 0.60f, 0.30f, 0.50f), TextStartX, NotePadY + 54.f * UIS, TextAvailableW, 1.f * UIS);

		// Multi-line Note Content
		TArray<FString> NoteLines;
		Note.Content.ParseIntoArrayLines(NoteLines, false);
		if (NoteLines.Num() == 0 && !Note.Content.IsEmpty())
		{
			NoteLines.Add(Note.Content);
		}

		float NoteCurY = NotePadY + 68.f * UIS;
		for (const FString& NL : NoteLines)
		{
			DrawFarsiTextBounded(NL, FLinearColor(0.92f, 0.90f, 0.85f, 1.0f), TextStartX, NoteCurY, TextAvailableW, Font, 0.98f * UIS, true);
			NoteCurY += 30.f * UIS;
		}

		// Next Note Button
		const float NextNoteBtnW = 280.f * UIS;
		const float NextNoteBtnH = 42.f * UIS;
		const float NextNoteBtnX = NotePadX + (NotePadW - NextNoteBtnW) * 0.5f;
		const float NextNoteBtnY = ContentY + ContentH - 58.f * UIS;
		const bool bNextHover = (MouseX >= NextNoteBtnX && MouseX <= NextNoteBtnX + NextNoteBtnW && MouseY >= NextNoteBtnY && MouseY <= NextNoteBtnY + NextNoteBtnH);

		DrawChiseledTacticalBox(NextNoteBtnX, NextNoteBtnY, NextNoteBtnW, NextNoteBtnH,
			bNextHover ? FLinearColor(0.24f, 0.18f, 0.06f, 0.98f) : FLinearColor(0.10f, 0.08f, 0.04f, 0.90f),
			bNextHover ? FLinearColor(1.0f, 0.82f, 0.25f, 1.0f) : FLinearColor(0.75f, 0.60f, 0.30f, 0.80f), 1.5f * UIS, 6.0f * UIS);

		DrawFarsiTextBounded(SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("NextNoteButton"), TEXT("مطالعه دست‌نوشته دیگر [کلیک]"), TEXT("Read another note [Click]")), FLinearColor::White, NextNoteBtnX, NextNoteBtnY, NextNoteBtnW, Font, 0.95f * UIS, true, true, NextNoteBtnH);
		if (bNextHover && bLeftClick)
		{
			Inv->NextFallenNote();
		}
	}

	// =========================================================================
	//  TAB 2: POCKET FRONTLINE RADIO (بی‌سیم و رادیو جیبی)
	// =========================================================================
	else if (InventoryActiveTab == 2 && Inv)
	{
		const FSquadRadioStation Station = Inv->GetCurrentRadioStation();

		const float RadioX = ContentX + 30.f * UIS;
		const float RadioY = ContentY + 20.f * UIS;
		const float RadioW = ContentW - 60.f * UIS;
		const float RadioH = ContentH - 50.f * UIS;

		DrawChiseledTacticalBox(RadioX, RadioY, RadioW, RadioH,
			FLinearColor(0.04f, 0.05f, 0.07f, 0.96f),
			FLinearColor(1.0f, 0.82f, 0.25f, 0.90f), 1.5f * UIS, 10.0f * UIS);

		// Left: Photorealistic 3D Vintage Radio Render (Preserved Aspect Ratio)
		// S24-INVFIX: the art square used to take its size from the panel HEIGHT
		// alone. On every capped window that left the right column NARROWER than
		// the fixed 3x160 px tuner button row below it - the power button drew
		// ~74 px past the radio box and ~20 px OUT of the inventory window. The
		// art is now clamped by the WIDTH too, so the content column keeps a floor.
		const float ArtSz = FMath::Clamp(RadioH - 50.f * UIS, 120.f * UIS, FMath::Max(120.f * UIS, RadioW - 360.f * UIS));
		if (ItemPocketRadioTexture)
		{
			DrawTexture(ItemPocketRadioTexture, RadioX + 24.f * UIS, RadioY + 25.f * UIS, ArtSz, ArtSz, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
		}

		const float RadioContentX = ItemPocketRadioTexture ? (RadioX + ArtSz + 40.f * UIS) : (RadioX + 24.f * UIS);
		const float RadioContentW = RadioW - (ItemPocketRadioTexture ? (ArtSz + 64.f * UIS) : 48.f * UIS);

		DrawFarsiTextBounded(SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("RadioTitle"), TEXT("رادیو و بی‌سیم جیبی گراندیک (گیرنده امواج حماسی جبهه)"), TEXT("Grundig pocket radio and tactical receiver")),
			FLinearColor(1.0f, 0.85f, 0.35f, 1.0f), RadioContentX, RadioY + 20.f * UIS, RadioContentW, Font, 1.25f * UIS, true);

		// Frequency Display Panel
		const float FreqBoxY = RadioY + 64.f * UIS;
		const float FreqBoxH = 88.f * UIS;

		DrawChiseledTacticalBox(RadioContentX, FreqBoxY, RadioContentW, FreqBoxH,
			FLinearColor(0.02f, 0.04f, 0.03f, 0.98f),
			FLinearColor(0.20f, 0.85f, 0.40f, 0.90f), 1.5f * UIS, 6.0f * UIS);

		// L2-INI: Inventory.RadioTunerLabel (user key) — station name appended after the label portion.
		const FString TunerFmt = SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("RadioTunerLabel"), TEXT("فرکانس: %.1f MHz"), TEXT("Frequency: %.1f MHz"));
		const FString FreqStr = FString::Printf(TEXT("%s  |  %s"), *SquadAIFormatRuntime(*TunerFmt, Station.Frequency), *Station.StationName);
		// S24-INVFIX: while playing, the equalizer bars own the right ~150 px of
		// this box - the text boxes shrink out of their way instead of printing
		// under the bars (a long station name used to run into them).
		const float FreqTextW = RadioContentW - 40.f * UIS - (Inv->IsRadioPlaying() ? 150.f * UIS : 0.f);
		DrawFarsiTextBounded(FreqStr, FLinearColor(0.35f, 1.0f, 0.50f, 1.0f), RadioContentX + 20.f * UIS, FreqBoxY + 14.f * UIS, FreqTextW, Font, 1.20f * UIS, true);

		const FString StatusStr = Inv->IsRadioPlaying()
			? SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("RadioStatusPlaying"), TEXT("● وضعیت: در حال پخش نوای جبهه"), TEXT("Status: playing front-line broadcast"))
			: SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("RadioStatusOff"), TEXT("○ وضعیت: خاموش"), TEXT("Status: off"));
		DrawFarsiTextBounded(StatusStr, Inv->IsRadioPlaying() ? FLinearColor(0.30f, 0.95f, 0.45f, 1.0f) : FLinearColor(0.7f, 0.7f, 0.7f), RadioContentX + 20.f * UIS, FreqBoxY + 48.f * UIS, FreqTextW, Font, 0.90f * UIS, true);

		// Animated Equalizer Bars
		if (Inv->IsRadioPlaying())
		{
			for (int32 b = 0; b < 24; ++b)
			{
				const float BarHeight = 8.f * UIS + 18.f * UIS * FMath::Abs(FMath::Sin(RadioWaveformAnimTimer + b * 0.45f));
				DrawRect(FLinearColor(0.25f, 0.95f, 0.40f, 0.85f), RadioContentX + RadioContentW - 140.f * UIS + (b * 5.f * UIS), FreqBoxY + FreqBoxH - 12.f * UIS - BarHeight, 3.f * UIS, BarHeight);
			}
		}

		// Frequency Tuner Buttons
		// S24-INVFIX: the three buttons now SHARE the content column's width
		// (capped at the designed 160 px) - the row can never leave the box.
		const float TunerBtnW = FMath::Min(160.f * UIS, (RadioContentW - 24.f * UIS) / 3.f);
		const float TunerBtnH = 44.f * UIS;
		const float TunerY = FreqBoxY + FreqBoxH + 24.f * UIS;

		// Prev Freq
		const float PrevFreqX = RadioContentX;
		const bool bPrevFreqHover = (MouseX >= PrevFreqX && MouseX <= PrevFreqX + TunerBtnW && MouseY >= TunerY && MouseY <= TunerY + TunerBtnH);
		DrawChiseledTacticalBox(PrevFreqX, TunerY, TunerBtnW, TunerBtnH,
			bPrevFreqHover ? FLinearColor(0.20f, 0.16f, 0.06f, 0.95f) : FLinearColor(0.08f, 0.10f, 0.12f, 0.90f),
			bPrevFreqHover ? FLinearColor(1.0f, 0.82f, 0.25f, 1.0f) : FLinearColor(0.35f, 0.40f, 0.48f, 0.70f), 1.0f * UIS, 4.0f * UIS);
		DrawFarsiTextBounded(SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("PreviousFrequency"), TEXT("◄ فرکانس قبلی"), TEXT("Previous frequency")), FLinearColor::White, PrevFreqX, TunerY, TunerBtnW, Font, 0.85f * UIS, true, true, TunerBtnH);
		if (bPrevFreqHover && bLeftClick) Inv->PreviousRadioStation();

		// Next Freq
		const float NextFreqX = PrevFreqX + TunerBtnW + 12.f * UIS;
		const bool bNextFreqHover = (MouseX >= NextFreqX && MouseX <= NextFreqX + TunerBtnW && MouseY >= TunerY && MouseY <= TunerY + TunerBtnH);
		DrawChiseledTacticalBox(NextFreqX, TunerY, TunerBtnW, TunerBtnH,
			bNextFreqHover ? FLinearColor(0.20f, 0.16f, 0.06f, 0.95f) : FLinearColor(0.08f, 0.10f, 0.12f, 0.90f),
			bNextFreqHover ? FLinearColor(1.0f, 0.82f, 0.25f, 1.0f) : FLinearColor(0.35f, 0.40f, 0.48f, 0.70f), 1.0f * UIS, 4.0f * UIS);
		DrawFarsiTextBounded(SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("NextFrequency"), TEXT("فرکانس بعدی ►"), TEXT("Next frequency")), FLinearColor::White, NextFreqX, TunerY, TunerBtnW, Font, 0.85f * UIS, true, true, TunerBtnH);
		if (bNextFreqHover && bLeftClick) Inv->NextRadioStation();

		// Power Toggle Button
		const float PowerBtnX = NextFreqX + TunerBtnW + 12.f * UIS;
		const bool bPowerHover = (MouseX >= PowerBtnX && MouseX <= PowerBtnX + TunerBtnW && MouseY >= TunerY && MouseY <= TunerY + TunerBtnH);
		DrawChiseledTacticalBox(PowerBtnX, TunerY, TunerBtnW, TunerBtnH,
			bPowerHover ? FLinearColor(0.25f, 0.12f, 0.12f, 0.95f) : FLinearColor(0.12f, 0.08f, 0.08f, 0.90f),
			bPowerHover ? FLinearColor(1.0f, 0.4f, 0.4f, 1.0f) : FLinearColor(0.60f, 0.25f, 0.25f, 0.70f), 1.0f * UIS, 4.0f * UIS);
		DrawFarsiTextBounded(SquadAIHUDIsEnglish(this) ? (Inv->IsRadioPlaying() ? TEXT("Turn radio off") : TEXT("Turn radio on")) : (Inv->IsRadioPlaying() ? TEXT("خاموش کردن رادیو") : TEXT("روشن کردن رادیو")), FLinearColor::White, PowerBtnX, TunerY, TunerBtnW, Font, 0.85f * UIS, true, true, TunerBtnH);
		if (bPowerHover && bLeftClick) Inv->ToggleRadioPower();
	}

	// =========================================================================
	//  TAB 3: POCKET QURAN & DUAS (قرآن و ادعیه متبرک)
	// =========================================================================
	else if (InventoryActiveTab == 3 && Inv)
	{
		FString QuranArabic, QuranTranslation;
		Inv->GetCurrentQuranVerse(QuranArabic, QuranTranslation);

		const float QuranX = ContentX + 30.f * UIS;
		const float QuranY = ContentY + 20.f * UIS;
		const float QuranW = ContentW - 60.f * UIS;
		const float QuranH = ContentH - 50.f * UIS;

		DrawChiseledTacticalBox(QuranX, QuranY, QuranW, QuranH,
			FLinearColor(0.04f, 0.08f, 0.05f, 0.98f),
			FLinearColor(1.0f, 0.82f, 0.25f, 0.95f), 1.5f * UIS, 10.0f * UIS);

		// Left: Photorealistic 3D Quran Render (Preserved Aspect Ratio)
		// S24-INVFIX: same clamp as the radio tab - the art square yields to the
		// content column on narrow windows instead of starving it.
		const float QuranArtSz = FMath::Clamp(QuranH - 50.f * UIS, 120.f * UIS, FMath::Max(120.f * UIS, QuranW - 360.f * UIS));
		if (ItemPocketQuranTexture)
		{
			DrawTexture(ItemPocketQuranTexture, QuranX + 24.f * UIS, QuranY + 25.f * UIS, QuranArtSz, QuranArtSz, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
		}

		const float QuranContentX = ItemPocketQuranTexture ? (QuranX + QuranArtSz + 36.f * UIS) : (QuranX + 24.f * UIS);
		const float QuranContentW = QuranW - (ItemPocketQuranTexture ? (QuranArtSz + 56.f * UIS) : 48.f * UIS);

		DrawFarsiTextBounded(SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("QuranTitle"), TEXT("قرآن جیبی رزمنده و ادعیه نصر و آرامش دل‌ها"), TEXT("Fighter pocket Quran and prayers for victory and calm")),
			FLinearColor(1.0f, 0.85f, 0.35f, 1.0f), QuranContentX, QuranY + 20.f * UIS, QuranContentW, Font, 1.30f * UIS, true);

		DrawRect(FLinearColor(1.0f, 0.82f, 0.25f, 0.50f), QuranContentX, QuranY + 54.f * UIS, QuranContentW, 1.f * UIS);

		TArray<FString> ArabicLines;
		QuranArabic.ParseIntoArrayLines(ArabicLines, false);
		if (ArabicLines.Num() == 0 && !QuranArabic.IsEmpty()) ArabicLines.Add(QuranArabic);

		float VerseY = QuranY + 75.f * UIS;
		for (const FString& AL : ArabicLines)
		{
			DrawFarsiTextBounded(AL, FLinearColor(1.0f, 0.92f, 0.45f, 1.0f), QuranContentX, VerseY, QuranContentW, Font, 1.25f * UIS, true, true);
			VerseY += 34.f * UIS;
		}

		VerseY += 10.f * UIS;
		TArray<FString> TransLines;
		QuranTranslation.ParseIntoArrayLines(TransLines, false);
		if (TransLines.Num() == 0 && !QuranTranslation.IsEmpty()) TransLines.Add(QuranTranslation);

		for (const FString& TL : TransLines)
		{
			DrawFarsiTextBounded(TL, FLinearColor(0.92f, 0.95f, 0.98f, 1.0f), QuranContentX, VerseY, QuranContentW, Font, 1.05f * UIS, true, true);
			VerseY += 28.f * UIS;
		}

		// Next Verse Button
		const float NextVerseBtnW = 260.f * UIS;
		const float NextVerseBtnH = 44.f * UIS;
		const float NextVerseBtnX = QuranContentX + (QuranContentW - NextVerseBtnW) * 0.5f;
		const float NextVerseBtnY = QuranY + QuranH - 65.f * UIS;
		const bool bVerseHover = (MouseX >= NextVerseBtnX && MouseX <= NextVerseBtnX + NextVerseBtnW && MouseY >= NextVerseBtnY && MouseY <= NextVerseBtnY + NextVerseBtnH);

		DrawChiseledTacticalBox(NextVerseBtnX, NextVerseBtnY, NextVerseBtnW, NextVerseBtnH,
			bVerseHover ? FLinearColor(0.12f, 0.25f, 0.16f, 0.98f) : FLinearColor(0.06f, 0.14f, 0.09f, 0.90f),
			bVerseHover ? FLinearColor(1.0f, 0.82f, 0.25f, 1.0f) : FLinearColor(0.25f, 0.80f, 0.40f, 0.80f), 1.5f * UIS, 6.0f * UIS);

		DrawFarsiTextBounded(SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("NextVerseButton"), TEXT("آیه و دعای دیگر [کلیک]"), TEXT("Another verse and prayer [Click]")), FLinearColor::White, NextVerseBtnX, NextVerseBtnY, NextVerseBtnW, Font, 0.95f * UIS, true, true, NextVerseBtnH);
		if (bVerseHover && bLeftClick) Inv->NextQuranVerse();
	}

	// =========================================================================
	//  TAB 4: COMBAT WALLET & DOG TAG (کیف مدارک و پلاک هویت)
	// =========================================================================
	else if (InventoryActiveTab == 4 && LocSys)
	{
		const float CardW = (ContentW - 60.f * UIS) * 0.5f;
		const float CardH = ContentH - 50.f * UIS;
		const float Card1X = ContentX + 20.f * UIS;
		const float Card2X = Card1X + CardW + 20.f * UIS;
		const float CardY = ContentY + 25.f * UIS;

		// B6-22: identity dossier wired to the editable profile (was: hardcoded strings).
			// L2-INI: rank/name fallback comes from Inventory.WalletOwner (user key, now live);
			// active-profile fields (set in the profile page) still win when present.
			FString FighterName = SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("WalletOwner"), TEXT("رزمنده ستوان‌یار یکم"), TEXT("First Sergeant"));
			FString BloodType = bEnglishHUD ? TEXT("O+") : TEXT("O+ (مثبت)");
			FString DogTagNo = bEnglishHUD ? TEXT("958 / 1980 - KH") : TEXT("۹۵۸ / ۱۳۵۹ - خ");
		if (USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(this))
		{
			const FSquadPlayerProfile& Prof = Prog->GetActiveProfile();
			if (!Prof.PlayerName.IsEmpty()) { FighterName = Prof.PlayerName; }
			if (!Prof.BloodType.IsEmpty()) { BloodType = Prof.BloodType; }
			if (!Prof.DogTagNumber.IsEmpty()) { DogTagNo = Prof.DogTagNumber; }
		}

		// Card 1: Military Identification Card
		DrawChiseledTacticalBox(Card1X, CardY, CardW, CardH,
			FLinearColor(0.07f, 0.08f, 0.10f, 0.96f),
			FLinearColor(1.0f, 0.82f, 0.25f, 0.85f), 1.5f * UIS, 8.0f * UIS);

		DrawFarsiTextBounded(SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("WalletCardTitle"), TEXT("کارت شناسایی رزمنده ستاد جنگ‌های نامنظم"), TEXT("Irregular Warfare Fighter Identification Card")), FLinearColor(1.0f, 0.85f, 0.35f, 1.0f), Card1X + 16.f * UIS, CardY + 16.f * UIS, CardW - 32.f * UIS, Font, 1.15f * UIS, true);
		DrawRect(FLinearColor(0.35f, 0.40f, 0.50f, 0.60f), Card1X + 16.f * UIS, CardY + 46.f * UIS, CardW - 32.f * UIS, 1.f * UIS);

		DrawFarsiTextBounded(SquadAIFormatRuntime(*SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("WalletFighterNameFmt"), TEXT("نام رزمنده: %s"), TEXT("Fighter name: %s")), *FighterName), FLinearColor::White, Card1X + 16.f * UIS, CardY + 62.f * UIS, CardW - 32.f * UIS, Font, 0.95f * UIS, true);
		DrawFarsiTextBounded(SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("WalletUnit"), TEXT("یگان: ستاد جنگ‌های نامنظم (شهید چمران / رستمی)"), TEXT("Unit: Irregular Warfare HQ (Chamran / Rostami)")), FLinearColor::White, Card1X + 16.f * UIS, CardY + 98.f * UIS, CardW - 32.f * UIS, Font, 0.88f * UIS, true);
		DrawFarsiTextBounded(SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("WalletAxis"), TEXT("محور عملیاتی: دهلاویه، سوسنگرد و کرخه"), TEXT("Operation axis: Dehlavieh, Susangerd and Karkheh")), FLinearColor::White, Card1X + 16.f * UIS, CardY + 134.f * UIS, CardW - 32.f * UIS, Font, 0.88f * UIS, true);
		DrawFarsiTextBounded(SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("WalletCommander"), TEXT("فرمانده مستقیم: سرگرد شهید ایرج رستمی"), TEXT("Direct commander: Major Shahid Iraj Rostami")), FLinearColor(0.30f, 0.95f, 0.45f, 1.0f), Card1X + 16.f * UIS, CardY + 170.f * UIS, CardW - 32.f * UIS, Font, 0.90f * UIS, true);

		// Card 2: Blood Type Card & Metal Identity Dog Tag (With Photorealistic 3D Wallet & Tag Render!)
		DrawChiseledTacticalBox(Card2X, CardY, CardW, CardH,
			FLinearColor(0.07f, 0.08f, 0.10f, 0.96f),
			FLinearColor(0.85f, 0.25f, 0.25f, 0.85f), 1.5f * UIS, 8.0f * UIS);

		DrawFarsiTextBounded(SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("WalletMedicalCardTitle"), TEXT("کارت سلامت و پلاک هویت فلزی"), TEXT("Medical Card and Metal Dog Tag")), FLinearColor(1.0f, 0.45f, 0.45f, 1.0f), Card2X + 16.f * UIS, CardY + 16.f * UIS, CardW - 32.f * UIS, Font, 1.15f * UIS, true);
		DrawRect(FLinearColor(0.35f, 0.40f, 0.50f, 0.60f), Card2X + 16.f * UIS, CardY + 46.f * UIS, CardW - 32.f * UIS, 1.f * UIS);

		if (ItemCombatWalletTexture)
		{
			DrawTexture(ItemCombatWalletTexture, Card2X + CardW - 130.f * UIS, CardY + 60.f * UIS, 115.f * UIS, 115.f * UIS, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
		}

		// G-12: the metal identity tag render the header comment promised (was wallet only).
		if (ItemDogTagTexture)
		{
			DrawTexture(ItemDogTagTexture, Card2X + CardW - 130.f * UIS, CardY + 185.f * UIS, 115.f * UIS, 115.f * UIS, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
		}

		const float Card2TextW = ItemCombatWalletTexture ? (CardW - 155.f * UIS) : (CardW - 32.f * UIS);

		// L2-INI: Inventory.WalletBloodGroup may hold the FULL line ("گروه خونی: O+") or a printf
		// format ("گروه خونی: %s") — Printf tolerates both (no specifier => shown verbatim).
		DrawFarsiTextBounded(SquadAIFormatRuntime(*SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("WalletBloodGroup"), TEXT("گروه خونی: %s"), TEXT("Blood type: %s")), *BloodType), FLinearColor(1.0f, 0.30f, 0.30f, 1.0f), Card2X + 16.f * UIS, CardY + 62.f * UIS, Card2TextW, Font, 1.05f * UIS, true);
		DrawFarsiTextBounded(SquadAIFormatRuntime(*SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("WalletDogTag"), TEXT("شماره پلاک فلزی: %s"), TEXT("Metal dog tag: %s")), *DogTagNo), FLinearColor(1.0f, 0.85f, 0.35f, 1.0f), Card2X + 16.f * UIS, CardY + 98.f * UIS, Card2TextW, Font, 1.0f * UIS, true);
		DrawFarsiTextBounded(SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("WalletMedicalStatus"), TEXT("وضعیت امدادی: کاملاً آماده رزم و مجهز"), TEXT("Medical status: fully combat-ready and equipped")), FLinearColor::White, Card2X + 16.f * UIS, CardY + 134.f * UIS, Card2TextW, Font, 0.88f * UIS, true);
		DrawFarsiTextBounded(SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("WalletPhysicalReadiness"), TEXT("آمادگی جسمانی: عالی (استقامت رزم کویری)"), TEXT("Physical readiness: excellent desert-combat endurance")), FLinearColor::White, Card2X + 16.f * UIS, CardY + 170.f * UIS, Card2TextW, Font, 0.88f * UIS, true);
	}

	// =========================================================================
	//  TAB 5: SUPPLIES & CANTEEN (اقلام و تدارکات)
	// =========================================================================
	else if (InventoryActiveTab == 5 && Inv)
	{
		const float ItemW = (ContentW - 80.f * UIS) / 3.f;
		const float ItemH = (ContentH - 60.f * UIS) * 0.5f;

		struct FSupplyDisplay
		{
			FString Name;
			FString Qty;
			FString Desc;
			FLinearColor Col;
			UTexture2D* Icon;
		};

		TArray<FSupplyDisplay> Supplies = {
				{ SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("SupplyFirstAidName"), TEXT("بسته امدادی انفرادی"), TEXT("Individual first-aid pouch")), SquadAIFormatRuntime(*SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("SupplyStockFmt"), TEXT("موجودی: %d عدد"), TEXT("Stock: %d")), Inv->FirstAidKits), SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("SupplyFirstAidDesc"), TEXT("درمان جراحت و بازیابی سلامت سریع در سنگر"), TEXT("Treat wounds and quickly recover health in the trench")), FLinearColor(0.25f, 0.90f, 0.45f, 1.0f), ItemFirstAidPouchTexture.Get() },
				{ SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("SupplyFragName"), TEXT("نارنجک ترکش‌زا [G]"), TEXT("Fragmentation grenade [G]")), SquadAIFormatRuntime(*SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("SupplyStockFmt"), TEXT("موجودی: %d عدد"), TEXT("Stock: %d")), Inv->FragGrenades), SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("SupplyFragDesc"), TEXT("انهدام تجمعات دشمن و سنگرهای تیربار"), TEXT("Destroy enemy groups and machine-gun nests")), FLinearColor(1.0f, 0.40f, 0.25f, 1.0f), nullptr },
				{ SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("SupplySmokeName"), TEXT("نارنجک دودزا [H]"), TEXT("Smoke grenade [H]")), SquadAIFormatRuntime(*SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("SupplyStockFmt"), TEXT("موجودی: %d عدد"), TEXT("Stock: %d")), Inv->SmokeGrenades), SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("SupplySmokeDesc"), TEXT("ایجاد پرده دید ۱۸ ثانیه‌ای در برابر تک‌تیراندازان"), TEXT("Create an 18-second visual screen against snipers")), FLinearColor(0.70f, 0.85f, 1.0f, 1.0f), nullptr },
				{ SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("SupplyCanteenName"), TEXT("قمقمه آب فلزی"), TEXT("Metal water canteen")), SquadAIFormatRuntime(*SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("SupplyWaterFmt"), TEXT("میزان آب: %d%%"), TEXT("Water: %d%%")), FMath::RoundToInt(Inv->CanteenWaterPercent * 100.f)), SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("SupplyCanteenDesc"), TEXT("رفع عطش و خستگی در گرمای طاقت‌فرسای خوزستان"), TEXT("Relieves thirst and fatigue in the Khuzestan heat")), FLinearColor(0.30f, 0.70f, 1.0f, 1.0f), ItemCanteenTexture.Get() },
				{ SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("SupplyKeffiyehName"), TEXT("چفیه و سربند متبرک"), TEXT("Keffiyeh and blessed headband")), SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("SupplyKeffiyehCount"), TEXT("تعداد: ۱ عدد"), TEXT("Count: 1")), SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("SupplyKeffiyehDesc"), TEXT("محافظت در برابر گردوغبار و نشانه شجاعت و ایمان"), TEXT("Dust protection and a sign of courage and faith")), FLinearColor(1.0f, 0.85f, 0.35f, 1.0f), nullptr },
				{ SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("SupplyCompassName"), TEXT("قطب‌نما و نقشه تاکتیکی"), TEXT("Compass and tactical map")), SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("SupplyCompassStatus"), TEXT("وضعیت: فعال [V]"), TEXT("Status: active [V]")), SquadAIHUDLocal(this, TEXT("Inventory"), TEXT("SupplyCompassDesc"), TEXT("راهنمای مسیر و تشخیص معابر مین‌گذاری شده"), TEXT("Route guidance and minefield path awareness")), FLinearColor(1.0f, 0.85f, 0.35f, 1.0f), nullptr }
		};

		for (int32 i = 0; i < Supplies.Num(); ++i)
		{
			const int32 Row = i / 3;
			const int32 Col = i % 3;
			const float IX = ContentX + 20.f * UIS + (Col * (ItemW + 20.f * UIS));
			const float IY = ContentY + 20.f * UIS + (Row * (ItemH + 20.f * UIS));

			DrawChiseledTacticalBox(IX, IY, ItemW, ItemH,
				FLinearColor(0.06f, 0.08f, 0.10f, 0.95f),
				Supplies[i].Col, 1.0f * UIS, 6.0f * UIS);

			if (Supplies[i].Icon)
			{
				DrawTexture(Supplies[i].Icon, IX + ItemW - 54.f * UIS, IY + 10.f * UIS, 44.f * UIS, 44.f * UIS, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
			}

			const float TextW = Supplies[i].Icon ? (ItemW - 70.f * UIS) : (ItemW - 24.f * UIS);

			DrawFarsiTextBounded(Supplies[i].Name, Supplies[i].Col, IX + 14.f * UIS, IY + 12.f * UIS, TextW, Font, 1.0f * UIS, true);
			DrawFarsiTextBounded(Supplies[i].Qty, FLinearColor::White, IX + 14.f * UIS, IY + 38.f * UIS, TextW, Font, 0.90f * UIS, true);
			DrawFarsiTextBounded(Supplies[i].Desc, FLinearColor(0.85f, 0.88f, 0.92f, 0.90f), IX + 14.f * UIS, IY + 64.f * UIS, ItemW - 28.f * UIS, Font, 0.82f * UIS, true);
		}
	}
}

#include "HUD/SquadAIMainMenuWidget.h"
#include "SaveSystem/SquadAISaveLoadSubsystem.h"
#include "Performance/SquadAILoadingScreenSubsystem.h"
#include "Performance/DifficultySubsystem.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetSystemLibrary.h"

void USquadAIMainMenuWidget::NativeConstruct()
{
	Super::NativeConstruct();
	CurrentMenuState = EMainMenuState::Main;
	RefreshSaveSlots();
}

void USquadAIMainMenuWidget::RefreshSaveSlots()
{
	if (USquadAISaveLoadSubsystem* SaveSys = USquadAISaveLoadSubsystem::Get(this))
	{
		AvailableSaveSlots = SaveSys->GetAllSaveSlotNames();
		bHasSavedGame = SaveSys->HasAnySaves();
	}
}

void USquadAIMainMenuWidget::StartNewGame(EGameDifficulty Difficulty)
{
	UWorld* World = GetWorld();
	if (!World) return;

	if (UDifficultySubsystem* Diff = UDifficultySubsystem::Get(World))
	{
		Diff->SetDifficulty(Difficulty);
	}

	const FText SectorTitle = FText::FromString(TEXT("Sector 1: Khuzestan Frontline"));
	const FText Briefing = FText::FromString(TEXT("Infiltrate hostile desert trenches, locate enemy strongpoints, and secure the perimeter with your fireteam."));

	if (USquadAILoadingScreenSubsystem* Loading = USquadAILoadingScreenSubsystem::Get(World))
	{
		Loading->LoadLevelWithScreen(GameplayLevelName, SectorTitle, Briefing);
	}
	else
	{
		UGameplayStatics::OpenLevel(World, GameplayLevelName);
	}
}

void USquadAIMainMenuWidget::ContinueGame()
{
	if (USquadAISaveLoadSubsystem* SaveSys = USquadAISaveLoadSubsystem::Get(this))
	{
		const FString LatestSlot = SaveSys->GetMostRecentSaveSlot();
		if (!LatestSlot.IsEmpty())
		{
			SaveSys->LoadGame(LatestSlot, true);
		}
	}
}

void USquadAIMainMenuWidget::LoadSaveSlot(const FString& SlotName)
{
	if (USquadAISaveLoadSubsystem* SaveSys = USquadAISaveLoadSubsystem::Get(this))
	{
		SaveSys->LoadGame(SlotName, true);
	}
}

void USquadAIMainMenuWidget::DeleteSaveSlot(const FString& SlotName)
{
	if (USquadAISaveLoadSubsystem* SaveSys = USquadAISaveLoadSubsystem::Get(this))
	{
		SaveSys->DeleteSaveSlot(SlotName);
		RefreshSaveSlots();
	}
}

void USquadAIMainMenuWidget::LaunchMission(int32 MissionIndex)
{
	UWorld* World = GetWorld();
	if (!World) return;

	const FText SectorTitle = FText::FromString(FString::Printf(TEXT("Sector %d: Tactical Engagement"), MissionIndex + 1));
	const FText Briefing = FText::FromString(TEXT("Execute precision squad assault on hostile fortified ruins and defensive emplacements."));

	if (USquadAILoadingScreenSubsystem* Loading = USquadAILoadingScreenSubsystem::Get(World))
	{
		Loading->LoadLevelWithScreen(GameplayLevelName, SectorTitle, Briefing);
	}
	else
	{
		UGameplayStatics::OpenLevel(World, GameplayLevelName);
	}
}

void USquadAIMainMenuWidget::ApplySettings(const FSquadGameSettingsSaveData& NewSettings)
{
	if (USquadAISaveLoadSubsystem* SaveSys = USquadAISaveLoadSubsystem::Get(this))
	{
		SaveSys->SaveSettings(NewSettings);
	}
}

void USquadAIMainMenuWidget::SetMenuState(EMainMenuState NewState)
{
	CurrentMenuState = NewState;
	if (CurrentMenuState == EMainMenuState::LoadGame)
	{
		RefreshSaveSlots();
	}
}

void USquadAIMainMenuWidget::QuitGame()
{
	if (APlayerController* PC = GetOwningPlayer())
	{
		UKismetSystemLibrary::QuitGame(GetWorld(), PC, EQuitPreference::Quit, false);
	}
}

// QuestMissionWidget.cpp — UMG widget with Persian text + checklist
#include "HUD/QuestMissionWidget.h"
#include "HUD/FarsiTextHelper.h"
#include "Utilities/SquadAIAssetHelper.h"   // S26-FIXUI: self-importing HUD font
#include "Quest/QuestChain.h"
#include "Quest/MissionZone.h"
#include "Quest/EnemyWaveSpawner.h"
#include "Components/TextBlock.h"
#include "Components/VerticalBox.h"
#include "Components/Image.h"
#include "Engine/Font.h"
#include "EngineUtils.h"
#include "SquadAITuning.h"

void UQuestMissionWidget::NativeConstruct()
{
	Super::NativeConstruct();
	UpdateDisplay();
}

void UQuestMissionWidget::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	Super::NativeTick(MyGeometry, InDeltaTime);
	if (!GetWorld() || !GetWorld()->IsGameWorld()) return;
	RefreshTimer += InDeltaTime;
	if (RefreshTimer >= 0.5f) { RefreshTimer = 0.f; UpdateDisplay(); }
}

void UQuestMissionWidget::SetQuestChain(AQuestChain* Chain)
{
	ActiveChain = Chain;
	UpdateDisplay();
}

AQuestChain* UQuestMissionWidget::FindQuestChain()
{
	if (ActiveChain && ActiveChain->IsValidLowLevel()) return ActiveChain;
	ActiveChain = AQuestChain::FindPreferred(GetWorld(), true);
	return ActiveChain;
}

FSlateFontInfo UQuestMissionWidget::GetBestFont() const
{
	// Priority: widget PersianFont > widget DefaultFont > SquadAITuning path > SquadAITuning ref
	if (PersianFont.FontObject) return PersianFont;
	if (DefaultFont.FontObject) return DefaultFont;

	const USquadAITuning* T = USquadAITuning::Get();
	if (T)
	{
		// Try loading from asset path first (works in standalone mode)
		if (!T->HUDFontPath.IsEmpty())
		{
			static UObject* CachedFont = nullptr;
			static FString CachedPath;
			if (!CachedFont || CachedPath != T->HUDFontPath)
			{
				// S26-FIXUI SWEEP: same loader the canvas HUD uses - it SELF-IMPORTS
				// the TTF shipped in Content/Fonts as /Game/Fonts/SquadAI_HUD, so
				// this widget no longer depends on something else drawing first.
				CachedFont = FSquadAIAssetHelper::LoadFontSafe(*T->HUDFontPath, TEXT("Fonts/SquadAI_HUD.ttf"));
				CachedPath = T->HUDFontPath;
			}
			if (CachedFont)
			{
				FSlateFontInfo F;
				F.FontObject = CachedFont;
				F.Size = 18; // Default size, overridden per-element
				return F;
			}
		}

		// Fallback: direct reference (editor only)
		if (T->HUDFont)
			{
				FSlateFontInfo F;
				F.FontObject = T->HUDFont;
				F.Size = 18;
				return F;
			}
	}

	return FSlateFontInfo();
}

void UQuestMissionWidget::UpdateDisplay()
{
	AQuestChain* Chain = FindQuestChain();
	if (!Chain || !Chain->bIsActive)
	{
		if (MissionDescription) MissionDescription->SetText(FText::GetEmpty());
		if (MissionTypeBadge) MissionTypeBadge->SetText(FText::GetEmpty());
		if (DefendTimer) DefendTimer->SetVisibility(ESlateVisibility::Collapsed);
		if (EnemyCounter) EnemyCounter->SetVisibility(ESlateVisibility::Collapsed);
		if (ChecklistContainer) ChecklistContainer->SetVisibility(ESlateVisibility::Collapsed);
		return;
	}

	const FSlateFontInfo UseFont = GetBestFont();
	const USquadAITuning* Tuning = USquadAITuning::Get();
	const int32 ListFontSize = (Tuning && Tuning->ChecklistFontSize > 0) ? Tuning->ChecklistFontSize : 18;
	const int32 DescFontSize = (Tuning && Tuning->MissionDescFontSize > 0) ? Tuning->MissionDescFontSize : 20;
	const int32 BadgeFontSize = (Tuning && Tuning->BadgeFontSize > 0) ? Tuning->BadgeFontSize : 16;
	const int32 TimerFontSize = (Tuning && Tuning->TimerFontSize > 0) ? Tuning->TimerFontSize : 24;
	const int32 EnemyFontSize = (Tuning && Tuning->EnemyCounterFontSize > 0) ? Tuning->EnemyCounterFontSize : 18;

	AMissionZone* Current = Chain->GetCurrentMission();
	if (!Current) return;

	// Mission description with Persian contextual shaping
	if (MissionDescription)
	{
		const FString ShapedDesc = FFarsiTextHelper::ShapeAndOrder(Current->MissionDescription.ToString());
		MissionDescription->SetText(FText::FromString(ShapedDesc));
		FSlateFontInfo F = UseFont; F.Size = DescFontSize;
		MissionDescription->SetFont(F);
	}

	// Type badge
	if (MissionTypeBadge)
	{
		FText Badge; FLinearColor Col = FLinearColor::White;
		if (!Current->CustomBadgeText.IsEmpty()) { Badge = Current->CustomBadgeText; }
		else
		{
			switch (Current->MissionType)
			{
			case EMissionType::Reach: Badge = FText::FromString(TEXT("پیشروی")); Col = FLinearColor(0.3f, 0.7f, 1.f); break;
			case EMissionType::Clear: Badge = FText::FromString(TEXT("پاکسازی")); Col = FLinearColor(1.f, 0.5f, 0.2f); break;
			case EMissionType::Defend: Badge = FText::FromString(TEXT("پدافند")); Col = FLinearColor(1.f, 0.2f, 0.2f); break;
			}
		}
		const FString ShapedBadge = FFarsiTextHelper::ShapeAndOrder(Badge.ToString());
		MissionTypeBadge->SetText(FText::FromString(ShapedBadge));
		MissionTypeBadge->SetColorAndOpacity(FSlateColor(Col));
		FSlateFontInfo F = UseFont; F.Size = BadgeFontSize;
		MissionTypeBadge->SetFont(F);
	}

	// Defend timer + background
	if (DefendTimer)
	{
		if (Current->MissionType == EMissionType::Defend && Current->IsActive())
		{
			const FString TS = UFarsiTextHelper::FormatTimerPersian(Current->DefendTimeRemaining);
			const FString ShapedTimer = FFarsiTextHelper::ShapeAndOrder(FString::Printf(TEXT("پدافند: %s"), *TS));
			DefendTimer->SetText(FText::FromString(ShapedTimer));
			DefendTimer->SetVisibility(ESlateVisibility::Visible);
			if (TimerBackground) TimerBackground->SetVisibility(ESlateVisibility::Visible);
			FSlateFontInfo F = UseFont; F.Size = TimerFontSize;
			DefendTimer->SetFont(F);
		}
		else
		{
			DefendTimer->SetVisibility(ESlateVisibility::Collapsed);
			if (TimerBackground) TimerBackground->SetVisibility(ESlateVisibility::Collapsed);
		}
	}

	// Splash art behind mission text
	if (MissionSplashBackground)
	{
		MissionSplashBackground->SetVisibility(
			Current->IsActive() ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
	}

	// Enemy counter
	if (EnemyCounter)
	{
		if (Current->MissionType == EMissionType::Clear && Current->IsActive())
		{
			int32 Alive = 0;
			for (AEnemyWaveSpawner* Sp : Current->LinkedSpawners) { if (Sp) Alive += Sp->AliveEnemyCount; }
			if (Alive == 0) Alive = Current->AliveEnemies;
			const FString EnemyStr = FString::Printf(TEXT("نیروهای متخاصم: %s"), *UFarsiTextHelper::IntToPersian(Alive));
			const FString ShapedEnemy = FFarsiTextHelper::ShapeAndOrder(EnemyStr);
			EnemyCounter->SetText(FText::FromString(ShapedEnemy));
			EnemyCounter->SetVisibility(ESlateVisibility::Visible);
			FSlateFontInfo F = UseFont; F.Size = EnemyFontSize;
			EnemyCounter->SetFont(F);
		}
		else EnemyCounter->SetVisibility(ESlateVisibility::Collapsed);
	}

	// Checklist — only rebuild when count changes
	if (ChecklistContainer)
	{
		ChecklistContainer->SetVisibility(ESlateVisibility::Visible);

		bool bNeedsRebuild = (ChecklistContainer->GetChildrenCount() != Chain->Missions.Num());

		if (!bNeedsRebuild)
		{
			for (int32 i = 0; i < Chain->Missions.Num(); ++i)
			{
				UWidget* Child = ChecklistContainer->GetChildAt(i);
				UTextBlock* Item = Child ? Cast<UTextBlock>(Child) : nullptr;
				if (!Item) { bNeedsRebuild = true; break; }

				AMissionZone* M = Chain->Missions[i];
				if (!M) continue;

				FString Prefix; FLinearColor C(0.4f, 0.4f, 0.4f);
				if (M->MissionState == EMissionZoneState::Completed) { Prefix = TEXT("  ✔  "); C = FLinearColor(0.2f, 0.9f, 0.2f); }
				else if (M->MissionState == EMissionZoneState::Active) { Prefix = TEXT("  ▶  "); C = FLinearColor(1.f, 0.9f, 0.2f); }
				else if (M->MissionState == EMissionZoneState::Failed) { Prefix = TEXT("  ✖  "); C = FLinearColor(0.9f, 0.2f, 0.2f); }
				else { Prefix = TEXT("     "); }

				const FString ShapedItem = FFarsiTextHelper::ShapeAndOrder(M->MissionDescription.ToString());
				Item->SetText(FText::FromString(Prefix + ShapedItem));
				Item->SetColorAndOpacity(FSlateColor(C));
			}
		}

		if (bNeedsRebuild)
		{
			ChecklistContainer->ClearChildren();

			for (int32 i = 0; i < Chain->Missions.Num(); ++i)
			{
				AMissionZone* M = Chain->Missions[i];
				if (!M) continue;

				UTextBlock* Item = NewObject<UTextBlock>(this);
				if (!Item) continue;

				FString Prefix; FLinearColor C(0.4f, 0.4f, 0.4f);
				if (M->MissionState == EMissionZoneState::Completed) { Prefix = TEXT("  ✔  "); C = FLinearColor(0.2f, 0.9f, 0.2f); }
				else if (M->MissionState == EMissionZoneState::Active) { Prefix = TEXT("  ▶  "); C = FLinearColor(1.f, 0.9f, 0.2f); }
				else if (M->MissionState == EMissionZoneState::Failed) { Prefix = TEXT("  ✖  "); C = FLinearColor(0.9f, 0.2f, 0.2f); }
				else { Prefix = TEXT("     "); }

				const FString ShapedItem = FFarsiTextHelper::ShapeAndOrder(M->MissionDescription.ToString());
				Item->SetText(FText::FromString(Prefix + ShapedItem));
				Item->SetColorAndOpacity(FSlateColor(C));

				FSlateFontInfo ListFont = UseFont;
				ListFont.Size = ListFontSize;
				Item->SetFont(ListFont);

				ChecklistContainer->AddChildToVerticalBox(Item);
			}
		}
	}

	// Distance
	if (DistanceText)
	{
		APawn* Player = GetOwningPlayerPawn();
		if (Player && Current)
		{
			const int32 DM = FMath::RoundToInt(FVector::Dist(Player->GetActorLocation(), Current->GetActorLocation()) / 100.f);
			const USquadAITuning* DT = USquadAITuning::Get();
			const FString Suff = (DT && !DT->DistanceSuffix.IsEmpty()) ? DT->DistanceSuffix : TEXT(" متر");
			const FString DistStr = FString::Printf(TEXT("%d%s"), DM, *Suff);
			DistanceText->SetText(FText::FromString(FFarsiTextHelper::ShapeAndOrder(DistStr)));
			FSlateFontInfo F = UseFont; F.Size = ListFontSize;
			DistanceText->SetFont(F);
		}
	}
}

#include "HUD/SquadAIMainMenuHUD.h"
#include "HUD/FarsiTextHelper.h"
#include "HUD/QuestNativeHUD.h" // S19-INSTANT: AQuestNativeHUD::LocalizeHUDText (the supported FA/EN wrapper)
#include "Actors/SquadAIMainMenuSetupActor.h"
#include "EngineUtils.h"
#include "GameFramework/SquadAIInventorySubsystem.h"
#include "Utilities/SquadAIAssetHelper.h"
#include "GameFramework/SquadAIProgressionSubsystem.h"
#include "SaveSystem/SquadAISaveLoadSubsystem.h"
#include "SaveSystem/SquadAISaveGame.h"
#include "Performance/SquadAILoadingScreenSubsystem.h"
#include "Performance/DifficultySubsystem.h"
#include "Localization/SquadAILocalizationSubsystem.h"
#include "Engine/Canvas.h"
#include "Engine/Texture2D.h"
#include "Misc/App.h" // S18-VIDFIX2
#include "HAL/PlatformTime.h" // S19-FOGSMOOTH: FPlatformTime::Seconds()
#include "CoreGlobals.h"      // S19-FOGSMOOTH: GFrameCounter
#include "Materials/MaterialInterface.h" // S16-FLAG2: LoadObject<UMaterialInterface> needs the complete type
#include "Materials/Material.h" // S16-FLAG3: domain check on the flag-wave material
#include "HAL/IConsoleManager.h" // S16-FLAG4: safety cvar
#include "MediaPlayer.h"  // S16-VID
#include "MediaTexture.h" // S16-VID
#include "MediaSource.h" // S19-IMGSEQ: Cast<UMediaSource> needs the complete type; MediaPlayer.h only forward-declares it
#include "UObject/UnrealType.h" // S19-IMGSEQ: FProperty / FStructProperty / FStrProperty (reflection writes)
#include "HAL/FileManager.h"    // S19-IMGSEQ: IFileManager::Get().DirectoryExists()
#include "ImageUtils.h"   // S17-FOGFX: runtime PNG -> UTexture2D
#include "Materials/MaterialInstanceDynamic.h" // S17-FOGFX
#include "Engine/Font.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetSystemLibrary.h"
#include "GameFramework/PlayerController.h"
#include "NiagaraFunctionLibrary.h"
#include "NiagaraSystem.h"
#include "NiagaraComponent.h"
#include "Camera/PlayerCameraManager.h"

// S16-FLAG4/5/7: switch for the waving-flag menu background.
// S16-FLAG7: user REJECTED flag v1 (image drew darker via DrawMaterial's
// gamma path, mask let the soldier's head wobble, motion too sinusoidal) —
// default back to 0 = static image. The draw path stays for a future improved
// version; opt in with SquadAI.MenuFlagWave 1.
static TAutoConsoleVariable<int32> CVarSquadAIMenuFlagWave(
	TEXT("SquadAI.MenuFlagWave"), 0,
	TEXT("1 = draw the waving-flag menu background material (M_MenuFlagWave) if present and valid. 0 = static image."));

// S16-VID: looping video menu background (Content/Movies/MenuBackground.mp4).
static TAutoConsoleVariable<int32> CVarSquadAIMenuVideo(
	TEXT("SquadAI.MenuVideo"), 1,
	TEXT("1 = use Content/Movies/MenuBackground.mp4 as the looping menu background when the file exists. 0 = static image."));

// S19-IMGSEQ: image sequences avoid the video codec and keyframe-seek flush,
// but ImgMedia still decodes each JPG/PNG frame and consumes the global cache.
// They remove codec startup/loop behavior; they are not decode- or cache-free.
static TAutoConsoleVariable<int32> CVarSquadAIMenuImgSeq(
	TEXT("SquadAI.MenuImgSeq"), 1,
	TEXT("1 = prefer an image sequence folder (Content/Movies/MenuBackground_Seq) over MenuBackground.mp4. "
		"Requires the ImgMedia plugin. Silently falls back to MP4 if the plugin is off or the folder is missing."));

// S19-IMGSEQ: which native media player to ask for when opening a sequence.
// Electra (the UE5 default) CANNOT play image sequences, so we must name the
// ImgMedia player explicitly. Left as a cvar so an alternate name can be tried
// without a recompile.
static TAutoConsoleVariable<FString> CVarSquadAIImgSeqPlayer(
	TEXT("SquadAI.MenuImgSeqPlayer"), TEXT("ImgMedia"),
	TEXT("Native media player name used for image sequences. Default 'ImgMedia'. Electra cannot play image sequences."));

// S16-INTRO: silent intro video before the menu, ending in a smoke wipe.
static TAutoConsoleVariable<int32> CVarSquadAIMenuIntro(
	TEXT("SquadAI.MenuIntro"), 1,
	TEXT("1 = play Content/Movies/MenuIntro.mp4 fullscreen before the menu (smoke transition) when the file exists. 0 = straight to menu."));

// S16-INTRO smoke wipe timing
static constexpr float SquadAIIntroSmokeIn = 0.55f;
static constexpr float SquadAIIntroSmokeOut = 1.35f;

// S17-FOGFX: HQ explosion-fog wipe (Content/Movies/FogFX/). Timeline tuned in
// the approved web preview: blast IN -> whiteout -> black-smoke logo hold ->
// long rising clear over the menu.
static TAutoConsoleVariable<int32> CVarSquadAIMenuFogFX(
	TEXT("SquadAI.MenuFogFX"), 1,
	TEXT("1 = HQ explosion-fog intro wipe (Content/Movies/FogFX/ PNGs) when present. 0 = classic S16-INTRO dust wipe."));
static constexpr float SquadAIFogInT   = 0.90f; // blast in
static constexpr float SquadAIFogPeakT = 0.35f; // whiteout hold
static constexpr float SquadAIFogLogoT = 3.00f; // logo + game name in black smoke
static constexpr float SquadAIFogOutT  = 3.90f; // rising clear over the menu

// S19-FOGSPEED: one knob for the whole intro wipe. It scales the fog CLOCK, not
// the individual phases, so blast / whiteout / logo / clear all stay in the
// proportion they were authored in — the sequence just runs faster or slower.
//   1.0 = as authored (8.15 s total)   |   1.4 = default, ~5.8 s
//   2.0 = twice as fast                |   0.5 = slow, cinematic
// Live-tunable from the console:  SquadAI.MenuFogSpeed 2.0
static TAutoConsoleVariable<float> CVarSquadAIMenuFogSpeed(
	TEXT("SquadAI.MenuFogSpeed"), 1.4f,
	TEXT("Speed multiplier for the menu intro fog wipe. 1 = authored speed (8.15 s), 2 = twice as fast, 0.5 = half speed."));

// S19-VID: seamless background-video looping. Native looping lets the decoder
// run to end-of-stream and then Seek(0); that seek flushes the decoder and the
// flush is the freeze at the wrap. Instead we rewind a moment BEFORE the end
// while the decoder is still running — no end-of-stream, no flush, no stall.
static TAutoConsoleVariable<int32> CVarSquadAIMenuVideoSeamlessLoop(
	TEXT("SquadAI.MenuVideo.SeamlessLoop"), 1,
	TEXT("1 = rewind the menu background video just before the end so the loop never hits end-of-stream (no decoder flush / freeze). 0 = native looping."));
static TAutoConsoleVariable<float> CVarSquadAIMenuVideoLoopLead(
	TEXT("SquadAI.MenuVideo.LoopLead"), 0.45f,
	TEXT("Seconds before the end of the clip at which the seamless loop rewinds. Larger = safer against the freeze, but more of the tail is skipped."));
static TAutoConsoleVariable<float> CVarSquadAIMenuVideoLoopStart(
	TEXT("SquadAI.MenuVideo.LoopStart"), 0.0f,
	TEXT("Where the seamless loop rewinds to, in seconds. Use a value > 0 to skip a leader/identifier at the head of the clip."));
static TAutoConsoleVariable<float> CVarSquadAIMenuVideoLoopEndTrim(
	TEXT("SquadAI.MenuVideo.LoopEndTrim"), 0.0f,
	TEXT("Seconds trimmed off the end of the clip by the seamless loop. Use it to drop a fade-to-black tail."));

namespace SquadAIFogMath
{
	static float EaseOutCubic(float X) { return 1.f - FMath::Pow(1.f - FMath::Clamp(X, 0.f, 1.f), 3.f); }
	static float EaseIn16(float X) { return FMath::Pow(FMath::Clamp(X, 0.f, 1.f), 1.6f); }
}

namespace
{
	// Exact sRGB samples taken from /home/user/uploads/Max_a_check_this_game_menu.png.
	// Use this helper instead of eye-balled FLinearColor values so Canvas output lands
	// on the sampled reference hue after Unreal's sRGB conversion.
	static FLinearColor SquadAIRefSRGBA(uint8 R, uint8 G, uint8 B, float A = 1.0f)
	{
		FLinearColor C = FLinearColor::FromSRGBColor(FColor(R, G, B, 255));
		C.A = A;
		return C;
	}

	// L2-INI: INI-driven string lookup with the menu's bilingual default contract.
	static FString SquadAIMenuLocal(const UObject* Context, const TCHAR* Section, const TCHAR* Key, const TCHAR* PersianText, const TCHAR* EnglishText, bool bEnglish)
	{
		if (const USquadAILocalizationSubsystem* Loc = USquadAILocalizationSubsystem::Get(Context))
		{
			return Loc->GetString(Section, Key, bEnglish ? FString(EnglishText) : FString(PersianText));
		}
		return bEnglish ? FString(EnglishText) : FString(PersianText);
	}

	static bool SquadAIHasPersianOrArabicGlyphs(const FString& Text)
	{
		for (int32 i = 0; i < Text.Len(); ++i)
		{
			const TCHAR Ch = Text[i];
			if (Ch >= 0x0600 && Ch <= 0x06FF)
			{
				return true;
			}
		}
		return false;
	}

	static FString SquadAINormalizePersianDigitsForEnglish(const FString& InText)
	{
		FString Out = InText;
		Out.ReplaceInline(TEXT("۰"), TEXT("0"));
		Out.ReplaceInline(TEXT("۱"), TEXT("1"));
		Out.ReplaceInline(TEXT("۲"), TEXT("2"));
		Out.ReplaceInline(TEXT("۳"), TEXT("3"));
		Out.ReplaceInline(TEXT("۴"), TEXT("4"));
		Out.ReplaceInline(TEXT("۵"), TEXT("5"));
		Out.ReplaceInline(TEXT("۶"), TEXT("6"));
		Out.ReplaceInline(TEXT("۷"), TEXT("7"));
		Out.ReplaceInline(TEXT("۸"), TEXT("8"));
		Out.ReplaceInline(TEXT("۹"), TEXT("9"));
		Out.ReplaceInline(TEXT("٠"), TEXT("0"));
		Out.ReplaceInline(TEXT("١"), TEXT("1"));
		Out.ReplaceInline(TEXT("٢"), TEXT("2"));
		Out.ReplaceInline(TEXT("٣"), TEXT("3"));
		Out.ReplaceInline(TEXT("٤"), TEXT("4"));
		Out.ReplaceInline(TEXT("٥"), TEXT("5"));
		Out.ReplaceInline(TEXT("٦"), TEXT("6"));
		Out.ReplaceInline(TEXT("٧"), TEXT("7"));
		Out.ReplaceInline(TEXT("٨"), TEXT("8"));
		Out.ReplaceInline(TEXT("٩"), TEXT("9"));
		return Out;
	}

	struct FSquadAIMenuTextPair
	{
		const TCHAR* Fa;
		const TCHAR* En;
	};

	static FString SquadAIMenuEnglishSingleLine(const FString& InLine)
	{
		static const FSquadAIMenuTextPair ExactTranslations[] =
		{
			// Shared/menu chrome
			{ TEXT("← بازگشت"), TEXT("← BACK") },
			{ TEXT("فهرست پرونده‌ها"), TEXT("Profile List") },
			{ TEXT("وضعیت"), TEXT("Status") },
			{ TEXT("آماده"), TEXT("Ready") },
			{ TEXT("قفل"), TEXT("Locked") },
			{ TEXT("پاداش"), TEXT("Reward") },
			{ TEXT("مدت"), TEXT("Duration") },
			{ TEXT("سطح"), TEXT("Level") },
			{ TEXT("عملیات"), TEXT("Operations") },
			{ TEXT("دقت"), TEXT("Accuracy") },
			{ TEXT("ساعات"), TEXT("Hours") },
			{ TEXT("بیشتر"), TEXT("More") },
			{ TEXT("نمایش جزئیات"), TEXT("Details") },
			{ TEXT("تغییر نقشه"), TEXT("Change Map") },
			{ TEXT("شروع سریع"), TEXT("Quick Start") },
			{ TEXT("ادامه از آخرین ذخیره عملیات"), TEXT("Continue from latest operation save") },
			{ TEXT("ورود فوری به نبرد"), TEXT("Enter combat immediately") },

			// Main/menu report chrome that can appear while returning from submenus
			{ TEXT("عملیات خوزستان | رازهای پیروزی"), TEXT("Operation Khuzestan | Secrets of Victory") },
			{ TEXT("جوخه"), TEXT("Squad") },
			{ TEXT("بارگذاری"), TEXT("Load Game") },
			{ TEXT("یادگارها"), TEXT("Relics") },
			{ TEXT("تنظیمات"), TEXT("Settings") },
			{ TEXT("خروج"), TEXT("Exit") },
			{ TEXT("آخرین گزارش"), TEXT("Latest Report") },
			{ TEXT("به‌روزرسانی فصل جدید"), TEXT("New season update") },
			{ TEXT("گزارش‌های میدانی و توازن نبرد به‌روز شد."), TEXT("Field reports and combat balance have been updated.") },
			{ TEXT("سقوط خوزستان"), TEXT("Fall of Khuzestan") },
			{ TEXT("عملیات اصلی"), TEXT("Main Operation") },
			{ TEXT("پیشروی به خط مقدم و شکستن هجوم زرهی دشمن."), TEXT("Advance to the frontline and break the enemy armored assault.") },
			{ TEXT("چالش‌های روزانه"), TEXT("Daily Challenges") },
			{ TEXT("۱/۳"), TEXT("1/3") },
			{ TEXT("به‌روزرسانی: ۱۲:۴۵"), TEXT("Refresh: 12:45") },
			{ TEXT("۲۵ هدف با سلاح اصلی"), TEXT("25 primary-weapon targets") },
			{ TEXT("۱۲/۲۵"), TEXT("12/25") },
			{ TEXT("۳ عملیات داستانی"), TEXT("3 story operations") },
			{ TEXT("۲ پیروزی چندنفره"), TEXT("2 multiplayer victories") },
			{ TEXT("۰/۲"), TEXT("0/2") },
			{ TEXT("رازهای پیروزی"), TEXT("Secrets of Victory") },
			{ TEXT("نقشه: دهلاویه"), TEXT("Map: Dehlavieh") },

			// Map select
			{ TEXT("برد شناسایی مناطق عملیاتی | THEATER RECON BOARD"), TEXT("THEATER RECON BOARD") },
			{ TEXT("محور را انتخاب کنید؛ پرونده سمت راست وضعیت، خطر و پاداش اعزام را نشان می‌دهد."), TEXT("Select a front; the right-side file shows status, risk, and deployment rewards.") },
			{ TEXT("هیچ منطقه عملیاتی در سیستم پیشروی ثبت نشده است."), TEXT("No operational theater is registered in progression.") },
			{ TEXT("● آماده اعزام"), TEXT("● Ready to deploy") },
			{ TEXT("○ در آماده‌سازی"), TEXT("○ In preparation") },
			{ TEXT("پرونده اطلاعات عملیات"), TEXT("Operation Intelligence File") },
			{ TEXT("اعزام به منطقه نبرد"), TEXT("Deploy to Combat Zone") },
			{ TEXT("محور دهلاویه و رودخانه کرخه"), TEXT("Dehlavieh & Karkheh River Frontline") },
			{ TEXT("خط مقدم نبرد خوزستان — دفاع در برابر ادوات زرهی دشمن"), TEXT("Khuzestan frontline — defense against hostile armor") },
			{ TEXT("موقعیت تاکتیکی: نبرد سنگین در حاشیه رودخانه کرخه و دشت‌های تفتیده دهلاویه."), TEXT("Tactical situation: heavy fighting along the Karkheh riverbanks and the scorched Dehlavieh plains.") },
			{ TEXT("موقعیت تاکتیکی: نبرد سنگین در حاشیه رودخانه پرآب کرخه و دشت‌های تفتیده دهلاویه."), TEXT("Tactical situation: heavy fighting along the Karkheh riverbanks and the scorched Dehlavieh plains.") },
			{ TEXT("ستون‌های زرهی و تانک‌های متخاصم در حال پیشروی به سمت روستای خشتی در عقبه خط هستند."), TEXT("Hostile armored columns are advancing toward the rear mudbrick village.") },
			{ TEXT("نیروهای متخاصم با ستون‌های زرهی و تانک‌های پیشرفته در حال پیشروی به سمت روستای خشتی عقبه هستند."), TEXT("Hostile armored columns are advancing toward the rear mudbrick village compound.") },
			{ TEXT("ماموریت جوخه با فرماندهی سرگرد شهید ایرج رستمی: استقرار در سنگرهای شنی، انهدام تانک‌ها با آرپی‌جی-۷ و تثبیت خط پدافندی."), TEXT("Mission: under Major Shahid Iraj Rostami, occupy the sand trenches, destroy armor with RPG-7s, and stabilize the defensive line.") },
			{ TEXT("ماموریت جوخه به فرماندهی سرگرد شهید ایرج رستمی: استقرار در سنگرهای شنی، هدایت آتشبار خمپاره، شکار تانک‌ها با آرپی‌جی-۷ و تثبیت خط پدافندی."), TEXT("Mission: under Major Shahid Iraj Rostami, hold the sand trenches, direct mortar fire, hunt armor with RPG-7s, and stabilize the defensive line.") },
			{ TEXT("محور بستان و تنگه چزابه"), TEXT("Bostan & Chazzabeh Marshes") },
			{ TEXT("تپه‌های رملی و آبراهه‌های هورالهویزه"), TEXT("Dune hills and Hoor al-Hawizeh waterways") },
			{ TEXT("موقعیت تاکتیکی: دشت‌های رملی و آبراهه‌های باتلاقی هورالهویزه در غرب سوسنگرد."), TEXT("Tactical situation: dune fields and marsh waterways west of Susangerd.") },
			{ TEXT("دشمن خطوط پدافندی متراکم ایجاد کرده است. عملیات شناسایی و نفوذ شبانه در حال برنامه‌ریزی است."), TEXT("The enemy has built dense defensive lines. Recon and night infiltration are being planned.") },
			{ TEXT("خرمشهر و اروندکنار"), TEXT("Khorramshahr & Arvand River") },
			{ TEXT("نبرد شهری در کوچه‌ها و نخلستان‌های اروند"), TEXT("Urban combat through alleys and Arvand palm groves") },
			{ TEXT("موقعیت تاکتیکی: نبرد تن‌به‌تن شهری در میان ساختمان‌های خشتی و نخلستان‌های حاشیه اروندکنار."), TEXT("Tactical situation: close urban fighting among mudbrick buildings and palm groves near Arvandkenar.") },
			{ TEXT("حماسه مقاومت ۳۴ روزه رزمندگان و مدافعان شهر در برابر لشکرهای زرهی متجاوز."), TEXT("A 34-day stand by the city's defenders against invading armored divisions.") },
			{ TEXT("در دست آماده‌سازی و بهینه‌سازی عملیاتی (Undergoing)"), TEXT("Undergoing operational preparation") },
			{ TEXT("در دست آماده‌سازی و بازسازی عملیاتی (Undergoing)"), TEXT("Undergoing operational reconstruction") },
			{ TEXT("۲۰ الی ۳۰ دقیقه"), TEXT("20 to 30 minutes") },
			{ TEXT("۲۵ الی ۳۵ دقیقه"), TEXT("25 to 35 minutes") },
			{ TEXT("۳۵ الی ۴۵ دقیقه"), TEXT("35 to 45 minutes") },

			// Armory
			{ TEXT("زرادخانه میدانی و آماده‌سازی سلاح | FIELD ARMORY"), TEXT("FIELD ARMORY") },
			{ TEXT("سلاح را انتخاب کنید؛ مشخصات، نقش تاریخی، ویژگی‌ها و وضعیت تجهیز در سمت راست نمایش داده می‌شود."), TEXT("Select a weapon; specs, historical role, traits, and equip status appear on the right.") },
			{ TEXT("هیچ سلاحی در کاتالوگ زرادخانه ثبت نشده است."), TEXT("No weapon is registered in the armory catalog.") },
			{ TEXT("● تجهیز شده"), TEXT("● Equipped") },
			{ TEXT("● آماده تجهیز"), TEXT("● Ready to equip") },
			{ TEXT("قدرت آتش"), TEXT("Firepower") },
			{ TEXT("برد موثر"), TEXT("Effective Range") },
			{ TEXT("نرخ شلیک"), TEXT("Fire Rate") },
			{ TEXT("کنترل و دقت"), TEXT("Control & Accuracy") },
			{ TEXT("ویژگی‌های رزمی"), TEXT("Combat Traits") },
			{ TEXT("سلاح فعال و تجهیز شده"), TEXT("Weapon Active & Equipped") },
			{ TEXT("تجهیز و فعال‌سازی در میدان"), TEXT("Equip & Activate") },
			{ TEXT("مهارت ویژه"), TEXT("Speciality") },
			{ TEXT("توضیحات تاکتیکی مهارت ویژه سلاح."), TEXT("Tactical description of weapon capability.") },
			{ TEXT("تفنگ جنگی ژ-۳ (G3A3)"), TEXT("H&K G3A3 Battle Rifle") },
			{ TEXT("سلاح سازمانی و استاندارد ارتش"), TEXT("Standard Service Rifle") },
			{ TEXT("سلاح سازمانی و استاندارد ارتش، کالیبر قدرتمند ۷.۶۲ میلی‌متری با برد و دقت آتش بسیار بالا در دشت‌های باز."), TEXT("Standard-issue 7.62mm rifle with strong range and accuracy in open plains.") },
			{ TEXT("سلاح سازمانی و کالیبر پرقدرت ارتش (۷.۶۲×۵۱)، کشندگی بسیار بالا و برد موثر عالی در دشت‌های باز."), TEXT("Standard high-power 7.62x51 service rifle with excellent lethality and range in open terrain.") },
			{ TEXT("۷.۶۲×۵۱ میلی‌متر ناتو"), TEXT("7.62x51mm NATO") },
			{ TEXT("قدرت کشندگی و نفوذ بالا"), TEXT("High Lethality & Penetration") },
			{ TEXT("کالیبر پرقدرت ۷.۶۲ میلی‌متری ناتو با شلیک‌های سنگین و بازدارندگی کامل در برابر پیاده‌نظام متخاصم."), TEXT("Powerful 7.62mm NATO caliber with heavy stopping fire against hostile infantry.") },
			{ TEXT("دقت بالا در دشت‌های باز"), TEXT("Open-Desert Precision") },
			{ TEXT("برد موثر تا ۸۰۰ متر؛ ایده‌آل برای هدف‌گیری نیروهای متخاصم پیش از رسیدن به سنگرها."), TEXT("Effective range up to 800 meters; ideal for engaging hostiles before they reach the trenches.") },
			{ TEXT("تفنگ هجومی کلاشینکف (AK-47 / AKM)"), TEXT("Kalashnikov AK-47 / AKM") },
			{ TEXT("سلاح محبوب نیروهای نامنظم و چریکی (۷.۶۲×۳۹)، پایداری افسانه‌ای در گرد و غبار بیابان و نواخت تیر سریع."), TEXT("Favored guerrilla 7.62x39 rifle with legendary dust reliability and a fast rate of fire.") },
			{ TEXT("عدم افت کیفیت در شن"), TEXT("Desert Reliability") },
			{ TEXT("مکانیزم گاز پیستون مطمئن؛ شلیک ممتد در گل‌ولای و ریزگردهای خوزستان بدون گیر کردن."), TEXT("Reliable gas-piston action; sustained fire through mud and Khuzestan dust without jamming.") },
			{ TEXT("سرعت بالای پیشروی"), TEXT("High Mobility Assault") },
			{ TEXT("وزن سبک و بالانس عالی؛ افزایش سرعت مانور و پاکسازی کانال‌ها و سنگرها."), TEXT("Light, well-balanced handling improves maneuver speed and trench clearing.") },
			{ TEXT("راکت‌انداز ضدتانک آرپی‌جی-۷ (RPG-7)"), TEXT("RPG-7 Tank Destroyer") },
			{ TEXT("شکارچی زره‌پوش‌ها و تانک‌های دشمن با سر جنگی شدیدالانفجار، سلاح اصلی خط‌شکنان و رزمندگان ستاد جنگ‌های نامنظم."), TEXT("High-explosive anti-armor launcher used by frontline assault fighters and irregular units.") },
			{ TEXT("شکارچی قطعی تانک‌ها"), TEXT("Tank Killer") },
			{ TEXT("شلیک راکت شدیدالانفجار خرج گود PG-7V؛ انهدام کامل تانک‌ها و نفربرهای زرهی دشمن در یک شلیک دقیق."), TEXT("PG-7V shaped-charge rocket; destroys enemy tanks and APCs with one accurate shot.") },
			{ TEXT("انهدام استحکامات و دوشکا"), TEXT("Bunker & DShK Breaker") },
			{ TEXT("تخریب آنی مواضع تیربار سنگین دوشکا و دیوارهای خشتی مستحکم دشمن با شعاع انفجار وسیع."), TEXT("Rapidly destroys heavy machine-gun nests and fortified mudbrick walls with a wide blast.") },
			{ TEXT("تیربار سنگین ام‌جی-۳ (MG3 Machine Gun)"), TEXT("Rheinmetall MG3 Machine Gun") },
			{ TEXT("قدرت آتش سرکوبگر ویرانگر با نواخت ۱۲۰۰ تیر در دقیقه، برتری آتش مطلق در تثبیت خطوط دفاعی سنگرها."), TEXT("Devastating suppressive fire at 1200 rounds per minute for holding trench defense lines.") },
			{ TEXT("زمین‌گیر کردن سراسری"), TEXT("Area Suppression") },
			{ TEXT("نواخت آتش فوق‌العاده؛ پرده آتش سرکوبگر متراکم که تمام امواج پیاده دشمن را در سنگرها زمین‌گیر می‌کند."), TEXT("Extreme fire rate creates a dense suppressive curtain against infantry waves.") },
			{ TEXT("تفنگ تک‌تیرانداز دراگونوف (SVD Dragunov)"), TEXT("SVD Dragunov Marksman") },
			{ TEXT("دقت مرگبار دوربرد مجهز به دوربین اپتیکی، شکار تک‌تیراندازان و تیربارچی‌های سنگرنشین متخاصم."), TEXT("Long-range optic-equipped precision rifle for counter-sniper and machine-gunner elimination.") },
			{ TEXT("شکار اهداف حساس"), TEXT("High-Value Target Hunter") },
			{ TEXT("مجهز به دوربین اپتیکی PSO-1؛ حذف آنی تیربارچی‌ها، تک‌تیراندازان و فرماندهان دشمن در فواصل ۱۰۰۰ متری."), TEXT("PSO-1 optic; eliminates machine gunners, snipers, and commanders at up to 1000 meters.") },

			// Progression
			{ TEXT("برد دکترین و ارتقای توانمندی‌ها | DOCTRINE BOARD"), TEXT("DOCTRINE BOARD") },
			{ TEXT("کارت‌های عملیاتی با هزینه، وضعیت بازگشایی و اثر رزمی؛ مناسب نمای AAA و بدون شلوغی تزئینی."), TEXT("Operational cards show cost, unlock status, and combat effect in a clean AAA layout.") },
			{ TEXT("وضعیت رزمنده"), TEXT("Soldier Status") },
			{ TEXT("سطح فعلی"), TEXT("Current Level") },
			{ TEXT("امتیاز کل"), TEXT("Total XP") },
			{ TEXT("امتیاز ارتقا"), TEXT("Skill Points") },
			{ TEXT("نوار آمادگی دکترین"), TEXT("Doctrine Readiness Track") },
			{ TEXT("راهنما: کارت را بررسی کنید، سپس با امتیاز ارتقا بازگشایی کنید."), TEXT("Tip: inspect a card, then unlock it with skill points.") },
			{ TEXT("شاخه‌های آموزش میدانی"), TEXT("Field Training Branches") },
			{ TEXT("هیچ گره ارتقایی در کاتالوگ فعلی ثبت نشده است."), TEXT("No progression node is registered in the current catalog.") },
			{ TEXT("بازگشایی شده"), TEXT("Unlocked") },
			{ TEXT("پرونده گره انتخاب‌شده"), TEXT("Selected Node File") },
			{ TEXT("وضعیت: ثبت‌شده در پرونده"), TEXT("Status: registered in dossier") },
			{ TEXT("وضعیت: آماده بازگشایی"), TEXT("Status: ready to unlock") },
			{ TEXT("وضعیت: نیازمند امتیاز بیشتر"), TEXT("Status: needs more points") },
			{ TEXT("این آموزه فعال است"), TEXT("Doctrine Active") },
			{ TEXT("بازگشایی آموزه"), TEXT("Unlock Doctrine") },
			{ TEXT("امتیاز ناکافی"), TEXT("Insufficient Points") },
			{ TEXT("فرماندهی و رهبری میدان"), TEXT("Field Leadership") },
			{ TEXT("افزایش استقامت، روحیه نبرد و سرعت عکس‌العمل تمام رزمندگان جوخه در زیر آتش سنگین."), TEXT("Boosts stamina, morale, and reaction speed for squad members under heavy fire.") },
			{ TEXT("افزایش استقامت و سرعت عکس‌العمل تمام افراد جوخه در زیر آتش سنگین دشمن."), TEXT("Boosts squad stamina and tactical reaction speed under heavy fire.") },
			{ TEXT("دقت تیراندازی و کالیبر سنگین"), TEXT("Precision Marksmanship") },
			{ TEXT("کاهش خطای دید، تثبیت لگد سلاح و افزایش دقت آتش دوربرد در دشت‌های باز دهلاویه."), TEXT("Reduces sight drift, stabilizes recoil, and improves long-range accuracy in open terrain.") },
			{ TEXT("استقامت رزمنده و امدادگری"), TEXT("Combat Endurance") },
			{ TEXT("افزایش ظرفیت سلامت، مقاومت در برابر موج انفجار و تسریع پانسمان و احیای همرزمان."), TEXT("Increases health capacity, blast resistance, and speeds up field revive actions.") },
			{ TEXT("تاکتیک‌های نامنظم و شبیخون"), TEXT("Irregular Warfare Tactics") },
			{ TEXT("افزایش ظرفیت حمل نارنجک‌ها و فشنگ‌های ذخیره، سرعت پیشروی و مانورهای چریکی."), TEXT("Increases grenade/ammo capacity, advance speed, and guerrilla maneuver ability.") },
			{ TEXT("مهندسی رزمی و استحکامات"), TEXT("Combat Engineering") },
			{ TEXT("سرعت تعویض خشاب تاکتیکی در سنگرها و استحکام‌بخشی به جان‌پناه‌های پدافندی."), TEXT("Improves tactical reload speed and reinforces defensive cover positions.") },

			// Profile
			{ TEXT("پرونده رزمنده | SERVICE DOSSIER"), TEXT("SERVICE DOSSIER") },
			{ TEXT("انتخاب پروفایل، نشان چهره، نام میدانی و سوابق رزمی در یک کارت خوانا و تاکتیکی."), TEXT("Choose profile, avatar, callsign, and combat records in one readable tactical card.") },
			{ TEXT("هنوز پرونده ذخیره‌شده‌ای وجود ندارد."), TEXT("No saved profile exists yet.") },
			{ TEXT("+ ایجاد پرونده جدید"), TEXT("+ Create New Profile") },
			{ TEXT("شناسه‌ها و نام‌ها فقط در همین سیستم پرونده ذخیره می‌شوند."), TEXT("IDs and names are stored only inside this dossier system.") },
			{ TEXT("کارت شناسایی میدانی"), TEXT("Field ID Card") },
			{ TEXT("رزمنده"), TEXT("Fighter") },
			{ TEXT("نام رزمنده"), TEXT("Soldier Name") },
			{ TEXT("ویرایش نام نمایشی یا انتخاب نام آماده"), TEXT("Edit display name or choose a preset callsign") },
			{ TEXT("ذخیره نام"), TEXT("Save Name") },
			{ TEXT("ویرایش نام"), TEXT("Edit Name") },
			{ TEXT("نام آماده"), TEXT("Preset Name") },
			{ TEXT("انصراف"), TEXT("Cancel") },
			{ TEXT("انتخاب نشان و سوابق"), TEXT("Avatar & Records") },
			{ TEXT("شهید رستمی"), TEXT("Shahid Rostami") },
			{ TEXT("رزمنده بسیجی"), TEXT("Basiji Fighter") },
			{ TEXT("تکاور ارتش"), TEXT("Army Commando") },
			{ TEXT("جنگ نامنظم"), TEXT("Irregular Warfare") },
			{ TEXT("سرگرد شهید ایرج رستمی"), TEXT("Major Shahid Iraj Rostami") },
			{ TEXT("دیده‌بان چمران"), TEXT("Chamran Scout") },
			{ TEXT("رزمنده خط‌شکن"), TEXT("Line-Breaker Fighter") },
			{ TEXT("شکارچی تانک‌های کرخه"), TEXT("Karkheh Tank Hunter") },
			{ TEXT("صفحه کلید: فارسی"), TEXT("Keyboard: Persian") },
			{ TEXT("صفحه کلید: EN"), TEXT("Keyboard: EN") },
			{ TEXT("۰ دقیقه"), TEXT("0 minutes") },
			{ TEXT("نیروهای دشمن"), TEXT("Enemy Forces") },
			{ TEXT("تانک‌های منهدم"), TEXT("Tanks Destroyed") },
			{ TEXT("هدشات"), TEXT("Headshots") },
			{ TEXT("احیای همرزمان"), TEXT("Squad Revives") },
			{ TEXT("زمان حضور"), TEXT("Time Deployed") },
			{ TEXT("امتیاز مهارت"), TEXT("Skill Points") },

			// Achievements
			{ TEXT("ویترین افتخارات دفاع مقدس | HONORS CASE"), TEXT("HONORS CASE") },
			{ TEXT("مدال‌ها روی قاب جداگانه قرار دارند؛ متن و روند پیشرفت در کارت‌های خوانا و بدون تزئینات سنگین نمایش داده می‌شود."), TEXT("Medals sit in separate frames; progress and text are shown in clean readable cards.") },
			{ TEXT("مدال انتخاب‌شده"), TEXT("Selected Medal") },
			{ TEXT("نشان"), TEXT("Medal") },
			{ TEXT("وضعیت: کسب شده"), TEXT("Status: earned") },
			{ TEXT("وضعیت: در حال پیشرفت"), TEXT("Status: in progress") },
			{ TEXT("این افتخار در پرونده رزمنده ثبت شده است."), TEXT("This honor is recorded in the soldier dossier.") },
			{ TEXT("کاتالوگ افتخارات هنوز خالی است."), TEXT("The honors catalog is empty.") },
			{ TEXT("اولین پیروزی خط‌شکن"), TEXT("First Blood") },
			{ TEXT("اولین موج متخاصم را در سنگرهای خط مقدم خنثی کنید."), TEXT("Neutralize the first hostile wave in the frontline trenches.") },
			{ TEXT("اولین موج دشمن متخاصم را در سنگرهای دهلاویه خنثی کنید."), TEXT("Neutralize the first enemy combat wave in Dehlavieh trenches.") },
			{ TEXT("مدافع غیور دهلاویه"), TEXT("Defender of Dehlavieh") },
			{ TEXT("تمام ماموریت‌های محور رودخانه کرخه و دهلاویه را با موفقیت به پایان برسانید."), TEXT("Complete all Karkheh and Dehlavieh front missions successfully.") },
			{ TEXT("امدادگر قهرمان میدان"), TEXT("Heroic Combat Medic") },
			{ TEXT("۵ بار همرزمان مجروح را در حین درگیری با نگه داشتن کلید E مداوا و احیا کنید."), TEXT("Revive wounded squadmates 5 times during combat by holding E.") },
			{ TEXT("مدال افتخار سرگرد رستمی"), TEXT("Major Rostami's Medal of Honor") },
			{ TEXT("رسیدن به سطح ۵ و آزادسازی سلاح‌های سنگین زرادخانه."), TEXT("Reach level 5 and unlock heavy armory weapons.") },

			// Relics
			{ TEXT("دست‌نوشته‌ها و یادگاری همرزمان شهید | RELICS OF THE FALLEN"), TEXT("RELICS OF THE FALLEN") },
			{ TEXT("هنوز یادگاری‌ای ثبت نشده — در میدان نبرد دست‌نوشته‌ها را بیابید"), TEXT("No relic has been recorded yet — find field notes on the battlefield.") },
			{ TEXT("یادگاری همرزم"), TEXT("Comrade Relic") },

			// Difficulty
			{ TEXT("انتخاب شدت نبرد و اعزام | COMBAT INTENSITY"), TEXT("COMBAT INTENSITY") },
			{ TEXT("چهار کارت بدون قاب طلایی؛ شدت نبرد از آموزش تا شبیه‌سازی مرگبار افزایش می‌یابد."), TEXT("Four clean cards; combat intensity rises from training to lethal simulation.") },
			{ TEXT("سرباز تازه‌کار"), TEXT("Recruit") },
			{ TEXT("آموزش فرماندهی و آشنایی"), TEXT("Command training and orientation") },
			{ TEXT("ریسک پایین"), TEXT("Low Risk") },
			{ TEXT("• دشمن با تأخیر واکنش می‌دهد"), TEXT("• Enemies react more slowly") },
			{ TEXT("• تدارکات و امداد فراوان‌تر است"), TEXT("• Supplies and aid are more available") },
			{ TEXT("• مناسب یادگیری فرمان‌های جوخه"), TEXT("• Best for learning squad commands") },
			{ TEXT("تعادل استاندارد عملیات"), TEXT("Standard operational balance") },
			{ TEXT("ریسک متوسط"), TEXT("Medium Risk") },
			{ TEXT("• دشمن سنگر می‌گیرد و فشار می‌آورد"), TEXT("• Enemies take cover and apply pressure") },
			{ TEXT("• مهمات نیازمند مدیریت است"), TEXT("• Ammo must be managed") },
			{ TEXT("• تجربه اصلی و پیشنهادی بازی"), TEXT("• Recommended core experience") },
			{ TEXT("کهنه‌سرباز جبهه"), TEXT("Frontline Veteran") },
			{ TEXT("آتش سنگین و فرصت کم"), TEXT("Heavy fire and narrow windows") },
			{ TEXT("ریسک بالا"), TEXT("High Risk") },
			{ TEXT("• دور زدن و سرکوب دشمن جدی است"), TEXT("• Flanking and suppression are serious") },
			{ TEXT("• جعبه‌های امدادی بسیار محدود"), TEXT("• Medical supplies are very limited") },
			{ TEXT("• هماهنگی دقیق جوخه ضروری است"), TEXT("• Precise squad coordination is required") },
			{ TEXT("فرمانده مرگبار"), TEXT("Lethal Commander") },
			{ TEXT("شبیه‌سازی بی‌رحمانه خط مقدم"), TEXT("Ruthless frontline simulation") },
			{ TEXT("ریسک حداکثر"), TEXT("Maximum Risk") },
			{ TEXT("• یک خطا می‌تواند عملیات را بشکند"), TEXT("• One mistake can break the operation") },
			{ TEXT("• دشمن هماهنگ و بی‌رحم است"), TEXT("• The enemy is coordinated and ruthless") },
			{ TEXT("• بدون تکیه بر نشانگرهای کمکی"), TEXT("• No reliance on assist indicators") },
			{ TEXT("تأیید و اعزام"), TEXT("Confirm & Deploy") },

			// Load / Settings / Briefing
			{ TEXT("بارگذاری موقعیت ذخیره‌شده عملیات"), TEXT("Load Saved Operation Position") },
			{ TEXT("اطلاعاتی ذخیره نشده است"), TEXT("No saved data") },
			{ TEXT("پایین (Low)"), TEXT("Low") },
			{ TEXT("متوسط (Med)"), TEXT("Medium") },
			{ TEXT("بالا (High)"), TEXT("High") },
			{ TEXT("خیلی بالا (Epic)"), TEXT("Epic") },
			{ TEXT("کیفیت گرافیک و سایه‌ها:"), TEXT("Graphics and shadow quality:") },
			{ TEXT("زبان منوها و فرامین:"), TEXT("Menu and command language:") },
			{ TEXT("فارسی (Persian)"), TEXT("Persian") },
			{ TEXT("حجم صدای افکت‌های جنگی:"), TEXT("Battle SFX volume:") },
			{ TEXT("حجم صدای بیسیم و مکالمات:"), TEXT("Radio and voice volume:") },
			{ TEXT("محرمانه - به کلی سری"), TEXT("CLASSIFIED - TOP SECRET") },
			{ TEXT("سند اطلاعات عملیاتی | محور دفاعی دهلاویه — سوسنگرد"), TEXT("OPERATIONAL INTELLIGENCE | Dehlavieh — Susangerd Defensive Axis") },
			{ TEXT("تاریخ سند: ۲۵ خرداد ۱۳۶۰ // منطقه عملیاتی: خوزستان - خط مقدم دهلاویه"), TEXT("Document date: 15 June 1981 // Theater: Khuzestan - Dehlavieh frontline") },
			{ TEXT("فرماندهی کل محور: دکتر مصطفی چمران | فرمانده میدان: سرگرد شهید ایرج رستمی"), TEXT("Axis command: Dr. Mostafa Chamran | Field commander: Major Shahid Iraj Rostami") },
			{ TEXT("هدف عملیاتی: تثبیت خاکریزهای مقدم، سد پیشروی ستون‌های زرهی و دفاع از اهواز"), TEXT("Objective: hold forward berms, halt armored columns, and defend Ahvaz") },
			{ TEXT("تاکتیک جنگی: شبیخون‌های چریکی، آتش خمپاره سبک، هدایت ضدزره و مین‌گذاری هوشمند"), TEXT("Tactics: guerrilla raids, light mortar fire, anti-armor direction, and smart mine placement") },
			{ TEXT("پیام فرمانده: «برادران رزمنده، اینجا خاک ناموس وطن است. وجبی عقب‌نشینی نخواهیم کرد.»"), TEXT("Command message: Brothers, this ground is the honor of our homeland. We will not retreat one step.") },
			{ TEXT("دکتر شهید مصطفی چمران"), TEXT("Dr. Shahid Mostafa Chamran") },
			{ TEXT("سردار شهید حسن باقری"), TEXT("Sardar Shahid Hassan Bagheri") },
			{ TEXT("شهید محمد جهان‌آرا"), TEXT("Shahid Mohammad Jahan-Ara") },

			// Built-in profile/default/fail-reason strings that can appear in submenus
			{ TEXT("رزمنده دلیر"), TEXT("Brave Fighter") },
			{ TEXT("O+ (مثبت)"), TEXT("O+ (positive)") },
			{ TEXT("۹۵۸ / ۱۳۵۹ - خ"), TEXT("958 / 1359 - KH") },
			{ TEXT("دلاور محور دهلاویه"), TEXT("Dehlavieh Axis Veteran") },
			{ TEXT("تکاور تیپ ۵۵ هوابرد"), TEXT("55th Airborne Commando") },
			{ TEXT("رزمنده خط‌شکن سوسنگرد"), TEXT("Susangerd Line-Breaker") },
			{ TEXT("پاسدار پدافند بستان"), TEXT("Bostan Defense Guard") },
			{ TEXT("این سلاح قبلاً آزاد شده است."), TEXT("This weapon is already unlocked.") },
			{ TEXT("سلاح مورد نظر در زرادخانه یافت نشد."), TEXT("The requested weapon was not found in the armory.") }
		};

		for (const FSquadAIMenuTextPair& Pair : ExactTranslations)
		{
			if (InLine.Equals(Pair.Fa, ESearchCase::CaseSensitive))
			{
				return FString(Pair.En);
			}
		}

		FString Out = SquadAINormalizePersianDigitsForEnglish(InLine);
		auto Replace = [&Out](const TCHAR* From, const TCHAR* To)
		{
			Out.ReplaceInline(From, To, ESearchCase::CaseSensitive);
		};

		// Dynamic generated strings and last-resort phrase cleanup.
		const FString LevelPrefix(TEXT("سطح "));
		if (Out.StartsWith(LevelPrefix)) return FString(TEXT("Level ")) + Out.RightChop(LevelPrefix.Len());
		const FString ProfilePrefix(TEXT("پرونده "));
		if (Out.StartsWith(ProfilePrefix)) return FString(TEXT("Profile ")) + Out.RightChop(ProfilePrefix.Len());
		const FString EmptySlotPrefix(TEXT("جایگاه خالی "));
		if (Out.StartsWith(EmptySlotPrefix)) return FString(TEXT("Empty Slot ")) + Out.RightChop(EmptySlotPrefix.Len());
		const FString NewNamePrefix(TEXT("نام جدید: "));
		if (Out.StartsWith(NewNamePrefix)) return FString(TEXT("New name: ")) + Out.RightChop(NewNamePrefix.Len());
		const FString DogTagPrefix(TEXT("شماره پلاک: "));
		if (Out.StartsWith(DogTagPrefix)) return FString(TEXT("Dog tag: ")) + Out.RightChop(DogTagPrefix.Len());
		const FString BloodPrefix(TEXT("گروه خون: "));
		if (Out.StartsWith(BloodPrefix)) return FString(TEXT("Blood type: ")) + Out.RightChop(BloodPrefix.Len());
		const FString WeaponPrefix(TEXT("سلاح تجهیزشده: "));
		if (Out.StartsWith(WeaponPrefix)) return FString(TEXT("Equipped weapon: ")) + Out.RightChop(WeaponPrefix.Len());
		const FString LockedLevelPrefix(TEXT("○ قفل: سطح "));
		if (Out.StartsWith(LockedLevelPrefix)) return FString(TEXT("○ Locked: Level ")) + Out.RightChop(LockedLevelPrefix.Len());
		const FString CostPrefix(TEXT("هزینه: "));
		if (Out.StartsWith(CostPrefix))
		{
			Out = FString(TEXT("Cost: ")) + Out.RightChop(CostPrefix.Len());
			Replace(TEXT("امتیاز"), TEXT("points"));
			return Out;
		}
		const FString UnlockWeaponPrefix(TEXT("آزادسازی سلاح ("));
		if (Out.StartsWith(UnlockWeaponPrefix)) return FString(TEXT("Unlock Weapon (")) + Out.RightChop(UnlockWeaponPrefix.Len());
		const FString FighterPrefix(TEXT("رزمنده "));
		if (Out.StartsWith(FighterPrefix)) return FString(TEXT("Fighter ")) + Out.RightChop(FighterPrefix.Len());

		Replace(TEXT("نیازمند رسیدن به سطح"), TEXT("Requires level"));
		Replace(TEXT("است (سطح فعلی:"), TEXT("(current level:"));
		Replace(TEXT("امتیاز کافی نیست"), TEXT("Not enough XP"));
		Replace(TEXT("لازم:"), TEXT("required:"));
		Replace(TEXT("موجود:"), TEXT("available:"));
		Replace(TEXT("ساعت و"), TEXT("hours and"));
		Replace(TEXT("ساعت"), TEXT("hours"));
		Replace(TEXT("قفل: سطح"), TEXT("Locked: Level"));
		Replace(TEXT("وضعیت:"), TEXT("Status:"));
		Replace(TEXT("پاداش"), TEXT("Reward"));
		Replace(TEXT("امتیاز"), TEXT("points"));
		Replace(TEXT("دقیقه"), TEXT("minutes"));
		Replace(TEXT("ثبت افتخارات:"), TEXT("Honors unlocked:"));
			Replace(TEXT("قفل"), TEXT("Locked"));
			Replace(TEXT("نشان"), TEXT("Medal"));
		Replace(TEXT("آماده"), TEXT("Ready"));
		Replace(TEXT("بازگشایی شده"), TEXT("Unlocked"));
		Replace(TEXT("در حال پیشرفت"), TEXT("In progress"));
		Replace(TEXT("کسب شده"), TEXT("Earned"));

		return Out;
	}

	static FString SquadAIMenuEnglishText(const FString& InText)
	{
		FString NormalizedInput = InText;
		NormalizedInput.ReplaceInline(TEXT("\r\n"), TEXT("\n"));
		NormalizedInput.ReplaceInline(TEXT("\r"), TEXT("\n"));
		if (NormalizedInput.Contains(TEXT("\n")))
		{
			TArray<FString> Lines;
			NormalizedInput.ParseIntoArray(Lines, TEXT("\n"), false);
			FString Joined;
			for (int32 i = 0; i < Lines.Num(); ++i)
			{
				if (i > 0) Joined += TEXT("\n");
				Joined += SquadAIMenuEnglishSingleLine(Lines[i]);
			}
			return Joined;
		}
		return SquadAIMenuEnglishSingleLine(NormalizedInput);
	}

	// S17-ARFIX: English -> Arabic display map for the menu. The Farsi master
	// strings are first normalized to English (SquadAIMenuEnglishText), then
	// looked up here; anything missing simply stays English (P7-L4 fallback).
	static FString SquadAIMenuArabicSingleLine(const FString& InText)
	{
		static const TMap<FString, FString> ArabicMap = {
			{ TEXT("← BACK"), TEXT("← رجوع") },
			{ TEXT("Profile List"), TEXT("قائمة الملفات") },
			{ TEXT("Status"), TEXT("الحالة") },
			{ TEXT("Ready"), TEXT("جاهز") },
			{ TEXT("Locked"), TEXT("مقفل") },
			{ TEXT("Reward"), TEXT("المكافأة") },
			{ TEXT("Duration"), TEXT("المدة") },
			{ TEXT("Level"), TEXT("المستوى") },
			{ TEXT("Operations"), TEXT("العمليات") },
			{ TEXT("Accuracy"), TEXT("الدقة") },
			{ TEXT("Hours"), TEXT("ساعات") },
			{ TEXT("More"), TEXT("المزيد") },
			{ TEXT("Details"), TEXT("التفاصيل") },
			{ TEXT("Change Map"), TEXT("تغيير الخريطة") },
			{ TEXT("Quick Start"), TEXT("بدء سريع") },
			{ TEXT("Continue from latest operation save"), TEXT("المتابعة من آخر حفظ للعملية") },
			{ TEXT("Enter combat immediately"), TEXT("الدخول في القتال فورًا") },
			{ TEXT("Operation Khuzestan | Secrets of Victory"), TEXT("عملية خوزستان | أسرار النصر") },
			{ TEXT("Squad"), TEXT("الفصيل") },
			{ TEXT("Load Game"), TEXT("تحميل اللعبة") },
			{ TEXT("Relics"), TEXT("التذكارات") },
			{ TEXT("Settings"), TEXT("الإعدادات") },
			{ TEXT("Exit"), TEXT("خروج") },
			{ TEXT("Latest Report"), TEXT("آخر تقرير") },
			{ TEXT("New season update"), TEXT("تحديث الموسم الجديد") },
			{ TEXT("Field reports and combat balance have been updated."), TEXT("تم تحديث التقارير الميدانية وتوازن القتال.") },
			{ TEXT("Fall of Khuzestan"), TEXT("سقوط خوزستان") },
			{ TEXT("Main Operation"), TEXT("العملية الرئيسية") },
			{ TEXT("Advance to the frontline and break the enemy armored assault."), TEXT("تقدَّم إلى خط الجبهة واكسر هجوم دروع العدو.") },
			{ TEXT("Daily Challenges"), TEXT("التحديات اليومية") },
			{ TEXT("Refresh: 12:45"), TEXT("التحديث: 12:45") },
			{ TEXT("25 primary-weapon targets"), TEXT("إصابة 25 هدفًا بالسلاح الرئيسي") },
			{ TEXT("3 story operations"), TEXT("إنجاز 3 عمليات قصصية") },
			{ TEXT("2 multiplayer victories"), TEXT("انتصاران في اللعب الجماعي") },
			{ TEXT("Secrets of Victory"), TEXT("أسرار النصر") },
			{ TEXT("Map: Dehlavieh"), TEXT("الخريطة: دهلاوية") },
			{ TEXT("THEATER RECON BOARD"), TEXT("لوحة استطلاع مسرح العمليات") },
			{ TEXT("Select a front; the right-side file shows status, risk, and deployment rewards."), TEXT("اختر جبهة؛ يعرض الملف الجانبي الحالة والمخاطر ومكافآت الانتشار.") },
			{ TEXT("No operational theater is registered in progression."), TEXT("لا يوجد مسرح عمليات مسجَّل في نظام التقدم.") },
			{ TEXT("● Ready to deploy"), TEXT("● جاهز للانتشار") },
			{ TEXT("○ In preparation"), TEXT("○ قيد التحضير") },
			{ TEXT("Operation Intelligence File"), TEXT("ملف استخبارات العملية") },
			{ TEXT("Deploy to Combat Zone"), TEXT("الانتشار إلى منطقة القتال") },
			{ TEXT("Dehlavieh & Karkheh River Frontline"), TEXT("جبهة دهلاوية ونهر الكرخة") },
			{ TEXT("Khuzestan frontline — defense against hostile armor"), TEXT("جبهة خوزستان — الدفاع ضد دروع العدو") },
			{ TEXT("Tactical situation: heavy fighting along the Karkheh riverbanks and the scorched Dehlavieh plains."), TEXT("الموقف التكتيكي: قتال عنيف على ضفاف نهر الكرخة وسهول دهلاوية المحروقة.") },
			{ TEXT("Hostile armored columns are advancing toward the rear mudbrick village."), TEXT("أرتال مدرعة معادية تتقدم نحو القرية الطينية الخلفية.") },
			{ TEXT("Hostile armored columns are advancing toward the rear mudbrick village compound."), TEXT("أرتال مدرعة معادية تتقدم نحو مجمع القرية الطينية الخلفية.") },
			{ TEXT("Mission: under Major Shahid Iraj Rostami, occupy the sand trenches, destroy armor with RPG-7s, and stabilize the defensive line."), TEXT("المهمة: بقيادة الرائد الشهيد إيرج رستمي، تمركزوا في الخنادق الرملية ودمِّروا الدروع بقاذفات آر بي جي-7 وثبِّتوا الخط الدفاعي.") },
			{ TEXT("Mission: under Major Shahid Iraj Rostami, hold the sand trenches, direct mortar fire, hunt armor with RPG-7s, and stabilize the defensive line."), TEXT("المهمة: بقيادة الرائد الشهيد إيرج رستمي، تمسَّكوا بالخنادق الرملية ووجِّهوا نيران الهاون وطاردوا الدروع بقاذفات آر بي جي-7 وثبِّتوا الخط الدفاعي.") },
			{ TEXT("Bostan & Chazzabeh Marshes"), TEXT("أهوار بستان ومضيق الجزابة") },
			{ TEXT("Dune hills and Hoor al-Hawizeh waterways"), TEXT("تلال رملية وممرات هور الحويزة المائية") },
			{ TEXT("Tactical situation: dune fields and marsh waterways west of Susangerd."), TEXT("الموقف التكتيكي: حقول الكثبان وممرات الأهوار المائية غرب سوسنجرد.") },
			{ TEXT("The enemy has built dense defensive lines. Recon and night infiltration are being planned."), TEXT("أقام العدو خطوطًا دفاعية كثيفة. يجري التخطيط للاستطلاع والتسلل الليلي.") },
			{ TEXT("Khorramshahr & Arvand River"), TEXT("خرمشهر ونهر أروند") },
			{ TEXT("Urban combat through alleys and Arvand palm groves"), TEXT("قتال حضري في الأزقة وبساتين نخيل أروند") },
			{ TEXT("Tactical situation: close urban fighting among mudbrick buildings and palm groves near Arvandkenar."), TEXT("الموقف التكتيكي: قتال حضري قريب بين المباني الطينية وبساتين النخيل قرب أروندكنار.") },
			{ TEXT("A 34-day stand by the city's defenders against invading armored divisions."), TEXT("صمود 34 يومًا لمدافعي المدينة في وجه الفرق المدرعة الغازية.") },
			{ TEXT("Undergoing operational preparation"), TEXT("قيد التحضير العملياتي") },
			{ TEXT("Undergoing operational reconstruction"), TEXT("قيد إعادة البناء العملياتي") },
			{ TEXT("20 to 30 minutes"), TEXT("من 20 إلى 30 دقيقة") },
			{ TEXT("25 to 35 minutes"), TEXT("من 25 إلى 35 دقيقة") },
			{ TEXT("35 to 45 minutes"), TEXT("من 35 إلى 45 دقيقة") },
			{ TEXT("FIELD ARMORY"), TEXT("مستودع السلاح الميداني") },
			{ TEXT("Select a weapon; specs, historical role, traits, and equip status appear on the right."), TEXT("اختر سلاحًا؛ تظهر المواصفات والدور التاريخي والخصائص وحالة التجهيز جانبًا.") },
			{ TEXT("No weapon is registered in the armory catalog."), TEXT("لا يوجد سلاح مسجَّل في فهرس المستودع.") },
			{ TEXT("● Equipped"), TEXT("● مجهَّز") },
			{ TEXT("● Ready to equip"), TEXT("● جاهز للتجهيز") },
			{ TEXT("Firepower"), TEXT("قوة النيران") },
			{ TEXT("Effective Range"), TEXT("المدى الفعّال") },
			{ TEXT("Fire Rate"), TEXT("معدل الرمي") },
			{ TEXT("Control & Accuracy"), TEXT("التحكم والدقة") },
			{ TEXT("Combat Traits"), TEXT("الخصائص القتالية") },
			{ TEXT("Weapon Active & Equipped"), TEXT("السلاح مفعَّل ومجهَّز") },
			{ TEXT("Equip & Activate"), TEXT("تجهيز وتفعيل") },
			{ TEXT("Speciality"), TEXT("التخصص") },
			{ TEXT("Tactical description of weapon capability."), TEXT("وصف تكتيكي لقدرات السلاح.") },
			{ TEXT("H&K G3A3 Battle Rifle"), TEXT("بندقية القتال H&K G3A3") },
			{ TEXT("Standard Service Rifle"), TEXT("بندقية الخدمة القياسية") },
			{ TEXT("Standard-issue 7.62mm rifle with strong range and accuracy in open plains."), TEXT("بندقية 7.62 ملم قياسية بمدى ودقة قويين في السهول المكشوفة.") },
			{ TEXT("Standard high-power 7.62x51 service rifle with excellent lethality and range in open terrain."), TEXT("بندقية خدمة قوية عيار 7.62×51 بفتك ومدى ممتازين في الأراضي المكشوفة.") },
			{ TEXT("7.62x51mm NATO"), TEXT("عيار 7.62×51 ملم ناتو") },
			{ TEXT("High Lethality & Penetration"), TEXT("فتك واختراق عاليان") },
			{ TEXT("Powerful 7.62mm NATO caliber with heavy stopping fire against hostile infantry."), TEXT("عيار ناتو 7.62 ملم قوي بنيران إيقاف ثقيلة ضد مشاة العدو.") },
			{ TEXT("Open-Desert Precision"), TEXT("دقة الصحراء المكشوفة") },
			{ TEXT("Effective range up to 800 meters; ideal for engaging hostiles before they reach the trenches."), TEXT("مدى فعّال حتى 800 متر؛ مثالي للاشتباك مع العدو قبل بلوغه الخنادق.") },
			{ TEXT("Kalashnikov AK-47 / AKM"), TEXT("كلاشينكوف AK-47 / AKM") },
			{ TEXT("Favored guerrilla 7.62x39 rifle with legendary dust reliability and a fast rate of fire."), TEXT("بندقية 7.62×39 المفضلة لدى المغاوير بموثوقية أسطورية في الغبار ومعدل رمي سريع.") },
			{ TEXT("Desert Reliability"), TEXT("موثوقية صحراوية") },
			{ TEXT("Reliable gas-piston action; sustained fire through mud and Khuzestan dust without jamming."), TEXT("آلية مكبس غاز موثوقة؛ رمي متواصل وسط الوحل وغبار خوزستان دون انحشار.") },
			{ TEXT("High Mobility Assault"), TEXT("اقتحام عالي الحركة") },
			{ TEXT("Light, well-balanced handling improves maneuver speed and trench clearing."), TEXT("خفة وتوازن ممتازان يرفعان سرعة المناورة وتطهير الخنادق.") },
			{ TEXT("RPG-7 Tank Destroyer"), TEXT("قاذف آر بي جي-7 المضاد للدبابات") },
			{ TEXT("High-explosive anti-armor launcher used by frontline assault fighters and irregular units."), TEXT("قاذف مضاد للدروع شديد الانفجار يستخدمه مقاتلو الاقتحام والوحدات غير النظامية.") },
			{ TEXT("Tank Killer"), TEXT("قاتل الدبابات") },
			{ TEXT("PG-7V shaped-charge rocket; destroys enemy tanks and APCs with one accurate shot."), TEXT("صاروخ PG-7V بشحنة مشكَّلة؛ يدمِّر دبابات وناقلات العدو بطلقة دقيقة واحدة.") },
			{ TEXT("Bunker & DShK Breaker"), TEXT("كاسر التحصينات والدوشكا") },
			{ TEXT("Rapidly destroys heavy machine-gun nests and fortified mudbrick walls with a wide blast."), TEXT("يدمِّر أعشاش الرشاشات الثقيلة والجدران الطينية المحصَّنة بانفجار واسع.") },
			{ TEXT("Rheinmetall MG3 Machine Gun"), TEXT("رشاش MG3 راينميتال") },
			{ TEXT("Devastating suppressive fire at 1200 rounds per minute for holding trench defense lines."), TEXT("نيران إخماد مدمِّرة بمعدل 1200 طلقة في الدقيقة لتثبيت خطوط الدفاع.") },
			{ TEXT("Area Suppression"), TEXT("إخماد شامل") },
			{ TEXT("Extreme fire rate creates a dense suppressive curtain against infantry waves."), TEXT("معدل رمي هائل يصنع ستارة نيران كثيفة ضد أمواج المشاة.") },
			{ TEXT("SVD Dragunov Marksman"), TEXT("قناصة دراغونوف SVD") },
			{ TEXT("Long-range optic-equipped precision rifle for counter-sniper and machine-gunner elimination."), TEXT("بندقية دقيقة بعيدة المدى بمنظار لصيد القناصة والرشاشين.") },
			{ TEXT("High-Value Target Hunter"), TEXT("صائد الأهداف الثمينة") },
			{ TEXT("PSO-1 optic; eliminates machine gunners, snipers, and commanders at up to 1000 meters."), TEXT("منظار PSO-1؛ يصفّي الرشاشين والقناصة والقادة حتى مسافة 1000 متر.") },
			{ TEXT("DOCTRINE BOARD"), TEXT("لوحة العقيدة القتالية") },
			{ TEXT("Operational cards show cost, unlock status, and combat effect in a clean AAA layout."), TEXT("بطاقات عملياتية تعرض الكلفة وحالة الفتح والأثر القتالي بتنسيق أنيق.") },
			{ TEXT("Soldier Status"), TEXT("حالة المقاتل") },
			{ TEXT("Current Level"), TEXT("المستوى الحالي") },
			{ TEXT("Total XP"), TEXT("مجموع الخبرة") },
			{ TEXT("Skill Points"), TEXT("نقاط المهارة") },
			{ TEXT("Doctrine Readiness Track"), TEXT("مسار الجاهزية العقائدية") },
			{ TEXT("Tip: inspect a card, then unlock it with skill points."), TEXT("تلميح: افحص البطاقة ثم افتحها بنقاط المهارة.") },
			{ TEXT("Field Training Branches"), TEXT("فروع التدريب الميداني") },
			{ TEXT("No progression node is registered in the current catalog."), TEXT("لا توجد عقدة تقدم مسجَّلة في الفهرس الحالي.") },
			{ TEXT("Unlocked"), TEXT("مفتوح") },
			{ TEXT("Selected Node File"), TEXT("ملف العقدة المختارة") },
			{ TEXT("Status: registered in dossier"), TEXT("الحالة: مسجَّلة في السجل") },
			{ TEXT("Status: ready to unlock"), TEXT("الحالة: جاهزة للفتح") },
			{ TEXT("Status: needs more points"), TEXT("الحالة: تحتاج نقاطًا إضافية") },
			{ TEXT("Doctrine Active"), TEXT("العقيدة مفعَّلة") },
			{ TEXT("Unlock Doctrine"), TEXT("فتح العقيدة") },
			{ TEXT("Insufficient Points"), TEXT("نقاط غير كافية") },
			{ TEXT("Field Leadership"), TEXT("القيادة الميدانية") },
			{ TEXT("Boosts stamina, morale, and reaction speed for squad members under heavy fire."), TEXT("يرفع التحمّل والمعنويات وسرعة الاستجابة لأفراد الفصيل تحت النيران الكثيفة.") },
			{ TEXT("Boosts squad stamina and tactical reaction speed under heavy fire."), TEXT("يرفع تحمّل الفصيل وسرعة الاستجابة التكتيكية تحت النيران الكثيفة.") },
			{ TEXT("Precision Marksmanship"), TEXT("الرماية الدقيقة") },
			{ TEXT("Reduces sight drift, stabilizes recoil, and improves long-range accuracy in open terrain."), TEXT("يقلّل انحراف التسديد ويثبّت الارتداد ويحسّن الدقة البعيدة في الأراضي المكشوفة.") },
			{ TEXT("Combat Endurance"), TEXT("التحمّل القتالي") },
			{ TEXT("Increases health capacity, blast resistance, and speeds up field revive actions."), TEXT("يزيد سعة الصحة ومقاومة الانفجارات ويسرّع الإنعاش الميداني.") },
			{ TEXT("Irregular Warfare Tactics"), TEXT("تكتيكات الحرب غير النظامية") },
			{ TEXT("Increases grenade/ammo capacity, advance speed, and guerrilla maneuver ability."), TEXT("يزيد سعة القنابل والذخيرة وسرعة التقدم وقدرة المناورة.") },
			{ TEXT("Combat Engineering"), TEXT("الهندسة القتالية") },
			{ TEXT("Improves tactical reload speed and reinforces defensive cover positions."), TEXT("يحسّن سرعة التلقيم التكتيكي ويعزّز مواقع الستر الدفاعية.") },
			{ TEXT("SERVICE DOSSIER"), TEXT("سجل الخدمة") },
			{ TEXT("Choose profile, avatar, callsign, and combat records in one readable tactical card."), TEXT("اختر الملف والصورة والاسم الحركي والسجلات القتالية في بطاقة تكتيكية واحدة.") },
			{ TEXT("No saved profile exists yet."), TEXT("لا يوجد ملف محفوظ بعد.") },
			{ TEXT("+ Create New Profile"), TEXT("+ إنشاء ملف جديد") },
			{ TEXT("IDs and names are stored only inside this dossier system."), TEXT("تُحفظ الهويات والأسماء داخل نظام السجل هذا فقط.") },
			{ TEXT("Field ID Card"), TEXT("بطاقة الهوية الميدانية") },
			{ TEXT("Fighter"), TEXT("مقاتل") },
			{ TEXT("Soldier Name"), TEXT("اسم المقاتل") },
			{ TEXT("Edit display name or choose a preset callsign"), TEXT("عدِّل الاسم الظاهر أو اختر اسمًا حركيًا جاهزًا") },
			{ TEXT("Save Name"), TEXT("حفظ الاسم") },
			{ TEXT("Edit Name"), TEXT("تعديل الاسم") },
			{ TEXT("Preset Name"), TEXT("اسم جاهز") },
			{ TEXT("Cancel"), TEXT("إلغاء") },
			{ TEXT("Avatar & Records"), TEXT("الصورة والسجلات") },
			{ TEXT("Shahid Rostami"), TEXT("الشهيد رستمي") },
			{ TEXT("Basiji Fighter"), TEXT("مقاتل بسيجي") },
			{ TEXT("Army Commando"), TEXT("مغوار الجيش") },
			{ TEXT("Irregular Warfare"), TEXT("الحرب غير النظامية") },
			{ TEXT("Major Shahid Iraj Rostami"), TEXT("الرائد الشهيد إيرج رستمي") },
			{ TEXT("Chamran Scout"), TEXT("كشّاف جمران") },
			{ TEXT("Line-Breaker Fighter"), TEXT("مقاتل كاسر الخطوط") },
			{ TEXT("Karkheh Tank Hunter"), TEXT("صائد دبابات الكرخة") },
			{ TEXT("Keyboard: Persian"), TEXT("لوحة المفاتيح: فارسية") },
			{ TEXT("Keyboard: EN"), TEXT("لوحة المفاتيح: EN") },
			{ TEXT("Keyboard: English"), TEXT("لوحة المفاتيح: إنجليزية") },
			{ TEXT("0 minutes"), TEXT("0 دقيقة") },
			{ TEXT("Enemy Forces"), TEXT("قوات العدو") },
			{ TEXT("Tanks Destroyed"), TEXT("دبابات مدمَّرة") },
			{ TEXT("Headshots"), TEXT("إصابات الرأس") },
			{ TEXT("Squad Revives"), TEXT("إنعاشات الفصيل") },
			{ TEXT("Time Deployed"), TEXT("زمن الانتشار") },
			{ TEXT("HONORS CASE"), TEXT("خزانة الأوسمة") },
			{ TEXT("Medals sit in separate frames; progress and text are shown in clean readable cards."), TEXT("الأوسمة في إطارات مستقلة؛ يُعرض التقدم والنص في بطاقات واضحة.") },
			{ TEXT("Selected Medal"), TEXT("الوسام المختار") },
			{ TEXT("Medal"), TEXT("وسام") },
			{ TEXT("Status: earned"), TEXT("الحالة: مُنح") },
			{ TEXT("Status: in progress"), TEXT("الحالة: قيد الإنجاز") },
			{ TEXT("This honor is recorded in the soldier dossier."), TEXT("هذا الوسام مسجَّل في سجل المقاتل.") },
			{ TEXT("The honors catalog is empty."), TEXT("فهرس الأوسمة فارغ.") },
			{ TEXT("First Blood"), TEXT("الدم الأول") },
			{ TEXT("Neutralize the first hostile wave in the frontline trenches."), TEXT("صدّ الموجة المعادية الأولى في خنادق الجبهة.") },
			{ TEXT("Neutralize the first enemy combat wave in Dehlavieh trenches."), TEXT("صدّ موجة العدو الأولى في خنادق دهلاوية.") },
			{ TEXT("Defender of Dehlavieh"), TEXT("مدافع دهلاوية") },
			{ TEXT("Complete all Karkheh and Dehlavieh front missions successfully."), TEXT("أنجز جميع مهام جبهتي الكرخة ودهلاوية بنجاح.") },
			{ TEXT("Heroic Combat Medic"), TEXT("المسعف القتالي البطل") },
			{ TEXT("Revive wounded squadmates 5 times during combat by holding E."), TEXT("أنعش رفاق الفصيل الجرحى 5 مرات أثناء القتال بالضغط المطوّل على E.") },
			{ TEXT("Major Rostami's Medal of Honor"), TEXT("وسام شرف الرائد رستمي") },
			{ TEXT("Reach level 5 and unlock heavy armory weapons."), TEXT("ابلغ المستوى 5 وافتح الأسلحة الثقيلة.") },
			{ TEXT("RELICS OF THE FALLEN"), TEXT("تذكارات الشهداء") },
			{ TEXT("No relic has been recorded yet — find field notes on the battlefield."), TEXT("لم يُسجَّل أي تذكار بعد — اعثر على المذكرات الميدانية في أرض المعركة.") },
			{ TEXT("Comrade Relic"), TEXT("تذكار رفيق") },
			{ TEXT("COMBAT INTENSITY"), TEXT("شدة القتال") },
			{ TEXT("Four clean cards; combat intensity rises from training to lethal simulation."), TEXT("أربع بطاقات واضحة؛ تتصاعد شدة القتال من التدريب إلى المحاكاة المميتة.") },
			{ TEXT("Recruit"), TEXT("مجنَّد") },
			{ TEXT("Command training and orientation"), TEXT("تدريب على القيادة وتعريف بالأوامر") },
			{ TEXT("Low Risk"), TEXT("خطر منخفض") },
			{ TEXT("• Enemies react more slowly"), TEXT("• يستجيب الأعداء ببطء أكبر") },
			{ TEXT("• Supplies and aid are more available"), TEXT("• الإمدادات والإسعاف متوافرة أكثر") },
			{ TEXT("• Best for learning squad commands"), TEXT("• الأفضل لتعلّم أوامر الفصيل") },
			{ TEXT("Standard operational balance"), TEXT("توازن عملياتي قياسي") },
			{ TEXT("Medium Risk"), TEXT("خطر متوسط") },
			{ TEXT("• Enemies take cover and apply pressure"), TEXT("• يحتمي الأعداء ويمارسون الضغط") },
			{ TEXT("• Ammo must be managed"), TEXT("• يجب إدارة الذخيرة") },
			{ TEXT("• Recommended core experience"), TEXT("• التجربة الأساسية الموصى بها") },
			{ TEXT("Frontline Veteran"), TEXT("محارب الخطوط الأمامية") },
			{ TEXT("Heavy fire and narrow windows"), TEXT("نيران كثيفة وفرص ضيقة") },
			{ TEXT("High Risk"), TEXT("خطر مرتفع") },
			{ TEXT("• Flanking and suppression are serious"), TEXT("• الالتفاف والإخماد خطران جدّيان") },
			{ TEXT("• Medical supplies are very limited"), TEXT("• الإمدادات الطبية محدودة جدًا") },
			{ TEXT("• Precise squad coordination is required"), TEXT("• مطلوب تنسيق دقيق للفصيل") },
			{ TEXT("Lethal Commander"), TEXT("القائد المميت") },
			{ TEXT("Ruthless frontline simulation"), TEXT("محاكاة جبهة بلا رحمة") },
			{ TEXT("Maximum Risk"), TEXT("الخطر الأقصى") },
			{ TEXT("• One mistake can break the operation"), TEXT("• خطأ واحد قد يُفشل العملية") },
			{ TEXT("• The enemy is coordinated and ruthless"), TEXT("• العدو منسَّق ولا يرحم") },
			{ TEXT("• No reliance on assist indicators"), TEXT("• لا اعتماد على مؤشرات المساعدة") },
			{ TEXT("Confirm & Deploy"), TEXT("تأكيد وانتشار") },
			{ TEXT("Load Saved Operation Position"), TEXT("تحميل موقع العملية المحفوظ") },
			{ TEXT("No saved data"), TEXT("لا توجد بيانات محفوظة") },
			{ TEXT("Low"), TEXT("منخفض") },
			{ TEXT("Medium"), TEXT("متوسط") },
			{ TEXT("High"), TEXT("مرتفع") },
			{ TEXT("Epic"), TEXT("فائق (Epic)") },
			{ TEXT("Graphics and shadow quality:"), TEXT("جودة الرسوم والظلال:") },
			{ TEXT("Menu and command language:"), TEXT("لغة القوائم والأوامر:") },
			{ TEXT("Persian"), TEXT("الفارسية") },
			{ TEXT("Battle SFX volume:"), TEXT("مستوى صوت المؤثرات القتالية:") },
			{ TEXT("Radio and voice volume:"), TEXT("مستوى صوت اللاسلكي والمحادثات:") },
			{ TEXT("CLASSIFIED - TOP SECRET"), TEXT("سري للغاية - مكتوم") },
			{ TEXT("OPERATIONAL INTELLIGENCE | Dehlavieh — Susangerd Defensive Axis"), TEXT("استخبارات عملياتية | محور دهلاوية — سوسنجرد الدفاعي") },
			{ TEXT("Document date: 15 June 1981 // Theater: Khuzestan - Dehlavieh frontline"), TEXT("تاريخ الوثيقة: 15 حزيران/يونيو 1981 // المسرح: خوزستان - جبهة دهلاوية") },
			{ TEXT("Axis command: Dr. Mostafa Chamran | Field commander: Major Shahid Iraj Rostami"), TEXT("قيادة المحور: الدكتور مصطفى جمران | القائد الميداني: الرائد الشهيد إيرج رستمي") },
			{ TEXT("Objective: hold forward berms, halt armored columns, and defend Ahvaz"), TEXT("الهدف: تثبيت السواتر الأمامية وإيقاف الأرتال المدرعة والدفاع عن الأهواز") },
			{ TEXT("Tactics: guerrilla raids, light mortar fire, anti-armor direction, and smart mine placement"), TEXT("التكتيك: غارات مغاوير ونيران هاون خفيفة وتوجيه مضاد للدروع وزرع ألغام ذكي") },
			{ TEXT("Command message: Brothers, this ground is the honor of our homeland. We will not retreat one step."), TEXT("رسالة القيادة: «أيها الإخوة، هذه الأرض شرف الوطن. لن نتراجع شبرًا واحدًا.»") },
			{ TEXT("Dr. Shahid Mostafa Chamran"), TEXT("الدكتور الشهيد مصطفى جمران") },
			{ TEXT("Sardar Shahid Hassan Bagheri"), TEXT("القائد الشهيد حسن باقري") },
			{ TEXT("Shahid Mohammad Jahan-Ara"), TEXT("الشهيد محمد جهان آرا") },
			{ TEXT("Brave Fighter"), TEXT("مقاتل باسل") },
			{ TEXT("O+ (positive)"), TEXT("O+ (موجب)") },
			{ TEXT("Dehlavieh Axis Veteran"), TEXT("محارب محور دهلاوية") },
			{ TEXT("55th Airborne Commando"), TEXT("مغاوير اللواء 55 المحمول جوًا") },
			{ TEXT("Susangerd Line-Breaker"), TEXT("كاسر خطوط سوسنجرد") },
			{ TEXT("Bostan Defense Guard"), TEXT("حارس دفاع بستان") },
			{ TEXT("This weapon is already unlocked."), TEXT("هذا السلاح مفتوح بالفعل.") },
			{ TEXT("The requested weapon was not found in the armory."), TEXT("السلاح المطلوب غير موجود في المستودع.") },
		};
		const FString Trimmed = InText.TrimStartAndEnd();
		if (const FString* Found = ArabicMap.Find(Trimmed))
		{
			FString Result = InText;
			Result.ReplaceInline(*Trimmed, **Found);
			return Result;
		}
		return InText;
	}

	static FString SquadAIMenuArabicText(const FString& InText)
	{
		FString NormalizedInput = InText;
		NormalizedInput.ReplaceInline(TEXT("\r\n"), TEXT("\n"));
		NormalizedInput.ReplaceInline(TEXT("\r"), TEXT("\n"));
		if (NormalizedInput.Contains(TEXT("\n")))
		{
			TArray<FString> Lines;
			NormalizedInput.ParseIntoArray(Lines, TEXT("\n"), false);
			FString Joined;
			for (int32 i = 0; i < Lines.Num(); ++i)
			{
				if (i > 0) Joined += TEXT("\n");
				Joined += SquadAIMenuArabicSingleLine(Lines[i]);
			}
			return Joined;
		}
		return SquadAIMenuArabicSingleLine(NormalizedInput);
	}

	// S17-ARFIX: single decision point for what the menu actually renders.
	static FString SquadAIMenuDisplayText(const FString& InText, const FString& LangCode)
	{
		if (LangCode.StartsWith(TEXT("fa"), ESearchCase::IgnoreCase)) return InText;
		const FString English = SquadAIMenuEnglishText(InText);
		if (LangCode.StartsWith(TEXT("ar"), ESearchCase::IgnoreCase)) return SquadAIMenuArabicText(English);
		return English;
	}
}

ASquadAIMainMenuHUD::ASquadAIMainMenuHUD()
{
	PrimaryActorTick.bCanEverTick = true;
	// B6-21: language preset moved to BeginPlay (no subsystems exist at ctor/CDO time).
	ApplyThemeColors();

	// Resolve modular tactical textures
	static ConstructorHelpers::FObjectFinder<UTexture2D> FrameGoldFinder(TEXT("/Game/Textures/UI_Frame_TacticalBorder_Gold"));
	if (FrameGoldFinder.Succeeded()) FrameTacticalGoldTexture = FrameGoldFinder.Object;

	static ConstructorHelpers::FObjectFinder<UTexture2D> FrameCrimsonFinder(TEXT("/Game/Textures/UI_Frame_TacticalBorder_Crimson"));
	if (FrameCrimsonFinder.Succeeded()) FrameTacticalCrimsonTexture = FrameCrimsonFinder.Object;

	static ConstructorHelpers::FObjectFinder<UTexture2D> FrameHexFinder(TEXT("/Game/Textures/UI_Frame_Badge_Hexagon"));
	if (FrameHexFinder.Succeeded()) FrameBadgeHexagonTexture = FrameHexFinder.Object;

	static ConstructorHelpers::FObjectFinder<UTexture2D> FrameAvaFinder(TEXT("/Game/Textures/UI_Frame_Avatar_Portrait"));
	if (FrameAvaFinder.Succeeded()) FrameAvatarPortraitTexture = FrameAvaFinder.Object;

	static ConstructorHelpers::FObjectFinder<UTexture2D> EmblemFinder(TEXT("/Game/Textures/UI_Military_Watermark_Emblem"));
	if (EmblemFinder.Succeeded()) WatermarkEmblemTexture = EmblemFinder.Object;

	static ConstructorHelpers::FObjectFinder<UTexture2D> TraitTankFinder(TEXT("/Game/Textures/UI_Trait_TankDestroyer"));
	if (TraitTankFinder.Succeeded()) TraitTankDestroyerTexture = TraitTankFinder.Object;

	static ConstructorHelpers::FObjectFinder<UTexture2D> TraitHeavyFinder(TEXT("/Game/Textures/UI_Trait_HeavyCaliber"));
	if (TraitHeavyFinder.Succeeded()) TraitHeavyCaliberTexture = TraitHeavyFinder.Object;

	static ConstructorHelpers::FObjectFinder<UTexture2D> TraitDesertFinder(TEXT("/Game/Textures/UI_Trait_DesertReliability"));
	if (TraitDesertFinder.Succeeded()) TraitDesertReliabilityTexture = TraitDesertFinder.Object;

	static ConstructorHelpers::FObjectFinder<UTexture2D> TraitSuppFinder(TEXT("/Game/Textures/UI_Trait_AreaSuppression"));
	if (TraitSuppFinder.Succeeded()) TraitAreaSuppressionTexture = TraitSuppFinder.Object;

	static ConstructorHelpers::FObjectFinder<UTexture2D> TraitMarksFinder(TEXT("/Game/Textures/UI_Trait_SilentMarksman"));
	if (TraitMarksFinder.Succeeded()) TraitSilentMarksmanTexture = TraitMarksFinder.Object;
}

// ============================ S19-IMGSEQ ===================================
// Image-sequence menu playback avoids the video codec and its keyframe-seek
// flush, but it is not decode-free: ImgMedia still decodes every JPG/PNG frame
// and holds frames in its global cache. This is why it must not run alongside
// the intro sequence and why oversized/high-FPS sequences can still cache-thrash.
//
// Everything here goes through the reflection layer on purpose. UImgMediaSource
// lives in the OPTIONAL ImgMedia plugin and is declared MinimalAPI, so naming
// the type or calling its methods directly would fail to LINK for anyone with
// the plugin switched off. Resolving the class by name and calling its
// UFUNCTIONs via ProcessEvent keeps this module independent of that plugin.
bool ASquadAIMainMenuHUD::TryOpenImageSequence(UMediaPlayer* Player, const FString& SequenceDir, float FPS)
{
	if (!Player || SequenceDir.IsEmpty())
	{
		return false;
	}
	if (!IFileManager::Get().DirectoryExists(*SequenceDir))
	{
		return false;
	}

	UClass* ImgSrcClass = FindObject<UClass>(nullptr, TEXT("/Script/ImgMedia.ImgMediaSource"));
	if (!ImgSrcClass)
	{
		ImgSrcClass = LoadObject<UClass>(nullptr, TEXT("/Script/ImgMedia.ImgMediaSource"));
	}
	if (!ImgSrcClass)
	{
		// Tell the user WHY, so this is diagnosable without a debugger. The two
		// cases need completely different fixes, and the log previously could not
		// tell them apart.
		const FString PluginFile = FPaths::EnginePluginsDir() / TEXT("Media/ImgMedia/ImgMedia.uplugin");
		if (!IFileManager::Get().FileExists(*PluginFile))
		{
			UE_LOG(LogTemp, Warning, TEXT("[SquadAIMenu] S19-IMGSEQ: sequence found at %s, but the ImgMedia plugin is NOT INSTALLED."), *SequenceDir);
			UE_LOG(LogTemp, Warning, TEXT("[SquadAIMenu] S19-IMGSEQ: expected the plugin at: %s"), *PluginFile);
			UE_LOG(LogTemp, Warning, TEXT("[SquadAIMenu] S19-IMGSEQ: it ships with the engine - reinstall, or use SquadAI.MenuImgSeq 0. Falling back to MP4."));
		}
		else
		{
			UE_LOG(LogTemp, Warning, TEXT("[SquadAIMenu] S19-IMGSEQ: sequence found at %s, but the ImgMedia plugin is NOT ENABLED in this project."), *SequenceDir);
			UE_LOG(LogTemp, Warning, TEXT("[SquadAIMenu] S19-IMGSEQ: Edit > Plugins > Media Players > \"Image Sequence Media Player\" (that is its display name; the internal name is ImgMedia)."));
			UE_LOG(LogTemp, Warning, TEXT("[SquadAIMenu] S19-IMGSEQ: or add this to your .uproject Plugins array: {\"Name\": \"ImgMedia\", \"Enabled\": true}"));
			UE_LOG(LogTemp, Warning, TEXT("[SquadAIMenu] S19-IMGSEQ: until then the MP4 is used, which is fine."));
		}
		return false;
	}

	UObject* Src = NewObject<UObject>(this, ImgSrcClass);
	if (!Src)
	{
		return false;
	}

	// SetSequencePath is a UFUNCTION, so ProcessEvent reaches it even though the
	// class is MinimalAPI.
	UFunction* SetPathFn = ImgSrcClass->FindFunctionByName(TEXT("SetSequencePath"));
	if (!SetPathFn)
	{
		UE_LOG(LogTemp, Warning, TEXT("[SquadAIMenu] S19-IMGSEQ: SetSequencePath missing on ImgMediaSource - falling back to MP4."));
		return false;
	}
	// Field name is deliberately not "Path": the static checker resolves printf
	// arguments by name, and a struct field called Path would make it flag
	// unrelated const TCHAR* Path variables elsewhere in this file.
	struct FSetSeqPathParams { FString InSequenceDirectory; };
	FSetSeqPathParams PathParams;
	PathParams.InSequenceDirectory = SequenceDir;
	Src->ProcessEvent(SetPathFn, &PathParams);

	// ImgMedia only reads a frame rate out of EXR headers. For JPG/PNG we have to
	// supply it or the clip plays back at a default rate that will not match.
	if (FStructProperty* FrProp = CastField<FStructProperty>(ImgSrcClass->FindPropertyByName(TEXT("FrameRateOverride"))))
	{
		void* FrAddr = FrProp->ContainerPtrToValuePtr<void>(Src);
		const int32 Den = 1000;
		const int32 Num = FMath::Max(1, FMath::RoundToInt(FPS * static_cast<float>(Den)));
		if (FProperty* N = FrProp->Struct->FindPropertyByName(TEXT("Numerator")))
		{
			*N->ContainerPtrToValuePtr<int32>(FrAddr) = Num;
		}
		if (FProperty* D = FrProp->Struct->FindPropertyByName(TEXT("Denominator")))
		{
			*D->ContainerPtrToValuePtr<int32>(FrAddr) = Den;
		}
	}

	// A stale proxy override would silently play a low-resolution sub-folder.
	if (FStrProperty* ProxyProp = CastField<FStrProperty>(ImgSrcClass->FindPropertyByName(TEXT("ProxyOverride"))))
	{
		*ProxyProp->ContainerPtrToValuePtr<FString>(Src) = FString();
	}

	UMediaSource* MediaSrc = Cast<UMediaSource>(Src);
	if (!MediaSrc)
	{
		return false;
	}

	// Electra cannot play image sequences - ask for the ImgMedia player by name,
	// and undo it if we bail out below so the MP4 fallback still works.
	const FName WantedPlayer(*CVarSquadAIImgSeqPlayer.GetValueOnGameThread());
	Player->SetDesiredPlayerName(WantedPlayer);

	if (!Player->CanPlaySource(MediaSrc))
	{
		Player->SetDesiredPlayerName(NAME_None);
		UE_LOG(LogTemp, Warning, TEXT("[SquadAIMenu] S19-IMGSEQ: player '%s' cannot play %s - falling back to MP4."),
			*WantedPlayer.ToString(), *SequenceDir);
		return false;
	}
	if (!Player->OpenSource(MediaSrc))
	{
		Player->SetDesiredPlayerName(NAME_None);
		UE_LOG(LogTemp, Warning, TEXT("[SquadAIMenu] S19-IMGSEQ: OpenSource failed for %s - falling back to MP4."), *SequenceDir);
		return false;
	}

	UE_LOG(LogTemp, Log, TEXT("[SquadAIMenu] S19-IMGSEQ: image sequence opened - ImgMedia frame path (no video-codec decode), %s @ %.2f fps."),
		*SequenceDir, FPS);
	return true;
}

// ============================ S16-INTRO ====================================
void ASquadAIMainMenuHUD::InitIntroVideo()
{
	if (CVarSquadAIMenuIntro.GetValueOnGameThread() != 1)
	{
		return;
	}
	const FString SeqAbs   = FPaths::ConvertRelativePathToFull(FPaths::ProjectContentDir() / TEXT("Movies/MenuIntro_Seq"));
	const FString VideoAbs = FPaths::ConvertRelativePathToFull(FPaths::ProjectContentDir() / TEXT("Movies/MenuIntro.mp4"));
	const bool bSeqWanted  = (CVarSquadAIMenuImgSeq.GetValueOnGameThread() == 1);
	const bool bHasSeq     = IFileManager::Get().DirectoryExists(*SeqAbs);
	if (!FPaths::FileExists(VideoAbs) && !(bSeqWanted && bHasSeq))
	{
		UE_LOG(LogTemp, Log, TEXT("[SquadAIMenu] S16-INTRO: no intro at %s and no image sequence at %s — straight to menu."), *VideoAbs, *SeqAbs);
		return;
	}
	IntroVideoPlayer = NewObject<UMediaPlayer>(this, TEXT("SquadAIMenuIntroPlayer"));
	IntroVideoTexture = NewObject<UMediaTexture>(this, TEXT("SquadAIMenuIntroTexture"));
	if (!IntroVideoPlayer || !IntroVideoTexture)
	{
		IntroVideoPlayer = nullptr;
		IntroVideoTexture = nullptr;
		return;
	}
	// AutoClear OFF: the last video frame must persist under the smoke ramp-in.
	IntroVideoTexture->AutoClear = false;
	IntroVideoTexture->SetMediaPlayer(IntroVideoPlayer);
	IntroVideoTexture->UpdateResource();
	IntroVideoPlayer->PlayOnOpen = true;
	IntroVideoPlayer->SetLooping(false);
	IntroVideoPlayer->OnEndReached.AddDynamic(this, &ASquadAIMainMenuHUD::OnIntroVideoEnded);

	// S19-IMGSEQ: same preference for the intro clip.
	if (bSeqWanted && bHasSeq && TryOpenImageSequence(IntroVideoPlayer, SeqAbs, 30.f))
	{
		bIntroVideoActive = true;
		IntroStartRealTime = GetWorld() ? GetWorld()->GetRealTimeSeconds() : 0.f;
		UE_LOG(LogTemp, Log, TEXT("[SquadAIMenu] S16-INTRO: intro image sequence opened: %s"), *SeqAbs);
		return;
	}

	if (IntroVideoPlayer->OpenUrl(FString(TEXT("file://")) + VideoAbs))
	{
		bIntroVideoActive = true;
		IntroStartRealTime = GetWorld() ? GetWorld()->GetRealTimeSeconds() : 0.f;
		UE_LOG(LogTemp, Log, TEXT("[SquadAIMenu] S16-INTRO: intro video opened: %s (menu music starts alongside — SetupActor BeginPlay)."), *VideoAbs);
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("[SquadAIMenu] S16-INTRO: OpenUrl FAILED for %s — straight to menu."), *VideoAbs);
		IntroVideoPlayer = nullptr;
		IntroVideoTexture = nullptr;
	}
}

void ASquadAIMainMenuHUD::OnIntroVideoEnded()
{
	BeginIntroSmoke();
}

void ASquadAIMainMenuHUD::BeginIntroSmoke()
{
	if (IntroSmokeT < 0.f && IntroSmokeT > -1.5f) // only from idle (-1), never restart from done (-2)
	{
		IntroSmokeT = 0.f;
		FogClockLastUpdate = -1.0;            // S19-FOGSMOOTH: rebase on the next step
		FogClockFrameStamp = 0xFFFFFFFFu;
	}
}

float ASquadAIMainMenuHUD::AdvanceFogClock()
{
	const double Now = FPlatformTime::Seconds();

	// First step after the sequence starts: establish the baseline, do not move.
	if (FogClockLastUpdate < 0.0)
	{
		FogClockLastUpdate = Now;
		FogClockFrameStamp = GFrameCounter;
		return 0.f;
	}

	// One step per frame at most, even if DrawHUD runs twice.
	if (FogClockFrameStamp == GFrameCounter)
	{
		return 0.f;
	}
	FogClockFrameStamp = GFrameCounter;

	double Step = Now - FogClockLastUpdate;
	FogClockLastUpdate = Now;

	// Clamp the step: a loading hitch or a tab-out otherwise hands us a
	// multi-second delta and the fog teleports to the end. 50 ms is ~3 frames
	// at 60 Hz -- smooth motion, and after a stall the wipe simply runs a
	// touch longer instead of jumping.
	Step = FMath::Clamp(Step, 0.0, 0.05);

	return static_cast<float>(Step * static_cast<double>(GetFogSpeedScale()));
}

void ASquadAIMainMenuHUD::DrawIntroSmoke(float ScreenW, float ScreenH, float Alpha)
{
	if (Alpha <= 0.f) return;
	// Full wash first (guarantees coverage even without the dust texture)...
	DrawRect(FLinearColor(0.105f, 0.095f, 0.085f, FMath::Clamp(Alpha, 0.f, 1.f) * 0.90f), 0.f, 0.f, ScreenW, ScreenH);
	// ...then big drifting smoke billows on top.
	if (MenuSoftDustTexture)
	{
		const float T = GetWorld() ? GetWorld()->GetRealTimeSeconds() : 0.f;
		for (int32 i = 0; i < 7; ++i)
		{
			const float Fi = static_cast<float>(i);
			const float Size = ScreenW * (0.55f + 0.18f * FMath::Fmod(Fi * 0.731f, 1.f));
			const float X = ScreenW * (0.06f + 0.155f * Fi) + FMath::Sin(T * 0.55f + Fi * 2.1f) * ScreenW * 0.05f - Size * 0.5f;
			const float Y = ScreenH * (0.5f + 0.34f * FMath::Sin(Fi * 1.7f + 0.9f)) + FMath::Sin(T * 0.42f + Fi * 1.3f) * ScreenH * 0.06f - Size * 0.5f;
			const float Rot = Fi * 51.f + T * (i % 2 == 0 ? 5.f : -4.f);
			const FLinearColor C = (i % 3 == 0)
				? FLinearColor(0.16f, 0.145f, 0.13f, Alpha * 0.55f)
				: FLinearColor(0.55f, 0.50f, 0.44f, Alpha * 0.40f);
			DrawTexture(MenuSoftDustTexture, X, Y, Size, Size, 0.f, 0.f, 1.f, 1.f, C, BLEND_Translucent, 1.f, false, Rot, FVector2D(0.5f, 0.5f));
		}
	}
}

bool ASquadAIMainMenuHUD::DrawIntroSequence(float ScreenW, float ScreenH)
{
	if (!bIntroVideoActive)
	{
		return false;
	}
	// S19-FOGSMOOTH: the fog clock is advanced by AdvanceFogClock() from a
	// monotonic source; the world delta is no longer used for it.
	// Skip: any confirm/back key or click jumps to the smoke wipe.
	// S17-FOGFX: a second press during the fog/logo hold skips to the clear.
	if (APlayerController* PC = GetOwningPlayerController())
	{
		if (PC->WasInputKeyJustPressed(EKeys::SpaceBar) || PC->WasInputKeyJustPressed(EKeys::Enter) ||
			PC->WasInputKeyJustPressed(EKeys::Escape) || PC->WasInputKeyJustPressed(EKeys::LeftMouseButton))
		{
			if (bFogFXReady && IntroSmokeT >= 0.f)
			{
				IntroSmokeT = FMath::Max(IntroSmokeT, FogSmokeInTotal() - 0.001f);
			}
			BeginIntroSmoke();
		}
	}

	DrawRect(FLinearColor::Black, 0.f, 0.f, ScreenW, ScreenH);
	const float VidW = IntroVideoTexture ? IntroVideoTexture->GetSurfaceWidth() : 0.f;
	const float VidH = IntroVideoTexture ? IntroVideoTexture->GetSurfaceHeight() : 0.f;
	if (VidW > 2.f && VidH > 2.f)
	{
		bIntroGotFrame = true;
		// Aspect-correct cover crop (same rules as the menu key art).
		const float TexAspect = VidW / VidH;
		const float ViewAspect = ScreenW / FMath::Max(1.f, ScreenH);
		float U0 = 0.f, V0 = 0.f, US = 1.f, VS = 1.f;
		if (TexAspect > ViewAspect) { US = ViewAspect / TexAspect; U0 = (1.f - US) * 0.5f; }
		else if (TexAspect < ViewAspect) { VS = TexAspect / ViewAspect; V0 = (1.f - VS) * 0.5f; }
		DrawTexture(IntroVideoTexture, 0.f, 0.f, ScreenW, ScreenH, U0, V0, US, VS, FLinearColor::White);
	}
	else if (!bIntroGotFrame && GetWorld() && GetWorld()->GetRealTimeSeconds() - IntroStartRealTime > 4.f)
	{
		// Codec never delivered a frame — bail straight to the menu, no smoke.
		UE_LOG(LogTemp, Warning, TEXT("[SquadAIMenu] S16-INTRO: no frame within 4 s — skipping intro."));
		bIntroVideoActive = false;
		IntroSmokeT = -2.f;
		return false;
	}

	// Smoke ramp-in over the final video frame, then hand over to the menu.
	// S17-FOGFX: with fog assets the ramp covers blast+whiteout+logo hold, so
	// the frozen last frame stays hidden beneath the fog for the whole reveal.
	if (IntroSmokeT >= 0.f)
	{
		// S19-FOGSPEED: the clock runs at the configured speed; every phase
		// threshold below is compared against the same scaled clock.
		IntroSmokeT += AdvanceFogClock(); // S19-FOGSMOOTH (was Delta * Speed)
		if (bFogFXReady)
		{
			DrawFogFX(ScreenW, ScreenH, IntroSmokeT);
		}
		else
		{
			DrawIntroSmoke(ScreenW, ScreenH, FMath::Clamp(IntroSmokeT / SquadAIIntroSmokeIn, 0.f, 1.f));
		}
		if (IntroSmokeT >= FogSmokeInTotal())
		{
			bIntroVideoActive = false; // next frame draws the menu under the clearing smoke
			// S19-STUTTER: closing the media player tears down the decoder and the
			// media texture synchronously on the game thread — and this used to
			// happen on the exact frame the clear began, which is the hitch you
			// felt "when the fog goes down". Defer it: pause now (cheap) and
			// release once the wipe has finished and the menu is on screen.
			if (IntroVideoPlayer)
			{
				IntroVideoPlayer->Pause();
			}
			bIntroVideoClosePending = true;
		}
	}
	return true;
}

void ASquadAIMainMenuHUD::DrawIntroSmokeOverlay(float ScreenW, float ScreenH)
{
	if (bIntroVideoActive || IntroSmokeT < FogSmokeInTotal() || IntroSmokeT < 0.f)
	{
		return;
	}
	IntroSmokeT += AdvanceFogClock(); // S19-FOGSMOOTH (was Delta * Speed)
	const float OutPhase = (IntroSmokeT - FogSmokeInTotal()) / FogSmokeOutTotal();
	if (OutPhase >= 1.f)
	{
		IntroSmokeT = -2.f; // done for good
		ReleaseIntroVideo();  // S19-STUTTER: safe now — the menu is fully visible
		return;
	}
	if (bFogFXReady) // S17-FOGFX: full rising clear drawn from the same clock
	{
		DrawFogFX(ScreenW, ScreenH, IntroSmokeT);
		return;
	}
	// Eased clear: smoke lingers, then breaks up quickly at the end.
	const float Alpha = FMath::Pow(1.f - FMath::Clamp(OutPhase, 0.f, 1.f), 1.6f);
	DrawIntroSmoke(ScreenW, ScreenH, Alpha);
}

// ============================ S17-FOGFX ====================================
// HQ explosion-fog wipe. Visuals + exact timings ported from the approved
// WebGL preview (26 warm-graded billows, dark earth core carrying the logo,
// 150 round dirt motes, whiteout wash, long accelerating rising clear).

float ASquadAIMainMenuHUD::FogSmokeInTotal() const
{
	return bFogFXReady ? (SquadAIFogInT + SquadAIFogPeakT + SquadAIFogLogoT) : SquadAIIntroSmokeIn;
}

float ASquadAIMainMenuHUD::FogSmokeOutTotal() const
{
	return bFogFXReady ? SquadAIFogOutT : SquadAIIntroSmokeOut;
}

float ASquadAIMainMenuHUD::GetFogSpeedScale() const
{
	// Clamp so a stray console value can never make the wipe instant (which
	// reads as a flash) or effectively endless (which reads as a hang).
	return FMath::Clamp(CVarSquadAIMenuFogSpeed.GetValueOnGameThread(), 0.1f, 8.f);
}

void ASquadAIMainMenuHUD::ReleaseIntroVideo()
{
	if (!bIntroVideoClosePending)
	{
		return;
	}
	bIntroVideoClosePending = false;
	if (IntroVideoPlayer)
	{
		IntroVideoPlayer->Close();
	}
	IntroVideoPlayer = nullptr;
	IntroVideoTexture = nullptr;
}

void ASquadAIMainMenuHUD::InitFogFX()
{
	if (CVarSquadAIMenuFogFX.GetValueOnGameThread() != 1)
	{
		return;
	}
	const FString Dir = FPaths::ConvertRelativePathToFull(FPaths::ProjectContentDir() / TEXT("Movies/FogFX"));

	// --- sprites (loose PNGs, zero editor setup — same convention as the MP4s)
	for (int32 i = 1; i <= 4; ++i)
	{
		const FString P = Dir / FString::Printf(TEXT("puff%d.png"), i);
		if (FPaths::FileExists(P))
		{
			if (UTexture2D* T = FImageUtils::ImportFileAsTexture2D(P))
			{
				FogPuffTextures.Add(T);
			}
		}
	}
	if (FogPuffTextures.Num() == 0)
	{
		UE_LOG(LogTemp, Log, TEXT("[SquadAIMenu] S17-FOGFX: no puff*.png in %s — classic S16 dust wipe."), *Dir);
		return;
	}
	const FString LogoP = Dir / TEXT("logo.png");
	const FString TitleP = Dir / TEXT("title.png");
	const FString NoiseP = Dir / TEXT("noise.png");
	if (FPaths::FileExists(LogoP))  FogLogoTexture  = FImageUtils::ImportFileAsTexture2D(LogoP);
	if (FPaths::FileExists(TitleP)) FogTitleTexture = FImageUtils::ImportFileAsTexture2D(TitleP);
	if (FPaths::FileExists(NoiseP)) FogNoiseTexture = FImageUtils::ImportFileAsTexture2D(NoiseP);

	// --- optional churn material (built once by SquadAI_ImportFogFX.py).
	// Surface-domain check mirrors the S16-FLAG3 lesson: a stale UI-domain
	// material would draw as NOTHING through Canvas, so it is refused here.
	constexpr int32 NumWhite = 26, NumBlack = 12;
	if (UMaterialInterface* FogMat = LoadObject<UMaterialInterface>(nullptr, TEXT("/Game/SquadAI/FogFX/M_FogBillow.M_FogBillow")))
	{
		const UMaterial* BaseMat = FogMat->GetMaterial();
		if (BaseMat && BaseMat->MaterialDomain == EMaterialDomain::MD_Surface && FogNoiseTexture)
		{
			const int32 NumMIDs = NumWhite + NumBlack + 2; // + logo + title
			FogFXMIDs.Reserve(NumMIDs);
			for (int32 i = 0; i < NumMIDs; ++i)
			{
				FogFXMIDs.Add(UMaterialInstanceDynamic::Create(FogMat, this));
			}
			bFogFXUseMaterial = true;
		}
		else
		{
			UE_LOG(LogTemp, Warning, TEXT("[SquadAIMenu] S17-FOGFX: M_FogBillow unusable (domain!=Surface or noise.png missing) — DrawTexture fallback."));
		}
	}

	// --- deterministic billow/dust fields (same distribution as the preview)
	FRandomStream RS(0x51A7F09);
	auto R = [&RS](float A, float B) { return A + RS.FRand() * (B - A); };

	const float RingDist[3] = { 0.10f, 0.32f, 0.55f };
	const int32 RingN[3]    = { 8, 10, 8 };
	for (int32 Ring = 0; Ring < 3; ++Ring)
	{
		for (int32 i = 0; i < RingN[Ring]; ++i)
		{
			FFogBillow B;
			B.Ang = (static_cast<float>(i) / RingN[Ring]) * 2.f * PI + R(-0.4f, 0.4f);
			B.Dist = RingDist[Ring] * R(0.7f, 1.3f);
			B.TexIdx = (Ring == 2) ? (RS.FRand() < 0.5f ? 2 : 3) : (RS.FRand() < 0.5f ? 0 : 1);
			B.TexIdx %= FogPuffTextures.Num();
			B.Delay = Ring * 0.10f + R(0.f, 0.12f);
			B.S0 = R(0.22f, 0.35f);
			B.S1 = R(0.85f, 1.25f) * (Ring == 0 ? 1.15f : 1.f);
			B.Rot = R(-0.45f, 0.45f);
			B.RotV = R(-0.10f, 0.10f);
			B.DriftX = R(-0.05f, 0.05f);
			B.DriftY = R(-0.34f, -0.16f);
			B.FadeLead = R(0.f, 0.75f);
			B.Seed = R(0.f, 100.f);
			B.Tint = FLinearColor::White;
			// Ring index reused for painter sorting below.
			B.Tint.A = static_cast<float>(Ring);
			FogWhiteBillows.Add(B);
		}
	}
	// wisps behind, dense core on top
	FogWhiteBillows.Sort([](const FFogBillow& A, const FFogBillow& B) { return A.Tint.A > B.Tint.A; });
	for (FFogBillow& B : FogWhiteBillows) { B.Tint.A = 1.f; }

	for (int32 i = 0; i < NumBlack; ++i)
	{
		FFogBillow B;
		const float K = R(0.07f, 0.15f);
		B.Ang = (static_cast<float>(i) / NumBlack) * 2.f * PI + R(-0.5f, 0.5f);
		B.Dist = R(0.04f, 0.17f);
		B.TexIdx = (RS.FRand() < 0.5f ? 0 : 1) % FogPuffTextures.Num();
		B.Delay = R(0.f, 0.30f);
		B.S0 = R(0.22f, 0.30f);
		B.S1 = R(0.55f, 0.90f);
		B.Rot = R(-0.4f, 0.4f);
		B.RotV = R(-0.08f, 0.08f);
		B.DriftX = R(-0.04f, 0.04f);
		B.DriftY = R(-0.30f, -0.15f);
		B.FadeLead = R(0.f, 0.4f);
		B.Seed = R(100.f, 200.f);
		B.Tint = FLinearColor(K * 1.18f, K, K * 0.74f, 1.f); // dark earth-brown
		FogBlackBillows.Add(B);
	}

	const FLinearColor DustTints[4] = {
		FLinearColor(0.95f, 0.62f, 0.34f), FLinearColor(1.f, 0.80f, 0.52f),
		FLinearColor(0.80f, 0.52f, 0.30f), FLinearColor(1.f, 0.92f, 0.72f) };
	for (int32 i = 0; i < 150; ++i)
	{
		FFogDust D;
		D.X0 = RS.FRand(); D.Y0 = RS.FRand();
		D.VX = R(-0.025f, 0.025f); D.VY = R(-0.07f, -0.015f);
		D.Size = R(3.f, 9.f); D.A0 = R(0.25f, 0.7f);
		D.Ph = R(0.f, 6.283f); D.Fl = R(1.5f, 4.5f);
		D.Tint = DustTints[FMath::Min(3, static_cast<int32>(RS.FRand() * 4.f))];
		FogDustMotes.Add(D);
	}

	// --- round soft dust-mote texture (radial falloff — no square pixels)
	constexpr int32 DS = 64;
	FogDustDotTexture = UTexture2D::CreateTransient(DS, DS, PF_B8G8R8A8);
	if (FogDustDotTexture)
	{
		FTexture2DMipMap& Mip = FogDustDotTexture->GetPlatformData()->Mips[0];
		FColor* Px = static_cast<FColor*>(Mip.BulkData.Lock(LOCK_READ_WRITE));
		for (int32 Y = 0; Y < DS; ++Y)
		{
			for (int32 X = 0; X < DS; ++X)
			{
				const float RX = (X + 0.5f) / DS * 2.f - 1.f;
				const float RY = (Y + 0.5f) / DS * 2.f - 1.f;
				const float Rad = FMath::Sqrt(RX * RX + RY * RY);
				const float A = FMath::Max(0.f, 1.f - Rad);
				const uint8 V = static_cast<uint8>(FMath::RoundToInt(255.f * A * A));
				Px[Y * DS + X] = FColor(255, 255, 255, V);
			}
		}
		Mip.BulkData.Unlock();
		FogDustDotTexture->SRGB = true;
		FogDustDotTexture->UpdateResource();
	}

	bFogFXReady = true;
	UE_LOG(LogTemp, Log, TEXT("[SquadAIMenu] S17-FOGFX: ACTIVE — %d puffs, logo:%d title:%d, churn material:%d."),
		FogPuffTextures.Num(), FogLogoTexture ? 1 : 0, FogTitleTexture ? 1 : 0, bFogFXUseMaterial ? 1 : 0);
}

void ASquadAIMainMenuHUD::DrawFogBillowQuad(int32 MIDIndex, UTexture2D* Sprite, float CX, float CY, float SizeW, float SizeH, float RotDeg, float Warp, float Diss, float Alpha, float Seed, const FLinearColor& Tint)
{
	if (!Sprite || Alpha <= 0.003f)
	{
		return;
	}
	// Logo/title art (the last two MID slots) must never get the smoke UV
	// tricks in the fallback path — full quad, clean edges.
	const bool bIsArt = (Sprite == FogLogoTexture || Sprite == FogTitleTexture);
	const float X = CX - SizeW * 0.5f;
	const float Y = CY - SizeH * 0.5f;
	if (bFogFXUseMaterial && FogFXMIDs.IsValidIndex(MIDIndex) && FogFXMIDs[MIDIndex])
	{
		UMaterialInstanceDynamic* M = FogFXMIDs[MIDIndex];
		M->SetTextureParameterValue(TEXT("SpriteTex"), Sprite);
		M->SetTextureParameterValue(TEXT("NoiseTex"), FogNoiseTexture);
		M->SetScalarParameterValue(TEXT("Warp"), Warp);
		M->SetScalarParameterValue(TEXT("Diss"), Diss);
		M->SetScalarParameterValue(TEXT("AlphaMul"), Alpha);
		M->SetScalarParameterValue(TEXT("Seed"), Seed);
		M->SetVectorParameterValue(TEXT("Tint"), Tint);
		DrawMaterial(M, X, Y, SizeW, SizeH, 0.f, 0.f, 1.f, 1.f, 1.f, false, RotDeg, FVector2D(0.5f, 0.5f));
		return;
	}
	// Fallback churn: pan a moving inner UV window so the billow's internal
	// detail drifts instead of reading as a static picture. Dissolve maps to
	// an eased fade (per-billow staggered via FadeLead upstream).
	const float Ch = GetWorld() ? GetWorld()->GetRealTimeSeconds() : 0.f;
	const float U0 = bIsArt ? 0.f : 0.10f + 0.055f * FMath::Sin(Ch * 0.37f + Seed);
	const float V0 = bIsArt ? 0.f : 0.10f + 0.055f * FMath::Sin(Ch * 0.29f + Seed * 1.7f);
	const float UVS = bIsArt ? 1.f : 0.8f;
	const float DissFade = 1.f - FMath::Clamp((Diss + 0.15f) / 1.5f, 0.f, 1.f);
	FLinearColor C = Tint;
	C.A = Alpha * DissFade;
	if (C.A <= 0.003f)
	{
		return;
	}
	DrawTexture(Sprite, X, Y, SizeW, SizeH, U0, V0, UVS, UVS, C, BLEND_Translucent, 1.f, false, RotDeg, FVector2D(0.5f, 0.5f));
}

void ASquadAIMainMenuHUD::DrawFogFX(float ScreenW, float ScreenH, float T)
{
	using namespace SquadAIFogMath;
	const float ClearStart = SquadAIFogInT + SquadAIFogPeakT + SquadAIFogLogoT;

	float Fog;
	if (T < SquadAIFogInT)          { Fog = EaseOutCubic(T / SquadAIFogInT); }
	else if (T < ClearStart)        { Fog = 1.f; }
	else                            { Fog = 1.f - EaseIn16((T - ClearStart) / SquadAIFogOutT); }
	if (Fog <= 0.001f)
	{
		return;
	}
	const bool bClearing = T > ClearStart;
	const float ClearT = bClearing ? FMath::Clamp((T - ClearStart) / SquadAIFogOutT, 0.f, 1.f) : 0.f;
	const float Churn = (GetWorld() ? GetWorld()->GetRealTimeSeconds() : 0.f) * 0.9f;
	const float Base = FMath::Max(ScreenW, ScreenH);
	const float CXc = ScreenW * 0.5f;
	const float CYc = ScreenH * 0.58f;
	const float Grow = EaseOutCubic(T / (SquadAIFogInT * 1.6f));
	const float EndFade = (ClearT > 0.90f) ? (1.f - ClearT) / 0.10f : 1.f;
	const float Rise = EaseIn16(ClearT) * 0.35f + ClearT;

	// --- white/ochre fog billows
	int32 MIDIdx = 0;
	for (const FFogBillow& B : FogWhiteBillows)
	{
		const int32 ThisMID = MIDIdx++;
		const float Lo = FMath::Clamp((Grow - B.Delay) / (1.f - B.Delay * 0.7f), 0.f, 1.f);
		if (Lo <= 0.f) continue;
		const float G = EaseOutCubic(Lo);
		const float Scl = (B.S0 + (B.S1 - B.S0) * G) * Base * 0.62f * (1.f + ClearT * 0.35f);
		const float DX = FMath::Cos(B.Ang) * B.Dist * Base * G + B.DriftX * Base * ClearT;
		const float DY = FMath::Sin(B.Ang) * B.Dist * Base * 0.8f * G + B.DriftY * Base * Rise;
		float Alpha, Diss;
		if (bClearing)
		{
			Alpha = EndFade;
			Diss = -0.15f + EaseIn16(FMath::Min(ClearT * (1.f + B.FadeLead) * 0.92f, 1.f)) * 1.5f;
		}
		else { Alpha = FMath::Min(Lo * 2.2f, 1.f); Diss = -0.15f; }
		DrawFogBillowQuad(ThisMID, FogPuffTextures[B.TexIdx], CXc + DX, CYc + DY, Scl, Scl,
			FMath::RadiansToDegrees(B.Rot + B.RotV * Churn),
			0.045f + G * 0.055f + ClearT * 0.10f, Diss, FMath::Min(Alpha, 1.f), B.Seed, B.Tint);
	}

	// --- whiteout wash (orange haze, intro-frame tone)
	const float InP = FMath::Clamp(T / SquadAIFogInT, 0.f, 1.f);
	const float Wash = bClearing ? FMath::Max(0.f, Fog - 0.2f) * 0.5f : FMath::Pow(InP, 4.f) * 0.92f;
	if (Wash > 0.01f)
	{
		FLinearColor WashC = FLinearColor::FromSRGBColor(FColor(238, 172, 112));
		WashC.A = FMath::Min(Wash, 1.f);
		DrawRect(WashC, 0.f, 0.f, ScreenW, ScreenH);
	}

	// --- round dirt motes drifting through the smoke
	if (FogDustDotTexture)
	{
		const float DScale = FMath::Max(1.f, Base / 1080.f);
		for (const FFogDust& D : FogDustMotes)
		{
			const float X = FMath::Frac(D.X0 + D.VX * T + 10.f);
			const float Y = FMath::Frac(D.Y0 + D.VY * T * (1.f + ClearT * 2.2f) + 10.f);
			const float A = D.A0 * (0.6f + 0.4f * FMath::Sin(D.Ph + T * D.Fl)) * FMath::Min(Fog * 1.4f, 1.f);
			if (A <= 0.01f) continue;
			const float S = D.Size * DScale * (1.f + ClearT * 0.4f);
			FLinearColor C = D.Tint;
			C.A = A;
			DrawTexture(FogDustDotTexture, X * ScreenW - S * 0.5f, Y * ScreenH - S * 0.5f, S, S, 0.f, 0.f, 1.f, 1.f, C);
		}
	}

	// --- dark earth core: erupts WITH the blast, carries the logo, lifts late
	const float BT = FMath::Max(0.f, T - 0.10f);
	const float BCY = ScreenH * 0.48f;
	for (const FFogBillow& B : FogBlackBillows)
	{
		const int32 ThisMID = MIDIdx++;
		const float Bl = FMath::Clamp((BT - B.Delay) / 0.8f, 0.f, 1.f);
		if (Bl <= 0.f) continue;
		const float G = EaseOutCubic(Bl);
		const float Scl = (B.S0 + (B.S1 - B.S0) * G) * Base * 0.62f * (1.f + ClearT * 0.35f);
		const float DX = FMath::Cos(B.Ang) * B.Dist * Base * G + B.DriftX * Base * ClearT;
		const float DY = FMath::Sin(B.Ang) * B.Dist * Base * 0.8f * G + B.DriftY * Base * Rise * 1.1f;
		float Alpha, Diss;
		if (bClearing)
		{
			Alpha = EndFade;
			Diss = -0.15f + EaseIn16(FMath::Min(ClearT * (1.f + B.FadeLead) * 1.15f, 1.f)) * 1.5f;
		}
		else { Alpha = FMath::Min(Bl * 2.0f, 1.f) * 0.96f; Diss = -0.15f; }
		DrawFogBillowQuad(ThisMID, FogPuffTextures[B.TexIdx], CXc + DX, BCY + DY, Scl, Scl,
			FMath::RadiansToDegrees(B.Rot + B.RotV * Churn),
			0.05f + G * 0.05f + ClearT * 0.10f, Diss, FMath::Min(Alpha, 1.f), B.Seed, B.Tint);
	}

	// --- company logo + game name: start the instant the whiteout hits
	const float LT = FMath::Max(0.f, T - SquadAIFogInT);
	const float InL = FMath::Clamp(LT / 0.55f, 0.f, 1.f);
	const float InT2 = FMath::Clamp((LT - 0.15f) / 0.55f, 0.f, 1.f);
	const float OutL = bClearing ? FMath::Clamp(ClearT / 0.30f, 0.f, 1.f) : 0.f;
	const float AL = EaseOutCubic(InL) * (1.f - OutL);
	const float AT = EaseOutCubic(InT2) * (1.f - OutL);
	const float RiseL = -EaseIn16(ClearT) * 0.22f * Base;
	const float MinDim = FMath::Min(ScreenW, ScreenH);
	if (FogLogoTexture && AL > 0.003f)
	{
		const float S = MinDim * 0.36f * (0.94f + 0.06f * EaseOutCubic(InL));
		DrawFogBillowQuad(MIDIdx, FogLogoTexture, ScreenW * 0.5f, ScreenH * 0.37f + RiseL, S, S,
			0.f, 0.035f * (1.f - InL) + ClearT * 0.05f, 1.1f * (1.f - InL) - 0.15f, AL, 55.5f, FLinearColor::White);
	}
	MIDIdx++;
	if (FogTitleTexture && AT > 0.003f)
	{
		const float TW = MinDim * 0.72f * (0.96f + 0.04f * EaseOutCubic(InT2));
		DrawFogBillowQuad(MIDIdx, FogTitleTexture, ScreenW * 0.5f, ScreenH * 0.645f + RiseL, TW, TW * 0.25f,
			0.f, 0.03f * (1.f - InT2) + ClearT * 0.05f, 1.1f * (1.f - InT2) - 0.15f, AT, 77.7f, FLinearColor::White);
	}
}
// ========================== /S17-FOGFX =====================================

// S16-VID: looping video menu background. Zero-setup convention: drop an
// H.264 MP4 at Content/Movies/MenuBackground.mp4. Player + texture are created
// at runtime — no assets, no widgets, no editor work. File absent -> the
// static image / flag paths behave exactly as before.
void ASquadAIMainMenuHUD::InitBackgroundVideo()
{
	if (CVarSquadAIMenuVideo.GetValueOnGameThread() != 1)
	{
		return;
	}
	const FString SeqAbs   = FPaths::ConvertRelativePathToFull(FPaths::ProjectContentDir() / TEXT("Movies/MenuBackground_Seq"));
	const FString VideoAbs = FPaths::ConvertRelativePathToFull(FPaths::ProjectContentDir() / TEXT("Movies/MenuBackground.mp4"));
	const bool bSeqWanted  = (CVarSquadAIMenuImgSeq.GetValueOnGameThread() == 1);
	const bool bHasSeq     = IFileManager::Get().DirectoryExists(*SeqAbs);
	if (!FPaths::FileExists(VideoAbs) && !(bSeqWanted && bHasSeq))
	{
		UE_LOG(LogTemp, Log, TEXT("[SquadAIMenu] S16-VID: no video at %s and no image sequence at %s — static menu background."), *VideoAbs, *SeqAbs);
		return;
	}
	BackgroundVideoPlayer = NewObject<UMediaPlayer>(this, TEXT("SquadAIMenuVideoPlayer"));
	BackgroundVideoTexture = NewObject<UMediaTexture>(this, TEXT("SquadAIMenuVideoTexture"));
	if (!BackgroundVideoPlayer || !BackgroundVideoTexture)
	{
		BackgroundVideoPlayer = nullptr;
		BackgroundVideoTexture = nullptr;
		return;
	}
	// S18-VIDFIX: AutoClear blanks the surface whenever the player has no new
	// frame — exactly what happens for the millisecond at the loop wrap, which
	// is what you saw as a flicker. Hold the last frame instead.
	BackgroundVideoTexture->AutoClear = false;
	BackgroundVideoTexture->SetMediaPlayer(BackgroundVideoPlayer);
	BackgroundVideoTexture->UpdateResource();
	BackgroundVideoPlayer->PlayOnOpen = true;
	BackgroundVideoPlayer->SetLooping(true);

	// S19-IMGSEQ: avoid a video-codec stream when an image sequence is present.
	// ImgMedia still decodes each frame and uses its global cache; any failure
	// falls through to the MP4 path below, unchanged.
	if (bSeqWanted && bHasSeq && TryOpenImageSequence(BackgroundVideoPlayer, SeqAbs, 30.f))
	{
		BackgroundVideoPlayerB = nullptr;
		BackgroundVideoTextureB = nullptr;
		return;
	}

	const FString Url = FString(TEXT("file://")) + VideoAbs;
	if (BackgroundVideoPlayer->OpenUrl(Url))
	{
		UE_LOG(LogTemp, Log, TEXT("[SquadAIMenu] S16-VID: menu background video opened (looping): %s"), *VideoAbs);

		// S18-VIDFIX: the S17 A/B handoff is REMOVED. It started the standby
		// player up to 0.35 s before player A finished and swapped the moment
		// the standby had decoded two frames — so the picture cut backwards to
		// the start of the clip while A was still mid-shot. That is the "weird\n		// movement" at every lap. One player with native looping is correct;
		// the original stutter came from the texture being cleared at the wrap,
		// which AutoClear = false below fixes.
		BackgroundVideoPlayerB = nullptr;
		BackgroundVideoTextureB = nullptr;
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("[SquadAIMenu] S16-VID: OpenUrl FAILED for %s — static background kept."), *Url);
		BackgroundVideoPlayer = nullptr;
		BackgroundVideoTexture = nullptr;
	}
}

// S19-PIEMEDIADEFER: only open the background sequence after the intro/fog wipe clears.
void ASquadAIMainMenuHUD::UpdateBackgroundVideoLoop()
{
	// S19-FOGSTUTTER: do NOT run the menu background video while the intro fog
	// wipe is on screen. The wipe draws ~180 canvas quads per frame (billows,
	// motes, logo, title); adding video decode + texture upload to those same
	// frames is what made the clear hitch. The video starts the instant the
	// wipe finishes - which is also the first moment the player can see it.
	if (IsIntroWipeActive())
	{
		return;
	}

	if (bBackgroundVideoInitPending)
	{
		bBackgroundVideoInitPending = false;
		InitBackgroundVideo();
	}
	if (!BackgroundVideoPlayer)
	{
		return;
	}

	const double NowSeconds = FPlatformTime::Seconds();

	// S19-VID: seamless loop. Rewind a moment before the end while the decoder
	// is still running. Hitting end-of-stream is what forces the decoder flush
	// that freezes the picture at the wrap; never reaching it avoids the flush.
	if (CVarSquadAIMenuVideoSeamlessLoop.GetValueOnGameThread() == 1
		&& BackgroundVideoPlayer->IsPlaying())
	{
		const FTimespan Dur = BackgroundVideoPlayer->GetDuration();
		const FTimespan Now = BackgroundVideoPlayer->GetTime();
		if (Dur > FTimespan::Zero() && Now >= FTimespan::Zero())
		{
			const double Total = Dur.GetTotalSeconds();
			const double Trim = FMath::Clamp(static_cast<double>(CVarSquadAIMenuVideoLoopEndTrim.GetValueOnGameThread()), 0.0, Total * 0.25);
			const double Start = FMath::Max(0.0, static_cast<double>(CVarSquadAIMenuVideoLoopStart.GetValueOnGameThread()));
			const double Lead = FMath::Max(0.05, static_cast<double>(CVarSquadAIMenuVideoLoopLead.GetValueOnGameThread()));

			const FTimespan LoopEnd = FTimespan::FromSeconds(Total - Trim);
			const FTimespan LoopStart = FTimespan::FromSeconds(FMath::Min(Start, LoopEnd.GetTotalSeconds()));
			const FTimespan Trigger = LoopEnd - FTimespan::FromSeconds(Lead);

			if (LoopEnd > LoopStart && Now >= Trigger)
			{
				BackgroundVideoPlayer->Seek(LoopStart);

				// S19-VIDLOOP2: arm the seek grace window. Seek() is asynchronous -
				// the player reports "not playing" until the decoder resyncs, and
				// the watchdog below used to read that gap as a stall and fire its
				// own Seek(0)+Play(). Two seeks raced on one decoder, which is why
				// the loop survived a lap or two and then died.
				bVideoSeekInFlight = true;
				VideoSeekStartedAt = NowSeconds;
				bVideoLoopHandoffArmed = false;
				return;
			}
		}
	}

	if (BackgroundVideoPlayer->IsPlaying() || BackgroundVideoPlayer->IsPreparing())
	{
		bVideoSeekInFlight = false;
		bVideoLoopHandoffArmed = false;
		return;
	}

	if (BackgroundVideoPlayer->IsPaused() || BackgroundVideoPlayer->IsClosed())
	{
		return; // intentionally stopped (menu teardown / intro video playing)
	}

	// S19-VIDLOOP2: ignore the not-playing gap created by our own Seek() so the
	// watchdog cannot race it. Once the grace expires and it is still not
	// playing, treat it as a real stall and fall through to the resume below.
	if (bVideoSeekInFlight)
	{
		if (NowSeconds - VideoSeekStartedAt < VideoSeekGraceSeconds)
		{
			return;
		}
		bVideoSeekInFlight = false;
	}

	// S19-VIDLOOP2: the old guard was a STICKY one-shot - it was only cleared
	// while IsPlaying() was true, so once the player stalled in a state where
	// IsPlaying() never came back, the flag stayed armed and the watchdog could
	// NEVER fire again. That is the "plays twice then stops": one or two laps,
	// one stall, then permanent silence. Re-arm on a timer instead, so a real
	// stall is always recoverable no matter how it ends up stuck.
	if (bVideoLoopHandoffArmed
		&& (NowSeconds - VideoResumeAttemptedAt) < VideoResumeRetrySeconds)
	{
		return;
	}

	bVideoLoopHandoffArmed = true;
	VideoResumeAttemptedAt = NowSeconds;
	BackgroundVideoPlayer->SetLooping(true);
	BackgroundVideoPlayer->Seek(FTimespan::Zero());
	BackgroundVideoPlayer->Play();
	UE_LOG(LogTemp, Log, TEXT("[SquadAIMenu] S19-VIDLOOP2: background video stalled - resumed (attempt %d)."), ++VideoResumeCount);
}

void ASquadAIMainMenuHUD::AutoResolveMissingTextures()
{
	// AAA-MW-27: prefer the loose clean PNG over any old imported uasset/material
	// background that may already have tactical square/grid lines baked into it.
	if (UTexture2D* CleanMenuBackground = FSquadAIAssetHelper::LoadTextureSafe(nullptr, TEXT("Textures/Menu_Background_KhuzestanDesertWar.png")))
	{
		BackgroundTexture = CleanMenuBackground;
		BackgroundType = EMenuBackgroundType::StaticImageKenBurns;
		BackgroundMaterial = nullptr;
	}
	else if (!BackgroundTexture)
	{
		BackgroundTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Menu_Background_KhuzestanDesertWar.Menu_Background_KhuzestanDesertWar"), TEXT("Textures/Menu_Background_KhuzestanDesertWar.png"));
	}
	// S16-FLAG2/3/5: waving-flag background — auto-load M_MenuFlagWave when the
	// user has run SquadAI_ImportMenuFlagWave.py. Built from the SAME approved
	// clean key art (AAA-MW-27's baked-grid concern does not apply).
	// GUARD (S16-FLAG3): a stale script build made the material UI-domain, and
	// Canvas DrawMaterial renders UI-domain materials as NOTHING (menu went
	// blank). Only accept Surface-domain builds; otherwise warn and keep the
	// static background.
	if (!FlagWaveBackgroundMaterial && CVarSquadAIMenuFlagWave.GetValueOnGameThread() == 1)
	{
		if (UMaterialInterface* FlagMat = LoadObject<UMaterialInterface>(nullptr, TEXT("/Game/SquadAI/MenuFlagWave/M_MenuFlagWave.M_MenuFlagWave")))
		{
			const UMaterial* FlagBase = FlagMat->GetMaterial();
			const bool bDomainOK = FlagBase && FlagBase->MaterialDomain == EMaterialDomain::MD_Surface;
			// S16-FLAG6: the import script adds scalar param "FlagWaveOK" as its LAST
			// build step. If it is missing, a previous script run crashed midway and
			// left a half-built (black) material — reject those too, keep static bg.
			float FlagWaveOK = 0.f;
			const bool bComplete = FlagMat->GetScalarParameterValue(FMaterialParameterInfo(FName(TEXT("FlagWaveOK"))), FlagWaveOK) && FlagWaveOK > 0.5f;
			if (bDomainOK && bComplete)
			{
				FlagWaveBackgroundMaterial = FlagMat;
				UE_LOG(LogTemp, Log, TEXT("[SquadAIMenu] S16-FLAG5: waving-flag background ACTIVE (M_MenuFlagWave valid + complete). Disable with SquadAI.MenuFlagWave 0."));
			}
			else
			{
				UE_LOG(LogTemp, Warning, TEXT("[SquadAIMenu] S16-FLAG3/6: M_MenuFlagWave rejected (%s). Delete /Game/SquadAI/MenuFlagWave, re-run the NEWEST SquadAI_ImportMenuFlagWave.py, restart."), bDomainOK ? TEXT("incomplete build — an earlier script run crashed midway") : TEXT("wrong material domain — stale script"));
			}
		}
	}
	if (!WatermarkEmblemTexture) WatermarkEmblemTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Military_Watermark_Emblem.UI_Military_Watermark_Emblem"), TEXT("Textures/UI_Military_Watermark_Emblem.png"));
	if (!ProgressionArtTexture) ProgressionArtTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Player_Progression_Art.UI_Player_Progression_Art"), TEXT("Textures/UI_Player_Progression_Art.png"));
	if (!ProgressionLeadershipTexture) ProgressionLeadershipTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Progression_Leadership.UI_Progression_Leadership"), TEXT("Textures/UI_Progression_Leadership.png"));
	if (!ProgressionMarksmanshipTexture) ProgressionMarksmanshipTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Progression_Marksmanship.UI_Progression_Marksmanship"), TEXT("Textures/UI_Progression_Marksmanship.png"));
	if (!ProgressionEnduranceTexture) ProgressionEnduranceTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Progression_Endurance.UI_Progression_Endurance"), TEXT("Textures/UI_Progression_Endurance.png"));
	if (!ProgressionTacticsTexture) ProgressionTacticsTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Progression_Tactics.UI_Progression_Tactics"), TEXT("Textures/UI_Progression_Tactics.png"));
	if (!ProgressionEngineeringTexture) ProgressionEngineeringTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Progression_Engineering.UI_Progression_Engineering"), TEXT("Textures/UI_Progression_Engineering.png"));
	if (!ProgressionUpgradeBarTexture) ProgressionUpgradeBarTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Progression_UpgradeBar.UI_Progression_UpgradeBar"), TEXT("Textures/UI_Progression_UpgradeBar.png"));

	if (!BackgroundMedalsTexture) BackgroundMedalsTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Background_Medals.UI_Background_Medals"), TEXT("Textures/UI_Background_Medals.png"));
	if (!BackgroundProgressionTexture) BackgroundProgressionTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Background_Progression.UI_Background_Progression"), TEXT("Textures/UI_Background_Progression.png"));
	if (!BackgroundArmoryTexture) BackgroundArmoryTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Background_Armory.UI_Background_Armory"), TEXT("Textures/UI_Background_Armory.png"));

	if (!DiffRecruitTexture) DiffRecruitTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Diff_Recruit.UI_Diff_Recruit"), TEXT("Textures/UI_Diff_Recruit.png"));
	if (!DiffRegularTexture) DiffRegularTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Diff_Regular.UI_Diff_Regular"), TEXT("Textures/UI_Diff_Regular.png"));
	if (!DiffHardenedTexture) DiffHardenedTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Diff_Hardened.UI_Diff_Hardened"), TEXT("Textures/UI_Diff_Hardened.png"));
	if (!DiffLethalTexture) DiffLethalTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Diff_Lethal.UI_Diff_Lethal"), TEXT("Textures/UI_Diff_Lethal.png"));

	if (!FrameTacticalGoldTexture) FrameTacticalGoldTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Frame_TacticalBorder_Gold.UI_Frame_TacticalBorder_Gold"), TEXT("Textures/UI_Frame_TacticalBorder_Gold.png"));
	if (!FrameTacticalCrimsonTexture) FrameTacticalCrimsonTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Frame_TacticalBorder_Crimson.UI_Frame_TacticalBorder_Crimson"), TEXT("Textures/UI_Frame_TacticalBorder_Crimson.png"));
	if (!FrameBadgeHexagonTexture) FrameBadgeHexagonTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Frame_Badge_Hexagon.UI_Frame_Badge_Hexagon"), TEXT("Textures/UI_Frame_Badge_Hexagon.png"));
	if (!FrameMedalSocketTexture) FrameMedalSocketTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Frame_MedalSocket.UI_Frame_MedalSocket"), TEXT("Textures/UI_Frame_MedalSocket.png")); // MEGA-11: separate socket
	if (!FrameAvatarPortraitTexture) FrameAvatarPortraitTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Frame_Avatar_Portrait.UI_Frame_Avatar_Portrait"), TEXT("Textures/UI_Frame_Avatar_Portrait.png"));
	if (!FrameMapTheaterTexture) FrameMapTheaterTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Frame_MapTheater.UI_Frame_MapTheater"), TEXT("Textures/UI_Frame_MapTheater.png"));

	if (!AvatarRostamiTexture) AvatarRostamiTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Avatar_ShahidRostami.UI_Avatar_ShahidRostami"), TEXT("Textures/UI_Avatar_ShahidRostami.png"));
	if (!AvatarYoungBasijiTexture) AvatarYoungBasijiTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Avatar_YoungBasiji.UI_Avatar_YoungBasiji"), TEXT("Textures/UI_Avatar_YoungBasiji.png"));
	if (!AvatarArteshParatrooperTexture) AvatarArteshParatrooperTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Avatar_ArteshParatrooper.UI_Avatar_ArteshParatrooper"), TEXT("Textures/UI_Avatar_ArteshParatrooper.png"));
	if (!AvatarGuerrillaHunterTexture) AvatarGuerrillaHunterTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Avatar_GuerrillaHunter.UI_Avatar_GuerrillaHunter"), TEXT("Textures/UI_Avatar_GuerrillaHunter.png"));

	if (!TraitTankDestroyerTexture) TraitTankDestroyerTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Trait_TankDestroyer.UI_Trait_TankDestroyer"), TEXT("Textures/UI_Trait_TankDestroyer.png"));
	if (!TraitHeavyCaliberTexture) TraitHeavyCaliberTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Trait_HeavyCaliber.UI_Trait_HeavyCaliber"), TEXT("Textures/UI_Trait_HeavyCaliber.png"));
	if (!TraitDesertReliabilityTexture) TraitDesertReliabilityTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Trait_DesertReliability.UI_Trait_DesertReliability"), TEXT("Textures/UI_Trait_DesertReliability.png"));
	if (!TraitAreaSuppressionTexture) TraitAreaSuppressionTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Trait_AreaSuppression.UI_Trait_AreaSuppression"), TEXT("Textures/UI_Trait_AreaSuppression.png"));
	if (!TraitSilentMarksmanTexture) TraitSilentMarksmanTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Trait_SilentMarksman.UI_Trait_SilentMarksman"), TEXT("Textures/UI_Trait_SilentMarksman.png"));

	if (!MapPreviewDehlaviehTexture) MapPreviewDehlaviehTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Map_Preview_Dehlavieh_Karkheh.Map_Preview_Dehlavieh_Karkheh"), TEXT("Textures/Map_Preview_Dehlavieh_Karkheh.png"));
	if (!MapPreviewBostanTexture) MapPreviewBostanTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Map_Preview_Bostan_Chazzabeh.Map_Preview_Bostan_Chazzabeh"), TEXT("Textures/Map_Preview_Bostan_Chazzabeh.png"));
	if (!MapPreviewKhorramshahrTexture) MapPreviewKhorramshahrTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Map_Preview_Khorramshahr_Arvand.Map_Preview_Khorramshahr_Arvand"), TEXT("Textures/Map_Preview_Khorramshahr_Arvand.png"));

	if (!WeaponPreviewG3A3Texture) WeaponPreviewG3A3Texture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Weapon_Preview_G3A3.Weapon_Preview_G3A3"), TEXT("Textures/Weapon_Preview_G3A3.png"));
	if (!WeaponPreviewAK47Texture) WeaponPreviewAK47Texture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Weapon_Preview_AK47.Weapon_Preview_AK47"), TEXT("Textures/Weapon_Preview_AK47.png"));
	if (!WeaponPreviewRPG7Texture) WeaponPreviewRPG7Texture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Weapon_Preview_RPG7.Weapon_Preview_RPG7"), TEXT("Textures/Weapon_Preview_RPG7.png"));
	if (!WeaponPreviewMG3Texture) WeaponPreviewMG3Texture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Weapon_Preview_MG3.Weapon_Preview_MG3"), TEXT("Textures/Weapon_Preview_MG3.png"));
	if (!WeaponPreviewSVDTexture) WeaponPreviewSVDTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Weapon_Preview_SVD.Weapon_Preview_SVD"), TEXT("Textures/Weapon_Preview_SVD.png"));

	if (!ButtonNormalTexture) ButtonNormalTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Button_Tactical_Normal.UI_Button_Tactical_Normal"), TEXT("Textures/UI_Button_Tactical_Normal.png"));
	if (!ButtonHoverTexture) ButtonHoverTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Button_Tactical_Hover.UI_Button_Tactical_Hover"), TEXT("Textures/UI_Button_Tactical_Hover.png"));
	if (!LoadingBarFrameTexture) LoadingBarFrameTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_LoadingBar_Frame.UI_LoadingBar_Frame"), TEXT("Textures/UI_LoadingBar_Frame.png"));
	if (!LoadingBarFillTexture) LoadingBarFillTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_LoadingBar_Fill.UI_LoadingBar_Fill"), TEXT("Textures/UI_LoadingBar_Fill.png"));
	if (!PauseCardTexture) PauseCardTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Frame_Tactical_PauseCard.UI_Frame_Tactical_PauseCard"), TEXT("Textures/UI_Frame_Tactical_PauseCard.png"));

	// AAA-MW-6: high-fidelity PNG menu icons plus real Niagara menu dust resolution.
	if (!MenuIconStartTexture) MenuIconStartTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_MenuIcon_Start.UI_MenuIcon_Start"), TEXT("Textures/UI_MenuIcon_Start.png"));
	if (!MenuIconOperationsTexture) MenuIconOperationsTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_MenuIcon_Operations.UI_MenuIcon_Operations"), TEXT("Textures/UI_MenuIcon_Operations.png"));
	if (!MenuIconArmoryTexture) MenuIconArmoryTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_MenuIcon_Armory.UI_MenuIcon_Armory"), TEXT("Textures/UI_MenuIcon_Armory.png"));
	if (!MenuIconProgressionTexture) MenuIconProgressionTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_MenuIcon_Progression.UI_MenuIcon_Progression"), TEXT("Textures/UI_MenuIcon_Progression.png"));
	if (!MenuIconProfileTexture) MenuIconProfileTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_MenuIcon_Profile.UI_MenuIcon_Profile"), TEXT("Textures/UI_MenuIcon_Profile.png"));
	if (!MenuIconRecordsTexture) MenuIconRecordsTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_MenuIcon_Records.UI_MenuIcon_Records"), TEXT("Textures/UI_MenuIcon_Records.png"));
	if (!MenuIconSettingsTexture) MenuIconSettingsTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_MenuIcon_Settings.UI_MenuIcon_Settings"), TEXT("Textures/UI_MenuIcon_Settings.png"));
	if (!MenuIconExitTexture) MenuIconExitTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_MenuIcon_Exit.UI_MenuIcon_Exit"), TEXT("Textures/UI_MenuIcon_Exit.png"));
	if (!RailIconSquadTexture) RailIconSquadTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_MenuIcon_RailSquad.UI_MenuIcon_RailSquad"), TEXT("Textures/UI_MenuIcon_RailSquad.png"));
	if (!RailIconMessagesTexture) RailIconMessagesTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_MenuIcon_RailMessages.UI_MenuIcon_RailMessages"), TEXT("Textures/UI_MenuIcon_RailMessages.png"));
	if (!RailIconLoadTexture) RailIconLoadTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_MenuIcon_RailLoad.UI_MenuIcon_RailLoad"), TEXT("Textures/UI_MenuIcon_RailLoad.png"));
	if (!RailIconRelicTexture) RailIconRelicTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_MenuIcon_RailRelic.UI_MenuIcon_RailRelic"), TEXT("Textures/UI_MenuIcon_RailRelic.png"));
	if (!RailIconSettingsTexture) RailIconSettingsTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_MenuIcon_RailSettings.UI_MenuIcon_RailSettings"), TEXT("Textures/UI_MenuIcon_RailSettings.png"));
	if (!RailIconPowerTexture) RailIconPowerTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_MenuIcon_RailPower.UI_MenuIcon_RailPower"), TEXT("Textures/UI_MenuIcon_RailPower.png"));
	if (!StatIconLevelTexture) StatIconLevelTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_StatIcon_Level.UI_StatIcon_Level"), TEXT("Textures/UI_StatIcon_Level.png"));
	if (!StatIconOperationsTexture) StatIconOperationsTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_StatIcon_Operations.UI_StatIcon_Operations"), TEXT("Textures/UI_StatIcon_Operations.png"));
	if (!StatIconAccuracyTexture) StatIconAccuracyTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_StatIcon_Accuracy.UI_StatIcon_Accuracy"), TEXT("Textures/UI_StatIcon_Accuracy.png"));
	if (!StatIconHoursTexture) StatIconHoursTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_StatIcon_Hours.UI_StatIcon_Hours"), TEXT("Textures/UI_StatIcon_Hours.png"));
	if (!StatIconXPTexture) StatIconXPTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_StatIcon_XP.UI_StatIcon_XP"), TEXT("Textures/UI_StatIcon_XP.png"));
	if (!MenuSoftDustTexture) MenuSoftDustTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Menu_DustSoft.UI_Menu_DustSoft"), TEXT("Textures/UI_Menu_DustSoft.png"));
	if (!MenuSoftEmberTexture) MenuSoftEmberTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Menu_EmberSoft.UI_Menu_EmberSoft"), TEXT("Textures/UI_Menu_EmberSoft.png"));
	if (!MenuDustHazeBandTexture) MenuDustHazeBandTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Menu_DustHazeBand.UI_Menu_DustHazeBand"), TEXT("Textures/UI_Menu_DustHazeBand.png"));
	if (!MenuTopBlackGradientTexture) MenuTopBlackGradientTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Menu_BlackGradientTop.UI_Menu_BlackGradientTop"), TEXT("Textures/UI_Menu_BlackGradientTop.png"));
	if (!MenuBottomBlackGradientTexture) MenuBottomBlackGradientTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Menu_BlackGradientBottom.UI_Menu_BlackGradientBottom"), TEXT("Textures/UI_Menu_BlackGradientBottom.png"));
	if (!MenuQuickStartPlateTexture) MenuQuickStartPlateTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Menu_QuickStartPlate.UI_Menu_QuickStartPlate"), TEXT("Textures/UI_Menu_QuickStartPlate.png"));
	if (!MenuPanel3DPlateTexture) MenuPanel3DPlateTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Menu_Panel3DPlate.UI_Menu_Panel3DPlate"), TEXT("Textures/UI_Menu_Panel3DPlate.png"));
	if (!MenuLeftButtonPlateTexture) MenuLeftButtonPlateTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Menu_LeftButtonPlate.UI_Menu_LeftButtonPlate"), TEXT("Textures/UI_Menu_LeftButtonPlate.png"));
	if (!MenuLeftButtonHoverPlateTexture) MenuLeftButtonHoverPlateTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Menu_LeftButtonHoverPlate.UI_Menu_LeftButtonHoverPlate"), TEXT("Textures/UI_Menu_LeftButtonHoverPlate.png"));
	if (!MenuLeftHoverGlowTexture) MenuLeftHoverGlowTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Menu_LeftHoverGlow.UI_Menu_LeftHoverGlow"), TEXT("Textures/UI_Menu_LeftHoverGlow.png"));
	AutoResolveMenuDustNiagara();
}

// S19-PIEMEDIADEFER: the background reader opens only after the intro/fog wipe.
void ASquadAIMainMenuHUD::BeginPlay()
{
	Super::BeginPlay();

	// B6-21: was forced-Farsi in the ctor. Now honors the saved language (the B6-4
	// settings toggle persists via the settings slot).
	FString SavedLang = TEXT("fa");
	if (USquadAISaveLoadSubsystem* SaveSys = USquadAISaveLoadSubsystem::Get(this))
	{
		// P6-1: cache the FULL settings struct at boot. CachedMenuSettings was previously
		// filled only when the Settings screen opened (NavigateToState), so every
		// bMenuEnglish-driven panel and the quality readout sampled the default-constructed
		// cache (fa / preset 3) until then — English saves booted as a mixed-language menu
		// with a wrong "Epic" quality display.
		CachedMenuSettings = SaveSys->LoadSettings();
		SavedLang = CachedMenuSettings.LanguageCode;
	}
	if (SavedLang.StartsWith(TEXT("ar"), ESearchCase::IgnoreCase))
	{
		ApplyArabicPreset();
	}
	else if (SavedLang.StartsWith(TEXT("en"), ESearchCase::IgnoreCase))
	{
		ApplyEnglishPreset();
	}
	else
	{
		ApplyPersianFarsiPreset();
	}
	AutoResolveMissingTextures();
	bBackgroundVideoInitPending = true;
	InitIntroVideo(); // S16-INTRO
	InitFogFX(); // S17-FOGFX

	// AAA-MW-7: avoid blurry fullscreen/menu presentation from dynamic resolution or
	// low screen-percentage defaults. This is especially important for Canvas text,
	// PNG icons, the static background and world-space Niagara dust behind it.
	UKismetSystemLibrary::ExecuteConsoleCommand(this, TEXT("sg.ResolutionQuality 100"));
	UKismetSystemLibrary::ExecuteConsoleCommand(this, TEXT("r.DynamicRes.OperationMode 0"));
	UKismetSystemLibrary::ExecuteConsoleCommand(this, TEXT("r.ScreenPercentage 100"));
	UKismetSystemLibrary::ExecuteConsoleCommand(this, TEXT("r.SecondaryScreenPercentage.GameViewport 100"));
	UKismetSystemLibrary::ExecuteConsoleCommand(this, TEXT("r.Upscale.Quality 5"));
	UKismetSystemLibrary::ExecuteConsoleCommand(this, TEXT("r.Tonemapper.Sharpen 0.45"));

	// P1-L2: central language-changed subscription (settings-driven changes re-skin live).
	if (USquadAILocalizationSubsystem* Loc = USquadAILocalizationSubsystem::Get(this))
	{
		LanguageChangedHandle = Loc->OnLanguageChangedNative.AddUObject(this, &ASquadAIMainMenuHUD::OnLanguageChanged);
	}

	if (APlayerController* PC = GetOwningPlayerController())
	{
		PC->bShowMouseCursor = true;
		PC->bEnableClickEvents = true;
		PC->bEnableMouseOverEvents = true;

		FInputModeGameAndUI InputMode;
		InputMode.SetLockMouseToViewportBehavior(EMouseLockMode::DoNotLock);
		InputMode.SetHideCursorDuringCapture(false);
		PC->SetInputMode(InputMode);
	}

	SandParticles.Empty();
	for (int32 i = 0; i < 135; ++i) // AAA-MW-4: denser but much smaller reference-colored dust motes.
	{
		FSquadMenuParticle P;
		P.Position = FVector2D(FMath::RandRange(0.f, 1920.f), FMath::RandRange(0.f, 1080.f));
		P.Velocity = FVector2D(FMath::RandRange(15.f, 55.f), FMath::RandRange(-10.f, 10.f));
		P.Size = FMath::RandRange(0.8f, 2.2f);
		P.Alpha = FMath::RandRange(0.10f, 0.32f);
		P.LifeTime = FMath::RandRange(0.f, 3.0f);
		P.MaxLifeTime = FMath::RandRange(2.5f, 5.0f);
		P.Color = FLinearColor(FMath::RandRange(0.72f, 0.86f), FMath::RandRange(0.58f, 0.70f), FMath::RandRange(0.38f, 0.48f), 1.0f);
		SandParticles.Add(P);
	}

	// AAA-MW-24: same soft dust style, much denser across the screen; no lines or scratches.
	GroundDust.Empty();
	for (int32 i = 0; i < 920; ++i)
	{
		FSquadMenuParticle P;
		P.Position = FVector2D(FMath::RandRange(-120.f, 2040.f), FMath::RandRange(120.f, 1120.f));
		P.Velocity = FVector2D(FMath::RandRange(5.f, 24.f), FMath::RandRange(-7.f, 8.f));
		P.Size = FMath::RandRange(1.6f, 5.8f);
		P.Alpha = FMath::RandRange(0.070f, 0.240f);
		P.LifeTime = FMath::RandRange(0.f, 5.0f);
		P.MaxLifeTime = FMath::RandRange(9.0f, 18.0f);
		P.Color = FLinearColor(FMath::RandRange(0.70f, 0.90f), FMath::RandRange(0.58f, 0.74f), FMath::RandRange(0.40f, 0.54f), 1.0f);
		GroundDust.Add(P);
	}

	// MEGA-7: ember sparks rising off the bottom edge (distant-fire glow feel).
	EmberSparks.Empty();
	for (int32 i = 0; i < 118; ++i)
	{
		FSquadMenuParticle P;
		P.Position = FVector2D(FMath::RandRange(120.f, 1820.f), FMath::RandRange(260.f, 1090.f));
		P.Velocity = FVector2D(FMath::RandRange(-8.f, 16.f), FMath::RandRange(12.f, 38.f));
		P.Size = FMath::RandRange(1.0f, 2.7f);
		P.Alpha = FMath::RandRange(0.12f, 0.32f);
		P.LifeTime = FMath::RandRange(0.f, 3.0f);
		P.MaxLifeTime = FMath::RandRange(5.0f, 11.0f);
		P.Color = FLinearColor(0.92f, 0.62f, 0.25f, 1.0f);
		EmberSparks.Add(P);
	}
}

void ASquadAIMainMenuHUD::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	ReleaseIntroVideo(); // S19-STUTTER: never leak a media player if we go away mid-wipe
	if (USquadAILocalizationSubsystem* Loc = USquadAILocalizationSubsystem::Get(this))
	{
		Loc->OnLanguageChangedNative.Remove(LanguageChangedHandle);
	}
	Super::EndPlay(EndPlayReason);
}

void ASquadAIMainMenuHUD::OnLanguageChanged(const FString& NewLang)
{
	if (NewLang.Equals(TEXT("en"), ESearchCase::IgnoreCase)) { ApplyEnglishPreset(); }
	else if (NewLang.StartsWith(TEXT("ar"), ESearchCase::IgnoreCase)) { ApplyArabicPreset(); }
	else { ApplyPersianFarsiPreset(); }
}

void ASquadAIMainMenuHUD::ApplyPersianFarsiPreset()
{
	if (USquadAILocalizationSubsystem* LocSys = USquadAILocalizationSubsystem::Get(this))
	{
		LocSys->SetCurrentLanguage(TEXT("fa"));
		MenuTextConfig.GameTitle = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu"), TEXT("GameTitle"), TEXT("عملیات خوزستان | سرگرد شهید ایرج رستمی")));
		MenuTextConfig.GameSubtitle = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu"), TEXT("GameSubtitle"), TEXT("شوتر تاکتیکی جهان‌باز فرماندهی جوخه — دفاع مقدس (۱۳۵۹)")));
		MenuTextConfig.ButtonNewGame = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu"), TEXT("ButtonNewGame"), TEXT("شروع بازی جدید")));
		MenuTextConfig.ButtonMapSelect = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu"), TEXT("ButtonMapSelect"), TEXT("انتخاب منطقه و نقشه عملیات")));
		MenuTextConfig.ButtonArmory = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu"), TEXT("ButtonArmory"), TEXT("زرادخانه و آزادسازی سلاح‌ها")));
		MenuTextConfig.ButtonProgression = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu"), TEXT("ButtonProgression"), TEXT("ارتقای توانمندی‌ها و سطح رزمنده")));
		MenuTextConfig.ButtonPlayerProfile = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu"), TEXT("ButtonPlayerProfile"), TEXT("پرونده و آمار نبردهای رزمنده")));
		MenuTextConfig.ButtonAchievements = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu"), TEXT("ButtonAchievements"), TEXT("مدال‌ها و دستاوردهای جنگی")));
		MenuTextConfig.ButtonContinue = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu"), TEXT("ButtonContinue"), TEXT("ادامه عملیات")));
		MenuTextConfig.ButtonLoadGame = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu"), TEXT("ButtonLoadGame"), TEXT("بارگذاری ذخیره")));
		MenuTextConfig.ButtonRelicCollection = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu"), TEXT("ButtonRelicCollection"), TEXT("یادگاری‌های همرزمان شهید")));
		MenuTextConfig.ButtonSettings = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu"), TEXT("ButtonSettings"), TEXT("تنظیمات و گرافیک")));
		MenuTextConfig.ButtonBriefing = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu"), TEXT("ButtonBriefing"), TEXT("پرونده اطلاعات عملیاتی")));
		MenuTextConfig.ButtonQuit = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu"), TEXT("ButtonQuit"), TEXT("خروج از بازی")));
		MenuTextConfig.ButtonBack = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu"), TEXT("ButtonBack"), TEXT("← بازگشت")));
		MenuTextConfig.DifficultyTitle = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu"), TEXT("DifficultyTitle"), TEXT("انتخاب سطح دشواری نبرد")));
		MenuTextConfig.DiffRecruit = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu"), TEXT("DiffRecruit"), TEXT("سرباز تازه‌کار (آسان)")));
		MenuTextConfig.DiffRegular = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu"), TEXT("DiffRegular"), TEXT("سرباز رزمنده (متوسط)")));
		MenuTextConfig.DiffHardened = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu"), TEXT("DiffHardened"), TEXT("کهنه‌سرباز (دشوار)")));
		MenuTextConfig.DiffVeteran = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu"), TEXT("DiffVeteran"), TEXT("فرمانده افسانه‌ای (بسیار سنگین)")));
		return;
	}

	MenuTextConfig.GameTitle = FText::FromString(TEXT("عملیات خوزستان | سرگرد شهید ایرج رستمی"));
	MenuTextConfig.GameSubtitle = FText::FromString(TEXT("شوتر تاکتیکی جهان‌باز فرماندهی جوخه — دفاع مقدس (۱۳۵۹)"));
	MenuTextConfig.ButtonNewGame = FText::FromString(TEXT("شروع بازی جدید"));
	MenuTextConfig.ButtonMapSelect = FText::FromString(TEXT("انتخاب منطقه و نقشه عملیات"));
	MenuTextConfig.ButtonArmory = FText::FromString(TEXT("زرادخانه و آزادسازی سلاح‌ها"));
	MenuTextConfig.ButtonProgression = FText::FromString(TEXT("ارتقای توانمندی‌ها و سطح رزمنده"));
	MenuTextConfig.ButtonPlayerProfile = FText::FromString(TEXT("پرونده و آمار نبردهای رزمنده"));
	MenuTextConfig.ButtonAchievements = FText::FromString(TEXT("مدال‌ها و دستاوردهای جنگی"));
	MenuTextConfig.ButtonContinue = FText::FromString(TEXT("ادامه عملیات"));
	MenuTextConfig.ButtonLoadGame = FText::FromString(TEXT("بارگذاری ذخیره"));
	MenuTextConfig.ButtonRelicCollection = FText::FromString(TEXT("یادگاری‌های همرزمان شهید"));
	MenuTextConfig.ButtonSettings = FText::FromString(TEXT("تنظیمات و گرافیک"));
	MenuTextConfig.ButtonBriefing = FText::FromString(TEXT("پرونده اطلاعات عملیاتی"));
	MenuTextConfig.ButtonQuit = FText::FromString(TEXT("خروج از بازی"));
	MenuTextConfig.ButtonBack = FText::FromString(TEXT("← بازگشت"));
	MenuTextConfig.DifficultyTitle = FText::FromString(TEXT("انتخاب سطح دشواری نبرد"));
	MenuTextConfig.DiffRecruit = FText::FromString(TEXT("سرباز تازه‌کار (آسان)"));
	MenuTextConfig.DiffRegular = FText::FromString(TEXT("سرباز رزمنده (متوسط)"));
	MenuTextConfig.DiffHardened = FText::FromString(TEXT("کهنه‌سرباز (دشوار)"));
	MenuTextConfig.DiffVeteran = FText::FromString(TEXT("فرمانده افسانه‌ای (بسیار سنگین)"));
}

void ASquadAIMainMenuHUD::ApplyEnglishPreset()
{
	if (USquadAILocalizationSubsystem* LocSys = USquadAILocalizationSubsystem::Get(this))
	{
		LocSys->SetCurrentLanguage(TEXT("en"));
	}
	MenuTextConfig.GameTitle = FText::FromString(TEXT("OPERATION KHUZESTAN | MAJOR SHAHID ROSTAMI"));
	MenuTextConfig.GameSubtitle = FText::FromString(TEXT("Open-World Tactical Squad Commander — Sacred Defense 1980"));
	MenuTextConfig.ButtonNewGame = FText::FromString(TEXT("START NEW OPERATION"));
	MenuTextConfig.ButtonMapSelect = FText::FromString(TEXT("THEATER & MAP SELECTION"));
	MenuTextConfig.ButtonArmory = FText::FromString(TEXT("ARMORY & WEAPON LOADOUTS"));
	MenuTextConfig.ButtonProgression = FText::FromString(TEXT("SQUAD ATTRIBUTES & LEVEL"));
	MenuTextConfig.ButtonPlayerProfile = FText::FromString(TEXT("SOLDIER DOSSIER & STATS"));
	MenuTextConfig.ButtonAchievements = FText::FromString(TEXT("MEDALS & ACCOMPLISHMENTS"));
	MenuTextConfig.ButtonContinue = FText::FromString(TEXT("CONTINUE MISSION"));
	MenuTextConfig.ButtonLoadGame = FText::FromString(TEXT("LOAD CHECKPOINT"));
	MenuTextConfig.ButtonRelicCollection = FText::FromString(TEXT("RELICS OF FALLEN COMRADES"));
	MenuTextConfig.ButtonSettings = FText::FromString(TEXT("SETTINGS & GRAPHICS"));
	MenuTextConfig.ButtonBriefing = FText::FromString(TEXT("OPERATIONAL SITREP"));
	MenuTextConfig.ButtonQuit = FText::FromString(TEXT("EXIT TO DESKTOP"));
	MenuTextConfig.ButtonBack = FText::FromString(TEXT("← BACK"));
	MenuTextConfig.DifficultyTitle = FText::FromString(TEXT("SELECT COMBAT INTENSITY"));
	MenuTextConfig.DiffRecruit = FText::FromString(TEXT("RECRUIT (CASUAL)"));
	MenuTextConfig.DiffRegular = FText::FromString(TEXT("REGULAR (BALANCED)"));
	MenuTextConfig.DiffHardened = FText::FromString(TEXT("HARDENED (VETERAN)"));
	MenuTextConfig.DiffVeteran = FText::FromString(TEXT("LEGENDARY COMMANDER (REALISTIC)"));
}

void ASquadAIMainMenuHUD::ApplyArabicPreset()
{
	if (USquadAILocalizationSubsystem* LocSys = USquadAILocalizationSubsystem::Get(this))
	{
		LocSys->SetCurrentLanguage(TEXT("ar"));
		// P7-L4: Arabic core menu. INI [MainMenu.ar] overrides win when present; the
		// Arabic defaults below are used for any key the file does not provide.
		MenuTextConfig.GameTitle = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu.ar"), TEXT("GameTitle"), TEXT("الدفاع المقدس: خط النار دهلاوية")));
		MenuTextConfig.GameSubtitle = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu.ar"), TEXT("GameSubtitle"), TEXT("لعبة تكتيكية بعالم مفتوح لقيادة الفصيل — الدفاع المقدس (١٩٨٠)")));
		MenuTextConfig.ButtonNewGame = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu.ar"), TEXT("ButtonNewGame"), TEXT("بدء عملية جديدة")));
		MenuTextConfig.ButtonMapSelect = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu.ar"), TEXT("ButtonMapSelect"), TEXT("اختيار منطقة العمليات")));
		MenuTextConfig.ButtonArmory = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu.ar"), TEXT("ButtonArmory"), TEXT("التسليح وفتح الأسلحة")));
		MenuTextConfig.ButtonProgression = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu.ar"), TEXT("ButtonProgression"), TEXT("ترقية القدرات ومستوى المقاتل")));
		MenuTextConfig.ButtonPlayerProfile = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu.ar"), TEXT("ButtonPlayerProfile"), TEXT("السجل القتالي وإحصاءات المقاتل")));
		MenuTextConfig.ButtonAchievements = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu.ar"), TEXT("ButtonAchievements"), TEXT("الأوسمة والإنجازات الحربية")));
		MenuTextConfig.ButtonContinue = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu.ar"), TEXT("ButtonContinue"), TEXT("متابعة العملية")));
		MenuTextConfig.ButtonLoadGame = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu.ar"), TEXT("ButtonLoadGame"), TEXT("تحميل حفظ")));
		MenuTextConfig.ButtonRelicCollection = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu.ar"), TEXT("ButtonRelicCollection"), TEXT("تذكارات الرفاق الشهداء")));
		MenuTextConfig.ButtonSettings = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu.ar"), TEXT("ButtonSettings"), TEXT("الإعدادات والرسومات")));
		MenuTextConfig.ButtonBriefing = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu.ar"), TEXT("ButtonBriefing"), TEXT("ملف المعلومات العملياتي")));
		MenuTextConfig.ButtonQuit = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu.ar"), TEXT("ButtonQuit"), TEXT("الخروج من اللعبة")));
		MenuTextConfig.ButtonBack = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu.ar"), TEXT("ButtonBack"), TEXT("← رجوع")));
		MenuTextConfig.DifficultyTitle = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu.ar"), TEXT("DifficultyTitle"), TEXT("اختيار مستوى صعوبة المعركة")));
		MenuTextConfig.DiffRecruit = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu.ar"), TEXT("DiffRecruit"), TEXT("مجند جديد (سهل)")));
		MenuTextConfig.DiffRegular = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu.ar"), TEXT("DiffRegular"), TEXT("مقاتل (متوسط)")));
		MenuTextConfig.DiffHardened = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu.ar"), TEXT("DiffHardened"), TEXT("محارب قديم (صعب)")));
		MenuTextConfig.DiffVeteran = FText::FromString(LocSys->GetLocalizedText(TEXT("MainMenu.ar"), TEXT("DiffVeteran"), TEXT("قائد أسطوري (قاسٍ جداً)")));
		return;
	}

	MenuTextConfig.GameTitle = FText::FromString(TEXT("الدفاع المقدس: خط النار دهلاوية"));
	MenuTextConfig.GameSubtitle = FText::FromString(TEXT("لعبة تكتيكية بعالم مفتوح لقيادة الفصيل — الدفاع المقدس (١٩٨٠)"));
	MenuTextConfig.ButtonNewGame = FText::FromString(TEXT("بدء عملية جديدة"));
	MenuTextConfig.ButtonMapSelect = FText::FromString(TEXT("اختيار منطقة العمليات"));
	MenuTextConfig.ButtonArmory = FText::FromString(TEXT("التسليح وفتح الأسلحة"));
	MenuTextConfig.ButtonProgression = FText::FromString(TEXT("ترقية القدرات ومستوى المقاتل"));
	MenuTextConfig.ButtonPlayerProfile = FText::FromString(TEXT("السجل القتالي وإحصاءات المقاتل"));
	MenuTextConfig.ButtonAchievements = FText::FromString(TEXT("الأوسمة والإنجازات الحربية"));
	MenuTextConfig.ButtonContinue = FText::FromString(TEXT("متابعة العملية"));
	MenuTextConfig.ButtonLoadGame = FText::FromString(TEXT("تحميل حفظ"));
	MenuTextConfig.ButtonRelicCollection = FText::FromString(TEXT("تذكارات الرفاق الشهداء"));
	MenuTextConfig.ButtonSettings = FText::FromString(TEXT("الإعدادات والرسومات"));
	MenuTextConfig.ButtonBriefing = FText::FromString(TEXT("ملف المعلومات العملياتي"));
	MenuTextConfig.ButtonQuit = FText::FromString(TEXT("الخروج من اللعبة"));
	MenuTextConfig.ButtonBack = FText::FromString(TEXT("← رجوع"));
	MenuTextConfig.DifficultyTitle = FText::FromString(TEXT("اختيار مستوى صعوبة المعركة"));
	MenuTextConfig.DiffRecruit = FText::FromString(TEXT("مجند جديد (سهل)"));
	MenuTextConfig.DiffRegular = FText::FromString(TEXT("مقاتل (متوسط)"));
	MenuTextConfig.DiffHardened = FText::FromString(TEXT("محارب قديم (صعب)"));
	MenuTextConfig.DiffVeteran = FText::FromString(TEXT("قائد أسطوري (قاسٍ جداً)"));
}

void ASquadAIMainMenuHUD::ApplyThemeColors()
{
	switch (ColorTheme)
	{
	case EMenuColorTheme::DesertKhakiGold:
		PrimaryAccentColor = FLinearColor(0.48f, 0.72f, 0.68f, 1.0f);
		SecondaryAccentColor = FLinearColor(0.85f, 0.22f, 0.15f, 1.0f);
		PanelBgColor = FLinearColor(0.04f, 0.05f, 0.07f, 0.94f);
		break;
	case EMenuColorTheme::TacticalForestGreen:
		PrimaryAccentColor = FLinearColor(0.35f, 0.90f, 0.45f, 1.0f);
		SecondaryAccentColor = FLinearColor(0.80f, 0.65f, 0.20f, 1.0f);
		PanelBgColor = FLinearColor(0.03f, 0.06f, 0.04f, 0.94f);
		break;
	case EMenuColorTheme::NightOpsBlue:
		PrimaryAccentColor = FLinearColor(0.25f, 0.80f, 1.0f, 1.0f);
		SecondaryAccentColor = FLinearColor(0.95f, 0.75f, 0.25f, 1.0f);
		PanelBgColor = FLinearColor(0.03f, 0.04f, 0.08f, 0.94f);
		break;
	case EMenuColorTheme::RedAlertCrimson:
		PrimaryAccentColor = FLinearColor(1.0f, 0.25f, 0.25f, 1.0f);
		SecondaryAccentColor = FLinearColor(1.0f, 0.85f, 0.30f, 1.0f);
		PanelBgColor = FLinearColor(0.06f, 0.03f, 0.03f, 0.94f);
		break;
	}
}

void ASquadAIMainMenuHUD::NavigateToState(EMainMenuState NewState)
{
	if (MenuState == NewState) return;

	MenuState = NewState;
	IntroCascadeTimer = 0.0f;
	SubmenuSlideOffset = 40.0f;
	TargetSubmenuSlideOffset = 0.0f;

	// B6-4: refresh the settings working copy when the screen opens.
	if (MenuState == EMainMenuState::Settings)
	{
		if (USquadAISaveLoadSubsystem* SaveSys = USquadAISaveLoadSubsystem::Get(this))
		{
			CachedMenuSettings = SaveSys->LoadSettings();
		}
	}

	if (MenuState == EMainMenuState::Armory)
	{
		SelectedWeaponIndex = 0;
	}
	else if (MenuState == EMainMenuState::MapSelect)
	{
		SelectedMapIndex = 0;
	}
}

void ASquadAIMainMenuHUD::UpdateAnimations(float DeltaTime)
{
	MasterTime += DeltaTime;
	KenBurnsTimer += DeltaTime;
	IntroCascadeTimer += DeltaTime;

	SubmenuSlideOffset = FMath::FInterpTo(SubmenuSlideOffset, TargetSubmenuSlideOffset, DeltaTime, 12.0f);
	CompassRotation = FMath::Fmod(CompassRotation + DeltaTime * 6.0f, 360.0f);
	ChevronHoverSlide = 4.0f * FMath::Sin(MasterTime * 6.0f);
	LastFrameDelta = DeltaTime; // MEGA-8
}

void ASquadAIMainMenuHUD::UpdateSandParticles(float DeltaTime, float ScreenW, float ScreenH)
{
	if (bReducedMenuMotion) return; // MEGA-7: frozen tableau.
	for (auto& P : SandParticles)
	{
		P.LifeTime += DeltaTime;
		P.Position += P.Velocity * DeltaTime;

		if (P.Position.X > ScreenW + 20.f || P.Position.Y < -20.f || P.Position.Y > ScreenH + 20.f || P.LifeTime >= P.MaxLifeTime)
		{
			P.Position = FVector2D(FMath::RandRange(-20.f, 100.f), FMath::RandRange(0.f, ScreenH));
			P.Velocity = FVector2D(FMath::RandRange(20.f, 65.f), FMath::RandRange(-8.f, 8.f));
			P.LifeTime = 0.0f;
			P.MaxLifeTime = FMath::RandRange(2.5f, 5.0f);
		}
	}
}

void ASquadAIMainMenuHUD::DrawSandParticles()
{
	if (!Canvas || bReducedMenuMotion || MenuState != EMainMenuState::Main) return;
	if (!MenuSoftDustTexture)
	{
		// AAA-MW-30: no Canvas square/dot fallback. If the PNG is missing, skip this
		// layer rather than drawing rejected pixel/square artifacts over the background.
		return;
	}

	for (const auto& P : SandParticles)
	{
		const float NormalizedLife = P.LifeTime / FMath::Max(0.01f, P.MaxLifeTime);
		const float FadeAlpha = (NormalizedLife < 0.2f) ? (NormalizedLife / 0.2f) :
										(NormalizedLife > 0.8f) ? ((1.0f - NormalizedLife) / 0.2f) : 1.0f;

		FLinearColor ParticleColor = P.Color;
		ParticleColor.A = FMath::Clamp(P.Alpha * FadeAlpha * 0.42f, 0.f, 0.16f);
		const float Size = FMath::Clamp(P.Size * 9.5f, 10.f, 42.f);
		DrawTexture(MenuSoftDustTexture, P.Position.X - Size * 0.5f, P.Position.Y - Size * 0.5f, Size, Size, 0.f, 0.f, 1.f, 1.f, ParticleColor);
	}
}
void ASquadAIMainMenuHUD::UpdateGroundDustAndEmbers(float DeltaTime, float ScreenW, float ScreenH)
{
	if (bReducedMenuMotion) return; // MEGA-7: frozen tableau.
	const float BandTop = ScreenH * 0.14f;
	for (auto& P : GroundDust)
	{
		P.LifeTime += DeltaTime;
		P.Position += P.Velocity * DeltaTime;
		P.Position.Y += FMath::Sin(MasterTime * 0.55f + P.LifeTime * 0.9f) * 2.0f * DeltaTime; // tiny turbulent lift, never long streaks.
		if (P.Position.X > ScreenW + 70.f || P.Position.Y < BandTop - 60.f || P.Position.Y > ScreenH + 70.f || P.LifeTime >= P.MaxLifeTime)
		{
			P.Position = FVector2D(FMath::RandRange(-120.f, ScreenW + 80.f), FMath::RandRange(BandTop, ScreenH + 35.f));
			P.Velocity = FVector2D(FMath::RandRange(5.f, 24.f), FMath::RandRange(-7.f, 8.f));
			P.LifeTime = 0.f;
			P.MaxLifeTime = FMath::RandRange(9.0f, 18.0f);
			P.Size = FMath::RandRange(1.6f, 5.8f);
			P.Alpha = FMath::RandRange(0.035f, 0.145f);
		}
	}
	for (auto& P : EmberSparks)
	{
		P.LifeTime += DeltaTime;
		P.Position.Y -= P.Velocity.Y * DeltaTime; // rise.
		P.Position.X += (P.Velocity.X + 18.f * FMath::Sin(MasterTime * 2.2f + P.LifeTime * 3.f)) * DeltaTime; // sway.
		if (P.Position.Y < ScreenH * 0.20f || P.Position.X < -80.f || P.Position.X > ScreenW + 80.f || P.LifeTime >= P.MaxLifeTime)
		{
			P.Position = FVector2D(FMath::RandRange(0.f, ScreenW), FMath::RandRange(ScreenH * 0.36f, ScreenH + 20.f));
			P.Velocity = FVector2D(FMath::RandRange(-8.f, 16.f), FMath::RandRange(12.f, 38.f));
			P.LifeTime = 0.f;
			P.MaxLifeTime = FMath::RandRange(5.0f, 11.0f);
			P.Size = FMath::RandRange(1.0f, 2.7f);
			P.Alpha = FMath::RandRange(0.12f, 0.32f);
		}
	}
}

void ASquadAIMainMenuHUD::DrawGroundDustAndEmbers(float ScreenW, float ScreenH)
{
	// AAA-MW-22: soft sprite dust/embers only — no Canvas lines, no square dots.
	// Real Niagara call-ins are still scheduled, but the persistent atmosphere is a
	// slow translucent dust layer behind the menu panels.
	TickMenuNiagaraDust(ScreenW, ScreenH);
	if (!Canvas || MenuState != EMainMenuState::Main)
	{
		return;
	}
	if (MenuDustHazeBandTexture)
	{
		const float Drift = bReducedMenuMotion ? 0.f : FMath::Sin(MasterTime * 0.075f) * 34.f;
		DrawTexture(MenuDustHazeBandTexture, -52.f + Drift, ScreenH * 0.55f, ScreenW + 104.f, ScreenH * 0.36f, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
		DrawTexture(MenuDustHazeBandTexture, -80.f - Drift * 0.55f, ScreenH * 0.68f, ScreenW + 160.f, ScreenH * 0.28f, 0.f, 0.f, 1.f, 1.f, FLinearColor(1.f, 0.92f, 0.78f, 0.62f));
	}
	if (MenuSoftDustTexture)
	{
		for (const FSquadMenuParticle& P : GroundDust)
		{
			const float NormalizedLife = P.LifeTime / FMath::Max(0.01f, P.MaxLifeTime);
			const float Fade = (NormalizedLife < 0.18f) ? (NormalizedLife / 0.18f) : (NormalizedLife > 0.82f ? ((1.0f - NormalizedLife) / 0.18f) : 1.0f);
			const float X = P.Position.X;
			const float Y = P.Position.Y;
			const float Size = FMath::Clamp(P.Size * 15.5f, 18.f, 92.f);
			FLinearColor C = P.Color;
			C.A = FMath::Clamp(P.Alpha * Fade * 1.22f, 0.f, 0.34f);
			DrawTexture(MenuSoftDustTexture, X - Size * 0.5f, Y - Size * 0.5f, Size, Size, 0.f, 0.f, 1.f, 1.f, C);
		}
	}
	if (MenuSoftEmberTexture)
	{
		for (const FSquadMenuParticle& P : EmberSparks)
		{
			const float NormalizedLife = P.LifeTime / FMath::Max(0.01f, P.MaxLifeTime);
			const float Fade = (NormalizedLife < 0.20f) ? (NormalizedLife / 0.20f) : (NormalizedLife > 0.78f ? ((1.0f - NormalizedLife) / 0.22f) : 1.0f);
			const float Size = FMath::Clamp(P.Size * 10.5f, 10.f, 36.f);
			FLinearColor C = P.Color;
			C.A = FMath::Clamp(P.Alpha * Fade * 0.86f, 0.f, 0.34f);
			DrawTexture(MenuSoftEmberTexture, P.Position.X - Size * 0.5f, P.Position.Y - Size * 0.5f, Size, Size, 0.f, 0.f, 1.f, 1.f, C);
		}
	}
}

void ASquadAIMainMenuHUD::DrawGroundFogBands(float ScreenW, float ScreenH)
{
	// AAA-MW-6: disabled fake Canvas fog bands. The bottom atmosphere is handled by
	// real Niagara dust bursts behind the semi-transparent lower background window.
	(void)ScreenW;
	(void)ScreenH;
}


void ASquadAIMainMenuHUD::AutoResolveMenuDustNiagara()
{
	if (MenuDustNiagaraSystem)
	{
		return;
	}

	const TCHAR* CandidatePaths[] =
	{
		TEXT("/Game/NiagaraExamples/FX_Explosions/NS_Dirt_Explosion.NS_Dirt_Explosion"),
		TEXT("/Game/NiagaraExamples/FX_Explosions/NS_Dirt_Explosion"),
		TEXT("/Game/NiagaraExamples/FX_Explosions/NS_Dirt_Explosion_Medium.NS_Dirt_Explosion_Medium"),
		TEXT("/Game/NiagaraExamples/FX_Explosions/NS_Dirt_Explosion_Medium"),
		TEXT("/Game/FX/Niagara/NS_DustExplosion.NS_DustExplosion"),
		TEXT("/Game/FX/Niagara/NS_Dust_Explosion.NS_Dust_Explosion"),
		TEXT("/Game/FX/Niagara/DustExplosion.DustExplosion"),
		TEXT("/Game/VFX/NS_DustExplosion.NS_DustExplosion"),
		TEXT("/Game/VFX/NS_Dust_Explosion.NS_Dust_Explosion"),
		TEXT("/Game/VFX/DustExplosion.DustExplosion"),
		TEXT("/Game/Effects/NS_DustExplosion.NS_DustExplosion"),
		TEXT("/Game/Effects/NS_Dust_Explosion.NS_Dust_Explosion"),
		TEXT("/Game/Effects/DustExplosion.DustExplosion"),
		TEXT("/Game/Niagara/NS_DustExplosion.NS_DustExplosion"),
		TEXT("/Game/Niagara/NS_Dust_Explosion.NS_Dust_Explosion"),
		TEXT("/Game/Niagara/DustExplosion.DustExplosion")
	};

	for (const TCHAR* Path : CandidatePaths)
	{
		if (UNiagaraSystem* Resolved = LoadObject<UNiagaraSystem>(nullptr, Path))
		{
			MenuDustNiagaraSystem = Resolved;
			bLoggedMissingMenuDustNiagara = false;
			UE_LOG(LogTemp, Log, TEXT("[SquadAI MainMenu] Using Niagara menu dust system: %s"), Path);
			return;
		}
	}
}

// S19-PIENIAGARA: AutoRelease components are pooled; never also set AutoDestroy.
void ASquadAIMainMenuHUD::TickMenuNiagaraDust(float ScreenW, float ScreenH)
{
	if (!bUseNiagaraMenuDustExplosion || bReducedMenuMotion || MenuState != EMainMenuState::Main)
	{
		return;
	}

	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}

	AutoResolveMenuDustNiagara();
	if (!MenuDustNiagaraSystem)
	{
		if (!bLoggedMissingMenuDustNiagara)
		{
			UE_LOG(LogTemp, Warning, TEXT("[SquadAI MainMenu] No DustExplosion Niagara system found. Assign MenuDustNiagaraSystem or add NS_Dirt_Explosion/DustExplosion under /Game."));
			bLoggedMissingMenuDustNiagara = true;
		}
		return;
	}

	if (MasterTime < NextMenuNiagaraDustBurstTime)
	{
		return;
	}
	const float MinDustDelay = FMath::Max(0.42f, MenuNiagaraDustBurstInterval * 0.55f);
	const float MaxDustDelay = FMath::Max(MinDustDelay + 0.22f, MenuNiagaraDustBurstInterval * 1.12f);
	NextMenuNiagaraDustBurstTime = MasterTime + FMath::FRandRange(MinDustDelay, MaxDustDelay);

	APlayerCameraManager* Cam = UGameplayStatics::GetPlayerCameraManager(this, 0);
	if (!Cam)
	{
		return;
	}

	const FRotator CamRot = Cam->GetCameraRotation();
	const FVector CamLoc = Cam->GetCameraLocation();
	const FVector Forward = CamRot.Vector();
	const FVector Right = CamRot.RotateVector(FVector::RightVector);
	const FVector Up = CamRot.RotateVector(FVector::UpVector);
	const float UIS = FMath::Clamp(ScreenH / 1080.f, 0.70f, 1.35f);

	// Random 3D dust/explosion puffs across the camera frustum. Slower and softer than
	// the previous bottom strip: the effect should feel alive, not like scratch lines.
	const int32 BurstCount = 3 + ((MenuNiagaraDustBurstCounter % 2) == 0 ? 1 : 0);
	for (int32 i = 0; i < BurstCount; ++i)
	{
		const float Side = FMath::FRandRange(-610.f, 610.f) * UIS;
		const float Vertical = FMath::FRandRange(-215.f, 155.f) * UIS;
		const float Depth = FMath::FRandRange(470.f, 820.f) * UIS;
		const FVector SpawnLoc = CamLoc + Forward * Depth + Right * Side + Up * Vertical;
		const FRotator SpawnRot(0.f, CamRot.Yaw + FMath::FRandRange(-18.f, 18.f), 0.f);
		const float ScaleValue = FMath::FRandRange(0.72f, 1.32f) * UIS;

		UNiagaraComponent* DustComp = UNiagaraFunctionLibrary::SpawnSystemAtLocation(
			World,
			MenuDustNiagaraSystem.Get(),
			SpawnLoc,
			SpawnRot,
			FVector(ScaleValue),
			false, // AutoRelease owns teardown; AutoDestroy is invalid on pooled components.
			true,
			ENCPoolMethod::AutoRelease,
			true);
		if (DustComp)
		{
			DustComp->SetFloatParameter(TEXT("User.LifetimeScale"), 1.85f);
			DustComp->SetFloatParameter(TEXT("User.VelocityScale"), 0.55f);
			DustComp->SetFloatParameter(TEXT("User.SpawnRateScale"), 1.35f);
		}
	}
	++MenuNiagaraDustBurstCounter;
}

void ASquadAIMainMenuHUD::DrawMenuFilmGrain(float ScreenW, float ScreenH)
{
	if (!Canvas || !bMenuFilmGrain) return;
	const int32 T = FMath::FloorToInt(MasterTime * 12.f); // 12fps grain dance: filmic, cheap.
	for (int32 i = 0; i < 110; ++i)
	{
		uint32 Hv = (uint32)(i * 2654435761u + T * 40503u);
		Hv ^= Hv >> 15; Hv *= 2246822519u; Hv ^= Hv >> 13;
		const float GX = (float)(Hv % 1000) / 1000.f * ScreenW;
		const float GY = (float)((Hv >> 10) % 1000) / 1000.f * ScreenH;
		const float GA = 0.028f + 0.02f * (float)((Hv >> 20) % 100) / 100.f;
		DrawRect(FLinearColor(1.f, 0.96f, 0.88f, GA), GX, GY, 2.f, 2.f);
	}
}

void ASquadAIMainMenuHUD::GetFarsiTextSize(const FString& Text, UFont* Font, float Scale, float& OutW, float& OutH)
{
	OutW = 0.f;
	OutH = 0.f;
	if (!Canvas || Text.IsEmpty()) return;

	const FString DisplayText = SquadAIMenuDisplayText(Text, CachedMenuSettings.LanguageCode); // S17-ARFIX
	FString ShapedText;
	if (!SquadAIHasPersianOrArabicGlyphs(DisplayText)) { ShapedText = DisplayText; }
	else if (const FString* Cached = ShapedTextFrameCache.Find(DisplayText)) { ShapedText = *Cached; }
	else { ShapedText = FFarsiTextHelper::ShapeAndOrder(DisplayText); ShapedTextFrameCache.Add(DisplayText, ShapedText); }
	UFont* TargetFont = Font ? Font : (MenuFont ? MenuFont.Get() : GEngine->GetMediumFont());
	if (!TargetFont) return;

	const float HUDS = Scale * HUDFontScale; // MEGA-6 (G-14): measure what we draw.
	Canvas->TextSize(TargetFont, ShapedText, OutW, OutH, HUDS, HUDS);
	if (OutW <= 0.f) OutW = ShapedText.Len() * 12.f * HUDS;
	if (OutH <= 0.f) OutH = 18.f * HUDS;
}

void ASquadAIMainMenuHUD::DrawFarsiText(const FString& Text, const FLinearColor& Color, float X, float Y, UFont* Font, float Scale, bool bDropShadow)
{
	if (!Canvas || Text.IsEmpty()) return;

	const FString DisplayText = SquadAIMenuDisplayText(Text, CachedMenuSettings.LanguageCode); // S17-ARFIX
	FString ShapedText;
	if (!SquadAIHasPersianOrArabicGlyphs(DisplayText)) { ShapedText = DisplayText; }
	else if (const FString* Cached = ShapedTextFrameCache.Find(DisplayText)) { ShapedText = *Cached; }
	else { ShapedText = FFarsiTextHelper::ShapeAndOrder(DisplayText); ShapedTextFrameCache.Add(DisplayText, ShapedText); }
	UFont* TargetFont = Font ? Font : (MenuFont ? MenuFont.Get() : GEngine->GetMediumFont());
	if (!TargetFont) return;

	// AAA-MW-10: reference-style text is crisp, not glow-smeared. Pixel-align and
	// keep only one tight black shadow instead of stacking several scaled copies.
	const float DrawX = FMath::RoundToFloat(X);
	const float DrawY = FMath::RoundToFloat(Y);
	const float FinalScale = Scale * HUDFontScale;
	if (bDropShadow)
	{
		Canvas->SetDrawColor(SquadAIRefSRGBA(0x01, 0x01, 0x01, Color.A * 0.82f).ToFColor(true));
		Canvas->DrawText(TargetFont, ShapedText, DrawX + 1.4f, DrawY + 1.4f, FinalScale, FinalScale);
	}

	Canvas->SetDrawColor(Color.ToFColor(true));
	Canvas->DrawText(TargetFont, ShapedText, DrawX, DrawY, FinalScale, FinalScale);
}

void ASquadAIMainMenuHUD::DrawFarsiTextBounded(const FString& Text, const FLinearColor& Color, float X, float Y, float MaxWidth, UFont* Font, float PreferredScale, bool bDropShadow, bool bCenterHorizontal, float BoxHeight)
{
	if (!Canvas || Text.IsEmpty() || MaxWidth <= 0.f) return;

	const FString DisplayText = SquadAIMenuDisplayText(Text, CachedMenuSettings.LanguageCode); // S17-ARFIX
	FString ShapedText;
	if (!SquadAIHasPersianOrArabicGlyphs(DisplayText)) { ShapedText = DisplayText; }
	else if (const FString* Cached = ShapedTextFrameCache.Find(DisplayText)) { ShapedText = *Cached; }
	else { ShapedText = FFarsiTextHelper::ShapeAndOrder(DisplayText); ShapedTextFrameCache.Add(DisplayText, ShapedText); }
	UFont* TargetFont = Font ? Font : (MenuFont ? MenuFont.Get() : GEngine->GetMediumFont());
	if (!TargetFont) return;

	float RawW = 0.f, RawH = 0.f;
	Canvas->TextSize(TargetFont, ShapedText, RawW, RawH, 1.0f, 1.0f);
	if (RawW <= 0.f) RawW = ShapedText.Len() * 12.f;
	if (RawH <= 0.f) RawH = 18.f;

	// Global readability multiplier (bigger-fonts request). Bounded text auto-shrinks
	// to fit, so this can never overflow its box.
	const float RequestedScale = PreferredScale * HUDFontScale;
	float FinalScale = RequestedScale;
	const float ScaledW = RawW * RequestedScale;
	if (ScaledW > MaxWidth)
	{
		FinalScale = RequestedScale * (MaxWidth / ScaledW);
	}

	const float RenderW = RawW * FinalScale;
	const float RenderH = RawH * FinalScale;

	float DrawX = X;
	if (bCenterHorizontal)
	{
		DrawX = X + (MaxWidth - RenderW) * 0.5f;
	}

	float DrawY = Y;
	if (BoxHeight > 0.f)
	{
		DrawY = Y + (BoxHeight - RenderH) * 0.5f;
	}

	const float PixelX = FMath::RoundToFloat(DrawX);
	const float PixelY = FMath::RoundToFloat(DrawY);
	if (bDropShadow)
	{
		Canvas->SetDrawColor(SquadAIRefSRGBA(0x01, 0x01, 0x01, Color.A * 0.82f).ToFColor(true));
		Canvas->DrawText(TargetFont, ShapedText, PixelX + 1.3f, PixelY + 1.3f, FinalScale, FinalScale);
	}

	Canvas->SetDrawColor(Color.ToFColor(true));
	Canvas->DrawText(TargetFont, ShapedText, PixelX, PixelY, FinalScale, FinalScale);
}

void ASquadAIMainMenuHUD::RegisterButton(int32 ID, float X, float Y, float Width, float Height, const FText& Label)
{
	FMenuButtonRect Rect;
	Rect.ButtonID = ID;
	Rect.Min = FVector2D(X, Y);
	Rect.Max = FVector2D(X + Width, Y + Height);
	Rect.Label = Label;
	ClickableButtons.Add(Rect);
}

void ASquadAIMainMenuHUD::DrawNineSliceFrame(UTexture2D* FrameTexture, float X, float Y, float Width, float Height, float CornerSize, const FLinearColor& Tint)
{
	if (!Canvas || !FrameTexture || Width <= 1.f || Height <= 1.f) return;

	// AAA-MM-4: true transparent-center 9-slice frame support for the separate
	// Persian/Girih border PNGs. Edges stretch, corners stay crisp, and the center
	// is intentionally never drawn so content/background art remains untouched.
	const float TexW = FMath::Max(1.f, static_cast<float>(FrameTexture->GetSizeX()));
	const float TexH = FMath::Max(1.f, static_cast<float>(FrameTexture->GetSizeY()));
	const float Src = FMath::Clamp(FMath::Min(TexW, TexH) * 0.085f, 32.f, 128.f);
	const float U = Src / TexW;
	const float V = Src / TexH;
	const float C = FMath::Clamp(CornerSize, 8.f, FMath::Min(Width, Height) * 0.45f);
	const float MidW = FMath::Max(0.f, Width - 2.f * C);
	const float MidH = FMath::Max(0.f, Height - 2.f * C);
	const float MidU = FMath::Max(0.f, 1.f - 2.f * U);
	const float MidV = FMath::Max(0.f, 1.f - 2.f * V);

	// Corners
	DrawTexture(FrameTexture, X, Y, C, C, 0.f, 0.f, U, V, Tint);
	DrawTexture(FrameTexture, X + Width - C, Y, C, C, 1.f - U, 0.f, U, V, Tint);
	DrawTexture(FrameTexture, X, Y + Height - C, C, C, 0.f, 1.f - V, U, V, Tint);
	DrawTexture(FrameTexture, X + Width - C, Y + Height - C, C, C, 1.f - U, 1.f - V, U, V, Tint);

	// Edges only — no center fill.
	if (MidW > 1.f)
	{
		DrawTexture(FrameTexture, X + C, Y, MidW, C, U, 0.f, MidU, V, Tint);
		DrawTexture(FrameTexture, X + C, Y + Height - C, MidW, C, U, 1.f - V, MidU, V, Tint);
	}
	if (MidH > 1.f)
	{
		DrawTexture(FrameTexture, X, Y + C, C, MidH, 0.f, V, U, MidV, Tint);
		DrawTexture(FrameTexture, X + Width - C, Y + C, C, MidH, 1.f - U, V, U, MidV, Tint);
	}
}

void ASquadAIMainMenuHUD::DrawChiseledTacticalPanel(float X, float Y, float Width, float Height, const FLinearColor& BgColor, const FLinearColor& BorderColor, float CutSize)
{
	if (!Canvas) return;
	// MEGA-10 AAA: triple-depth — drop shadow + saturated fill + double border + inner bevel (not pale flat).
	DrawRect(FLinearColor(0.0f,0.0f,0.0f,0.45f), X+4.f, Y+4.f, Width, Height); // outer drop shadow
	DrawRect(BgColor, X, Y, Width, Height);
	DrawRect(FLinearColor(1.f,0.92f,0.55f,0.09f), X, Y, Width, Height*0.35f); // top volumetric highlight — kills flatness
	DrawRect(FLinearColor(0.0f,0.0f,0.0f,0.18f), X, Y+Height*0.75f, Width, Height*0.25f); // bottom recess
	// 1.8px laser border with chiseled corners — stronger, not pale
	DrawLine(X + CutSize, Y, X + Width - CutSize, Y, BorderColor, 1.8f);
	DrawLine(X + Width, Y + CutSize, X + Width, Y + Height - CutSize, BorderColor, 1.8f);
	DrawLine(X + Width - CutSize, Y + Height, X + CutSize, Y + Height, BorderColor, 1.8f);
	DrawLine(X, Y + Height - CutSize, X, Y + CutSize, BorderColor, 1.8f);
	DrawLine(X, Y + CutSize, X + CutSize, Y, BorderColor, 1.8f);
	DrawLine(X + Width - CutSize, Y, X + Width, Y + CutSize, BorderColor, 1.8f);
	DrawLine(X + Width, Y + Height - CutSize, X + Width - CutSize, Y + Height, BorderColor, 1.8f);
	DrawLine(X + CutSize, Y + Height, X, Y + Height - CutSize, BorderColor, 1.8f);
	// Inner brass pinstripe (1px inside) — double frame read
	const FLinearColor InnerGold(0.50f,0.82f,0.76f,0.46f); // AAA-B2-0: cool field-slate pinstripe, not gold
	DrawLine(X+CutSize+3.f, Y+3.f, X+Width-CutSize-3.f, Y+3.f, InnerGold, 1.0f);
	DrawLine(X+Width-3.f, Y+CutSize+3.f, X+Width-3.f, Y+Height-CutSize-3.f, InnerGold, 1.0f);
	DrawLine(X+Width-CutSize-3.f, Y+Height-3.f, X+CutSize+3.f, Y+Height-3.f, InnerGold, 1.0f);
	DrawLine(X+3.f, Y+Height-CutSize-3.f, X+3.f, Y+CutSize+3.f, InnerGold, 1.0f);
	DrawLine(X+3.f, Y+CutSize+3.f, X+CutSize+3.f, Y+3.f, InnerGold, 1.0f);
	DrawLine(X+Width-CutSize-3.f, Y+3.f, X+Width-3.f, Y+CutSize+3.f, InnerGold, 1.0f);
	DrawLine(X+Width-3.f, Y+Height-CutSize-3.f, X+Width-CutSize-3.f, Y+Height-3.f, InnerGold, 1.0f);
	DrawLine(X+CutSize+3.f, Y+Height-3.f, X+3.f, Y+Height-CutSize-3.f, InnerGold, 1.0f);

	// AAA-MM-4: if the new separate transparent frame PNG is installed, layer it as
	// the final micro-detail pass. Procedural chisel remains the guaranteed fallback.
	const bool bLooksCrimson = BorderColor.R > BorderColor.G * 1.25f && BorderColor.R > BorderColor.B * 1.25f;
	UTexture2D* FrameTex = (bLooksCrimson && FrameTacticalCrimsonTexture) ? FrameTacticalCrimsonTexture.Get() : FrameTacticalGoldTexture.Get();
	if (FrameTex && Width >= 96.f && Height >= 38.f)
	{
		const float FrameAlpha = FMath::Clamp(BorderColor.A * 0.78f, 0.0f, 0.92f);
		DrawNineSliceFrame(FrameTex, X - 1.f, Y - 1.f, Width + 2.f, Height + 2.f, FMath::Clamp(CutSize * 2.4f, 16.f, 46.f), FLinearColor(1.f, 1.f, 1.f, FrameAlpha));
	}
}

void ASquadAIMainMenuHUD::DrawTacticalTopoGrid(float X, float Y, float Width, float Height, const FLinearColor& Tint)
{
	// AAA-MW-26: the main menu must never receive graph-paper/topo lines. The
	// user specifically called out the background and quick-start CTA square grid.
	// Keep this helper available only for submenu recon boards where it is contained.
	if (!Canvas || MenuState == EMainMenuState::Main)
	{
		return;
	}

	const FLinearColor GridCol(Tint.R, Tint.G, Tint.B, 0.026f);
	const float Step = 52.f;
	for (float gx = X; gx < X + Width; gx += Step)
	{
		DrawLine(gx, Y, gx, Y + Height, GridCol, 0.65f);
	}
	for (float gy = Y; gy < Y + Height; gy += Step)
	{
		DrawLine(X, gy, X + Width, gy, GridCol, 0.65f);
	}
}

void ASquadAIMainMenuHUD::DrawBallisticBlueprintGrid(float X, float Y, float Width, float Height, const FLinearColor& Tint)
{
	DrawTacticalTopoGrid(X, Y, Width, Height, Tint);
}

void ASquadAIMainMenuHUD::DrawDossierDocumentUnderlay(float X, float Y, float Width, float Height, const FString& StampFarsi, const FLinearColor& StampColor)
{
	if (!Canvas) return;
	DrawChiseledTacticalPanel(X, Y, Width, Height, FLinearColor(0.04f, 0.05f, 0.07f, 0.95f), StampColor * 0.7f, 8.0f);
	DrawTacticalTopoGrid(X, Y, Width, Height, StampColor);

	if (!StampFarsi.IsEmpty())
	{
		DrawFarsiTextBounded(StampFarsi, FLinearColor(StampColor.R, StampColor.G, StampColor.B, 0.25f), X + 20.f, Y + Height - 50.f, Width - 40.f, TitleFont ? TitleFont.Get() : nullptr, 1.8f, false, true);
	}
}

void ASquadAIMainMenuHUD::DrawSacredDefenseBorder(float X, float Y, float Width, float Height, const FLinearColor& BorderColor, bool bActiveGlow)
{
	if (!Canvas) return;

	const float GlowAlpha = bActiveGlow ? (0.85f + 0.15f * FMath::Sin(MasterTime * 4.0f)) : 0.85f;
	const FLinearColor ActiveBorder(BorderColor.R, BorderColor.G, BorderColor.B, GlowAlpha);

	// 1. Semi-translucent dark panel backing
	DrawChiseledTacticalPanel(X, Y, Width, Height, PanelBgColor, ActiveBorder, 10.0f);

	// 2. Inner precision laser line (2px offset)
	DrawLine(X + 12.f, Y + 2.f, X + Width - 12.f, Y + 2.f, ActiveBorder * 0.70f, 1.0f);
	DrawLine(X + Width - 2.f, Y + 12.f, X + Width - 2.f, Y + Height - 12.f, ActiveBorder * 0.70f, 1.0f);
	DrawLine(X + Width - 12.f, Y + Height - 2.f, X + 12.f, Y + Height - 2.f, ActiveBorder * 0.70f, 1.0f);
	DrawLine(X + 2.f, Y + Height - 12.f, X + 2.f, Y + 12.f, ActiveBorder * 0.70f, 1.0f);

	// 3. High-precision 8-point Corner Titanium Brackets
	const float BracketLen = 28.0f;
	DrawLine(X, Y, X + BracketLen, Y, BorderColor, 3.0f);
	DrawLine(X, Y, X, Y + BracketLen, BorderColor, 3.0f);

	DrawLine(X + Width, Y, X + Width - BracketLen, Y, BorderColor, 3.0f);
	DrawLine(X + Width, Y, X + Width, Y + BracketLen, BorderColor, 3.0f);

	DrawLine(X, Y + Height, X + BracketLen, Y + Height, BorderColor, 3.0f);
	DrawLine(X, Y + Height, X, Y + Height - BracketLen, BorderColor, 3.0f);

	DrawLine(X + Width, Y + Height, X + Width - BracketLen, Y + Height, BorderColor, 3.0f);
	DrawLine(X + Width, Y + Height, X + Width, Y + Height - BracketLen, BorderColor, 3.0f);

	// 4. Ornate 3D bevel: light catches top/left, shadow falls bottom/right.
	const FLinearColor BevelLight(0.70f, 0.96f, 0.92f, 0.42f * GlowAlpha); // AAA-B2-0: cool bevel, no gold wash
	const FLinearColor BevelDark(0.0f, 0.0f, 0.0f, 0.55f * GlowAlpha);
	DrawLine(X + 1.f, Y + 1.f, X + Width - 1.f, Y + 1.f, BevelLight, 1.0f);
	DrawLine(X + 1.f, Y + 1.f, X + 1.f, Y + Height - 1.f, BevelLight, 1.0f);
	DrawLine(X + 1.f, Y + Height - 1.f, X + Width - 1.f, Y + Height - 1.f, BevelDark, 2.0f);
	DrawLine(X + Width - 1.f, Y + 1.f, X + Width - 1.f, Y + Height - 1.f, BevelDark, 2.0f);

	// 5. Brass corner rivets for the framed-plaque look.
	const float RivetR = 3.0f;
	const FLinearColor RivetCol = bActiveGlow ? PrimaryAccentColor : BorderColor;
	DrawRect(RivetCol, X - RivetR, Y - RivetR, RivetR * 2.f, RivetR * 2.f);
	DrawRect(RivetCol, X + Width - RivetR, Y - RivetR, RivetR * 2.f, RivetR * 2.f);
	DrawRect(RivetCol, X - RivetR, Y + Height - RivetR, RivetR * 2.f, RivetR * 2.f);
	DrawRect(RivetCol, X + Width - RivetR, Y + Height - RivetR, RivetR * 2.f, RivetR * 2.f);

	if (bActiveGlow)
	{
		// 6. Outer halo frame on the active panel.
		const FLinearColor HaloCol(ActiveBorder.R, ActiveBorder.G, ActiveBorder.B, 0.35f * GlowAlpha);
		DrawLine(X - 4.f, Y - 4.f, X + Width + 4.f, Y - 4.f, HaloCol, 1.0f);
		DrawLine(X - 4.f, Y + Height + 4.f, X + Width + 4.f, Y + Height + 4.f, HaloCol, 1.0f);
		DrawLine(X - 4.f, Y - 4.f, X - 4.f, Y + Height + 4.f, HaloCol, 1.0f);
		DrawLine(X + Width + 4.f, Y - 4.f, X + Width + 4.f, Y + Height + 4.f, HaloCol, 1.0f);
	}
}

void ASquadAIMainMenuHUD::DrawRoundedBox(float X, float Y, float Width, float Height, float CornerRadius, const FLinearColor& FillColor, const FLinearColor& BorderColor)
{
	DrawChiseledTacticalPanel(X, Y, Width, Height, FillColor, BorderColor, CornerRadius);
}

void ASquadAIMainMenuHUD::DrawTacticalDivider(float X, float Y, float Width, const FLinearColor& Color)
{
	if (!Canvas) return;
	DrawLine(X, Y, X + Width, Y, Color, 1.2f);
}

void ASquadAIMainMenuHUD::DrawStatBar(float X, float Y, float Width, float Height, float Fraction, const FLinearColor& FillColor, const FLinearColor& EmptyColor)
{
	if (!Canvas) return;

	// AAA-MW-11: higher-contrast reference-style segmented track: dark trench,
	// warm lit fill, thin brass edge instead of cold grey UI chrome.
	DrawRect(SquadAIRefSRGBA(0x01, 0x01, 0x01, 0.42f), X, Y, Width, Height);
	DrawRect(EmptyColor, X + 1.f, Y + 1.f, FMath::Max(0.f, Width - 2.f), FMath::Max(0.f, Height - 2.f));

	const float ClampedFrac = FMath::Clamp(Fraction, 0.0f, 1.0f);
	const int32 NumSegs = 10;
	const float Gap = 2.f;
	const float SegW = (Width - Gap * (NumSegs - 1)) / NumSegs;
	for (int32 s = 0; s < NumSegs; ++s)
	{
		const float SegFrac0 = static_cast<float>(s) / NumSegs;
		const float SegFrac1 = static_cast<float>(s + 1) / NumSegs;
		float SegFill = 0.f;
		if (ClampedFrac >= SegFrac1) SegFill = 1.f;
		else if (ClampedFrac > SegFrac0) SegFill = (ClampedFrac - SegFrac0) * NumSegs;
		if (SegFill <= 0.f) continue;
		const float SX = X + s * (SegW + Gap);
		const float SW = SegW * SegFill;
		DrawRect(FillColor, SX, Y, SW, Height);
		DrawRect(SquadAIRefSRGBA(0xE7, 0xB7, 0x56, 0.24f * FillColor.A), SX, Y, SW, FMath::Max(1.f, Height * 0.34f));
		DrawRect(SquadAIRefSRGBA(0x01, 0x01, 0x01, 0.18f), SX, Y + Height * 0.70f, SW, Height * 0.30f);
	}

	const FLinearColor Edge(FillColor.R, FillColor.G, FillColor.B, 0.46f);
	DrawLine(X, Y, X + Width, Y, Edge, 1.0f);
	DrawLine(X, Y + Height, X + Width, Y + Height, Edge * 0.72f, 1.0f);
	DrawLine(X, Y, X, Y + Height, Edge * 0.62f, 1.0f);
	DrawLine(X + Width, Y, X + Width, Y + Height, Edge * 0.62f, 1.0f);
}

void ASquadAIMainMenuHUD::DrawSpecialityBadge(float X, float Y, float Width, float Height, const FSquadWeaponSpecialityTrait& Trait, bool bHovered)
{
	const bool bMenuEnglish = !CachedMenuSettings.LanguageCode.StartsWith(TEXT("fa"), ESearchCase::IgnoreCase);
	if (!Canvas) return;

	const FLinearColor BgCol = bHovered ? FLinearColor(0.20f, 0.15f, 0.04f, 0.98f) : FLinearColor(0.06f, 0.08f, 0.10f, 0.90f);
	const FLinearColor BorderCol = bHovered ? PrimaryAccentColor : FLinearColor(0.35f, 0.40f, 0.45f, 0.70f);

	DrawChiseledTacticalPanel(X, Y, Width, Height, BgCol, BorderCol, 6.0f);

	UTexture2D* Icon = Trait.IconTexture ? Trait.IconTexture.Get() : GetTraitTexture(Trait.TraitID);
	if (Icon)
	{
		const float IconSz = Height - 12.f;
		DrawTexture(Icon, X + 6.f, Y + 6.f, IconSz, IconSz, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
	}

	const float TextX = X + Height + 4.f;
	const float TextW = Width - Height - 8.f;
	DrawFarsiTextBounded((bMenuEnglish ? Trait.TitleEnglish : Trait.TitleFarsi).ToString(), bHovered ? PrimaryAccentColor : FLinearColor::White, TextX, Y + 6.f, TextW, MenuFont ? MenuFont.Get() : nullptr, 0.90f, true);
	DrawFarsiTextBounded((bMenuEnglish ? Trait.DescriptionEnglish : Trait.DescriptionFarsi).ToString(), FLinearColor(0.75f, 0.80f, 0.85f, 0.90f), TextX, Y + 24.f, TextW, BodyFont ? BodyFont.Get() : nullptr, 0.75f, true);
}

void ASquadAIMainMenuHUD::DrawStyledButton(float X, float Y, float Width, float Height, const FText& Text, bool bHovered, bool bDisabled, float StaggerDelay)
{
	if (!Canvas) return;

	float CascadeOffset = 0.0f;
	float ButtonAlpha = 1.0f;
	if (IntroCascadeTimer < StaggerDelay)
	{
		CascadeOffset = -80.f * (1.0f - (IntroCascadeTimer / FMath::Max(0.01f, StaggerDelay)));
		ButtonAlpha = FMath::Clamp(IntroCascadeTimer / FMath::Max(0.01f, StaggerDelay), 0.f, 1.f);
	}

	// MEGA-8: eased hover ramp keyed by label (~150ms ease-out; zero signature change).
	float& Ramp = ButtonHoverRamp.FindOrAdd(Text.ToString());
	Ramp = FMath::FInterpTo(Ramp, (bHovered && !bDisabled) ? 1.f : 0.f, LastFrameDelta, 12.f);
	const float PressAge = MasterTime - LastMenuClickTime;
	const float PressDip = (!bDisabled && bHovered && PressAge >= 0.f && PressAge < 0.18f) ? 0.97f : 1.f;
	const float HoverGrow = (1.f + 0.03f * Ramp) * PressDip;
	const float DrawX = X + CascadeOffset + (Width - Width * HoverGrow) * 0.5f;
	const float DrawY = Y + (Height - Height * HoverGrow) * 0.5f;
	const float DrawW = Width * HoverGrow;
	const float DrawH = Height * HoverGrow;
	const float PulseGlow = 1.f + Ramp * (0.15f * FMath::Sin(MasterTime * 8.0f) - 0.08f);
	const FLinearColor Accent = PrimaryAccentColor * PulseGlow;

	// Modern AAA Tactical Obsidian / Matte Dark Charcoal Backdrop with Subtle Bevel
	const FLinearColor BgColor = bDisabled ? FLinearColor(0.035f, 0.045f, 0.055f, 0.70f * ButtonAlpha) :
								  FMath::Lerp(FLinearColor(0.055f, 0.07f, 0.09f, 0.96f * ButtonAlpha), FLinearColor(0.055f, 0.135f, 0.125f, 0.98f * ButtonAlpha), Ramp); // MEGA-8

	// Thin 1px Laser Border
	const FLinearColor BorderColor = bDisabled ? FLinearColor(0.18f, 0.20f, 0.22f, 0.40f * ButtonAlpha) :
								   FMath::Lerp(FLinearColor(0.40f, 0.48f, 0.56f, 0.85f * ButtonAlpha), Accent, Ramp); // MEGA-8

	// Crisp high-contrast readable text
	const FLinearColor TextColor = bDisabled ? FLinearColor(0.40f, 0.42f, 0.45f, 0.70f * ButtonAlpha) :
								 FMath::Lerp(FLinearColor(0.96f, 0.97f, 0.99f, 1.0f * ButtonAlpha), FLinearColor(0.88f, 1.0f, 0.97f, 1.0f * ButtonAlpha), Ramp); // MEGA-8

	// 1. Draw Textured Button Plate if Available, else fall back to Chiseled Panel
	if (Ramp > 0.5f && ButtonHoverTexture && !bDisabled) // MEGA-8: swap mid-ramp.
	{
		DrawTexture(ButtonHoverTexture, DrawX, DrawY, DrawW, DrawH, 0.f, 0.f, 1.f, 1.f, FLinearColor(1.f, 1.f, 1.f, ButtonAlpha));
	}
	else if (ButtonNormalTexture && !bDisabled)
	{
		DrawTexture(ButtonNormalTexture, DrawX, DrawY, DrawW, DrawH, 0.f, 0.f, 1.f, 1.f, FLinearColor(1.f, 1.f, 1.f, ButtonAlpha));
	}
	else
	{
		DrawChiseledTacticalPanel(DrawX, DrawY, DrawW, DrawH, BgColor, BorderColor, 6.0f);
	}

	// Left Khaki Gold Indicator Notch
	const float BracketW = 3.5f + 2.5f * Ramp; // MEGA-8
	const FLinearColor BracketColor = bDisabled ? FLinearColor(0.25f, 0.25f, 0.25f, 0.6f) :
									  FMath::Lerp(PrimaryAccentColor * 0.85f, Accent, Ramp); // MEGA-8
	DrawRect(BracketColor, DrawX, DrawY + 3.f, BracketW, DrawH - 6.f);

	if (Ramp > 0.02f && !bDisabled) // MEGA-8: shimmer rides the ramp tail.
	{
		const float ShimmerPos = FMath::Fmod(MasterTime * 2.2f, 1.5f) - 0.25f;
		const float ShimmerX = DrawX + (DrawW * ShimmerPos);
		if (ShimmerX >= DrawX + 8.f && ShimmerX <= DrawX + Width - 25.f)
		{
			DrawRect(FLinearColor(0.45f, 0.95f, 0.88f, 0.18f * ButtonAlpha * Ramp), ShimmerX, DrawY + 2.f, 24.f, DrawH - 4.f);
		}
	}

	// Bounded, auto-scaled, perfectly centered text with LARGER scale
	const float MarginX = 18.0f;
	DrawFarsiTextBounded(Text.ToString(), TextColor, DrawX + MarginX, DrawY, DrawW - (MarginX * 2.f), MenuFont ? MenuFont.Get() : nullptr, 1.25f, true, true, DrawH);
}

void ASquadAIMainMenuHUD::DrawBackgroundMedia(float ScreenW, float ScreenH)
{
	if (!Canvas) return;

	// AAA-MW-27: main menu must not draw old animated/material backgrounds because
	// those can contain the rejected square/grid overlay. Use the static texture
	// Ken-Burns path whenever a texture is available.
	// S16-FLAG2/4/5: draw the waving-flag material through the identical
	// aspect-correct Ken-Burns crop when it resolved (see AutoResolve guard).
	// Reduced-motion users and cvar 0 keep the static picture.
	// S16-VID: video is highest priority once frames actually arrive (surface
	// size stays 0 while opening, so the static image shows until the first
	// frame — never a black flash).
	UpdateBackgroundVideoLoop(); // S18-VIDFIX: loop watchdog (A/B handoff removed)
	const bool bUseVideo = BackgroundVideoTexture && BackgroundVideoPlayer
		&& CVarSquadAIMenuVideo.GetValueOnGameThread() == 1
		&& BackgroundVideoTexture->GetSurfaceWidth() > 2.f
		&& BackgroundVideoTexture->GetSurfaceHeight() > 2.f;
	// ---------------------------------------------------------------------
	// S18-VIDFIX3: the loop wrap, without the black dip.
	// Previous attempt faded to black over the wrap — that IS the black screen
	// you saw, and it is worse than the hitch it hid. UE loops by seeking to
	// zero, which flushes the decoder, so a handful of frames arrive late.
	// AutoClear = false already keeps the LAST GOOD FRAME on the surface during
	// that gap, so the correct behaviour is simply: change nothing, let the
	// still frame hold for ~0.1 s, and never touch the alpha. No dip, no flash,
	// no jump — the picture just pauses for a few frames at the same spot.
	// The only thing we still do near the wrap is freeze any UI motion that
	// would otherwise visibly stall with it.
	// ---------------------------------------------------------------------
	if (bUseVideo)
	{
		const float Now = static_cast<float>(BackgroundVideoPlayer->GetTime().GetTotalSeconds());
		if (Now + KINDA_SMALL_NUMBER < VideoLastTimeSeconds)
		{
			VideoWrapRecover = 0.25f; // just wrapped — purely informational now
		}
		else if (VideoWrapRecover > 0.f)
		{
			VideoWrapRecover = FMath::Max(0.f, VideoWrapRecover - FApp::GetDeltaTime());
		}
		VideoLastTimeSeconds = Now;
		VideoWrapFade = 1.0f;
	}

	const bool bUseFlagWave = !bUseVideo && (FlagWaveBackgroundMaterial != nullptr) && !bReducedMenuMotion
		&& CVarSquadAIMenuFlagWave.GetValueOnGameThread() == 1;
	if (BackgroundTexture || bUseFlagWave || bUseVideo)
	{
		// AAA-MW-24: never non-uniformly stretch the menu key art. The background now
		// uses a real aspect-correct Ken-Burns crop/pan so it feels alive without
		// turning the whole screen into a scaled screenshot.
		// S16-FLAG2: if only the material is available, use the flag key art's
		// native 1672x941 aspect for the crop maths.
		const float TexW = bUseVideo ? FMath::Max(1.f, BackgroundVideoTexture->GetSurfaceWidth())
			: (BackgroundTexture ? FMath::Max(1.f, static_cast<float>(BackgroundTexture->GetSizeX())) : 1672.f);
		const float TexH = bUseVideo ? FMath::Max(1.f, BackgroundVideoTexture->GetSurfaceHeight())
			: (BackgroundTexture ? FMath::Max(1.f, static_cast<float>(BackgroundTexture->GetSizeY())) : 941.f);
		const float TexAspect = TexW / TexH;
		const float ViewAspect = ScreenW / FMath::Max(1.f, ScreenH);
		float U0 = 0.f;
		float V0Base = 0.f;
		float USize = 1.f;
		float VSizeBase = 1.f;
		if (TexAspect > ViewAspect)
		{
			// Source is wider than the viewport: crop left/right, do not squeeze.
			USize = ViewAspect / TexAspect;
			U0 = (1.f - USize) * 0.5f;
		}
		else if (TexAspect < ViewAspect)
		{
			// Source is taller/narrower than the viewport: crop top/bottom, do not stretch.
			VSizeBase = TexAspect / ViewAspect;
			V0Base = (1.f - VSizeBase) * 0.5f;
		}
		// AAA-MW-24: bring back the pleasant alive background motion: a gentle
		// Ken-Burns pan plus real UV zoom/crop. It is still aspect-correct, so the
		// picture never gets non-uniformly stretched or screenshot-scaled.
		float VSize = VSizeBase;
		// S18-VIDFIX: NEVER Ken-Burns a video. The clip already has its own camera
		// move; adding a second slow pan/zoom on top is what read as "weird\n		// movement" (and the sine pan reverses direction every few seconds).
		// Stills keep the breathing motion.
		if (!bUseVideo && !bReducedMenuMotion && MenuState == EMainMenuState::Main)
		{
			const float BreathingZoomCrop = 0.018f + 0.017f * (0.5f + 0.5f * FMath::Sin(KenBurnsTimer * 0.115f + 0.8f));
			USize = FMath::Max(0.900f, USize * (1.f - BreathingZoomCrop));
			VSize = FMath::Max(0.900f, VSizeBase * (1.f - BreathingZoomCrop));

			const float UMargin = FMath::Max(0.f, 1.f - USize);
			const float VMargin = FMath::Max(0.f, 1.f - VSize);
			U0 = UMargin * (0.5f + 0.5f * FMath::Sin(KenBurnsTimer * 0.070f));
			V0Base = VMargin * (0.5f + 0.5f * FMath::Sin(KenBurnsTimer * 0.052f + 1.7f));
		}

		// Draw fully opaque. The user wants the menu picture clearly visible, not
		// dimmed by a black sheet just to reveal Niagara/window layers.
		if (bUseVideo)
		{
			// S16-VID: media textures draw through the SAME gamma path as plain
			// textures — correct brightness (unlike the material path).
			// S18-VIDFIX3: always fully opaque. The held last frame covers the
			// decoder gap; fading would only draw attention to it.
			DrawTexture(BackgroundVideoTexture, 0.f, 0.f, ScreenW, ScreenH, U0, V0Base, USize, VSize,
				FLinearColor::White);
		}
		else if (bUseFlagWave)
		{
			// S16-FLAG2: same rectangle, same UV crop — but sampled through the
			// waving-flag material (masked sine UV distortion + cloth shimmer).
			DrawMaterial(FlagWaveBackgroundMaterial, 0.f, 0.f, ScreenW, ScreenH, U0, V0Base, USize, VSize);
		}
		else
		{
			DrawTexture(BackgroundTexture, 0.f, 0.f, ScreenW, ScreenH, U0, V0Base, USize, VSize, FLinearColor::White);
		}
	}
	else if (BackgroundType == EMenuBackgroundType::AnimatedTextureMaterial && BackgroundMaterial && MenuState != EMainMenuState::Main)
	{
		DrawMaterialSimple(BackgroundMaterial, 0.f, 0.f, ScreenW, ScreenH, 1.0f);
	}
	else
	{
		// Sleek obsidian fallback, no tactical grid on the main menu.
		DrawRect(FLinearColor(0.05f, 0.06f, 0.08f, 1.0f), 0.f, 0.f, ScreenW, ScreenH);
		if (MenuState != EMainMenuState::Main)
		{
			DrawTacticalTopoGrid(0.f, 0.f, ScreenW, ScreenH, PrimaryAccentColor);
		}
	}

	// No full-screen black wash on the main menu: keep the background art visible.
	// Submenus keep a very light clarity shade only where needed for readability.
	if (MenuState != EMainMenuState::Main)
	{
		DrawRect(FLinearColor(0.0f, 0.0f, 0.0f, 0.12f), 0.f, 0.f, ScreenW, ScreenH);
	}

	if (WatermarkEmblemTexture)
	{
		const float EmblemSize = 220.f;
		const float EmblemX = ScreenW - EmblemSize - 40.f;
		const float EmblemY = ScreenH - EmblemSize - 60.f;
		// P7-MM4: the HQ emblem is an important insignia, not a droplet — the old lantern
		// flicker (0.145–0.195 alpha) made it look shadowy/dirty. Stable, clearly visible
		// watermark alpha, true colors (no tint multiply).
		DrawTexture(WatermarkEmblemTexture, EmblemX, EmblemY, EmblemSize, EmblemSize, 0.0f, 0.0f, 1.0f, 1.0f, FLinearColor(1.0f, 1.0f, 1.0f, 0.55f));
	}
}

void ASquadAIMainMenuHUD::DrawAudioWaveformVisualizer(float X, float Y, float Width, float Height)
{
	const bool bMenuEnglish = !CachedMenuSettings.LanguageCode.StartsWith(TEXT("fa"), ESearchCase::IgnoreCase);
	if (!Canvas) return;

	const int32 BarCount = 14;
	const float BarW = (Width / BarCount) - 3.f;

	for (int32 i = 0; i < BarCount; ++i)
	{
		const float Wave = FMath::Abs(FMath::Sin(MasterTime * 3.5f + i * 0.45f));
		const float BarH = FMath::Clamp(Wave * Height, 4.f, Height);
		const float BarX = X + i * (BarW + 3.f);
		const float BarY = Y + Height - BarH;

		DrawRect(PrimaryAccentColor * 0.75f, BarX, BarY, BarW, BarH);
	}

	DrawFarsiText(bMenuEnglish ? TEXT("Tactical radio frequency: 58.241 MHz // secure squad link") : TEXT("فرکانس بیسیم تاکتیکی: ۵۸.۲۴۱ مگاهرتز // ارتباط امن جوخه"), FLinearColor(0.65f, 0.70f, 0.75f, 0.85f), X, Y - 16.f, BodyFont ? BodyFont.Get() : nullptr, 0.75f, true);
}

void ASquadAIMainMenuHUD::DrawCompassDial(float X, float Y, float Radius)
{
	if (!Canvas) return;

	const int32 Segments = 8;
	for (int32 i = 0; i < Segments; ++i)
	{
		const float A0 = FMath::DegreesToRadians((360.f / Segments) * i + CompassRotation);
		const float A1 = FMath::DegreesToRadians((360.f / Segments) * (i + 1) + CompassRotation);

		DrawLine(X + FMath::Cos(A0) * Radius, Y + FMath::Sin(A0) * Radius,
				 X + FMath::Cos(A1) * Radius, Y + FMath::Sin(A1) * Radius,
				 PrimaryAccentColor * 0.75f, 1.2f);
	}

	for (int32 i = 0; i < 4; ++i)
	{
		const float A = FMath::DegreesToRadians(90.f * i + CompassRotation);
		DrawLine(X + FMath::Cos(A) * (Radius - 4.f), Y + FMath::Sin(A) * (Radius - 4.f),
				 X + FMath::Cos(A) * (Radius + 3.f), Y + FMath::Sin(A) * (Radius + 3.f),
				 PrimaryAccentColor, 1.5f);
	}

	const int32 Heading = FMath::FloorToInt(FMath::Fmod(CompassRotation, 360.0f));
	const FString HeadingStr = FString::Printf(TEXT("%03d°"), Heading);
	DrawFarsiTextBounded(HeadingStr, PrimaryAccentColor, X - 24.f, Y + Radius + 3.f, 48.f, BodyFont ? BodyFont.Get() : nullptr, 0.75f, true, true);
}

void ASquadAIMainMenuHUD::DrawTacticalTelemetryHUD(float ScreenW, float ScreenH)
{
	const bool bMenuEnglish = !CachedMenuSettings.LanguageCode.StartsWith(TEXT("fa"), ESearchCase::IgnoreCase);
	if (!Canvas) return;

	// AAA-MM-3: top-right telemetry is now a sealed command pill instead of loose text.
	const float UIS = FMath::Clamp(ScreenH / 1080.f, 0.70f, 1.35f);
	const float CrestSz = 50.f * UIS;
	const float PillW = 520.f * UIS;
	const float PillH = 56.f * UIS;
	const float PillX = ScreenW - PillW - 42.f * UIS;
	const float PillY = 18.f * UIS;

	DrawChiseledTacticalPanel(PillX, PillY, PillW, PillH, FLinearColor(0.03f, 0.045f, 0.055f, 0.78f), PrimaryAccentColor * 0.60f, 8.f * UIS);

	if (WatermarkEmblemTexture)
	{
		// P7-MM4: full-color, full-opacity crest (was warm-tinted at 0.88 alpha).
		DrawTexture(WatermarkEmblemTexture, PillX + PillW - CrestSz - 6.f * UIS, PillY + 3.f * UIS, CrestSz, CrestSz, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
	}

	const bool bBlink = FMath::Sin(MasterTime * 4.0f) > 0.0f;
	DrawRect(bBlink ? FLinearColor(0.20f, 1.0f, 0.35f, 0.95f) : FLinearColor(0.05f, 0.45f, 0.18f, 0.80f), PillX + 13.f * UIS, PillY + 13.f * UIS, 8.f * UIS, 8.f * UIS);

	const float TextX = PillX + 28.f * UIS;
	const float TextW = PillW - CrestSz - 48.f * UIS;
	DrawFarsiTextBounded(bMenuEnglish ? TEXT("Battle line coordinates: 31°19 44 N  48°41 12 E") : TEXT("مختصات خط نبرد: 31°19 44 N  48°41 12 E"), FLinearColor(0.92f, 0.94f, 0.98f, 1.0f), TextX, PillY + 8.f * UIS, TextW, MenuFont ? MenuFont.Get() : nullptr, 0.86f * UIS, true);
	DrawFarsiTextBounded(bMenuEnglish ? TEXT("Operational area: Khuzestan - Dehlavieh  |  full readiness") : TEXT("منطقه عملیاتی: خوزستان ـ دهلاویه  |  آماده‌باش کامل"), FLinearColor(0.80f, 0.86f, 0.88f, 0.90f), TextX, PillY + 30.f * UIS, TextW, BodyFont ? BodyFont.Get() : nullptr, 0.76f * UIS, true);
}

void ASquadAIMainMenuHUD::DrawScanlinesAndVignette(float ScreenW, float ScreenH)
{
	// Subtle top/bottom edge letterbox vignette
	if (!Canvas) return;
	DrawRect(SquadAIRefSRGBA(0x01, 0x01, 0x01, 0.30f), 0.f, 0.f, ScreenW, 6.f);
	DrawRect(SquadAIRefSRGBA(0x01, 0x01, 0x01, 0.30f), 0.f, ScreenH - 6.f, ScreenW, 6.f);
}

void ASquadAIMainMenuHUD::DrawHUD()
{
	Super::DrawHUD();

	if (!Canvas) return;

	// AAA-MM-1: owner directive — ignore the legacy UMG menu path completely.
	// Canvas is the only rendered main-menu stack; if a designer/old map leaves a UMG
	// instance alive, remove it so it cannot blank or fight the reconstructed AAA HUD.
	bUseProceduralCanvasMenu = true;
	// AAA-MW-8: do not force a high Canvas text scale. UFont/Canvas text is atlas-based;
	// large scale values magnify the glyph texture and look like a stretched image in fullscreen.
	// Use real larger font assets for size, and keep this multiplier near 1.0.
	HUDFontScale = FMath::Clamp(HUDFontScale, 0.90f, 1.18f);
	if (ActiveMenuWidget)
	{
		ActiveMenuWidget->RemoveFromParent();
		ActiveMenuWidget = nullptr;
	}

	ShapedTextFrameCache.Reset(); // B6-15: per-frame shape cache starts empty.
	const float ScreenW = Canvas->ClipX;
	const float ScreenH = Canvas->ClipY;
	const float UIScale = FMath::Clamp(ScreenH / 1080.f, 0.70f, 1.35f);

	// S16-INTRO: intro video owns the whole frame until its smoke ramp-in ends.
	if (DrawIntroSequence(ScreenW, ScreenH))
	{
		return;
	}

	const float DeltaTime = GetWorld() ? GetWorld()->GetDeltaSeconds() : 0.016f;

	// ===== S19-INSTANT: DEPARTURE =====
	// A level transition was requested (Start New Game -> difficulty, map launch,
	// load game). From this frame on, this HUD draws ONLY the loading screen, and
	// the pending blocking travel (OpenLevel) is allowed to start only once that
	// screen has actually been painted - see FSquadAILoadingHandoff.
	//
	// Before this round the screen-up work happened in the same tick and the very
	// next thing the game thread did was block inside OpenLevel, so the last frame
	// drawn was still the menu/difficulty card: the "few seconds stuck on that
	// screen" the report describes. Nothing below this point may run during a
	// departure - a menu button must never register under the loading screen.
	if (USquadAILoadingScreenSubsystem* LoadSys = USquadAILoadingScreenSubsystem::Get(this))
	{
		// bIsLoading is true from the request until the destination is ready and the
		// screen is dismissed - so this HUD keeps drawing the loading screen through
		// the travel AND through the destination's handshake (a menu world has no
		// other veil to show). The paint report is what releases the blocking travel,
		// and it matters only while the departure is pending.
		if (LoadSys->bIsLoading)
		{
			LoadSys->TickTransition(DeltaTime); // the drawn frame is the transition's clock
			DrawDepartureScreen(ScreenW, ScreenH, DeltaTime);
			if (LoadSys->IsDeparturePending())
			{
				LoadSys->NotifyDepartureScreenPainted(); // this frame counts: the travel gate reads it
			}
			return;
		}
	}
	UpdateAnimations(DeltaTime);
	UpdateSandParticles(DeltaTime, ScreenW, ScreenH);
	UpdateGroundDustAndEmbers(DeltaTime, ScreenW, ScreenH); // MEGA-7

	DrawBackgroundMedia(ScreenW, ScreenH);
	DrawSandParticles();
	DrawGroundFogBands(ScreenW, ScreenH); // MEGA-7: back layer first.
	DrawGroundDustAndEmbers(ScreenW, ScreenH); // MEGA-7
	DrawScanlinesAndVignette(ScreenW, ScreenH);

	float MouseX = 0.f, MouseY = 0.f;
	bool bJustClicked = false;
	if (APlayerController* PC = GetOwningPlayerController())
	{
		PC->GetMousePosition(MouseX, MouseY);
		bJustClicked = PC->WasInputKeyJustPressed(EKeys::LeftMouseButton);

		if (bIsEditingPlayerName)
		{
			if (PC->WasInputKeyJustPressed(EKeys::Enter))
			{
				if (USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(this))
				{
					if (!CustomPlayerNameInput.TrimStartAndEnd().IsEmpty())
					{
						Prog->SetActivePlayerName(CustomPlayerNameInput.TrimStartAndEnd());
					}
				}
				bIsEditingPlayerName = false;
			}
			else if (PC->WasInputKeyJustPressed(EKeys::Escape))
			{
				bIsEditingPlayerName = false;
			}
			else if (PC->WasInputKeyJustPressed(EKeys::F2) || PC->WasInputKeyJustPressed(EKeys::Tab))
			{
				bKeyboardLanguageFarsi = !bKeyboardLanguageFarsi;
			}
			else if (PC->WasInputKeyJustPressed(EKeys::BackSpace))
			{
				if (CustomPlayerNameInput.Len() > 0)
				{
					CustomPlayerNameInput.RemoveAt(CustomPlayerNameInput.Len() - 1);
				}
			}
			else if (PC->WasInputKeyJustPressed(EKeys::SpaceBar))
			{
				if (CustomPlayerNameInput.Len() < 28)
				{
					CustomPlayerNameInput += TEXT(" ");
				}
			}
			else
			{
				const FKey KeyList[] = {
					EKeys::Q, EKeys::W, EKeys::E, EKeys::R, EKeys::T, EKeys::Y, EKeys::U, EKeys::I, EKeys::O, EKeys::P,
					EKeys::LeftBracket, EKeys::RightBracket,
					EKeys::A, EKeys::S, EKeys::D, EKeys::F, EKeys::G, EKeys::H, EKeys::J, EKeys::K, EKeys::L,
					EKeys::Semicolon, EKeys::Apostrophe,
					EKeys::Z, EKeys::X, EKeys::C, EKeys::V, EKeys::B, EKeys::N, EKeys::M,
					EKeys::Comma, EKeys::Slash,
					EKeys::Zero, EKeys::One, EKeys::Two, EKeys::Three, EKeys::Four,
					EKeys::Five, EKeys::Six, EKeys::Seven, EKeys::Eight, EKeys::Nine,
					EKeys::Underscore, EKeys::Hyphen
				};

				// Persian Keyboard Layout (ISIRI 2901 Standard Persian Keymap)
				const TCHAR PersianKeyChars[] = {
					0x0636, 0x0635, 0x062B, 0x0642, 0x0641, 0x063A, 0x0639, 0x0647, 0x062E, 0x062D, // ض ص ث ق ف غ ع ه خ ح
					0x062C, 0x0686,                                                                 // ج چ
					0x0634, 0x0633, 0x06CC, 0x0628, 0x0644, 0x0627, 0x062A, 0x0646, 0x0645,       // ش س ی ب ل ا ت ن م
					0x06A9, 0x06AF,                                                                 // ک گ
					0x0638, 0x0637, 0x0632, 0x0631, 0x0630, 0x062F, 0x067E,                         // ظ ط ز ر ذ د پ
					0x0648, 0x0698,                                                                 // و ژ
					0x06F0, 0x06F1, 0x06F2, 0x06F3, 0x06F4,                                         // ۰ ۱ ۲ ۳ ۴
					0x06F5, 0x06F6, 0x06F7, 0x06F8, 0x06F9,                                         // ۵ ۶ ۷ ۸ ۹
					TEXT('_'), TEXT('-')
				};

				// English Keymap
				const TCHAR EnglishKeyChars[] = {
					TEXT('Q'), TEXT('W'), TEXT('E'), TEXT('R'), TEXT('T'), TEXT('Y'), TEXT('U'), TEXT('I'), TEXT('O'), TEXT('P'),
					TEXT('['), TEXT(']'),
					TEXT('A'), TEXT('S'), TEXT('D'), TEXT('F'), TEXT('G'), TEXT('H'), TEXT('J'), TEXT('K'), TEXT('L'),
					TEXT(';'), 0x0027,
					TEXT('Z'), TEXT('X'), TEXT('C'), TEXT('V'), TEXT('B'), TEXT('N'), TEXT('M'),
					TEXT(','), TEXT('/'),
					TEXT('0'), TEXT('1'), TEXT('2'), TEXT('3'), TEXT('4'),
					TEXT('5'), TEXT('6'), TEXT('7'), TEXT('8'), TEXT('9'),
					TEXT('_'), TEXT('-')
				};

				for (int32 ki = 0; ki < UE_ARRAY_COUNT(KeyList); ++ki)
				{
					if (PC->WasInputKeyJustPressed(KeyList[ki]) && CustomPlayerNameInput.Len() < 28)
					{
						const bool bUsePersianInput = bKeyboardLanguageFarsi && !!CachedMenuSettings.LanguageCode.StartsWith(TEXT("fa"), ESearchCase::IgnoreCase);
							const TCHAR TargetChar = bUsePersianInput ? PersianKeyChars[ki] : EnglishKeyChars[ki];
						CustomPlayerNameInput.AppendChar(TargetChar);
						break;
					}
				}
			}
		}
	}

	ClickableButtons.Empty();

	if (MenuState != EMainMenuState::Main)
	{
		// AAA-MM-2: cinematic command-header strip for submenu screens only.
		// AAA-MW-1: the main menu now owns its own COD-style top profile bar, so the old
		// global Farsi title/telemetry overlay is intentionally skipped on Main.
		const float HeaderX = 44.f * UIScale;
		const float HeaderY = 18.f * UIScale;
		const float HeaderH = 66.f * UIScale;
		DrawRect(FLinearColor(0.0f, 0.0f, 0.0f, 0.34f), 0.f, 0.f, ScreenW, HeaderH + 18.f * UIScale);
		DrawRect(FLinearColor(0.06f, 0.08f, 0.10f, 0.42f), HeaderX - 14.f * UIScale, HeaderY - 5.f * UIScale, 610.f * UIScale, HeaderH);
		DrawRect(PrimaryAccentColor, HeaderX - 2.f * UIScale, HeaderY + 4.f * UIScale, 4.f * UIScale, 38.f * UIScale);
		DrawFarsiText(MenuTextConfig.GameTitle.ToString(), PrimaryAccentColor, HeaderX + 14.f * UIScale, HeaderY, TitleFont ? TitleFont.Get() : nullptr, 1.28f * UIScale, true);
		DrawFarsiText(MenuTextConfig.GameSubtitle.ToString(), FLinearColor(0.84f, 0.88f, 0.90f, 0.92f), HeaderX + 14.f * UIScale, HeaderY + 31.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.82f * UIScale, true);
		DrawLine(42.f * UIScale, HeaderH + 14.f * UIScale, ScreenW - (42.f * UIScale), HeaderH + 14.f * UIScale, PrimaryAccentColor * 0.48f, 1.2f);
	}

	switch (MenuState)
	{
	case EMainMenuState::Main:
		DrawMainMenuScreen(ScreenW, ScreenH, MouseX, MouseY);
		break;
	case EMainMenuState::MapSelect:
		DrawMapSelectScreen(ScreenW, ScreenH, MouseX, MouseY);
		break;
	case EMainMenuState::PlayerProgression:
		DrawPlayerProgressionScreen(ScreenW, ScreenH, MouseX, MouseY);
		break;
	case EMainMenuState::PlayerProfile:
		DrawPlayerProfileScreen(ScreenW, ScreenH, MouseX, MouseY);
		break;
	case EMainMenuState::Armory:
		DrawArmoryScreen(ScreenW, ScreenH, MouseX, MouseY);
		break;
	case EMainMenuState::Achievements:
		DrawAchievementsScreen(ScreenW, ScreenH, MouseX, MouseY);
		break;
	case EMainMenuState::NewGameDifficulty:
		DrawDifficultyScreen(ScreenW, ScreenH, MouseX, MouseY);
		break;
	case EMainMenuState::LoadGame:
		DrawLoadGameScreen(ScreenW, ScreenH, MouseX, MouseY);
		break;
	case EMainMenuState::Settings:
		DrawSettingsScreen(ScreenW, ScreenH, MouseX, MouseY);
		break;
	case EMainMenuState::TacticalBriefing:
		DrawTacticalBriefingScreen(ScreenW, ScreenH, MouseX, MouseY);
		break;
	case EMainMenuState::RelicCollection:
		DrawRelicCollectionScreen(ScreenW, ScreenH, MouseX, MouseY);
		break;
	default:
		DrawMainMenuScreen(ScreenW, ScreenH, MouseX, MouseY);
		break;
	}

	if (HoveredButtonIndex != -1 && HoveredButtonIndex != LastHoveredButtonID)
	{
		if (ButtonHoverSound)
		{
			UGameplayStatics::PlaySound2D(this, ButtonHoverSound);
		}
		LastHoveredButtonID = HoveredButtonIndex;
	}
	else if (HoveredButtonIndex == -1)
	{
		LastHoveredButtonID = -1;
	}

	// MEGA-8: full-screen ease on menu-state change (quadratic fade, 350ms).
	if (!bMenuDrawInitialized || MenuState != LastDrawnMenuState) { LastDrawnMenuState = MenuState; ScreenFadeT = 0.f; bMenuDrawInitialized = true; }
	ScreenFadeT += DeltaTime;
	if (ScreenFadeT < 0.35f)
	{
		const float FA = 0.45f * (1.f - ScreenFadeT / 0.35f);
		DrawRect(FLinearColor(0.f, 0.f, 0.f, FA * FA), 0.f, 0.f, ScreenW, ScreenH);
	}
	if (MenuState != EMainMenuState::Main) { DrawMenuFilmGrain(ScreenW, ScreenH); } // AAA-MW-9: no grain/pixel squares over main menu.

	if (bJustClicked)
	{
		ProcessClickAtMousePosition(MouseX, MouseY);
	}

	// S16-INTRO: clearing smoke draws over the finished menu.
	DrawIntroSmokeOverlay(ScreenW, ScreenH);
}
// =============================================================================
//  1. MAIN MENU SCREEN (AAA CATEGORIZED TACTICAL LAYOUT)
// =============================================================================

void ASquadAIMainMenuHUD::DrawMainMenuScreen(float ScreenW, float ScreenH, float MouseX, float MouseY)
{
	const bool bMenuEnglish = !CachedMenuSettings.LanguageCode.StartsWith(TEXT("fa"), ESearchCase::IgnoreCase);
	// AAA-MW-15: main menu structure now follows the attached reference using
	// normalized X/Y coordinates instead of the old height-only 1080 scaling.
	const float RefX = ScreenW / 1600.f;
	const float RefY = ScreenH / 768.f;
	// AAA-MW-20: use the same reference scale family for strokes/text. The earlier
	// 1080-based scale made small bottom buttons unreadably tiny once the layout was
	// rebuilt around the 1600x768 reference grid.
	const float UIScale = FMath::Clamp(FMath::Min(RefX, RefY), 0.70f, 1.35f);
	// AAA-MW-21: clean shade mode. User liked the sampled color system but rejected
	// scattered slash/dust-looking lines, so all decorative random/hatch/sweep lines
	// in the main menu are disabled while ramps, depth, and real borders remain.
	const bool bCleanMenuDecor = true;
	HoveredButtonIndex = -1;

	USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(this);
	USquadAISaveLoadSubsystem* SaveSys = USquadAISaveLoadSubsystem::Get(this);
	const FSquadPlayerProfile Prof = Prog ? Prog->GetActiveProfile() : FSquadPlayerProfile();
	const bool bHasSave = SaveSys ? SaveSys->HasAnySaveGames() : false;
	const int32 PLevel = FMath::Max(1, Prof.PlayerLevel);
	const int32 TotalXP = FMath::Max(0, Prof.TotalXP);
	const int32 XPGoal = FMath::Max(12000, TotalXP + 1);
	const float LevelFrac = Prog ? FMath::Clamp(Prog->GetLevelProgressFraction(), 0.f, 1.f) : 0.54f;
	const int32 EnemiesHunted = Prof.EnemiesEliminated > 0 ? Prof.EnemiesEliminated : Prof.EnemiesHunted;

	// AAA-MW-13: exact sampled palette from the attached reference, not eye-balled.
	// Key samples: panel #1E1D1C, selected row #1D1B17, deep black #010101,
	// brass mean #AB7847, gold text #D3AB55, bright edge #E7B756, subtitle #9A9B9C.
	const FLinearColor RefDeepBlack = SquadAIRefSRGBA(0x01, 0x01, 0x01, 1.f);
	const FLinearColor RefPanelFill = SquadAIRefSRGBA(0x1E, 0x1D, 0x1C, 1.f);
	const FLinearColor RefPanelSelected = SquadAIRefSRGBA(0x1D, 0x1B, 0x17, 1.f);
	const FLinearColor RefPanelWarm = SquadAIRefSRGBA(0x3A, 0x2C, 0x18, 1.f);
	const FLinearColor RefFire = SquadAIRefSRGBA(0xA4, 0x63, 0x4A, 1.f);
	const FLinearColor RefGoldDeep = SquadAIRefSRGBA(0x77, 0x55, 0x26, 1.f);
	const FLinearColor RefGoldMid = SquadAIRefSRGBA(0xAB, 0x78, 0x47, 1.f);
	const FLinearColor RefGoldText = SquadAIRefSRGBA(0xD3, 0xAB, 0x55, 1.f);
	const FLinearColor RefGoldBright = SquadAIRefSRGBA(0xE7, 0xB7, 0x56, 1.f);
	const FLinearColor RefQuickDark = SquadAIRefSRGBA(0x40, 0x30, 0x1B, 1.f);
	const FLinearColor RefQuickBronze = SquadAIRefSRGBA(0x6B, 0x4C, 0x25, 1.f);
	const FLinearColor RefPanelCool = SquadAIRefSRGBA(0x10, 0x11, 0x11, 1.f);
	const FLinearColor RefPanelLow = SquadAIRefSRGBA(0x0B, 0x09, 0x0B, 1.f);
	const FLinearColor RefPanelSmoke = SquadAIRefSRGBA(0x3A, 0x36, 0x33, 1.f);
	const FLinearColor RefLabelBright = SquadAIRefSRGBA(0xEB, 0xCB, 0x88, 1.f);
	const FLinearColor RefCoolGlint = SquadAIRefSRGBA(0xC8, 0xCB, 0xCC, 1.f);
	const FLinearColor RefHotSpark = SquadAIRefSRGBA(0xFA, 0xC7, 0x67, 1.f);
	const FLinearColor RefWarningRed = SquadAIRefSRGBA(0x8A, 0x3F, 0x2D, 1.f);
	const FLinearColor RefActiveGreen = SquadAIRefSRGBA(0x14, 0xC8, 0x19, 1.f);
	const FLinearColor Brass = RefGoldMid;
	const FLinearColor BrassSoft = SquadAIRefSRGBA(0x9B, 0x79, 0x4D, 0.90f);
	const FLinearColor BrassDim = SquadAIRefSRGBA(0x77, 0x55, 0x26, 0.62f);
	const FLinearColor TextBright = SquadAIRefSRGBA(0xF8, 0xF8, 0xF8, 0.99f);
	const FLinearColor TextMuted = SquadAIRefSRGBA(0x9A, 0x9B, 0x9C, 0.92f);
	const FLinearColor PanelBlack = SquadAIRefSRGBA(0x1E, 0x1D, 0x1C, 0.58f);
	auto RefAlpha = [](FLinearColor C, float A) -> FLinearColor { C.A = A; return C; };
	const float MenuAnimTime = bReducedMenuMotion ? 0.f : MasterTime;
	auto RefMix = [](const FLinearColor& A, const FLinearColor& B, float T) -> FLinearColor
	{
		const float S = FMath::Clamp(T, 0.f, 1.f);
		return FLinearColor(
			FMath::Lerp(A.R, B.R, S),
			FMath::Lerp(A.G, B.G, S),
			FMath::Lerp(A.B, B.B, S),
			FMath::Lerp(A.A, B.A, S));
	};
	auto DrawSampledVerticalRamp = [&](float X, float Y, float W, float H, const FLinearColor& Top, const FLinearColor& Mid, const FLinearColor& Bottom, float Alpha, int32 SliceCount)
	{
		const int32 Count = FMath::Max(1, SliceCount);
		for (int32 Slice = 0; Slice < Count; ++Slice)
		{
			const float T0 = static_cast<float>(Slice) / static_cast<float>(Count);
			const float T1 = static_cast<float>(Slice + 1) / static_cast<float>(Count);
			const float TMid = (T0 + T1) * 0.5f;
			FLinearColor C = (TMid < 0.52f) ? RefMix(Top, Mid, TMid / 0.52f) : RefMix(Mid, Bottom, (TMid - 0.52f) / 0.48f);
			C.A = Alpha;
			DrawRect(C, X, Y + H * T0, W, H * (T1 - T0) + 1.f);
		}
	};
	auto DrawSampledHorizontalRamp = [&](float X, float Y, float W, float H, const FLinearColor& Left, const FLinearColor& Mid, const FLinearColor& Right, float Alpha, int32 SliceCount)
	{
		const int32 Count = FMath::Max(1, SliceCount);
		for (int32 Slice = 0; Slice < Count; ++Slice)
		{
			const float T0 = static_cast<float>(Slice) / static_cast<float>(Count);
			const float T1 = static_cast<float>(Slice + 1) / static_cast<float>(Count);
			const float TMid = (T0 + T1) * 0.5f;
			FLinearColor C = (TMid < 0.50f) ? RefMix(Left, Mid, TMid / 0.50f) : RefMix(Mid, Right, (TMid - 0.50f) / 0.50f);
			C.A = Alpha;
			DrawRect(C, X + W * T0, Y, W * (T1 - T0) + 1.f, H);
		}
	};
	// AAA-MW-27: no side/background rectangle washes. The current screenshot still
	// showed hard vertical boundaries; all main-background darkening is limited to
	// the top and bottom gradient plates below.

	// Restore only the top and bottom cinematic black highlights. Prefer smooth
	// PNG gradients so the fade has no Canvas slice seams/lines.
	const float TopShadeH = 170.f * UIScale;
	const float BottomShadeH = 250.f * UIScale;
	if (MenuTopBlackGradientTexture && MenuBottomBlackGradientTexture)
	{
		DrawTexture(MenuTopBlackGradientTexture, 0.f, 0.f, ScreenW, TopShadeH, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
		DrawTexture(MenuBottomBlackGradientTexture, 0.f, ScreenH - BottomShadeH, ScreenW, BottomShadeH, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
	}
	else
	{
		for (int32 ShadeSlice = 0; ShadeSlice < 72; ++ShadeSlice)
		{
			const float T0 = static_cast<float>(ShadeSlice) / 72.f;
			const float T1 = static_cast<float>(ShadeSlice + 1) / 72.f;
			const float TMid = (T0 + T1) * 0.5f;
			const float TopAlpha = 0.50f * FMath::Pow(1.f - TMid, 2.25f);
			const float BottomAlpha = 0.58f * FMath::Pow(TMid, 2.05f);
			DrawRect(RefAlpha(RefDeepBlack, TopAlpha), 0.f, TopShadeH * T0, ScreenW, TopShadeH * (T1 - T0) + 2.f);
			DrawRect(RefAlpha(RefDeepBlack, BottomAlpha), 0.f, ScreenH - BottomShadeH + BottomShadeH * T0, ScreenW, BottomShadeH * (T1 - T0) + 2.f);
		}
	}

	// AAA-MW-27: remove all hard-edged color rectangles over the main background.
	// They were visible as large square/box boundaries in the current screenshot.
	// Atmosphere now comes only from the background art, soft dust sprites, and the
	// top/bottom black gradient plates.

	// A second dust pass after the top/bottom highlights makes the approved soft
	// dust visible again, while still keeping it behind all panels/buttons.
	if (MenuState == EMainMenuState::Main)
	{
		if (MenuDustHazeBandTexture)
		{
			const float Drift = bReducedMenuMotion ? 0.f : FMath::Sin(MenuAnimTime * 0.065f + 1.2f) * 28.f;
			DrawTexture(MenuDustHazeBandTexture, -70.f + Drift, ScreenH * 0.52f, ScreenW + 140.f, ScreenH * 0.34f, 0.f, 0.f, 1.f, 1.f, FLinearColor(1.f, 0.94f, 0.82f, 0.72f));
		}
		if (MenuSoftDustTexture)
		{
			for (const FSquadMenuParticle& P : GroundDust)
			{
				const float NormalizedLife = P.LifeTime / FMath::Max(0.01f, P.MaxLifeTime);
				const float Fade = (NormalizedLife < 0.18f) ? (NormalizedLife / 0.18f) : (NormalizedLife > 0.82f ? ((1.0f - NormalizedLife) / 0.18f) : 1.0f);
				const float Size = FMath::Clamp(P.Size * 18.0f, 24.f, 116.f);
				FLinearColor C(FMath::Max(P.Color.R, 0.68f), FMath::Max(P.Color.G, 0.56f), FMath::Max(P.Color.B, 0.40f), 1.f);
				C.A = FMath::Clamp(P.Alpha * Fade * 1.62f, 0.f, 0.50f);
				DrawTexture(MenuSoftDustTexture, P.Position.X - Size * 0.5f, P.Position.Y - Size * 0.5f, Size, Size, 0.f, 0.f, 1.f, 1.f, C);
			}
		}
		if (MenuSoftEmberTexture)
		{
			for (const FSquadMenuParticle& P : EmberSparks)
			{
				const float NormalizedLife = P.LifeTime / FMath::Max(0.01f, P.MaxLifeTime);
				const float Fade = (NormalizedLife < 0.20f) ? (NormalizedLife / 0.20f) : (NormalizedLife > 0.78f ? ((1.0f - NormalizedLife) / 0.22f) : 1.0f);
				const float Size = FMath::Clamp(P.Size * 12.5f, 12.f, 44.f);
				FLinearColor C = RefAlpha(RefHotSpark, FMath::Clamp(P.Alpha * Fade * 0.92f, 0.f, 0.38f));
				DrawTexture(MenuSoftEmberTexture, P.Position.X - Size * 0.5f, P.Position.Y - Size * 0.5f, Size, Size, 0.f, 0.f, 1.f, 1.f, C);
			}
		}
	}

	auto DrawReferencePanel = [&](float X, float Y, float W, float H, bool bHot, float AlphaBoost)
	{
		const float Cut = 9.f * UIScale;
		const float BaseA = FMath::Clamp(PanelBlack.A + 0.13f + AlphaBoost + (bHot ? 0.10f : 0.f), 0.f, 0.92f);

		// Clean AAA shade system: layered shadows + sampled material ramps, but no
		// random decorative slashes/hatches inside the panels.
		if (!bCleanMenuDecor)
		{
			// Reserved for future non-clean decorators; intentionally empty now.
		}
		DrawRect(RefAlpha(RefDeepBlack, 0.22f), X + 10.f * UIScale, Y + 11.f * UIScale, W, H);
		DrawRect(RefAlpha(RefDeepBlack, 0.36f), X + 4.f * UIScale, Y + 5.f * UIScale, W, H);
		if (MenuPanel3DPlateTexture)
		{
			// Smooth PNG material plate: no internal Canvas rectangles/slice seams.
			DrawTexture(MenuPanel3DPlateTexture, X, Y, W, H, 0.f, 0.f, 1.f, 1.f, RefAlpha(FLinearColor::White, BaseA + (bHot ? 0.035f : 0.f)));
		}
		else
		{
			DrawSampledVerticalRamp(X, Y, W, H, RefPanelFill, RefPanelCool, RefPanelLow, BaseA, 10);
			// Do not cross full-width horizontal and vertical ramp slices: on screen that
			// reads as graph-paper squares. Use broad material plates and edge glows instead.
			DrawRect(RefAlpha(RefPanelWarm, bHot ? 0.040f : 0.020f), X, Y, W * 0.46f, H);
			DrawRect(RefAlpha(RefPanelSmoke, bHot ? 0.030f : 0.014f), X + W * 0.18f, Y + 2.f * UIScale, W * 0.64f, FMath::Max(1.f, H * 0.30f));
			DrawRect(RefAlpha(RefDeepBlack, 0.30f), X, Y + H * 0.54f, W, H * 0.46f);
			DrawRect(RefAlpha(bHot ? RefGoldText : RefPanelSmoke, bHot ? 0.045f : 0.022f), X + 4.f * UIScale, Y + 4.f * UIScale, FMath::Max(1.f, W - 8.f * UIScale), FMath::Max(1.f, H * 0.18f));
		}

		const FLinearColor Edge = bHot ? Brass : BrassDim;
		const float HotStroke = bHot ? 1.55f : 0.95f;
		DrawLine(X + Cut, Y, X + W - Cut, Y, Edge, HotStroke);
		DrawLine(X + W - Cut, Y, X + W, Y + Cut, Edge, HotStroke);
		DrawLine(X + W, Y + Cut, X + W, Y + H - Cut, Edge * 0.82f, bHot ? 1.16f : 0.78f);
		DrawLine(X + W, Y + H - Cut, X + W - Cut, Y + H, Edge * 0.66f, bHot ? 1.08f : 0.70f);
		DrawLine(X + W - Cut, Y + H, X + Cut, Y + H, Edge * 0.52f, bHot ? 1.00f : 0.64f);
		DrawLine(X + Cut, Y + H, X, Y + H - Cut, Edge * 0.50f, bHot ? 1.00f : 0.64f);
		DrawLine(X, Y + H - Cut, X, Y + Cut, Edge * 0.72f, bHot ? 1.08f : 0.72f);
		DrawLine(X, Y + Cut, X + Cut, Y, Edge, HotStroke);

		// Inner top/bottom shade lines only; no diagonal, no random strokes.
		const float Inset = 5.f * UIScale;
		DrawLine(X + Cut + Inset, Y + Inset, X + W - Cut - Inset, Y + Inset, RefAlpha(RefGoldBright, bHot ? 0.15f : 0.070f), 0.62f);
		DrawLine(X + W - Cut - Inset, Y + H - Inset, X + Cut + Inset, Y + H - Inset, RefAlpha(RefDeepBlack, 0.54f), 0.78f);
	};

	auto DrawPanelAngledMicroLines = [&](float X, float Y, float W, float H, float Intensity)
	{
		// AAA-MW-21: disabled. These small slash/tick details were perceived as random
		// dust/scratch lines across the UI. Panel beauty now comes from shade ramps only.
		(void)X;
		(void)Y;
		(void)W;
		(void)H;
		(void)Intensity;
	};

	auto DrawReferenceProgress = [&](float X, float Y, float W, float H, float Fraction, bool bWarningLead)
	{
		const float F = FMath::Clamp(Fraction, 0.f, 1.f);
		DrawSampledVerticalRamp(X, Y, W, H, RefPanelSmoke, RefPanelCool, RefDeepBlack, 0.82f, 4);
		DrawLine(X, Y, X + W, Y, RefAlpha(RefGoldBright, 0.14f), 0.75f);
		DrawLine(X, Y + H, X + W, Y + H, RefAlpha(RefDeepBlack, 0.70f), 0.85f);
		const float FillW = W * F;
		if (FillW > 1.f)
		{
			DrawSampledHorizontalRamp(X, Y, FillW, H, RefGoldBright, RefGoldText, RefGoldDeep, 0.96f, 12);
			DrawRect(RefAlpha(RefGoldBright, 0.30f), X, Y, FillW, FMath::Max(1.f, H * 0.30f));
			DrawLine(X + FillW, Y - 1.f * UIScale, X + FillW, Y + H + 1.f * UIScale, RefAlpha(RefGoldBright, 0.42f), 0.75f);
			DrawLine(X + FillW + 2.f * UIScale, Y, X + FillW + 2.f * UIScale, Y + H, RefAlpha(RefDeepBlack, 0.45f), 0.65f);
			if (bWarningLead)
			{
				DrawSampledHorizontalRamp(X, Y, FMath::Min(FillW, W * 0.20f), H, RefFire, RefWarningRed, RefGoldDeep, 0.90f, 5);
			}
		}
	};

	auto GetMainMenuIconTexture = [&](int32 ID) -> UTexture2D*
	{
		switch (ID)
		{
		case 1: return MenuIconStartTexture.Get();
		case 2: return MenuIconOperationsTexture.Get();
		case 3: return MenuIconArmoryTexture.Get();
		case 4: return MenuIconProgressionTexture.Get();
		case 5: return MenuIconProfileTexture.Get();
		case 6: return MenuIconRecordsTexture.Get();
		case 9: return MenuIconSettingsTexture.Get();
		case 11: return MenuIconExitTexture.Get();
		default: return nullptr;
		}
	};

	auto DrawIconWell = [&](int32 ID, float X, float Y, float S, bool bHot)
	{
		const FLinearColor IconColor = bHot ? Brass : BrassSoft;
		const FLinearColor IconDim = IconColor * 0.55f;
		const float Cx = X + S * 0.5f;
		const float Cy = Y + S * 0.5f;
		const float R = S * 0.31f;
		const float Stroke = (bHot ? 2.35f : 1.85f) * UIScale;

		// Dedicated icon cell: beveled, readable, and more "AAA" than flat glyph text.
		DrawRect(RefAlpha(RefDeepBlack, 0.64f), X, Y, S, S);
		DrawRect(RefAlpha(RefGoldDeep, bHot ? 0.20f : 0.09f), X, Y, S, S);
		DrawLine(X + 7.f * UIScale, Y, X + S, Y, IconColor * 0.52f, 1.0f * UIScale);
		DrawLine(X, Y + 7.f * UIScale, X + 7.f * UIScale, Y, IconColor * 0.52f, 1.0f * UIScale);
		DrawLine(X + S, Y + 7.f * UIScale, X + S, Y + S - 7.f * UIScale, BrassDim, 1.0f * UIScale);
		DrawLine(X + S - 7.f * UIScale, Y + S, X, Y + S, IconColor * 0.34f, 0.9f * UIScale);

		if (UTexture2D* IconTex = GetMainMenuIconTexture(ID))
		{
			const float Pad = 4.f * UIScale;
			const FLinearColor Tint = FLinearColor::White; // icon PNGs already use exact sampled reference gold
			DrawTexture(IconTex, X + Pad, Y + Pad, S - 2.f * Pad, S - 2.f * Pad, 0.f, 0.f, 1.f, 1.f, Tint);
			return;
		}

		if (ID == 1) // operation compass / launch
		{
			DrawLine(Cx, Cy - R * 1.18f, Cx + R * 0.30f, Cy - R * 0.22f, IconColor, Stroke);
			DrawLine(Cx + R * 0.30f, Cy - R * 0.22f, Cx + R * 1.05f, Cy, IconColor, Stroke);
			DrawLine(Cx + R * 1.05f, Cy, Cx + R * 0.30f, Cy + R * 0.22f, IconColor, Stroke);
			DrawLine(Cx + R * 0.30f, Cy + R * 0.22f, Cx, Cy + R * 1.18f, IconColor, Stroke);
			DrawLine(Cx, Cy + R * 1.18f, Cx - R * 0.30f, Cy + R * 0.22f, IconColor, Stroke);
			DrawLine(Cx - R * 0.30f, Cy + R * 0.22f, Cx - R * 1.05f, Cy, IconColor, Stroke);
			DrawLine(Cx - R * 1.05f, Cy, Cx - R * 0.30f, Cy - R * 0.22f, IconColor, Stroke);
			DrawLine(Cx - R * 0.30f, Cy - R * 0.22f, Cx, Cy - R * 1.18f, IconColor, Stroke);
			DrawLine(Cx - R * 0.52f, Cy, Cx + R * 0.52f, Cy, IconDim, 1.15f * UIScale);
			DrawLine(Cx, Cy - R * 0.52f, Cx, Cy + R * 0.52f, IconDim, 1.15f * UIScale);
		}
		else if (ID == 2) // shield / operations
		{
			DrawLine(Cx, Cy - R, Cx + R * 0.80f, Cy - R * 0.40f, IconColor, Stroke);
			DrawLine(Cx + R * 0.80f, Cy - R * 0.40f, Cx + R * 0.56f, Cy + R * 0.66f, IconColor, Stroke);
			DrawLine(Cx + R * 0.56f, Cy + R * 0.66f, Cx, Cy + R * 1.06f, IconColor, Stroke);
			DrawLine(Cx, Cy + R * 1.06f, Cx - R * 0.56f, Cy + R * 0.66f, IconColor, Stroke);
			DrawLine(Cx - R * 0.56f, Cy + R * 0.66f, Cx - R * 0.80f, Cy - R * 0.40f, IconColor, Stroke);
			DrawLine(Cx - R * 0.80f, Cy - R * 0.40f, Cx, Cy - R, IconColor, Stroke);
			DrawLine(Cx, Cy - R * 0.68f, Cx, Cy + R * 0.74f, IconDim, 1.1f * UIScale);
			DrawLine(Cx - R * 0.42f, Cy - R * 0.22f, Cx + R * 0.42f, Cy - R * 0.22f, IconDim, 1.1f * UIScale);
		}
		else if (ID == 3) // period rifle silhouette / armory
		{
			DrawLine(X + S * 0.20f, Cy + S * 0.08f, X + S * 0.76f, Cy - S * 0.12f, IconColor, Stroke + 0.3f * UIScale);
			DrawLine(X + S * 0.15f, Cy + S * 0.16f, X + S * 0.30f, Cy + S * 0.03f, IconColor, Stroke);
			DrawLine(X + S * 0.71f, Cy - S * 0.12f, X + S * 0.88f, Cy - S * 0.15f, IconColor, 1.4f * UIScale);
			DrawLine(X + S * 0.36f, Cy + S * 0.01f, X + S * 0.48f, Cy + S * 0.21f, IconDim, 1.8f * UIScale);
			DrawLine(X + S * 0.45f, Cy - S * 0.02f, X + S * 0.55f, Cy - S * 0.14f, IconDim, 1.2f * UIScale);
		}
		else if (ID == 4) // rank/progression chevrons
		{
			for (int32 k = 0; k < 3; ++k)
			{
				const float yy = Cy + (k - 1) * 8.5f * UIScale;
				DrawLine(Cx - R * 0.86f, yy + R * 0.33f, Cx, yy - R * 0.34f, IconColor, Stroke);
				DrawLine(Cx, yy - R * 0.34f, Cx + R * 0.86f, yy + R * 0.33f, IconColor, Stroke);
			}
			DrawLine(Cx - R * 0.56f, Cy + R * 1.02f, Cx + R * 0.56f, Cy + R * 1.02f, IconDim, 1.1f * UIScale);
		}
		else if (ID == 5) // dossier / profile
		{
			const float L = X + S * 0.25f;
			const float Rgt = X + S * 0.76f;
			const float T = Y + S * 0.20f;
			const float B = Y + S * 0.78f;
			DrawLine(L, T, Rgt - S * 0.12f, T, IconColor, Stroke);
			DrawLine(Rgt - S * 0.12f, T, Rgt, T + S * 0.12f, IconColor, Stroke);
			DrawLine(Rgt, T + S * 0.12f, Rgt, B, IconColor, Stroke);
			DrawLine(Rgt, B, L, B, IconColor, Stroke);
			DrawLine(L, B, L, T, IconColor, Stroke);
			DrawLine(Cx - R * 0.22f, Cy - R * 0.14f, Cx + R * 0.22f, Cy - R * 0.14f, IconDim, 1.3f * UIScale);
			DrawLine(Cx - R * 0.35f, Cy + R * 0.26f, Cx + R * 0.35f, Cy + R * 0.26f, IconDim, 1.3f * UIScale);
		}
		else if (ID == 6) // records / achievement graph
		{
			const float Base = Y + S * 0.76f;
			DrawLine(X + S * 0.22f, Base, X + S * 0.82f, Base, IconColor, 1.2f * UIScale);
			DrawRect(IconColor * 0.72f, X + S * 0.25f, Base - S * 0.20f, S * 0.10f, S * 0.20f);
			DrawRect(IconColor * 0.82f, X + S * 0.44f, Base - S * 0.36f, S * 0.10f, S * 0.36f);
			DrawRect(IconColor * 0.92f, X + S * 0.63f, Base - S * 0.52f, S * 0.10f, S * 0.52f);
			DrawLine(X + S * 0.25f, Base - S * 0.42f, X + S * 0.44f, Base - S * 0.55f, IconDim, 1.0f * UIScale);
			DrawLine(X + S * 0.44f, Base - S * 0.55f, X + S * 0.73f, Base - S * 0.68f, IconDim, 1.0f * UIScale);
		}
		else if (ID == 9) // settings / engineered cog
		{
			const float R0 = S * 0.22f;
			const float R1 = S * 0.32f;
			float PrevX = Cx + R1;
			float PrevY = Cy;
			for (int32 k = 1; k <= 8; ++k)
			{
				const float A = (float)k * 0.785398f;
				const float RR = (k % 2 == 0) ? R1 : R0;
				const float Px = Cx + FMath::Cos(A) * RR;
				const float Py = Cy + FMath::Sin(A) * RR;
				DrawLine(PrevX, PrevY, Px, Py, IconColor, Stroke);
				PrevX = Px;
				PrevY = Py;
			}
			DrawLine(Cx - R0 * 0.45f, Cy, Cx + R0 * 0.45f, Cy, IconDim, 1.1f * UIScale);
			DrawLine(Cx, Cy - R0 * 0.45f, Cx, Cy + R0 * 0.45f, IconDim, 1.1f * UIScale);
		}
		else if (ID == 11) // exit
		{
			DrawLine(X + S * 0.28f, Y + S * 0.23f, X + S * 0.28f, Y + S * 0.77f, IconColor, Stroke);
			DrawLine(X + S * 0.28f, Y + S * 0.23f, X + S * 0.56f, Y + S * 0.23f, IconColor, Stroke);
			DrawLine(X + S * 0.28f, Y + S * 0.77f, X + S * 0.56f, Y + S * 0.77f, IconColor, Stroke);
			DrawLine(X + S * 0.42f, Cy, X + S * 0.79f, Cy, IconColor, Stroke);
			DrawLine(X + S * 0.79f, Cy, X + S * 0.63f, Cy - S * 0.14f, IconColor, Stroke);
			DrawLine(X + S * 0.79f, Cy, X + S * 0.63f, Cy + S * 0.14f, IconColor, Stroke);
		}
	};


	auto DrawMainButton = [&](int32 ID, float X, float Y, float W, float H, const FString& Label, const FString& Subtitle, bool bPrimary)
	{
		const float HoverExtW = 54.f * UIScale;
		const bool bHover = (MouseX >= X && MouseX <= X + W + HoverExtW && MouseY >= Y && MouseY <= Y + H);
		if (bHover) HoveredButtonIndex = ID;
		RegisterButton(ID, X, Y, W + HoverExtW, H, FText::FromString(Label));

		float& Ramp = ButtonHoverRamp.FindOrAdd(FString::Printf(TEXT("AAA_MW21_%d_%s"), ID, *Label));
		Ramp = FMath::FInterpTo(Ramp, bHover ? 1.f : 0.f, LastFrameDelta, 13.f);
		const bool bSelected = bPrimary;
		const float IconW = 70.f * UIScale;
		const float Cut = 11.f * UIScale;
		const float Hot = FMath::Clamp(Ramp + (bSelected ? 1.f : 0.f), 0.f, 1.f);
		const float BodyX = X + IconW;
		const float BodyW = W - IconW;

		// AAA-MW-29: old-system left button material plates. The hover texture includes
		// the right-side appearing slab, fading rails, and aesthetic square foundation.
		// Existing Canvas rail/node/text overlays remain for crisp scaling.
		const float PlateExt = bHover ? (50.f * UIScale * FMath::Clamp(Ramp, 0.f, 1.f)) : 0.f;
		bool bDrewLeftButtonPlate = false;
		if (bHover && MenuLeftButtonHoverPlateTexture)
		{
			// The right-side extension appears only on true mouse hover, matching the old system.
			DrawTexture(MenuLeftButtonHoverPlateTexture, X, Y, W + PlateExt, H, 0.f, 0.f, 1.f, 1.f, RefAlpha(FLinearColor::White, FMath::Clamp(0.82f + 0.18f * Ramp, 0.f, 1.f)));
			bDrewLeftButtonPlate = true;
		}
		else if (MenuLeftButtonPlateTexture)
		{
			// Clean idle plate only. Do not add extra hard Canvas body rectangles on top.
			DrawTexture(MenuLeftButtonPlateTexture, X, Y, W, H, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
			bDrewLeftButtonPlate = true;
		}
		else
		{
			DrawRect(RefAlpha(RefDeepBlack, 0.26f), X + 5.f * UIScale, Y + 6.f * UIScale, W * 0.92f, H);
			if (bSelected)
			{
				DrawRect(RefAlpha(RefFire, 0.030f), X + IconW, Y + 4.f * UIScale, BodyW * 0.72f, H - 8.f * UIScale);
			}
			DrawRect(RefAlpha(RefDeepBlack, 0.68f + 0.08f * Hot), X, Y, IconW, H);
			DrawRect(RefAlpha(RefGoldDeep, 0.08f + 0.14f * Hot), X, Y, IconW, H);
			DrawSampledVerticalRamp(BodyX, Y, BodyW, H, RefPanelSelected, RefPanelCool, RefDeepBlack, 0.48f + 0.18f * Hot, 8);
			DrawRect(RefAlpha(RefGoldMid, 0.040f + 0.070f * Hot), BodyX, Y, BodyW, H * 0.44f);
			DrawRect(RefAlpha(RefDeepBlack, 0.070f), BodyX, Y + H * 0.58f, BodyW, H * 0.42f);
		}

			// AAA-MW-30: three contained old-style hover light sweeps. They move
			// left-to-right only inside the button body/extension, using one soft PNG
			// sprite so the effect reads as glow rather than random lines/scratches.
			if (bHover && MenuLeftHoverGlowTexture && !bReducedMenuMotion)
			{
				const float SweepW = 82.f * UIScale;
				const float SweepH = FMath::Max(1.f, H - 7.f * UIScale);
				const float SweepMinX = BodyX + 3.f * UIScale;
				const float SweepMaxX = FMath::Max(SweepMinX, X + W + PlateExt - SweepW - 8.f * UIScale);
				for (int32 SweepIndex = 0; SweepIndex < 3; ++SweepIndex)
				{
					const float Phase = FMath::Fmod(MenuAnimTime * 0.31f + static_cast<float>(SweepIndex) * 0.333f, 1.0f);
					const float SweepX = FMath::Lerp(SweepMinX, SweepMaxX, Phase);
					const float SweepAlpha = (0.15f + 0.035f * static_cast<float>(SweepIndex)) * Ramp;
					DrawTexture(MenuLeftHoverGlowTexture, SweepX, Y + 3.5f * UIScale, SweepW, SweepH, 0.f, 0.f, 1.f, 1.f, RefAlpha(FLinearColor::White, SweepAlpha));
				}
			}
		const FLinearColor Edge = FMath::Lerp(BrassDim, Brass, Hot);
		DrawLine(X + Cut, Y, X + IconW, Y, Edge, 1.25f + 0.25f * Hot);
		DrawLine(X, Y + Cut, X + Cut, Y, Edge, 1.25f + 0.25f * Hot);
		DrawLine(X, Y + H - Cut, X + Cut, Y + H, Edge * 0.62f, 0.95f + 0.18f * Hot);
		DrawLine(X + Cut, Y + H, X + IconW, Y + H, Edge * 0.58f, 0.95f + 0.18f * Hot);
		DrawLine(X, Y + Cut, X, Y + H - Cut, Edge * 0.68f, 0.90f + 0.16f * Hot);
		// Old-system divider: a gold line that fades out to the right; on hover it
		// becomes a stronger, cleaner solid rail with a small aesthetic square.
		const int32 FadeSegments = 16;
		for (int32 Seg = 0; Seg < FadeSegments; ++Seg)
		{
			const float T0 = static_cast<float>(Seg) / static_cast<float>(FadeSegments);
			const float T1 = static_cast<float>(Seg + 1) / static_cast<float>(FadeSegments);
			const float IdleA = FMath::Lerp(0.30f + 0.12f * Hot, 0.018f, T0);
			const float SolidA = 0.72f - 0.08f * T0;
			const float A = bHover ? SolidA : IdleA;
			DrawLine(BodyX + BodyW * T0, Y + 1.f * UIScale, BodyX + BodyW * T1, Y + 1.f * UIScale, RefAlpha(RefGoldBright, A), bHover ? 1.45f * UIScale : 0.78f * UIScale);
			DrawLine(BodyX + BodyW * T0, Y + H - 1.f * UIScale, BodyX + BodyW * T1, Y + H - 1.f * UIScale, RefAlpha(RefGoldDeep, A * 0.66f), bHover ? 1.12f * UIScale : 0.62f * UIScale);
		}
		if (bHover)
		{
			DrawLine(BodyX + 2.f * UIScale, Y + H * 0.50f, X + W - Cut - 8.f * UIScale, Y + H * 0.50f, RefAlpha(RefGoldBright, 0.26f), 1.1f * UIScale);
		}
		const float NodeS = bHover ? 8.f * UIScale : 6.f * UIScale;
		const float NodeX = X + W - 25.f * UIScale;
		const float NodeY = Y + H * 0.5f - NodeS * 0.5f;
		DrawRect(RefAlpha(RefGoldBright, bHover ? 0.78f : 0.34f), NodeX, NodeY, NodeS, NodeS);
		DrawRect(RefAlpha(RefDeepBlack, 0.52f), NodeX + NodeS * 0.38f, NodeY + NodeS * 0.38f, NodeS * 0.72f, NodeS * 0.72f);
		if (Hot > 0.01f)
		{
			// The PNG plates already contain the smooth activation body and right-side slab.
			// Fallback Canvas overlays remain only for missing/uncooked textures.
			if (!bDrewLeftButtonPlate)
			{
				DrawRect(RefAlpha(RefFire, 0.055f * Hot), BodyX, Y + 2.f * UIScale, BodyW, H - 4.f * UIScale);
				DrawRect(Brass * (0.14f + 0.16f * Hot), X, Y, 4.f * UIScale, H);
			}
			if (bHover && !bDrewLeftButtonPlate)
			{
				const float ExtW = 50.f * UIScale;
				const float ExtX = X + W - 9.f * UIScale;
				DrawRect(RefAlpha(RefDeepBlack, 0.44f * Ramp), ExtX + 6.f * UIScale, Y + 9.f * UIScale, ExtW, H - 18.f * UIScale);
				DrawRect(RefAlpha(RefGoldDeep, 0.20f * Ramp), ExtX, Y + 5.f * UIScale, ExtW, H - 10.f * UIScale);
				DrawRect(RefAlpha(RefGoldBright, 0.070f * Ramp), ExtX, Y + 5.f * UIScale, ExtW, (H - 10.f * UIScale) * 0.34f);
				DrawLine(ExtX + 4.f * UIScale, Y + 8.f * UIScale, ExtX + ExtW - 8.f * UIScale, Y + 8.f * UIScale, RefAlpha(RefGoldBright, 0.36f * Ramp), 0.95f * UIScale);
				DrawLine(ExtX + 4.f * UIScale, Y + H - 8.f * UIScale, ExtX + ExtW - 8.f * UIScale, Y + H - 8.f * UIScale, RefAlpha(RefDeepBlack, 0.64f * Ramp), 0.9f * UIScale);
				// A tiny right-facing bevel mark only at the far edge, preserving the old style.
				const float MarkX = X + W - 18.f * UIScale;
				const float MarkY = Y + H * 0.50f;
				DrawLine(MarkX - 5.f * UIScale, MarkY - 6.f * UIScale, MarkX, MarkY, RefAlpha(RefGoldBright, 0.34f * Ramp), 1.0f * UIScale);
				DrawLine(MarkX, MarkY, MarkX - 5.f * UIScale, MarkY + 6.f * UIScale, RefAlpha(RefGoldDeep, 0.30f * Ramp), 0.9f * UIScale);
			}
		}

		DrawIconWell(ID, X + 7.f * UIScale, Y + 7.f * UIScale, H - 14.f * UIScale, Hot > 0.20f);
		DrawLine(X + IconW, Y + 10.f * UIScale, X + IconW, Y + H - 10.f * UIScale, Edge * 0.62f, 0.85f);
		const float TextX = X + IconW + 22.f * UIScale;
		const float TextW = W - IconW - 54.f * UIScale;
		DrawFarsiTextBounded(Label, (Hot > 0.05f) ? RefLabelBright : TextBright, TextX, Y + 8.f * UIScale, TextW, MenuFont ? MenuFont.Get() : nullptr, (bSelected ? 1.12f : 1.02f) * UIScale, true, false);
		DrawFarsiTextBounded(Subtitle, TextMuted, TextX, Y + 39.f * UIScale, TextW, BodyFont ? BodyFont.Get() : nullptr, 0.78f * UIScale, true, false);
	};

	// Top-left operation / profile strip — restored after clean-artifact pass.
	const float ProfileX = 28.f * RefX;
	const float ProfileY = 15.f * RefY;
	const float Crest = 55.f * RefY;
	DrawReferencePanel(ProfileX - 3.f * UIScale, ProfileY - 3.f * UIScale, Crest + 6.f * UIScale, Crest + 6.f * UIScale, false, -0.16f);
	DrawLine(ProfileX + Crest + 8.f * UIScale, ProfileY + 6.f * UIScale, ProfileX + Crest + 8.f * UIScale, ProfileY + Crest - 6.f * UIScale, RefAlpha(RefGoldDeep, 0.22f), 0.65f);
	if (WatermarkEmblemTexture)
	{
		// P7-MM4: true logo colors — the Brass*0.95 multiply darkened/tinted the emblem
		// (the "shadowy" look). Full white tint, full opacity.
		DrawTexture(WatermarkEmblemTexture, ProfileX, ProfileY - 2.f * UIScale, Crest, Crest, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
	}
	else
	{
		DrawReferencePanel(ProfileX, ProfileY, Crest, Crest, false, 0.f);
		DrawFarsiTextBounded(TEXT("★"), Brass, ProfileX, ProfileY, Crest, TitleFont ? TitleFont.Get() : nullptr, 0.94f * UIScale, true, true, Crest);
	}
	const float TitleX = ProfileX + Crest + 16.f * UIScale;
	DrawFarsiTextBounded(bMenuEnglish ? TEXT("Operation Khuzestan | Secrets of Victory") : TEXT("عملیات خوزستان | رازهای پیروزی"), TextBright, TitleX, ProfileY - 1.f * UIScale, 520.f * UIScale, MenuFont ? MenuFont.Get() : nullptr, 1.28f * UIScale, true);
	DrawFarsiTextBounded(bMenuEnglish ? FString::Printf(TEXT("Level %d"), PLevel) : FString::Printf(TEXT("سطح %s"), *UFarsiTextHelper::IntToPersian(PLevel)), TextMuted, TitleX, ProfileY + 35.f * UIScale, 130.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.84f * UIScale, true);
	DrawFarsiTextBounded(bMenuEnglish ? FString::Printf(TEXT("%d / %d XP"), TotalXP, XPGoal) : UFarsiTextHelper::ToPersianDigits(FString::Printf(TEXT("%d / %d XP"), TotalXP, XPGoal)), TextMuted, TitleX + 178.f * UIScale, ProfileY + 35.f * UIScale, 190.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.78f * UIScale, true, true);
	DrawReferenceProgress(TitleX, ProfileY + 46.f * RefY, 188.f * RefX, 7.f * RefY, LevelFrac, false);
	// AAA-MW-28: avoid sliced glow bands on the main page; use a simple warm shade
	// plate so no UI lighting can read as background/grid lines.
	DrawRect(RefAlpha(RefFire, 0.026f), ProfileX + 70.f * RefX, ProfileY + 44.f * RefY, 224.f * RefX, 24.f * RefY);

	// Top-right icon rail — PNG-first; fallback is intentionally simple.
	auto GetRailIconTexture = [&](int32 ID) -> UTexture2D*
	{
		switch (ID)
		{
		case 5: return RailIconSquadTexture.Get();
		case 8: return RailIconLoadTexture ? RailIconLoadTexture.Get() : RailIconMessagesTexture.Get();
		case 12: return RailIconRelicTexture.Get();
		case 9: return RailIconSettingsTexture.Get();
		case 11: return RailIconPowerTexture.Get();
		default: return nullptr;
		}
	};

	auto DrawRailIcon = [&](int32 ID, float X, float Y, float S, bool bHot)
	{
		if (UTexture2D* IconTex = GetRailIconTexture(ID))
		{
			const float Pad = 8.f * UIScale;
			DrawTexture(IconTex, X + Pad, Y + Pad, S - 2.f * Pad, S - 2.f * Pad, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
			return;
		}
		const FLinearColor C = bHot ? Brass : TextMuted;
		DrawFarsiTextBounded(TEXT("•"), C, X, Y + 1.f * UIScale, S, BodyFont ? BodyFont.Get() : nullptr, 1.15f * UIScale, false, true, S);
	};

	const float RailIcon = 42.f * RefY;
	const float RailGap = 3.f * RefX;
	const float RailGroupW = 5.f * RailIcon + 4.f * RailGap;
	// AAA-MW-31: right-align the full utility rail. The previous fixed 1333px
	// origin pushed the settings/power icons off-screen at the 1440 reference width.
	const float RailX = ScreenW - RailGroupW - 28.f * RefX;
	const float RailY = 16.f * RefY;
	DrawReferencePanel(RailX - 3.f * RefX, RailY - 2.f * RefY, RailGroupW + 6.f * RefX, RailIcon + 4.f * RefY, false, -0.13f);
	for (int32 RailSep = 1; RailSep < 5; ++RailSep)
	{
		const float SX = RailX + RailSep * RailIcon + (RailSep - 0.5f) * RailGap;
		DrawLine(SX, RailY + 5.f * RefY, SX, RailY + RailIcon - 5.f * RefY, RefAlpha(RefGoldDeep, 0.26f), 0.75f);
	}
	const int32 RailIDs[] = { 5, 8, 12, 9, 11 };
	const TCHAR* RailLabelsFa[] = { TEXT("جوخه"), TEXT("بارگذاری"), TEXT("یادگارها") , TEXT("تنظیمات"), TEXT("خروج") };
	const TCHAR* RailLabelsEn[] = { TEXT("Squad"), TEXT("Load Game"), TEXT("Relics") , TEXT("Settings"), TEXT("Exit") };
	const TCHAR** RailLabels = bMenuEnglish ? RailLabelsEn : RailLabelsFa;
	for (int32 i = 0; i < 5; ++i)
	{
		const float X = RailX + i * (RailIcon + RailGap);
		const bool bHover = (MouseX >= X && MouseX <= X + RailIcon && MouseY >= RailY && MouseY <= RailY + RailIcon);
		if (bHover) HoveredButtonIndex = RailIDs[i];
		RegisterButton(RailIDs[i], X, RailY, RailIcon, RailIcon, FText::FromString(RailLabels[i]));
		DrawReferencePanel(X, RailY, RailIcon, RailIcon, bHover, -0.05f);
		DrawRailIcon(RailIDs[i], X, RailY, RailIcon, bHover);
		DrawRect(RefAlpha(RefGoldBright, bHover ? 0.30f : 0.14f), X + 5.f * UIScale, RailY + 5.f * UIScale, 2.f * UIScale, 2.f * UIScale);
		DrawRect(RefAlpha(RefDeepBlack, 0.42f), X + RailIcon - 7.f * UIScale, RailY + RailIcon - 7.f * UIScale, 2.f * UIScale, 2.f * UIScale);
		if (RailIDs[i] == 8)
		{
			DrawRect(RefAlpha(RefHotSpark, bHover ? 0.90f : 0.62f), X + RailIcon - 11.f * UIScale, RailY + 7.f * UIScale, 4.f * UIScale, 4.f * UIScale);
		}
	}


	// Left vertical command buttons — bigger, Persian, icon wells corrected.
	const float MenuX = 28.f * RefX;
	const float MenuY = 103.f * RefY;
	const float MenuW = 358.f * RefX;
	const float RowH = 59.f * RefY;
	const float RowGap = 2.f * RefY;
	struct FModernMenuEntry
	{
		int32 ID;
		const TCHAR* Label;
		const TCHAR* Subtitle;
	};
	const FModernMenuEntry EntriesFa[] = {
		{ 1,  TEXT("آغاز عملیات"), TEXT("شروع عملیات آماده") },
		{ 2,  (bMenuEnglish ? TEXT("Operations") : TEXT("عملیات")), TEXT("ماموریت‌ها و جبهه‌ها") },
		{ 3,  TEXT("تجهیزات"), TEXT("سلاح‌ها و مهمات") },
		{ 4,  TEXT("ترقیات"), TEXT("مهارت‌ها و پاداش‌ها") },
		{ 5,  TEXT("پرونده"), TEXT("جوخه و فرمانده") },
		{ 6,  TEXT("کارنامه نبرد"), TEXT("آمار و دستاوردها") },
		{ 9,  TEXT("تنظیمات"), TEXT("تصویر، صدا، کنترل") },
		{ 11, TEXT("خروج"), TEXT("بازگشت به دسکتاپ") }
	};
	const FModernMenuEntry EntriesEn[] = {
		{ 1,  TEXT("Start Operation"), TEXT("Begin a prepared mission") },
		{ 2,  TEXT("Operations"), TEXT("Missions and front lines") },
		{ 3,  TEXT("Equipment"), TEXT("Weapons and ammunition") },
		{ 4,  TEXT("Progression"), TEXT("Skills and rewards") },
		{ 5,  TEXT("Dossier"), TEXT("Squad and commander") },
		{ 6,  TEXT("Battle Record"), TEXT("Stats and achievements") },
		{ 9,  TEXT("Settings"), TEXT("Video, audio, controls") },
		{ 11, TEXT("Exit"), TEXT("Return to desktop") }
	};
	const FModernMenuEntry* Entries = bMenuEnglish ? EntriesEn : EntriesFa;
	for (int32 i = 0; i < (bMenuEnglish ? UE_ARRAY_COUNT(EntriesEn) : UE_ARRAY_COUNT(EntriesFa)); ++i)
	{
		const float Y = MenuY + i * (RowH + RowGap);
		DrawMainButton(Entries[i].ID, MenuX, Y, MenuW, RowH, FString(Entries[i].Label), FString(Entries[i].Subtitle), i == 0);
	}

	// Bottom-left news/intel panel — same content placement as reference, larger Persian text.
	const float NewsX = MenuX;
	const float NewsW = MenuW;
	const float NewsH = 118.f * RefY;
	const float NewsY = 599.f * RefY;
	DrawReferencePanel(NewsX, NewsY, NewsW, NewsH, false, -0.02f);
	DrawPanelAngledMicroLines(NewsX, NewsY, NewsW, NewsH, 0.52f);
	DrawFarsiTextBounded(bMenuEnglish ? TEXT("Latest Report") : TEXT("آخرین گزارش"), Brass, NewsX + 20.f * UIScale, NewsY + 15.f * UIScale, NewsW - 40.f * UIScale, MenuFont ? MenuFont.Get() : nullptr, 1.10f * UIScale, true);
	const float Thumb = 70.f * RefY;
	const float ThumbX = NewsX + 18.f * RefX;
	const float ThumbY = NewsY + 36.f * RefY;
	DrawReferencePanel(ThumbX, ThumbY, Thumb, Thumb, false, -0.08f);
	if (BackgroundTexture)
	{
		DrawTexture(BackgroundTexture, ThumbX + 4.f * UIScale, ThumbY + 4.f * UIScale, Thumb - 8.f * UIScale, Thumb - 8.f * UIScale, 0.08f, 0.10f, 0.38f, 0.38f, SquadAIRefSRGBA(0xBE, 0xA4, 0x62, 0.94f));
	}
	DrawFarsiTextBounded(bMenuEnglish ? TEXT("New season update") : TEXT("به‌روزرسانی فصل جدید"), Brass, ThumbX + Thumb + 18.f * UIScale, ThumbY + 2.f * UIScale, NewsW - Thumb - 74.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.86f * UIScale, true);
	DrawFarsiTextBounded(bMenuEnglish ? TEXT("Field reports and battle balance were updated.") : TEXT("گزارش‌های میدانی و توازن نبرد به‌روز شد."), TextMuted, ThumbX + Thumb + 18.f * UIScale, ThumbY + 29.f * UIScale, NewsW - Thumb - 78.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.62f * UIScale, true);
	const float ReadW = 166.f * UIScale;
	const float ReadH = 40.f * UIScale;
	const float ReadX = ThumbX + Thumb + 18.f * UIScale;
	const float ReadY = NewsY + NewsH - ReadH - 10.f * UIScale;
	const bool bReadHover = (MouseX >= ReadX && MouseX <= ReadX + ReadW && MouseY >= ReadY && MouseY <= ReadY + ReadH);
	if (bReadHover) HoveredButtonIndex = 13;
	RegisterButton(13, ReadX, ReadY, ReadW, ReadH, FText::FromString(bMenuEnglish ? TEXT("More") : TEXT("بیشتر")));
	DrawReferencePanel(ReadX, ReadY, ReadW, ReadH, bReadHover, -0.08f);
	DrawFarsiTextBounded(bMenuEnglish ? TEXT("More") : TEXT("بیشتر"), bReadHover ? RefLabelBright : TextBright, ReadX + 8.f * UIScale, ReadY, ReadW - 16.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 1.02f * UIScale, true, true, ReadH);
	for (int32 Dot = 0; Dot < 4; ++Dot)
	{
		const bool bActiveDot = Dot == 3;
		const float DotS = bActiveDot ? 6.f * UIScale : 5.f * UIScale;
		const float DotX = NewsX + NewsW - (44.f - Dot * 12.f) * UIScale;
		const float DotY = NewsY + NewsH - 18.f * UIScale;
		DrawRect(bActiveDot ? RefAlpha(RefActiveGreen, 0.92f) : SquadAIRefSRGBA(0x44, 0x3D, 0x31, 0.62f), DotX, DotY, DotS, DotS);
	}

	// Right mission card, matching reference density but with bigger Persian text.
	const float RightW = 340.f * RefX;
	const float RightX = 1217.f * RefX;
	const float MissionY = 103.f * RefY;
	const float MissionH = 178.f * RefY;
	DrawReferencePanel(RightX, MissionY, RightW, MissionH, false, -0.01f);
	DrawLine(RightX + 13.f * UIScale, MissionY + 9.f * UIScale, RightX + RightW - 13.f * UIScale, MissionY + 9.f * UIScale, RefAlpha(RefGoldBright, 0.28f), 1.0f * UIScale);
	DrawLine(RightX + RightW - 8.f * UIScale, MissionY + 13.f * UIScale, RightX + RightW - 8.f * UIScale, MissionY + MissionH - 13.f * UIScale, RefAlpha(RefDeepBlack, 0.70f), 1.05f * UIScale);
	DrawLine(RightX + 13.f * UIScale, MissionY + MissionH - 8.f * UIScale, RightX + RightW - 13.f * UIScale, MissionY + MissionH - 8.f * UIScale, RefAlpha(RefDeepBlack, 0.76f), 1.05f * UIScale);
	DrawPanelAngledMicroLines(RightX, MissionY, RightW, MissionH, 0.95f);
	UTexture2D* ActiveAvaTex = GetAvatarTexture(Prof.SelectedAvatarID);
	const float Portrait = 88.f * RefY;
	const float PortraitX = RightX + 18.f * RefX;
	const float PortraitY = MissionY + 34.f * RefY;
	DrawReferencePanel(PortraitX, PortraitY, Portrait, Portrait, false, -0.10f);
	if (ActiveAvaTex)
	{
		DrawTexture(ActiveAvaTex, PortraitX + 5.f * UIScale, PortraitY + 5.f * UIScale, Portrait - 10.f * UIScale, Portrait - 10.f * UIScale, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
	}
	else if (WatermarkEmblemTexture)
	{
		// P7-MM4b: portrait-fallback emblem also renders in true logo colors
		// (was Brass * 0.82f — same shadowy multiply the owner rejected).
		DrawTexture(WatermarkEmblemTexture, PortraitX + 10.f * UIScale, PortraitY + 10.f * UIScale, Portrait - 20.f * UIScale, Portrait - 20.f * UIScale, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
	}
	DrawLine(PortraitX + 5.f * UIScale, PortraitY + 5.f * UIScale, PortraitX + Portrait - 5.f * UIScale, PortraitY + 5.f * UIScale, RefAlpha(RefGoldBright, 0.22f), 0.9f);
	DrawLine(PortraitX + Portrait - 5.f * UIScale, PortraitY + 5.f * UIScale, PortraitX + Portrait - 5.f * UIScale, PortraitY + Portrait - 5.f * UIScale, RefAlpha(RefDeepBlack, 0.66f), 1.0f);
	DrawLine(PortraitX + 5.f * UIScale, PortraitY + Portrait - 5.f * UIScale, PortraitX + Portrait - 5.f * UIScale, PortraitY + Portrait - 5.f * UIScale, RefAlpha(RefDeepBlack, 0.72f), 1.0f);
	const float MTextX = PortraitX + Portrait + 18.f * UIScale;
	DrawFarsiTextBounded(bMenuEnglish ? TEXT("Khuzestan Front") : TEXT("سقوط خوزستان"), TextBright, MTextX, MissionY + 22.f * UIScale, RightW - (MTextX - RightX) - 20.f * UIScale, MenuFont ? MenuFont.Get() : nullptr, 1.34f * UIScale, true);
	DrawFarsiTextBounded(bMenuEnglish ? TEXT("Main Operation") : TEXT("عملیات اصلی"), BrassSoft, MTextX, MissionY + 66.f * UIScale, RightW - (MTextX - RightX) - 20.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.96f * UIScale, true);
	DrawLine(MTextX, MissionY + 94.f * UIScale, RightX + RightW - 18.f * UIScale, MissionY + 94.f * UIScale, Brass * 0.42f, 1.f);
	DrawLine(MTextX, MissionY + 98.f * UIScale, RightX + RightW - 82.f * UIScale, MissionY + 98.f * UIScale, RefAlpha(RefDeepBlack, 0.45f), 1.f);
	if (WatermarkEmblemTexture)
	{
		// P7-MM4b: true logo colors for the mission-card crest too. Screenshot pixel
		// sampling showed this site rendered ~0.72x the header crest brightness
		// (Brass * 0.74f multiply) — the "shadowy emblem" the owner reported.
		DrawTexture(WatermarkEmblemTexture, RightX + RightW - 72.f * UIScale, MissionY + 20.f * UIScale, 52.f * UIScale, 52.f * UIScale, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
	}
	DrawFarsiTextBounded(bMenuEnglish ? TEXT("Advance to the front line and break the enemy armored assault.") : TEXT("پیشروی به خط مقدم و شکستن هجوم زرهی دشمن."), TextMuted, MTextX, MissionY + 110.f * UIScale, RightW - (MTextX - RightX) - 20.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.86f * UIScale, true);
	const float DetailW = 204.f * RefX;
	const float DetailH = 36.f * RefY;
	const float DetailX = RightX + RightW - DetailW - 18.f * UIScale;
	const float DetailY = MissionY + MissionH - DetailH - 15.f * UIScale;
	const bool bDetailHover = (MouseX >= DetailX && MouseX <= DetailX + DetailW && MouseY >= DetailY && MouseY <= DetailY + DetailH);
	if (bDetailHover) HoveredButtonIndex = 13;
	RegisterButton(13, DetailX, DetailY, DetailW, DetailH, FText::FromString(bMenuEnglish ? TEXT("Details") : TEXT("نمایش جزئیات")));
	DrawReferencePanel(DetailX, DetailY, DetailW, DetailH, bDetailHover, -0.08f);
		DrawRect(RefAlpha(RefGoldBright, bDetailHover ? 0.052f : 0.026f), DetailX + 5.f * UIScale, DetailY + 4.f * UIScale, DetailW - 10.f * UIScale, DetailH * 0.32f);
		DrawLine(DetailX + 8.f * UIScale, DetailY + 5.f * UIScale, DetailX + DetailW - 8.f * UIScale, DetailY + 5.f * UIScale, RefAlpha(RefGoldBright, bDetailHover ? 0.34f : 0.18f), 0.9f * UIScale);
		DrawLine(DetailX + 8.f * UIScale, DetailY + DetailH - 5.f * UIScale, DetailX + DetailW - 8.f * UIScale, DetailY + DetailH - 5.f * UIScale, RefAlpha(RefDeepBlack, 0.62f), 0.8f * UIScale);
	DrawFarsiTextBounded(bMenuEnglish ? TEXT("Details") : TEXT("نمایش جزئیات"), bDetailHover ? Brass : TextBright, DetailX, DetailY + 1.f * UIScale, DetailW, BodyFont ? BodyFont.Get() : nullptr, 0.86f * UIScale, true, true, DetailH);

	// Objectives card.
	const float ObjY = 293.f * RefY;
	const float ObjH = 177.f * RefY;
	DrawReferencePanel(RightX, ObjY, RightW, ObjH, false, -0.01f);
		DrawLine(RightX + 12.f * UIScale, ObjY + 8.f * UIScale, RightX + RightW - 12.f * UIScale, ObjY + 8.f * UIScale, RefAlpha(RefGoldBright, 0.24f), 0.9f * UIScale);
		DrawLine(RightX + RightW - 8.f * UIScale, ObjY + 13.f * UIScale, RightX + RightW - 8.f * UIScale, ObjY + ObjH - 13.f * UIScale, RefAlpha(RefDeepBlack, 0.66f), 1.0f * UIScale);
		DrawLine(RightX + 12.f * UIScale, ObjY + ObjH - 8.f * UIScale, RightX + RightW - 12.f * UIScale, ObjY + ObjH - 8.f * UIScale, RefAlpha(RefDeepBlack, 0.72f), 1.0f * UIScale);
	DrawPanelAngledMicroLines(RightX, ObjY, RightW, ObjH, 0.78f);
	DrawFarsiTextBounded(bMenuEnglish ? TEXT("Daily Challenges") : TEXT("چالش‌های روزانه"), TextBright, RightX + 20.f * UIScale, ObjY + 15.f * UIScale, RightW - 86.f * UIScale, MenuFont ? MenuFont.Get() : nullptr, 1.02f * UIScale, true);
	DrawFarsiTextBounded(bMenuEnglish ? TEXT("1/3") : TEXT("۱/۳"), TextBright, RightX + RightW - 70.f * UIScale, ObjY + 15.f * UIScale, 52.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.82f * UIScale, true, true);
	DrawFarsiTextBounded(bMenuEnglish ? TEXT("Refresh: 12:45") : TEXT("به‌روزرسانی: ۱۲:۴۵"), TextMuted, RightX + RightW - 210.f * UIScale, ObjY + 18.f * UIScale, 130.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.62f * UIScale, true, true);
	struct FObjectiveLine { const TCHAR* Label; float Fraction; const TCHAR* Value; };
	const FObjectiveLine ObjLinesFa[] = {
		{ TEXT("۲۵ هدف با سلاح اصلی"), 0.48f, TEXT("۱۲/۲۵") },
		{ TEXT("۳ عملیات داستانی"), 0.33f, TEXT("۱/۳") },
		{ TEXT("۲ پیروزی چندنفره"), 0.0f, TEXT("۰/۲") }
	};
	const FObjectiveLine ObjLinesEn[] = {
		{ TEXT("25 primary-weapon targets"), 0.48f, TEXT("12/25") },
		{ TEXT("3 story operations"), 0.33f, TEXT("1/3") },
		{ TEXT("2 multiplayer victories"), 0.0f, TEXT("0/2") }
	};
	const FObjectiveLine* ObjLines = bMenuEnglish ? ObjLinesEn : ObjLinesFa;
	for (int32 i = 0; i < (bMenuEnglish ? UE_ARRAY_COUNT(ObjLinesEn) : UE_ARRAY_COUNT(ObjLinesFa)); ++i)
	{
		const float Y = ObjY + 62.f * UIScale + i * 44.f * UIScale;
		if (i > 0)
		{
			DrawLine(RightX + 20.f * UIScale, Y - 11.f * UIScale, RightX + RightW - 20.f * UIScale, Y - 11.f * UIScale, RefAlpha(RefDeepBlack, 0.50f), 0.8f);
			DrawLine(RightX + 20.f * UIScale, Y - 12.f * UIScale, RightX + RightW - 20.f * UIScale, Y - 12.f * UIScale, RefAlpha(RefGoldDeep, 0.075f), 0.55f);
		}
		DrawFarsiTextBounded(ObjLines[i].Label, TextMuted, RightX + 22.f * UIScale, Y, RightW - 100.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.76f * UIScale, true);
		DrawFarsiTextBounded(ObjLines[i].Value, Brass, RightX + RightW - 76.f * UIScale, Y, 58.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.76f * UIScale, true, true);
		DrawReferenceProgress(RightX + 22.f * UIScale, Y + 25.f * UIScale, RightW - 44.f * UIScale, 5.f * UIScale, ObjLines[i].Fraction, i == 0);
		if (i == 0)
		{
		}
	}

	// Map / emblem card.
	const float MapY = 489.f * RefY;
	const float MapH = 113.f * RefY;
	DrawReferencePanel(RightX, MapY, RightW, MapH, false, -0.02f);
		DrawLine(RightX + 12.f * UIScale, MapY + 8.f * UIScale, RightX + RightW - 12.f * UIScale, MapY + 8.f * UIScale, RefAlpha(RefGoldBright, 0.24f), 0.9f * UIScale);
		DrawLine(RightX + RightW - 8.f * UIScale, MapY + 13.f * UIScale, RightX + RightW - 8.f * UIScale, MapY + MapH - 13.f * UIScale, RefAlpha(RefDeepBlack, 0.66f), 1.0f * UIScale);
		DrawLine(RightX + 12.f * UIScale, MapY + MapH - 8.f * UIScale, RightX + RightW - 12.f * UIScale, MapY + MapH - 8.f * UIScale, RefAlpha(RefDeepBlack, 0.72f), 1.0f * UIScale);
	DrawPanelAngledMicroLines(RightX, MapY, RightW, MapH, 0.70f);
	DrawFarsiTextBounded(bMenuEnglish ? TEXT("Secrets of Victory") : TEXT("رازهای پیروزی"), TextBright, RightX + 20.f * UIScale, MapY + 16.f * UIScale, RightW - 150.f * UIScale, MenuFont ? MenuFont.Get() : nullptr, 1.06f * UIScale, true);
	DrawFarsiTextBounded(bMenuEnglish ? TEXT("Map: Dehlavieh") : TEXT("نقشه: دهلاویه"), TextMuted, RightX + 20.f * UIScale, MapY + 54.f * UIScale, RightW - 150.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.82f * UIScale, true);
	const float ChangeW = 156.f * UIScale;
	const float ChangeH = 36.f * UIScale;
	const float ChangeX = RightX + 18.f * UIScale;
	const float ChangeY = MapY + MapH - ChangeH - 13.f * UIScale;
	const bool bChangeHover = (MouseX >= ChangeX && MouseX <= ChangeX + ChangeW && MouseY >= ChangeY && MouseY <= ChangeY + ChangeH);
	if (bChangeHover) HoveredButtonIndex = 2;
	RegisterButton(2, ChangeX, ChangeY, ChangeW, ChangeH, FText::FromString(bMenuEnglish ? TEXT("Change Map") : TEXT("تغییر نقشه")));
	DrawReferencePanel(ChangeX, ChangeY, ChangeW, ChangeH, bChangeHover, -0.09f);
		DrawRect(RefAlpha(RefGoldBright, bChangeHover ? 0.050f : 0.024f), ChangeX + 5.f * UIScale, ChangeY + 4.f * UIScale, ChangeW - 10.f * UIScale, ChangeH * 0.32f);
		DrawLine(ChangeX + 8.f * UIScale, ChangeY + 5.f * UIScale, ChangeX + ChangeW - 8.f * UIScale, ChangeY + 5.f * UIScale, RefAlpha(RefGoldBright, bChangeHover ? 0.32f : 0.16f), 0.85f * UIScale);
		DrawLine(ChangeX + 8.f * UIScale, ChangeY + ChangeH - 5.f * UIScale, ChangeX + ChangeW - 8.f * UIScale, ChangeY + ChangeH - 5.f * UIScale, RefAlpha(RefDeepBlack, 0.62f), 0.8f * UIScale);
	DrawFarsiTextBounded(bMenuEnglish ? TEXT("Change Map") : TEXT("تغییر نقشه"), bChangeHover ? Brass : TextBright, ChangeX, ChangeY + 1.f * UIScale, ChangeW, BodyFont ? BodyFont.Get() : nullptr, 0.78f * UIScale, true, true, ChangeH);
	// S16-FLAG2: removed unused RefreshCX/RefreshCY floats (C4189 warnings-as-errors risk).
	if (WatermarkEmblemTexture)
	{
		// P7-MM4: true logo colors (was Brass * 0.72f dark multiply).
		DrawTexture(WatermarkEmblemTexture, RightX + RightW - 116.f * UIScale, MapY + 12.f * UIScale, 98.f * UIScale, 98.f * UIScale, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
	}

	auto DrawBottomStatIcon = [&](int32 IconID, float X, float Y, float S, const FLinearColor& C)
	{
		UTexture2D* IconTex = nullptr;
		switch (IconID)
		{
		case 0: IconTex = StatIconLevelTexture.Get(); break;
		case 1: IconTex = StatIconOperationsTexture.Get(); break;
		case 2: IconTex = StatIconAccuracyTexture.Get(); break;
		case 3: IconTex = StatIconHoursTexture.Get(); break;
		case 4: IconTex = StatIconXPTexture.Get(); break;
		default: break;
		}
		if (IconTex)
		{
			// AAA-MW-22: glowing PNG stat icons, matching the left-side menu icon quality.
			DrawTexture(IconTex, X - S * 0.12f, Y - S * 0.12f, S * 1.24f, S * 1.24f, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
			return;
		}

		// Fallback only if PNGs are not loaded.
		DrawRect(RefAlpha(C, 0.22f), X + S * 0.22f, Y + S * 0.22f, S * 0.56f, S * 0.56f);
		DrawRect(RefAlpha(RefGoldBright, 0.78f), X + S * 0.38f, Y + S * 0.38f, S * 0.24f, S * 0.24f);
	};

	// Bottom-center operational stats ribbon, matching the reference layout while
	// staying clear of the left news card and the right quick-start CTA.
	const float StatsLeftLimit = 468.f * RefX;
	const float StatsW = 647.f * RefX;
	const float StatsH = 90.f * RefY;
	const float StatsY = 626.f * RefY;
	if (StatsW >= 500.f * UIScale)
	{
		DrawReferencePanel(StatsLeftLimit, StatsY, StatsW, StatsH, false, -0.06f);
		DrawPanelAngledMicroLines(StatsLeftLimit, StatsY, StatsW, StatsH, 0.55f);
		struct FMenuStatCell { const TCHAR* Label; FString Value; };
		const int32 HoursPlayed = FMath::Max(0, FMath::RoundToInt(Prof.TotalPlaytimeSeconds / 3600.f));
		const FMenuStatCell StatCellsFa[] = {
			{ (bMenuEnglish ? TEXT("Level") : TEXT("سطح")), UFarsiTextHelper::IntToPersian(PLevel) },
			{ (bMenuEnglish ? TEXT("Operations") : TEXT("عملیات")), UFarsiTextHelper::IntToPersian(FMath::Max(0, Prof.MissionsCompleted)) },
			{ (bMenuEnglish ? TEXT("Accuracy") : TEXT("دقت")), UFarsiTextHelper::ToPersianDigits(FString::Printf(TEXT("%.1f%%"), Prof.OverallAccuracyPercentage)) },
			{ TEXT("ساعات"), UFarsiTextHelper::IntToPersian(HoursPlayed) },
			{ TEXT("XP"), UFarsiTextHelper::IntToPersian(TotalXP) }
		};
		const FMenuStatCell StatCellsEn[] = {
			{ TEXT("Level"), FString::Printf(TEXT("%d"), PLevel) },
			{ TEXT("Ops"), FString::Printf(TEXT("%d"), FMath::Max(0, Prof.MissionsCompleted)) },
			{ TEXT("Accuracy"), FString::Printf(TEXT("%.1f%%"), Prof.OverallAccuracyPercentage) },
			{ TEXT("Hours"), FString::Printf(TEXT("%d"), HoursPlayed) },
			{ TEXT("XP"), FString::Printf(TEXT("%d"), TotalXP) }
		};
		const FMenuStatCell* StatCells = bMenuEnglish ? StatCellsEn : StatCellsFa;
		const int32 StatCount = (bMenuEnglish ? UE_ARRAY_COUNT(StatCellsEn) : UE_ARRAY_COUNT(StatCellsFa));
		const float CellW = StatsW / static_cast<float>(StatCount);
		UFont* StatValueFont = TitleFont ? TitleFont.Get() : (GEngine ? GEngine->GetLargeFont() : nullptr);
		UFont* StatLabelFont = MenuFont ? MenuFont.Get() : (GEngine ? GEngine->GetMediumFont() : nullptr);
		for (int32 i = 0; i < StatCount; ++i)
		{
			const float CX = StatsLeftLimit + i * CellW;
			if (i > 0)
			{
				DrawLine(CX, StatsY + 12.f * UIScale, CX, StatsY + StatsH - 12.f * UIScale, BrassDim * 0.48f, 0.8f);
			}

			// AAA-MW-24: the old side-by-side cell squeezed text into ~70px and forced
			// Canvas auto-shrink/upscale, making the bottom-middle stats look low quality.
			// Center the PNG icon and give both number/label the full cell width.
			const float IconS = 31.f * UIScale;
			const float TextW = CellW - 12.f * UIScale;
			DrawBottomStatIcon(i, CX + (CellW - IconS) * 0.5f, StatsY + 6.f * UIScale, IconS, (i == 4) ? RefAlpha(RefCoolGlint, 0.52f) : RefGoldText);
			// P7-MM2: value moved DOWN to the exact middle of the icon-to-label gap (it sat
			// almost on the icon, at Y+35 while the glowing icon base reaches ~Y+42) and
			// rendered flat, which read as low quality. Screenshot pixel measurement put the
			// icon base at ~Y+39 and the label top at ~Y+68, so Y+46 with a slightly larger
			// scale centers the digits at the pixel-midpoint. Bigger scale + drop shadow,
			// same high-quality TitleFont path the left buttons and difficulty cards use
			// (TitleFont is proven to carry Persian digits: card indices "۰۱".."۰۴").
			DrawFarsiTextBounded(StatCells[i].Value, TextBright, CX + 6.f * UIScale, StatsY + 46.f * UIScale, TextW, StatValueFont, 1.15f * UIScale, true, true);
			DrawFarsiTextBounded(StatCells[i].Label, TextMuted, CX + 6.f * UIScale, StatsY + 68.f * UIScale, TextW, StatLabelFont, 0.76f * UIScale, false, true);
		}
	}

	// Quick start CTA.
	const float QuickW = RightW;
	const float QuickH = 89.f * RefY;
	const float QuickX = RightX;
	const float QuickY = 641.f * RefY;
	const bool bQuickHover = (MouseX >= QuickX && MouseX <= QuickX + QuickW && MouseY >= QuickY && MouseY <= QuickY + QuickH);
	if (bQuickHover) HoveredButtonIndex = 7;
	RegisterButton(7, QuickX, QuickY, QuickW, QuickH, FText::FromString(bMenuEnglish ? TEXT("Quick Start") : TEXT("شروع سریع")));
	const float QuickPulse = bReducedMenuMotion ? 0.f : (0.5f + 0.5f * FMath::Sin(MenuAnimTime * 1.25f));
	// P7-MM1: standard tactical 3D CTA — same beveled reference-panel treatment the
	// left-side menu buttons use (the old flat plate + hand-drawn ">>" strokes read as
	// low-quality next to them). Hover lifts the accent; a depth-shadowed double chevron
	// keeps the forward/launch affordance in 3D instead of flat strokes.
	DrawReferencePanel(QuickX, QuickY, QuickW, QuickH, bQuickHover, -0.06f);
	DrawPanelAngledMicroLines(QuickX, QuickY, QuickW, QuickH, 0.45f);
	DrawRect(RefAlpha(RefGoldBright, bQuickHover ? 0.16f : (0.06f + QuickPulse * 0.03f)), QuickX + 6.f * UIScale, QuickY + 5.f * UIScale, QuickW - 12.f * UIScale, QuickH * 0.16f);
	DrawLine(QuickX + 10.f * UIScale, QuickY, QuickX + QuickW - 10.f * UIScale, QuickY, RefAlpha(RefGoldBright, bQuickHover ? 0.95f : 0.60f), 1.6f * UIScale);
	DrawLine(QuickX + 10.f * UIScale, QuickY + QuickH, QuickX + QuickW - 10.f * UIScale, QuickY + QuickH, RefAlpha(RefDeepBlack, 0.85f), 1.3f * UIScale);
	{
		const float ChCX = QuickX + QuickW - 62.f * UIScale;
		const float ChCY = QuickY + QuickH * 0.5f;
		const float ChW = 11.f * UIScale;
		const float ChH = 17.f * UIScale;
		for (int32 c = 0; c < 2; ++c)
		{
			const float Off = c * (ChW + 7.f * UIScale);
			const float Sh = 2.f * UIScale; // depth shadow offset
			DrawLine(ChCX + Off + Sh, ChCY - ChH + Sh, ChCX + Off + ChW + Sh, ChCY + Sh, RefAlpha(RefDeepBlack, 0.85f), 2.2f * UIScale);
			DrawLine(ChCX + Off + ChW + Sh, ChCY + Sh, ChCX + Off + Sh, ChCY + ChH + Sh, RefAlpha(RefDeepBlack, 0.85f), 2.2f * UIScale);
			const FLinearColor ChCol = RefAlpha(RefGoldBright, (bQuickHover ? 0.95f : 0.74f) - c * 0.20f);
			DrawLine(ChCX + Off, ChCY - ChH, ChCX + Off + ChW, ChCY, ChCol, 2.2f * UIScale);
			DrawLine(ChCX + Off + ChW, ChCY, ChCX + Off, ChCY + ChH, ChCol, 2.2f * UIScale);
		}
	}
	// P7-MM1b: exact left-menu-button text recipe — pixel sampling showed the old
	// Quick Start title rendered dark gold (RefGoldText, ~0.7x brightness) and
	// battered against the bright plate, while the left labels the owner loves are
	// MenuFont in near-white TextBright (RefLabelBright on hover) with one tight
	// drop shadow. Same font, same colors, same shadow: identical quality.
	DrawFarsiTextBounded(bMenuEnglish ? TEXT("Quick Start") : TEXT("شروع سریع"), bQuickHover ? RefLabelBright : TextBright, QuickX + 28.f * UIScale, QuickY + 20.f * UIScale, QuickW - 118.f * UIScale, MenuFont ? MenuFont.Get() : nullptr, 1.15f * UIScale, true);
	DrawFarsiTextBounded(bMenuEnglish ? (bHasSave ? TEXT("Continue from latest operation save") : TEXT("Enter battle immediately")) : (bHasSave ? TEXT("ادامه از آخرین ذخیره عملیات") : TEXT("ورود فوری به نبرد")), TextMuted, QuickX + 28.f * UIScale, QuickY + 62.f * UIScale, QuickW - 118.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.88f * UIScale, true);

	// AAA-MW-22: bottom-left keyboard footer removed. Back/exit is handled by the
	// top-right power button, and the old quick-list footer button did not exist.
}

void ASquadAIMainMenuHUD::DrawMapSelectScreen(float ScreenW, float ScreenH, float MouseX, float MouseY)
{
	const bool bMenuEnglish = !CachedMenuSettings.LanguageCode.StartsWith(TEXT("fa"), ESearchCase::IgnoreCase);
	const float UIScale = FMath::Clamp(ScreenH / 1080.f, 0.70f, 1.35f);
	const float PanelX = 50.f * UIScale + SubmenuSlideOffset;
	const float PanelY = 104.f * UIScale;
	const float PanelW = ScreenW - (100.f * UIScale);
	const float PanelH = ScreenH - (170.f * UIScale);

	// AAA-B2-1: map screen rebuilt as a recon board — left sector ledger,
	// right 16:9 theater intelligence, cool slate palette instead of gold.
	DrawRect(FLinearColor(0.f, 0.f, 0.f, 0.34f), 0.f, PanelY - 12.f * UIScale, ScreenW, PanelH + 42.f * UIScale);
	DrawSacredDefenseBorder(PanelX, PanelY, PanelW, PanelH, PrimaryAccentColor * 0.92f, true);
	DrawRect(FLinearColor(0.0f, 0.0f, 0.0f, 0.18f), PanelX + 5.f * UIScale, PanelY + 5.f * UIScale, PanelW - 10.f * UIScale, PanelH - 10.f * UIScale);

	DrawFarsiTextBounded(SquadAIMenuLocal(this, TEXT("MapSelection"), TEXT("HeaderTitle"), TEXT("برد شناسایی مناطق عملیاتی | THEATER RECON BOARD"), TEXT("Theater Recon Board"), bMenuEnglish), PrimaryAccentColor, PanelX + 28.f * UIScale, PanelY + 18.f * UIScale, PanelW - 56.f * UIScale, TitleFont ? TitleFont.Get() : nullptr, 1.28f * UIScale, true);
	DrawFarsiTextBounded((bMenuEnglish ? TEXT("Choose an operation sector. The intelligence file on the right shows status, risk, and deployment reward.") : TEXT("محور را انتخاب کنید؛ پرونده سمت راست وضعیت، خطر و پاداش اعزام را نشان می‌دهد.")), FLinearColor(0.78f, 0.86f, 0.86f, 0.92f), PanelX + 28.f * UIScale, PanelY + 48.f * UIScale, PanelW - 56.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.86f * UIScale, true);

	USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(this);
	const TArray<FSquadMapDefinition> Maps = Prog ? Prog->GetAvailableMaps() : TArray<FSquadMapDefinition>();
	auto GetMapSubtitleForLanguage = [&](const FSquadMapDefinition& Map) -> FString
	{
		if (bMenuEnglish)
		{
			if (Map.MapID == FName("Dehlavieh_Karkheh")) { return TEXT("Khuzestan frontline — defense against hostile armored columns"); }
			if (Map.MapID == FName("Bostan_Chazzabeh")) { return TEXT("Dune fields and Hoor al-Hawizeh waterways"); }
			if (Map.MapID == FName("Khorramshahr_Arvand")) { return TEXT("Urban combat through alleys, palms, and Arvand riverfront"); }
		}
		return Map.Subtitle.ToString();
	};
	auto GetMapDurationForLanguage = [&](const FSquadMapDefinition& Map) -> FString
	{
		if (bMenuEnglish)
		{
			if (Map.MapID == FName("Dehlavieh_Karkheh")) { return TEXT("20 to 30 minutes"); }
			if (Map.MapID == FName("Bostan_Chazzabeh")) { return TEXT("25 to 35 minutes"); }
			if (Map.MapID == FName("Khorramshahr_Arvand")) { return TEXT("35 to 45 minutes"); }
		}
		if (Map.MapID == FName("Dehlavieh_Karkheh")) { return TEXT("۲۰ الی ۳۰ دقیقه"); }
		if (Map.MapID == FName("Bostan_Chazzabeh")) { return TEXT("۲۵ الی ۳۵ دقیقه"); }
		if (Map.MapID == FName("Khorramshahr_Arvand")) { return TEXT("۳۵ الی ۴۵ دقیقه"); }
		return Map.EstimatedPlaytime;
	};
	if (Maps.Num() <= 0)
	{
		DrawChiseledTacticalPanel(PanelX + 36.f * UIScale, PanelY + 92.f * UIScale, PanelW - 72.f * UIScale, 160.f * UIScale, FLinearColor(0.025f, 0.040f, 0.044f, 0.84f), SecondaryAccentColor, 10.f * UIScale);
		DrawFarsiTextBounded((bMenuEnglish ? TEXT("No operation sectors are registered in the progression system.") : TEXT("هیچ منطقه عملیاتی در سیستم پیشروی ثبت نشده است.")), SecondaryAccentColor, PanelX + 56.f * UIScale, PanelY + 136.f * UIScale, PanelW - 112.f * UIScale, TitleFont ? TitleFont.Get() : nullptr, 1.08f * UIScale, true, true);
	}
	else
	{
		SelectedMapIndex = FMath::Clamp(SelectedMapIndex, 0, Maps.Num() - 1);

		const float ListX = PanelX + 24.f * UIScale;
		const float ListY0 = PanelY + 88.f * UIScale;
		const float ListW = FMath::Clamp(PanelW * 0.31f, 370.f * UIScale, 470.f * UIScale);
		const float ItemH = 102.f * UIScale;
		const float ItemGap = 12.f * UIScale;

		DrawChiseledTacticalPanel(ListX, ListY0 - 12.f * UIScale, ListW, PanelH - 118.f * UIScale, FLinearColor(0.014f, 0.026f, 0.030f, 0.68f), PrimaryAccentColor * 0.50f, 10.f * UIScale);
		DrawTacticalTopoGrid(ListX + 10.f * UIScale, ListY0, ListW - 20.f * UIScale, PanelH - 142.f * UIScale, PrimaryAccentColor * 0.45f);

		float ListY = ListY0;
		for (int32 i = 0; i < Maps.Num(); ++i)
		{
			const FSquadMapDefinition& Map = Maps[i];
			const bool bHover = (MouseX >= ListX + 12.f * UIScale && MouseX <= ListX + ListW - 12.f * UIScale && MouseY >= ListY && MouseY <= ListY + ItemH);
			const bool bSelected = (SelectedMapIndex == i);
			if (bHover) HoveredButtonIndex = 100 + i;
			RegisterButton(100 + i, ListX + 12.f * UIScale, ListY, ListW - 24.f * UIScale, ItemH, bMenuEnglish ? Map.DisplayNameEnglish : Map.DisplayNameFarsi);

			const FLinearColor CardBg = bSelected ? FLinearColor(0.035f, 0.095f, 0.090f, 0.92f) : (bHover ? FLinearColor(0.040f, 0.070f, 0.075f, 0.90f) : FLinearColor(0.020f, 0.032f, 0.038f, 0.84f));
			const FLinearColor CardBorder = bSelected ? PrimaryAccentColor : (bHover ? FLinearColor(0.55f, 0.78f, 0.76f, 0.85f) : FLinearColor(0.28f, 0.38f, 0.40f, 0.65f));
			DrawChiseledTacticalPanel(ListX + 12.f * UIScale, ListY, ListW - 24.f * UIScale, ItemH, CardBg, CardBorder, 8.f * UIScale);
			DrawRect(bSelected ? PrimaryAccentColor : FLinearColor(0.36f, 0.52f, 0.50f, 0.65f), ListX + 16.f * UIScale, ListY + 7.f * UIScale, 4.f * UIScale, ItemH - 14.f * UIScale);

			UTexture2D* ListThumb = Map.PreviewTexture ? Map.PreviewTexture.Get() : GetMapPreviewTexture(Map.MapID);
			const float ThumbW = 112.f * UIScale;
			const float ThumbH = 68.f * UIScale;
			const float ThumbX = ListX + 30.f * UIScale;
			const float ThumbY = ListY + 17.f * UIScale;
			DrawChiseledTacticalPanel(ThumbX - 2.f * UIScale, ThumbY - 2.f * UIScale, ThumbW + 4.f * UIScale, ThumbH + 4.f * UIScale, FLinearColor(0.01f, 0.018f, 0.020f, 0.95f), CardBorder * 0.70f, 4.f * UIScale);
			if (ListThumb)
			{
				DrawTexture(ListThumb, ThumbX, ThumbY, ThumbW, ThumbH, 0.f, 0.f, 1.f, 1.f, bSelected ? FLinearColor::White : FLinearColor(0.78f, 0.84f, 0.82f, 0.92f));
			}
			else
			{
				DrawTacticalTopoGrid(ThumbX, ThumbY, ThumbW, ThumbH, CardBorder);
			}

			const float TextX = ThumbX + ThumbW + 14.f * UIScale;
			const float TextW = ListX + ListW - TextX - 24.f * UIScale;
			DrawFarsiTextBounded((bMenuEnglish ? Map.DisplayNameEnglish : Map.DisplayNameFarsi).ToString(), bSelected ? PrimaryAccentColor : FLinearColor(0.90f, 0.94f, 0.94f, 1.f), TextX, ListY + 16.f * UIScale, TextW, MenuFont ? MenuFont.Get() : nullptr, 0.96f * UIScale, true);
			DrawFarsiTextBounded(GetMapSubtitleForLanguage(Map), FLinearColor(0.70f, 0.78f, 0.78f, 0.88f), TextX, ListY + 42.f * UIScale, TextW, BodyFont ? BodyFont.Get() : nullptr, 0.80f * UIScale, true);
			// L2-INI: MapSelection/Map%d_Status is live (user key).
			const FString MapStatusFmt = SquadAIMenuLocal(this, TEXT("MapSelection"), *FString::Printf(TEXT("Map%d_Status"), i + 1),
					Map.bIsSelectable ? TEXT("آماده اعزام") : TEXT("در آماده‌سازی"),
					Map.bIsSelectable ? TEXT("Ready to deploy") : TEXT("Preparing"),
					bMenuEnglish);
			const FString StatusStr = (Map.bIsSelectable ? TEXT("● ") : TEXT("○ ")) + MapStatusFmt;
			DrawFarsiTextBounded(StatusStr, Map.bIsSelectable ? PrimaryAccentColor : FLinearColor(0.70f, 0.46f, 0.40f, 0.90f), TextX, ListY + 70.f * UIScale, TextW, BodyFont ? BodyFont.Get() : nullptr, 0.80f * UIScale, true);

			ListY += ItemH + ItemGap;
		}

		const FSquadMapDefinition& SelMap = Maps[SelectedMapIndex];
		const float DetailX = ListX + ListW + 24.f * UIScale;
		const float DetailY = ListY0 - 12.f * UIScale;
		const float DetailW = PanelX + PanelW - DetailX - 24.f * UIScale;
		const float DetailH = PanelH - 118.f * UIScale;
		DrawChiseledTacticalPanel(DetailX, DetailY, DetailW, DetailH, FLinearColor(0.015f, 0.027f, 0.032f, 0.70f), PrimaryAccentColor * 0.58f, 12.f * UIScale);

		const float ImgX = DetailX + 18.f * UIScale;
		const float ImgY = DetailY + 18.f * UIScale;
		const float ImgW = DetailW - 36.f * UIScale;
		const float ImgH = FMath::Min(DetailH * 0.50f, ImgW * 9.f / 16.f);
		UTexture2D* MapTex = SelMap.PreviewTexture ? SelMap.PreviewTexture.Get() : GetMapPreviewTexture(SelMap.MapID);
		if (!MapTex) MapTex = FSquadAIAssetHelper::LoadTextureSafe(nullptr, *FString::Printf(TEXT("Textures/Map_Preview_%s.png"), *SelMap.MapID.ToString()));
		if (!MapTex) MapTex = FSquadAIAssetHelper::LoadTextureSafe(nullptr, *FString::Printf(TEXT("Textures/%s.png"), *SelMap.MapID.ToString()));
		if (!MapTex)
		{
			static TSet<FName> G9WarnedMapIDs;
			if (!G9WarnedMapIDs.Contains(SelMap.MapID))
			{
				G9WarnedMapIDs.Add(SelMap.MapID);
				UE_LOG(LogTemp, Error, TEXT("[MainMenu] Map preview missing for MapID '%s'. Expected Map_Preview_* texture or Textures/%s.png."), *SelMap.MapID.ToString(), *SelMap.MapID.ToString());
			}
		}
		DrawChiseledTacticalPanel(ImgX - 3.f * UIScale, ImgY - 3.f * UIScale, ImgW + 6.f * UIScale, ImgH + 6.f * UIScale, FLinearColor(0.006f, 0.012f, 0.014f, 0.96f), PrimaryAccentColor * 0.62f, 8.f * UIScale);
		if (MapTex) DrawTexture(MapTex, ImgX, ImgY, ImgW, ImgH, 0.f, 0.f, 1.f, 1.f, FLinearColor(0.92f, 0.96f, 0.94f, 0.98f));
		else
		{
			DrawTacticalTopoGrid(ImgX, ImgY, ImgW, ImgH, PrimaryAccentColor);
			DrawFarsiTextBounded((bMenuEnglish ? SelMap.DisplayNameEnglish : SelMap.DisplayNameFarsi).ToString(), PrimaryAccentColor, ImgX, ImgY + ImgH * 0.42f, ImgW, TitleFont ? TitleFont.Get() : nullptr, 1.25f * UIScale, true, true);
		}
		DrawRect(FLinearColor(0.f, 0.f, 0.f, 0.28f), ImgX, ImgY + ImgH - 46.f * UIScale, ImgW, 46.f * UIScale);
		DrawFarsiTextBounded((bMenuEnglish ? SelMap.DisplayNameEnglish : SelMap.DisplayNameFarsi).ToString(), FLinearColor(0.92f, 1.0f, 0.98f, 1.f), ImgX + 18.f * UIScale, ImgY + ImgH - 38.f * UIScale, ImgW - 36.f * UIScale, TitleFont ? TitleFont.Get() : nullptr, 0.98f * UIScale, true);

		auto DrawChip = [&](float X, float Y, float W, const FString& Label, const FString& Value, const FLinearColor& Accent)
		{
			DrawChiseledTacticalPanel(X, Y, W, 50.f * UIScale, FLinearColor(0.020f, 0.034f, 0.038f, 0.82f), Accent * 0.58f, 6.f * UIScale);
			DrawFarsiTextBounded(Label, FLinearColor(0.66f, 0.74f, 0.74f, 0.88f), X + 8.f * UIScale, Y + 6.f * UIScale, W - 16.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.58f * UIScale, true, true);
			DrawFarsiTextBounded(Value, Accent, X + 8.f * UIScale, Y + 24.f * UIScale, W - 16.f * UIScale, MenuFont ? MenuFont.Get() : nullptr, 0.72f * UIScale, true, true);
		};
		const float ChipY = ImgY + ImgH + 18.f * UIScale;
		const float ChipGap = 10.f * UIScale;
		const float ChipW = (ImgW - 2.f * ChipGap) / 3.f;
		DrawChip(ImgX, ChipY, ChipW,
				bMenuEnglish ? TEXT("Status") : TEXT("وضعیت"),
				SelMap.bIsSelectable ? (bMenuEnglish ? TEXT("Ready") : TEXT("آماده")) : (bMenuEnglish ? TEXT("Locked") : TEXT("قفل")),
				SelMap.bIsSelectable ? PrimaryAccentColor : SecondaryAccentColor);
		DrawChip(ImgX + ChipW + ChipGap, ChipY, ChipW, bMenuEnglish ? TEXT("Reward") : TEXT("پاداش"), FString::Printf(TEXT("%d XP"), SelMap.CompletionXPReward), FLinearColor(0.70f, 0.82f, 0.74f, 1.f));
		DrawChip(ImgX + 2.f * (ChipW + ChipGap), ChipY, ChipW, bMenuEnglish ? TEXT("Duration") : TEXT("مدت"), GetMapDurationForLanguage(SelMap), FLinearColor(0.72f, 0.74f, 0.62f, 1.f));

		const float BriefY = ChipY + 66.f * UIScale;
		const float BriefH = DetailY + DetailH - BriefY - 76.f * UIScale;
		DrawChiseledTacticalPanel(ImgX, BriefY, ImgW, BriefH, FLinearColor(0.018f, 0.030f, 0.034f, 0.72f), PrimaryAccentColor * 0.42f, 8.f * UIScale);
		DrawFarsiTextBounded((bMenuEnglish ? TEXT("Operation Intelligence File") : TEXT("پرونده اطلاعات عملیات")), PrimaryAccentColor, ImgX + 16.f * UIScale, BriefY + 12.f * UIScale, ImgW - 32.f * UIScale, MenuFont ? MenuFont.Get() : nullptr, 0.84f * UIScale, true);
		DrawFarsiTextBounded((bMenuEnglish ? SelMap.SituationBriefingEnglish : SelMap.SituationBriefingFarsi).ToString(), FLinearColor(0.84f, 0.89f, 0.88f, 0.94f), ImgX + 16.f * UIScale, BriefY + 40.f * UIScale, ImgW - 32.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.86f * UIScale, true);

		const float LaunchW = 280.f * UIScale;
		const float LaunchH = 44.f * UIScale;
		const float LaunchX = DetailX + DetailW - LaunchW - 18.f * UIScale;
		const float LaunchY = DetailY + DetailH - LaunchH - 18.f * UIScale;
		const bool bLHover = (MouseX >= LaunchX && MouseX <= LaunchX + LaunchW && MouseY >= LaunchY && MouseY <= LaunchY + LaunchH);
		if (bLHover) HoveredButtonIndex = 199;
		RegisterButton(199, LaunchX, LaunchY, LaunchW, LaunchH, FText::FromString((bMenuEnglish ? TEXT("Deploy to Battle Zone") : TEXT("اعزام به منطقه نبرد"))));
		DrawStyledButton(LaunchX, LaunchY, LaunchW, LaunchH, FText::FromString((bMenuEnglish ? TEXT("Deploy to Battle Zone") : TEXT("اعزام به منطقه نبرد"))), bLHover, !SelMap.bIsSelectable);
	}

	const float BackW = 150.f * UIScale;
	const float BackH = 38.f * UIScale;
	const float BackX = PanelX + 24.f * UIScale;
	const float BackY = PanelY + PanelH - BackH - 18.f * UIScale;
	const bool bBackHover = (MouseX >= BackX && MouseX <= BackX + BackW && MouseY >= BackY && MouseY <= BackY + BackH);
	if (bBackHover) HoveredButtonIndex = 99;
	RegisterButton(99, BackX, BackY, BackW, BackH, MenuTextConfig.ButtonBack);
	DrawStyledButton(BackX, BackY, BackW, BackH, MenuTextConfig.ButtonBack, bBackHover);
}

// =============================================================================
//  3. ARMORY & WEAPON UPGRADES SCREEN
// =============================================================================

void ASquadAIMainMenuHUD::DrawArmoryScreen(float ScreenW, float ScreenH, float MouseX, float MouseY)
{
	const bool bMenuEnglish = !CachedMenuSettings.LanguageCode.StartsWith(TEXT("fa"), ESearchCase::IgnoreCase);
	const float UIScale = FMath::Clamp(ScreenH / 1080.f, 0.70f, 1.35f);
	const float PanelX = 50.f * UIScale + SubmenuSlideOffset;
	const float PanelY = 104.f * UIScale;
	const float PanelW = ScreenW - (100.f * UIScale);
	const float PanelH = ScreenH - (170.f * UIScale);

	// AAA-B2-2: armory rebuilt into a gunsmith workbench layout. The selected weapon
	// gets the hero viewport; the left rack is compact and readable. Gold/brown hover
	// is replaced by field-slate teal with rust reserved for locked states.
	DrawRect(SquadAIRefSRGBA(0x01, 0x01, 0x01, 0.38f), 0.f, PanelY - 12.f * UIScale, ScreenW, PanelH + 42.f * UIScale);
	DrawSacredDefenseBorder(PanelX, PanelY, PanelW, PanelH, PrimaryAccentColor * 0.90f, true);

	if (BackgroundArmoryTexture)
	{
		DrawTexture(BackgroundArmoryTexture, PanelX + 5.f * UIScale, PanelY + 5.f * UIScale, PanelW - 10.f * UIScale, PanelH - 10.f * UIScale, 0.f, 0.f, 1.f, 1.f, FLinearColor(0.58f, 0.66f, 0.64f, 0.38f));
		DrawRect(FLinearColor(0.f, 0.f, 0.f, 0.46f), PanelX + 5.f * UIScale, PanelY + 5.f * UIScale, PanelW - 10.f * UIScale, PanelH - 10.f * UIScale);
	}

	DrawFarsiTextBounded((bMenuEnglish ? TEXT("Field Armory and Weapon Preparation") : TEXT("زرادخانه میدانی و آماده‌سازی سلاح | FIELD ARMORY")), PrimaryAccentColor, PanelX + 28.f * UIScale, PanelY + 18.f * UIScale, PanelW - 56.f * UIScale, TitleFont ? TitleFont.Get() : nullptr, 1.28f * UIScale, true);
	DrawFarsiTextBounded((bMenuEnglish ? TEXT("Select a weapon. Stats, historical role, traits, and equip status appear on the right.") : TEXT("سلاح را انتخاب کنید؛ مشخصات، نقش تاریخی، ویژگی‌ها و وضعیت تجهیز در سمت راست نمایش داده می‌شود.")), FLinearColor(0.78f, 0.86f, 0.86f, 0.92f), PanelX + 28.f * UIScale, PanelY + 48.f * UIScale, PanelW - 56.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.86f * UIScale, true);

	USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(this);
	const TArray<FSquadWeaponDefinition> WeaponList = Prog ? Prog->GetAvailableWeapons() : TArray<FSquadWeaponDefinition>();
	const FName CurrentEquippedWep = Prog ? Prog->GetEquippedWeaponID() : FName("G3A3");

	if (WeaponList.Num() <= 0)
	{
		DrawChiseledTacticalPanel(PanelX + 34.f * UIScale, PanelY + 92.f * UIScale, PanelW - 68.f * UIScale, 150.f * UIScale, FLinearColor(0.025f, 0.040f, 0.044f, 0.82f), SecondaryAccentColor, 10.f * UIScale);
		DrawFarsiTextBounded((bMenuEnglish ? TEXT("No weapons are registered in the armory catalog.") : TEXT("هیچ سلاحی در کاتالوگ زرادخانه ثبت نشده است.")), SecondaryAccentColor, PanelX + 56.f * UIScale, PanelY + 135.f * UIScale, PanelW - 112.f * UIScale, TitleFont ? TitleFont.Get() : nullptr, 1.06f * UIScale, true, true);
	}
	else
	{
		SelectedWeaponIndex = FMath::Clamp(SelectedWeaponIndex, 0, WeaponList.Num() - 1);

		const float RackX = PanelX + 24.f * UIScale;
		const float RackY = PanelY + 88.f * UIScale;
		const float RackW = FMath::Clamp(PanelW * 0.34f, 430.f * UIScale, 555.f * UIScale);
		const float RackH = PanelH - 118.f * UIScale;
		DrawChiseledTacticalPanel(RackX, RackY - 12.f * UIScale, RackW, RackH, FLinearColor(0.014f, 0.026f, 0.030f, 0.68f), PrimaryAccentColor * 0.46f, 10.f * UIScale);

		float RowY = RackY;
		const float RowH = 92.f * UIScale;
		const float RowGap = 9.f * UIScale;
		for (int32 i = 0; i < WeaponList.Num(); ++i)
		{
			const FSquadWeaponDefinition& W = WeaponList[i];
			const bool bHover = (MouseX >= RackX + 12.f * UIScale && MouseX <= RackX + RackW - 12.f * UIScale && MouseY >= RowY && MouseY <= RowY + RowH);
			const bool bSelected = (SelectedWeaponIndex == i);
			const bool bWepUnlocked = W.bIsUnlocked || W.bDefaultUnlocked || (W.WeaponID == FName("G3A3")) || (W.WeaponID == FName("AK47"));
			const bool bEquipped = (W.WeaponID == CurrentEquippedWep);
			if (bHover) HoveredButtonIndex = 200 + i;
			RegisterButton(200 + i, RackX + 12.f * UIScale, RowY, RackW - 24.f * UIScale, RowH, bMenuEnglish ? W.DisplayNameEnglish : W.DisplayNameFarsi);

			const FLinearColor StateColor = bEquipped ? PrimaryAccentColor : (bWepUnlocked ? FLinearColor(0.64f, 0.74f, 0.68f, 1.f) : SecondaryAccentColor);
			const FLinearColor CardBg = bSelected ? FLinearColor(0.035f, 0.092f, 0.087f, 0.92f) : (bHover ? FLinearColor(0.040f, 0.070f, 0.075f, 0.90f) : FLinearColor(0.020f, 0.032f, 0.038f, 0.84f));
			DrawChiseledTacticalPanel(RackX + 12.f * UIScale, RowY, RackW - 24.f * UIScale, RowH, CardBg, bSelected ? PrimaryAccentColor : StateColor * 0.56f, 8.f * UIScale);
			DrawRect(StateColor, RackX + 16.f * UIScale, RowY + 7.f * UIScale, 4.f * UIScale, RowH - 14.f * UIScale);

			UTexture2D* Icon = GetWeaponPreviewTexture(W.WeaponID);
			const float ThumbW = 134.f * UIScale;
			const float ThumbH = 68.f * UIScale;
			const float ThumbX = RackX + 30.f * UIScale;
			const float ThumbY = RowY + 12.f * UIScale;
			DrawChiseledTacticalPanel(ThumbX - 2.f * UIScale, ThumbY - 2.f * UIScale, ThumbW + 4.f * UIScale, ThumbH + 4.f * UIScale, FLinearColor(0.01f, 0.018f, 0.020f, 0.95f), StateColor * 0.50f, 4.f * UIScale);
			if (Icon) DrawTexture(Icon, ThumbX, ThumbY, ThumbW, ThumbH, 0.f, 0.f, 1.f, 1.f, bWepUnlocked ? FLinearColor::White : FLinearColor(0.42f, 0.46f, 0.46f, 0.85f));
			else
			{
				DrawTacticalTopoGrid(ThumbX, ThumbY, ThumbW, ThumbH, StateColor);
				DrawFarsiTextBounded(W.Caliber.ToString(), StateColor, ThumbX, ThumbY + 22.f * UIScale, ThumbW, BodyFont ? BodyFont.Get() : nullptr, 0.79f * UIScale, true, true);
			}

			const float TextX = ThumbX + ThumbW + 14.f * UIScale;
			const float TextW = RackX + RackW - TextX - 24.f * UIScale;
			DrawFarsiTextBounded((bMenuEnglish ? W.DisplayNameEnglish : W.DisplayNameFarsi).ToString(), bEquipped ? PrimaryAccentColor : FLinearColor(0.90f, 0.94f, 0.94f, 1.f), TextX, RowY + 12.f * UIScale, TextW, MenuFont ? MenuFont.Get() : nullptr, 0.94f * UIScale, true);
			DrawFarsiTextBounded(W.Caliber.ToString(), FLinearColor(0.70f, 0.78f, 0.78f, 0.88f), TextX, RowY + 38.f * UIScale, TextW, BodyFont ? BodyFont.Get() : nullptr, 0.80f * UIScale, true);
			const FString Status = bEquipped
					? (bMenuEnglish ? FString(TEXT("● Equipped")) : FString(TEXT("● تجهیز شده")))
					: (bWepUnlocked ? (bMenuEnglish ? FString(TEXT("● Ready to equip")) : FString(TEXT("● آماده تجهیز")))
						: (bMenuEnglish ? FString::Printf(TEXT("○ Locked: level %d"), W.RequiredPlayerLevel) : FString::Printf(TEXT("○ قفل: سطح %d"), W.RequiredPlayerLevel)));
			DrawFarsiTextBounded(Status, StateColor, TextX, RowY + 62.f * UIScale, TextW, BodyFont ? BodyFont.Get() : nullptr, 0.80f * UIScale, true);

			RowY += RowH + RowGap;
		}

		const FSquadWeaponDefinition& SelW = WeaponList[SelectedWeaponIndex];
		const bool bIsSelUnlocked = SelW.bIsUnlocked || SelW.bDefaultUnlocked || (SelW.WeaponID == FName("G3A3")) || (SelW.WeaponID == FName("AK47"));
		const bool bIsEquipped = (CurrentEquippedWep == SelW.WeaponID);
		const float DetailX = RackX + RackW + 24.f * UIScale;
		const float DetailY = RackY - 12.f * UIScale;
		const float DetailW = PanelX + PanelW - DetailX - 24.f * UIScale;
		const float DetailH = RackH;
		DrawChiseledTacticalPanel(DetailX, DetailY, DetailW, DetailH, FLinearColor(0.014f, 0.026f, 0.030f, 0.72f), PrimaryAccentColor * 0.58f, 12.f * UIScale);

		const float ShowX = DetailX + 18.f * UIScale;
		const float ShowY = DetailY + 18.f * UIScale;
		const float ShowW = DetailW - 36.f * UIScale;
		const float ShowH = FMath::Min(DetailH * 0.42f, ShowW * 0.45f);
		DrawChiseledTacticalPanel(ShowX, ShowY, ShowW, ShowH, FLinearColor(0.005f, 0.012f, 0.014f, 0.94f), PrimaryAccentColor * 0.50f, 8.f * UIScale);
		DrawTacticalTopoGrid(ShowX, ShowY, ShowW, ShowH, PrimaryAccentColor * 0.55f);

		UTexture2D* WTex = SelW.PreviewTexture ? SelW.PreviewTexture.Get() : GetWeaponPreviewTexture(SelW.WeaponID);
		if (WTex)
		{
			float RenderW = ShowW - 22.f * UIScale;
			float RenderH = RenderW * (2.f / 3.f);
			if (RenderH > ShowH - 14.f * UIScale)
			{
				RenderH = ShowH - 14.f * UIScale;
				RenderW = RenderH * (3.f / 2.f);
			}
			const float ImgX = ShowX + (ShowW - RenderW) * 0.5f;
			const float ImgY = ShowY + (ShowH - RenderH) * 0.5f;
			DrawTexture(WTex, ImgX, ImgY, RenderW, RenderH, 0.f, 0.f, 1.f, 1.f, bIsSelUnlocked ? FLinearColor::White : FLinearColor(0.50f, 0.55f, 0.55f, 0.82f));
		}
		else
		{
			DrawFarsiTextBounded(SelW.Caliber.ToString(), PrimaryAccentColor * 0.82f, ShowX, ShowY + ShowH * 0.32f, ShowW, TitleFont ? TitleFont.Get() : nullptr, 1.70f * UIScale, true, true);
			DrawFarsiTextBounded((bMenuEnglish ? SelW.DisplayNameEnglish : SelW.DisplayNameFarsi).ToString(), FLinearColor(0.84f, 0.90f, 0.90f, 0.92f), ShowX, ShowY + ShowH * 0.58f, ShowW, BodyFont ? BodyFont.Get() : nullptr, 0.96f * UIScale, true, true);
		}

		float CurTextY = ShowY + ShowH + 16.f * UIScale;
		DrawFarsiTextBounded((bMenuEnglish ? SelW.DisplayNameEnglish : SelW.DisplayNameFarsi).ToString(), PrimaryAccentColor, DetailX + 22.f * UIScale, CurTextY, DetailW - 44.f * UIScale, TitleFont ? TitleFont.Get() : nullptr, 1.22f * UIScale, true);
		CurTextY += 30.f * UIScale;
		DrawFarsiTextBounded((bMenuEnglish ? SelW.HistoricalRoleEnglish : SelW.HistoricalRoleFarsi).ToString(), FLinearColor(0.84f, 0.90f, 0.90f, 0.94f), DetailX + 22.f * UIScale, CurTextY, DetailW - 44.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.92f * UIScale, true);
		CurTextY += 34.f * UIScale;

		struct FWeaponStatAttributeEntry { const TCHAR* Label; float Val; };
		const FWeaponStatAttributeEntry Attrs[] = {
			{ (bMenuEnglish ? TEXT("Firepower") : TEXT("قدرت آتش")), SelW.DamageRating },
			{ (bMenuEnglish ? TEXT("Effective Range") : TEXT("برد موثر")), SelW.EffectiveRangeRating },
			{ (bMenuEnglish ? TEXT("Rate of Fire") : TEXT("نرخ شلیک")), SelW.FireRateRating },
			{ (bMenuEnglish ? TEXT("Control and Accuracy") : TEXT("کنترل و دقت")), SelW.HandlingRating }
		};
		const float BarW = (DetailW - 66.f * UIScale) * 0.5f;
		const float BarH = 11.f * UIScale;
		for (int32 ai = 0; ai < 4; ++ai)
		{
			const float ax = DetailX + 22.f * UIScale + (ai % 2) * (BarW + 22.f * UIScale);
			const float ay = CurTextY + (ai / 2) * 38.f * UIScale;
			DrawFarsiTextBounded(Attrs[ai].Label, FLinearColor(0.80f, 0.86f, 0.86f, 0.92f), ax, ay, BarW, BodyFont ? BodyFont.Get() : nullptr, 0.86f * UIScale, true);
			DrawStatBar(ax, ay + 18.f * UIScale, BarW, BarH, Attrs[ai].Val, PrimaryAccentColor, FLinearColor(0.09f, 0.13f, 0.14f, 0.90f));
		}
		CurTextY += 88.f * UIScale;

		DrawFarsiTextBounded((bMenuEnglish ? TEXT("Combat Traits") : TEXT("ویژگی‌های رزمی")), PrimaryAccentColor, DetailX + 22.f * UIScale, CurTextY, DetailW - 44.f * UIScale, MenuFont ? MenuFont.Get() : nullptr, 0.86f * UIScale, true);
		CurTextY += 26.f * UIScale;
		const float BadgeW = (DetailW - 54.f * UIScale) * 0.5f;
		const float BadgeH = 56.f * UIScale;
		for (int32 ti = 0; ti < SelW.SpecialityTraits.Num() && ti < 2; ++ti)
		{
			const float bx = DetailX + 22.f * UIScale + ti * (BadgeW + 10.f * UIScale);
			const bool bHover = (MouseX >= bx && MouseX <= bx + BadgeW && MouseY >= CurTextY && MouseY <= CurTextY + BadgeH);
			DrawSpecialityBadge(bx, CurTextY, BadgeW, BadgeH, SelW.SpecialityTraits[ti], bHover);
		}

		const float ActW = 286.f * UIScale;
		const float ActH = 44.f * UIScale;
		const float ActX = DetailX + DetailW - ActW - 18.f * UIScale;
		const float ActY = DetailY + DetailH - ActH - 18.f * UIScale;
		if (bIsSelUnlocked)
		{
			const bool bActHover = (MouseX >= ActX && MouseX <= ActX + ActW && MouseY >= ActY && MouseY <= ActY + ActH);
			if (bActHover) HoveredButtonIndex = 299;
			const FText ActLabel = bIsEquipped ? FText::FromString((bMenuEnglish ? TEXT("Weapon Active and Equipped") : TEXT("سلاح فعال و تجهیز شده"))) : FText::FromString((bMenuEnglish ? TEXT("Equip and Activate in Field") : TEXT("تجهیز و فعال‌سازی در میدان")));
			RegisterButton(299, ActX, ActY, ActW, ActH, ActLabel);
			DrawStyledButton(ActX, ActY, ActW, ActH, ActLabel, bActHover, bIsEquipped);
		}
		else
		{
			const bool bActHover = (MouseX >= ActX && MouseX <= ActX + ActW && MouseY >= ActY && MouseY <= ActY + ActH);
			if (bActHover) HoveredButtonIndex = 298;
			FText UnlockFailReason;
			const bool bCanUnlock = (Prog && Prog->CanUnlockWeapon(SelW.WeaponID, UnlockFailReason));
			const FText ActLabel = bCanUnlock
					? FText::FromString(bMenuEnglish ? FString::Printf(TEXT("Unlock Weapon (%d XP)"), SelW.XPCostToUnlock) : FString::Printf(TEXT("آزادسازی سلاح (%d XP)"), SelW.XPCostToUnlock))
					: FText::FromString(UnlockFailReason.ToString());
			RegisterButton(298, ActX, ActY, ActW, ActH, ActLabel);
			DrawStyledButton(ActX, ActY, ActW, ActH, ActLabel, bActHover, !bCanUnlock);
		}
	}

	const float BackW = 150.f * UIScale;
	const float BackH = 38.f * UIScale;
	const float BackX = PanelX + 24.f * UIScale;
	const float BackY = PanelY + PanelH - BackH - 18.f * UIScale;
	const bool bBackHover = (MouseX >= BackX && MouseX <= BackX + BackW && MouseY >= BackY && MouseY <= BackY + BackH);
	if (bBackHover) HoveredButtonIndex = 99;
	RegisterButton(99, BackX, BackY, BackW, BackH, MenuTextConfig.ButtonBack);
	DrawStyledButton(BackX, BackY, BackW, BackH, MenuTextConfig.ButtonBack, bBackHover);
}

// =============================================================================
//  4. SQUAD ATTRIBUTES & TALENT TREE (ارتقای توانمندی‌ها)
// =============================================================================

void ASquadAIMainMenuHUD::DrawMilestoneProgressionTrack(float X, float Y, float W, float H, int32 UnlockedCount, int32 TotalMilestones, float UIScale)
{
	if (TotalMilestones <= 0) TotalMilestones = 6;
	UnlockedCount = FMath::Clamp(UnlockedCount, 0, TotalMilestones);

	// AAA-B3-0: cool oxidized-slate milestone cells replace the old warm ornamental strip.
	DrawChiseledTacticalPanel(X, Y, W, H, FLinearColor(0.012f, 0.024f, 0.027f, 0.94f), FLinearColor(0.34f, 0.50f, 0.48f, 0.80f), 4.f * UIScale);

	const float SlotPadX = 6.f * UIScale;
	const float SlotPadY = 5.f * UIScale;
	const float AvailableW = W - (SlotPadX * 2.f);
	const float AvailableH = H - (SlotPadY * 2.f);
	const float Gap = 6.f * UIScale;
	const float CellW = (AvailableW - (Gap * (TotalMilestones - 1))) / TotalMilestones;

	for (int32 i = 0; i < TotalMilestones; ++i)
	{
		const float cx = X + SlotPadX + i * (CellW + Gap);
		const float cy = Y + SlotPadY;
		const bool bFilled = (i < UnlockedCount);

		if (bFilled)
		{
			DrawChiseledTacticalPanel(cx, cy, CellW, AvailableH, FLinearColor(0.035f, 0.110f, 0.102f, 0.98f), PrimaryAccentColor, 3.f * UIScale);
			DrawRect(PrimaryAccentColor * 0.82f, cx + 2.f * UIScale, cy + 2.f * UIScale, CellW - 4.f * UIScale, AvailableH - 4.f * UIScale);
			DrawRect(FLinearColor(0.78f, 1.0f, 0.95f, 0.58f), cx + 4.f * UIScale, cy + 4.f * UIScale, CellW - 8.f * UIScale, 2.f * UIScale);

			const FString NumStr = FString::Printf(TEXT("✓ %d"), i + 1);
			DrawFarsiTextBounded(NumStr, FLinearColor(0.02f, 0.05f, 0.05f, 1.0f), cx, cy, CellW, MenuFont ? MenuFont.Get() : nullptr, 0.82f * UIScale, false, true, AvailableH);
		}
		else
		{
			DrawChiseledTacticalPanel(cx, cy, CellW, AvailableH, FLinearColor(0.030f, 0.040f, 0.045f, 0.88f), FLinearColor(0.24f, 0.34f, 0.35f, 0.62f), 3.f * UIScale);

			const FString NumStr = FString::Printf(TEXT("○ %d"), i + 1);
			DrawFarsiTextBounded(NumStr, FLinearColor(0.54f, 0.63f, 0.62f, 0.80f), cx, cy, CellW, BodyFont ? BodyFont.Get() : nullptr, 0.78f * UIScale, false, true, AvailableH);
		}
	}
}

void ASquadAIMainMenuHUD::DrawPlayerProgressionScreen(float ScreenW, float ScreenH, float MouseX, float MouseY)
{
	const bool bMenuEnglish = !CachedMenuSettings.LanguageCode.StartsWith(TEXT("fa"), ESearchCase::IgnoreCase);
	const float UIScale = FMath::Clamp(ScreenH / 1080.f, 0.70f, 1.35f);
	const float PanelX = 50.f * UIScale + SubmenuSlideOffset;
	const float PanelY = 104.f * UIScale;
	const float PanelW = ScreenW - (100.f * UIScale);
	const float PanelH = ScreenH - (170.f * UIScale);

	// AAA-B3-1: progression screen rebuilt as a doctrine operations board.
	DrawRect(FLinearColor(0.f, 0.f, 0.f, 0.36f), 0.f, PanelY - 12.f * UIScale, ScreenW, PanelH + 42.f * UIScale);
	DrawSacredDefenseBorder(PanelX, PanelY, PanelW, PanelH, PrimaryAccentColor * 0.90f, true);
	if (BackgroundProgressionTexture)
	{
		DrawTexture(BackgroundProgressionTexture, PanelX + 5.f * UIScale, PanelY + 5.f * UIScale, PanelW - 10.f * UIScale, PanelH - 10.f * UIScale, 0.f, 0.f, 1.f, 1.f, FLinearColor(0.55f, 0.66f, 0.64f, 0.34f));
		DrawRect(FLinearColor(0.f, 0.f, 0.f, 0.50f), PanelX + 5.f * UIScale, PanelY + 5.f * UIScale, PanelW - 10.f * UIScale, PanelH - 10.f * UIScale);
	}

	DrawFarsiTextBounded((bMenuEnglish ? TEXT("Doctrine Board and Skill Upgrades") : TEXT("برد دکترین و ارتقای توانمندی‌ها | DOCTRINE BOARD")), PrimaryAccentColor, PanelX + 28.f * UIScale, PanelY + 18.f * UIScale, PanelW - 56.f * UIScale, TitleFont ? TitleFont.Get() : nullptr, 1.24f * UIScale, true);
	DrawFarsiTextBounded((bMenuEnglish ? TEXT("Operational upgrade cards with cost, unlock state, and combat effect; clean AAA layout without ornamental clutter.") : TEXT("کارت‌های عملیاتی با هزینه، وضعیت بازگشایی و اثر رزمی؛ مناسب نمای AAA و بدون شلوغی تزئینی.")), FLinearColor(0.78f, 0.86f, 0.86f, 0.92f), PanelX + 28.f * UIScale, PanelY + 48.f * UIScale, PanelW - 56.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.84f * UIScale, true);

	USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(this);
	const FSquadPlayerProfile Prof = Prog ? Prog->GetActiveProfile() : FSquadPlayerProfile();
	const int32 AvailPoints = Prog ? Prog->GetAvailableUpgradePoints() : 0;
	const TArray<FSquadProgressionNode> Nodes = Prog ? Prog->GetProgressionNodes() : TArray<FSquadProgressionNode>();
	if (Nodes.Num() > 0) ActiveProgressionInspectIdx = FMath::Clamp(ActiveProgressionInspectIdx, 0, Nodes.Num() - 1);
	else ActiveProgressionInspectIdx = 0;

	auto DrawStatusChip = [&](float X, float Y, float W, float H, const FString& Label, const FString& Value, const FLinearColor& Accent)
	{
		DrawChiseledTacticalPanel(X, Y, W, H, FLinearColor(0.016f, 0.030f, 0.034f, 0.82f), Accent * 0.58f, 6.f * UIScale);
		DrawFarsiTextBounded(Label, FLinearColor(0.66f, 0.74f, 0.74f, 0.88f), X + 10.f * UIScale, Y + 7.f * UIScale, W - 20.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.58f * UIScale, true, true);
		DrawFarsiTextBounded(Value, Accent, X + 10.f * UIScale, Y + 27.f * UIScale, W - 20.f * UIScale, TitleFont ? TitleFont.Get() : nullptr, 0.86f * UIScale, true, true);
	};

	const float LeftX = PanelX + 24.f * UIScale;
	const float TopY = PanelY + 88.f * UIScale;
	const float LeftW = FMath::Clamp(PanelW * 0.23f, 300.f * UIScale, 360.f * UIScale);
	const float RightW = FMath::Clamp(PanelW * 0.29f, 410.f * UIScale, 500.f * UIScale);
	const float Gap = 22.f * UIScale;
	const float GridX = LeftX + LeftW + Gap;
	const float GridW = PanelW - LeftW - RightW - (3.f * Gap) - 24.f * UIScale;
	const float RightX = GridX + GridW + Gap;
	const float BoardH = PanelH - 118.f * UIScale;

	// Left service/progression summary.
	DrawChiseledTacticalPanel(LeftX, TopY - 12.f * UIScale, LeftW, BoardH, FLinearColor(0.014f, 0.026f, 0.030f, 0.70f), PrimaryAccentColor * 0.45f, 10.f * UIScale);
	DrawRect(PrimaryAccentColor, LeftX + 16.f * UIScale, TopY + 8.f * UIScale, 4.f * UIScale, 40.f * UIScale);
	DrawFarsiTextBounded((bMenuEnglish ? TEXT("Soldier Status") : TEXT("وضعیت رزمنده")), PrimaryAccentColor, LeftX + 30.f * UIScale, TopY + 2.f * UIScale, LeftW - 54.f * UIScale, MenuFont ? MenuFont.Get() : nullptr, 0.88f * UIScale, true);
	DrawFarsiTextBounded(Prof.PlayerName, FLinearColor(0.90f, 0.95f, 0.94f, 0.96f), LeftX + 30.f * UIScale, TopY + 28.f * UIScale, LeftW - 54.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.84f * UIScale, true);

	float ChipY = TopY + 74.f * UIScale;
	DrawStatusChip(LeftX + 16.f * UIScale, ChipY, LeftW - 32.f * UIScale, 58.f * UIScale, (bMenuEnglish ? TEXT("Current Level") : TEXT("سطح فعلی")), FString::Printf(TEXT("%d"), Prof.PlayerLevel), PrimaryAccentColor);
	ChipY += 68.f * UIScale;
	DrawStatusChip(LeftX + 16.f * UIScale, ChipY, LeftW - 32.f * UIScale, 58.f * UIScale, (bMenuEnglish ? TEXT("Total XP") : TEXT("امتیاز کل")), FString::Printf(TEXT("%d XP"), Prof.TotalXP), FLinearColor(0.70f, 0.82f, 0.74f, 1.f));
	ChipY += 68.f * UIScale;
	DrawStatusChip(LeftX + 16.f * UIScale, ChipY, LeftW - 32.f * UIScale, 58.f * UIScale, (bMenuEnglish ? TEXT("Upgrade Points") : TEXT("امتیاز ارتقا")), FString::Printf(TEXT("%d"), AvailPoints), AvailPoints > 0 ? PrimaryAccentColor : FLinearColor(0.60f, 0.68f, 0.67f, 0.92f));

	const float TrackY = ChipY + 88.f * UIScale;
	int32 UnlockedCount = 0;
	for (const FSquadProgressionNode& N : Nodes) { if (N.bUnlocked) ++UnlockedCount; }
	DrawFarsiTextBounded((bMenuEnglish ? TEXT("Doctrine Readiness Track") : TEXT("نوار آمادگی دکترین")), FLinearColor(0.76f, 0.84f, 0.83f, 0.90f), LeftX + 16.f * UIScale, TrackY - 24.f * UIScale, LeftW - 32.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.80f * UIScale, true, true);
	DrawMilestoneProgressionTrack(LeftX + 16.f * UIScale, TrackY, LeftW - 32.f * UIScale, 38.f * UIScale, UnlockedCount, FMath::Max(1, Nodes.Num()), UIScale);
	DrawFarsiTextBounded((bMenuEnglish ? TEXT("Hint: inspect a card, then unlock it with upgrade points.") : TEXT("راهنما: کارت را بررسی کنید، سپس با امتیاز ارتقا بازگشایی کنید.")), FLinearColor(0.63f, 0.70f, 0.70f, 0.78f), LeftX + 16.f * UIScale, TopY + BoardH - 78.f * UIScale, LeftW - 32.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.76f * UIScale, true, true);

	// Center doctrine card grid.
	DrawChiseledTacticalPanel(GridX, TopY - 12.f * UIScale, GridW, BoardH, FLinearColor(0.012f, 0.024f, 0.028f, 0.66f), PrimaryAccentColor * 0.38f, 10.f * UIScale);
	DrawTacticalTopoGrid(GridX + 10.f * UIScale, TopY, GridW - 20.f * UIScale, BoardH - 24.f * UIScale, PrimaryAccentColor * 0.35f);
	DrawFarsiTextBounded((bMenuEnglish ? TEXT("Field Training Branches") : TEXT("شاخه‌های آموزش میدانی")), PrimaryAccentColor, GridX + 22.f * UIScale, TopY + 10.f * UIScale, GridW - 44.f * UIScale, MenuFont ? MenuFont.Get() : nullptr, 0.86f * UIScale, true);

	if (Nodes.Num() == 0)
	{
		DrawFarsiTextBounded((bMenuEnglish ? TEXT("No upgrade nodes are registered in the current catalog.") : TEXT("هیچ گره ارتقایی در کاتالوگ فعلی ثبت نشده است.")), FLinearColor(0.78f, 0.84f, 0.84f, 0.90f), GridX + 35.f * UIScale, TopY + 92.f * UIScale, GridW - 70.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.96f * UIScale, true, true);
	}
	else
	{
		const int32 ColCount = 2;
		const int32 RowCount = FMath::Max(1, FMath::CeilToInt((float)Nodes.Num() / (float)ColCount));
		const float CardGap = 14.f * UIScale;
		const float CardW = (GridW - 48.f * UIScale - CardGap) / 2.f;
		const float AvailableCardsH = BoardH - 72.f * UIScale;
		const float CardH = FMath::Clamp((AvailableCardsH - (RowCount - 1) * CardGap) / RowCount, 96.f * UIScale, 138.f * UIScale);
		const float CardsY = TopY + 50.f * UIScale;

		for (int32 i = 0; i < Nodes.Num(); ++i)
		{
			const FSquadProgressionNode& N = Nodes[i];
			const int32 Col = i % ColCount;
			const int32 Row = i / ColCount;
			const float cx = GridX + 22.f * UIScale + Col * (CardW + CardGap);
			const float cy = CardsY + Row * (CardH + CardGap);
			const bool bHover = (MouseX >= cx && MouseX <= cx + CardW && MouseY >= cy && MouseY <= cy + CardH);
			const bool bSelected = (ActiveProgressionInspectIdx == i);
			const bool bCanBuy = !N.bUnlocked && AvailPoints >= N.Cost;
			const FLinearColor StateAccent = N.bUnlocked ? PrimaryAccentColor : (bCanBuy ? FLinearColor(0.70f, 0.82f, 0.74f, 1.f) : FLinearColor(0.74f, 0.28f, 0.22f, 1.f));

			if (bHover)
			{
				HoveredButtonIndex = 300 + i;
				ActiveProgressionInspectIdx = i;
			}
			RegisterButton(300 + i, cx, cy, CardW, CardH, bMenuEnglish ? N.DisplayNameEnglish : N.DisplayNameFarsi);

			DrawChiseledTacticalPanel(cx, cy, CardW, CardH, bSelected ? FLinearColor(0.032f, 0.076f, 0.078f, 0.96f) : FLinearColor(0.026f, 0.038f, 0.043f, 0.90f), (bSelected || bHover) ? StateAccent : FLinearColor(0.28f, 0.36f, 0.37f, 0.74f), 7.f * UIScale);
			DrawRect(StateAccent, cx, cy, 4.f * UIScale, CardH);

			const float IconSize = 54.f * UIScale;
			const float IconX = cx + 14.f * UIScale;
			const float IconY = cy + 14.f * UIScale;
			UTexture2D* Icon = N.IconTexture ? N.IconTexture.Get() : GetTraitTexture(N.NodeID);
			if (FrameBadgeHexagonTexture) DrawTexture(FrameBadgeHexagonTexture, IconX - 5.f * UIScale, IconY - 5.f * UIScale, IconSize + 10.f * UIScale, IconSize + 10.f * UIScale, 0.f, 0.f, 1.f, 1.f, StateAccent * 0.75f);
			else DrawChiseledTacticalPanel(IconX - 3.f * UIScale, IconY - 3.f * UIScale, IconSize + 6.f * UIScale, IconSize + 6.f * UIScale, FLinearColor(0.01f, 0.02f, 0.025f, 0.92f), StateAccent * 0.65f, 4.f * UIScale);
			if (Icon) DrawTexture(Icon, IconX, IconY, IconSize, IconSize, 0.f, 0.f, 1.f, 1.f, N.bUnlocked ? FLinearColor::White : FLinearColor(0.76f, 0.84f, 0.84f, 0.86f));
			else DrawFarsiTextBounded(TEXT("★"), StateAccent, IconX, IconY, IconSize, TitleFont ? TitleFont.Get() : nullptr, 1.1f * UIScale, true, true, IconSize);

			const float TextX = IconX + IconSize + 14.f * UIScale;
			const float TextW = CardW - (TextX - cx) - 16.f * UIScale;
			DrawFarsiTextBounded((bMenuEnglish ? N.DisplayNameEnglish : N.DisplayNameFarsi).ToString(), FLinearColor(0.92f, 0.97f, 0.96f, 1.f), TextX, cy + 12.f * UIScale, TextW, MenuFont ? MenuFont.Get() : nullptr, 0.72f * UIScale, true);
			DrawFarsiTextBounded((bMenuEnglish ? N.DescriptionEnglish : N.DescriptionFarsi).ToString(), FLinearColor(0.66f, 0.74f, 0.74f, 0.86f), TextX, cy + 38.f * UIScale, TextW, BodyFont ? BodyFont.Get() : nullptr, 0.54f * UIScale, false);

			const FString CostStr = N.bUnlocked
					? (bMenuEnglish ? FString(TEXT("Unlocked")) : FString(TEXT("بازگشایی شده")))
					: (bMenuEnglish ? FString::Printf(TEXT("Cost: %d points"), N.Cost) : FString::Printf(TEXT("هزینه: %d امتیاز"), N.Cost));
			DrawFarsiTextBounded(CostStr, StateAccent, TextX, cy + CardH - 26.f * UIScale, TextW, BodyFont ? BodyFont.Get() : nullptr, 0.76f * UIScale, true);
		}
	}

	// Right doctrine inspector.
	DrawChiseledTacticalPanel(RightX, TopY - 12.f * UIScale, RightW, BoardH, FLinearColor(0.014f, 0.026f, 0.030f, 0.78f), PrimaryAccentColor * 0.50f, 10.f * UIScale);
	DrawRect(PrimaryAccentColor, RightX + 18.f * UIScale, TopY + 12.f * UIScale, RightW - 36.f * UIScale, 3.f * UIScale);
	DrawFarsiTextBounded((bMenuEnglish ? TEXT("Selected Node File") : TEXT("پرونده گره انتخاب‌شده")), PrimaryAccentColor, RightX + 22.f * UIScale, TopY + 28.f * UIScale, RightW - 44.f * UIScale, MenuFont ? MenuFont.Get() : nullptr, 0.86f * UIScale, true, true);

	if (Nodes.IsValidIndex(ActiveProgressionInspectIdx))
	{
		const FSquadProgressionNode& ActiveN = Nodes[ActiveProgressionInspectIdx];
		const bool bCanBuy = !ActiveN.bUnlocked && AvailPoints >= ActiveN.Cost;
		const FLinearColor StatusColor = ActiveN.bUnlocked ? PrimaryAccentColor : (bCanBuy ? FLinearColor(0.70f, 0.82f, 0.74f, 1.f) : FLinearColor(0.74f, 0.28f, 0.22f, 1.f));
		const float BadgeSize = 104.f * UIScale;
		const float BadgeX = RightX + (RightW - BadgeSize) * 0.5f;
		const float BadgeY = TopY + 76.f * UIScale;
		UTexture2D* Icon = ActiveN.IconTexture ? ActiveN.IconTexture.Get() : GetTraitTexture(ActiveN.NodeID);
		if (FrameBadgeHexagonTexture) DrawTexture(FrameBadgeHexagonTexture, BadgeX - 10.f * UIScale, BadgeY - 10.f * UIScale, BadgeSize + 20.f * UIScale, BadgeSize + 20.f * UIScale, 0.f, 0.f, 1.f, 1.f, StatusColor * 0.90f);
		else DrawChiseledTacticalPanel(BadgeX - 8.f * UIScale, BadgeY - 8.f * UIScale, BadgeSize + 16.f * UIScale, BadgeSize + 16.f * UIScale, FLinearColor(0.02f, 0.035f, 0.038f, 0.94f), StatusColor * 0.75f, 6.f * UIScale);
		if (Icon) DrawTexture(Icon, BadgeX, BadgeY, BadgeSize, BadgeSize, 0.f, 0.f, 1.f, 1.f, ActiveN.bUnlocked ? FLinearColor::White : FLinearColor(0.76f, 0.84f, 0.84f, 0.86f));
		else DrawFarsiTextBounded(TEXT("★"), StatusColor, BadgeX, BadgeY, BadgeSize, TitleFont ? TitleFont.Get() : nullptr, 2.1f * UIScale, true, true, BadgeSize);

		DrawFarsiTextBounded((bMenuEnglish ? ActiveN.DisplayNameEnglish : ActiveN.DisplayNameFarsi).ToString(), FLinearColor(0.94f, 0.98f, 0.97f, 1.f), RightX + 26.f * UIScale, BadgeY + BadgeSize + 18.f * UIScale, RightW - 52.f * UIScale, TitleFont ? TitleFont.Get() : nullptr, 0.90f * UIScale, true, true);
		DrawFarsiTextBounded(ActiveN.DisplayNameEnglish.ToString(), FLinearColor(0.64f, 0.72f, 0.72f, 0.82f), RightX + 26.f * UIScale, BadgeY + BadgeSize + 48.f * UIScale, RightW - 52.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.76f * UIScale, false, true);
		DrawFarsiTextBounded((bMenuEnglish ? ActiveN.DescriptionEnglish : ActiveN.DescriptionFarsi).ToString(), FLinearColor(0.78f, 0.86f, 0.85f, 0.92f), RightX + 28.f * UIScale, BadgeY + BadgeSize + 86.f * UIScale, RightW - 56.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.80f * UIScale, true);

		const FString Status = ActiveN.bUnlocked
				? (bMenuEnglish ? FString(TEXT("Status: recorded in dossier")) : FString(TEXT("وضعیت: ثبت‌شده در پرونده")))
				: (bCanBuy ? (bMenuEnglish ? FString(TEXT("Status: ready to unlock")) : FString(TEXT("وضعیت: آماده بازگشایی")))
					: (bMenuEnglish ? FString(TEXT("Status: more points required")) : FString(TEXT("وضعیت: نیازمند امتیاز بیشتر"))));
		DrawChiseledTacticalPanel(RightX + 24.f * UIScale, TopY + BoardH - 132.f * UIScale, RightW - 48.f * UIScale, 44.f * UIScale, FLinearColor(0.020f, 0.036f, 0.040f, 0.88f), StatusColor * 0.64f, 5.f * UIScale);
		DrawFarsiTextBounded(Status, StatusColor, RightX + 34.f * UIScale, TopY + BoardH - 122.f * UIScale, RightW - 68.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.84f * UIScale, true, true);

		const float ActX = RightX + 42.f * UIScale;
		const float ActY = TopY + BoardH - 72.f * UIScale;
		const float ActW = RightW - 84.f * UIScale;
		const float ActH = 42.f * UIScale;
		const bool bActHover = (MouseX >= ActX && MouseX <= ActX + ActW && MouseY >= ActY && MouseY <= ActY + ActH);
		if (bActHover) HoveredButtonIndex = 300 + ActiveProgressionInspectIdx;
		const FText ActLabel = ActiveN.bUnlocked ? FText::FromString((bMenuEnglish ? TEXT("Doctrine Active") : TEXT("این آموزه فعال است"))) : (bCanBuy ? FText::FromString((bMenuEnglish ? TEXT("Unlock Doctrine") : TEXT("بازگشایی آموزه"))) : FText::FromString((bMenuEnglish ? TEXT("Not Enough Points") : TEXT("امتیاز ناکافی"))));
		RegisterButton(300 + ActiveProgressionInspectIdx, ActX, ActY, ActW, ActH, ActLabel);
		DrawStyledButton(ActX, ActY, ActW, ActH, ActLabel, bActHover, ActiveN.bUnlocked || !bCanBuy);
	}

	const float BackW = 160.f * UIScale;
	const float BackH = 40.f * UIScale;
	const float BackX = PanelX + PanelW - BackW - 26.f * UIScale;
	const float BackY = PanelY + PanelH - BackH - 18.f * UIScale;
	const bool bBackHover = (MouseX >= BackX && MouseX <= BackX + BackW && MouseY >= BackY && MouseY <= BackY + BackH);
	if (bBackHover) HoveredButtonIndex = 99;
	RegisterButton(99, BackX, BackY, BackW, BackH, MenuTextConfig.ButtonBack);
	DrawStyledButton(BackX, BackY, BackW, BackH, MenuTextConfig.ButtonBack, bBackHover);
}

void ASquadAIMainMenuHUD::DrawPlayerProfileScreen(float ScreenW, float ScreenH, float MouseX, float MouseY)
{
	const bool bMenuEnglish = !CachedMenuSettings.LanguageCode.StartsWith(TEXT("fa"), ESearchCase::IgnoreCase);
	const float UIScale = FMath::Clamp(ScreenH / 1080.f, 0.70f, 1.35f);
	const float PanelX = 50.f * UIScale + SubmenuSlideOffset;
	const float PanelY = 104.f * UIScale;
	const float PanelW = ScreenW - (100.f * UIScale);
	const float PanelH = ScreenH - (170.f * UIScale);

	// AAA-B3-2: profile is now a service dossier / personnel card command desk.
	DrawRect(SquadAIRefSRGBA(0x01, 0x01, 0x01, 0.38f), 0.f, PanelY - 12.f * UIScale, ScreenW, PanelH + 42.f * UIScale);
	DrawSacredDefenseBorder(PanelX, PanelY, PanelW, PanelH, PrimaryAccentColor * 0.92f, true);

	DrawFarsiTextBounded(SquadAIMenuLocal(this, TEXT("Profile"), TEXT("HeaderTitle"), TEXT("پرونده رزمنده | SERVICE DOSSIER"), TEXT("Soldier Service Dossier"), bMenuEnglish), PrimaryAccentColor, PanelX + 28.f * UIScale, PanelY + 18.f * UIScale, PanelW - 56.f * UIScale, TitleFont ? TitleFont.Get() : nullptr, 1.25f * UIScale, true);
	DrawFarsiTextBounded((bMenuEnglish ? TEXT("Choose profile, avatar badge, field name, and combat record in one readable tactical card.") : TEXT("انتخاب پروفایل، نشان چهره، نام میدانی و سوابق رزمی در یک کارت خوانا و تاکتیکی.")), FLinearColor(0.78f, 0.86f, 0.86f, 0.92f), PanelX + 28.f * UIScale, PanelY + 48.f * UIScale, PanelW - 56.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.84f * UIScale, true);

	USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(this);
	const FSquadPlayerProfile Prof = Prog ? Prog->GetActiveProfile() : FSquadPlayerProfile();
	const TArray<FSquadPlayerProfile> Profiles = Prog ? Prog->GetAllProfiles() : TArray<FSquadPlayerProfile>();
	const int32 ActiveProfIdx = Prog ? Prog->GetActiveProfileIndex() : 0;
	ActiveProfileSlotIndex = FMath::Max(0, ActiveProfIdx);

	auto DrawMiniMetric = [&](float X, float Y, float W, float H, const FString& Label, const FString& Value, const FLinearColor& Accent)
	{
		DrawChiseledTacticalPanel(X, Y, W, H, FLinearColor(0.016f, 0.029f, 0.033f, 0.88f), Accent * 0.54f, 5.f * UIScale);
		DrawFarsiTextBounded(Label, FLinearColor(0.66f, 0.74f, 0.74f, 0.86f), X + 10.f * UIScale, Y + 6.f * UIScale, W - 20.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.56f * UIScale, true, true);
		DrawFarsiTextBounded(Value, Accent, X + 10.f * UIScale, Y + 27.f * UIScale, W - 20.f * UIScale, TitleFont ? TitleFont.Get() : nullptr, 0.78f * UIScale, true, true);
	};

	const float TopY = PanelY + 88.f * UIScale;
	const float Gap = 22.f * UIScale;
	const float SlotW = FMath::Clamp(PanelW * 0.22f, 310.f * UIScale, 370.f * UIScale);
	const float CardW = FMath::Clamp(PanelW * 0.36f, 560.f * UIScale, 690.f * UIScale);
	const float SideW = PanelW - SlotW - CardW - 4.f * Gap;
	const float SlotX = PanelX + 24.f * UIScale;
	const float CardX = SlotX + SlotW + Gap;
	const float SideX = CardX + CardW + Gap;
	const float WorkH = PanelH - 118.f * UIScale;

	// Left profile roster.
	DrawChiseledTacticalPanel(SlotX, TopY - 12.f * UIScale, SlotW, WorkH, FLinearColor(0.014f, 0.026f, 0.030f, 0.70f), PrimaryAccentColor * 0.42f, 10.f * UIScale);
	DrawFarsiTextBounded((bMenuEnglish ? TEXT("Dossier List") : TEXT("فهرست پرونده‌ها")), PrimaryAccentColor, SlotX + 20.f * UIScale, TopY + 4.f * UIScale, SlotW - 40.f * UIScale, MenuFont ? MenuFont.Get() : nullptr, 0.86f * UIScale, true);

	float SlotY = TopY + 42.f * UIScale;
	const int32 VisibleProfiles = FMath::Min(Profiles.Num(), 6);
	for (int32 pi = 0; pi < VisibleProfiles; ++pi)
	{
		const FSquadPlayerProfile& P = Profiles[pi];
		const float RowH = 64.f * UIScale;
		const bool bActive = (pi == ActiveProfIdx);
		const bool bHover = (MouseX >= SlotX + 16.f * UIScale && MouseX <= SlotX + SlotW - 16.f * UIScale && MouseY >= SlotY && MouseY <= SlotY + RowH);
		if (bHover) HoveredButtonIndex = 410 + pi;
		RegisterButton(410 + pi, SlotX + 16.f * UIScale, SlotY, SlotW - 32.f * UIScale, RowH, FText::FromString(P.PlayerName));
		DrawChiseledTacticalPanel(SlotX + 16.f * UIScale, SlotY, SlotW - 32.f * UIScale, RowH, bActive ? FLinearColor(0.030f, 0.075f, 0.074f, 0.96f) : FLinearColor(0.026f, 0.038f, 0.043f, 0.88f), (bActive || bHover) ? PrimaryAccentColor : FLinearColor(0.26f, 0.34f, 0.36f, 0.70f), 6.f * UIScale);
		DrawFarsiTextBounded(bMenuEnglish ? FString::Printf(TEXT("Dossier %02d"), pi + 1) : FString::Printf(TEXT("پرونده %02d"), pi + 1), bActive ? PrimaryAccentColor : FLinearColor(0.63f, 0.71f, 0.71f, 0.82f), SlotX + 28.f * UIScale, SlotY + 8.f * UIScale, SlotW - 56.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.54f * UIScale, true);
		DrawFarsiTextBounded(P.PlayerName, FLinearColor(0.90f, 0.96f, 0.95f, 0.96f), SlotX + 28.f * UIScale, SlotY + 28.f * UIScale, SlotW - 56.f * UIScale, MenuFont ? MenuFont.Get() : nullptr, 0.68f * UIScale, true);
		SlotY += RowH + 10.f * UIScale;
	}
	if (VisibleProfiles == 0)
	{
		DrawFarsiTextBounded((bMenuEnglish ? TEXT("No saved dossiers yet.") : TEXT("هنوز پرونده ذخیره‌شده‌ای وجود ندارد.")), FLinearColor(0.72f, 0.80f, 0.80f, 0.84f), SlotX + 24.f * UIScale, SlotY + 8.f * UIScale, SlotW - 48.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.82f * UIScale, true, true);
		SlotY += 82.f * UIScale;
	}

	const float CreateH = 42.f * UIScale;
	const bool bCreateHover = (MouseX >= SlotX + 16.f * UIScale && MouseX <= SlotX + SlotW - 16.f * UIScale && MouseY >= SlotY && MouseY <= SlotY + CreateH);
	if (bCreateHover) HoveredButtonIndex = 460;
	RegisterButton(460, SlotX + 16.f * UIScale, SlotY, SlotW - 32.f * UIScale, CreateH, FText::FromString((bMenuEnglish ? TEXT("+ Create New Dossier") : TEXT("+ ایجاد پرونده جدید"))));
	DrawStyledButton(SlotX + 16.f * UIScale, SlotY, SlotW - 32.f * UIScale, CreateH, FText::FromString((bMenuEnglish ? TEXT("+ Create New Dossier") : TEXT("+ ایجاد پرونده جدید"))), bCreateHover);

	DrawFarsiTextBounded((bMenuEnglish ? TEXT("Names and identifiers are stored only in this local dossier system.") : TEXT("شناسه‌ها و نام‌ها فقط در همین سیستم پرونده ذخیره می‌شوند.")), FLinearColor(0.60f, 0.68f, 0.68f, 0.75f), SlotX + 20.f * UIScale, TopY + WorkH - 72.f * UIScale, SlotW - 40.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.58f * UIScale, true, true);

	// Center dossier card.
	DrawChiseledTacticalPanel(CardX, TopY - 12.f * UIScale, CardW, WorkH, FLinearColor(0.018f, 0.030f, 0.034f, 0.76f), PrimaryAccentColor * 0.46f, 12.f * UIScale);
	DrawRect(PrimaryAccentColor, CardX + 24.f * UIScale, TopY + 12.f * UIScale, CardW - 48.f * UIScale, 3.f * UIScale);
	DrawFarsiTextBounded((bMenuEnglish ? TEXT("Field Identification Card") : TEXT("کارت شناسایی میدانی")), PrimaryAccentColor, CardX + 26.f * UIScale, TopY + 28.f * UIScale, CardW - 52.f * UIScale, MenuFont ? MenuFont.Get() : nullptr, 0.86f * UIScale, true);

	const float PortraitSize = 172.f * UIScale;
	const float PortraitX = CardX + 30.f * UIScale;
	const float PortraitY = TopY + 72.f * UIScale;
	DrawChiseledTacticalPanel(PortraitX - 8.f * UIScale, PortraitY - 8.f * UIScale, PortraitSize + 16.f * UIScale, PortraitSize + 16.f * UIScale, FLinearColor(0.012f, 0.022f, 0.026f, 0.94f), PrimaryAccentColor * 0.70f, 8.f * UIScale);
	if (FrameAvatarPortraitTexture) DrawTexture(FrameAvatarPortraitTexture, PortraitX - 12.f * UIScale, PortraitY - 12.f * UIScale, PortraitSize + 24.f * UIScale, PortraitSize + 24.f * UIScale, 0.f, 0.f, 1.f, 1.f, PrimaryAccentColor * 0.80f);
	UTexture2D* AvatarTex = GetAvatarTexture(Prof.SelectedAvatarID);
	if (AvatarTex) DrawTexture(AvatarTex, PortraitX, PortraitY, PortraitSize, PortraitSize, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
	else
	{
		DrawTacticalTopoGrid(PortraitX, PortraitY, PortraitSize, PortraitSize, PrimaryAccentColor * 0.55f);
		DrawFarsiTextBounded((bMenuEnglish ? TEXT("Soldier") : TEXT("رزمنده")), PrimaryAccentColor, PortraitX, PortraitY + 54.f * UIScale, PortraitSize, TitleFont ? TitleFont.Get() : nullptr, 0.95f * UIScale, true, true);
	}

	const float IdentityX = PortraitX + PortraitSize + 28.f * UIScale;
	const float IdentityW = CardW - (IdentityX - CardX) - 30.f * UIScale;
	DrawFarsiTextBounded(SquadAIMenuLocal(this, TEXT("Profile"), TEXT("CallsignLabel"), TEXT("نام رزمنده"), TEXT("Soldier Name"), bMenuEnglish), FLinearColor(0.66f, 0.74f, 0.74f, 0.82f), IdentityX, PortraitY + 4.f * UIScale, IdentityW, BodyFont ? BodyFont.Get() : nullptr, 0.56f * UIScale, true);
	DrawFarsiTextBounded(Prof.PlayerName, FLinearColor(0.94f, 0.99f, 0.98f, 1.f), IdentityX, PortraitY + 25.f * UIScale, IdentityW, TitleFont ? TitleFont.Get() : nullptr, 0.98f * UIScale, true);
	DrawFarsiTextBounded(bMenuEnglish ? FString::Printf(TEXT("Dog tag: %s"), *Prof.DogTagNumber) : FString::Printf(TEXT("شماره پلاک: %s"), *Prof.DogTagNumber), FLinearColor(0.78f, 0.86f, 0.85f, 0.92f), IdentityX, PortraitY + 72.f * UIScale, IdentityW, BodyFont ? BodyFont.Get() : nullptr, 0.80f * UIScale, true);
	DrawFarsiTextBounded(bMenuEnglish ? FString::Printf(TEXT("Blood type: %s"), *Prof.BloodType) : FString::Printf(TEXT("گروه خون: %s"), *Prof.BloodType), FLinearColor(0.84f, 0.42f, 0.34f, 0.95f), IdentityX, PortraitY + 100.f * UIScale, IdentityW, BodyFont ? BodyFont.Get() : nullptr, 0.80f * UIScale, true);
	DrawFarsiTextBounded(bMenuEnglish ? FString::Printf(TEXT("Equipped weapon: %s"), *Prof.EquippedWeaponID.ToString()) : FString::Printf(TEXT("سلاح تجهیزشده: %s"), *Prof.EquippedWeaponID.ToString()), PrimaryAccentColor, IdentityX, PortraitY + 128.f * UIScale, IdentityW, BodyFont ? BodyFont.Get() : nullptr, 0.80f * UIScale, true);

	const float NamePlateX = CardX + 30.f * UIScale;
	const float NamePlateY = PortraitY + PortraitSize + 34.f * UIScale;
	const float NamePlateW = CardW - 60.f * UIScale;
	const float NamePlateH = 68.f * UIScale;
	DrawChiseledTacticalPanel(NamePlateX, NamePlateY, NamePlateW, NamePlateH, bIsEditingPlayerName ? FLinearColor(0.025f, 0.060f, 0.064f, 0.96f) : FLinearColor(0.018f, 0.033f, 0.038f, 0.88f), bIsEditingPlayerName ? PrimaryAccentColor : FLinearColor(0.30f, 0.38f, 0.40f, 0.74f), 7.f * UIScale);
	if (bIsEditingPlayerName)
	{
		if (CustomPlayerNameInput.IsEmpty()) CustomPlayerNameInput = Prof.PlayerName;
		const FString CursorStr = (FMath::Sin(MasterTime * 6.0f) > 0.0f) ? TEXT("|") : TEXT("");
		DrawFarsiTextBounded(bMenuEnglish ? FString::Printf(TEXT("New name: %s%s"), *CustomPlayerNameInput, *CursorStr) : FString::Printf(TEXT("نام جدید: %s%s"), *CustomPlayerNameInput, *CursorStr), PrimaryAccentColor, NamePlateX + 14.f * UIScale, NamePlateY + 12.f * UIScale, NamePlateW - 28.f * UIScale, MenuFont ? MenuFont.Get() : nullptr, 0.80f * UIScale, true);
	}
	else
	{
		DrawFarsiTextBounded((bMenuEnglish ? TEXT("Edit display name or choose a preset name") : TEXT("ویرایش نام نمایشی یا انتخاب نام آماده")), FLinearColor(0.74f, 0.82f, 0.82f, 0.86f), NamePlateX + 14.f * UIScale, NamePlateY + 12.f * UIScale, NamePlateW - 28.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.78f * UIScale, true);
	}

	const float BtnW = (NamePlateW - 28.f * UIScale) / (bIsEditingPlayerName ? 3.f : 2.f);
	const float BtnH = 34.f * UIScale;
	const float BtnY = NamePlateY + NamePlateH + 12.f * UIScale;
	const float EditX = NamePlateX;
	const bool bEditHover = (MouseX >= EditX && MouseX <= EditX + BtnW && MouseY >= BtnY && MouseY <= BtnY + BtnH);
	if (bEditHover) HoveredButtonIndex = 450;
	RegisterButton(450, EditX, BtnY, BtnW, BtnH, FText::FromString(bIsEditingPlayerName ? (bMenuEnglish ? TEXT("Save Name") : TEXT("ذخیره نام")) : (bMenuEnglish ? TEXT("Edit Name") : TEXT("ویرایش نام"))));
	DrawStyledButton(EditX, BtnY, BtnW, BtnH, FText::FromString(bIsEditingPlayerName ? (bMenuEnglish ? TEXT("Save Name") : TEXT("ذخیره نام")) : (bMenuEnglish ? TEXT("Edit Name") : TEXT("ویرایش نام"))), bEditHover);

	const float RandomX = EditX + BtnW + 14.f * UIScale;
	const bool bRandomHover = (MouseX >= RandomX && MouseX <= RandomX + BtnW && MouseY >= BtnY && MouseY <= BtnY + BtnH);
	if (bRandomHover) HoveredButtonIndex = 452;
	RegisterButton(452, RandomX, BtnY, BtnW, BtnH, FText::FromString((bMenuEnglish ? TEXT("Preset Name") : TEXT("نام آماده"))));
	DrawStyledButton(RandomX, BtnY, BtnW, BtnH, FText::FromString((bMenuEnglish ? TEXT("Preset Name") : TEXT("نام آماده"))), bRandomHover);
	if (bIsEditingPlayerName)
	{
		const float CancelX = RandomX + BtnW + 14.f * UIScale;
		const bool bCancelHover = (MouseX >= CancelX && MouseX <= CancelX + BtnW && MouseY >= BtnY && MouseY <= BtnY + BtnH);
		if (bCancelHover) HoveredButtonIndex = 451;
		RegisterButton(451, CancelX, BtnY, BtnW, BtnH, FText::FromString((bMenuEnglish ? TEXT("Cancel") : TEXT("انصراف"))));
		DrawStyledButton(CancelX, BtnY, BtnW, BtnH, FText::FromString((bMenuEnglish ? TEXT("Cancel") : TEXT("انصراف"))), bCancelHover);
	}

	const float StatY = BtnY + 56.f * UIScale;
	const float MetricW = (NamePlateW - 14.f * UIScale) / 2.f;
	DrawMiniMetric(NamePlateX, StatY, MetricW, 56.f * UIScale, (bMenuEnglish ? TEXT("Level") : TEXT("سطح")), FString::Printf(TEXT("%d"), Prof.PlayerLevel), PrimaryAccentColor);
	DrawMiniMetric(NamePlateX + MetricW + 14.f * UIScale, StatY, MetricW, 56.f * UIScale, TEXT("XP"), FString::Printf(TEXT("%d"), Prof.TotalXP), FLinearColor(0.70f, 0.82f, 0.74f, 1.f));
	DrawMiniMetric(NamePlateX, StatY + 70.f * UIScale, MetricW, 56.f * UIScale, (bMenuEnglish ? TEXT("Operations") : TEXT("عملیات")), FString::Printf(TEXT("%d"), Prof.MissionsCompleted), PrimaryAccentColor);
	DrawMiniMetric(NamePlateX + MetricW + 14.f * UIScale, StatY + 70.f * UIScale, MetricW, 56.f * UIScale, (bMenuEnglish ? TEXT("Accuracy") : TEXT("دقت")), FString::Printf(TEXT("%.1f%%"), Prof.OverallAccuracyPercentage), PrimaryAccentColor);

	// Right controls: avatars, preset chips / keyboard, lifetime records.
	DrawChiseledTacticalPanel(SideX, TopY - 12.f * UIScale, SideW, WorkH, FLinearColor(0.014f, 0.026f, 0.030f, 0.72f), PrimaryAccentColor * 0.42f, 10.f * UIScale);
	DrawFarsiTextBounded((bMenuEnglish ? TEXT("Avatar and Record") : TEXT("انتخاب نشان و سوابق")), PrimaryAccentColor, SideX + 20.f * UIScale, TopY + 4.f * UIScale, SideW - 40.f * UIScale, MenuFont ? MenuFont.Get() : nullptr, 0.86f * UIScale, true);

	struct FAvatarShowcaseEntry
	{
		FName ID;
		const TCHAR* Name;
		UTexture2D* Tex;
	};
	const FAvatarShowcaseEntry AvatarsList[] = {
		{ FName("ShahidRostami"), bMenuEnglish ? TEXT("Shahid Rostami") : TEXT("شهید رستمی"), AvatarRostamiTexture ? AvatarRostamiTexture.Get() : nullptr },
		{ FName("YoungBasiji"), bMenuEnglish ? TEXT("Basiji Fighter") : TEXT("رزمنده بسیجی"), AvatarYoungBasijiTexture ? AvatarYoungBasijiTexture.Get() : nullptr },
		{ FName("ArteshParatrooper"), bMenuEnglish ? TEXT("Army Commando") : TEXT("تکاور ارتش"), AvatarArteshParatrooperTexture ? AvatarArteshParatrooperTexture.Get() : nullptr },
		{ FName("GuerrillaHunter"), bMenuEnglish ? TEXT("Irregular Warfare") : TEXT("جنگ نامنظم"), AvatarGuerrillaHunterTexture ? AvatarGuerrillaHunterTexture.Get() : nullptr }
	};
	const float AvaGap = 10.f * UIScale;
	const float AvaW = (SideW - 50.f * UIScale - AvaGap) * 0.5f;
	const float AvaH = 92.f * UIScale;
	float AvaY = TopY + 42.f * UIScale;
	for (int32 ai = 0; ai < 4; ++ai)
	{
		const float ax = SideX + 20.f * UIScale + (ai % 2) * (AvaW + AvaGap);
		const float ay = AvaY + (ai / 2) * (AvaH + AvaGap);
		const bool bActive = (Prof.SelectedAvatarID == AvatarsList[ai].ID) || (ai == 0 && (Prof.SelectedAvatarID == FName("Avatar_Rostami") || Prof.SelectedAvatarID.IsNone()));
		const bool bHover = (MouseX >= ax && MouseX <= ax + AvaW && MouseY >= ay && MouseY <= ay + AvaH);
		if (bHover) HoveredButtonIndex = 400 + ai;
		RegisterButton(400 + ai, ax, ay, AvaW, AvaH, FText::FromString(AvatarsList[ai].Name));
		DrawChiseledTacticalPanel(ax, ay, AvaW, AvaH, bActive ? FLinearColor(0.028f, 0.072f, 0.074f, 0.96f) : FLinearColor(0.026f, 0.038f, 0.043f, 0.88f), (bActive || bHover) ? PrimaryAccentColor : FLinearColor(0.26f, 0.34f, 0.36f, 0.70f), 6.f * UIScale);
		const float ImgSize = 48.f * UIScale;
		const float ImgX = ax + (AvaW - ImgSize) * 0.5f;
		if (AvatarsList[ai].Tex) DrawTexture(AvatarsList[ai].Tex, ImgX, ay + 8.f * UIScale, ImgSize, ImgSize, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
		else
		{
			DrawChiseledTacticalPanel(ImgX, ay + 8.f * UIScale, ImgSize, ImgSize, FLinearColor(0.018f, 0.030f, 0.034f, 0.92f), PrimaryAccentColor * 0.62f, 4.f * UIScale);
			FString Initial; Initial.AppendChar(AvatarsList[ai].Name[0]);
			DrawFarsiTextBounded(Initial, PrimaryAccentColor, ImgX, ay + 8.f * UIScale, ImgSize, TitleFont ? TitleFont.Get() : nullptr, 0.92f * UIScale, true, true, ImgSize);
		}
		DrawFarsiTextBounded(AvatarsList[ai].Name, bActive ? PrimaryAccentColor : FLinearColor(0.86f, 0.92f, 0.92f, 0.92f), ax + 4.f * UIScale, ay + AvaH - 24.f * UIScale, AvaW - 8.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.76f * UIScale, true, true);
	}

	float ControlY = AvaY + (2 * (AvaH + AvaGap)) + 16.f * UIScale;
	if (bIsEditingPlayerName)
	{
		const TCHAR* PresetChips[] = {
			bMenuEnglish ? TEXT("Major Shahid Iraj Rostami") : TEXT("سرگرد شهید ایرج رستمی"),
			bMenuEnglish ? TEXT("Chamran Scout") : TEXT("دیده‌بان چمران"),
			bMenuEnglish ? TEXT("Line-Breaker Fighter") : TEXT("رزمنده خط‌شکن"),
			bMenuEnglish ? TEXT("Karkheh Tank Hunter") : TEXT("شکارچی تانک‌های کرخه")
		};
		const float ChipW = (SideW - 50.f * UIScale - AvaGap) * 0.5f;
		const float ChipH = 32.f * UIScale;
		for (int32 ci = 0; ci < 4; ++ci)
		{
			const float cx = SideX + 20.f * UIScale + (ci % 2) * (ChipW + AvaGap);
			const float cy = ControlY + (ci / 2) * (ChipH + 8.f * UIScale);
			const bool bChipHover = (MouseX >= cx && MouseX <= cx + ChipW && MouseY >= cy && MouseY <= cy + ChipH);
			if (bChipHover) HoveredButtonIndex = 480 + ci;
			RegisterButton(480 + ci, cx, cy, ChipW, ChipH, FText::FromString(PresetChips[ci]));
			DrawStyledButton(cx, cy, ChipW, ChipH, FText::FromString(PresetChips[ci]), bChipHover);
		}
		ControlY += 78.f * UIScale;

		const float LangW = SideW - 40.f * UIScale;
		const float LangH = 32.f * UIScale;
		const bool bLangHover = (MouseX >= SideX + 20.f * UIScale && MouseX <= SideX + 20.f * UIScale + LangW && MouseY >= ControlY && MouseY <= ControlY + LangH);
		if (bLangHover) HoveredButtonIndex = 453;
		RegisterButton(453, SideX + 20.f * UIScale, ControlY, LangW, LangH, FText::FromString((bMenuEnglish || !bKeyboardLanguageFarsi) ? (bMenuEnglish ? TEXT("Keyboard: English") : TEXT("صفحه کلید: EN")) : TEXT("صفحه کلید: فارسی")));
		DrawStyledButton(SideX + 20.f * UIScale, ControlY, LangW, LangH, FText::FromString((bMenuEnglish || !bKeyboardLanguageFarsi) ? (bMenuEnglish ? TEXT("Keyboard: English") : TEXT("صفحه کلید: EN")) : TEXT("صفحه کلید: فارسی")), bLangHover);
		ControlY += 42.f * UIScale;

		const TCHAR* FarsiKeys[] = {
			TEXT("ض"), TEXT("ص"), TEXT("ث"), TEXT("ق"), TEXT("ف"), TEXT("غ"), TEXT("ع"), TEXT("ه"), TEXT("خ"), TEXT("ح"), TEXT("ج"), TEXT("چ"),
			TEXT("ش"), TEXT("س"), TEXT("ی"), TEXT("ب"), TEXT("ل"), TEXT("ا"), TEXT("ت"), TEXT("ن"), TEXT("م"), TEXT("ک"), TEXT("گ"),
			TEXT("ظ"), TEXT("ط"), TEXT("ز"), TEXT("ر"), TEXT("ذ"), TEXT("د"), TEXT("پ"), TEXT("و"), TEXT("ژ"), TEXT(" ")
		};
		const TCHAR* EnglishKeys[] = {
			TEXT("Q"), TEXT("W"), TEXT("E"), TEXT("R"), TEXT("T"), TEXT("Y"), TEXT("U"), TEXT("I"), TEXT("O"), TEXT("P"), TEXT("["), TEXT("]"),
			TEXT("A"), TEXT("S"), TEXT("D"), TEXT("F"), TEXT("G"), TEXT("H"), TEXT("J"), TEXT("K"), TEXT("L"), TEXT(";"), TEXT("'"),
			TEXT("Z"), TEXT("X"), TEXT("C"), TEXT("V"), TEXT("B"), TEXT("N"), TEXT("M"), TEXT(","), TEXT("/"), TEXT(" ")
		};
		const bool bUseEnglishVirtualKeys = bMenuEnglish || !bKeyboardLanguageFarsi;
		const int32 ActiveKeyCount = bUseEnglishVirtualKeys ? UE_ARRAY_COUNT(EnglishKeys) : UE_ARRAY_COUNT(FarsiKeys);
		const int32 KeysPerRow = 8;
		const float KeyGap = 5.f * UIScale;
		const float KeyW = (SideW - 40.f * UIScale - (KeysPerRow - 1) * KeyGap) / KeysPerRow;
		const float KeyH = 30.f * UIScale;
		for (int32 ki = 0; ki < ActiveKeyCount; ++ki)
		{
			const int32 Row = ki / KeysPerRow;
			const int32 Col = ki % KeysPerRow;
			const float kx = SideX + 20.f * UIScale + Col * (KeyW + KeyGap);
			const float ky = ControlY + Row * (KeyH + KeyGap);
			const bool bKeyHover = (MouseX >= kx && MouseX <= kx + KeyW && MouseY >= ky && MouseY <= ky + KeyH);
			if (bKeyHover) HoveredButtonIndex = 600 + ki;
			const TCHAR* ActiveKey = bUseEnglishVirtualKeys ? EnglishKeys[ki] : FarsiKeys[ki];
			RegisterButton(600 + ki, kx, ky, KeyW, KeyH, FText::FromString(ActiveKey));
			DrawChiseledTacticalPanel(kx, ky, KeyW, KeyH, bKeyHover ? FLinearColor(0.038f, 0.100f, 0.100f, 0.96f) : FLinearColor(0.030f, 0.044f, 0.050f, 0.88f), bKeyHover ? PrimaryAccentColor : FLinearColor(0.28f, 0.36f, 0.38f, 0.68f), 3.f * UIScale);
			const FString KeyDisplay = (ki == ActiveKeyCount - 1) ? FString(TEXT("␣")) : FString(ActiveKey);
			DrawFarsiTextBounded(KeyDisplay, bKeyHover ? PrimaryAccentColor : FLinearColor(0.86f, 0.92f, 0.92f, 0.92f), kx, ky + 1.f * UIScale, KeyW, MenuFont ? MenuFont.Get() : nullptr, 0.68f * UIScale, false, true, KeyH);
		}
		ControlY += 150.f * UIScale;
	}

	const int32 EnemiesVal = Prof.EnemiesEliminated > 0 ? Prof.EnemiesEliminated : Prof.EnemiesHunted;
	const int32 RevivesVal = Prof.AlliesRevived > 0 ? Prof.AlliesRevived : Prof.TriageRevives;
	FString PlaytimeVal = !Prof.FormattedPlaytime.IsEmpty() ? Prof.FormattedPlaytime : (Prog ? Prog->GetFormattedPlaytime() : (bMenuEnglish ? TEXT("0 minutes") : TEXT("۰ دقیقه")));
		if (bMenuEnglish)
		{
			PlaytimeVal = SquadAIMenuDisplayText(PlaytimeVal, CachedMenuSettings.LanguageCode); // S17-ARFIX
		}
	struct FLifetimeRecordEntry { const TCHAR* Label; FString Value; FLinearColor Accent; };
	// L2-INI: [Profile] KillsLabel/TanksLabel/RevivesLabel/TimeLabel/ScoreLabel are live (user keys).
	// Labels must outlive the Records array — hoist to locals (the struct stores const TCHAR*).
	const FString LblEnemies   = SquadAIMenuLocal(this, TEXT("Profile"), TEXT("KillsLabel"),     TEXT("نیروهای دشمن"),   TEXT("Enemies"),        bMenuEnglish);
	const FString LblTanks     = SquadAIMenuLocal(this, TEXT("Profile"), TEXT("TanksLabel"),     TEXT("تانک‌های منهدم"), TEXT("Tanks Destroyed"), bMenuEnglish);
	const FString LblHeadshots = SquadAIMenuLocal(this, TEXT("Profile"), TEXT("HeadshotsLabel"), TEXT("هدشات"),         TEXT("Headshots"),      bMenuEnglish);
	const FString LblRevives   = SquadAIMenuLocal(this, TEXT("Profile"), TEXT("RevivesLabel"),   TEXT("احیای همرزمان"), TEXT("Ally Revives"),    bMenuEnglish);
	const FString LblTime      = SquadAIMenuLocal(this, TEXT("Profile"), TEXT("TimeLabel"),      TEXT("زمان حضور"),     TEXT("Time Served"),     bMenuEnglish);
	const FString LblSkill     = SquadAIMenuLocal(this, TEXT("Profile"), TEXT("ScoreLabel"),     TEXT("امتیاز مهارت"),  TEXT("Skill Points"),   bMenuEnglish);
	const FLifetimeRecordEntry Records[] = {
		{ *LblEnemies,   FString::Printf(TEXT("%d"), EnemiesVal),                 PrimaryAccentColor },
		{ *LblTanks,     FString::Printf(TEXT("%d"), Prof.TanksDemolished),       FLinearColor(0.74f, 0.28f, 0.22f, 1.f) },
		{ *LblHeadshots, FString::Printf(TEXT("%d"), Prof.HeadshotCount),         PrimaryAccentColor },
		{ *LblRevives,   FString::Printf(TEXT("%d"), RevivesVal),                 FLinearColor(0.70f, 0.82f, 0.74f, 1.f) },
		{ *LblTime,      PlaytimeVal,                                             PrimaryAccentColor },
		{ *LblSkill,     FString::Printf(TEXT("%d"), Prof.AvailableSkillPoints),  PrimaryAccentColor }
	};
const float RecGap = 10.f * UIScale;
	const float RecW = (SideW - 50.f * UIScale - RecGap) * 0.5f;
	const float RecH = 54.f * UIScale;
	for (int32 ri = 0; ri < UE_ARRAY_COUNT(Records); ++ri)
	{
		const float rx = SideX + 20.f * UIScale + (ri % 2) * (RecW + RecGap);
		const float ry = ControlY + (ri / 2) * (RecH + RecGap);
		DrawMiniMetric(rx, ry, RecW, RecH, Records[ri].Label, Records[ri].Value, Records[ri].Accent);
	}

	const float BackW = 160.f * UIScale;
	const float BackH = 40.f * UIScale;
	const float BackX = PanelX + PanelW - BackW - 26.f * UIScale;
	const float BackY = PanelY + PanelH - BackH - 18.f * UIScale;
	const bool bBackHover = (MouseX >= BackX && MouseX <= BackX + BackW && MouseY >= BackY && MouseY <= BackY + BackH);
	if (bBackHover) HoveredButtonIndex = 99;
	RegisterButton(99, BackX, BackY, BackW, BackH, MenuTextConfig.ButtonBack);
	DrawStyledButton(BackX, BackY, BackW, BackH, MenuTextConfig.ButtonBack, bBackHover);
}

void ASquadAIMainMenuHUD::DrawAchievementsScreen(float ScreenW, float ScreenH, float MouseX, float MouseY)
{
	const bool bMenuEnglish = !CachedMenuSettings.LanguageCode.StartsWith(TEXT("fa"), ESearchCase::IgnoreCase);
	const float UIScale = FMath::Clamp(ScreenH / 1080.f, 0.70f, 1.35f);
	const float PanelX = 50.f * UIScale + SubmenuSlideOffset;
	const float PanelY = 104.f * UIScale;
	const float PanelW = ScreenW - (100.f * UIScale);
	const float PanelH = ScreenH - (170.f * UIScale);

	// AAA-B3-3: achievements are displayed as a restrained honors case, with medals separate from content.
	DrawRect(FLinearColor(0.f, 0.f, 0.f, 0.40f), 0.f, PanelY - 12.f * UIScale, ScreenW, PanelH + 42.f * UIScale);
	DrawSacredDefenseBorder(PanelX, PanelY, PanelW, PanelH, PrimaryAccentColor * 0.92f, true);
	if (BackgroundMedalsTexture)
	{
		DrawTexture(BackgroundMedalsTexture, PanelX + 5.f * UIScale, PanelY + 5.f * UIScale, PanelW - 10.f * UIScale, PanelH - 10.f * UIScale, 0.f, 0.f, 1.f, 1.f, FLinearColor(0.60f, 0.72f, 0.70f, 0.30f));
		DrawRect(FLinearColor(0.f, 0.f, 0.f, 0.54f), PanelX + 5.f * UIScale, PanelY + 5.f * UIScale, PanelW - 10.f * UIScale, PanelH - 10.f * UIScale);
	}

	DrawFarsiTextBounded((bMenuEnglish ? TEXT("Honors Case") : TEXT("ویترین افتخارات دفاع مقدس | HONORS CASE")), PrimaryAccentColor, PanelX + 28.f * UIScale, PanelY + 18.f * UIScale, PanelW - 56.f * UIScale, TitleFont ? TitleFont.Get() : nullptr, 1.25f * UIScale, true);
	DrawFarsiTextBounded((bMenuEnglish ? TEXT("Medals sit in separate frames; progress and descriptions use readable clean cards.") : TEXT("مدال‌ها روی قاب جداگانه قرار دارند؛ متن و روند پیشرفت در کارت‌های خوانا و بدون تزئینات سنگین نمایش داده می‌شود.")), FLinearColor(0.78f, 0.86f, 0.86f, 0.92f), PanelX + 28.f * UIScale, PanelY + 48.f * UIScale, PanelW - 56.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.70f * UIScale, true);

	USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(this);
	const TArray<FSquadAchievementDefinition> Achs = Prog ? Prog->GetAchievements() : TArray<FSquadAchievementDefinition>();
	if (Achs.Num() > 0) ActiveMedalInspectIdx = FMath::Clamp(ActiveMedalInspectIdx, 0, Achs.Num() - 1);
	else ActiveMedalInspectIdx = 0;

	int32 UnlockedCount = 0;
	for (const FSquadAchievementDefinition& A : Achs)
	{
		if (A.bUnlocked || A.bIsUnlocked) ++UnlockedCount;
	}

	const float TopY = PanelY + 88.f * UIScale;
	const float Gap = 22.f * UIScale;
	const float InspectW = FMath::Clamp(PanelW * 0.33f, 470.f * UIScale, 560.f * UIScale);
	const float InspectX = PanelX + 24.f * UIScale;
	const float GridX = InspectX + InspectW + Gap;
	const float GridW = PanelW - InspectW - (3.f * Gap) - 24.f * UIScale;
	const float WorkH = PanelH - 118.f * UIScale;

	// Inspector / selected medal.
	DrawChiseledTacticalPanel(InspectX, TopY - 12.f * UIScale, InspectW, WorkH, FLinearColor(0.014f, 0.026f, 0.030f, 0.76f), PrimaryAccentColor * 0.48f, 12.f * UIScale);
	DrawRect(PrimaryAccentColor, InspectX + 24.f * UIScale, TopY + 12.f * UIScale, InspectW - 48.f * UIScale, 3.f * UIScale);
	DrawFarsiTextBounded((bMenuEnglish ? TEXT("Selected Medal") : TEXT("مدال انتخاب‌شده")), PrimaryAccentColor, InspectX + 24.f * UIScale, TopY + 28.f * UIScale, InspectW - 48.f * UIScale, MenuFont ? MenuFont.Get() : nullptr, 0.86f * UIScale, true, true);

	if (Achs.IsValidIndex(ActiveMedalInspectIdx))
	{
		const FSquadAchievementDefinition& ActiveA = Achs[ActiveMedalInspectIdx];
		const bool bEarned = ActiveA.bUnlocked || ActiveA.bIsUnlocked;
		const float ProgressFrac = ActiveA.TargetProgress > 0.f ? FMath::Clamp(ActiveA.CurrentProgress / ActiveA.TargetProgress, 0.f, 1.f) : (bEarned ? 1.f : 0.f);
		const FLinearColor MedalAccent = bEarned ? PrimaryAccentColor : FLinearColor(0.44f, 0.52f, 0.53f, 0.80f);
		const float MedalSize = 148.f * UIScale;
		const float MedalX = InspectX + (InspectW - MedalSize) * 0.5f;
		const float MedalY = TopY + 78.f * UIScale;
		UTexture2D* Icon = ActiveA.IconTexture ? ActiveA.IconTexture.Get() : GetTraitTexture(ActiveA.AchievementID);

		if (FrameMedalSocketTexture) DrawTexture(FrameMedalSocketTexture, MedalX - 18.f * UIScale, MedalY - 18.f * UIScale, MedalSize + 36.f * UIScale, MedalSize + 36.f * UIScale, 0.f, 0.f, 1.f, 1.f, MedalAccent);
		else DrawChiseledTacticalPanel(MedalX - 14.f * UIScale, MedalY - 14.f * UIScale, MedalSize + 28.f * UIScale, MedalSize + 28.f * UIScale, FLinearColor(0.018f, 0.030f, 0.034f, 0.94f), MedalAccent * 0.70f, 8.f * UIScale);
		DrawChiseledTacticalPanel(MedalX, MedalY, MedalSize, MedalSize, bEarned ? FLinearColor(0.030f, 0.070f, 0.070f, 0.92f) : FLinearColor(0.024f, 0.030f, 0.034f, 0.86f), MedalAccent * 0.70f, 9.f * UIScale);
		if (Icon) DrawTexture(Icon, MedalX + 22.f * UIScale, MedalY + 20.f * UIScale, MedalSize - 44.f * UIScale, MedalSize - 44.f * UIScale, 0.f, 0.f, 1.f, 1.f, bEarned ? FLinearColor::White : FLinearColor(0.54f, 0.62f, 0.62f, 0.74f));
		else DrawFarsiTextBounded(bEarned ? (bMenuEnglish ? TEXT("Medal") : TEXT("نشان")) : (bMenuEnglish ? TEXT("Locked") : TEXT("قفل")), MedalAccent, MedalX, MedalY + 44.f * UIScale, MedalSize, TitleFont ? TitleFont.Get() : nullptr, 0.92f * UIScale, true, true);

		DrawFarsiTextBounded((bMenuEnglish ? ActiveA.DisplayNameEnglish : ActiveA.DisplayNameFarsi).ToString(), FLinearColor(0.94f, 0.98f, 0.97f, 1.f), InspectX + 30.f * UIScale, MedalY + MedalSize + 24.f * UIScale, InspectW - 60.f * UIScale, TitleFont ? TitleFont.Get() : nullptr, 0.90f * UIScale, true, true);
		DrawFarsiTextBounded(ActiveA.DisplayNameEnglish.ToString(), FLinearColor(0.62f, 0.70f, 0.70f, 0.84f), InspectX + 30.f * UIScale, MedalY + MedalSize + 54.f * UIScale, InspectW - 60.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.62f * UIScale, false, true);
		DrawFarsiTextBounded((bMenuEnglish ? ActiveA.DescriptionEnglish : ActiveA.DescriptionFarsi).ToString(), FLinearColor(0.78f, 0.86f, 0.85f, 0.92f), InspectX + 30.f * UIScale, MedalY + MedalSize + 92.f * UIScale, InspectW - 60.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.67f * UIScale, true);

		const float BarX = InspectX + 40.f * UIScale;
		const float BarY = TopY + WorkH - 152.f * UIScale;
		const float BarW = InspectW - 80.f * UIScale;
		DrawFarsiTextBounded(bEarned ? (bMenuEnglish ? TEXT("Status: earned") : TEXT("وضعیت: کسب شده")) : (bMenuEnglish ? TEXT("Status: in progress") : TEXT("وضعیت: در حال پیشرفت")), bEarned ? PrimaryAccentColor : FLinearColor(0.70f, 0.82f, 0.74f, 0.94f), BarX, BarY - 28.f * UIScale, BarW, BodyFont ? BodyFont.Get() : nullptr, 0.70f * UIScale, true, true);
		DrawStatBar(BarX, BarY, BarW, 14.f * UIScale, ProgressFrac, bEarned ? PrimaryAccentColor : FLinearColor(0.70f, 0.82f, 0.74f, 1.f), FLinearColor(0.06f, 0.09f, 0.10f, 0.95f));
		DrawFarsiTextBounded(bMenuEnglish ? FString::Printf(TEXT("%.0f / %.0f  |  Reward %d XP"), ActiveA.CurrentProgress, ActiveA.TargetProgress, ActiveA.XPReward) : FString::Printf(TEXT("%.0f / %.0f  |  پاداش %d XP"), ActiveA.CurrentProgress, ActiveA.TargetProgress, ActiveA.XPReward), FLinearColor(0.74f, 0.82f, 0.82f, 0.86f), BarX, BarY + 22.f * UIScale, BarW, BodyFont ? BodyFont.Get() : nullptr, 0.62f * UIScale, true, true);
		if (bEarned)
		{
			DrawFarsiTextBounded((bMenuEnglish ? TEXT("This honor is recorded in the soldier dossier.") : TEXT("این افتخار در پرونده رزمنده ثبت شده است.")), PrimaryAccentColor, BarX, BarY + 52.f * UIScale, BarW, BodyFont ? BodyFont.Get() : nullptr, 0.62f * UIScale, true, true);
		}
	}
	else
	{
		DrawFarsiTextBounded((bMenuEnglish ? TEXT("The honors catalog is still empty.") : TEXT("کاتالوگ افتخارات هنوز خالی است.")), FLinearColor(0.78f, 0.84f, 0.84f, 0.90f), InspectX + 35.f * UIScale, TopY + 130.f * UIScale, InspectW - 70.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.78f * UIScale, true, true);
	}

	// Right grid of medals.
	DrawChiseledTacticalPanel(GridX, TopY - 12.f * UIScale, GridW, WorkH, FLinearColor(0.012f, 0.024f, 0.028f, 0.66f), PrimaryAccentColor * 0.38f, 10.f * UIScale);
	DrawTacticalTopoGrid(GridX + 10.f * UIScale, TopY, GridW - 20.f * UIScale, WorkH - 24.f * UIScale, PrimaryAccentColor * 0.32f);
	DrawFarsiTextBounded(bMenuEnglish ? FString::Printf(TEXT("Honors recorded: %d / %d"), UnlockedCount, Achs.Num()) : FString::Printf(TEXT("ثبت افتخارات: %d / %d"), UnlockedCount, Achs.Num()), PrimaryAccentColor, GridX + 24.f * UIScale, TopY + 10.f * UIScale, GridW - 48.f * UIScale, MenuFont ? MenuFont.Get() : nullptr, 0.86f * UIScale, true);

	if (Achs.Num() > 0)
	{
		const int32 ColCount = 2;
		const int32 RowCount = FMath::Max(1, FMath::CeilToInt((float)Achs.Num() / (float)ColCount));
		const float CardGap = 14.f * UIScale;
		const float CardW = (GridW - 54.f * UIScale - CardGap) / 2.f;
		const float AvailableCardsH = WorkH - 76.f * UIScale;
		const float CardH = FMath::Clamp((AvailableCardsH - (RowCount - 1) * CardGap) / RowCount, 96.f * UIScale, 126.f * UIScale);
		const float CardsY = TopY + 52.f * UIScale;
		for (int32 i = 0; i < Achs.Num(); ++i)
		{
			const FSquadAchievementDefinition& A = Achs[i];
			const int32 Col = i % ColCount;
			const int32 Row = i / ColCount;
			const float cx = GridX + 24.f * UIScale + Col * (CardW + CardGap);
			const float cy = CardsY + Row * (CardH + CardGap);
			const bool bEarned = A.bUnlocked || A.bIsUnlocked;
			const bool bHover = (MouseX >= cx && MouseX <= cx + CardW && MouseY >= cy && MouseY <= cy + CardH);
			const bool bSelected = (ActiveMedalInspectIdx == i);
			const float ProgressFrac = A.TargetProgress > 0.f ? FMath::Clamp(A.CurrentProgress / A.TargetProgress, 0.f, 1.f) : (bEarned ? 1.f : 0.f);
			const FLinearColor StateAccent = bEarned ? PrimaryAccentColor : FLinearColor(0.50f, 0.58f, 0.59f, 0.80f);
			if (bHover)
			{
				HoveredButtonIndex = 520 + i;
				ActiveMedalInspectIdx = i;
			}
			RegisterButton(520 + i, cx, cy, CardW, CardH, bMenuEnglish ? A.DisplayNameEnglish : A.DisplayNameFarsi);

			DrawChiseledTacticalPanel(cx, cy, CardW, CardH, bSelected ? FLinearColor(0.030f, 0.070f, 0.070f, 0.96f) : FLinearColor(0.026f, 0.038f, 0.043f, 0.90f), (bHover || bSelected) ? StateAccent : FLinearColor(0.26f, 0.34f, 0.36f, 0.70f), 7.f * UIScale);
			DrawRect(StateAccent, cx, cy, 4.f * UIScale, CardH);

			const float IconSize = 56.f * UIScale;
			const float IconX = cx + 14.f * UIScale;
			const float IconY = cy + 14.f * UIScale;
			UTexture2D* Icon = A.IconTexture ? A.IconTexture.Get() : GetTraitTexture(A.AchievementID);
			if (FrameMedalSocketTexture) DrawTexture(FrameMedalSocketTexture, IconX - 6.f * UIScale, IconY - 6.f * UIScale, IconSize + 12.f * UIScale, IconSize + 12.f * UIScale, 0.f, 0.f, 1.f, 1.f, StateAccent * 0.80f);
			else DrawChiseledTacticalPanel(IconX - 4.f * UIScale, IconY - 4.f * UIScale, IconSize + 8.f * UIScale, IconSize + 8.f * UIScale, FLinearColor(0.014f, 0.024f, 0.028f, 0.90f), StateAccent * 0.60f, 5.f * UIScale);
			if (Icon) DrawTexture(Icon, IconX, IconY, IconSize, IconSize, 0.f, 0.f, 1.f, 1.f, bEarned ? FLinearColor::White : FLinearColor(0.54f, 0.62f, 0.62f, 0.72f));
			else DrawFarsiTextBounded(bEarned ? TEXT("✓") : TEXT("•"), StateAccent, IconX, IconY, IconSize, TitleFont ? TitleFont.Get() : nullptr, 1.1f * UIScale, true, true, IconSize);

			const float TextX = IconX + IconSize + 14.f * UIScale;
			const float TextW = CardW - (TextX - cx) - 16.f * UIScale;
			DrawFarsiTextBounded((bMenuEnglish ? A.DisplayNameEnglish : A.DisplayNameFarsi).ToString(), FLinearColor(0.92f, 0.97f, 0.96f, 1.f), TextX, cy + 12.f * UIScale, TextW, MenuFont ? MenuFont.Get() : nullptr, 0.70f * UIScale, true);
			DrawFarsiTextBounded((bMenuEnglish ? A.DescriptionEnglish : A.DescriptionFarsi).ToString(), FLinearColor(0.66f, 0.74f, 0.74f, 0.84f), TextX, cy + 36.f * UIScale, TextW, BodyFont ? BodyFont.Get() : nullptr, 0.52f * UIScale, false);
			DrawStatBar(TextX, cy + CardH - 24.f * UIScale, TextW, 10.f * UIScale, ProgressFrac, bEarned ? PrimaryAccentColor : FLinearColor(0.70f, 0.82f, 0.74f, 1.f), FLinearColor(0.06f, 0.09f, 0.10f, 0.95f));
		}
	}

	const float BackW = 160.f * UIScale;
	const float BackH = 40.f * UIScale;
	const float BackX = PanelX + PanelW - BackW - 26.f * UIScale;
	const float BackY = PanelY + PanelH - BackH - 18.f * UIScale;
	const bool bBackHover = (MouseX >= BackX && MouseX <= BackX + BackW && MouseY >= BackY && MouseY <= BackY + BackH);
	if (bBackHover) HoveredButtonIndex = 99;
	RegisterButton(99, BackX, BackY, BackW, BackH, MenuTextConfig.ButtonBack);
	DrawStyledButton(BackX, BackY, BackW, BackH, MenuTextConfig.ButtonBack, bBackHover);
}

void ASquadAIMainMenuHUD::DrawRelicCollectionScreen(float ScreenW, float ScreenH, float MouseX, float MouseY)
{
	const bool bMenuEnglish = !CachedMenuSettings.LanguageCode.StartsWith(TEXT("fa"), ESearchCase::IgnoreCase);
	const float UIScale = FMath::Clamp(ScreenH / 1080.f, 0.70f, 1.35f);
	const float PanelX = 60.f * UIScale + SubmenuSlideOffset;
	const float PanelY = 90.f * UIScale;
	const float PanelW = ScreenW - (120.f * UIScale);
	const float PanelH = ScreenH - (140.f * UIScale);

	DrawSacredDefenseBorder(PanelX, PanelY, PanelW, PanelH, PrimaryAccentColor, true);

	if (!BackgroundRelicsTexture) BackgroundRelicsTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_FallenNotes_Background.UI_FallenNotes_Background"), TEXT("Textures/UI_FallenNotes_Background.png"));
	if (BackgroundRelicsTexture)
	{
		DrawTexture(BackgroundRelicsTexture, PanelX + 4.f, PanelY + 4.f, PanelW - 8.f, PanelH - 8.f, 0.f, 0.f, 1.f, 1.f, FLinearColor(0.85f, 0.85f, 0.90f, 0.88f));
	}

	DrawFarsiTextBounded((bMenuEnglish ? TEXT("Relics of the Fallen") : TEXT("دست‌نوشته‌ها و یادگاری همرزمان شهید | RELICS OF THE FALLEN")), PrimaryAccentColor, PanelX + 25.f, PanelY + 16.f * UIScale, PanelW - 50.f, TitleFont ? TitleFont.Get() : nullptr, 1.50f * UIScale, true);

	USquadAIInventorySubsystem* Inv = USquadAIInventorySubsystem::Get(this);
	const int32 NoteCount = Inv ? Inv->GetTotalNotesCount() : 0;
	if (NoteCount > 0)
	{
		ActiveRelicInspectIdx = FMath::Clamp(ActiveRelicInspectIdx, 0, NoteCount - 1);
	}
	else
	{
		ActiveRelicInspectIdx = 0;
	}

	ASquadAIMainMenuSetupActor* Setup = nullptr;
	// MEGA-5 (H-g): was a per-frame TActorIterator over every actor — the setup actor
	// is a level singleton, so resolve it once and cache it.
	if (!CachedRelicSetupActor.IsValid() && GetWorld())
	{
		for (TActorIterator<ASquadAIMainMenuSetupActor> It(GetWorld()); It; ++It)
		{
			CachedRelicSetupActor = *It;
			break;
		}
	}
	Setup = CachedRelicSetupActor.Get();

	// Left: Selected Keepsake Inspection Card
	const float InspectX = PanelX + 25.f;
	const float InspectY = PanelY + 55.f * UIScale;
	const float InspectW = 420.f * UIScale;
	const float InspectH = PanelH - 80.f * UIScale;

	DrawChiseledTacticalPanel(InspectX, InspectY, InspectW, InspectH, FLinearColor(0.035f, 0.045f, 0.06f, 0.96f), PrimaryAccentColor * 0.80f, 10.f);

	if (NoteCount > 0 && Inv)
	{
		const FSquadFallenTroopNote Note = Inv->GetFallenNoteByIndex(ActiveRelicInspectIdx);

		// G-13: per-note art first (wired scan or Textures/Notes drop-in), legacy
		// index-keyed setup list second, placeholder last.
		UTexture2D* NoteArt = Note.NoteImage ? Note.NoteImage.Get() : Inv->GetNoteImage(Note);
		if (!NoteArt && Setup && Setup->FallenNotesImageList.IsValidIndex(ActiveRelicInspectIdx))
		{
			NoteArt = Setup->FallenNotesImageList[ActiveRelicInspectIdx].Get();
		}
		if (!NoteArt && Setup)
		{
			NoteArt = Setup->FallenNotesPlaceholderArtwork.Get();
		}
		if (NoteArt)
		{
			const float ArtSz = 136.f * UIScale;
			const float ArtX = InspectX + (InspectW - ArtSz) * 0.5f;
			const float ArtY = InspectY + 20.f * UIScale;
			DrawTexture(NoteArt, ArtX, ArtY, ArtSz, ArtSz, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
		}

		float CurY = InspectY + 180.f * UIScale;
		DrawFarsiTextBounded(Note.Title, PrimaryAccentColor, InspectX + 16.f, CurY, InspectW - 32.f, TitleFont ? TitleFont.Get() : nullptr, 1.40f * UIScale, true);
		CurY += 40.f * UIScale;

		TArray<FString> NoteLines;
		Note.Content.ParseIntoArrayLines(NoteLines, false);
		if (NoteLines.Num() == 0 && !Note.Content.IsEmpty())
		{
			NoteLines.Add(Note.Content);
		}
		for (const FString& NL : NoteLines)
		{
			if (CurY > InspectY + InspectH - 30.f * UIScale) break;
			DrawFarsiTextBounded(NL, FLinearColor(0.92f, 0.90f, 0.85f, 1.0f), InspectX + 16.f, CurY, InspectW - 32.f, BodyFont ? BodyFont.Get() : nullptr, 1.02f * UIScale, true);
			CurY += 30.f * UIScale;
		}
	}
	else
	{
		DrawFarsiTextBounded((bMenuEnglish ? TEXT("No relics recorded yet — find notes on the battlefield") : TEXT("هنوز یادگاری‌ای ثبت نشده — در میدان نبرد دست‌نوشته‌ها را بیابید")), FLinearColor(0.75f, 0.80f, 0.85f, 0.95f), InspectX + 16.f, InspectY + 40.f * UIScale, InspectW - 32.f, BodyFont ? BodyFont.Get() : nullptr, 1.02f * UIScale, true);
	}

	// Right: Collection List
	const float ListX = InspectX + InspectW + 20.f * UIScale;
	const float ListY = PanelY + 55.f * UIScale;
	const float ListW = PanelW - InspectW - 55.f * UIScale;
	const float CardW = ListW;
	const float CardH = 64.f * UIScale;
	const float CardGap = 12.f * UIScale;

	for (int32 i = 0; i < NoteCount; ++i)
	{
		const float ay = ListY + i * (CardH + CardGap);
		if (ay + CardH > PanelY + PanelH - 70.f * UIScale) break;
		const bool bHover = (MouseX >= ListX && MouseX <= ListX + CardW && MouseY >= ay && MouseY <= ay + CardH);
		const bool bSelected = (ActiveRelicInspectIdx == i);
		if (bHover)
		{
			HoveredButtonIndex = 750 + i; // F-G3: relic cards moved off the 600s (collided with Farsi keys + load slots).
			ActiveRelicInspectIdx = i;
		}
		RegisterButton(750 + i, ListX, ay, CardW, CardH, FText::FromString((bMenuEnglish ? TEXT("Comrade Relic") : TEXT("یادگاری همرزم"))));

		const FLinearColor CardBg = bSelected ? FLinearColor(0.18f, 0.14f, 0.05f, 0.98f) : FLinearColor(0.04f, 0.05f, 0.07f, 0.92f);
		const FLinearColor CardBorder = bSelected ? PrimaryAccentColor : FLinearColor(0.28f, 0.34f, 0.40f, 0.70f);
		DrawChiseledTacticalPanel(ListX, ay, CardW, CardH, CardBg, CardBorder, 6.f);

		const FSquadFallenTroopNote RowNote = Inv->GetFallenNoteByIndex(i);
		UTexture2D* RowArt = RowNote.NoteImage ? RowNote.NoteImage.Get() : Inv->GetNoteImage(RowNote);
		if (!RowArt && Setup && Setup->FallenNotesImageList.IsValidIndex(i))
		{
			RowArt = Setup->FallenNotesImageList[i].Get();
		}
		if (RowArt)
		{
			DrawTexture(RowArt, ListX + 14.f, ay + 10.f * UIScale, 44.f * UIScale, 44.f * UIScale, 0.f, 0.f, 1.f, 1.f, FLinearColor::White);
		}
		DrawFarsiTextBounded(RowNote.Title, bSelected ? PrimaryAccentColor : FLinearColor(0.90f, 0.92f, 0.96f, 1.0f), ListX + 70.f * UIScale, ay + 18.f * UIScale, CardW - 84.f * UIScale, MenuFont ? MenuFont.Get() : nullptr, 1.10f * UIScale, true);
	}

	// Back Button
	const float BackW = 160.f * UIScale;
	const float BackH = 40.f * UIScale;
	const float BackX = PanelX + 25.f;
	const float BackY = PanelY + PanelH - BackH - 14.f * UIScale;
	const bool bBackHover = (MouseX >= BackX && MouseX <= BackX + BackW && MouseY >= BackY && MouseY <= BackY + BackH);
	if (bBackHover) HoveredButtonIndex = 99;

	RegisterButton(99, BackX, BackY, BackW, BackH, MenuTextConfig.ButtonBack);
	DrawStyledButton(BackX, BackY, BackW, BackH, MenuTextConfig.ButtonBack, bBackHover);
}

// =============================================================================
//  7. DIFFICULTY SELECTION SCREEN (4 IMMERSIVE VERTICAL CARDS WITH PNG BACKGROUNDS)
// ============================================================================

// =============================================================================
//  S19-INSTANT: THE DEPARTURE SCREEN
//  The loading screen the player waits in between choosing a difficulty (or a
//  map / a save) and the gameplay world appearing. Canvas-native and drawn by
//  this HUD, so it is painted on the click frame and stays painted through the
//  blocking map load.
// =============================================================================
void ASquadAIMainMenuHUD::DrawDepartureScreen(float ScreenW, float ScreenH, float DeltaTime)
{
	const bool bMenuEnglish = CachedMenuSettings.LanguageCode.StartsWith(TEXT("en"), ESearchCase::IgnoreCase)
		|| CachedMenuSettings.LanguageCode.StartsWith(TEXT("ar"), ESearchCase::IgnoreCase);
	const float S = FMath::Clamp(ScreenH / 1080.f, 0.70f, 1.35f);

	// ---- the content: the same dossier the gameplay veil shows --------------
	USquadAILoadingScreenSubsystem* LoadSys = USquadAILoadingScreenSubsystem::Get(this);
	USquadAILocalizationSubsystem* LocSys = USquadAILocalizationSubsystem::Get(this);

	FString TitleStr;
	FString DescStr;
	if (LoadSys && !LoadSys->CurrentSectorTitle.IsEmpty())
	{
		TitleStr = LoadSys->CurrentSectorTitle.ToString();
	}
	else
	{
		TitleStr = LocSys ? LocSys->GetString(TEXT("Loading"), TEXT("LoadingTitle"),
				bMenuEnglish ? FString(TEXT("Khuzestan Operational Sector - Dehlavieh Front Line"))
							 : FString(TEXT("منطقه عملیاتی خوزستان — خط مقدم دهلاویه")))
			: (bMenuEnglish ? TEXT("Khuzestan Operational Sector - Dehlavieh Front Line")
							: TEXT("منطقه عملیاتی خوزستان — خط مقدم دهلاویه"));
	}
	if (LoadSys && !LoadSys->CurrentMissionBriefing.IsEmpty())
	{
		DescStr = LoadSys->CurrentMissionBriefing.ToString();
	}
	else
	{
		DescStr = LocSys ? LocSys->GetString(TEXT("Loading"), TEXT("LoadingDesc"),
				bMenuEnglish ? FString(TEXT("Loading equipment, holding the radio net and briefing the squad..."))
							 : FString(TEXT("در حال بارگذاری تجهیزات، تثبیت فرکانس بی‌سیم و هماهنگی جوخه...")))
			: (bMenuEnglish ? TEXT("Loading equipment, holding the radio net and briefing the squad...")
							: TEXT("در حال بارگذاری تجهیزات، تثبیت فرکانس بی‌سیم و هماهنگی جوخه..."));
	}

	// ---- the clock: the handoff owns it, so the bar can be carried across the
	// travel and continued (not restarted) by the destination's deployment veil.
	DepartureSeconds += FMath::Max(0.f, DeltaTime);
	const float Progress = LoadSys ? LoadSys->GetTransitionProgress() : FMath::Min(0.92f, DepartureSeconds * 0.42f);

	// ---- 1. full-screen artwork (the menu's own background, unchanged) -----
	// DrawBackgroundMedia already falls back to a flat dark fill when no artwork
	// has resolved, so the departure screen can never come up transparent.
	DrawBackgroundMedia(ScreenW, ScreenH);
	// Cinematic darkening so the dossier below stays legible over any artwork.
	DrawRect(FLinearColor(0.0f, 0.0f, 0.0f, 0.42f), 0.f, 0.f, ScreenW, ScreenH);

	// ---- 2. the briefing dossier card --------------------------------------
	const float CardW = FMath::Min(880.f * S, ScreenW - 60.f * S);
	const float CardH = 220.f * S;
	const float CardX = (ScreenW - CardW) * 0.5f;
	const float CardY = ScreenH - CardH - 40.f * S;

	// S19-INSTANT: 7 arguments - (X, Y, W, H, Bg, Border, CutSize). The extra float that
	// used to be here was a border thickness that the function does not take (C2660).
	DrawChiseledTacticalPanel(CardX, CardY, CardW, CardH,
		FLinearColor(0.03f, 0.04f, 0.06f, 0.96f),
		FLinearColor(1.0f, 0.82f, 0.25f, 0.95f), 10.f * S);

	// The percentage shares the title row (right-aligned), NOT its own line: the row
	// below is the description's, and a second line from either would have collided.
	// The title is bounded to what is left of the row.
	const float PctW = 84.f * S;
	const float PctStrW = FString(TEXT("%100")).Len() * 13.f * S; // same estimate the HUD uses
	(void)PctStrW;
	DrawFarsiTextBounded(TitleStr, FLinearColor(1.0f, 0.88f, 0.35f, 1.0f),
		CardX + 24.f * S, CardY + 16.f * S, CardW - 48.f * S - PctW - 10.f * S,
		TitleFont ? TitleFont.Get() : nullptr, 1.42f * S, true);

	DrawFarsiTextBounded(DescStr, FLinearColor(0.92f, 0.95f, 0.98f, 1.0f),
		CardX + 24.f * S, CardY + 56.f * S, CardW - 48.f * S, BodyFont ? BodyFont.Get() : nullptr, 0.98f * S, true);

	// ---- 3. the progress bar (same 3D-plated style as the gameplay veil) ---
	const float BarW = CardW - 48.f * S;
	const float BarH = 18.f * S;
	const float BarX = CardX + 24.f * S;
	const float BarY = CardY + 100.f * S;

	DrawRect(FLinearColor(0.06f, 0.08f, 0.12f, 0.98f), BarX, BarY, BarW, BarH);
	DrawRect(FLinearColor(0.40f, 0.48f, 0.60f, 0.85f), BarX, BarY, BarW, 1.5f * S);
	DrawRect(FLinearColor(0.40f, 0.48f, 0.60f, 0.85f), BarX, BarY + BarH - 1.5f * S, BarW, 1.5f * S);

	const float FillW = BarW * FMath::Clamp(Progress, 0.02f, 1.0f);
	if (LoadingBarFillTexture)
	{
		DrawTexture(LoadingBarFillTexture, BarX, BarY, FillW, BarH, 0.f, 0.f, FMath::Clamp(Progress, 0.02f, 1.0f), 1.f, FLinearColor(1.0f, 0.85f, 0.25f, 1.0f));
	}
	else
	{
		DrawRect(FLinearColor(0.95f, 0.72f, 0.15f, 1.0f), BarX, BarY, FillW, BarH);
		DrawRect(FLinearColor(1.0f, 0.95f, 0.65f, 0.85f), BarX, BarY + 2.f * S, FillW, 4.f * S);
		DrawRect(FLinearColor(0.45f, 0.25f, 0.05f, 0.70f), BarX, BarY + BarH - 4.f * S, FillW, 3.f * S);
	}
	const FString PctStr = FString::Printf(TEXT("%%%d"), FMath::RoundToInt(Progress * 100.f));
	DrawFarsiTextBounded(PctStr, FLinearColor(1.0f, 0.90f, 0.40f, 1.0f),
		CardX + CardW - 24.f * S - PctW, CardY + 20.f * S, PctW,
		TitleFont ? TitleFont.Get() : nullptr, 1.10f * S, true, true);

	// ---- 4. the status line (this is what the player WAITS on) --------------
	const float PromptBoxW = CardW - 48.f * S;
	const float PromptBoxH = 48.f * S;
	const float PromptBoxX = CardX + 24.f * S;
	const float PromptBoxY = CardY + 130.f * S;
	DrawChiseledTacticalPanel(PromptBoxX, PromptBoxY, PromptBoxW, PromptBoxH,
		FLinearColor(0.05f, 0.06f, 0.08f, 0.85f),
		FLinearColor(0.30f, 0.35f, 0.42f, 0.60f), 6.f * S);
	DrawFarsiTextBounded(
		AQuestNativeHUD::LocalizeHUDText(this, TEXT("Loading"), TEXT("DeploymentVeil"),
			TEXT("در حال استقرار نیروها و هماهنگی بی‌سیم..."), TEXT("Deploying forces and coordinating radio...")),
		FLinearColor(0.80f, 0.85f, 0.90f, 0.95f), PromptBoxX, PromptBoxY, PromptBoxW,
		BodyFont ? BodyFont.Get() : nullptr, 1.00f * S, true, true, PromptBoxH);

	// ---- 5. combat tip, so a long load has something to read ---------------
	if (LoadSys)
	{
		const FText Tip = LoadSys->GetRandomTacticalTip();
		if (!Tip.IsEmpty())
		{
			DrawFarsiTextBounded(Tip.ToString(), FLinearColor(0.86f, 0.90f, 0.94f, 0.90f),
				CardX + 24.f * S, CardY - 32.f * S, CardW - 48.f * S,
				BodyFont ? BodyFont.Get() : nullptr, 0.86f * S, true);
		}
	}

	// ---- 6. a spinner, so "working" is visible even if a frame stutters -----
	// Vertical order above the card, bottom-up: tip line (CardY-32), spinner caption
	// (CardY-56, one line tall), spinner (centre CardY-90, so its ticks stop 9 px above
	// the caption). The same numbers are mirrored in tools/hud_layout_check.py.
	const float SpinnerR = 16.f * S;
	const float SpinnerCX = ScreenW * 0.5f;
	const float SpinnerCY = CardY - 90.f * S;
	const int32 Spokes = 12;
	const float Spin = DepartureSeconds * 2.4f;
	for (int32 i = 0; i < Spokes; ++i)
	{
		const float A = Spin + (2.f * PI * static_cast<float>(i)) / static_cast<float>(Spokes);
		const float Alpha = 0.10f + 0.90f * (static_cast<float>(i) / static_cast<float>(Spokes));
		DrawLine(SpinnerCX + FMath::Cos(A) * SpinnerR, SpinnerCY + FMath::Sin(A) * SpinnerR,
			SpinnerCX + FMath::Cos(A) * (SpinnerR + 9.f * S), SpinnerCY + FMath::Sin(A) * (SpinnerR + 9.f * S),
			FLinearColor(1.0f, 0.86f, 0.35f, Alpha), 2.0f * S);
	}
	DrawFarsiTextBounded(
		AQuestNativeHUD::LocalizeHUDText(this, TEXT("Loading"), TEXT("LoadingCaption"),
			TEXT("در حال بارگذاری"), TEXT("LOADING")),
		FLinearColor(1.0f, 0.86f, 0.35f, 0.95f),
		ScreenW * 0.5f - 200.f * S, CardY - 56.f * S, 400.f * S,
		TitleFont ? TitleFont.Get() : nullptr, 1.10f * S, true, true);
}

void ASquadAIMainMenuHUD::DrawDifficultyScreen(float ScreenW, float ScreenH, float MouseX, float MouseY)
{
	const bool bMenuEnglish = !CachedMenuSettings.LanguageCode.StartsWith(TEXT("fa"), ESearchCase::IgnoreCase);
	const float UIScale = FMath::Clamp(ScreenH / 1080.f, 0.70f, 1.35f);

	// AAA-B2-3: difficulty screen rebuilt as cinematic deployment cards. Text lives
	// in a lower glass band, images stay dominant, and color coding uses olive/teal/rust/crimson,
	// not the old gold wash.
	const float HeaderX = 54.f * UIScale;
	const float HeaderY = 104.f * UIScale;
	DrawChiseledTacticalPanel(HeaderX, HeaderY, ScreenW - 108.f * UIScale, 74.f * UIScale, FLinearColor(0.012f, 0.024f, 0.028f, 0.70f), PrimaryAccentColor * 0.60f, 10.f * UIScale);
	DrawFarsiTextBounded((bMenuEnglish ? TEXT("Combat Intensity and Deployment") : TEXT("انتخاب شدت نبرد و اعزام | COMBAT INTENSITY")), PrimaryAccentColor, HeaderX + 24.f * UIScale, HeaderY + 12.f * UIScale, ScreenW - 156.f * UIScale, TitleFont ? TitleFont.Get() : nullptr, 1.20f * UIScale, true);
	DrawFarsiTextBounded((bMenuEnglish ? TEXT("Four cinematic cards; combat intensity rises from training to lethal simulation.") : TEXT("چهار کارت بدون قاب طلایی؛ شدت نبرد از آموزش تا شبیه‌سازی مرگبار افزایش می‌یابد.")), FLinearColor(0.78f, 0.86f, 0.86f, 0.92f), HeaderX + 24.f * UIScale, HeaderY + 42.f * UIScale, ScreenW - 156.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.70f * UIScale, true);

	const float ColMarginX = 54.f * UIScale;
	const float ColGap = 16.f * UIScale;
	const float TotalColsW = ScreenW - (2.f * ColMarginX);
	const float ColW = (TotalColsW - (3.f * ColGap)) / 4.f;
	const float ColY = 196.f * UIScale;
	const float ColH = ScreenH - ColY - (86.f * UIScale);

	struct FDifficultyColumnData
	{
		int32 ID;
		FText Title;
		const TCHAR* Subtitle;
		const TCHAR* Tone;
		UTexture2D* BackgroundTex;
		TArray<const TCHAR*> Modifiers;
		FLinearColor ThemeColor;
	};

	const FDifficultyColumnData DiffCols[4] = {
		{ 501, FText::FromString(bMenuEnglish ? TEXT("Recruit") : TEXT("سرباز تازه‌کار")), bMenuEnglish ? TEXT("Command training and familiarization") : TEXT("آموزش فرماندهی و آشنایی"), bMenuEnglish ? TEXT("Low risk") : TEXT("ریسک پایین"), DiffRecruitTexture ? DiffRecruitTexture.Get() : nullptr,
			{ bMenuEnglish ? TEXT("• Enemies react with delay") : TEXT("• دشمن با تأخیر واکنش می‌دهد"), bMenuEnglish ? TEXT("• Supplies and aid are more generous") : TEXT("• تدارکات و امداد فراوان‌تر است"), bMenuEnglish ? TEXT("• Best for learning squad commands") : TEXT("• مناسب یادگیری فرمان‌های جوخه") }, FLinearColor(0.42f, 0.70f, 0.46f, 1.f) },
		{ 502, FText::FromString(bMenuEnglish ? TEXT("Line-Breaker") : TEXT("رزمنده خط‌شکن")), bMenuEnglish ? TEXT("Standard operation balance") : TEXT("تعادل استاندارد عملیات"), bMenuEnglish ? TEXT("Medium risk") : TEXT("ریسک متوسط"), DiffRegularTexture ? DiffRegularTexture.Get() : nullptr,
			{ bMenuEnglish ? TEXT("• Enemies take cover and pressure you") : TEXT("• دشمن سنگر می‌گیرد و فشار می‌آورد"), bMenuEnglish ? TEXT("• Ammunition requires management") : TEXT("• مهمات نیازمند مدیریت است"), bMenuEnglish ? TEXT("• Recommended core experience") : TEXT("• تجربه اصلی و پیشنهادی بازی") }, FLinearColor(0.42f, 0.78f, 0.76f, 1.f) },
		{ 503, FText::FromString(bMenuEnglish ? TEXT("Frontline Veteran") : TEXT("کهنه‌سرباز جبهه")), bMenuEnglish ? TEXT("Heavy fire and limited time") : TEXT("آتش سنگین و فرصت کم"), bMenuEnglish ? TEXT("High risk") : TEXT("ریسک بالا"), DiffHardenedTexture ? DiffHardenedTexture.Get() : nullptr,
			{ bMenuEnglish ? TEXT("• Flanking and suppression are serious") : TEXT("• دور زدن و سرکوب دشمن جدی است"), bMenuEnglish ? TEXT("• Aid boxes are very limited") : TEXT("• جعبه‌های امدادی بسیار محدود"), bMenuEnglish ? TEXT("• Precise squad coordination required") : TEXT("• هماهنگی دقیق جوخه ضروری است") }, FLinearColor(0.72f, 0.50f, 0.34f, 1.f) },
		{ 504, FText::FromString(bMenuEnglish ? TEXT("Lethal Commander") : TEXT("فرمانده مرگبار")), bMenuEnglish ? TEXT("Ruthless front-line simulation") : TEXT("شبیه‌سازی بی‌رحمانه خط مقدم"), bMenuEnglish ? TEXT("Maximum risk") : TEXT("ریسک حداکثر"), DiffLethalTexture ? DiffLethalTexture.Get() : nullptr,
			{ bMenuEnglish ? TEXT("• One mistake can break the operation") : TEXT("• یک خطا می‌تواند عملیات را بشکند"), bMenuEnglish ? TEXT("• Enemies are coordinated and ruthless") : TEXT("• دشمن هماهنگ و بی‌رحم است"), bMenuEnglish ? TEXT("• No reliance on helper indicators") : TEXT("• بدون تکیه بر نشانگرهای کمکی") }, FLinearColor(0.78f, 0.22f, 0.18f, 1.f) }
	};

	for (int32 i = 0; i < 4; ++i)
	{
		const FDifficultyColumnData& Col = DiffCols[i];
		const float cx = ColMarginX + i * (ColW + ColGap);
		const bool bHover = (MouseX >= cx && MouseX <= cx + ColW && MouseY >= ColY && MouseY <= ColY + ColH);
		if (bHover) HoveredButtonIndex = Col.ID;
		RegisterButton(Col.ID, cx, ColY, ColW, ColH, Col.Title);

		const FLinearColor BorderCol = bHover ? Col.ThemeColor : Col.ThemeColor * 0.62f;
		DrawChiseledTacticalPanel(cx, ColY, ColW, ColH, FLinearColor(0.008f, 0.016f, 0.018f, 0.95f), BorderCol, 10.f * UIScale);

		const float ImgPad = 8.f * UIScale;
		if (Col.BackgroundTex)
		{
			DrawTexture(Col.BackgroundTex, cx + ImgPad, ColY + ImgPad, ColW - 2.f * ImgPad, ColH - 2.f * ImgPad, 0.f, 0.f, 1.f, 1.f, bHover ? FLinearColor(1.05f, 1.08f, 1.06f, 1.f) : FLinearColor(0.78f, 0.84f, 0.82f, 0.94f));
		}
		else
		{
			DrawRect(FLinearColor(0.018f, 0.030f, 0.034f, 0.96f), cx + ImgPad, ColY + ImgPad, ColW - 2.f * ImgPad, ColH - 2.f * ImgPad);
			DrawTacticalTopoGrid(cx + ImgPad, ColY + ImgPad, ColW - 2.f * ImgPad, ColH - 2.f * ImgPad, Col.ThemeColor);
		}

		// Readability bands: top small identity strip, bottom full tactical glass sheet.
		DrawRect(FLinearColor(0.f, 0.f, 0.f, bHover ? 0.24f : 0.34f), cx + ImgPad, ColY + ImgPad, ColW - 2.f * ImgPad, ColH - 2.f * ImgPad);
		DrawRect(FLinearColor(0.f, 0.f, 0.f, 0.70f), cx + ImgPad, ColY + ColH - 238.f * UIScale, ColW - 2.f * ImgPad, 230.f * UIScale);
		DrawRect(Col.ThemeColor, cx + 14.f * UIScale, ColY + 14.f * UIScale, 5.f * UIScale, 44.f * UIScale);

		// UE 5.7 checked-format strings require FString::Printf format args to be compile-time literals;
		// do not pass a ternary/runtime const TCHAR* as the format parameter.
		const FString DifficultyCardIndexText = bMenuEnglish
			? FString::Printf(TEXT("%02d"), i + 1)
			: UFarsiTextHelper::ToPersianDigits(FString::Printf(TEXT("%02d"), i + 1));
		DrawFarsiTextBounded(DifficultyCardIndexText, Col.ThemeColor, cx + 24.f * UIScale, ColY + 15.f * UIScale, 58.f * UIScale, TitleFont ? TitleFont.Get() : nullptr, 0.98f * UIScale, true);
		DrawFarsiTextBounded(Col.Tone, FLinearColor(0.85f, 0.91f, 0.90f, 0.92f), cx + 80.f * UIScale, ColY + 20.f * UIScale, ColW - 100.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.66f * UIScale, true);

		float TextY = ColY + ColH - 222.f * UIScale;
		DrawFarsiTextBounded(Col.Title.ToString(), bHover ? FLinearColor(0.92f, 1.0f, 0.98f, 1.f) : FLinearColor::White, cx + 18.f * UIScale, TextY, ColW - 36.f * UIScale, TitleFont ? TitleFont.Get() : nullptr, 1.02f * UIScale, true, true);
		TextY += 28.f * UIScale;
		DrawFarsiTextBounded(Col.Subtitle, Col.ThemeColor, cx + 18.f * UIScale, TextY, ColW - 36.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.70f * UIScale, true, true);
		TextY += 30.f * UIScale;
		DrawLine(cx + 22.f * UIScale, TextY, cx + ColW - 22.f * UIScale, TextY, Col.ThemeColor * 0.65f, 1.0f);
		TextY += 12.f * UIScale;

		for (const TCHAR* Mod : Col.Modifiers)
		{
			DrawFarsiTextBounded(Mod, FLinearColor(0.84f, 0.89f, 0.88f, 0.94f), cx + 18.f * UIScale, TextY, ColW - 36.f * UIScale, BodyFont ? BodyFont.Get() : nullptr, 0.62f * UIScale, true);
			TextY += 22.f * UIScale;
		}

		const float LaunchBtnH = 40.f * UIScale;
		const float LaunchBtnW = ColW - 32.f * UIScale;
		const float LaunchBtnX = cx + 16.f * UIScale;
		const float LaunchBtnY = ColY + ColH - LaunchBtnH - 18.f * UIScale;
		const bool bBtnHover = (MouseX >= LaunchBtnX && MouseX <= LaunchBtnX + LaunchBtnW && MouseY >= LaunchBtnY && MouseY <= LaunchBtnY + LaunchBtnH);
		DrawStyledButton(LaunchBtnX, LaunchBtnY, LaunchBtnW, LaunchBtnH, FText::FromString((bMenuEnglish ? TEXT("Confirm and Deploy") : TEXT("تأیید و اعزام"))), bBtnHover || bHover);
	}

	const float BackW = 150.f * UIScale;
	const float BackH = 38.f * UIScale;
	const float BackX = ColMarginX;
	const float BackY = ScreenH - BackH - 24.f * UIScale;
	const bool bBackHover = (MouseX >= BackX && MouseX <= BackX + BackW && MouseY >= BackY && MouseY <= BackY + BackH);
	if (bBackHover) HoveredButtonIndex = 99;
	RegisterButton(99, BackX, BackY, BackW, BackH, MenuTextConfig.ButtonBack);
	DrawStyledButton(BackX, BackY, BackW, BackH, MenuTextConfig.ButtonBack, bBackHover);
}

// =============================================================================
//  8. LOAD GAME SCREEN
// =============================================================================

void ASquadAIMainMenuHUD::DrawLoadGameScreen(float ScreenW, float ScreenH, float MouseX, float MouseY)
{
	const bool bMenuEnglish = !CachedMenuSettings.LanguageCode.StartsWith(TEXT("fa"), ESearchCase::IgnoreCase);
	const float UIScale = FMath::Clamp(ScreenH / 1080.f, 0.70f, 1.35f);
	const float BoxW = 600.f * UIScale;
	const float BoxH = 460.f * UIScale;
	const float BoxX = (ScreenW - BoxW) * 0.5f;
	const float BoxY = (ScreenH - BoxH) * 0.5f;

	DrawSacredDefenseBorder(BoxX, BoxY, BoxW, BoxH, PrimaryAccentColor, true);
	DrawFarsiTextBounded((bMenuEnglish ? TEXT("Load Saved Operation Position") : TEXT("بارگذاری موقعیت ذخیره‌شده عملیات")), PrimaryAccentColor, BoxX + 20.f, BoxY + 20.f * UIScale, BoxW - 40.f, TitleFont ? TitleFont.Get() : nullptr, 1.30f * UIScale, true, true);

	USquadAISaveLoadSubsystem* SaveSys = USquadAISaveLoadSubsystem::Get(this);
	const TArray<FSquadSaveSlotInfo> Slots = SaveSys ? SaveSys->GetAllSaveSlots() : TArray<FSquadSaveSlotInfo>();

	float SlotY = BoxY + 65.f * UIScale;
	const float SlotW = BoxW - 40.f * UIScale;
	const float SlotH = 70.f * UIScale;

	for (int32 i = 0; i < 4; ++i)
	{
		const bool bExists = Slots.IsValidIndex(i) && Slots[i].bExists;
		const FString SlotName = bExists
			? (bMenuEnglish ? FString::Printf(TEXT("Saved Operation Slot %d"), i + 1) : Slots[i].DisplayName)
			: (bMenuEnglish ? FString::Printf(TEXT("Empty Slot %d"), i + 1) : FString::Printf(TEXT("جایگاه خالی %d"), i + 1));
		const FString SlotDate = bExists ? Slots[i].Timestamp.ToString(TEXT("%Y-%m-%d %H:%M")) : (bMenuEnglish ? TEXT("No saved data") : TEXT("اطلاعاتی ذخیره نشده است"));

		const bool bHover = (MouseX >= BoxX + 20.f * UIScale && MouseX <= BoxX + 20.f * UIScale + SlotW && MouseY >= SlotY && MouseY <= SlotY + SlotH);
		if (bHover && bExists) HoveredButtonIndex = 700 + i; // F-G3: load slots moved off the 600s (Farsi branch hijacked them).

		RegisterButton(700 + i, BoxX + 20.f * UIScale, SlotY, SlotW, SlotH, FText::FromString(SlotName));

		DrawChiseledTacticalPanel(BoxX + 20.f * UIScale, SlotY, SlotW, SlotH, bHover ? FLinearColor(0.20f, 0.15f, 0.04f, 0.98f) : FLinearColor(0.06f, 0.08f, 0.10f, 0.90f), bHover ? PrimaryAccentColor : FLinearColor(0.30f, 0.35f, 0.40f, 0.70f), 6.f);
		DrawFarsiTextBounded(SlotName, bHover ? PrimaryAccentColor : FLinearColor::White, BoxX + 32.f * UIScale, SlotY + 10.f * UIScale, SlotW - 24.f, MenuFont ? MenuFont.Get() : nullptr, 1.05f * UIScale, true);
		DrawFarsiTextBounded(SlotDate, FLinearColor(0.80f, 0.85f, 0.90f, 1.0f), BoxX + 32.f * UIScale, SlotY + 36.f * UIScale, SlotW - 24.f, BodyFont ? BodyFont.Get() : nullptr, 0.82f * UIScale, true);

		SlotY += SlotH + 10.f * UIScale;
	}

	// Back Button
	const float BackW = 140.f * UIScale;
	const float BackH = 36.f * UIScale;
	const float BackX = BoxX + 20.f * UIScale;
	const float BackY = BoxY + BoxH - BackH - 14.f * UIScale;
	const bool bBackHover = (MouseX >= BackX && MouseX <= BackX + BackW && MouseY >= BackY && MouseY <= BackY + BackH);
	if (bBackHover) HoveredButtonIndex = 99;

	RegisterButton(99, BackX, BackY, BackW, BackH, MenuTextConfig.ButtonBack);
	DrawStyledButton(BackX, BackY, BackW, BackH, MenuTextConfig.ButtonBack, bBackHover);
}

// =============================================================================
//  9. SETTINGS & GRAPHICS SCREEN
// =============================================================================

void ASquadAIMainMenuHUD::DrawSettingsScreen(float ScreenW, float ScreenH, float MouseX, float MouseY)
{
	const bool bMenuEnglish = !CachedMenuSettings.LanguageCode.StartsWith(TEXT("fa"), ESearchCase::IgnoreCase);
	const float UIScale = FMath::Clamp(ScreenH / 1080.f, 0.70f, 1.35f);
	const float BoxW = 560.f * UIScale;
	const float BoxH = 440.f * UIScale; // S17-MVOL: fifth settings row
	const float BoxX = (ScreenW - BoxW) * 0.5f;
	const float BoxY = (ScreenH - BoxH) * 0.5f;

	DrawSacredDefenseBorder(BoxX, BoxY, BoxW, BoxH, PrimaryAccentColor, true);
	DrawFarsiTextBounded(MenuTextConfig.ButtonSettings.ToString(), PrimaryAccentColor, BoxX + 20.f, BoxY + 20.f * UIScale, BoxW - 40.f, TitleFont ? TitleFont.Get() : nullptr, 1.30f * UIScale, true, true);

	struct FSettingOptionEntry
	{
		int32 ID;
		const TCHAR* Name;
		FString Val;
		bool bIsVolume;
	};

	// B6-4: live values from the settings working copy (was: hardcoded placebo rows).
	const TCHAR* QualityNamesFa[] = {
		TEXT("پایین (Low)"), TEXT("متوسط (Med)"), TEXT("بالا (High)"), TEXT("خیلی بالا (Epic)")
	};
	const TCHAR* QualityNamesEn[] = {
		TEXT("Low"), TEXT("Medium"), TEXT("High"), TEXT("Epic")
	};
	const int32 QualityIdx = FMath::Clamp(CachedMenuSettings.OverallQualityPreset, 0, 3);
	const TCHAR** QualityNames = bMenuEnglish ? QualityNamesEn : QualityNamesFa;
	const FSettingOptionEntry SettingsList[] = {
		{ 701, bMenuEnglish ? TEXT("Graphics and shadow quality:") : TEXT("کیفیت گرافیک و سایه‌ها:"), QualityNames[QualityIdx], false },
		{ 702, bMenuEnglish ? TEXT("Game language:") : TEXT("زبان منوها و فرامین:"),
			CachedMenuSettings.LanguageCode.StartsWith(TEXT("ar"), ESearchCase::IgnoreCase) ? FString(TEXT("العربية (Arabic)"))
			: (bMenuEnglish ? FString(TEXT("English")) : FString(TEXT("فارسی (Persian)"))), false },
		{ 703, bMenuEnglish ? TEXT("Battle SFX volume:") : TEXT("حجم صدای افکت‌های جنگی:"), FString::Printf(TEXT("%d%%"), FMath::RoundToInt(CachedMenuSettings.SFXVolume * 100.f)), true },
		{ 704, bMenuEnglish ? TEXT("Radio and voice volume:") : TEXT("حجم صدای بیسیم و مکالمات:"), FString::Printf(TEXT("%d%%"), FMath::RoundToInt(CachedMenuSettings.VoiceVolume * 100.f)), true },
		{ 720, bMenuEnglish ? TEXT("Menu music volume:") : TEXT("حجم موسیقی منوی اصلی:"), FString::Printf(TEXT("%d%%"), FMath::RoundToInt(CachedMenuSettings.MusicVolume * 100.f)), true } // S17-MVOL
	};

	float SetY = BoxY + 70.f * UIScale;
	const float SetW = BoxW - 40.f * UIScale;
	const float SetH = 44.f * UIScale;

	for (const FSettingOptionEntry& S : SettingsList)
	{
		const float RowX = BoxX + 20.f * UIScale;
		DrawChiseledTacticalPanel(RowX, SetY, SetW, SetH, FLinearColor(0.06f, 0.08f, 0.10f, 0.90f), FLinearColor(0.25f, 0.30f, 0.35f, 0.70f), 4.f);
		DrawFarsiTextBounded(S.Name, FLinearColor(0.85f, 0.88f, 0.92f, 1.0f), RowX + 12.f * UIScale, SetY + 10.f * UIScale, SetW * 0.55f, BodyFont ? BodyFont.Get() : nullptr, 0.88f * UIScale, true);
		DrawFarsiTextBounded(S.Val, PrimaryAccentColor, BoxX + SetW - 160.f * UIScale, SetY + 10.f * UIScale, 140.f * UIScale, MenuFont ? MenuFont.Get() : nullptr, 0.90f * UIScale, true, true);

		// B6-4: rows are clickable (701/702 whole-row; volume rows get [-]/[+] steppers).
		if (S.bIsVolume)
		{
			const float StepW = 30.f * UIScale;
			const float ValX = BoxX + SetW - 160.f * UIScale;
			const float MinusX = ValX - (StepW + 6.f * UIScale);
			const float PlusX = ValX + 140.f * UIScale + 6.f * UIScale;
			const float StepY = SetY + 8.f * UIScale;
			const float StepH = SetH - 16.f * UIScale;
			const int32 MinusID = (S.ID == 703) ? 705 : ((S.ID == 704) ? 707 : 709); // S17-MVOL
			const int32 PlusID = (S.ID == 703) ? 706 : ((S.ID == 704) ? 708 : 710); // S17-MVOL
			const bool bMinusHover = (MouseX >= MinusX && MouseX <= MinusX + StepW && MouseY >= StepY && MouseY <= StepY + StepH);
			const bool bPlusHover = (MouseX >= PlusX && MouseX <= PlusX + StepW && MouseY >= StepY && MouseY <= StepY + StepH);
			if (bMinusHover) HoveredButtonIndex = MinusID;
			if (bPlusHover) HoveredButtonIndex = PlusID;
			RegisterButton(MinusID, MinusX, StepY, StepW, StepH, FText::FromString(TEXT("-")));
			RegisterButton(PlusID, PlusX, StepY, StepW, StepH, FText::FromString(TEXT("+")));
			DrawChiseledTacticalPanel(MinusX, StepY, StepW, StepH, bMinusHover ? FLinearColor(0.20f, 0.16f, 0.06f, 0.98f) : FLinearColor(0.08f, 0.09f, 0.11f, 0.95f), PrimaryAccentColor, 4.f);
			DrawChiseledTacticalPanel(PlusX, StepY, StepW, StepH, bPlusHover ? FLinearColor(0.20f, 0.16f, 0.06f, 0.98f) : FLinearColor(0.08f, 0.09f, 0.11f, 0.95f), PrimaryAccentColor, 4.f);
			DrawFarsiTextBounded(TEXT("-"), FLinearColor::White, MinusX, StepY, StepW, MenuFont ? MenuFont.Get() : nullptr, 0.9f * UIScale, true, true, StepH);
			DrawFarsiTextBounded(TEXT("+"), FLinearColor::White, PlusX, StepY, StepW, MenuFont ? MenuFont.Get() : nullptr, 0.9f * UIScale, true, true, StepH);
		}
		else
		{
			const bool bRowHover = (MouseX >= RowX && MouseX <= RowX + SetW && MouseY >= SetY && MouseY <= SetY + SetH);
			if (bRowHover) HoveredButtonIndex = S.ID;
			RegisterButton(S.ID, RowX, SetY, SetW, SetH, FText::FromString(S.Name));
		}
		SetY += SetH + 10.f * UIScale;
	}

	// Back Button
	const float BackW = 140.f * UIScale;
	const float BackH = 36.f * UIScale;
	const float BackX = BoxX + 20.f * UIScale;
	const float BackY = BoxY + BoxH - BackH - 14.f * UIScale;
	const bool bBackHover = (MouseX >= BackX && MouseX <= BackX + BackW && MouseY >= BackY && MouseY <= BackY + BackH);
	if (bBackHover) HoveredButtonIndex = 99;

	RegisterButton(99, BackX, BackY, BackW, BackH, MenuTextConfig.ButtonBack);
	DrawStyledButton(BackX, BackY, BackW, BackH, MenuTextConfig.ButtonBack, bBackHover);
}

// =============================================================================
//  10. TACTICAL BRIEFING & CLASSIFIED DOSSIER
// =============================================================================

void ASquadAIMainMenuHUD::DrawTacticalBriefingScreen(float ScreenW, float ScreenH, float MouseX, float MouseY)
{
	const bool bMenuEnglish = !CachedMenuSettings.LanguageCode.StartsWith(TEXT("fa"), ESearchCase::IgnoreCase);
	const float UIScale = FMath::Clamp(ScreenH / 1080.f, 0.70f, 1.35f);
	const float BoxW = 760.f * UIScale;
	const float BoxH = 540.f * UIScale;
	const float BoxX = (ScreenW - BoxW) * 0.5f;
	const float BoxY = (ScreenH - BoxH) * 0.5f;

	DrawSacredDefenseBorder(BoxX, BoxY, BoxW, BoxH, PrimaryAccentColor, true);
	DrawDossierDocumentUnderlay(BoxX, BoxY, BoxW, BoxH, (bMenuEnglish ? TEXT("CLASSIFIED - TOP SECRET") : TEXT("محرمانه - به کلی سری")), PrimaryAccentColor);

	DrawFarsiTextBounded((bMenuEnglish ? TEXT("Operational Intelligence Document | Dehlavieh - Susangerd Defense Axis") : TEXT("سند اطلاعات عملیاتی | محور دفاعی دهلاویه — سوسنگرد")), PrimaryAccentColor, BoxX + 30.f, BoxY + 24.f * UIScale, BoxW - 60.f, TitleFont ? TitleFont.Get() : nullptr, 1.30f * UIScale, true);

	const TCHAR* BriefingLines[] = {
		(bMenuEnglish ? TEXT("Document date: 15 June 1981 // Theater: Khuzestan - Dehlavieh front line") : TEXT("تاریخ سند: ۲۵ خرداد ۱۳۶۰ // منطقه عملیاتی: خوزستان - خط مقدم دهلاویه")),
		(bMenuEnglish ? TEXT("Axis command: Dr. Mostafa Chamran | Field commander: Major Shahid Iraj Rostami") : TEXT("فرماندهی کل محور: دکتر مصطفی چمران | فرمانده میدان: سرگرد شهید ایرج رستمی")),
		(bMenuEnglish ? TEXT("Operational objective: hold forward berms, block armored columns, and defend Ahvaz") : TEXT("هدف عملیاتی: تثبیت خاکریزهای مقدم، سد پیشروی ستون‌های زرهی و دفاع از اهواز")),
		(bMenuEnglish ? TEXT("Battle tactics: guerrilla raids, light mortar fire, anti-armor guidance, and smart mine placement") : TEXT("تاکتیک جنگی: شبیخون‌های چریکی، آتش خمپاره سبک، هدایت ضدزره و مین‌گذاری هوشمند")),
		(bMenuEnglish ? TEXT("Commander message: Brothers, this ground is the honor of our homeland. We will not retreat one step.") : TEXT("پیام فرمانده: «برادران رزمنده، اینجا خاک ناموس وطن است. وجبی عقب‌نشینی نخواهیم کرد.»"))
	};

	float LineY = BoxY + 70.f * UIScale;
	for (const TCHAR* L : BriefingLines)
	{
		DrawFarsiTextBounded(L, FLinearColor(0.90f, 0.92f, 0.95f, 1.0f), BoxX + 30.f, LineY, BoxW - 60.f, BodyFont ? BodyFont.Get() : nullptr, 0.90f * UIScale, true);
		LineY += 34.f * UIScale;
	}

	// Back Button
	const float BackW = 160.f * UIScale;
	const float BackH = 38.f * UIScale;
	const float BackX = BoxX + 30.f;
	const float BackY = BoxY + BoxH - BackH - 18.f * UIScale;
	const bool bBackHover = (MouseX >= BackX && MouseX <= BackX + BackW && MouseY >= BackY && MouseY <= BackY + BackH);
	if (bBackHover) HoveredButtonIndex = 99;

	RegisterButton(99, BackX, BackY, BackW, BackH, MenuTextConfig.ButtonBack);
	DrawStyledButton(BackX, BackY, BackW, BackH, MenuTextConfig.ButtonBack, bBackHover);
}

// =============================================================================
//  11. CLICK & INTERACTION HANDLER
// =============================================================================

void ASquadAIMainMenuHUD::ProcessClickAtMousePosition(float MouseX, float MouseY)
{
	LastMenuClickTime = MasterTime; // MEGA-8: press-dip feedback clock.
	const bool bMenuEnglish = !CachedMenuSettings.LanguageCode.StartsWith(TEXT("fa"), ESearchCase::IgnoreCase);
	for (const auto& Btn : ClickableButtons)
	{
		if (MouseX >= Btn.Min.X && MouseX <= Btn.Max.X && MouseY >= Btn.Min.Y && MouseY <= Btn.Max.Y)
		{
			if (ButtonClickSound)
			{
				UGameplayStatics::PlaySound2D(this, ButtonClickSound);
			}

			if (Btn.ButtonID == 1) // Start New Game -> Difficulty
			{
				NavigateToState(EMainMenuState::NewGameDifficulty);
			}
			else if (Btn.ButtonID == 2) // Map Select
			{
				NavigateToState(EMainMenuState::MapSelect);
			}
			else if (Btn.ButtonID == 3) // Armory
			{
				NavigateToState(EMainMenuState::Armory);
			}
			else if (Btn.ButtonID == 4) // Progression
			{
				NavigateToState(EMainMenuState::PlayerProgression);
			}
			else if (Btn.ButtonID == 5) // Profile
			{
				NavigateToState(EMainMenuState::PlayerProfile);
			}
			else if (Btn.ButtonID == 6) // Achievements
			{
				NavigateToState(EMainMenuState::Achievements);
			}
			else if (Btn.ButtonID == 7) // Continue
			{
				if (USquadAISaveLoadSubsystem* SaveSys = USquadAISaveLoadSubsystem::Get(this))
				{
					if (SaveSys->HasAnySaveGames())
					{
						SaveSys->LoadLatestSave();
						return;
					}
				}
				if (USquadAILoadingScreenSubsystem* LoadSys = USquadAILoadingScreenSubsystem::Get(this))
				{
					LoadSys->StartDeploymentTransition(TargetGameplayLevelName, TEXT("Dehlavieh"));
				}
				else
				{
					UGameplayStatics::OpenLevel(this, TargetGameplayLevelName);
				}
			}
			else if (Btn.ButtonID == 8) // Load Game
			{
				NavigateToState(EMainMenuState::LoadGame);
			}
			else if (Btn.ButtonID == 9) // Settings
			{
				NavigateToState(EMainMenuState::Settings);
			}
			else if (Btn.ButtonID == 10) // Profile Header Slate (P1-7: single meaning now)
			{
				NavigateToState(EMainMenuState::PlayerProfile);
			}
			else if (Btn.ButtonID == 13) // P1-7: Tactical Briefing (was unreachable on shared ID 10)
			{
				NavigateToState(EMainMenuState::TacticalBriefing);
			}
			else if (Btn.ButtonID == 11) // Quit
			{
				UKismetSystemLibrary::QuitGame(this, GetOwningPlayerController(), EQuitPreference::Quit, false);
			}
			else if (Btn.ButtonID == 12) // Relic Collection
			{
				NavigateToState(EMainMenuState::RelicCollection);
			}
			else if (Btn.ButtonID == 99) // Back
			{
				if (ButtonBackSound)
				{
					UGameplayStatics::PlaySound2D(this, ButtonBackSound);
				}
				NavigateToState(EMainMenuState::Main);
			}
			else if (Btn.ButtonID == 701) // B6-4: cycle quality preset
			{
				if (USquadAISaveLoadSubsystem* SaveSys = USquadAISaveLoadSubsystem::Get(this))
				{
					FSquadGameSettingsSaveData S = SaveSys->LoadSettings();
					S.OverallQualityPreset = (S.OverallQualityPreset + 1) % 4;
					SaveSys->SaveSettings(S); // persists + ApplySettingsToEngine
					CachedMenuSettings = S;
				}
			}
			else if (Btn.ButtonID == 702) // B6-4: toggle menu language (live re-skin) — fa → en → ar (P7-L4)
			{
				if (USquadAISaveLoadSubsystem* SaveSys = USquadAISaveLoadSubsystem::Get(this))
				{
					FSquadGameSettingsSaveData S = SaveSys->LoadSettings();
					if (S.LanguageCode.StartsWith(TEXT("fa"), ESearchCase::IgnoreCase)) { S.LanguageCode = TEXT("en"); }
					else if (S.LanguageCode.StartsWith(TEXT("en"), ESearchCase::IgnoreCase)) { S.LanguageCode = TEXT("ar"); }
					else { S.LanguageCode = TEXT("fa"); }
					SaveSys->SaveSettings(S);
					CachedMenuSettings = S;
					if (S.LanguageCode.StartsWith(TEXT("ar"), ESearchCase::IgnoreCase)) { ApplyArabicPreset(); }
					else if (S.LanguageCode.StartsWith(TEXT("en"), ESearchCase::IgnoreCase)) { ApplyEnglishPreset(); }
					else { ApplyPersianFarsiPreset(); }
				}
			}
			else if (Btn.ButtonID >= 705 && Btn.ButtonID <= 710) // B6-4: volume steppers (S17-MVOL: +menu music)
			{
				if (USquadAISaveLoadSubsystem* SaveSys = USquadAISaveLoadSubsystem::Get(this))
				{
					FSquadGameSettingsSaveData S = SaveSys->LoadSettings();
					const float Delta = (Btn.ButtonID == 705 || Btn.ButtonID == 707 || Btn.ButtonID == 709) ? -0.1f : 0.1f;
					if (Btn.ButtonID <= 706) { S.SFXVolume = FMath::Clamp(S.SFXVolume + Delta, 0.f, 1.f); }
					else if (Btn.ButtonID <= 708) { S.VoiceVolume = FMath::Clamp(S.VoiceVolume + Delta, 0.f, 1.f); }
					else { S.MusicVolume = FMath::Clamp(S.MusicVolume + Delta, 0.f, 1.f); }
					SaveSys->SaveSettings(S);
					CachedMenuSettings = S;
					if (Btn.ButtonID >= 709) // S17-MVOL: apply to the playing theme instantly
					{
						for (TActorIterator<ASquadAIMainMenuSetupActor> It(GetWorld()); It; ++It)
						{
							It->SetMenuMusicVolume(S.MusicVolume);
						}
					}
				}
			}
			else if (Btn.ButtonID >= 100 && Btn.ButtonID < 190) // Select Map
			{
				SelectedMapIndex = Btn.ButtonID - 100;
			}
			else if (Btn.ButtonID == 199) // Launch Map
			{
				USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(this);
				const TArray<FSquadMapDefinition> Maps = Prog ? Prog->GetAvailableMaps() : TArray<FSquadMapDefinition>();
				if (Maps.IsValidIndex(SelectedMapIndex))
				{
					const FName TargetMap = Maps[SelectedMapIndex].LevelPackageName;
					if (USquadAILoadingScreenSubsystem* LoadSys = USquadAILoadingScreenSubsystem::Get(this))
					{
						LoadSys->StartDeploymentTransition(TargetMap, Maps[SelectedMapIndex].MapID);
					}
					else
					{
						UGameplayStatics::OpenLevel(this, TargetMap);
					}
				}
			}
			else if (Btn.ButtonID >= 200 && Btn.ButtonID < 290) // Select Weapon
			{
				SelectedWeaponIndex = Btn.ButtonID - 200;
			}
			else if (Btn.ButtonID == 298) // Unlock Weapon
			{
				if (USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(this))
				{
					const TArray<FSquadWeaponDefinition> Weps = Prog->GetAvailableWeapons();
					if (Weps.IsValidIndex(SelectedWeaponIndex))
					{
						if (Prog->UnlockWeapon(Weps[SelectedWeaponIndex].WeaponID))
						{
							if (UpgradePurchasedSound)
							{
								UGameplayStatics::PlaySound2D(this, UpgradePurchasedSound);
							}
						}
					}
				}
			}
			else if (Btn.ButtonID == 299) // Equip Weapon
			{
				if (USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(this))
				{
					const TArray<FSquadWeaponDefinition> Weps = Prog->GetAvailableWeapons();
					if (Weps.IsValidIndex(SelectedWeaponIndex))
					{
						Prog->EquipWeapon(Weps[SelectedWeaponIndex].WeaponID);
						if (UpgradePurchasedSound)
						{
							UGameplayStatics::PlaySound2D(this, UpgradePurchasedSound);
						}
					}
				}
			}
			else if (Btn.ButtonID >= 300 && Btn.ButtonID < 390) // Buy Node
			{
				const int32 NodeIdx = Btn.ButtonID - 300;
				if (USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(this))
				{
					const TArray<FSquadProgressionNode> Nodes = Prog->GetProgressionNodes();
					if (Nodes.IsValidIndex(NodeIdx))
					{
						if (Prog->UnlockProgressionNode(Nodes[NodeIdx].NodeID))
						{
							if (UpgradePurchasedSound)
							{
								UGameplayStatics::PlaySound2D(this, UpgradePurchasedSound);
							}
						}
					}
				}
			}
			else if (Btn.ButtonID >= 400 && Btn.ButtonID < 410) // Select Avatar
			{
				const int32 AvaIdx = Btn.ButtonID - 400;
				const FName AvaIDs[] = { FName("ShahidRostami"), FName("YoungBasiji"), FName("ArteshParatrooper"), FName("GuerrillaHunter") };
				if (AvaIdx >= 0 && AvaIdx < 4)
				{
					if (USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(this))
					{
						Prog->SetActiveAvatar(AvaIDs[AvaIdx]);
					}
				}
			}
			else if (Btn.ButtonID >= 410 && Btn.ButtonID < 440) // Switch Profile
			{
				const int32 ProfIdx = Btn.ButtonID - 410;
				if (USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(this))
				{
					Prog->SwitchProfile(ProfIdx);
				}
			}
			else if (Btn.ButtonID == 450) // Toggle Edit or Save Name
			{
				if (bIsEditingPlayerName)
				{
					if (USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(this))
					{
						if (!CustomPlayerNameInput.TrimStartAndEnd().IsEmpty())
						{
							Prog->SetActivePlayerName(CustomPlayerNameInput.TrimStartAndEnd());
						}
					}
					bIsEditingPlayerName = false;
				}
				else
				{
					if (USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(this))
					{
						CustomPlayerNameInput = Prog->GetActiveProfile().PlayerName;
					}
					bIsEditingPlayerName = true;
				}
			}
			else if (Btn.ButtonID == 451) // Cancel Name Edit
			{
				bIsEditingPlayerName = false;
			}
			else if (Btn.ButtonID == 452) // Cycle Random Callsign Preset
			{
				if (USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(this))
				{
					CustomPlayerNameInput = Prog->CyclePresetCallsign();
				}
			}
			else if (Btn.ButtonID == 453) // Toggle Keyboard Language (Farsi / English)
			{
				bKeyboardLanguageFarsi = !bKeyboardLanguageFarsi;
			}
			else if (Btn.ButtonID == 460) // Create New Profile
			{
				if (USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(this))
				{
					const int32 NewCount = Prog->GetAllProfiles().Num() + 1;
					Prog->CreateNewProfile(bMenuEnglish ? FString::Printf(TEXT("Soldier %d"), NewCount) : FString::Printf(TEXT("رزمنده %d"), NewCount), FName("ShahidRostami"));
				}
			}
			else if (Btn.ButtonID >= 480 && Btn.ButtonID <= 483) // Preset Name Chip
			{
				const TCHAR* PresetChips[] = {
					bMenuEnglish ? TEXT("Major Shahid Iraj Rostami") : TEXT("سرگرد شهید ایرج رستمی"),
					bMenuEnglish ? TEXT("Dr. Shahid Mostafa Chamran") : TEXT("دکتر شهید مصطفی چمران"),
					bMenuEnglish ? TEXT("Commander Shahid Hassan Bagheri") : TEXT("سردار شهید حسن باقری"),
					bMenuEnglish ? TEXT("Shahid Mohammad Jahanara") : TEXT("شهید محمد جهان‌آرا")
				};
				const int32 ChipIdx = Btn.ButtonID - 480;
				if (ChipIdx >= 0 && ChipIdx < 4)
				{
					CustomPlayerNameInput = PresetChips[ChipIdx];
					if (USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(this))
					{
						Prog->SetActivePlayerName(CustomPlayerNameInput);
					}
					bIsEditingPlayerName = false;
				}
			}
			else if (Btn.ButtonID >= 600 && Btn.ButtonID < 650) // On-Screen Persian Virtual Key
			{
				const TCHAR* FarsiKeys[] = {
					TEXT("ض"), TEXT("ص"), TEXT("ث"), TEXT("ق"), TEXT("ف"), TEXT("غ"), TEXT("ع"), TEXT("ه"), TEXT("خ"), TEXT("ح"), TEXT("ج"), TEXT("چ"),
					TEXT("ش"), TEXT("س"), TEXT("ی"), TEXT("ب"), TEXT("ل"), TEXT("ا"), TEXT("ت"), TEXT("ن"), TEXT("م"), TEXT("ک"), TEXT("گ"),
					TEXT("ظ"), TEXT("ط"), TEXT("ز"), TEXT("ر"), TEXT("ذ"), TEXT("د"), TEXT("پ"), TEXT("و"), TEXT("ژ"), TEXT(" ")
				};
				const TCHAR* EnglishKeys[] = {
					TEXT("Q"), TEXT("W"), TEXT("E"), TEXT("R"), TEXT("T"), TEXT("Y"), TEXT("U"), TEXT("I"), TEXT("O"), TEXT("P"), TEXT("["), TEXT("]"),
					TEXT("A"), TEXT("S"), TEXT("D"), TEXT("F"), TEXT("G"), TEXT("H"), TEXT("J"), TEXT("K"), TEXT("L"), TEXT(";"), TEXT("'"),
					TEXT("Z"), TEXT("X"), TEXT("C"), TEXT("V"), TEXT("B"), TEXT("N"), TEXT("M"), TEXT(","), TEXT("/"), TEXT(" ")
				};
				const bool bUseEnglishVirtualKeys = bMenuEnglish || !bKeyboardLanguageFarsi;
				const int32 ActiveKeyCount = bUseEnglishVirtualKeys ? UE_ARRAY_COUNT(EnglishKeys) : UE_ARRAY_COUNT(FarsiKeys);
				const int32 KeyIdx = Btn.ButtonID - 600;
				if (KeyIdx >= 0 && KeyIdx < ActiveKeyCount && CustomPlayerNameInput.Len() < 28)
				{
					CustomPlayerNameInput += (bUseEnglishVirtualKeys ? EnglishKeys[KeyIdx] : FarsiKeys[KeyIdx]);
				}
			}
			else if (MenuState == EMainMenuState::NewGameDifficulty && Btn.ButtonID >= 501 && Btn.ButtonID <= 504) // AAA-B2-4: difficulty cards launch only from the difficulty screen; medals stay on 520+.
			{
				const EGameDifficulty Diffs[] = { EGameDifficulty::Easy, EGameDifficulty::Normal, EGameDifficulty::Hard, EGameDifficulty::Lethal };
				const int32 DiffIdx = Btn.ButtonID - 501;
				if (DiffIdx >= 0 && DiffIdx < 4)
				{
					if (UDifficultySubsystem* DiffSys = UDifficultySubsystem::Get(this))
					{
						DiffSys->SetDifficulty(Diffs[DiffIdx]);
					}
				}

				if (USquadAILoadingScreenSubsystem* LoadSys = USquadAILoadingScreenSubsystem::Get(this))
				{
					LoadSys->StartDeploymentTransition(TargetGameplayLevelName, TEXT("Dehlavieh"));
				}
				else
				{
					UGameplayStatics::OpenLevel(this, TargetGameplayLevelName);
				}
			}
			else if (Btn.ButtonID >= 700 && Btn.ButtonID < 710) // Load Save Slot // F-G3: was 600-610 (unreachable — Farsi branch above matched first).
			{
				const int32 SlotIdx = Btn.ButtonID - 700;
				if (USquadAISaveLoadSubsystem* SaveSys = USquadAISaveLoadSubsystem::Get(this))
				{
					SaveSys->LoadGameFromSlot(SlotIdx);
				}
			}
			return;
		}
	}
}

UTexture2D* ASquadAIMainMenuHUD::GetAvatarTexture(FName AvatarID) const
{
	if (AvatarID == FName("ShahidRostami")) return AvatarRostamiTexture;
	if (AvatarID == FName("YoungBasiji")) return AvatarYoungBasijiTexture;
	if (AvatarID == FName("ArteshParatrooper")) return AvatarArteshParatrooperTexture;
	if (AvatarID == FName("GuerrillaHunter")) return AvatarGuerrillaHunterTexture;
	return AvatarRostamiTexture;
}

UTexture2D* ASquadAIMainMenuHUD::GetTraitTexture(FName TraitID) const
{
	const FString S = TraitID.ToString();
	if (S.Contains(TEXT("Tank")) || S.Contains(TEXT("Bunker")) || S.Contains(TEXT("Rocket"))) return TraitTankDestroyerTexture.Get();
	if (S.Contains(TEXT("Heavy")) || S.Contains(TEXT("Caliber")) || S.Contains(TEXT("Precision")) || S.Contains(TEXT("FirstBlood"))) return TraitHeavyCaliberTexture.Get();
	if (S.Contains(TEXT("Desert")) || S.Contains(TEXT("Reliability")) || S.Contains(TEXT("Mobility")) || S.Contains(TEXT("Medic"))) return TraitDesertReliabilityTexture.Get();
	if (S.Contains(TEXT("Area")) || S.Contains(TEXT("Suppression")) || S.Contains(TEXT("MachineGun"))) return TraitAreaSuppressionTexture.Get();
	if (S.Contains(TEXT("Silent")) || S.Contains(TEXT("Marksman")) || S.Contains(TEXT("Sniper"))) return TraitSilentMarksmanTexture.Get();
	if (S.Contains(TEXT("Rostami")) || S.Contains(TEXT("Honor")) || S.Contains(TEXT("Defender"))) return WatermarkEmblemTexture.Get();
	return TraitHeavyCaliberTexture.Get();
}

UTexture2D* ASquadAIMainMenuHUD::GetMapPreviewTexture(FName MapID) const
{
	const FString S = MapID.ToString();
	if (S.Contains(TEXT("Dehlavieh")) || S.Contains(TEXT("Karkheh"))) return MapPreviewDehlaviehTexture.Get();
	if (S.Contains(TEXT("Bostan")) || S.Contains(TEXT("Chazzabeh"))) return MapPreviewBostanTexture.Get();
	if (S.Contains(TEXT("Khorramshahr")) || S.Contains(TEXT("Arvand"))) return MapPreviewKhorramshahrTexture.Get();
	return MapPreviewDehlaviehTexture.Get();
}

UTexture2D* ASquadAIMainMenuHUD::GetWeaponPreviewTexture(FName WeaponID) const
{
	const FString S = WeaponID.ToString();
	if (S.Contains(TEXT("G3"))) return WeaponPreviewG3A3Texture.Get();
	if (S.Contains(TEXT("AK"))) return WeaponPreviewAK47Texture.Get();
	if (S.Contains(TEXT("RPG"))) return WeaponPreviewRPG7Texture.Get();
	if (S.Contains(TEXT("MG3"))) return WeaponPreviewMG3Texture.Get();
	if (S.Contains(TEXT("SVD")) || S.Contains(TEXT("Dragunov"))) return WeaponPreviewSVDTexture.Get();
	return WeaponPreviewG3A3Texture.Get();
}

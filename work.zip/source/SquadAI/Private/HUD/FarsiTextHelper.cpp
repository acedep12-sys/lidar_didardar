// FarsiTextHelper.cpp — Comprehensive Persian Unicode Contextual Shaping, RTL BiDi Reordering & Digit Conversion
#include "HUD/FarsiTextHelper.h"

// Persian digits U+06F0..U+06F9: ۰ ۱ ۲ ۳ ۴ ۵ ۶ ۷ ۸ ۹
static const TCHAR PersianDigits[] = {
	0x06F0, 0x06F1, 0x06F2, 0x06F3, 0x06F4,
	0x06F5, 0x06F6, 0x06F7, 0x06F8, 0x06F9
};

struct FPersianGlyphMapping
{
	TCHAR Base;
	TCHAR Isolated;
	TCHAR Final;
	TCHAR Initial;
	TCHAR Medial;
	bool bRightJoinOnly;
};

static const FPersianGlyphMapping PersianTable[] = {
	// Base, Isolated, Final, Initial, Medial, RightOnly
	{ 0x0622, 0xFE81, 0xFE82, 0xFE81, 0xFE82, true  }, // آ
	{ 0x0627, 0xFE8D, 0xFE8E, 0xFE8D, 0xFE8E, true  }, // ا
	{ 0x0623, 0xFE83, 0xFE84, 0xFE83, 0xFE84, true  }, // أ
	{ 0x0625, 0xFE87, 0xFE88, 0xFE87, 0xFE88, true  }, // إ
	{ 0x0628, 0xFE8F, 0xFE90, 0xFE91, 0xFE92, false }, // ب
	{ 0x067E, 0xFB56, 0xFB57, 0xFB58, 0xFB59, false }, // پ
	{ 0x062A, 0xFE95, 0xFE96, 0xFE97, 0xFE98, false }, // ت
	{ 0x062B, 0xFE99, 0xFE9A, 0xFE9B, 0xFE9C, false }, // ث
	{ 0x062C, 0xFE9D, 0xFE9E, 0xFE9F, 0xFEA0, false }, // ج
	{ 0x0686, 0xFB7A, 0xFB7B, 0xFB7C, 0xFB7D, false }, // چ
	{ 0x062D, 0xFEA1, 0xFEA2, 0xFEA3, 0xFEA4, false }, // ح
	{ 0x062E, 0xFEA5, 0xFEA6, 0xFEA7, 0xFEA8, false }, // خ
	{ 0x062F, 0xFEA9, 0xFEAA, 0xFEA9, 0xFEAA, true  }, // د
	{ 0x0630, 0xFEAB, 0xFEAC, 0xFEAB, 0xFEAC, true  }, // ذ
	{ 0x0631, 0xFEAD, 0xFEAE, 0xFEAD, 0xFEAE, true  }, // ر
	{ 0x0632, 0xFEAF, 0xFEB0, 0xFEAF, 0xFEB0, true  }, // ز
	{ 0x0698, 0xFB8A, 0xFB8B, 0xFB8A, 0xFB8B, true  }, // ژ
	{ 0x0633, 0xFEB1, 0xFEB2, 0xFEB3, 0xFEB4, false }, // س
	{ 0x0634, 0xFEB5, 0xFEB6, 0xFEB7, 0xFEB8, false }, // ش
	{ 0x0635, 0xFEB9, 0xFEBA, 0xFEBB, 0xFEBC, false }, // ص
	{ 0x0636, 0xFEBD, 0xFEBE, 0xFEBF, 0xFEC0, false }, // ض
	{ 0x0637, 0xFEC1, 0xFEC2, 0xFEC3, 0xFEC4, false }, // ط
	{ 0x0638, 0xFEC5, 0xFEC6, 0xFEC7, 0xFEC8, false }, // ظ
	{ 0x0639, 0xFEC9, 0xFECA, 0xFECB, 0xFECC, false }, // ع
	{ 0x063A, 0xFECD, 0xFECE, 0xFECF, 0xFED0, false }, // غ
	{ 0x0641, 0xFED1, 0xFED2, 0xFED3, 0xFED4, false }, // ف
	{ 0x0642, 0xFED5, 0xFED6, 0xFED7, 0xFED8, false }, // ق
	{ 0x06A9, 0xFB8E, 0xFB8F, 0xFB90, 0xFB91, false }, // ک (Persian Kaf)
	{ 0x0643, 0xFED9, 0xFEDA, 0xFEDB, 0xFEDC, false }, // ك (Arabic Kaf)
	{ 0x06AF, 0xFB92, 0xFB93, 0xFB94, 0xFB95, false }, // گ
	{ 0x0644, 0xFEDD, 0xFEDE, 0xFEDF, 0xFEE0, false }, // ل
	{ 0x0645, 0xFEE1, 0xFEE2, 0xFEE3, 0xFEE4, false }, // م
	{ 0x0646, 0xFEE5, 0xFEE6, 0xFEE7, 0xFEE8, false }, // ن
	{ 0x0648, 0xFEED, 0xFEEE, 0xFEED, 0xFEEE, true  }, // و
	{ 0x0624, 0xFE85, 0xFE86, 0xFE85, 0xFE86, true  }, // ؤ
	{ 0x0647, 0xFEE9, 0xFEEA, 0xFEEB, 0xFEEC, false }, // ه
	{ 0x06C0, 0x06C0, 0xFBA5, 0x06C0, 0xFBA5, true  }, // ه (Heh with Yeh/Hamza above)
	{ 0x0629, 0xFE93, 0xFE94, 0xFE93, 0xFE94, true  }, // ة
	{ 0x06CC, 0xFBFC, 0xFBFD, 0xFBFE, 0xFBFF, false }, // ی (Persian Ye)
	{ 0x064A, 0xFEF1, 0xFEF2, 0xFEF3, 0xFEF4, false }, // ي (Arabic Ye)
	{ 0x0649, 0xFEEF, 0xFEF0, 0xFEEF, 0xFEF0, true  }, // ى
	{ 0x0626, 0xFE89, 0xFE8A, 0xFE8B, 0xFE8C, false }  // ئ
};

static const FPersianGlyphMapping* FindGlyph(TCHAR Ch)
{
	for (const auto& M : PersianTable)
	{
		if (M.Base == Ch) return &M;
	}
	return nullptr;
}

static bool CanJoinLeft(TCHAR Ch)
{
	const FPersianGlyphMapping* M = FindGlyph(Ch);
	return M && !M->bRightJoinOnly;
}

static bool CanJoinRight(TCHAR Ch)
{
	return FindGlyph(Ch) != nullptr;
}

static bool IsRTLChar(TCHAR Ch)
{
	// P1-L1: digit runs are LTR (Persian/Arabic-Indic digits were reversed inside RTL lines).
	if ((Ch >= 0x0660 && Ch <= 0x0669) || (Ch >= 0x06F0 && Ch <= 0x06F9)) return false;
	return Ch == 0x200C ||
		   (Ch >= 0x0600 && Ch <= 0x06FF) ||
		   (Ch >= 0xFB50 && Ch <= 0xFDFF) ||
		   (Ch >= 0xFE70 && Ch <= 0xFEFC);
}

static bool IsLTRChar(TCHAR Ch)
{
	return (Ch >= TEXT('a') && Ch <= TEXT('z')) ||
		   (Ch >= TEXT('A') && Ch <= TEXT('Z')) ||
		   (Ch >= TEXT('0') && Ch <= TEXT('9')) ||
		   (Ch >= 0x0660 && Ch <= 0x0669) || // Arabic-Indic digits (P1-L1: stay forward)
		   (Ch >= 0x06F0 && Ch <= 0x06F9);   // Persian digits (P1-L1: stay forward)
}

static bool IsDigitChar(TCHAR Ch)
{
	return (Ch >= TEXT('0') && Ch <= TEXT('9')) ||
		   (Ch >= 0x0660 && Ch <= 0x0669) || (Ch >= 0x06F0 && Ch <= 0x06F9);
}

static bool IsNumberSeparator(TCHAR Ch)
{
	return Ch == TEXT(':') || Ch == TEXT('/') || Ch == TEXT('.') || Ch == TEXT(',') || Ch == TEXT('%') ||
		   Ch == 0x060C || Ch == 0x066A || Ch == 0x066B || Ch == 0x066C; // ، ٪ ٫ ٬
}

FString UFarsiTextHelper::ToPersianDigits(const FString& Input)
{
	FString Result = Input;
	for (int32 i = 0; i < Result.Len(); ++i)
	{
		const TCHAR Ch = Result[i];
		if (Ch >= TEXT('0') && Ch <= TEXT('9'))
		{
			Result[i] = PersianDigits[Ch - TEXT('0')];
		}
	}
	return Result;
}

FString UFarsiTextHelper::IntToPersian(int32 Value)
{
	return ToPersianDigits(FString::FromInt(Value));
}

FString UFarsiTextHelper::FormatTimerPersian(float TotalSeconds)
{
	const int32 Min = FMath::FloorToInt(TotalSeconds / 60.f);
	const int32 Sec = FMath::FloorToInt(FMath::Fmod(TotalSeconds, 60.f));
	return ToPersianDigits(FString::Printf(TEXT("%d:%02d"), Min, Sec));
}

FText UFarsiTextHelper::FormatWavePersian(int32 Current, int32 Total)
{
	return FText::FromString(FString::Printf(
		TEXT("موج %s از %s"),
		*IntToPersian(Current), *IntToPersian(Total)));
}

FText UFarsiTextHelper::FormatKillsPersian(int32 Kills)
{
	return FText::FromString(FString::Printf(
		TEXT("شکار دشمن: %s"), *IntToPersian(Kills)));
}

FText UFarsiTextHelper::FormatRemainingPersian(int32 Remaining)
{
	return FText::FromString(FString::Printf(
		TEXT("باقی‌مانده: %s"),
		*IntToPersian(Remaining)));
}

FString UFarsiTextHelper::GetPersianCardinal(float YawDegrees)
{
	float Y = FMath::Fmod(YawDegrees + 360.f, 360.f);
	if (Y >= 337.5f || Y < 22.5f)   return TEXT("شمال");
	if (Y < 67.5f)                    return TEXT("شمال‌شرق");
	if (Y < 112.5f)                   return TEXT("شرق");
	if (Y < 157.5f)                   return TEXT("جنوب‌شرق");
	if (Y < 202.5f)                   return TEXT("جنوب");
	if (Y < 247.5f)                   return TEXT("جنوب‌غرب");
	if (Y < 292.5f)                   return TEXT("غرب");
	return TEXT("شمال‌غرب");
}

FString UFarsiTextHelper::WrapRTL(const FString& Input)
{
	return FString::Printf(TEXT("\x202B%s\x202C"), *Input);
}

static bool IsTashkeel(TCHAR C) { return (C >= 0x064B && C <= 0x065F) || C == 0x0670; }

// Nearest shaping-relevant neighbor (skips tashkeel ONLY).
// P7-L3: ZWNJ (0x200C) is NOT skipped — it is a join BOUNDARY. The old code treated it
// as transparent, so "جبهه‌ها" joined across the ZWNJ and rendered merged ("جبههها").
static int32 PrevShapeIndex(const FString& S, int32 i)
{
	for (int32 k = i - 1; k >= 0; --k) { if (!IsTashkeel(S[k])) return k; }
	return INDEX_NONE;
}
static int32 NextShapeIndex(const FString& S, int32 i)
{
	for (int32 k = i + 1; k < S.Len(); ++k) { if (!IsTashkeel(S[k])) return k; }
	return INDEX_NONE;
}

FString UFarsiTextHelper::ShapeFarsi(const FString& Input)
{
	if (Input.IsEmpty()) return Input;

	// Normalize Heh + Hamza above (ه: 0x0647 + 0x0654) and ه (0x06C0) to standard Heh (0x0647)
	// so UCanvas::DrawText always uses standard Heh presentation forms (0xFEE9/0xFEEA) and never hits a missing glyph.
	FString Normalized = Input;
	Normalized.ReplaceInline(TEXT("\x0647\x0654"), TEXT("\x0647"), ESearchCase::CaseSensitive);
	Normalized.ReplaceInline(TEXT("\x06C0"), TEXT("\x0647"), ESearchCase::CaseSensitive);

	// P1-L1: tashkeel/diacritics (0x064B..0x065F, 0x0670) are PRESERVED (Quranic text keeps
	// meaning) and transparent to joining — see PrevShapeIndex/NextShapeIndex.
	const FString& CleanInput = Normalized;

	FString Output;
	Output.Reserve(CleanInput.Len());

	const int32 N = CleanInput.Len();
	int32 i = 0;

	while (i < N)
	{
		const TCHAR Ch = CleanInput[i];

		// Handle Zero-Width Non-Joiner (ZWNJ: U+200C):
		// CleanInput retains 0x200C so PrevShapeIndex / NextShapeIndex treat it as a hard non-joining
		// boundary (selecting Isolated/Final before 0x200C and Initial/Isolated after 0x200C).
		// Do NOT emit 0x200C into Output because Output already contains explicit presentation forms
		// (0xFB50..0xFEFC) and UCanvas::DrawText renders a .notdef box for U+200C in bitmap/runtime fonts.
		if (Ch == 0x200C)
		{
			i++;
			continue;
		}

		// Handle Lam-Alef Ligatures (لا, لأ, لإ, لآ)
		if (Ch == 0x0644 && i + 1 < N)
		{
			const TCHAR NextCh = CleanInput[i + 1];
			const int32 PrevSI = PrevShapeIndex(CleanInput, i);
		const bool bPrevJoins = (PrevSI != INDEX_NONE && CanJoinLeft(CleanInput[PrevSI]));

			TCHAR LamAlefIso = 0;
			TCHAR LamAlefFin = 0;

			if (NextCh == 0x0622) { LamAlefIso = 0xFEF5; LamAlefFin = 0xFEF6; } // لآ
			else if (NextCh == 0x0623) { LamAlefIso = 0xFEF7; LamAlefFin = 0xFEF8; } // لأ
			else if (NextCh == 0x0625) { LamAlefIso = 0xFEF9; LamAlefFin = 0xFEFA; } // لإ
			else if (NextCh == 0x0627) { LamAlefIso = 0xFEFB; LamAlefFin = 0xFEFC; } // لا

			if (LamAlefIso != 0)
			{
				Output.AppendChar(bPrevJoins ? LamAlefFin : LamAlefIso);
				i += 2;
				continue;
			}
		}

		if (const FPersianGlyphMapping* M = FindGlyph(Ch))
		{
			const int32 PrevSI = PrevShapeIndex(CleanInput, i);
		const bool bPrevJoins = (PrevSI != INDEX_NONE && CanJoinLeft(CleanInput[PrevSI]));
			const int32 NextSI = NextShapeIndex(CleanInput, i);
		const bool bNextJoins = (NextSI != INDEX_NONE && CanJoinRight(CleanInput[NextSI]));

			if (!bPrevJoins && !bNextJoins)
			{
				Output.AppendChar(M->Isolated);
			}
			else if (bPrevJoins && !bNextJoins)
			{
				Output.AppendChar(M->Final);
			}
			else if (!bPrevJoins && bNextJoins)
			{
				Output.AppendChar(M->Initial);
			}
			else
			{
				Output.AppendChar(M->Medial);
			}
		}
		else
		{
			Output.AppendChar(Ch);
		}

		i++;
	}

	return Output;
}

FString UFarsiTextHelper::ReorderBiDi(const FString& Input)
{
	if (Input.IsEmpty()) return Input;

	// Split by newline and process each line independently
	TArray<FString> Lines;
	Input.ParseIntoArrayLines(Lines, false);

	if (Lines.Num() == 0) return Input;

	FString Result;
	for (int32 LineIdx = 0; LineIdx < Lines.Num(); ++LineIdx)
	{
		const FString& Line = Lines[LineIdx];
		if (Line.IsEmpty())
		{
			if (LineIdx > 0) Result += TEXT("\n");
			continue;
		}

		enum class ETokenType { RTL, LTR, Neutral };
		struct FToken
		{
			ETokenType Type;
			FString Text;
		};

		TArray<FToken> Tokens;
		FToken Cur;
		Cur.Type = ETokenType::Neutral;

		for (int32 c = 0; c < Line.Len(); ++c)
		{
			const TCHAR Ch = Line[c];
			ETokenType T = IsRTLChar(Ch) ? ETokenType::RTL :
						   IsLTRChar(Ch) ? ETokenType::LTR : ETokenType::Neutral;
			// P1-L1: separators between digits join the number run (12:34, 100%, ۵.۵۶ stay intact),
			// and multiplication sign × (0x00D7) adjacent to a digit (۴×, ×۲) stays attached to the number.
			if (T == ETokenType::Neutral && IsNumberSeparator(Ch) && c > 0 && c + 1 < Line.Len()
				&& IsDigitChar(Line[c - 1]) && IsDigitChar(Line[c + 1]))
			{
				T = ETokenType::LTR;
			}
			else if (T == ETokenType::Neutral && Ch == 0x00D7
				&& ((c > 0 && IsDigitChar(Line[c - 1])) || (c + 1 < Line.Len() && IsDigitChar(Line[c + 1]))))
			{
				T = ETokenType::LTR;
			}

			if (Cur.Text.IsEmpty())
			{
				Cur.Type = T;
				Cur.Text.AppendChar(Ch);
			}
			else if (Cur.Type == T)
			{
				Cur.Text.AppendChar(Ch);
			}
			else
			{
				Tokens.Add(Cur);
				Cur.Type = T;
				Cur.Text.Empty();
				Cur.Text.AppendChar(Ch);
			}
		}
		if (!Cur.Text.IsEmpty())
		{
			Tokens.Add(Cur);
		}

		// If no RTL characters in line, keep line unchanged
		bool bHasRTL = false;
		for (const auto& Tok : Tokens)
		{
			if (Tok.Type == ETokenType::RTL)
			{
				bHasRTL = true;
				break;
			}
		}

		if (!bHasRTL)
		{
			if (LineIdx > 0) Result += TEXT("\n");
			Result += Line;
			continue;
		}

		// Reorder RTL line
		FString ReorderedLine;
		for (int32 t = Tokens.Num() - 1; t >= 0; --t)
		{
			const FToken& Tok = Tokens[t];
			if (Tok.Type == ETokenType::RTL)
			{
				// Reverse characters in RTL token
				FString Rev = Tok.Text;
				const int32 Len = Rev.Len();
				for (int32 k = 0; k < Len / 2; ++k)
				{
					Swap(Rev[k], Rev[Len - 1 - k]);
				}
				ReorderedLine += Rev;
			}
			else if (Tok.Type == ETokenType::Neutral)
			{
				// Mirror punctuation brackets and reverse string
				FString Rev = Tok.Text;
				const int32 Len = Rev.Len();
				for (int32 k = 0; k < Len / 2; ++k)
				{
					Swap(Rev[k], Rev[Len - 1 - k]);
				}
				for (int32 k = 0; k < Rev.Len(); ++k)
				{
					if (Rev[k] == TEXT('(')) Rev[k] = TEXT(')');
					else if (Rev[k] == TEXT(')')) Rev[k] = TEXT('(');
					else if (Rev[k] == TEXT('[')) Rev[k] = TEXT(']');
					else if (Rev[k] == TEXT(']')) Rev[k] = TEXT('[');
					else if (Rev[k] == TEXT('{')) Rev[k] = TEXT('}');
					else if (Rev[k] == TEXT('}')) Rev[k] = TEXT('{');
					else if (Rev[k] == TEXT('<')) Rev[k] = TEXT('>');
					else if (Rev[k] == TEXT('>')) Rev[k] = TEXT('<');
					else if (Rev[k] == 0x00AB) Rev[k] = 0x00BB; // « »
					else if (Rev[k] == 0x00BB) Rev[k] = 0x00AB;
					else if (Rev[k] == 0x2039) Rev[k] = 0x203A; // ‹ ›
					else if (Rev[k] == 0x203A) Rev[k] = 0x2039;
					else if (Rev[k] == 0x25BA) Rev[k] = 0x25C4; // ► ◄
					else if (Rev[k] == 0x25C4) Rev[k] = 0x25BA;
					else if (Rev[k] == 0x2192) Rev[k] = 0x2190; // → ←
					else if (Rev[k] == 0x2190) Rev[k] = 0x2192;
				}
				ReorderedLine += Rev;
			}
			else
			{
				// LTR numbers and English words remain forward
				ReorderedLine += Tok.Text;
			}
		}

		if (LineIdx > 0) Result += TEXT("\n");
		Result += ReorderedLine;
	}

	return Result;
}

FString UFarsiTextHelper::ShapeAndOrder(const FString& Input)
{
	if (Input.IsEmpty()) return Input;
	const FString Shaped = ShapeFarsi(Input);
	return ReorderBiDi(Shaped);
}

#include "HUD/SquadAILoadingScreenWidget.h"
#include "Performance/SquadAILoadingScreenSubsystem.h"
#include "Sound/SoundBase.h"
#include "Kismet/GameplayStatics.h"
#include "HAL/PlatformTime.h"

void USquadAILoadingScreenWidget::NativeConstruct()
{
	Super::NativeConstruct();
	RadarSweepAngle = 0.0f;
	SimulatedProgress = 0.0f;
	bIsReadyToDeploy = false;
	PromptPulseAlpha = 1.0f;
	TipTimer = 0.0f;
}

void USquadAILoadingScreenWidget::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	Super::NativeTick(MyGeometry, InDeltaTime);

	// 1. Rotate tactical radar sweep 240 deg/s
	RadarSweepAngle = FMath::Fmod(RadarSweepAngle + (InDeltaTime * 240.0f), 360.0f);

	// 2. Simulated progress advance
	if (!bIsReadyToDeploy)
	{
		if (SimulatedProgress < 0.92f)
		{
			SimulatedProgress += InDeltaTime * 0.35f;
		}
	}
	else
	{
		SimulatedProgress = 1.0f;
	}

	// 3. Flashing deploy prompt pulse & Enter / Space Key Listener
	if (bIsReadyToDeploy)
	{
		PulseTimer += InDeltaTime * 4.0f;
		PromptPulseAlpha = 0.5f + 0.5f * FMath::Sin(PulseTimer);

		if (bRequirePlayerInputToDeploy)
		{
			if (APlayerController* PC = GetOwningPlayer())
			{
				if (PC->WasInputKeyJustPressed(EKeys::Enter) ||
					PC->WasInputKeyJustPressed(EKeys::SpaceBar) ||
					PC->WasInputKeyJustPressed(EKeys::Gamepad_FaceButton_Bottom) ||
					PC->WasInputKeyJustPressed(EKeys::LeftMouseButton))
				{
					OnDeployClicked();
				}
			}
		}
	}

	// 4. Rotating combat tips every 6 seconds. NativeTick may throttle near-zero while
	// a heavyweight streaming frame stalls; guard the cadence with wall time so the user
	// always sees their localized tips rolling during long loads.
	TipTimer += InDeltaTime;
	const double WallNow = FPlatformTime::Seconds();
	if (TipTimer >= 6.0f || (WallNow - LastTipWallTime) >= 7.0)
	{
		TipTimer = 0.0f;
		LastTipWallTime = WallNow;
		if (USquadAILoadingScreenSubsystem* LoadingSys = USquadAILoadingScreenSubsystem::Get(this))
		{
			CombatTipText = LoadingSys->GetRandomTacticalTip();
		}
	}
}

void USquadAILoadingScreenWidget::SetLoadingContent(const FText& InSectorTitle, const FText& InMissionBriefing, const FText& InCombatTip)
{
	SectorTitleText = InSectorTitle;
	MissionBriefingText = InMissionBriefing;
	CombatTipText = InCombatTip;
}

void USquadAILoadingScreenWidget::MarkLoadingComplete()
{
	bIsReadyToDeploy = true;
	SimulatedProgress = 1.0f;

	if (!bRequirePlayerInputToDeploy)
	{
		// Auto-dismiss after brief 0.5s pause
		if (UWorld* World = GetWorld())
		{
			FTimerHandle DismissHandle;
			TWeakObjectPtr<USquadAILoadingScreenWidget> WeakThis(this);
			World->GetTimerManager().SetTimer(DismissHandle, [WeakThis]()
			{
				if (WeakThis.IsValid())
				{
					WeakThis->OnDeployClicked();
				}
			}, 0.5f, false);
		}
	}
}

void USquadAILoadingScreenWidget::OnDeployClicked()
{
	if (DeployConfirmationSound)
	{
		UGameplayStatics::PlaySound2D(this, DeployConfirmationSound);
	}

	if (USquadAILoadingScreenSubsystem* LoadingSys = USquadAILoadingScreenSubsystem::Get(this))
	{
		LoadingSys->HideLoadingScreen(0.8f);
	}
	else
	{
		RemoveFromParent();
	}
}

#include "HUD/QuestCompletionWidget.h"
#include "Quest/QuestChain.h"
#include "Quest/MissionZone.h"
#include "Components/TextBlock.h"
#include "Components/Image.h"
#include "Components/Widget.h"
#include "SquadAITuning.h"
#include "EngineUtils.h"

void UQuestCompletionWidget::NativeConstruct()
{
	Super::NativeConstruct();
	SetVisibility(ESlateVisibility::Collapsed);
	AnimState = EAnimState::Hidden;
}

void UQuestCompletionWidget::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	Super::NativeTick(MyGeometry, InDeltaTime);

	if (AnimState == EAnimState::Hidden) return;

	AnimTimer += InDeltaTime;

	switch (AnimState)
	{
	case EAnimState::ZoomIn:
	{
		const float Alpha = FMath::Clamp(AnimTimer / ZoomInDuration, 0.f, 1.f);
		const float Eased = FMath::InterpEaseOut(0.f, 1.f, Alpha, 2.f);
		ApplyZoomIn(Eased);
		if (Alpha >= 1.f)
		{
			// Read hold duration from SquadAITuning
			const USquadAITuning* T = USquadAITuning::Get();
			const float HoldDur = (T && T->MissionCompletionDisplaySeconds > 0.f) ? T->MissionCompletionDisplaySeconds : 3.0f;
			AnimTimer = 0.f;
			AnimState = EAnimState::Holding;
			// Store actual hold duration
			HoldDuration = HoldDur;
		}
		break;
	}
	case EAnimState::Holding:
	{
		if (AnimTimer >= HoldDuration)
		{
			AnimTimer = 0.f;
			AnimState = EAnimState::FlyOut;
		}
		break;
	}
	case EAnimState::FlyOut:
	{
		const float Alpha = FMath::Clamp(AnimTimer / FlyOutDuration, 0.f, 1.f);
		const float Eased = FMath::InterpEaseIn(0.f, 1.f, Alpha, 2.f);
		ApplyFlyOut(Eased);
		if (Alpha >= 1.f)
		{
			HideMessage();
		}
		break;
	}
	default:
		break;
	}
}

void UQuestCompletionWidget::ShowCompletionMessage(const FText& Message)
{
	if (CompletionText)
	{
		CompletionText->SetText(Message);
	}

	// Set background image from SquadAITuning
	if (BackgroundImage)
	{
		const USquadAITuning* T = USquadAITuning::Get();
		if (T && T->MissionCompletionBackground)
		{
			BackgroundImage->SetBrushFromTexture(T->MissionCompletionBackground);
		}
	}

	SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	AnimTimer = 0.f;
	AnimState = EAnimState::ZoomIn;
	ApplyZoomIn(0.f);
}

void UQuestCompletionWidget::HideMessage()
{
	SetVisibility(ESlateVisibility::Collapsed);
	AnimState = EAnimState::Hidden;
	AnimTimer = 0.f;

	// Reset transform
	SetRenderOpacity(1.f);
	FWidgetTransform T;
	SetRenderTransform(T);
}

void UQuestCompletionWidget::SetQuestChain(AQuestChain* Chain)
{
	if (ActiveChain)
	{
		// Unbind old chain
		for (AMissionZone* M : ActiveChain->Missions)
		{
			if (M) M->OnMissionStateChanged.RemoveDynamic(this, &UQuestCompletionWidget::HandleMissionStateChanged);
		}
	}

	ActiveChain = Chain;

	if (ActiveChain)
	{
		for (AMissionZone* M : ActiveChain->Missions)
		{
			if (M) M->OnMissionStateChanged.AddDynamic(this, &UQuestCompletionWidget::HandleMissionStateChanged);
		}
	}
}

void UQuestCompletionWidget::NativeDestruct()
{
	// MEGA-5 (H-2): SetQuestChain unbinds on swap but nothing unbound on destroy —
	// a late mission-state broadcast would hit a dead widget.
	if (ActiveChain)
	{
		for (AMissionZone* M : ActiveChain->Missions)
		{
			if (M) M->OnMissionStateChanged.RemoveDynamic(this, &UQuestCompletionWidget::HandleMissionStateChanged);
		}
		ActiveChain = nullptr;
	}
	Super::NativeDestruct();
}

void UQuestCompletionWidget::HandleMissionStateChanged(AMissionZone* Mission, EMissionZoneState NewState)
{
	if (!Mission) return;
	if (NewState == EMissionZoneState::Completed)
	{
		const USquadAITuning* T = USquadAITuning::Get();
		FString Msg = (T && !T->MissionCompletionMessage.IsEmpty()) ? T->MissionCompletionMessage : TEXT("MISSION COMPLETE");
		ShowCompletionMessage(FText::FromString(Msg));
	}
}

void UQuestCompletionWidget::ApplyZoomIn(float Alpha)
{
	// Scale from 0.3 to 1.0
	const float Scale = FMath::Lerp(0.3f, 1.f, Alpha);
	FWidgetTransform Transform;
	Transform.Scale = FVector2D(Scale, Scale);
	SetRenderTransform(Transform);
	SetRenderOpacity(Alpha);
}

void UQuestCompletionWidget::ApplyFlyOut(float Alpha)
{
	// Move up and fade out
	const float OffsetY = FMath::Lerp(0.f, -300.f, Alpha);
	FWidgetTransform Transform;
	Transform.Translation = FVector2D(0.f, OffsetY);
	SetRenderTransform(Transform);
	SetRenderOpacity(1.f - Alpha);
}


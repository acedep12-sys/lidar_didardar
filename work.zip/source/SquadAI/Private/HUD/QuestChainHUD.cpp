// QuestChainHUD.cpp — UMG widget for quest chain progress display
#include "HUD/QuestChainHUD.h"
#include "Quest/QuestChain.h"
#include "Quest/MissionZone.h"
#include "Kismet/GameplayStatics.h"
#include "GameFramework/Pawn.h"

void UQuestChainHUD::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	Super::NativeTick(MyGeometry, InDeltaTime);

	// FIX: Only refresh at 0.5s interval instead of every frame
	TimeSinceRefresh += InDeltaTime;
	if (TimeSinceRefresh >= 0.5f)
	{
		TimeSinceRefresh = 0.f;
		RefreshData();
	}
}

void UQuestChainHUD::SetQuestChain(AQuestChain* Chain)
{
	ActiveChain = Chain;
	MissionChecklist.Empty(); // Force rebuild on chain change
	RefreshData();
}

void UQuestChainHUD::RefreshData()
{
	if (!ActiveChain || !ActiveChain->IsValidLowLevel())
	{
		if (MissionChecklist.Num() > 0)
		{
			CurrentQuestDescription = FText::FromString(TEXT(""));
			MissionChecklist.Empty();
			bShowDefendTimer = false;
			bShowQuestMarker = false;
		}
		return;
	}

	CurrentQuestDescription = ActiveChain->GetCurrentMissionDescription();
	OverallProgress = ActiveChain->GetOverallProgress();
	CurrentMissionIndex = ActiveChain->CurrentMissionIndex;
	TotalMissions = ActiveChain->GetTotalMissions();

	BuildMissionChecklist();
	UpdateDefendTimer();
	UpdateNavigation();
}

void UQuestChainHUD::BuildMissionChecklist()
{
	if (!ActiveChain) return;

	// FIX: Only rebuild if mission count changed
	if (MissionChecklist.Num() != ActiveChain->Missions.Num())
	{
		MissionChecklist.Empty();
		MissionChecklist.Reserve(ActiveChain->Missions.Num());

		for (int32 i = 0; i < ActiveChain->Missions.Num(); ++i)
		{
			AMissionZone* Mission = ActiveChain->Missions[i];
			if (!Mission) continue;

			FQuestMissionHUDData Data;
			Data.Description = Mission->MissionDescription;
			Data.Type = Mission->MissionType;
			Data.State = Mission->MissionState;
			Data.Progress = Mission->MissionProgress;
			Data.bIsCurrent = (i == ActiveChain->CurrentMissionIndex);

			MissionChecklist.Add(Data);
		}
	}
	else
	{
		// Update existing entries in-place
		for (int32 i = 0; i < ActiveChain->Missions.Num(); ++i)
		{
			AMissionZone* Mission = ActiveChain->Missions[i];
			if (!Mission || !MissionChecklist.IsValidIndex(i)) continue;

			MissionChecklist[i].State = Mission->MissionState;
			MissionChecklist[i].Progress = Mission->MissionProgress;
			MissionChecklist[i].bIsCurrent = (i == ActiveChain->CurrentMissionIndex);
		}
	}
}

void UQuestChainHUD::UpdateDefendTimer()
{
	bShowDefendTimer = false;

	if (!ActiveChain) return;
	AMissionZone* Current = ActiveChain->GetCurrentMission();
	if (!Current) return;

	if (Current->MissionType == EMissionType::Defend && Current->IsActive())
	{
		bShowDefendTimer = true;
		DefendTimeRemaining = Current->DefendTimeRemaining;
		DefendDuration = Current->DefendDuration;
		DefendProgress = Current->MissionProgress;
	}
}

void UQuestChainHUD::UpdateNavigation()
{
	bShowQuestMarker = false;
	QuestDirection = FVector::ZeroVector;
	QuestDistance = 0.f;

	if (!ActiveChain) return;
	AMissionZone* Current = ActiveChain->GetCurrentMission();
	if (!Current) return;

	UWorld* World = GetWorld();
	if (!World) return;

	APawn* Player = UGameplayStatics::GetPlayerPawn(World, 0);
	if (!Player) return;

	const FVector PlayerLoc = Player->GetActorLocation();
	const FVector ZoneLoc = Current->GetActorLocation();
	const FVector ToZone = ZoneLoc - PlayerLoc;

	QuestDistance = ToZone.Size();
	if (QuestDistance > 100.f)
	{
		QuestDirection = ToZone.GetSafeNormal();
		bShowQuestMarker = true;
	}
}

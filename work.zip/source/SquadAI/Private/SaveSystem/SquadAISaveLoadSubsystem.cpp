#include "SaveSystem/SquadAISaveLoadSubsystem.h"
#include "SaveSystem/SquadAISaveGame.h"
#include "Characters/SoldierCharacter.h"
#include "Characters/LeaderCharacter.h"
#include "Characters/AllySoldier.h"
#include "Components/HealthComponent.h"
#include "Components/WeaponComponent.h"
#include "Quest/QuestChain.h"
#include "Quest/MissionZone.h"
#include "Performance/DifficultySubsystem.h"
#include "Performance/SquadAIAudioSubsystem.h"
#include "Localization/SquadAILocalizationSubsystem.h"
#include "Camera/PlayerCameraManager.h"
#include "Performance/SquadAILoadingScreenSubsystem.h"
#include "GameFramework/SquadAIProgressionSubsystem.h"
#include "GameFramework/SquadAIInventorySubsystem.h"
#include "Components/TacticalGrenadeComponent.h"
#include "Containers/Ticker.h"
#include "Kismet/GameplayStatics.h"
#include "GameFramework/GameUserSettings.h"
#include "HAL/IConsoleManager.h"
#include "Engine/World.h"
#include "Engine/GameInstance.h"
#include "Engine/Engine.h"
#include "EngineUtils.h"

namespace
{
	static FString SquadAISaveSlotDisplayTextForLanguage(const FString& In, bool bEnglish)
	{
		FString Out = In;
		if (!bEnglish) return Out;
		// Full saved titles first, then smaller component words.
		Out.ReplaceInline(TEXT("محور دهلاویه و کرخه - خط مقدم"), TEXT("Dehlavieh and Karkheh Frontline"));
		Out.ReplaceInline(TEXT("محور دهلاویه و کرخه"), TEXT("Dehlavieh and Karkheh Axis"));
		Out.ReplaceInline(TEXT("پیشروی در سنگرهای دهلاویه"), TEXT("Advance through the Dehlavieh trenches"));
		Out.ReplaceInline(TEXT("پیشروی در سنگرهای خط مقدم"), TEXT("Advance through the frontline trenches"));
		Out.ReplaceInline(TEXT("سنگرهای دهلاویه"), TEXT("Dehlavieh trenches"));
		Out.ReplaceInline(TEXT("موقعیت ذخیره شماره"), TEXT("Save Slot"));
		Out.ReplaceInline(TEXT("ذخیره خودکار"), TEXT("Autosave"));
		Out.ReplaceInline(TEXT("خط مقدم"), TEXT("Frontline"));
		Out.ReplaceInline(TEXT("دهلاویه"), TEXT("Dehlavieh"));
		Out.ReplaceInline(TEXT("کرخه"), TEXT("Karkheh"));
		Out.ReplaceInline(TEXT("خوزستان"), TEXT("Khuzestan"));
		return Out;
	}
}

void USquadAISaveLoadSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
	// Load user settings on game startup and apply to engine
	const FSquadGameSettingsSaveData Settings = LoadSettings();
	ApplySettingsToEngine(Settings);
	UE_LOG(LogTemp, Log, TEXT("[SquadAISaveLoad] Initialized Save/Load Subsystem & loaded settings profile"));
}

void USquadAISaveLoadSubsystem::SchedulePostTravelApply(const FString& TargetMapName)
{
	// B6-12 root cause: with bTransitionToMap, ApplySaveDataToWorld was never called after
	// the new world loaded (it only ran in the no-travel path), so loads silently did
	// nothing. Poll on a core ticker until the destination world is live, then apply once.
	FTSTicker::GetCoreTicker().RemoveTicker(PostTravelApplyHandle);
	PendingApplyMapName = TargetMapName;
	PendingApplyElapsed = 0.f;
	TWeakObjectPtr<USquadAISaveLoadSubsystem> WeakSelf(this);
	PostTravelApplyHandle = FTSTicker::GetCoreTicker().AddTicker(
		FTickerDelegate::CreateLambda([WeakSelf](float DeltaTime) -> bool
		{
			USquadAISaveLoadSubsystem* Self = WeakSelf.Get();
			if (!Self || !Self->CurrentLoadedSave) return false;
			Self->PendingApplyElapsed += DeltaTime;
			UWorld* World = Self->GetWorld();
			const FString WorldName = World ? World->GetMapName() : FString();
			if (World && World->HasBegunPlay() && WorldName.Contains(Self->PendingApplyMapName))
			{
				Self->ApplySaveDataToWorld(World);
				UE_LOG(LogTemp, Log, TEXT("[SquadAISaveLoad] Post-travel apply complete on '%s'"), *WorldName);
				return false;
			}
			if (Self->PendingApplyElapsed > 30.f)
			{
				UE_LOG(LogTemp, Error, TEXT("[SquadAISaveLoad] Post-travel apply TIMED OUT waiting for '%s'"), *Self->PendingApplyMapName);
				return false;
			}
			return true;
		}), 0.25f);
}

void USquadAISaveLoadSubsystem::Deinitialize()
{
	FTSTicker::GetCoreTicker().RemoveTicker(PostTravelApplyHandle);
	Super::Deinitialize();
}

USquadAISaveLoadSubsystem* USquadAISaveLoadSubsystem::Get(const UObject* WorldContextObject)
{
	if (!WorldContextObject) return nullptr;
	UGameInstance* GI = UGameplayStatics::GetGameInstance(WorldContextObject);
	return GI ? GI->GetSubsystem<USquadAISaveLoadSubsystem>() : nullptr;
}

bool USquadAISaveLoadSubsystem::SaveGame(const FString& SlotName)
{
	UWorld* World = GetWorld();
	if (!World) return false;

	USquadAISaveGame* SaveObj = Cast<USquadAISaveGame>(UGameplayStatics::CreateSaveGameObject(USquadAISaveGame::StaticClass()));
	if (!SaveObj) return false;

	SaveObj->SlotName = SlotName;
	SaveObj->Timestamp = FDateTime::Now();
	SaveObj->MapName = World->GetMapName();
	SaveObj->MapName.RemoveFromStart(World->StreamingLevelsPrefix);

	GatherWorldDataIntoSave(SaveObj, World);

	const bool bSuccess = UGameplayStatics::SaveGameToSlot(SaveObj, SlotName, 0);
	if (bSuccess)
	{
		CurrentLoadedSave = SaveObj;
		bMostRecentCacheValid = false;
		UE_LOG(LogTemp, Log, TEXT("[SquadAISaveLoad] Successfully saved game to slot '%s' (Map: %s, Mission: %s)"),
			*SlotName, *SaveObj->MapName, *SaveObj->ActiveMissionTitle.ToString());
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("[SquadAISaveLoad] Failed to save game to slot '%s'"), *SlotName);
	}

	OnSaveCompleted.Broadcast(bSuccess);
	return bSuccess;
}

bool USquadAISaveLoadSubsystem::LoadGame(const FString& SlotName, bool bTransitionToMap)
{
	if (!UGameplayStatics::DoesSaveGameExist(SlotName, 0))
	{
		UE_LOG(LogTemp, Warning, TEXT("[SquadAISaveLoad] Save slot '%s' does not exist"), *SlotName);
		OnLoadCompleted.Broadcast(false);
		return false;
	}

	USquadAISaveGame* Loaded = Cast<USquadAISaveGame>(UGameplayStatics::LoadGameFromSlot(SlotName, 0));
	if (!Loaded)
	{
		UE_LOG(LogTemp, Error, TEXT("[SquadAISaveLoad] Failed to deserialize save slot '%s'"), *SlotName);
		OnLoadCompleted.Broadcast(false);
		return false;
	}

	CurrentLoadedSave = Loaded;
	bEnteredLevelFromLoad = true; // S18-INTRO2: the HUD suppresses the opening stamp

	if (bTransitionToMap)
	{
		UWorld* World = GetWorld();
		if (USquadAILoadingScreenSubsystem* Loading = USquadAILoadingScreenSubsystem::Get(World))
		{
				const USquadAILocalizationSubsystem* LocForLoad = GetGameInstance() ? GetGameInstance()->GetSubsystem<USquadAILocalizationSubsystem>() : nullptr;
				const bool bEnglishLoad = LocForLoad && LocForLoad->GetCurrentLanguage().StartsWith(TEXT("en"), ESearchCase::IgnoreCase);
				const FText LoadTitle = FText::FromString(SquadAISaveSlotDisplayTextForLanguage(Loaded->SectorDisplayName.ToString(), bEnglishLoad));
				const FText LoadSubtitle = FText::FromString(SquadAISaveSlotDisplayTextForLanguage(Loaded->ActiveMissionTitle.ToString(), bEnglishLoad));
				Loading->LoadLevelWithScreen(FName(*Loaded->MapName), LoadTitle, LoadSubtitle);
		}
		else if (World)
		{
			UGameplayStatics::OpenLevel(World, FName(*Loaded->MapName));
		}
		SchedulePostTravelApply(Loaded->MapName);
	}
	else if (GetWorld())
	{
		ApplySaveDataToWorld(GetWorld());
	}

	OnLoadCompleted.Broadcast(true);
	return true;
}

bool USquadAISaveLoadSubsystem::QuickSave()
{
	return SaveGame(QuickSaveSlotName);
}

bool USquadAISaveLoadSubsystem::QuickLoad()
{
	return LoadGame(QuickSaveSlotName, true);
}

bool USquadAISaveLoadSubsystem::AutoSave(const FText& SectorName)
{
	UWorld* World = GetWorld();
	if (!World) return false;

	USquadAISaveGame* SaveObj = Cast<USquadAISaveGame>(UGameplayStatics::CreateSaveGameObject(USquadAISaveGame::StaticClass()));
	if (!SaveObj) return false;

	SaveObj->SlotName = AutoSaveSlotName;
	SaveObj->Timestamp = FDateTime::Now();
	SaveObj->MapName = World->GetMapName();
	SaveObj->MapName.RemoveFromStart(World->StreamingLevelsPrefix);
	if (!SectorName.IsEmpty())
	{
		SaveObj->SectorDisplayName = SectorName;
	}

	GatherWorldDataIntoSave(SaveObj, World);

	const bool bSuccess = UGameplayStatics::SaveGameToSlot(SaveObj, AutoSaveSlotName, 0);
	if (bSuccess)
	{
		CurrentLoadedSave = SaveObj;
		bMostRecentCacheValid = false;
		UE_LOG(LogTemp, Log, TEXT("[SquadAISaveLoad] AutoSave executed successfully"));
	}
	return bSuccess;
}

bool USquadAISaveLoadSubsystem::DeleteSaveSlot(const FString& SlotName)
{
	if (UGameplayStatics::DoesSaveGameExist(SlotName, 0))
	{
		const bool bDeleted = UGameplayStatics::DeleteGameInSlot(SlotName, 0);
		if (bDeleted) { bMostRecentCacheValid = false; }
		return bDeleted;
	}
	return false;
}

bool USquadAISaveLoadSubsystem::DoesSaveExist(const FString& SlotName) const
{
	return UGameplayStatics::DoesSaveGameExist(SlotName, 0);
}

TArray<FString> USquadAISaveLoadSubsystem::GetAllSaveSlotNames() const
{
	TArray<FString> Result;
	if (DoesSaveExist(AutoSaveSlotName)) Result.Add(AutoSaveSlotName);
	if (DoesSaveExist(QuickSaveSlotName)) Result.Add(QuickSaveSlotName);

	for (int32 i = 0; i < 10; ++i)
	{
		const FString Slot = FString::Printf(TEXT("SquadAISave_Slot%d"), i);
		if (DoesSaveExist(Slot))
		{
			Result.Add(Slot);
		}
	}

	if (DoesSaveExist(TEXT("SquadAISave_Manual")))
	{
		Result.Add(TEXT("SquadAISave_Manual"));
	}

	return Result;
}

USquadAISaveGame* USquadAISaveLoadSubsystem::ReadSaveMetadata(const FString& SlotName) const
{
	if (!DoesSaveExist(SlotName)) return nullptr;
	return Cast<USquadAISaveGame>(UGameplayStatics::LoadGameFromSlot(SlotName, 0));
}

FString USquadAISaveLoadSubsystem::GetMostRecentSaveSlot() const
{
	// B6-15: slot metadata only changes on save/delete (which invalidate below).
	if (bMostRecentCacheValid) { return CachedMostRecentSlot; }
	const TArray<FString> Slots = GetAllSaveSlotNames();
	if (Slots.Num() == 0) return FString();

	FString MostRecentSlot = Slots[0];
	FDateTime LatestTime = FDateTime::MinValue();

	for (const FString& Slot : Slots)
	{
		if (USquadAISaveGame* Save = ReadSaveMetadata(Slot))
		{
			if (Save->Timestamp > LatestTime)
			{
				LatestTime = Save->Timestamp;
				MostRecentSlot = Slot;
			}
		}
	}

	CachedMostRecentSlot = MostRecentSlot;
	bMostRecentCacheValid = true;
	return MostRecentSlot;
}

bool USquadAISaveLoadSubsystem::HasAnySaves() const
{
	return GetAllSaveSlotNames().Num() > 0;
}

void USquadAISaveLoadSubsystem::GatherWorldDataIntoSave(USquadAISaveGame* SaveObj, UWorld* World)
{
	if (!SaveObj || !World) return;

	// 1. Player / Leader character
	APawn* PlayerPawn = UGameplayStatics::GetPlayerPawn(World, 0);
	if (PlayerPawn)
	{
		SaveObj->PlayerTransform = PlayerPawn->GetActorTransform();
		if (UHealthComponent* HC = PlayerPawn->FindComponentByClass<UHealthComponent>())
		{
			SaveObj->PlayerHealth = HC->CurrentHealth;
			SaveObj->PlayerMaxHealth = HC->MaxHealth;
		}
		if (UWeaponComponent* WC = PlayerPawn->FindComponentByClass<UWeaponComponent>())
		{
			SaveObj->AmmoInClip = WC->CurrentClipAmmo; // was BurstShots (a burst counter, not ammo!)
			SaveObj->ReserveAmmo = WC->ReserveAmmo;
		}
	}

	// 2. Squad Allies
	SaveObj->SavedAllies.Empty();
	for (TActorIterator<AAllySoldier> It(World); It; ++It)
	{
		AAllySoldier* Ally = *It;
		if (!Ally) continue;

		FSquadAllySaveData AllyData;
		AllyData.AllyID = Ally->GetName();
		AllyData.Transform = Ally->GetActorTransform();
		AllyData.bIsDowned = Ally->IsDowned();
		if (UHealthComponent* HC = Ally->HealthComp)
		{
			AllyData.Health = HC->CurrentHealth;
			AllyData.MaxHealth = HC->MaxHealth;
			AllyData.bIsDead = HC->bIsDead;
		}
		SaveObj->SavedAllies.Add(AllyData);
	}

	// 3. Campaign & Mission Progress
	// S5-15: stamp the format version, capture progress from the HUD-authoritative
	// chain (FindPreferred: same chain the player actually follows), and record its
	// stable identity. Previously this grabbed the FIRST chain in TActorIterator
	// order — non-deterministic across sessions — so progress could be written for
	// one chain and later restored onto another.
	SaveObj->SaveFormatVersion = USquadAISaveGame::CurrentSaveFormatVersion;
	AQuestChain* Chain = AQuestChain::FindPreferred(World, /*bActiveOnly=*/false);
	if (!Chain)
	{
		for (TActorIterator<AQuestChain> It(World); It; ++It) { Chain = *It; break; }
	}
	if (Chain)
	{
		SaveObj->ActiveMissionIndex = Chain->CurrentMissionIndex;
		SaveObj->CompletedMissionCount = Chain->CompletedMissionCount; // B6-7: was CurrentMissionIndex (completed==active!)
	// S5-15b: prefer the designer-minted ChainSaveId; otherwise fall back to the
	// actor's OWN ActorGuid — persistent for placed actors in every (cooked or
	// uncooked) level, regenerated by the editor on duplicate, zero resave needed.
		SaveObj->SavedChainId = Chain->ChainSaveId.IsValid() ? Chain->ChainSaveId : Chain->GetActorGuid();
		SaveObj->SavedChainName = Chain->GetFName();
		if (Chain->Missions.IsValidIndex(Chain->CurrentMissionIndex) && Chain->Missions[Chain->CurrentMissionIndex])
		{
			SaveObj->ActiveMissionTitle = Chain->Missions[Chain->CurrentMissionIndex]->MissionDescription;
		}
	}

	// 4. Difficulty
	if (UDifficultySubsystem* Diff = UDifficultySubsystem::Get(World))
	{
		SaveObj->DifficultyRating = (int32)Diff->GetCurrentDifficulty();
	}

	// 5. Supplies (grenades/smoke/kits).
	if (USquadAIInventorySubsystem* Inv = USquadAIInventorySubsystem::Get(World))
	{
		SaveObj->FragGrenades = Inv->FragGrenades;
		SaveObj->SmokeGrenades = Inv->SmokeGrenades;
		SaveObj->FirstAidKits = Inv->FirstAidKits;
	}

	// 6. Equipped weapon (unlock state itself lives in Progression's own disk save).
	if (USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(World))
	{
		SaveObj->EquippedWeaponID = Prog->GetEquippedWeaponID();
	}
}

void USquadAISaveLoadSubsystem::ApplySaveDataToWorld(UWorld* World)
{
	if (!CurrentLoadedSave || !World) return;

	// 1. Restore Player / Leader
	APawn* PlayerPawn = UGameplayStatics::GetPlayerPawn(World, 0);
	if (PlayerPawn)
	{
		PlayerPawn->SetActorTransform(CurrentLoadedSave->PlayerTransform);
		if (ASoldierCharacter* SC = Cast<ASoldierCharacter>(PlayerPawn))
		{
			SC->bIsDowned = false;
		}
		if (UHealthComponent* HC = PlayerPawn->FindComponentByClass<UHealthComponent>())
		{
			HC->CurrentHealth = CurrentLoadedSave->PlayerHealth;
			HC->MaxHealth = CurrentLoadedSave->PlayerMaxHealth;
			HC->bIsDead = false;
		}
	}

	// 2. Restore Quest / Campaign State
	// S5-15: select WHICH chain gets the saved progress by stable identity —
	// v2+ saves: ChainSaveId GUID match, then actor-name match as secondary;
	// legacy v1 saves: first auto-start chain (old behavior preserved).
	// Previously this restored onto the FIRST chain in TActorIterator order,
	// which is non-deterministic across sessions — progress could land on the
	// wrong chain.
	AQuestChain* RestoreChain = nullptr;
	if (CurrentLoadedSave->SaveFormatVersion >= 2 && CurrentLoadedSave->SavedChainId.IsValid())
	{
		for (TActorIterator<AQuestChain> It(World); It; ++It)
		{
			AQuestChain* C = *It;
	// S5-15b: match the minted override OR the persistent ActorGuid — saves written
	// before the level was ever re-saved (ChainSaveId still random per session)
	// still resolve via ActorGuid.
			if (C && (C->ChainSaveId == CurrentLoadedSave->SavedChainId || C->GetActorGuid() == CurrentLoadedSave->SavedChainId)) { RestoreChain = C; break; }
		}
	}
	if (!RestoreChain && CurrentLoadedSave->SavedChainName != NAME_None)
	{
		for (TActorIterator<AQuestChain> It(World); It; ++It)
		{
			AQuestChain* C = *It;
			if (C && C->GetFName() == CurrentLoadedSave->SavedChainName) { RestoreChain = C; break; }
		}
	}
	if (!RestoreChain)
	{
		// Legacy fallback: first auto-start chain. (Old code broke out after the
		// first chain even when it wasn't bAutoStart; selecting the first AUTO-START
		// chain is a strict improvement — a non-starting chain could never hold progress.)
		for (TActorIterator<AQuestChain> It(World); It; ++It)
		{
			AQuestChain* C = *It;
			if (C && C->bAutoStart) { RestoreChain = C; break; }
		}
	}
	if (AQuestChain* Chain = RestoreChain)
	{
			// B6-8: StartChain() unconditionally resets to mission 0, so every load
			// restarted the chain. Restore the saved position surgically instead.
			const int32 SavedActive = CurrentLoadedSave->ActiveMissionIndex;
			const int32 SavedDone = CurrentLoadedSave->CompletedMissionCount;
			if (Chain->Missions.Num() > 0 && SavedDone >= Chain->Missions.Num())
			{
				// Whole chain was finished: park it completed, nothing active.
				Chain->bIsActive = false;
				Chain->bIsCompleted = true;
				Chain->CurrentMissionIndex = Chain->Missions.Num() - 1;
				Chain->CompletedMissionCount = Chain->Missions.Num();
				for (AMissionZone* M : Chain->Missions)
				{
					if (!M) continue;
					M->OnMissionStateChanged.RemoveAll(Chain);
					M->SilentResetForLoadRestore();
					M->MissionState = EMissionZoneState::Completed;
					M->MissionProgress = 1.f;
				}
			}
			else if (Chain->Missions.IsValidIndex(SavedActive))
			{
				// Neutralize any pending BeginPlay auto-start timer: StartChain()
				// early-outs once bIsActive is set, so it can't reset us later.
				Chain->bIsActive = true;
				Chain->bIsCompleted = false;
				Chain->CurrentMissionIndex = -1;
				Chain->CompletedMissionCount = FMath::Clamp(SavedDone, 0, SavedActive);
				for (AMissionZone* M : Chain->Missions)
				{
					if (!M) continue;
					M->OnMissionStateChanged.RemoveAll(Chain);
					M->SilentResetForLoadRestore();
				}
				// Direct writes: no completion broadcasts (the chain is being rebuilt
				// manually and must not auto-advance; no XP re-award either).
				for (int32 i = 0; i < SavedActive && i < Chain->Missions.Num(); ++i)
				{
					if (AMissionZone* M = Chain->Missions[i])
					{
						M->MissionState = EMissionZoneState::Completed;
						M->MissionProgress = 1.f;
					}
				}
				// F-P03: public wrapper (StartMissionAtIndex is private).
				Chain->RestoreMissionState(SavedActive);
			}
			else
			{
				// Saved index doesn't fit this chain (different map?) — fresh start.
				Chain->StartChain();
			}
		}

	// 3. Restore Difficulty
	if (UDifficultySubsystem* Diff = UDifficultySubsystem::Get(World))
	{
		Diff->SetDifficulty((EGameDifficulty)FMath::Clamp(CurrentLoadedSave->DifficultyRating, 0, 3));
	}

	// 4. Restore Squad Allies (gathered but previously never applied).
	for (const FSquadAllySaveData& AllyData : CurrentLoadedSave->SavedAllies)
	{
		for (TActorIterator<AAllySoldier> It(World); It; ++It)
		{
			AAllySoldier* Ally = *It;
			if (!Ally || Ally->GetName() != AllyData.AllyID) continue;
			Ally->SetActorTransform(AllyData.Transform);
			if (UHealthComponent* HC = Ally->HealthComp)
			{
				HC->MaxHealth = AllyData.MaxHealth;
				HC->CurrentHealth = FMath::Clamp(AllyData.Health, 1.f, AllyData.MaxHealth);
				HC->bIsDead = false;
			}
			if (AllyData.bIsDowned && !Ally->IsDowned())
			{
				Ally->EnterDownedState();
			}
			break;
		}
	}

	// 5. Restore supplies + sync the player's grenade component.
	if (USquadAIInventorySubsystem* Inv = USquadAIInventorySubsystem::Get(World))
	{
		Inv->FragGrenades = FMath::Max(0, CurrentLoadedSave->FragGrenades);
		Inv->SmokeGrenades = FMath::Max(0, CurrentLoadedSave->SmokeGrenades);
		Inv->FirstAidKits = FMath::Max(0, CurrentLoadedSave->FirstAidKits);
		if (APawn* P = UGameplayStatics::GetPlayerPawn(World, 0))
		{
			if (UTacticalGrenadeComponent* GC = P->FindComponentByClass<UTacticalGrenadeComponent>())
			{
				GC->FragGrenadesRemaining = FMath::Clamp(Inv->FragGrenades, 0, GC->MaxFragGrenades);
				GC->SmokeGrenadesRemaining = FMath::Clamp(Inv->SmokeGrenades, 0, GC->MaxSmokeGrenades);
				GC->OnGrenadeInventoryChanged.Broadcast(GC->FragGrenadesRemaining, GC->SmokeGrenadesRemaining);
			}
		}
	}

	// 6. Restore loadout ammo + equipped weapon.
	if (APawn* P2 = UGameplayStatics::GetPlayerPawn(World, 0))
	{
		if (UWeaponComponent* WC = P2->FindComponentByClass<UWeaponComponent>())
		{
			WC->CurrentClipAmmo = FMath::Max(0, CurrentLoadedSave->AmmoInClip);
			WC->ReserveAmmo = FMath::Max(0, CurrentLoadedSave->ReserveAmmo);
		}
	}
	if (USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(World))
	{
		Prog->EquipWeapon(CurrentLoadedSave->EquippedWeaponID);
	}

	UE_LOG(LogTemp, Log, TEXT("[SquadAISaveLoad] Applied loaded save data to world '%s'"), *World->GetName());
}

void USquadAISaveLoadSubsystem::SaveSettings(const FSquadGameSettingsSaveData& Settings)
{
	USquadAISaveGame* SaveObj = Cast<USquadAISaveGame>(UGameplayStatics::CreateSaveGameObject(USquadAISaveGame::StaticClass()));
	if (!SaveObj) return;

	SaveObj->SavedSettings = Settings;
	UGameplayStatics::SaveGameToSlot(SaveObj, SettingsSlotName, 0);
	ApplySettingsToEngine(Settings);
	UE_LOG(LogTemp, Log, TEXT("[SquadAISaveLoad] Saved user settings profile"));
}

FSquadGameSettingsSaveData USquadAISaveLoadSubsystem::LoadSettings()
{
	if (UGameplayStatics::DoesSaveGameExist(SettingsSlotName, 0))
	{
		if (USquadAISaveGame* SaveObj = Cast<USquadAISaveGame>(UGameplayStatics::LoadGameFromSlot(SettingsSlotName, 0)))
		{
			return SaveObj->SavedSettings;
		}
	}
	return FSquadGameSettingsSaveData();
}

bool USquadAISaveLoadSubsystem::LoadLatestSave()
{
	const FString MostRecent = GetMostRecentSaveSlot();
	if (!MostRecent.IsEmpty())
	{
		return LoadGame(MostRecent, true);
	}
	return false;
}

bool USquadAISaveLoadSubsystem::LoadGameFromSlot(int32 SlotIndex)
{
	const FString TargetSlot = FString::Printf(TEXT("SquadAISave_Slot%d"), SlotIndex);
	if (DoesSaveExist(TargetSlot))
	{
		return LoadGame(TargetSlot, true);
	}
	return false;
}

TArray<FSquadSaveSlotInfo> USquadAISaveLoadSubsystem::GetAllSaveSlots() const
{
	TArray<FSquadSaveSlotInfo> Slots;
	for (int32 i = 0; i < 4; ++i)
	{
		FSquadSaveSlotInfo SlotInfo;
		SlotInfo.SlotName = FString::Printf(TEXT("SquadAISave_Slot%d"), i);
			const USquadAILocalizationSubsystem* LocForSlots = GetGameInstance() ? GetGameInstance()->GetSubsystem<USquadAILocalizationSubsystem>() : nullptr;
			const bool bEnglishSlots = LocForSlots && LocForSlots->GetCurrentLanguage().StartsWith(TEXT("en"), ESearchCase::IgnoreCase);
			SlotInfo.DisplayName = bEnglishSlots ? FString::Printf(TEXT("Save Slot %d"), i + 1) : FString::Printf(TEXT("موقعیت ذخیره شماره %d"), i + 1);
		if (DoesSaveExist(SlotInfo.SlotName))
		{
			if (USquadAISaveGame* Meta = ReadSaveMetadata(SlotInfo.SlotName))
			{
				SlotInfo.Timestamp = Meta->Timestamp;
				if (!Meta->SectorDisplayName.IsEmpty())
				{
						SlotInfo.DisplayName = SquadAISaveSlotDisplayTextForLanguage(Meta->SectorDisplayName.ToString(), bEnglishSlots);
				}
			}
			SlotInfo.bExists = true;
		}
		else
		{
			SlotInfo.bExists = false;
		}
		Slots.Add(SlotInfo);
	}
	return Slots;
}

void USquadAISaveLoadSubsystem::ApplySettingsToEngine(const FSquadGameSettingsSaveData& Settings)
{
	CachedSettings = Settings;
	if (GEngine && GEngine->GetGameUserSettings())
	{
		UGameUserSettings* UserSettings = GEngine->GetGameUserSettings();
		UserSettings->SetOverallScalabilityLevel(Settings.OverallQualityPreset);
		UserSettings->SetVSyncEnabled(Settings.bVSyncEnabled);
		UserSettings->ApplySettings(false);
	}

	// B6-9: volumes + language + FOV were persisted but never applied. Subsystem Gets
	// are null-guarded: at Initialize time the world subsystems may not exist yet.
	if (USquadAIAudioSubsystem* Audio = USquadAIAudioSubsystem::Get(this))
	{
		Audio->ApplyVolumeSettings(Settings.MasterVolume, Settings.MusicVolume, Settings.SFXVolume, Settings.VoiceVolume);
	}
	if (UGameInstance* GI = GetGameInstance())
	{
		if (USquadAILocalizationSubsystem* Loc = GI->GetSubsystem<USquadAILocalizationSubsystem>())
		{
			Loc->SetCurrentLanguage(Settings.LanguageCode);
		}
	}
	else if (USquadAILocalizationSubsystem* Loc = USquadAILocalizationSubsystem::Get(this))
	{
		Loc->SetCurrentLanguage(Settings.LanguageCode);
	}
	if (APlayerCameraManager* Cam = UGameplayStatics::GetPlayerCameraManager(this, 0))
	{
		Cam->SetFOV(FMath::Clamp(Settings.FieldOfView, 60.f, 120.f));
	}
	// B6-9 residual CLOSED: motion blur via null-guarded console var; subtitles gate
	// DrawRadioChatterSubtitle via GetCachedSettings(). Sensitivity/invert stay exposed
	// via GetCachedSettings for the out-of-module look-input owner (no in-module
	// SetupPlayerInputComponent/Turn/LookUp exists — verified zero hits).
	if (IConsoleVariable* MBVar = IConsoleManager::Get().FindConsoleVariable(TEXT("r.MotionBlurQuality")))
	{
		MBVar->Set(Settings.bMotionBlurEnabled ? 4 : 0);
	}
}

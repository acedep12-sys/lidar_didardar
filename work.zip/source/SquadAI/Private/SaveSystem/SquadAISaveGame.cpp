#include "SaveSystem/SquadAISaveGame.h"

USquadAISaveGame::USquadAISaveGame()
{
	Timestamp = FDateTime::Now();
	PlaytimeSeconds = 0.0f;
	MapName = TEXT("L_Khuzestan");
	SectorDisplayName = FText::FromString(TEXT("محور دهلاویه و کرخه - خط مقدم"));
	ActiveMissionIndex = 0;
	ActiveMissionTitle = FText::FromString(TEXT("پیشروی در سنگرهای دهلاویه"));
	CompletedMissionCount = 0;
	TotalWavesCleared = 0;
	DifficultyRating = 1;

	PlayerLevel = 1;
	PlayerTotalXP = 0;
	PlayerCurrentLevelXP = 0;
	AvailableSkillPoints = 0;

	PlayerHealth = 100.0f;
	PlayerMaxHealth = 100.0f;
	EquippedWeaponID = FName("G3A3");
	AmmoInClip = 20;
	ReserveAmmo = 140;
	FragGrenades = 3;
	SmokeGrenades = 2;
	FirstAidKits = 2;
}

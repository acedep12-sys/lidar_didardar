// EnemyWaveSpawner.cpp — Configurable enemy wave spawner
// Spawns enemies in waves with configurable X=enemies/wave, Y=interval, Z=max waves.
// Uses AEnemySoldier by default, but EnemyClass can be set to any BP from TPWCS pack.
#include "Quest/EnemyWaveSpawner.h"
#include "SquadAITuning.h"
#include "Quest/SpawnerTrigger.h"
#include "Quest/EnemyPool.h"
#include "Quest/MissionZone.h" // S14-END
#include "EngineUtils.h" // S14-END: TActorIterator
#include "Characters/EnemySoldier.h"
#include "Characters/EnemyCommander.h"
#include "Characters/EnemyPatroller.h"     // S19-PATROL: fireteam gate           // S19-ELITE
#include "Characters/EnemyCommanderAssistant.h"   // S19-ELITE
#include "Characters/SoldierCharacter.h"
#include "Components/HealthComponent.h"
#include "Performance/SoldierRegistrySubsystem.h"
#include "AI/EnemyFireteamSubsystem.h"
#include "AI/SoldierAIController.h"
#include "Components/CapsuleComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Engine/World.h"
#include "TimerManager.h"
#include "NavigationSystem.h"
#include "Kismet/KismetMathLibrary.h"
#include "UObject/UnrealType.h"
#include "Performance/SquadAIRecovery.h" // S19-HUNT: IsActorDead covers pack pawns

AEnemyWaveSpawner::AEnemyWaveSpawner()
{
	PrimaryActorTick.bCanEverTick = false;

	USceneComponent* Root = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	SetRootComponent(Root);

#if WITH_EDITORONLY_DATA
	UStaticMeshComponent* EditorMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("EditorVisual"));
	EditorMesh->SetupAttachment(Root);
	EditorMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	EditorMesh->SetHiddenInGame(true);
	static ConstructorHelpers::FObjectFinder<UStaticMesh> SphereMesh(TEXT("/Engine/BasicShapes/Sphere.Sphere"));
	if (SphereMesh.Succeeded())
	{
		EditorMesh->SetStaticMesh(SphereMesh.Object);
		EditorMesh->SetRelativeScale3D(FVector(0.3f));
	}
#endif
}

void AEnemyWaveSpawner::BeginPlay()
{
	Super::BeginPlay();

	if (LinkedTrigger)
	{
		LinkedTrigger->LinkedSpawners.AddUnique(this);
	}

	UE_LOG(LogTemp, Warning, TEXT("[WaveSpawner] %s: BeginPlay. Config: X=%d enemies/wave, Y=%.1fs interval, Z=%d max waves, Loop=%d, AutoActivate=%d, EnemyClass=%s"),
		*GetName(), EnemiesPerWave, SpawnIntervalSeconds, MaxWaves, bLoopWaves ? 1 : 0, bAutoActivate ? 1 : 0,
		EnemyClass ? *EnemyClass->GetName() : TEXT("DEFAULT(AEnemySoldier)"));

	if (bAutoActivate)
	{
		ActivateSpawner();
	}
}

void AEnemyWaveSpawner::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(SpawnTimerHandle);
		World->GetTimerManager().ClearTimer(WaveDelayTimerHandle);
	}

	if (bDestroyEnemiesOnSpawnerEnd)
	{
		for (APawn* Enemy : SpawnedEnemies)
		{
			if (Enemy && Enemy->IsValidLowLevel() && !Enemy->IsActorBeingDestroyed())
			{
				UnbindEnemyDeathDelegate(Enemy);
				Enemy->Destroy();
			}
		}
	}

	Super::EndPlay(EndPlayReason);
}

void AEnemyWaveSpawner::ActivateSpawner()
{
	if (bIsActive) return;
	if (bOneShot && bActivatedOnce) return;

	// S14-END: post-campaign peace. SpawnerTriggers fire on player overlap with
	// no idea of mission state — after the LAST mission completed, walking into
	// one re-armed a bLoopWaves spawner and the map filled with endless waves
	// ("enemies spawn a few seconds after all missions are done"), grinding the
	// GPU until it timed out. If the map has mission zones and EVERY one of
	// them is Completed, there is nothing left to fight for: refuse activation.
	{
		int32 ZoneCount = 0, CompletedCount = 0;
		for (TActorIterator<AMissionZone> It(GetWorld()); It; ++It)
		{
			ZoneCount++;
			if (It->IsComplete()) CompletedCount++;
		}
		if (ZoneCount > 0 && CompletedCount == ZoneCount)
		{
			UE_LOG(LogTemp, Warning, TEXT("[WaveSpawner] %s: activation REFUSED — all %d mission zones completed (S14-END post-campaign peace)."),
				*GetName(), ZoneCount);
			return;
		}
	}

	bIsActive = true;
	bActivatedOnce = true;
	bCompleted = false;
	CurrentWave = 0;
	TotalEnemiesSpawned = 0;
	AliveEnemyCount = 0;
	SpawnedInCurrentWave = 0;

	UE_LOG(LogTemp, Warning, TEXT("[WaveSpawner] %s ACTIVATED. Config: X=%d, Y=%.1f, Z=%d, Loop=%d, MaxAlive=%d, Radius=%.0f"),
		*GetName(), EnemiesPerWave, SpawnIntervalSeconds, MaxWaves, bLoopWaves ? 1 : 0, MaxAliveEnemies, SpawnRadius);

	// S5-7: Prewarm had zero callers — every wave paid full SpawnActor cost despite the
	// pool + Acquire path. Top up to MaxAlive (self-regulating: retries reuse Release()d pawns).
	if (UEnemyPoolSubsystem* Pool = GetWorld()->GetSubsystem<UEnemyPoolSubsystem>())
	{
		TSubclassOf<APawn> PoolClass = EnemyClass;
		if (!PoolClass)
		{
			PoolClass = AEnemySoldier::StaticClass();
		}
		const int32 Want = FMath::Max(0, MaxAliveEnemies);
		const int32 Have = Pool->GetAvailableCount(PoolClass);
		if (Want > Have)
		{
			Pool->Prewarm(PoolClass, Want - Have);
		}
	}

	StartNextWave();
}

void AEnemyWaveSpawner::DeactivateSpawner()
{
	if (!bIsActive) return;

	bIsActive = false;

	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(SpawnTimerHandle);
		World->GetTimerManager().ClearTimer(WaveDelayTimerHandle);
	}

	UE_LOG(LogTemp, Warning, TEXT("[WaveSpawner] %s deactivated at wave %d. Total spawned: %d, Alive: %d"),
		*GetName(), CurrentWave, TotalEnemiesSpawned, AliveEnemyCount);
}

void AEnemyWaveSpawner::ResetSpawner()
{
	DeactivateSpawner();

	UWorld* World = GetWorld();
	UEnemyFireteamSubsystem* FT = World ? World->GetSubsystem<UEnemyFireteamSubsystem>() : nullptr;

	for (APawn* Enemy : SpawnedEnemies)
	{
		if (Enemy && Enemy->IsValidLowLevel() && !Enemy->IsActorBeingDestroyed())
		{
			UnbindEnemyDeathDelegate(Enemy);
			if (FT)
			{
				FT->UnregisterMember(Enemy);
			}
			Enemy->Destroy();
		}
	}
	SpawnedEnemies.Empty();

	if (World)
	{
		TArray<APawn*> Owned;
		for (TActorIterator<APawn> It(World); It; ++It)
		{
			if (It->GetOwner() == this)
			{
				Owned.Add(*It);
			}
		}
		for (APawn* P : Owned)
		{
			if (!P || P->IsActorBeingDestroyed()) continue;
			if (FT)
			{
				FT->UnregisterMember(P);
			}
			P->Destroy();
		}
	}

	CurrentWave = 0;
	TotalEnemiesSpawned = 0;
	AliveEnemyCount = 0;
	SpawnedInCurrentWave = 0;
	bIsActive = false;
	bCompleted = false;
	bActivatedOnce = false;

	UE_LOG(LogTemp, Warning, TEXT("[WaveSpawner] %s reset — ready for reactivation"), *GetName());
}

// ===== S19-HUNT =====
// "He reached the quest zone and then did nothing" - the zone still had enemies, but
// nothing ever asked the spawner what was left. AliveEnemyCount is a counter used for
// mission completion; these helpers answer the ACTOR-level question the leader needs.
//
// IsActorDead() (reflection over the pack's death flags plus our native health) is the
// only death test that is correct for BOTH kinds of enemy - the same reason S19-CORPSE
// uses it for threat memory.
bool AEnemyWaveSpawner::HasAliveEnemies() const
{
	for (const TObjectPtr<APawn>& Entry : SpawnedEnemies)
	{
		APawn* Pawn = Entry.Get();
		if (!Pawn || Pawn->IsActorBeingDestroyed()) continue;
		if (SquadAIRecovery::IsActorDead(Pawn)) continue;
		return true;
	}
	return false;
}

int32 AEnemyWaveSpawner::CountAliveEnemies() const
{
	int32 Count = 0;
	for (const TObjectPtr<APawn>& Entry : SpawnedEnemies)
	{
		APawn* Pawn = Entry.Get();
		if (!Pawn || Pawn->IsActorBeingDestroyed()) continue;
		if (SquadAIRecovery::IsActorDead(Pawn)) continue;
		++Count;
	}
	return Count;
}

APawn* AEnemyWaveSpawner::GetNearestAliveEnemy(const FVector& From) const
{
	APawn* Best = nullptr;
	float BestDistSq = -1.f;
	for (const TObjectPtr<APawn>& Entry : SpawnedEnemies)
	{
		APawn* Pawn = Entry.Get();
		if (!Pawn || Pawn->IsActorBeingDestroyed()) continue;
		if (SquadAIRecovery::IsActorDead(Pawn)) continue;
		const float DistSq = FVector::DistSquared(Pawn->GetActorLocation(), From);
		if (BestDistSq < 0.f || DistSq < BestDistSq)
		{
			BestDistSq = DistSq;
			Best = Pawn;
		}
	}
	return Best;
}

FString AEnemyWaveSpawner::GetProgressString() const
{
	if (bCompleted)
		return FString::Printf(TEXT("COMPLETED: %d enemies spawned in %d waves"), TotalEnemiesSpawned, CurrentWave);
	if (bIsActive)
		return FString::Printf(TEXT("WAVE %d/%d: %d spawned, %d alive"), CurrentWave, MaxWaves, TotalEnemiesSpawned, AliveEnemyCount);
	return FString::Printf(TEXT("IDLE: %d/%d waves done"), CurrentWave, MaxWaves);
}

void AEnemyWaveSpawner::StartNextWave()
{
	if (!bIsActive) return;

	// Check if we've completed all waves
	if (MaxWaves > 0 && CurrentWave >= MaxWaves)
	{
		if (bLoopWaves)
		{
			CurrentWave = 0;
			UE_LOG(LogTemp, Warning, TEXT("[WaveSpawner] %s: Looping — restarting from wave 1. Alive: %d"),
				*GetName(), AliveEnemyCount);
		}
		else
		{
			bIsActive = false;
			bCompleted = true;
			OnSpawnerAllWavesDone.Broadcast();
			UE_LOG(LogTemp, Warning, TEXT("[WaveSpawner] %s COMPLETED all %d waves. Total enemies: %d"),
				*GetName(), MaxWaves, TotalEnemiesSpawned);
			// S5-6e: spawning is done, but Clear missions count AliveEnemyCount — keep polling
			// until the last pack member falls (previously polling stopped here forever).
			if (AliveEnemyCount > 0 && GetWorld())
			{
				GetWorld()->GetTimerManager().SetTimer(SpawnTimerHandle, this,
					&AEnemyWaveSpawner::PollLatePackDeaths, 1.5f, true);
			}
			return;
		}
	}

	CurrentWave++;
	SpawnedInCurrentWave = 0;

	// S19-ELITE: does this wave come with a commander?
	bCommanderWaveThisWave = ShouldSpawnCommanderThisWave();

	UE_LOG(LogTemp, Warning, TEXT("[WaveSpawner] %s starting wave %d/%d (%d enemies, %.1fs interval)%s"),
		*GetName(), CurrentWave, MaxWaves, EnemiesPerWave, SpawnIntervalSeconds,
		bCommanderWaveThisWave ? TEXT(" - WITH COMMANDER") : TEXT(""));

	if (bCommanderWaveThisWave)
	{
		SpawnCommanderAndEscorts();
	}

	SpawnNextEnemy();
}

void AEnemyWaveSpawner::SpawnNextEnemy()
{
	if (!bIsActive) return;
	if (!GetWorld()) return;

	if (SpawnedInCurrentWave >= EnemiesPerWave)
	{
		OnWaveCompleted();
		return;
	}

	CleanupDeadEnemies();
	if (MaxAliveEnemies > 0 && AliveEnemyCount >= MaxAliveEnemies)
	{
		UE_LOG(LogTemp, Verbose, TEXT("[WaveSpawner] %s: Max alive enemies (%d) reached. Waiting..."),
			*GetName(), MaxAliveEnemies);
		GetWorld()->GetTimerManager().SetTimer(SpawnTimerHandle, this,
			&AEnemyWaveSpawner::SpawnNextEnemy, SpawnIntervalSeconds, false);
		return;
	}

	TSubclassOf<APawn> SpawnClass = EnemyClass;
	if (!SpawnClass)
	{
		SpawnClass = AEnemySoldier::StaticClass();
		UE_LOG(LogTemp, Warning, TEXT("[WaveSpawner] %s: No EnemyClass set, using AEnemySoldier. Set EnemyClass in Details panel to your BP_Enemy!"),
			*GetName());
	}

	const FVector SpawnLocation = GetRandomSpawnLocation();
	const FRotator SpawnRotation = FRotator(0.f, FMath::FRandRange(0.f, 360.f), 0.f);

	// S19-ELITE: the spawn-and-track body moved into SpawnEnemyOfClass, because the
	// commander's reinforcement calls have to produce exactly the same kind of enemy
	// (pool path, death binding, state-tree rescue, fireteam) without being a wave.
	if (APawn* SpawnedEnemy = SpawnEnemyOfClass(SpawnClass, SpawnLocation, SpawnRotation))
	{
		SpawnedInCurrentWave++;
		UE_LOG(LogTemp, Verbose, TEXT("[WaveSpawner] %s: Spawned enemy %d/%d in wave %d at %s (class=%s)"),
			*GetName(), SpawnedInCurrentWave, EnemiesPerWave, CurrentWave,
			*SpawnLocation.ToString(), *SpawnClass->GetName());
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("[WaveSpawner] %s: FAILED to spawn enemy %d/%d in wave %d at %s (class=%s)"),
			*GetName(), SpawnedInCurrentWave + 1, EnemiesPerWave, CurrentWave,
			*SpawnLocation.ToString(), *SpawnClass->GetName());
		// Still increment so we don't infinite loop
		SpawnedInCurrentWave++;
	}

	GetWorld()->GetTimerManager().SetTimer(SpawnTimerHandle, this,
		&AEnemyWaveSpawner::SpawnNextEnemy, SpawnIntervalSeconds, false);
}

void AEnemyWaveSpawner::OnWaveCompleted()
{
	OnSpawnerWaveCompleted.Broadcast(CurrentWave);

	UE_LOG(LogTemp, Warning, TEXT("[WaveSpawner] %s: Wave %d completed. Alive: %d. Waiting %.1fs for next wave."),
		*GetName(), CurrentWave, AliveEnemyCount, DelayBetweenWaves);

	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().SetTimer(WaveDelayTimerHandle,
			FTimerDelegate::CreateUObject(this, &AEnemyWaveSpawner::StartNextWave),
			DelayBetweenWaves, false);
	}
}


void AEnemyWaveSpawner::PollLatePackDeaths()
{
	CleanupDeadEnemies();
	if (AliveEnemyCount <= 0)
	{
		GetWorld()->GetTimerManager().ClearTimer(SpawnTimerHandle);
	}
}
void AEnemyWaveSpawner::CleanupDeadEnemies()
{
	AliveEnemyCount = 0;
	TArray<APawn*> NewlyDeadPackEnemies;

	for (int32 i = SpawnedEnemies.Num() - 1; i >= 0; --i)
	{
		APawn* Enemy = SpawnedEnemies[i];
		if (!Enemy || !Enemy->IsValidLowLevel() || Enemy->IsActorBeingDestroyed())
		{
			SpawnedEnemies.RemoveAtSwap(i);
			continue;
		}

		// Check alive status via SquadAI HealthComponent
		if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(Enemy))
		{
			// S14-COUNT: pooled sleepers get their health RESET by SleepEnemy —
			// a recycled corpse still in this list read as "alive" again, so
			// AliveEnemyCount climbed back up after every kill (HUD remaining
			// count rising on an empty map) and Clear missions could never
			// reach AliveEnemies<=0. A sleeper is hidden with collision off;
			// drop it from tracking (re-Acquire re-adds it).
			if (Enemy->IsHidden() && !Enemy->GetActorEnableCollision())
			{
				SpawnedEnemies.RemoveAtSwap(i);
				continue;
			}
			if (Soldier->IsAlive())
			{
				AliveEnemyCount++;
			}
		}
		else
		{
			// For TPWCS pack enemies, check BPC_HealthAI via reflection
			bool bIsDead = false;
			bool bFoundHealth = false;
			TArray<UActorComponent*> Comps;
			Enemy->GetComponents(Comps);
			for (UActorComponent* C : Comps)
			{
				if (!C) continue;
				if (!C->GetName().Contains(TEXT("BPC_Health"))) continue;

				for (const FName& N : { FName(TEXT("currentHealth")), FName(TEXT("CurrentHealth")) })
				{
					if (FDoubleProperty* DP = FindFProperty<FDoubleProperty>(C->GetClass(), N))
					{
						if (DP->GetPropertyValue_InContainer(C) <= 0.0)
						{
							bIsDead = true;
						}
						bFoundHealth = true;
						break;
					}
					if (FFloatProperty* FP = FindFProperty<FFloatProperty>(C->GetClass(), N))
					{
						if (FP->GetPropertyValue_InContainer(C) <= 0.f)
						{
							bIsDead = true;
						}
						bFoundHealth = true;
						break;
					}
				}
				if (bFoundHealth) break;
			}

			if (bIsDead && Enemy->GetGameTimeSinceCreation() < 14.0f)
			{
				// G-23: TPWCS/pack enemies sometimes expose BPC_HealthAI before it has
				// been initialized, so currentHealth reads as 0 on the first cleanup pass.
				// Do not remove a fresh spawn as "dead" before it has had time to possess,
				// initialize health, and start moving toward the quest zone.
				AliveEnemyCount++;
				continue;
			}

			if (bIsDead)
			{
				if (UEnemyFireteamSubsystem* FT = GetWorld() ? GetWorld()->GetSubsystem<UEnemyFireteamSubsystem>() : nullptr)
				{
					FT->UnregisterMember(Enemy);
				}
				// Collect for broadcast AFTER the loop (avoid redundant MissionZone recalculations)
				NewlyDeadPackEnemies.Add(Enemy);
				SpawnedEnemies.RemoveAtSwap(i);
			}
			else
			{
				AliveEnemyCount++;
			}
		}
	}

	// Broadcast death events AFTER the loop — single recalculation per cleanup cycle.
	// P1-1: also recycle pooled pack members like soldier OnEnemyDied does (Release is a
	// no-op for directly-spawned pawns, so this is safe for both spawn paths).
	for (APawn* DeadEnemy : NewlyDeadPackEnemies)
	{
		OnSpawnerEnemyDied.Broadcast(DeadEnemy);
		if (UWorld* World = GetWorld())
		{
			const float Linger = USquadAITuning::Get() ? USquadAITuning::Get()->CorpseLingerSeconds : 5.f;
			TWeakObjectPtr<APawn> WeakDead(DeadEnemy);
			FTimerHandle PackReleaseTimer;
			World->GetTimerManager().SetTimer(PackReleaseTimer, [World, WeakDead]()
			{
				if (APawn* P = WeakDead.Get())
				{
					if (UEnemyPoolSubsystem* Pool = World->GetSubsystem<UEnemyPoolSubsystem>())
					{
						Pool->Release(P);
					}
				}
			}, Linger, false);
		}
	}
}

// =========================================================================
//  S19-ELITE: commander slot + the shared spawn-and-track path
// =========================================================================
bool AEnemyWaveSpawner::ShouldSpawnCommanderThisWave() const
{
	switch (CommanderWavePolicy)
	{
	case ECommanderWavePolicy::Never:
		return false;
	case ECommanderWavePolicy::FirstWave:
		return CurrentWave == 1;
	case ECommanderWavePolicy::FinalWave:
		// With MaxWaves == 0 (infinite) there is no final wave, so he opens instead -
		// otherwise the policy would silently never fire.
		return (MaxWaves > 0) ? (CurrentWave >= MaxWaves) : (CurrentWave == 1);
	case ECommanderWavePolicy::EveryWave:
		return true;
	default:
		return false;
	}
}

void AEnemyWaveSpawner::SpawnCommanderAndEscorts()
{
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}

	const TSubclassOf<AEnemyCommander> CmdClass = CommanderClass
		? CommanderClass : TSubclassOf<AEnemyCommander>(AEnemyCommander::StaticClass());
	const TSubclassOf<AEnemyCommanderAssistant> AsstClass = AssistantClass
		? AssistantClass : TSubclassOf<AEnemyCommanderAssistant>(AEnemyCommanderAssistant::StaticClass());

	// He arrives at the spawner itself (not on a random ring) so the player sees where the
	// command came from, and so his escorts have a centre to form up on.
	const FVector CmdLoc = GetActorLocation();
	const FRotator CmdRot(0.f, FMath::FRandRange(0.f, 360.f), 0.f);

	APawn* SpawnedPawn = SpawnEnemyOfClass(CmdClass, CmdLoc, CmdRot);
	AEnemyCommander* Commander = Cast<AEnemyCommander>(SpawnedPawn);
	SpawnedCommander = Commander;

	if (!Commander)
	{
		UE_LOG(LogTemp, Error, TEXT("[WaveSpawner] %s: commander wave but no commander spawned (class %s) - the wave runs without one"),
			*GetName(), *GetNameSafe(CmdClass.Get()));
		return;
	}

	int32 Escorts = 0;
	for (int32 i = 0; i < AssistantsPerCommander; ++i)
	{
		const float Ang = (2.f * PI * i) / FMath::Max(1, AssistantsPerCommander);
		const FVector Offset(FMath::Cos(Ang) * 320.f, FMath::Sin(Ang) * 320.f, 0.f);
		if (APawn* EscortPawn = SpawnEnemyOfClass(AsstClass, CmdLoc + Offset, FRotator(0.f, FMath::FRandRange(0.f, 360.f), 0.f)))
		{
			if (AEnemyCommanderAssistant* Assistant = Cast<AEnemyCommanderAssistant>(EscortPawn))
			{
				Assistant->SetCommander(Commander);
				++Escorts;
			}
		}
	}

	UE_LOG(LogTemp, Warning, TEXT("[WaveSpawner] %s: wave %d commander %s spawned with %d/%d assistant(s)"),
		*GetName(), CurrentWave, *Commander->GetName(), Escorts, AssistantsPerCommander);
}

int32 AEnemyWaveSpawner::SpawnReinforcementSquad(int32 Count, const FVector& Around)
{
	UWorld* World = GetWorld();
	if (!World || Count <= 0)
	{
		return 0;
	}

	UWorld* TraceWorld = World;
	TSubclassOf<APawn> SpawnClass = EnemyClass;
	if (!SpawnClass)
	{
		SpawnClass = AEnemySoldier::StaticClass();
	}

	int32 Spawned = 0;
	for (int32 i = 0; i < Count; ++i)
	{
		// Ring around the caller, 4-9 m out: close enough to feel like a response, far
		// enough that nobody spawns inside anybody.
		const float Ang = FMath::FRandRange(0.f, 2.f * PI);
		const float Dist = FMath::FRandRange(400.f, 900.f);
		FVector Loc = Around + FVector(FMath::Cos(Ang) * Dist, FMath::Sin(Ang) * Dist, 0.f);

		// Drop them onto the ground (same trace the wave spawn uses).
		FHitResult Hit;
		FCollisionQueryParams Params;
		Params.AddIgnoredActor(this);
		if (TraceWorld->LineTraceSingleByChannel(Hit, Loc + FVector(0.f, 0.f, 400.f), Loc - FVector(0.f, 0.f, 1500.f), ECC_Visibility, Params))
		{
			Loc = Hit.ImpactPoint + FVector(0.f, 0.f, 90.f);
		}
		else
		{
			Loc.Z += 90.f;
		}

		const FRotator Rot(0.f, FMath::FRandRange(0.f, 360.f), 0.f);
		if (SpawnEnemyOfClass(SpawnClass, Loc, Rot))
		{
			++Spawned;
		}
	}

	UE_LOG(LogTemp, Warning, TEXT("[WaveSpawner] %s: REINFORCEMENTS - %d/%d spawned around %s (alive now %d, wave counter untouched)"),
		*GetName(), Spawned, Count, *Around.ToString(), AliveEnemyCount);

	return Spawned;
}

APawn* AEnemyWaveSpawner::SpawnEnemyOfClass(TSubclassOf<APawn> SpawnClass, const FVector& SpawnLocation, const FRotator& SpawnRotation)
{
	UWorld* World = GetWorld();
	if (!World || !SpawnClass)
	{
		return nullptr;
	}

	APawn* SpawnedEnemy = nullptr;

	// 1. Try acquiring prewarmed enemy from pool (zero GC allocation)
	if (UEnemyPoolSubsystem* Pool = World->GetSubsystem<UEnemyPoolSubsystem>())
	{
		SpawnedEnemy = Pool->Acquire(SpawnClass, SpawnLocation, SpawnRotation);
	}

	// 2. Fallback to direct SpawnActor if pool empty (elite classes are never prewarmed,
	//    so this is the path a commander takes)
	if (!SpawnedEnemy)
	{
		FActorSpawnParameters SpawnParams;
		SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;
		SpawnParams.Owner = this;

		SpawnedEnemy = World->SpawnActor<APawn>(SpawnClass, SpawnLocation, SpawnRotation, SpawnParams);
	}

	if (!SpawnedEnemy)
	{
		return nullptr;
	}

	// ---- bookkeeping: what this spawner produced ----
	SpawnedEnemies.Add(SpawnedEnemy);
	TotalEnemiesSpawned++;
	AliveEnemyCount++;

	BindEnemyDeathDelegate(SpawnedEnemy);

	if (ASoldierCharacter* SpawnedSoldier = Cast<ASoldierCharacter>(SpawnedEnemy))
	{
		// G-23: stop allies/environment/crossfire deleting a wave before it reaches combat.
		// Player-controlled damage remains valid during this window.
		SpawnedSoldier->ResetSpawnGracePeriod(14.0f);
	}

	if (SpawnedEnemy->GetController() == nullptr)
	{
		SpawnedEnemy->SpawnDefaultController();

		// S19-ENEMYST: a pack state tree on this pawn starts before possession and
		// gives up with "Could not find context actor of type Pawn" (tick disabled
		// forever). Rescue it now that the controller exists, and once more shortly
		// after - possession can land a frame later.
		SquadAIRecovery::EnsurePawnStateTreesRunning(SpawnedEnemy, TEXT("wave spawn"));
		if (UWorld* RescueWorld = GetWorld())
		{
			FTimerHandle RescueHandle;
			TWeakObjectPtr<APawn> WeakEnemy(SpawnedEnemy);
			RescueWorld->GetTimerManager().SetTimer(RescueHandle, [WeakEnemy]()
			{
				if (APawn* Enemy = WeakEnemy.Get())
				{
					SquadAIRecovery::EnsurePawnStateTreesRunning(Enemy, TEXT("wave spawn retry"));
				}
			}, 1.5f, false);
		}
	}

	// ---- fireteam ----
	// The commander is a commander: he does not take a slot in the suppressive-fire team.
	bool bJoin = bEnableFireteam;
	if (const AEnemyCommander* AsCommander = Cast<AEnemyCommander>(SpawnedEnemy))
	{
		bJoin = bEnableFireteam && AsCommander->bJoinFireteam;
	}
	else if (const AEnemyPatroller* AsPatroller = Cast<AEnemyPatroller>(SpawnedEnemy))
	{
		// S19-PATROL: a patroller pulled into the suppressive-fire team would be yanked off his
		// beat by the fireteam move goals. He joins only if a designer says so.
		bJoin = bEnableFireteam && AsPatroller->bJoinFireteam;
	}
	if (bJoin)
	{
		TWeakObjectPtr<APawn> WeakEnemy(SpawnedEnemy);
		const uint32 TeamKey = GetUniqueID();
		FTimerHandle JoinHandle;
		World->GetTimerManager().SetTimer(JoinHandle, [WeakEnemy, TeamKey]()
		{
			APawn* P = WeakEnemy.Get();
			if (!P || !P->GetWorld())
			{
				return;
			}
			if (UEnemyFireteamSubsystem* FT = P->GetWorld()->GetSubsystem<UEnemyFireteamSubsystem>())
			{
				FT->RegisterMember(P, TeamKey);
			}
		}, 0.25f, false);
	}

	return SpawnedEnemy;
}

FVector AEnemyWaveSpawner::GetRandomSpawnLocation() const
{
	FVector Origin = GetActorLocation();

	const float Angle = FMath::FRandRange(0.f, 2.f * PI);
	const float Distance = FMath::FRandRange(0.f, SpawnRadius);
	FVector RandomPoint = Origin + FVector(FMath::Cos(Angle) * Distance, FMath::Sin(Angle) * Distance, 0.f);

	UWorld* World = GetWorld();
	if (!World) return RandomPoint;

	// Try NavMesh projection first
	UNavigationSystemV1* NavSys = FNavigationSystem::GetCurrent<UNavigationSystemV1>(World);
	if (NavSys)
	{
		FNavLocation ProjectedLocation;
		if (NavSys->ProjectPointToNavigation(RandomPoint, ProjectedLocation, FVector(500.f, 500.f, 500.f)))
		{
			return ProjectedLocation.Location;
		}
	}

	// Fallback: line trace to ground
	FHitResult Hit;
	FVector TraceStart = RandomPoint + FVector(0, 0, 1000.f);
	FVector TraceEnd = RandomPoint - FVector(0, 0, 5000.f);
	if (World->LineTraceSingleByChannel(Hit, TraceStart, TraceEnd, ECC_WorldStatic))
	{
		return Hit.Location;
	}

	UE_LOG(LogTemp, Warning, TEXT("[WaveSpawner] %s: Spawn location at raw %s (no navmesh or ground found)"),
		*GetName(), *RandomPoint.ToString());
	return RandomPoint;
}

void AEnemyWaveSpawner::BindEnemyDeathDelegate(APawn* Enemy)
{
	if (!Enemy) return;

	// Try SquadAI HealthComponent first
	if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(Enemy))
	{
		if (Soldier->HealthComp)
		{
			// P1-Q1: Remove-before-Add — exactly one owner binding per pooled life.
			Soldier->HealthComp->OnDeath.RemoveDynamic(this, &AEnemyWaveSpawner::OnEnemyDied);
			Soldier->HealthComp->OnDeath.AddDynamic(this, &AEnemyWaveSpawner::OnEnemyDied);
			return;
		}
	}

	// For TPWCS pack enemies, we rely on the CleanupDeadEnemies() polling.
	// The pack doesn't expose a standard OnDeath delegate.
	UE_LOG(LogTemp, Warning, TEXT("[WaveSpawner] %s: Enemy %s is not ASoldierCharacter — death detection via polling only"),
		*GetName(), *GetNameSafe(Enemy));
}

void AEnemyWaveSpawner::UnbindEnemyDeathDelegate(APawn* Enemy)
{
	if (!Enemy) return;
	if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(Enemy))
	{
		if (Soldier->HealthComp)
		{
			Soldier->HealthComp->OnDeath.RemoveDynamic(this, &AEnemyWaveSpawner::OnEnemyDied);
		}
	}
}

void AEnemyWaveSpawner::OnEnemyDied(AActor* DeadActor)
{
	APawn* DeadPawn = Cast<APawn>(DeadActor);
	if (DeadPawn)
	{
		if (UEnemyFireteamSubsystem* FT = GetWorld() ? GetWorld()->GetSubsystem<UEnemyFireteamSubsystem>() : nullptr)
		{
			FT->UnregisterMember(DeadPawn);
		}

		// Recycle back into pool after corpse linger duration
		UWorld* World = GetWorld();
		const float Linger = USquadAITuning::Get()->CorpseLingerSeconds;
		TWeakObjectPtr<APawn> WeakDeadPawn(DeadPawn);

		FTimerHandle ReleaseTimer;
		World->GetTimerManager().SetTimer(ReleaseTimer, [World, WeakDeadPawn]()
		{
			if (APawn* P = WeakDeadPawn.Get())
			{
				if (UEnemyPoolSubsystem* Pool = World->GetSubsystem<UEnemyPoolSubsystem>())
				{
					Pool->Release(P);
				}
				else
				{
					P->Destroy();
				}
			}
		}, Linger, false);
	}
	// S14-COUNT: stop tracking the corpse immediately — it belongs to the pool
	// now. Left in SpawnedEnemies, it resurrected in the books once SleepEnemy
	// reset its health (rising HUD count + Clear mission never completing).
	if (DeadPawn)
	{
		SpawnedEnemies.Remove(DeadPawn);
	}
	AliveEnemyCount = FMath::Max(0, AliveEnemyCount - 1);

	UE_LOG(LogTemp, Verbose, TEXT("[WaveSpawner] %s: Enemy died. Alive: %d/%d. Total spawned: %d"),
		*GetName(), AliveEnemyCount, MaxAliveEnemies, TotalEnemiesSpawned);

	// Fire event for MissionZone to listen to
	OnSpawnerEnemyDied.Broadcast(DeadActor);

	UnbindEnemyDeathDelegate(DeadPawn);
}

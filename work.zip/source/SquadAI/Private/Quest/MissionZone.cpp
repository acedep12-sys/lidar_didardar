// MissionZone.cpp — A single mission point in the world
#include "Quest/MissionZone.h"
#include "Performance/SquadAIRecovery.h"   // S19-DEATHPOSE/S19-PACKALIVE/S19-PACKHP
#include "Diagnostics/SquadAISituationLog.h"   // S19-LOGGER
#include "Quest/QuestChain.h"
#include "Quest/EnemyWaveSpawner.h"
#include "Quest/WaveSpawner.h"
#include "Quest/SabotageTargetActor.h" // S17-SAB
#include "Quest/EscortTargetActor.h"   // S19-ESCORT
#include "Quest/IntelSiteActor.h"      // S19-INTEL
#include "Quest/ExtractionZoneActor.h" // S19-EXFIL
#include "Tactical/MissionClockModel.h" // S19-CLOCK
#include "Quest/MissionBriefingModel.h"   // S23-BRIEF: the staged debrief facts
#include "Quest/MissionStoryModel.h"        // S24-STORY: the war talks back
#include "Tactical/SquadAIRadioChatterSubsystem.h"  // S24-STORY
#include "Tactical/SquadAIAlarmSubsystem.h" // S19-ALARM: the world's shared alarm channel
#include "Quest/CapturePointActor.h"        // S19-CAP
#include "Quest/DefendedAssetActor.h"       // S19-ASSET
#include "Quest/InterdictionDirectorActor.h" // S19-INTERDICT
#include "Tactical/TacticalMortarBarrageActor.h" // S17-SPOT
#include "Quest/SupplyCrateActor.h" // S17-SUPP
#include "HUD/QuestNativeHUD.h" // S17-STORY
#include "GameFramework/SquadAIInventorySubsystem.h"
#include "Components/BoxComponent.h"
#include "Components/StaticMeshComponent.h"
#include "GameFramework/Pawn.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/PlayerController.h"
#include "Components/CapsuleComponent.h"
#include "Characters/SoldierCharacter.h"
#include "Characters/LeaderCharacter.h"
#include "Characters/AllySoldier.h"
#include "AI/SoldierAIController.h"
#include "Components/HealthComponent.h"
#include "Components/StateTreeAIComponent.h"
#include "Performance/SoldierRegistrySubsystem.h"
#include "Kismet/GameplayStatics.h"
#include "EngineUtils.h"
#include "Engine/World.h"
#include "TimerManager.h"
#include "NavigationSystem.h"   // S19-GROUNDRESPAWN (navmesh fallback)
#include "UObject/UnrealType.h"
#include "Performance/SquadAIAudioSubsystem.h"
#include "Performance/SquadAICinematicCombatSubsystem.h"
#include "GameFramework/SquadAIProgressionSubsystem.h"

AMissionZone::AMissionZone()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.bStartWithTickEnabled = false;
	PrimaryActorTick.TickInterval = 0.5f;

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SetRootComponent(SceneRoot);

	TriggerVolume = CreateDefaultSubobject<UBoxComponent>(TEXT("TriggerVolume"));
	TriggerVolume->SetupAttachment(SceneRoot);
	TriggerVolume->SetBoxExtent(FVector(300.f, 300.f, 150.f));
	TriggerVolume->SetCollisionProfileName(TEXT("Trigger"));
	TriggerVolume->SetGenerateOverlapEvents(true);
	TriggerVolume->SetRelativeLocation(FVector(0.f, 0.f, 150.f));

	VisualMarker = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("VisualMarker"));
	VisualMarker->SetupAttachment(SceneRoot);
	VisualMarker->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	VisualMarker->SetRelativeLocation(FVector(0.f, 0.f, 5.f));
	VisualMarker->SetRelativeScale3D(FVector(1.f, 1.f, 0.05f));
	VisualMarker->SetHiddenInGame(true);

#if WITH_EDITORONLY_DATA
	static ConstructorHelpers::FObjectFinder<UStaticMesh> CubeMesh(TEXT("/Engine/BasicShapes/Cube.Cube"));
	if (CubeMesh.Succeeded())
	{
		VisualMarker->SetStaticMesh(CubeMesh.Object);
	}
#endif
}

void AMissionZone::BeginPlay()
{
	Super::BeginPlay();

	TriggerVolume->OnComponentBeginOverlap.AddDynamic(this, &AMissionZone::OnPlayerEnteredZone);
	TriggerVolume->OnComponentEndOverlap.AddDynamic(this, &AMissionZone::OnPlayerLeftZone);

	// S17-POW: freeze linked captives shortly after level start — waits out the
	// AI possession/StartLogic window so the stop isn't overridden.
	if (POWCaptives.Num() > 0 && GetWorld())
	{
		GetWorld()->GetTimerManager().SetTimer(POWFreezeHandle,
			FTimerDelegate::CreateUObject(this, &AMissionZone::FreezePOWCaptives),
			1.0f, false);
	}

	// S20-WP: with World Partition, a far mission's cell streams in LONG after its
	// chain began - the chain's one-shot discovery never saw it, so it would stay
	// orphaned and the campaign would end without it. Register with the live chain
	// now; the chain sorts it in and starts it when its act comes up.
	if (OwningChain == nullptr)
	{
		AQuestChain::AdoptOrphanZone(this);
	}
}

void AMissionZone::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (MissionState != EMissionZoneState::Active) return;

	// S19-CLOCK: the clock applies to EVERY mission type, so it runs before the
	// per-type switch - and it can end the mission, which is why the state is
	// re-tested immediately afterwards.
	TickMissionClock(DeltaTime);
	if (MissionState != EMissionZoneState::Active) return;

	// S19-ALARM: poll the world alarm channel - the ghost record and the fail-on-
	// full-alarm rule are zone concerns, and polling cannot leak a binding on reset.
	TickMissionAlarm();   // S19-ALARM
	if (MissionState != EMissionZoneState::Active) return;

	UpdatePOWRescue(DeltaTime); // S17-POW (no-op when no captives linked)

	switch (MissionType)
	{
	case EMissionType::Reach:
		break;

	case EMissionType::Clear:
		// OPTIMIZATION: Clear completion is now event-driven via spawner delegates.
		// This poll is a safety net only — should rarely trigger.
		if (!bEventDrivenClearCheck)
		{
			CheckClearCompletion();
		}
		break;

	case EMissionType::Defend:
		DefendTimeRemaining -= DeltaTime;
		if (DefendTimeRemaining <= 0.f)
		{
			DefendTimeRemaining = 0.f;
			CompleteMission();
			return;
		}
		// S17-HOLD: line-overrun pressure — enemies holding the zone fail the defense.
		if (bFailIfOverrun)
		{
			OverrunCheckAccum += DeltaTime;
			if (OverrunCheckAccum >= 0.5f)
			{
				OverrunCheckAccum = 0.f;
				const int32 NearCount = CountLivingHostilesNear(GetActorLocation(), OverrunRadius);
				if (NearCount >= OverrunEnemyCount)
				{
					OverrunSeconds += 0.5f;
					if (!bOverrunWarningActive)
					{
						bOverrunWarningActive = true;
						OnMissionAlert.Broadcast(this, TEXT("OverrunWarning"));
						UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: LINE UNDER PRESSURE — %d hostiles inside %.0f m (fail in %.0f s unless pushed back)"),
							*GetName(), NearCount, OverrunRadius / 100.f, FMath::Max(0.f, OverrunGraceTime - OverrunSeconds));
					}
					if (OverrunSeconds >= OverrunGraceTime)
					{
						UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: LINE OVERRUN — defense failed."), *GetName());
						FailMission();
						return;
					}
				}
				else
				{
					OverrunSeconds = FMath::Max(0.f, OverrunSeconds - 1.0f); // pressure decays 2x as fast as it builds
					if (bOverrunWarningActive && OverrunSeconds <= 0.f)
					{
						bOverrunWarningActive = false;
						OnMissionAlert.Broadcast(this, TEXT("OverrunCleared"));
						UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: line pressure cleared."), *GetName());
					}
				}
			}
		}
		break;
	}

	UpdateProgress();
}

void AMissionZone::ActivateMission()
{
	if (MissionState == EMissionZoneState::Active || MissionState == EMissionZoneState::Completed) return;

	SetMissionState(EMissionZoneState::Active);
	SetActorTickEnabled(true);
	TotalEnemiesSpawned = 0;

	// Save player position for restore on fail
	if (APawn* P = UGameplayStatics::GetPlayerPawn(GetWorld(), 0))
	{
		SavedPlayerLocation = P->GetActorLocation();
		SavedPlayerRotation = P->GetActorRotation();

		// S19-PACKHP: mission start is the one moment we know the player must be at
		// full, sane health. A pack health component left above its own maxHealth
		// (observed: 1998 / 100) makes every enemy bullet look like it missed --
		// the bar cannot move until health drops below the max. Clamp it here, and
		// leave a breadcrumb so the next log shows exactly what was wrong.
		FString ClampWhy;
		if (SquadAIRecovery::ClampPackHealthToMax(P, &ClampWhy))
		{
			UE_LOG(LogTemp, Warning, TEXT("[MissionZone] S19-PACKHP at mission start: %s"), *ClampWhy);
		}
	}
	AliveEnemies = 0;
	bAllSpawnersDone = false;
	DefendWaveCount = 0;
	LastBroadcastProgress = -1.f;
	OverrunSeconds = 0.f;          // S17-HOLD
	OverrunCheckAccum = 0.f;       // S17-HOLD
	bOverrunWarningActive = false; // S17-HOLD
	BindSabotageTargets();         // S17-SAB (also resets each target)
	BindSupplyCrates();            // S17-SUPP (also resets each crate)
	BindPOWCaptives();             // S17-POW (re-freezes unfreed captives)
	ComputeAndResetScore();        // S19-SCORE: every attempt scores fresh
	BindEscort();                  // S19-ESCORT (also revives a dead convoy)
	BindIntelSites();              // S19-INTEL (also resets every site)
	BindExtraction();              // S19-EXFIL (also resets the pad)
	BindCaptureAndAssetAndInterdiction(); // S19-CAP/ASSET/INTERDICT
	bEscortArrived = false;
	bEscortDead = false;
	bExtractionReady = false;
	bClockWarned = false;
	bClockExpired = false;
	ElapsedActiveSeconds = 0.f;
	TimeLimitRemaining = FMath::Max(0.f, TimeLimitSeconds);

	++ActivationCount;

	BindPlayerDeathDelegate();

	// S19-REGROUP: ActivationCount 2+ means a failed attempt is being restarted.
	// RespawnPlayer() has already put the player back at the zone's respawn point; bring
	// the squad with him, otherwise the leader is left standing wherever he was when the
	// player died (live log: 154 m away, halted, reading as "the leader stopped following").
	if (ActivationCount > 1)
	{
		RegroupSquadAtRespawn();
	}

	// S17-STORY: show this zone's briefing card (held until the player leaves
	// the deployment screen, so it is never wasted under the veil).
	if (!MissionBriefingTitle.IsEmpty() || !MissionBriefingText.IsEmpty())
	{
		if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this))
		{
			HUD->ShowStoryCard(MissionBriefingTitle, MissionBriefingText, MissionBriefingDuration);
		}
	}
	// S24-STORY: the briefing card lands, and command opens the act on the
	// radio - the story walks into the fight with the player. FIRST activation
	// only: a respawn re-activation re-briefs the card, but command does not
	// re-open the act twice.
	if (ActivationCount == 1)
	{
		BroadcastStoryBeat((uint8)EMissionStoryEvent::ActOpened);
	}

	UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s activated: Type=%s, Description='%s'"),
		*GetName(),
		MissionType == EMissionType::Reach ? TEXT("Reach") :
		MissionType == EMissionType::Clear ? TEXT("Clear") : TEXT("Defend"),
		*MissionDescription.ToString());

	switch (MissionType)
	{
	case EMissionType::Reach:
	{
		MissionProgress = 0.f;
		APawn* Player = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
		if (Player && TriggerVolume)
		{
			TArray<AActor*> OverlappingActors;
			TriggerVolume->GetOverlappingActors(OverlappingActors, APawn::StaticClass());
			for (AActor* A : OverlappingActors)
			{
				APawn* P = Cast<APawn>(A);
				if (P && P->IsPlayerControlled())
				{
					bPlayerInZone = true;
					CompleteMission();
					return;
				}
			}
		}
		break;
	}

	case EMissionType::Clear:
	{
		BindSpawnerEvents();
		if (LinkedSpawners.Num() == 0 && LinkedTemplateSpawners.Num() == 0)
		{
			// No spawners — nothing to clear, complete immediately
			CompleteMission();
			return;
		}
		ActivateLinkedSpawners();
		ArmHVTDesignation(); // S17-HVT
		ArmSpotterDesignation(); // S17-SPOT
		break;
	}

	case EMissionType::Defend:
	{
		DefendTimeRemaining = DefendDuration;
		BindSpawnerEvents();
		ActivateLinkedSpawners();
		ArmSpotterDesignation(); // S17-SPOT

		if (GetWorld() && DefendWaveInterval > 0.f)
		{
			GetWorld()->GetTimerManager().SetTimer(DefendWaveTimerHandle,
				FTimerDelegate::CreateUObject(this, &AMissionZone::OnDefendWaveTimerExpired),
				DefendWaveInterval, true);
		}
		break;
	}
	}
}

void AMissionZone::OnDefendWaveTimerExpired()
{
	if (MissionState != EMissionZoneState::Active) return;
	DefendWaveCount++;
	ScoreState.Add(EMissionScoreEvent::DefendWaveSurvived); // S19-SCORE
	UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: Defend wave %d"), *GetName(), DefendWaveCount);
	ActivateLinkedSpawners();
}

// ===== S17-HOLD =====
int32 AMissionZone::CountLivingHostilesNear(const FVector& Center, float Radius) const
{
	int32 Count = 0;
	const float RadiusSq = Radius * Radius;
	UWorld* World = GetWorld();
	if (!World) return 0;
	for (TActorIterator<ASoldierCharacter> It(World); It; ++It)
	{
		const ASoldierCharacter* S = *It;
		if (!S || !S->IsEnemy() || !S->IsAlive()) continue;
		const FVector Loc = S->GetActorLocation();
		if (Loc.Z < -9000.f) continue; // pooled sleeper (parked at Z=-10000)
		if (FVector::DistSquared2D(Loc, Center) <= RadiusSq) Count++;
	}
	return Count;
}

// ===== S17-CNTR =====
bool AMissionZone::AreAllMissionZonesCompleted() const
{
	UWorld* World = GetWorld();
	if (!World) return false;
	for (TActorIterator<AMissionZone> It(World); It; ++It)
	{
		if (*It && It->MissionState != EMissionZoneState::Completed) return false;
	}
	return true;
}

void AMissionZone::LaunchCounterattack()
{
	if (MissionState != EMissionZoneState::Completed || !GetWorld()) return;
	if (AreAllMissionZonesCompleted())
	{
		UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: counterattack cancelled — campaign complete (S14-END rule)."), *GetName());
		return;
	}
	bCounterattackLaunched = true;
	OnMissionAlert.Broadcast(this, TEXT("CounterattackIncoming"));
	BroadcastStoryBeat((uint8)EMissionStoryEvent::Counterattack);   // S24-STORY: hold what you bled for
	UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: COUNTERATTACK — enemy forces are moving to retake the zone!"), *GetName());
	ActivateLinkedSpawners();
	GetWorld()->GetTimerManager().SetTimer(CounterattackStopHandle,
		FTimerDelegate::CreateUObject(this, &AMissionZone::StopCounterattack),
		FMath::Max(5.f, CounterattackDuration), false);
}

void AMissionZone::StopCounterattack()
{
	DeactivateLinkedSpawners();
	OnMissionAlert.Broadcast(this, TEXT("CounterattackSpawningEnded"));
	UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: counterattack spawning ended — mop up the remaining hostiles."), *GetName());
}

// ===== S17-HVT =====
void AMissionZone::ArmHVTDesignation()
{
	if (!bHVTHunt || !GetWorld()) return;
	ResetHVTState();
	// Poll until a candidate exists (spawners need a few seconds to populate).
	GetWorld()->GetTimerManager().SetTimer(HVTSelectHandle,
		FTimerDelegate::CreateUObject(this, &AMissionZone::TryDesignateHVT),
		3.f, true, 4.f);
}

void AMissionZone::ResetHVTState()
{
	if (ASoldierCharacter* Old = HVTTarget.Get())
	{
		if (Old->HealthComp)
		{
			Old->HealthComp->OnDeath.RemoveDynamic(this, &AMissionZone::OnHVTDied);
		}
	}
	HVTTarget = nullptr;
	bHVTDesignated = false;
	bHVTDead = false;
	if (GetWorld())
	{
		GetWorld()->GetTimerManager().ClearTimer(HVTSelectHandle);
		GetWorld()->GetTimerManager().ClearTimer(HVTEscapeHandle);
	}
}

void AMissionZone::TryDesignateHVT()
{
	if (MissionState != EMissionZoneState::Active || bHVTDesignated || !GetWorld())
	{
		if (GetWorld()) GetWorld()->GetTimerManager().ClearTimer(HVTSelectHandle);
		return;
	}
	// Nearest living hostile to the zone becomes the officer.
	ASoldierCharacter* Best = nullptr;
	float BestDistSq = MAX_flt;
	const FVector Center = GetActorLocation();
	for (TActorIterator<ASoldierCharacter> It(GetWorld()); It; ++It)
	{
		ASoldierCharacter* S = *It;
		if (!S || !S->IsEnemy() || !S->IsAlive() || !S->HealthComp) continue;
		if (S->GetActorLocation().Z < -9000.f) continue; // pooled sleeper
		const float DistSq = FVector::DistSquared2D(S->GetActorLocation(), Center);
		if (DistSq < BestDistSq) { BestDistSq = DistSq; Best = S; }
	}
	if (!Best) return; // keep polling

	HVTTarget = Best;
	bHVTDesignated = true;
	GetWorld()->GetTimerManager().ClearTimer(HVTSelectHandle);

	// Officer buff: tougher, and his death is what the mission is about.
	Best->HealthComp->MaxHealth *= FMath::Max(1.f, HVTHealthMultiplier);
	Best->HealthComp->CurrentHealth = Best->HealthComp->MaxHealth;
	Best->HealthComp->OnDeath.AddDynamic(this, &AMissionZone::OnHVTDied);

	int32 Guards = 0;
	if (bBuffBodyguards)
	{
		const float GuardRadiusSq = HVTBodyguardRadius * HVTBodyguardRadius;
		for (TActorIterator<ASoldierCharacter> It(GetWorld()); It; ++It)
		{
			ASoldierCharacter* S = *It;
			if (!S || S == Best || !S->IsEnemy() || !S->IsAlive() || !S->HealthComp) continue;
			if (S->GetActorLocation().Z < -9000.f) continue;
			if (FVector::DistSquared2D(S->GetActorLocation(), Best->GetActorLocation()) > GuardRadiusSq) continue;
			S->HealthComp->MaxHealth *= FMath::Max(1.f, BodyguardHealthMultiplier);
			S->HealthComp->CurrentHealth = S->HealthComp->MaxHealth;
			Guards++;
		}
	}

	if (HVTEscapeTime > 0.f)
	{
		GetWorld()->GetTimerManager().SetTimer(HVTEscapeHandle,
			FTimerDelegate::CreateUObject(this, &AMissionZone::OnHVTEscapeTimeout),
			HVTEscapeTime, false);
	}

	OnMissionAlert.Broadcast(this, TEXT("HVTDesignated"));
	UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: HVT designated — '%s' (%s), health x%.1f, %d bodyguards toughened%s"),
		*GetName(),
		HVTName.IsEmpty() ? TEXT("Enemy Officer") : *HVTName.ToString(),
		*Best->GetName(), HVTHealthMultiplier, Guards,
		HVTEscapeTime > 0.f ? *FString::Printf(TEXT(", escapes in %.0f s"), HVTEscapeTime) : TEXT(""));
}

void AMissionZone::OnHVTDied(AActor* OwnerActor)
{
	if (!bHVTDesignated || bHVTDead) return;
	bHVTDead = true;
	if (GetWorld())
	{
		GetWorld()->GetTimerManager().ClearTimer(HVTEscapeHandle);
	}
	if (ASoldierCharacter* Old = HVTTarget.Get())
	{
		if (Old->HealthComp)
		{
			Old->HealthComp->OnDeath.RemoveDynamic(this, &AMissionZone::OnHVTDied);
		}
	}
	OnMissionAlert.Broadcast(this, TEXT("HVTEliminated"));
	UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: HVT '%s' ELIMINATED."), *GetName(),
		HVTName.IsEmpty() ? TEXT("Enemy Officer") : *HVTName.ToString());
	if (bCompleteOnHVTKill && MissionState == EMissionZoneState::Active)
	{
		CompleteMission();
	}
}

void AMissionZone::OnHVTEscapeTimeout()
{
	if (MissionState != EMissionZoneState::Active || bHVTDead) return;
	OnMissionAlert.Broadcast(this, TEXT("HVTEscaped"));
	UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: HVT '%s' ESCAPED — mission failed."), *GetName(),
		HVTName.IsEmpty() ? TEXT("Enemy Officer") : *HVTName.ToString());
	FailMission();
}

// ===== S17-SAB =====
bool AMissionZone::AreAllSabotageTargetsDetonated() const
{
	for (const TObjectPtr<ASabotageTargetActor>& T : SabotageTargets)
	{
		if (T && !T->IsDetonated()) return false;
	}
	return true;
}

void AMissionZone::BindSabotageTargets()
{
	for (const TObjectPtr<ASabotageTargetActor>& T : SabotageTargets)
	{
		if (!T) continue;
		T->ResetTarget();
		T->OnDetonated.RemoveDynamic(this, &AMissionZone::OnSabotageTargetDetonated);
		T->OnDetonated.AddDynamic(this, &AMissionZone::OnSabotageTargetDetonated);
	}
}

void AMissionZone::UnbindSabotageTargets()
{
	for (const TObjectPtr<ASabotageTargetActor>& T : SabotageTargets)
	{
		if (!T) continue;
		T->OnDetonated.RemoveDynamic(this, &AMissionZone::OnSabotageTargetDetonated);
		T->ResetTarget();
	}
}

void AMissionZone::OnSabotageTargetDetonated(ASabotageTargetActor* Target)
{
	if (MissionState != EMissionZoneState::Active) return;
	ScoreState.Add(EMissionScoreEvent::SabotagePlanted);   // S19-SCORE
	// S19-ALARM: a demolition charge going off mid-base is heard (30 m witness radius).
	if (USquadAIAlarmSubsystem* AlarmSys = USquadAIAlarmSubsystem::Get(this))
	{
		AlarmSys->RaiseEvent(EMissionAlarmEvent::SabotageTriggered,
			Target ? Target->GetActorLocation() : GetActorLocation(), 3000.f);
	}
	OnMissionAlert.Broadcast(this, TEXT("SabotageChargeDetonated"));

	int32 Remaining = 0;
	for (const TObjectPtr<ASabotageTargetActor>& T : SabotageTargets)
	{
		if (T && !T->IsDetonated()) Remaining++;
	}
	UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: demolition target destroyed — %d remaining."), *GetName(), Remaining);
	if (Remaining > 0) return;

	OnMissionAlert.Broadcast(this, TEXT("SabotageComplete"));
	// All charges blown — drive the type-appropriate completion re-check:
	// Reach completes now; Clear re-checks enemies; Defend's own timer tick
	// keeps retrying CompleteMission once time is up (gate now passes).
	switch (MissionType)
	{
	case EMissionType::Clear:
		CheckClearCompletion();
		break;
	case EMissionType::Defend:
		break;
	default:
		CompleteMission();
		break;
	}
}

// ===== S17-SPOT =====
void AMissionZone::ArmSpotterDesignation()
{
	if (!bArtillerySpotter || !GetWorld()) return;
	ResetSpotterState();
	GetWorld()->GetTimerManager().SetTimer(SpotterSelectHandle,
		FTimerDelegate::CreateUObject(this, &AMissionZone::TryDesignateSpotter),
		3.f, true, 4.f);
}

void AMissionZone::ResetSpotterState()
{
	if (SpotterTarget.IsValid() && SpotterTarget->HealthComp)
	{
		SpotterTarget->HealthComp->OnDeath.RemoveDynamic(this, &AMissionZone::OnSpotterDied);
	}
	SpotterTarget = nullptr;
	bSpotterDesignated = false;
	bSpotterDead = false;
	if (GetWorld())
	{
		GetWorld()->GetTimerManager().ClearTimer(SpotterSelectHandle);
		GetWorld()->GetTimerManager().ClearTimer(SpotterShellHandle);
	}
}

void AMissionZone::TryDesignateSpotter()
{
	if (MissionState != EMissionZoneState::Active || bSpotterDesignated || !GetWorld())
	{
		if (GetWorld()) GetWorld()->GetTimerManager().ClearTimer(SpotterSelectHandle);
		return;
	}
	// Forward observers watch from range: pick the living hostile FARTHEST
	// from the player (never the HVT — two objectives, two men).
	APawn* Player = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	const FVector Ref = Player ? Player->GetActorLocation() : GetActorLocation();
	ASoldierCharacter* Best = nullptr;
	float BestDistSq = -1.f;
	for (TActorIterator<ASoldierCharacter> It(GetWorld()); It; ++It)
	{
		ASoldierCharacter* S = *It;
		if (!S || !S->IsEnemy() || !S->IsAlive() || !S->HealthComp) continue;
		if (S->GetActorLocation().Z < -9000.f) continue; // pooled sleeper
		if (HVTTarget.IsValid() && S == HVTTarget.Get()) continue;
		const float DistSq = FVector::DistSquared2D(S->GetActorLocation(), Ref);
		if (DistSq > BestDistSq) { BestDistSq = DistSq; Best = S; }
	}
	if (!Best) return; // keep polling

	SpotterTarget = Best;
	bSpotterDesignated = true;
	GetWorld()->GetTimerManager().ClearTimer(SpotterSelectHandle);

	Best->HealthComp->MaxHealth *= FMath::Max(1.f, SpotterHealthMultiplier);
	Best->HealthComp->CurrentHealth = Best->HealthComp->MaxHealth;
	Best->HealthComp->OnDeath.AddDynamic(this, &AMissionZone::OnSpotterDied);

	GetWorld()->GetTimerManager().SetTimer(SpotterShellHandle,
		FTimerDelegate::CreateUObject(this, &AMissionZone::FireSpotterBarrage),
		FMath::Max(6.f, SpotterShellingInterval), true, FMath::Max(0.f, SpotterFirstBarrageDelay));

	OnMissionAlert.Broadcast(this, TEXT("SpotterDesignated"));
	UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: enemy ARTILLERY SPOTTER active ('%s') — barrages every %.0f s until he is silenced."),
		*GetName(), *Best->GetName(), SpotterShellingInterval);
}

void AMissionZone::FireSpotterBarrage()
{
	UWorld* World = GetWorld();
	if (!World) return;
	if (MissionState != EMissionZoneState::Active || bSpotterDead
		|| !SpotterTarget.IsValid() || !SpotterTarget->IsAlive())
	{
		World->GetTimerManager().ClearTimer(SpotterShellHandle);
		return;
	}
	APawn* Player = UGameplayStatics::GetPlayerPawn(World, 0);
	if (!Player) return;

	const float Angle = FMath::FRandRange(0.f, 2.f * PI);
	const float Dist = FMath::FRandRange(0.f, SpotterTargetScatter);
	const FVector TargetLoc = Player->GetActorLocation()
		+ FVector(FMath::Cos(Angle) * Dist, FMath::Sin(Angle) * Dist, 0.f);

	FActorSpawnParameters SpawnParams;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	if (ATacticalMortarBarrageActor* Barrage = World->SpawnActor<ATacticalMortarBarrageActor>(
		ATacticalMortarBarrageActor::StaticClass(), TargetLoc, FRotator::ZeroRotator, SpawnParams))
	{
		Barrage->ShellCount = SpotterShellCount;
		Barrage->ShellDamage = SpotterShellDamage;
		Barrage->StartBarrage(TargetLoc); // whistle + HUD danger ring built in
		OnMissionAlert.Broadcast(this, TEXT("IncomingArtillery"));
		UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: spotter called a barrage (%d shells) near the player."),
			*GetName(), SpotterShellCount);
	}
}

void AMissionZone::OnSpotterDied(AActor* OwnerActor)
{
	if (bSpotterDead) return;
	bSpotterDead = true;
	if (SpotterTarget.IsValid() && SpotterTarget->HealthComp)
	{
		SpotterTarget->HealthComp->OnDeath.RemoveDynamic(this, &AMissionZone::OnSpotterDied);
	}
	if (GetWorld())
	{
		GetWorld()->GetTimerManager().ClearTimer(SpotterShellHandle);
	}
	OnMissionAlert.Broadcast(this, TEXT("SpotterEliminated"));
	UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: artillery spotter SILENCED — the shelling stops."), *GetName());
}

// ===== S17-SUPP =====
bool AMissionZone::AreAllSupplyCratesDelivered() const
{
	for (const TObjectPtr<ASupplyCrateActor>& Crate : SupplyCrates)
	{
		if (Crate && !Crate->IsDelivered()) return false;
	}
	return true;
}

void AMissionZone::BindSupplyCrates()
{
	const FVector DeliverLoc = SupplyDeliveryPoint ? SupplyDeliveryPoint->GetActorLocation() : GetActorLocation();
	for (const TObjectPtr<ASupplyCrateActor>& Crate : SupplyCrates)
	{
		if (!Crate) continue;
		Crate->ResetCrate();
		Crate->SetDeliveryTarget(DeliverLoc, SupplyDeliveryRadius);
		Crate->OnPickedUp.RemoveDynamic(this, &AMissionZone::OnSupplyCratePickedUpEvent);
		Crate->OnPickedUp.AddDynamic(this, &AMissionZone::OnSupplyCratePickedUpEvent);
		Crate->OnDelivered.RemoveDynamic(this, &AMissionZone::OnSupplyCrateDeliveredEvent);
		Crate->OnDelivered.AddDynamic(this, &AMissionZone::OnSupplyCrateDeliveredEvent);
	}
}

void AMissionZone::UnbindSupplyCrates()
{
	for (const TObjectPtr<ASupplyCrateActor>& Crate : SupplyCrates)
	{
		if (!Crate) continue;
		Crate->OnPickedUp.RemoveDynamic(this, &AMissionZone::OnSupplyCratePickedUpEvent);
		Crate->OnDelivered.RemoveDynamic(this, &AMissionZone::OnSupplyCrateDeliveredEvent);
		Crate->ResetCrate();
	}
}

void AMissionZone::OnSupplyCratePickedUpEvent(ASupplyCrateActor* Crate)
{
	if (MissionState != EMissionZoneState::Active) return;
	OnMissionAlert.Broadcast(this, TEXT("SupplyCrateTaken"));
}

void AMissionZone::OnSupplyCrateDeliveredEvent(ASupplyCrateActor* Crate)
{
	if (MissionState != EMissionZoneState::Active) return;
	ScoreState.Add(EMissionScoreEvent::SupplyDelivered);   // S19-SCORE
	OnMissionAlert.Broadcast(this, TEXT("SupplyCrateSecured"));

	int32 Remaining = 0;
	for (const TObjectPtr<ASupplyCrateActor>& C : SupplyCrates)
	{
		if (C && !C->IsDelivered()) Remaining++;
	}
	UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: supplies secured — %d crate(s) remaining."), *GetName(), Remaining);
	if (Remaining > 0) return;

	OnMissionAlert.Broadcast(this, TEXT("SupplyRunComplete"));
	// Same type-aware recheck as sabotage: Reach completes, Clear re-checks
	// enemies, Defend's timer tick keeps retrying CompleteMission on its own.
	switch (MissionType)
	{
	case EMissionType::Clear:
		CheckClearCompletion();
		break;
	case EMissionType::Defend:
		break;
	default:
		CompleteMission();
		break;
	}
}

// ===== S17-POW =====
bool AMissionZone::AreAllPOWsFreed() const
{
	for (int32 i = 0; i < POWCaptives.Num(); i++)
	{
		ASoldierCharacter* P = POWCaptives[i];
		if (!P || !P->IsAlive()) continue; // dead/missing captives are lost, not blocking
		if (!POWFreed.IsValidIndex(i) || !POWFreed[i]) return false;
	}
	return true;
}

void AMissionZone::BindPOWCaptives()
{
	if (POWCaptives.Num() == 0) return;
	if (POWFreed.Num() != POWCaptives.Num())
	{
		POWFreed.Init(false, POWCaptives.Num());
	}
	POWFreeProgress.Init(0.f, POWCaptives.Num());
	for (int32 i = 0; i < POWCaptives.Num(); i++)
	{
		ASoldierCharacter* P = POWCaptives[i];
		if (!P || !P->HealthComp) continue;
		P->HealthComp->OnDeath.RemoveDynamic(this, &AMissionZone::OnPOWDied);
		P->HealthComp->OnDeath.AddDynamic(this, &AMissionZone::OnPOWDied);
	}
	FreezePOWCaptives();
}

void AMissionZone::FreezePOWCaptives()
{
	for (int32 i = 0; i < POWCaptives.Num(); i++)
	{
		if (POWFreed.IsValidIndex(i) && POWFreed[i]) continue;
		ASoldierCharacter* P = POWCaptives[i];
		if (!P || !P->IsAlive()) continue;
		if (bPOWsInvulnerableWhileCaptive)
		{
			P->SetCanBeDamaged(false);
		}
		if (ASoldierAIController* AIC = Cast<ASoldierAIController>(P->GetController()))
		{
			if (AIC->StateTreeComp && AIC->StateTreeComp->IsRunning())
			{
				AIC->StateTreeComp->StopLogic(TEXT("Captive"));
			}
		}
		if (UCharacterMovementComponent* CMC = P->GetCharacterMovement())
		{
			CMC->StopMovementImmediately();
			CMC->DisableMovement();
		}
	}
}

void AMissionZone::UpdatePOWRescue(float DeltaTime)
{
	if (POWCaptives.Num() == 0) return;
	APawn* Player = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	if (!Player) return;
	const FVector PL = Player->GetActorLocation();

	for (int32 i = 0; i < POWCaptives.Num(); i++)
	{
		if (POWFreed.IsValidIndex(i) && POWFreed[i]) continue;
		ASoldierCharacter* P = POWCaptives[i];
		if (!P || !P->IsAlive()) continue;
		if (!POWFreeProgress.IsValidIndex(i)) continue;

		const bool bClose = FVector::DistSquared2D(PL, P->GetActorLocation()) <= POWFreeRadius * POWFreeRadius
			&& FMath::Abs(PL.Z - P->GetActorLocation().Z) < 350.f;
		if (bClose)
		{
			if (POWFreeProgress[i] <= 0.f)
			{
				UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: cutting POW '%s' loose — hold position %.1f s"),
					*GetName(), *P->GetName(), POWFreeTime);
			}
			POWFreeProgress[i] += DeltaTime;
			if (POWFreeProgress[i] >= POWFreeTime)
			{
				FreePOW(i);
			}
		}
		else if (POWFreeProgress[i] > 0.f)
		{
			POWFreeProgress[i] = FMath::Max(0.f, POWFreeProgress[i] - DeltaTime * 1.5f);
		}
	}
}

void AMissionZone::FreePOW(int32 Index)
{
	if (!POWCaptives.IsValidIndex(Index) || !POWFreed.IsValidIndex(Index) || POWFreed[Index]) return;
	ASoldierCharacter* P = POWCaptives[Index];
	if (!P) return;
	POWFreed[Index] = true;

	P->SetCanBeDamaged(true);
	if (UCharacterMovementComponent* CMC = P->GetCharacterMovement())
	{
		CMC->SetMovementMode(MOVE_Walking);
	}
	if (ASoldierAIController* AIC = Cast<ASoldierAIController>(P->GetController()))
	{
		if (AIC->StateTreeComp)
		{
			if (!AIC->StateTreeComp->IsRunning())
			{
				AIC->StateTreeComp->StartLogic();
			}
			else
			{
				AIC->StateTreeComp->RestartLogic();
			}
		}
	}
	if (bPOWsFollowPlayer)
	{
		if (AAllySoldier* Ally = Cast<AAllySoldier>(P))
		{
			Ally->LeaderOverride = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
		}
	}

	ScoreState.Add(EMissionScoreEvent::POWRescued);        // S19-SCORE
	OnMissionAlert.Broadcast(this, TEXT("POWFreed"));
	int32 Remaining = 0;
	for (int32 i = 0; i < POWCaptives.Num(); i++)
	{
		ASoldierCharacter* C = POWCaptives[i];
		if (!C || !C->IsAlive()) continue;
		if (!POWFreed.IsValidIndex(i) || !POWFreed[i]) Remaining++;
	}
	UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: POW '%s' FREED — %d captive(s) remaining."),
		*GetName(), *P->GetName(), Remaining);
	if (Remaining > 0) return;

	OnMissionAlert.Broadcast(this, TEXT("AllPOWsFreed"));
	switch (MissionType)
	{
	case EMissionType::Clear:
		CheckClearCompletion();
		break;
	case EMissionType::Defend:
		break;
	default:
		CompleteMission();
		break;
	}
}

void AMissionZone::OnPOWDied(AActor* OwnerActor)
{
	if (MissionState != EMissionZoneState::Active) return;
	// Only a CAPTIVE dying fails the rescue — a freed man is a soldier again.
	for (int32 i = 0; i < POWCaptives.Num(); i++)
	{
		if (POWCaptives[i] != OwnerActor) continue;
		if (POWFreed.IsValidIndex(i) && POWFreed[i]) return;
		ScoreState.Add(EMissionScoreEvent::FriendlyDeath); // S19-SCORE
		OnMissionAlert.Broadcast(this, TEXT("POWKilled"));
		UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: POW '%s' was KILLED while captive — mission failed."),
			*GetName(), *GetNameSafe(OwnerActor));
		if (bFailOnPOWDeath)
		{
			FailMission();
		}
		return;
	}
}

void AMissionZone::CompleteMission()
{
	if (MissionState != EMissionZoneState::Active) return;

	// S17-HVT: the officer must be dead before this zone can complete — covers
	// every completion path (poll, spawner events, no-spawner shortcut).
	if (bHVTHunt && bHVTDesignated && !bHVTDead && HVTTarget.IsValid())
	{
		UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: area clear but the OFFICER still lives — completion held."), *GetName());
		return;
	}

	// S17-SAB: every linked demolition target must be destroyed first.
	if (!AreAllSabotageTargetsDetonated())
	{
		UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: objectives standing — demolition charges still pending, completion held."), *GetName());
		return;
	}

	// S17-SUPP: every linked supply crate must reach the delivery point first.
	if (!AreAllSupplyCratesDelivered())
	{
		UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: supplies still in the field — completion held."), *GetName());
		return;
	}

	// S17-POW: no completion while a living captive is still tied up.
	if (!AreAllPOWsFreed())
	{
		UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: prisoners still in enemy hands — completion held."), *GetName());
		return;
	}
	// S19-ESCORT: the convoy has to be there.
	if (!AreEscortGatesMet())
	{
		UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: the convoy has not arrived — completion held."), *GetName());
		return;
	}
	// S19-INTEL: every linked site has to have reported.
	if (!AreAllIntelSitesReported())
	{
		UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: intel still incomplete — completion held."), *GetName());
		return;
	}
	// S19-CAP: every linked capture point must be HELD (captured and held through
	// its hold phase). Losing one back re-opens this gate - the lost handler says so.
	if (!AreAllCapturePointsHeld())
	{
		UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: a capture point is not held - completion held."), *GetName());
		return;
	}
	// S19-INTERDICT: the courier run's own quota decides.
	if (!IsInterdictionGateMet())
	{
		UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: the interdiction quota is not met - completion held."), *GetName());
		return;
	}
	// S19-EXFIL: LAST, because this gate does not block - it ARMS the pad, and the
	// mission is completed by OnExtractionReadyEvent re-entering this function.
	if (!IsExtractionGateMet())
	{
		ArmExtractionIfPresent();
		OnMissionAlert.Broadcast(this, TEXT("ExtractionAvailable"));
		UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: primary objective done — hold the extraction pad to finish."), *GetName());
		SquadAISituation::Note(FString::Printf(
			TEXT("MISSION %s: primary objective done, extraction armed - hold the pad."), *GetName()));
		return;
	}

	UnbindPlayerDeathDelegate();
	UnbindSpawnerEvents();
	UnbindEscort();                // S19-ESCORT
	UnbindIntelSites();            // S19-INTEL
	UnbindExtraction();            // S19-EXFIL
	UnbindCaptureAndAssetAndInterdiction(); // S19-CAP/ASSET/INTERDICT
	DeactivateLinkedSpawners();

	if (GetWorld())
	{
		GetWorld()->GetTimerManager().ClearTimer(DefendWaveTimerHandle);
		GetWorld()->GetTimerManager().ClearTimer(PlayerDeathPollHandle);
	}

	MissionProgress = 1.f;
	// Deep-review fix B4: the reports land BEFORE the state broadcast - a listener
	// (the operation director banks the step's score on this broadcast) must read the
	// FINAL total, completion award and stealth bonus included.
	ReportParAtCompletion();       // S19-CLOCK
	const bool bFirstCompletionPass = !bScoreReported;   // S23-BRIEF: extraction re-enters
	ReportScoreAtCompletion();     // S19-SCORE
	SetMissionState(EMissionZoneState::Completed);
	// S23-BRIEF: the debrief card - the fight is over, say so with the NUMBERS
	// before the chain moves on: the zone's real score, par, grade, clock and
	// ghost record, staged in brass with the grade stamping in. The extraction
	// re-entry runs this path twice BY DESIGN - the card fires on the first
	// pass only, so it never restarts mid-read.
	if (bFirstCompletionPass)
	{
		if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this))
		{
			FMissionDebriefFacts Facts;
			Facts.Title = MissionBriefingTitle.IsEmpty()
				? FString(TEXT("THE ACT"))
				: MissionBriefingTitle.ToString();
			Facts.Score = ScoreState.Total;
			Facts.Par = ScoreState.ParScore;
			Facts.GradeLetter = FMissionScoreModel::GradeLetter(ScoreState.Grade());
			Facts.TimeMMSS = FMissionClockModel::FormatMMSS(ElapsedActiveSeconds);
			const FMissionClockModel::EParVerdict Verdict =
				FMissionClockModel::EvaluatePar(ParTimeSeconds, ElapsedActiveSeconds);
			Facts.bParBeaten = (Verdict == FMissionClockModel::EParVerdict::Beaten);
			Facts.bParMissed = (Verdict == FMissionClockModel::EParVerdict::Missed);
			Facts.bGhost = ScoreState.bStealthBonusApplied;
			HUD->ShowDebriefCard(Facts.Title, Facts);
		}
	}
	// P1-4: encounter-owned last-kill moment — the zone is the only one that knows the
	// FINAL hostile is down (per-kill callers always passed false, so slow-mo never fired).
	if (MissionType == EMissionType::Clear)
	{
		if (USquadAICinematicCombatSubsystem* CineSys = USquadAICinematicCombatSubsystem::Get(this))
		{
			CineSys->NotifyEnemyEliminated(nullptr, false, true);
		}
	}
	SetActorTickEnabled(false);

	// Award repeatable Player Progression XP on quest completion
	if (USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(this))
	{
		Prog->AwardQuestCompletionXP(GetFName(), 800);
	}

	// S17-CNTR: schedule a one-shot counterattack on the zone just taken.
	// Skipped when the campaign is already fully complete (S14-END rule).
	if (bCounterattackAfterComplete && !bCounterattackLaunched && GetWorld() && !AreAllMissionZonesCompleted())
	{
		GetWorld()->GetTimerManager().SetTimer(CounterattackStartHandle,
			FTimerDelegate::CreateUObject(this, &AMissionZone::LaunchCounterattack),
			FMath::Max(3.f, CounterattackDelay), false);
		UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: counterattack scheduled in %.0f s."), *GetName(), FMath::Max(3.f, CounterattackDelay));
	}

	UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s COMPLETED: '%s'"),
		*GetName(), *MissionDescription.ToString());
}

void AMissionZone::SilentResetForLoadRestore()
{
	UnbindPlayerDeathDelegate();
	UnbindSpawnerEvents();
	UnbindEscort();                // S19-ESCORT
	UnbindIntelSites();            // S19-INTEL
	UnbindExtraction();            // S19-EXFIL
	UnbindCaptureAndAssetAndInterdiction(); // S19-CAP/ASSET/INTERDICT
	DeactivateLinkedSpawners();

	if (GetWorld())
	{
		GetWorld()->GetTimerManager().ClearTimer(DefendWaveTimerHandle);
		GetWorld()->GetTimerManager().ClearTimer(PlayerDeathPollHandle);
	}

	if (GetWorld())
	{
		GetWorld()->GetTimerManager().ClearTimer(CounterattackStartHandle); // S17-CNTR
		GetWorld()->GetTimerManager().ClearTimer(CounterattackStopHandle);  // S17-CNTR
	}
	SetActorTickEnabled(false);
	// Direct writes: no state-change broadcast (the chain is being rebuilt manually).
	MissionState = EMissionZoneState::Locked;
	MissionProgress = 0.f;
	AliveEnemies = 0;
	bAllSpawnersDone = false;
	OverrunSeconds = 0.f;          // S17-HOLD
	OverrunCheckAccum = 0.f;       // S17-HOLD
	bOverrunWarningActive = false; // S17-HOLD
	bCounterattackLaunched = false; // S17-CNTR
	ResetHVTState();               // S17-HVT
	ResetSpotterState();           // S17-SPOT
	UnbindSabotageTargets();       // S17-SAB
	UnbindSupplyCrates();          // S17-SUPP
	UnbindEscort();                // S19-ESCORT
	UnbindIntelSites();            // S19-INTEL
	UnbindExtraction();            // S19-EXFIL
	UnbindCaptureAndAssetAndInterdiction(); // S19-CAP/ASSET/INTERDICT
	bEscortArrived = false;
	bEscortDead = false;
	bExtractionReady = false;
	bClockWarned = false;
	bClockExpired = false;
	ElapsedActiveSeconds = 0.f;
	TimeLimitRemaining = 0.f;
	POWFreed.Reset();              // S17-POW (re-init on next activation)
	POWFreeProgress.Reset();       // S17-POW
}

void AMissionZone::FailMission()
{
	if (MissionState != EMissionZoneState::Active) return;

	UnbindPlayerDeathDelegate();
	UnbindSpawnerEvents();
	UnbindEscort();                // S19-ESCORT
	UnbindIntelSites();            // S19-INTEL
	UnbindExtraction();            // S19-EXFIL
	UnbindCaptureAndAssetAndInterdiction(); // S19-CAP/ASSET/INTERDICT
	DeactivateLinkedSpawners();

	if (GetWorld())
	{
		GetWorld()->GetTimerManager().ClearTimer(DefendWaveTimerHandle);
		GetWorld()->GetTimerManager().ClearTimer(PlayerDeathPollHandle);
	}

	SetMissionState(EMissionZoneState::Failed);
	SetActorTickEnabled(false);

	UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s FAILED: '%s'"),
		*GetName(), *MissionDescription.ToString());
}

// S19-MISSIONREVIVE: Respawn must clear the full ragdoll/downed/input state, not just refill health.
void AMissionZone::RespawnPlayer()
{
	APawn* Player = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	if (!Player) return;

	// S19-LOGGER: capture the death state so the log shows what the restore had to fix.
	const FString PoseBeforeRespawn = SquadAISituation::DescribePose(Player);
	const FString HealthBeforeRespawn = SquadAISituation::DescribeHealth(Player);

	const FVector RawRespawnLoc = GetRespawnLocation();
	// S19-GROUNDRESPAWN: the raw point is the trigger volume's centre and can be far
	// above the ground; respawning there dropped the player and the pack's fall damage
	// took the health. Ground it for this pawn.
	const FVector RespawnLoc = GroundLocationFor(Player, RawRespawnLoc);
	const FRotator RespawnRot = Player->GetActorRotation();

	if (ACharacter* Character = Cast<ACharacter>(Player))
	{
		Character->SetLifeSpan(0.f);

		if (!Character->GetController())
		{
			if (APlayerController* PC = Cast<APlayerController>(UGameplayStatics::GetPlayerController(GetWorld(), 0)))
			{
				PC->Possess(Character);
			}
		}

		if (UCapsuleComponent* Capsule = Character->GetCapsuleComponent())
		{
			Capsule->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
		}

		if (UCharacterMovementComponent* CMC = Character->GetCharacterMovement())
		{
			CMC->SetMovementMode(MOVE_Walking);
			CMC->StopMovementImmediately();
		}

		// S19-DEATHPOSE: pack characters own several skeletal meshes; resetting only
		// GetMesh() leaves a secondary ragdoll hidden or simulating at the death
		// transform. More importantly, turning physics off is NOT enough to get the
		// death pose off the body -- the physics blend weight has to be reset and the
		// animation mode re-armed, or the pawn comes back as a body frozen in its
		// last ragdoll pose with the AnimBP no longer driving it.
		TArray<USkeletalMeshComponent*> RespawnMeshes;
		Character->GetComponents<USkeletalMeshComponent>(RespawnMeshes);
		for (USkeletalMeshComponent* Mesh : RespawnMeshes)
		{
			if (!Mesh) continue;
			SquadAIRecovery::RestoreAnimatedPose(Mesh, /*bReinitializeAnim=*/true,
				/*bForceAnimMode=*/(Mesh == Character->GetMesh()));
			Mesh->SetCollisionProfileName(TEXT("CharacterMesh"));
			if (Mesh == Character->GetMesh())
			{
				if (UAnimInstance* Anim = Mesh->GetAnimInstance())
				{
					Anim->StopAllMontages(0.15f);
				}
			}
		}

		// S19-PACKALIVE: and tell the pack itself that this pawn is alive again --
		// clearing our own copy of bIsDead? is not enough for the pack's HUD,
		// stimuli source or its AnimBP death state.
		{
			FString ReviveWhy;
			SquadAIRecovery::RevivePackActor(Player, &ReviveWhy);
			UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: pack revive on respawn -> %s"), *GetName(), *ReviveWhy);
		}
	}

	Player->SetActorLocationAndRotation(RespawnLoc, RespawnRot, false, nullptr, ETeleportType::TeleportPhysics);

	if (APlayerController* PC = Cast<APlayerController>(Player->GetController()))
	{
		Player->EnableInput(PC);
		PC->SetIgnoreMoveInput(false);
		PC->SetIgnoreLookInput(false);
	}

	// S19-LOGGER: before -> after for the revive. If the pose line still shows
	// rag=1 / blend>0 / anim=SingleNode after this, the frozen-death-pose bug is back
	// and this line names the mesh and the flag that did not get reset.
	// (Three separate lines on purpose: one line per fact keeps every line greppable,
	// and a multi-line UE_LOG entry breaks "grep PLAYER-RESPAWN" style debugging.)
	SquadAISituation::Note(FString::Printf(TEXT("PLAYER-RESPAWN (MissionZone::RespawnPlayer) at (%.0f,%.0f,%.0f) raw=(%.0f,%.0f,%.0f)%s"),
		RespawnLoc.X, RespawnLoc.Y, RespawnLoc.Z,
		RawRespawnLoc.X, RawRespawnLoc.Y, RawRespawnLoc.Z,
		(FVector::DistSquared(RawRespawnLoc, RespawnLoc) > 1.f) ? TEXT(" GROUNDED") : TEXT("")));
	SquadAISituation::Note(FString::Printf(TEXT("PLAYER-RESPAWN before hp{%s} pose{%s}"),
		*HealthBeforeRespawn, *PoseBeforeRespawn));
	SquadAISituation::Note(FString::Printf(TEXT("PLAYER-RESPAWN after  hp{%s} pose{%s}"),
		*SquadAISituation::DescribeHealth(Player), *SquadAISituation::DescribePose(Player)));

	if (bResetHealthOnRespawn)
	{
		if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(Player))
		{
			const bool bWasDowned = Soldier->IsDowned();
			if (bWasDowned)
			{
				Soldier->CompleteRevive(this);
			}
			else if (Soldier->HealthComp)
			{
				Soldier->HealthComp->Revive(); // F-G7: Revive (broadcasts) instead of manual flags.
			}
			Soldier->ClearCover();
			if (!bWasDowned)
			{
				Soldier->ResetSpawnGracePeriod();
			}
		}
		RestorePackHealth(Player);
	}

	if (bResetAmmoOnRespawn)
	{
		ResetPlayerAmmo(Player);
	}
}

void AMissionZone::RestartCurrentAttempt()
{
	if (MissionState != EMissionZoneState::Active) return;
	if (bRestartingAttempt) return;
	bRestartingAttempt = true;

	UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: Restarting current attempt — wipe enemies, respawn squad, replay waves"),
		*GetName());

	UnbindPlayerDeathDelegate();

	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(DefendWaveTimerHandle);
		World->GetTimerManager().ClearTimer(RestartAttemptTimer);
	}

	for (AEnemyWaveSpawner* Spawner : LinkedSpawners)
	{
		if (Spawner && Spawner->IsValidLowLevel() && !Spawner->IsActorBeingDestroyed())
		{
			Spawner->ResetSpawner();
		}
	}
	// S5-6: halt template waves during the wipe (replayed via ActivateLinkedSpawners).
	for (AWaveSpawner* TemplateSpawner : LinkedTemplateSpawners)
	{
		if (TemplateSpawner && TemplateSpawner->IsValidLowLevel() && !TemplateSpawner->IsActorBeingDestroyed())
		{
			TemplateSpawner->StopWaves(true);
		}
	}

	TotalEnemiesSpawned = 0;
	AliveEnemies = 0;
	DefendWaveCount = 0;
	MissionProgress = 0.f;
	LastBroadcastProgress = -1.f;
	bAllSpawnersDone = false;
	bEventDrivenClearCheck = false;
	OverrunSeconds = 0.f;          // S17-HOLD
	OverrunCheckAccum = 0.f;       // S17-HOLD
	bOverrunWarningActive = false; // S17-HOLD
	ResetHVTState();               // S17-HVT
	ResetSpotterState();           // S17-SPOT
	BindSabotageTargets();         // S17-SAB (also resets each target)
	BindSupplyCrates();            // S17-SUPP (also resets each crate)
	BindPOWCaptives();             // S17-POW (re-freezes unfreed captives)
	ComputeAndResetScore();        // S19-SCORE: every attempt scores fresh
	BindEscort();                  // S19-ESCORT (also revives a dead convoy)
	BindIntelSites();              // S19-INTEL (also resets every site)
	BindExtraction();              // S19-EXFIL (also resets the pad)
	BindCaptureAndAssetAndInterdiction(); // S19-CAP/ASSET/INTERDICT
	bEscortArrived = false;
	bEscortDead = false;
	bExtractionReady = false;
	bClockWarned = false;
	bClockExpired = false;
	ElapsedActiveSeconds = 0.f;
	TimeLimitRemaining = FMath::Max(0.f, TimeLimitSeconds);
	if (MissionType == EMissionType::Defend)
	{
		DefendTimeRemaining = DefendDuration;
	}

	RespawnSquad();

	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().SetTimer(RestartAttemptTimer,
			FTimerDelegate::CreateUObject(this, &AMissionZone::FinishRestartAttempt),
			0.75f, false);
	}
	else
	{
		FinishRestartAttempt();
	}
}

void AMissionZone::FinishRestartAttempt()
{
	if (MissionState != EMissionZoneState::Active)
	{
		bRestartingAttempt = false;
		return;
	}

	BindPlayerDeathDelegate();

	switch (MissionType)
	{
	case EMissionType::Clear:
		BindSpawnerEvents();
		ActivateLinkedSpawners();
		ArmHVTDesignation(); // S17-HVT
		ArmSpotterDesignation(); // S17-SPOT
		break;
	case EMissionType::Defend:
		DefendTimeRemaining = DefendDuration;
		BindSpawnerEvents();
		ActivateLinkedSpawners();
		ArmSpotterDesignation(); // S17-SPOT
		if (GetWorld() && DefendWaveInterval > 0.f)
		{
			GetWorld()->GetTimerManager().SetTimer(DefendWaveTimerHandle,
				FTimerDelegate::CreateUObject(this, &AMissionZone::OnDefendWaveTimerExpired),
				DefendWaveInterval, true);
		}
		break;
	default:
		break;
	}

	bRestartingAttempt = false;
	UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: Attempt restarted. Waves use original counts/timing."), *GetName());
}

// S19-MISSIONREVIVE: Restore reflected pack HP and clear the pack's death-state flags as well.
void AMissionZone::RestorePackHealth(AActor* Actor)
{
	if (!Actor) return;

	const TArray<FName> DeathFlagNames = {
		FName(TEXT("bIsDead?")), FName(TEXT("bIsDead")), FName(TEXT("bDead?")),
		FName(TEXT("bDead")), FName(TEXT("IsDead")), FName(TEXT("isDead?")), FName(TEXT("isDead"))
	};
	auto ClearPackDeathFlags = [&DeathFlagNames](UObject* Object)
	{
		if (!Object) return;
		for (const FName& FlagName : DeathFlagNames)
		{
			if (FBoolProperty* BoolProp = FindFProperty<FBoolProperty>(Object->GetClass(), FlagName))
			{
				BoolProp->SetPropertyValue_InContainer(Object, false);
			}
		}
	};

	// Some host BPs store their death bool on the pawn; others keep it on BPC_Health.
	ClearPackDeathFlags(Actor);

	TArray<UActorComponent*> Comps;
	Actor->GetComponents(Comps);
	for (UActorComponent* C : Comps)
	{
		if (!C) continue;
		const FString N = C->GetName();
		const FString CN = C->GetClass() ? C->GetClass()->GetName() : FString();
		if (N.Contains(TEXT("HealthComp"))) continue; // Native UHealthComponent is reset through Revive().

		ClearPackDeathFlags(C);
		if (!N.Contains(TEXT("BPC_Health")) && !N.Contains(TEXT("Health")) && !CN.Contains(TEXT("Health")))
		{
			continue;
		}

		double MaxH = 100.0;
		bool bGotMax = false;
		for (const FName& MN : { FName(TEXT("maxHealth")), FName(TEXT("MaxHealth")), FName(TEXT("Max Health")), FName(TEXT("MaxHP")) })
		{
			if (FDoubleProperty* DP = FindFProperty<FDoubleProperty>(C->GetClass(), MN))
			{
				MaxH = DP->GetPropertyValue_InContainer(C);
				bGotMax = true;
				break;
			}
			if (FFloatProperty* FP = FindFProperty<FFloatProperty>(C->GetClass(), MN))
			{
				MaxH = FP->GetPropertyValue_InContainer(C);
				bGotMax = true;
				break;
			}
			if (FIntProperty* IP = FindFProperty<FIntProperty>(C->GetClass(), MN))
			{
				MaxH = static_cast<double>(IP->GetPropertyValue_InContainer(C));
				bGotMax = true;
				break;
			}
		}
		if (!bGotMax) MaxH = 100.0;

		for (const FName& HN : { FName(TEXT("currentHealth")), FName(TEXT("CurrentHealth")), FName(TEXT("Current Health")), FName(TEXT("Health")), FName(TEXT("health")), FName(TEXT("HP")), FName(TEXT("currentHP")), FName(TEXT("CurrentHP")) })
		{
			if (FDoubleProperty* DP = FindFProperty<FDoubleProperty>(C->GetClass(), HN))
			{
				DP->SetPropertyValue_InContainer(C, MaxH);
				break;
			}
			if (FFloatProperty* FP = FindFProperty<FFloatProperty>(C->GetClass(), HN))
			{
				FP->SetPropertyValue_InContainer(C, static_cast<float>(MaxH));
				break;
			}
			if (FIntProperty* IP = FindFProperty<FIntProperty>(C->GetClass(), HN))
			{
				IP->SetPropertyValue_InContainer(C, FMath::RoundToInt(MaxH));
				break;
			}
		}
	}

	// S19-PACKHP: a pack health component can report MORE health than its own
	// maxHealth (seen live: currentHealth 1998.338 / maxHealth 100). Every hit is
	// then real but invisible -- the HUD bar never leaves 100% and the pawn is
	// effectively Nx tougher. The loop above writes maxHealth, so anything above
	// it is stale: clamp it back down and say so.
	FString ClampWhy;
	if (SquadAIRecovery::ClampPackHealthToMax(Actor, &ClampWhy))
	{
		UE_LOG(LogTemp, Warning, TEXT("[MissionZone] S19-PACKHP %s"), *ClampWhy);
	}

	// S19-PACKALIVE: clearing the reflected flags is only half the job -- the pack
	// keeps its own dead state (BPC_Health*) which its HUD, stimuli source and
	// AnimBP read. Run the pack's own "alive again" entry points.
	FString ReviveWhy;
	SquadAIRecovery::RevivePackActor(Actor, &ReviveWhy);
	UE_LOG(LogTemp, Warning, TEXT("[MissionZone] S19-PACKALIVE %s"), *ReviveWhy);
}

// S19-MISSIONREVIVE: Mission retries must use CompleteRevive for downed soldiers, not just reset HealthComp.
void AMissionZone::RevivePawnAt(APawn* Pawn, const FVector& Loc, const FRotator& Rot, bool bIsPlayer)
{
	if (!Pawn) return;

	// S19-LOGGER: capture the death state before the revive (see RespawnPlayer).
	const FString PoseBeforeRevive = SquadAISituation::DescribePose(Pawn);
	const FString HealthBeforeRevive = SquadAISituation::DescribeHealth(Pawn);

	// S19-GROUNDRESPAWN: callers pass formation slots derived from the respawn point, so
	// the same airborne Z would be inherited by the whole squad. Ground it per pawn.
	const FVector RawLoc = Loc;
	const FVector GroundedLoc = GroundLocationFor(Pawn, Loc);

	Pawn->SetLifeSpan(0.f);

	if (ACharacter* Character = Cast<ACharacter>(Pawn))
	{
		if (bIsPlayer && !Character->GetController())
		{
			if (APlayerController* PC = Cast<APlayerController>(UGameplayStatics::GetPlayerController(GetWorld(), 0)))
			{
				PC->Possess(Character);
			}
		}

		if (UCapsuleComponent* Capsule = Character->GetCapsuleComponent())
		{
			Capsule->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
		}

		if (UCharacterMovementComponent* CMC = Character->GetCharacterMovement())
		{
			CMC->SetMovementMode(MOVE_Walking);
			CMC->StopMovementImmediately();
		}

		// G-2: freeze + re-show EVERY skeletal mesh — pack BPs carry extra simulating
		// meshes (CharacterMesh0) that moved through the teleport and stayed hidden.
		// S19-DEATHPOSE: also hand the pose back to the AnimBP (physics blend weight
		// 0 + animation mode re-armed), otherwise a reviving pawn keeps its death pose.
		TArray<USkeletalMeshComponent*> ReviveMeshes;
		Character->GetComponents<USkeletalMeshComponent>(ReviveMeshes);
		for (USkeletalMeshComponent* Mesh : ReviveMeshes)
		{
			if (!Mesh) continue;
			SquadAIRecovery::RestoreAnimatedPose(Mesh, /*bReinitializeAnim=*/true,
				/*bForceAnimMode=*/(Mesh == Character->GetMesh()));
			Mesh->SetCollisionProfileName(TEXT("CharacterMesh"));
			if (Mesh == Character->GetMesh())
			{
				if (UAnimInstance* Anim = Mesh->GetAnimInstance())
				{
					Anim->StopAllMontages(0.15f);
				}
			}
		}
		{
			FString ReviveWhy;
			SquadAIRecovery::RevivePackActor(Pawn, &ReviveWhy);
			UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: pack revive (%s) -> %s"),
				*GetName(), bIsPlayer ? TEXT("player") : TEXT("squad"), *ReviveWhy);
		}

		if (Character->bIsCrouched)
		{
			Character->UnCrouch();
		}
	}

	// S19-LOGGER: before -> after for this revive (pose flags are the answer to
	// "did he come back standing, animated, and not a frozen body").
	SquadAISituation::Note(FString::Printf(TEXT("PAWN-REVIVE (RevivePawnAt, %s) %s at (%.0f,%.0f,%.0f)%s"),
		bIsPlayer ? TEXT("player") : TEXT("squad"), *GetNameSafe(Pawn),
		GroundedLoc.X, GroundedLoc.Y, GroundedLoc.Z,
		(FVector::DistSquared(RawLoc, GroundedLoc) > 1.f)
			? *FString::Printf(TEXT(" GROUNDED from raw Z=%.0f"), RawLoc.Z) : TEXT("")));
	SquadAISituation::Note(FString::Printf(TEXT("PAWN-REVIVE before hp{%s} pose{%s}"),
		*HealthBeforeRevive, *PoseBeforeRevive));
	SquadAISituation::Note(FString::Printf(TEXT("PAWN-REVIVE after  hp{%s} pose{%s}"),
		*SquadAISituation::DescribeHealth(Pawn), *SquadAISituation::DescribePose(Pawn)));

	Pawn->SetActorLocationAndRotation(GroundedLoc, Rot, false, nullptr, ETeleportType::TeleportPhysics);

	if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(Pawn))
	{
		const bool bWasDowned = Soldier->IsDowned();
		if (bWasDowned)
		{
			Soldier->CompleteRevive(this);
		}
		else if (Soldier->HealthComp)
		{
			Soldier->HealthComp->Revive();
		}
		Soldier->ClearCover();
		if (!bWasDowned)
		{
			Soldier->ResetSpawnGracePeriod(); // MEGA-5 (G-5): respawned pawns get spawn protection too.
		}
		if (ASoldierAIController* AIC = Cast<ASoldierAIController>(Soldier->GetController()))
		{
			AIC->StopMovement();
			AIC->Memory.Reset();
			if (AIC->StateTreeComp && !AIC->StateTreeComp->IsRunning())
			{
				AIC->StateTreeComp->StartLogic();
			}
		}
	}

	RestorePackHealth(Pawn);

	if (bIsPlayer)
	{
		if (APlayerController* PC = Cast<APlayerController>(Pawn->GetController()))
		{
			Pawn->EnableInput(PC);
			PC->SetIgnoreMoveInput(false);
			PC->SetIgnoreLookInput(false);
		}
		if (bResetAmmoOnRespawn)
		{
			ResetPlayerAmmo(Pawn);
		}
	}
}

void AMissionZone::RespawnSquad()
{
	UWorld* World = GetWorld();
	if (!World) return;

	APawn* Player = UGameplayStatics::GetPlayerPawn(World, 0);

	FVector Base = GetRespawnLocation();
	if (MissionType == EMissionType::Reach && !SavedPlayerLocation.IsNearlyZero())
	{
		Base = SavedPlayerLocation;
	}
	else
	{
		// S19-GROUNDRESPAWN: GetRespawnLocation() is the trigger volume centre, which can
		// be tens of metres in the air - the whole formation would inherit that Z.
		Base = GroundLocationFor(Player, Base);
	}

	FRotator PlayerRot = SavedPlayerRotation;
	if (Player)
	{
		if (PlayerRot.IsNearlyZero())
		{
			PlayerRot = Player->GetActorRotation();
		}
		RevivePawnAt(Player, Base, PlayerRot, true);
	}

	// The formation itself lives in PlaceSquadFormation() so RegroupSquadAtRespawn()
	// places the squad exactly the same way (S19-REGROUP).
	PlaceSquadFormation(Base, PlayerRot, Player);
}

// S19-REGROUP: the same slots RespawnSquad() has always used - the leader right behind
// the player, the squad in rows facing the same way. Extracted so a restarted mission can
// regroup without reviving/teleporting the player a second time.
int32 AMissionZone::PlaceSquadFormation(const FVector& Base, const FRotator& Rot, AActor* SkipActor)
{
	UWorld* World = GetWorld();
	if (!World) return 0;

	const FVector Fwd = Rot.Vector().GetSafeNormal2D();
	const FVector Right = FVector(-Fwd.Y, Fwd.X, 0.f);
	int32 AllySlot = 0;
	int32 Placed = 0;

	auto PlaceFriendly = [&](ASoldierCharacter* S)
	{
		if (!S || !S->IsAlive() || S == SkipActor) return;
		if (S->IsEnemy()) return;

		FVector Slot = Base;
		if (Cast<ALeaderCharacter>(S))
		{
			Slot = Base - Fwd * 280.f;
		}
		else
		{
			const int32 Row = (AllySlot / 2) + 1;
			const float Side = (AllySlot % 2 == 0) ? 1.f : -1.f;
			Slot = Base - Fwd * (220.f + Row * 180.f) + Right * (Side * Row * 140.f);
			++AllySlot;
		}
		RevivePawnAt(S, Slot, Rot, false);
		++Placed;
	};

	if (USoldierRegistrySubsystem* Reg = World->GetSubsystem<USoldierRegistrySubsystem>())
	{
		for (const TWeakObjectPtr<ASoldierCharacter>& W : Reg->GetAllSoldiers())
		{
			PlaceFriendly(W.Get());
		}
	}
	else
	{
		for (TActorIterator<ASoldierCharacter> It(World); It; ++It)
		{
			PlaceFriendly(*It);
		}
	}
	return Placed;
}

// S19-REGROUP: a failed mission is restarted by re-activating this zone (QuestChain ->
// ActivateMission). RespawnPlayer() teleports the player back to the zone's respawn point,
// but the squad is not moved by anything - so the leader stayed wherever he was when the
// player died. Seen live: the player respawned, the leader was 154 m away and halted
// ("HALT-FOR-PLAYER"), which reads as "the leader stopped following". Pull the squad back
// with the player so the new attempt starts as a squad.
void AMissionZone::RegroupSquadAtRespawn()
{
	UWorld* World = GetWorld();
	if (!World) return;

	APawn* Player = UGameplayStatics::GetPlayerPawn(World, 0);
	const FVector Base = GetGroundedRespawnLocation(Player);
	const FRotator Rot = Player ? Player->GetActorRotation() : SavedPlayerRotation;

	const int32 Placed = PlaceSquadFormation(Base, Rot, Player);

	UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s S19-REGROUP: placed %d squad member(s) at the respawn point (%.0f,%.0f,%.0f)"),
		*GetName(), Placed, Base.X, Base.Y, Base.Z);
	SquadAISituation::Note(FString::Printf(
		TEXT("REGROUP placed %d squad member(s) at the respawn point (%.0f,%.0f,%.0f) - mission %s restart"),
		Placed, Base.X, Base.Y, Base.Z, *GetName()));
}

void AMissionZone::ResetMission()
{
	UnbindPlayerDeathDelegate();
	UnbindSpawnerEvents();
	UnbindEscort();                // S19-ESCORT
	UnbindIntelSites();            // S19-INTEL
	UnbindExtraction();            // S19-EXFIL
	UnbindCaptureAndAssetAndInterdiction(); // S19-CAP/ASSET/INTERDICT
	DeactivateLinkedSpawners();

	for (AEnemyWaveSpawner* Spawner : LinkedSpawners)
	{
		if (Spawner && Spawner->IsValidLowLevel() && !Spawner->IsActorBeingDestroyed())
		{
			Spawner->ResetSpawner();
		}
	}
	// S5-6: AWaveSpawner has no Reset — StopWaves halts timers; StartWaves re-inits.
	for (AWaveSpawner* TemplateSpawner : LinkedTemplateSpawners)
	{
		if (TemplateSpawner && TemplateSpawner->IsValidLowLevel() && !TemplateSpawner->IsActorBeingDestroyed())
		{
			TemplateSpawner->StopWaves(true);
		}
	}

	if (GetWorld())
	{
		GetWorld()->GetTimerManager().ClearTimer(DefendWaveTimerHandle);
		GetWorld()->GetTimerManager().ClearTimer(PlayerDeathPollHandle);
	}

	TotalEnemiesSpawned = 0;
	AliveEnemies = 0;
	DefendWaveCount = 0;
	MissionProgress = 0.f;
	LastBroadcastProgress = -1.f;
	bPlayerInZone = false;
	bAllSpawnersDone = false;
	bEventDrivenClearCheck = false;

	SetMissionState(EMissionZoneState::Locked);
}

// S19-GROUNDRESPAWN ---------------------------------------------------------
// GetRespawnLocation() returns the trigger volume's COMPONENT location, i.e. the centre
// of the box the designer stretched over the objective area. For a volume that is 80 m
// tall, "the respawn point" is 40 m up in the air. The live log shows exactly that:
//
//   [SAI-EVT] PLAYER-RESPAWN ... at (346500,249180,12438)   <- 38 m above the ground
//   [SAI] t=39..41 [BP_PlayerCharacter_C_0] move: mm=3 ... v=1080 -> 1993 -> 3010   <- free fall
//   [SAI] t=42     [BP_PlayerCharacter_C_0] hp: BPC_HealthPlayer 22.6/100.0          <- fall damage
//
// The pack applies fall damage itself (BPC_RagdollMaster/BPC_HealthPlayer), which is why
// the health drop was invisible to SquadAI and read as "weird health".
FVector AMissionZone::GroundLocationFor(const AActor* ForActor, const FVector& Raw) const
{
	UWorld* World = GetWorld();
	if (!World) return Raw;

	// Capsule dimensions of the pawn that will stand there, so it lands ON the ground
	// rather than buried in it.
	float HalfHeight = 88.f;
	if (const ACharacter* AsCharacter = Cast<ACharacter>(ForActor))
	{
		// GetCapsuleComponent() is const-qualified and hands back a non-const pointer;
		// keeping the local non-const means every accessor below is unambiguously callable.
		if (UCapsuleComponent* Capsule = AsCharacter->GetCapsuleComponent())
		{
			HalfHeight = Capsule->GetScaledCapsuleHalfHeight();
		}
	}

	// Straight down from well above the raw point. The volume centre is usually above
	// the ground, but a CustomRespawnLocation can be below it - so the trace starts high
	// and runs a long way down.
	const FVector TraceStart = Raw + FVector(0.f, 0.f, 2000.f);
	const FVector TraceEnd = Raw - FVector(0.f, 0.f, 20000.f);

	FCollisionQueryParams Params(SCENE_QUERY_STAT(MissionRespawnGround), /*bTraceComplex=*/false, ForActor);
	FHitResult Hit;
	if (World->LineTraceSingleByChannel(Hit, TraceStart, TraceEnd, ECC_Visibility, Params))
	{
		return Hit.ImpactPoint + FVector(0.f, 0.f, HalfHeight + 2.f);
	}

	// Nothing solid underneath (or the trace was blocked): ask the navmesh, which knows
	// where a character can actually stand.
	if (UNavigationSystemV1* Nav = FNavigationSystem::GetCurrent<UNavigationSystemV1>(World))
	{
		FNavLocation Projected;
		if (Nav->ProjectPointToNavigation(Raw, Projected, FVector(1000.f, 1000.f, 5000.f)))
		{
			return Projected.Location + FVector(0.f, 0.f, HalfHeight + 2.f);
		}
	}

	// Last resort: the raw point (logged by the callers, so it is visible if it happens).
	return Raw;
}

// ===== S19-HUNT =====
// Sources, in order: the wave spawners this zone is linked to, then the template spawners.
// Both are the same objects the mission's own completion test counts, so "no enemies left
// to hunt" and "mission can complete" can never disagree.
int32 AMissionZone::GetAliveEnemyCount() const
{
	int32 Count = 0;
	for (const TObjectPtr<AEnemyWaveSpawner>& Spawner : LinkedSpawners)
	{
		if (Spawner && Spawner->IsValidLowLevel() && !Spawner->IsActorBeingDestroyed())
		{
			Count += Spawner->CountAliveEnemies();
		}
	}
	for (const TObjectPtr<AWaveSpawner>& TemplateSpawner : LinkedTemplateSpawners)
	{
		if (TemplateSpawner && TemplateSpawner->IsValidLowLevel() && !TemplateSpawner->IsActorBeingDestroyed())
		{
			Count += TemplateSpawner->CountAliveEnemies();
		}
	}
	return Count;
}

bool AMissionZone::HasAliveEnemies() const
{
	// Only an ACTIVE zone hunts: a failed/completed zone must not keep the squad running
	// around after the objective is over.
	if (MissionState != EMissionZoneState::Active) return false;
	return GetAliveEnemyCount() > 0;
}

AActor* AMissionZone::GetNearestAliveEnemy(const FVector& From, float MaxDistance) const
{
	if (MissionState != EMissionZoneState::Active) return nullptr;

	AActor* Best = nullptr;
	float BestDistSq = -1.f;
	const float MaxDistSq = (MaxDistance > 0.f) ? (MaxDistance * MaxDistance) : -1.f;

	auto Consider = [&](APawn* Candidate)
	{
		if (!Candidate || Candidate->IsActorBeingDestroyed()) return;
		const float DistSq = FVector::DistSquared(Candidate->GetActorLocation(), From);
		if (MaxDistSq > 0.f && DistSq > MaxDistSq) return;
		if (BestDistSq < 0.f || DistSq < BestDistSq)
		{
			BestDistSq = DistSq;
			Best = Candidate;
		}
	};

	for (const TObjectPtr<AEnemyWaveSpawner>& Spawner : LinkedSpawners)
	{
		if (Spawner && Spawner->IsValidLowLevel() && !Spawner->IsActorBeingDestroyed())
		{
			Consider(Spawner->GetNearestAliveEnemy(From));
		}
	}
	for (const TObjectPtr<AWaveSpawner>& TemplateSpawner : LinkedTemplateSpawners)
	{
		if (TemplateSpawner && TemplateSpawner->IsValidLowLevel() && !TemplateSpawner->IsActorBeingDestroyed())
		{
			Consider(TemplateSpawner->GetNearestAliveEnemy(From));
		}
	}
	return Best;
}

float AMissionZone::GetHuntPursuitRadius() const
{
	// S19-HUNT3: 0 on the property means "auto" - 600 m, which covers the pack's 500 cm...
	// (500 m) spawn radius and the walk to it. Never smaller than the activation radius.
	const float Auto = 60000.f;
	return FMath::Max(HuntPursuitRadius > 0.f ? HuntPursuitRadius : Auto,
		HuntActivationRadius > 0.f ? HuntActivationRadius : 3000.f);
}

FVector AMissionZone::GetGroundedRespawnLocation(AActor* ForActor) const
{
	return GroundLocationFor(ForActor, GetRespawnLocation());
}

FVector AMissionZone::GetRespawnLocation() const
{
	if (bUseTriggerAsRespawnPoint && TriggerVolume)
	{
		return TriggerVolume->GetComponentLocation();
	}
	return CustomRespawnLocation;
}

FText AMissionZone::GetDisplayBadgeText() const
{
	if (!CustomBadgeText.IsEmpty()) return CustomBadgeText;

	switch (MissionType)
	{
	case EMissionType::Reach:  return FText::FromString(TEXT("REACH"));
	case EMissionType::Clear:  return FText::FromString(TEXT("CLEAR"));
	case EMissionType::Defend: return FText::FromString(TEXT("DEFEND"));
	default: return FText::GetEmpty();
	}
}

void AMissionZone::SetMissionState(EMissionZoneState NewState)
{
	if (MissionState == NewState) return;
	MissionState = NewState;
	OnMissionStateChanged.Broadcast(this, NewState);

	if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
	{
		USoundBase* MusicOverride = (NewState == EMissionZoneState::Active && CustomCombatMusic) ? CustomCombatMusic.Get() : (CustomAmbientMusic ? CustomAmbientMusic.Get() : nullptr);
		AudioSys->NotifyMissionStateChanged(this, static_cast<uint8>(NewState));
		if (MusicOverride)
		{
			AudioSys->CrossfadeMusic(MusicOverride, 2.0f);
		}
	}
}

void AMissionZone::UpdateProgress()
{
	float NewProgress = MissionProgress;

	switch (MissionType)
	{
	case EMissionType::Reach:
		NewProgress = bPlayerInZone ? 1.f : 0.f;
		break;

	case EMissionType::Clear:
		if (TotalEnemiesSpawned > 0)
		{
			const int32 Killed = TotalEnemiesSpawned - AliveEnemies;
			NewProgress = FMath::Clamp(static_cast<float>(Killed) / static_cast<float>(TotalEnemiesSpawned), 0.f, 1.f);
		}
		break;

	case EMissionType::Defend:
		if (DefendDuration > 0.f)
		{
			NewProgress = FMath::Clamp(1.f - (DefendTimeRemaining / DefendDuration), 0.f, 1.f);
		}
		break;
	}

	MissionProgress = NewProgress;

	// Notify audio subsystem of mission progress and enemy count for dynamic music & horde scaling
	if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
	{
		AudioSys->NotifyMissionProgress(this, MissionProgress, DefendTimeRemaining, AliveEnemies);
	}

	// OPTIMIZATION: Only broadcast if progress actually changed (by > 0.5%)
	if (FMath::Abs(NewProgress - LastBroadcastProgress) > 0.005f)
	{
		LastBroadcastProgress = NewProgress;
		OnMissionProgressUpdated.Broadcast(this, MissionProgress);
	}
}

// ===== PLAYER DEATH =====

// S19-PLAYERDEATH: Retry a late player-pawn spawn instead of leaving the active mission without a death owner.
void AMissionZone::BindPlayerDeathDelegate()
{
	if (!GetWorld()) return;
	APawn* Player = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	if (!Player)
	{
		GetWorld()->GetTimerManager().SetTimer(PlayerDeathPollHandle,
			FTimerDelegate::CreateUObject(this, &AMissionZone::BindPlayerDeathDelegate),
			0.25f, false);
		return;
	}

	// Try SquadAI health component first
	if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(Player))
	{
		if (Soldier->HealthComp)
		{
			Soldier->HealthComp->OnDeath.RemoveDynamic(this, &AMissionZone::OnPlayerDied);
			Soldier->HealthComp->OnDeath.AddDynamic(this, &AMissionZone::OnPlayerDied);

			// If activation/binding happened after lethal damage, the delegate event is
			// already gone. Defer recovery until mission activation has finished.
			if (!Soldier->HealthComp->IsAlive() || Soldier->IsDowned())
			{
				TWeakObjectPtr<AMissionZone> WeakThis(this);
				TWeakObjectPtr<APawn> WeakPlayer(Player);
				GetWorld()->GetTimerManager().SetTimer(PlayerDeathPollHandle, [WeakThis, WeakPlayer]()
				{
					if (!WeakThis.IsValid() || WeakThis->IsActorBeingDestroyed() ||
						WeakThis->MissionState != EMissionZoneState::Active)
					{
						return;
					}
					if (APawn* DeadPlayer = WeakPlayer.Get())
					{
						WeakThis->OnPlayerDied(DeadPlayer);
					}
				}, 0.05f, false);
			}
			return;
		}
	}

	// Fallback: find ANY health component on the player (TPWCS pack characters)
	TArray<UActorComponent*> Comps;
	Player->GetComponents(Comps);
	for (UActorComponent* C : Comps)
	{
		if (!C) continue;
		if (C->GetName().Contains(TEXT("BPC_Health")) || (C->GetClass() && C->GetClass()->GetName().Contains(TEXT("Health"))))
		{
			// Find OnDeath delegate via reflection
			FMulticastDelegateProperty* OnDeathProp = FindFProperty<FMulticastDelegateProperty>(C->GetClass(), FName(TEXT("OnDeath")));
			if (OnDeathProp)
			{
				UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: Bound to player death via %s::OnDeath"), *GetName(), *C->GetName());
				// We can't AddDynamic to an arbitrary delegate, so use a timer to check health
				break;
			}
		}
	}

	// Ultimate fallback: poll player health every 0.15s using SEPARATE handle
	if (GetWorld())
	{
		TWeakObjectPtr<AMissionZone> WeakThis(this);
		TWeakObjectPtr<APawn> WeakPlayer(Player);
		GetWorld()->GetTimerManager().SetTimer(PlayerDeathPollHandle, [WeakThis, WeakPlayer]()
		{
			if (!WeakThis.IsValid() || WeakThis->IsActorBeingDestroyed()) return;
			APawn* Pl = WeakPlayer.Get();
			if (!Pl || !Pl->IsValidLowLevel()) return;
			if (WeakThis->MissionState != EMissionZoneState::Active) return;

			bool bIsDead = false;
			if (ASoldierCharacter* S = Cast<ASoldierCharacter>(Pl))
			{
				// Direct check — no reflection needed
				bIsDead = !S->IsAlive();
			}
			else
			{
				UActorComponent* HealthC = WeakThis->CachedPlayerPackHealth.Get();
				if (!HealthC || HealthC->GetOwner() != Pl)
				{
					HealthC = nullptr;
					TArray<UActorComponent*> Comps;
					Pl->GetComponents(Comps);
					for (UActorComponent* C : Comps)
					{
						if (!C) continue;
						if (!C->GetName().Contains(TEXT("BPC_Health"))) continue;
						HealthC = C;
						WeakThis->CachedPlayerPackHealth = C;
						break;
					}
				}
				if (HealthC)
				{
					if (FDoubleProperty* DP = FindFProperty<FDoubleProperty>(HealthC->GetClass(), FName(TEXT("currentHealth"))))
					{
						bIsDead = DP->GetPropertyValue_InContainer(HealthC) <= 0.0;
					}
					else if (FFloatProperty* FP = FindFProperty<FFloatProperty>(HealthC->GetClass(), FName(TEXT("currentHealth"))))
					{
						bIsDead = FP->GetPropertyValue_InContainer(HealthC) <= 0.f;
					}
				}
			}

			// S19-DEATHPROMPT: the poll runs every 0.15 s and the player stays dead for the
			// whole prompt delay - without this the log filled with a dozen identical
			// "detected as dead" lines and the situation note repeated with it.
			if (bIsDead && !WeakThis->bDeathSequenceRunning)
			{
				UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: Player detected as dead via polling"), *WeakThis->GetName());
				// S19-LOGGER: the death moment in full - this is the state the revive
				// has to recover from (health zero, ragdoll or death pose, dead flags).
				SquadAISituation::Note(FString::Printf(TEXT("PLAYER-DEATH detected by poll | hp: %s | pose: %s"),
					*SquadAISituation::DescribeHealth(Pl), *SquadAISituation::DescribePose(Pl)));
				WeakThis->OnPlayerDied(Pl);
			}
		}, 0.15f, true);
	}
}

void AMissionZone::UnbindPlayerDeathDelegate()
{
	// Clear the death poll timer (used for TPWCS characters)
	if (GetWorld())
	{
		GetWorld()->GetTimerManager().ClearTimer(PlayerDeathPollHandle);
	}

	APawn* Player = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	if (!Player) return;

	if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(Player))
	{
		if (Soldier->HealthComp)
		{
			Soldier->HealthComp->OnDeath.RemoveDynamic(this, &AMissionZone::OnPlayerDied);
		}
	}
}

void AMissionZone::OnPlayerDied(AActor* OwnerActor)
{
	// S19-DEATHPROMPT: this runs once per death - both the native OnDeath delegate and the
	// 0.15 s poll call it, and the player is still dead for the whole delayed window, so
	// re-entry must be blocked until the recovery below has run.
	if (bDeathSequenceRunning)
	{
		return;
	}
	bDeathSequenceRunning = true;

	// S19-DEATHPROMPT: say it on screen. The live log showed four deaths where the only
	// evidence was a teleport 300+ m away ("i got teleported somewhere at last, what
	// happened there?") - the pack plays a death animation, but nothing told the player
	// what had just happened. The prompt is FA/EN-localised and INI-overridable.
	if (PlayerDeathPromptSeconds > 0.f)
	{
		if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this))
		{
			HUD->ShowDeathPrompt(
				AQuestNativeHUD::LocalizeHUDText(this, TEXT("PlayerDeath"), TEXT("Title"), TEXT("شما از پا در آمدید"), TEXT("YOU DIED")),
				AQuestNativeHUD::LocalizeHUDText(this, TEXT("PlayerDeath"), TEXT("Body"),
					TEXT("ماموریت از نو آغاز می‌شود — همراهان شما را به نقطه‌ی استقرار بازمی‌گردانند"),
					TEXT("The mission restarts — your squad is regrouping you at the staging point")),
				PlayerDeathPromptSeconds);
		}
		SquadAISituation::Note(FString::Printf(TEXT("DEATH-PROMPT %s: death prompt shown for %.1fs, respawn delayed %.1fs"),
			*GetName(), PlayerDeathPromptSeconds, FMath::Max(0.f, PlayerRespawnDelaySeconds)));
	}

	// S19-DEATHPROMPT: give the prompt (and the player) a beat before the teleport. The
	// recovery body is exactly the old synchronous one, moved behind a timer.
	const float Delay = FMath::Max(0.f, PlayerRespawnDelaySeconds);
	if (Delay > 0.01f && GetWorld())
	{
		TWeakObjectPtr<AMissionZone> WeakThis(this);
		FTimerHandle DeathSequenceHandle;
		GetWorld()->GetTimerManager().SetTimer(DeathSequenceHandle, [WeakThis]()
		{
			if (AMissionZone* Zone = WeakThis.Get())
			{
				Zone->bDeathSequenceRunning = false;
				Zone->OnPlayerDied_Recover();
			}
		}, Delay, false);
		return;
	}

	bDeathSequenceRunning = false;
	OnPlayerDied_Recover();
}

void AMissionZone::OnPlayerDied_Recover()
{
	// S5-1: FailMission had zero callers — attempts restarted silently forever and the
	// chain failure branch was unreachable. Revive first (else the chain's mission
	// restart starts with a dead player), then fail for real.
	RespawnPlayer();
	if (bFailMissionOnPlayerDeath)
	{
		UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: Player died during mission '%s' — failing mission"),
			*GetName(), *MissionDescription.ToString());
		FailMission();
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: Player died during mission '%s' — restarting attempt"),
			*GetName(), *MissionDescription.ToString());
		RestartCurrentAttempt();
	}
}

// ===== SPAWNER EVENTS (OPTIMIZATION: event-driven instead of polling) =====

void AMissionZone::BindSpawnerEvents()
{
	for (AEnemyWaveSpawner* Spawner : LinkedSpawners)
	{
		if (!Spawner) continue;
		Spawner->OnSpawnerEnemyDied.RemoveDynamic(this, &AMissionZone::OnSpawnerEnemyDiedEvent);
		Spawner->OnSpawnerEnemyDied.AddDynamic(this, &AMissionZone::OnSpawnerEnemyDiedEvent);
		Spawner->OnSpawnerAllWavesDone.RemoveDynamic(this, &AMissionZone::OnSpawnerCompletedEvent);
		Spawner->OnSpawnerAllWavesDone.AddDynamic(this, &AMissionZone::OnSpawnerCompletedEvent);
	}
}

void AMissionZone::UnbindSpawnerEvents()
{
	for (AEnemyWaveSpawner* Spawner : LinkedSpawners)
	{
		if (!Spawner) continue;
		Spawner->OnSpawnerEnemyDied.RemoveDynamic(this, &AMissionZone::OnSpawnerEnemyDiedEvent);
		Spawner->OnSpawnerAllWavesDone.RemoveDynamic(this, &AMissionZone::OnSpawnerCompletedEvent);
	}
}

void AMissionZone::OnSpawnerEnemyDiedEvent(AActor* DeadEnemy)
{
	if (MissionState != EMissionZoneState::Active) return;

	// FIX: Sync with actual spawner counts instead of decrementing from 0
	AliveEnemies = 0;
	TotalEnemiesSpawned = 0;
	for (AEnemyWaveSpawner* Spawner : LinkedSpawners)
	{
		if (!Spawner) continue;
		AliveEnemies += Spawner->AliveEnemyCount;
		TotalEnemiesSpawned += Spawner->TotalEnemiesSpawned;
	}

	if (MissionType == EMissionType::Clear)
	{
		bool bAllDone = true;
		for (AEnemyWaveSpawner* Spawner : LinkedSpawners)
		{
			if (!Spawner) continue;
			if (!Spawner->bCompleted && Spawner->bIsActive)
			{
				bAllDone = false;
				break;
			}
		}

		if (bAllDone && AliveEnemies <= 0 && TotalEnemiesSpawned > 0)
		{
			bEventDrivenClearCheck = true;
			CompleteMission();
		}
	}
}

void AMissionZone::OnSpawnerCompletedEvent()
{
	if (MissionState != EMissionZoneState::Active) return;

	// Check if ALL spawners are done
	bool bAllDone = true;
	for (AEnemyWaveSpawner* Spawner : LinkedSpawners)
	{
		if (!Spawner) continue;
		if (!Spawner->bCompleted && Spawner->bIsActive)
		{
			bAllDone = false;
			break;
		}
	}

	if (bAllDone)
	{
		// For Clear: wait until all enemies are dead (handled by OnSpawnerEnemyDiedEvent)
		// For Defend: DON'T complete here — the defend timer handles completion.
		// The wave timer will reactivate spawners if needed for more waves.
	}
}

// ===== OVERLAP =====

void AMissionZone::OnPlayerEnteredZone(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
	UPrimitiveComponent* OtherComp, int32 OtherBodyIndex,
	bool bFromSweep, const FHitResult& SweepResult)
{
	if (!OtherActor) return;
	APawn* Pawn = Cast<APawn>(OtherActor);
	if (!Pawn || !Pawn->IsPlayerControlled()) return;

	bPlayerInZone = true;

	if (MissionState == EMissionZoneState::Active && MissionType == EMissionType::Reach)
	{
		CompleteMission();
	}
}

void AMissionZone::OnPlayerLeftZone(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
	UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
	if (!OtherActor) return;
	APawn* Pawn = Cast<APawn>(OtherActor);
	if (!Pawn || !Pawn->IsPlayerControlled()) return;

	bPlayerInZone = false;
}

// ===== SPAWNER HELPERS =====

void AMissionZone::ActivateLinkedSpawners()
{
	for (AEnemyWaveSpawner* Spawner : LinkedSpawners)
	{
		if (Spawner && Spawner->IsValidLowLevel() && !Spawner->IsActorBeingDestroyed())
		{
			Spawner->ActivateSpawner();
		}
	}
	// S5-6: template stack driven alongside the X/Y/Z stack.
	for (AWaveSpawner* TemplateSpawner : LinkedTemplateSpawners)
	{
		if (TemplateSpawner && TemplateSpawner->IsValidLowLevel() && !TemplateSpawner->IsActorBeingDestroyed())
		{
			TemplateSpawner->StartWaves();
		}
	}
}

void AMissionZone::DeactivateLinkedSpawners()
{
	for (AEnemyWaveSpawner* Spawner : LinkedSpawners)
	{
		if (Spawner && Spawner->IsValidLowLevel() && !Spawner->IsActorBeingDestroyed())
		{
			Spawner->DeactivateSpawner();
		}
	}
	// S5-6: template stack driven alongside the X/Y/Z stack.
	for (AWaveSpawner* TemplateSpawner : LinkedTemplateSpawners)
	{
		if (TemplateSpawner && TemplateSpawner->IsValidLowLevel() && !TemplateSpawner->IsActorBeingDestroyed())
		{
			TemplateSpawner->StopWaves(true);
		}
	}
}

void AMissionZone::CheckClearCompletion()
{
	AliveEnemies = 0;
	bAllSpawnersDone = true;
	TotalEnemiesSpawned = 0;

	for (AEnemyWaveSpawner* Spawner : LinkedSpawners)
	{
		if (!Spawner) continue;

		TotalEnemiesSpawned += Spawner->TotalEnemiesSpawned;
		AliveEnemies += Spawner->AliveEnemyCount;

		if (!Spawner->bCompleted && Spawner->bIsActive)
		{
			bAllSpawnersDone = false;
		}
	}
	// S5-6: template-stack contribution to Clear completion.
	for (AWaveSpawner* TemplateSpawner : LinkedTemplateSpawners)
	{
		if (!TemplateSpawner) continue;

		TotalEnemiesSpawned += TemplateSpawner->TotalSpawned;
		AliveEnemies += TemplateSpawner->CachedLiving;

		if (!TemplateSpawner->AreAllWavesComplete() && TemplateSpawner->IsSpawningActive())
		{
			bAllSpawnersDone = false;
		}
	}

	if (bAllSpawnersDone && AliveEnemies <= 0 && TotalEnemiesSpawned > 0)
	{
		CompleteMission();
	}
}

// ===== AMMO RESET =====

void AMissionZone::ResetPlayerAmmo(APawn* Player)
{
	if (!Player) return;

	if (USquadAIInventorySubsystem* Inv = USquadAIInventorySubsystem::Get(this))
	{
		for (FSquadInventoryWeaponItem& W : Inv->Weapons)
		{
			W.ClipAmmo = W.MaxClipAmmo;
			W.ReserveAmmo = FMath::Max(W.ReserveAmmo, W.MaxClipAmmo * 6);
		}
		Inv->FragGrenades = FMath::Max(2, Inv->FragGrenades);
		Inv->SmokeGrenades = FMath::Max(2, Inv->SmokeGrenades);
	}

	TArray<UActorComponent*> Comps;
	Player->GetComponents(Comps);
	for (UActorComponent* C : Comps)
	{
		if (!C) continue;
		const FString N = C->GetName();
		if (N.Contains(TEXT("BPC_WeaponCharacter")))
		{
			FString CurrentWeaponID = TEXT("default");
			for (const FName& WN : { FName(TEXT("Active Weapon")), FName(TEXT("ActiveWeapon")) })
			{
				if (FNameProperty* WP = FindFProperty<FNameProperty>(C->GetClass(), WN))
				{
					CurrentWeaponID = WP->GetPropertyValue_InContainer(C).ToString();
					break;
				}
			}

			const FName WeaponKey(*CurrentWeaponID);
			int32 ClipAmmo = DefaultRespawnClipAmmo;
			if (const int32* FoundClip = PerWeaponClipAmmo.Find(WeaponKey))
			{
				ClipAmmo = *FoundClip;
			}

			int32 ReserveAmmo = DefaultRespawnReserveAmmo;
			if (const int32* FoundReserve = PerWeaponReserveAmmo.Find(WeaponKey))
			{
				ReserveAmmo = *FoundReserve;
			}

			for (const FName& ClipName : { FName(TEXT("Ammo Clip Current")), FName(TEXT("AmmoClipCurrent")) })
			{
				if (FIntProperty* P = FindFProperty<FIntProperty>(C->GetClass(), ClipName))
				{
					P->SetPropertyValue_InContainer(C, ClipAmmo);
				}
			}

			for (const FName& AmmoName : { FName(TEXT("Ammo Current")), FName(TEXT("AmmoCurrent")) })
			{
				if (FIntProperty* P = FindFProperty<FIntProperty>(C->GetClass(), AmmoName))
				{
					P->SetPropertyValue_InContainer(C, ReserveAmmo);
				}
			}

			UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: Reset ammo for '%s' — Clip=%d, Reserve=%d"),
				*GetName(), *CurrentWeaponID, ClipAmmo, ReserveAmmo);
			break;
		}
	}
}

// =========================================================================
//  S19-ESCORT / S19-INTEL / S19-EXFIL / S19-CLOCK
//  The four mission-creator modifier groups. Each one follows the shape the
//  sabotage/supply/POW groups established: Bind* in ActivateMission (which also
//  resets the prop), a gate in CompleteMission, Unbind* on every exit path.
// =========================================================================

// ===== S19-ESCORT =====
void AMissionZone::BindEscort()
{
	if (!EscortTarget)
	{
		bEscortArrived = false;
		bEscortDead = false;
		return;
	}
	// A convoy left wrecked by a failed attempt is revived, exactly like a crate
	// that has to go back into the field.
	if (EscortTarget->IsEscortDead())
	{
		EscortTarget->ResetEscort();
	}
	bEscortArrived = EscortTarget->IsArrived();
	bEscortDead = false;
	EscortTarget->OnEscortArrived.RemoveDynamic(this, &AMissionZone::OnEscortArrivedEvent);
	EscortTarget->OnEscortArrived.AddDynamic(this, &AMissionZone::OnEscortArrivedEvent);
	EscortTarget->OnEscortDied.RemoveDynamic(this, &AMissionZone::OnEscortDiedEvent);
	EscortTarget->OnEscortDied.AddDynamic(this, &AMissionZone::OnEscortDiedEvent);
}

void AMissionZone::UnbindEscort()
{
	if (!EscortTarget)
	{
		return;
	}
	EscortTarget->OnEscortArrived.RemoveDynamic(this, &AMissionZone::OnEscortArrivedEvent);
	EscortTarget->OnEscortDied.RemoveDynamic(this, &AMissionZone::OnEscortDiedEvent);
}

bool AMissionZone::AreEscortGatesMet() const
{
	if (!EscortTarget || !bRequireEscortArrival)
	{
		return true;
	}
	// A dead convoy must never soft-lock the zone: the death handler has already
	// decided whether that fails the mission or merely removes the gate, so here a
	// destroyed convoy counts as "this gate is no longer standing in the way".
	if (bEscortDead || EscortTarget->IsEscortDead())
	{
		return true;
	}
	return bEscortArrived || EscortTarget->IsArrived();
}

void AMissionZone::OnEscortArrivedEvent(AEscortTargetActor* Escort)
{
	if (MissionState != EMissionZoneState::Active)
	{
		return;
	}
	bEscortArrived = true;
	ScoreState.Add(EMissionScoreEvent::EscortArrived);     // S19-SCORE
	OnMissionAlert.Broadcast(this, TEXT("EscortArrived"));
	SquadAISituation::Note(FString::Printf(TEXT("MISSION %s: convoy arrived."), *GetName()));

	// Arriving may be the last gate for this zone - re-drive the type's own check
	// rather than completing blindly (a Clear zone still needs its enemies dead).
	switch (MissionType)
	{
	case EMissionType::Clear:
		CheckClearCompletion();
		break;
	case EMissionType::Defend:
		break; // its own timer drives completion
	default:
		CompleteMission();
		break;
	}
}

void AMissionZone::OnEscortDiedEvent(AEscortTargetActor* Escort)
{
	if (MissionState != EMissionZoneState::Active)
	{
		return;
	}
	bEscortDead = true;
	ScoreState.Add(EMissionScoreEvent::FriendlyDeath);     // S19-SCORE
	OnMissionAlert.Broadcast(this, TEXT("EscortLost"));
	if (bFailIfEscortDies)
	{
		SquadAISituation::Note(FString::Printf(TEXT("MISSION %s: the convoy was destroyed - mission failed."), *GetName()));
		FailMission();
		return;
	}
	SquadAISituation::Note(FString::Printf(
		TEXT("MISSION %s: the convoy was destroyed - the mission continues without it."), *GetName()));
	switch (MissionType)
	{
	case EMissionType::Clear:
		CheckClearCompletion();
		break;
	case EMissionType::Defend:
		break;
	default:
		CompleteMission();
		break;
	}
}

// ===== S19-INTEL =====
void AMissionZone::BindIntelSites()
{
	for (const TObjectPtr<AIntelSiteActor>& S : IntelSites)
	{
		if (!S)
		{
			continue;
		}
		S->ResetSite();
		S->OnIntelReported.RemoveDynamic(this, &AMissionZone::OnIntelSiteReportedEvent);
		S->OnIntelReported.AddDynamic(this, &AMissionZone::OnIntelSiteReportedEvent);
	}
}

void AMissionZone::UnbindIntelSites()
{
	for (const TObjectPtr<AIntelSiteActor>& S : IntelSites)
	{
		if (!S)
		{
			continue;
		}
		S->OnIntelReported.RemoveDynamic(this, &AMissionZone::OnIntelSiteReportedEvent);
	}
}

bool AMissionZone::AreAllIntelSitesReported() const
{
	for (const TObjectPtr<AIntelSiteActor>& S : IntelSites)
	{
		if (S && !S->IsReported())
		{
			return false;
		}
	}
	return true;
}

void AMissionZone::OnIntelSiteReportedEvent(AIntelSiteActor* Site)
{
	if (MissionState != EMissionZoneState::Active)
	{
		return;
	}
	int32 Remaining = 0;
	for (const TObjectPtr<AIntelSiteActor>& S : IntelSites)
	{
		if (S && !S->IsReported())
		{
			Remaining++;
		}
	}
	ScoreState.Add(EMissionScoreEvent::IntelReported);     // S19-SCORE
	OnMissionAlert.Broadcast(this, TEXT("IntelReported"));
	UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: intel site '%s' reported — %d to go."),
		*GetName(), Site ? *Site->GetName() : TEXT("?"), Remaining);
	if (Remaining > 0)
	{
		return;
	}

	OnMissionAlert.Broadcast(this, TEXT("AllIntelGathered"));
	SquadAISituation::Note(FString::Printf(TEXT("MISSION %s: all intel gathered."), *GetName()));
	switch (MissionType)
	{
	case EMissionType::Clear:
		CheckClearCompletion();
		break;
	case EMissionType::Defend:
		break;
	default:
		CompleteMission();
		break;
	}
}

// ===== S19-EXFIL =====
void AMissionZone::BindExtraction()
{
	if (!ExtractionZone)
	{
		bExtractionReady = false;
		return;
	}
	// A pad left ready (or half-held) by a previous attempt starts over.
	ExtractionZone->ResetExtraction();
	bExtractionReady = false;
	ExtractionZone->OnExtractionReady.RemoveDynamic(this, &AMissionZone::OnExtractionReadyEvent);
	ExtractionZone->OnExtractionReady.AddDynamic(this, &AMissionZone::OnExtractionReadyEvent);
}

void AMissionZone::UnbindExtraction()
{
	if (!ExtractionZone)
	{
		return;
	}
	// Deliberately does NOT reset the pad: this runs on COMPLETION too, and clearing
	// the pad there would flip a finished exfil back to dormant in front of the player.
	ExtractionZone->OnExtractionReady.RemoveDynamic(this, &AMissionZone::OnExtractionReadyEvent);
}

bool AMissionZone::IsExtractionGateMet() const
{
	if (!ExtractionZone || !bRequireExtraction)
	{
		return true;
	}
	return bExtractionReady || ExtractionZone->IsExtractionReady();
}

void AMissionZone::ArmExtractionIfPresent()
{
	if (ExtractionZone && !ExtractionZone->IsArmed())
	{
		ExtractionZone->ArmExtraction();
	}
}

void AMissionZone::OnExtractionReadyEvent(AExtractionZoneActor* Zone)
{
	if (MissionState != EMissionZoneState::Active)
	{
		return;
	}
	bExtractionReady = true;
	ScoreState.Add(EMissionScoreEvent::ExtractionComplete); // S19-SCORE
	OnMissionAlert.Broadcast(this, TEXT("ExtractionComplete"));
	SquadAISituation::Note(FString::Printf(TEXT("MISSION %s: extraction pad held - wrapping up."), *GetName()));
	switch (MissionType)
	{
	case EMissionType::Clear:
		CheckClearCompletion();
		break;
	case EMissionType::Defend:
		break; // the defend timer's own tick re-runs CompleteMission every frame
	default:
		CompleteMission();
		break;
	}
}

// ===== S19-CLOCK =====
void AMissionZone::TickMissionClock(float DeltaTime)
{
	ElapsedActiveSeconds += FMath::Max(0.f, DeltaTime);
	TimeLimitRemaining = FMissionClockModel::Remaining(TimeLimitSeconds, ElapsedActiveSeconds);

	if (!FMissionClockModel::HasLimit(TimeLimitSeconds) || bClockExpired)
	{
		return;
	}

	if (!bClockWarned
		&& FMissionClockModel::ShouldWarn(TimeLimitSeconds, ElapsedActiveSeconds, TimeLimitWarnFraction))
	{
		bClockWarned = true;
		OnMissionAlert.Broadcast(this, TEXT("ClockWarning"));
		SquadAISituation::Note(FString::Printf(
			TEXT("MISSION %s: CLOCK WARNING - %s left of %s."),
			*GetName(), *FMissionClockModel::FormatMMSS(TimeLimitRemaining),
			*FMissionClockModel::FormatMMSS(TimeLimitSeconds)));
	}

	if (FMissionClockModel::IsExpired(TimeLimitSeconds, ElapsedActiveSeconds))
	{
		bClockExpired = true;
		OnMissionAlert.Broadcast(this, TEXT("TimeExpired"));
		if (bFailOnTimeExpiry)
		{
			SquadAISituation::Note(FString::Printf(
				TEXT("MISSION %s: OUT OF TIME after %s - the mission fails on the clock."),
				*GetName(), *FMissionClockModel::FormatMMSS(ElapsedActiveSeconds)));
			FailMission();
		}
		else
		{
			// Soft clock: the mission may still be won, but the log says the window closed.
			SquadAISituation::Note(FString::Printf(
				TEXT("MISSION %s: the time limit ran out at %s - the mission continues (soft clock)."),
				*GetName(), *FMissionClockModel::FormatMMSS(TimeLimitSeconds)));
		}
	}
}

void AMissionZone::ReportParAtCompletion()
{
	const float Spent = ElapsedActiveSeconds;
	if (FMissionClockModel::HasLimit(TimeLimitSeconds))
	{
		SquadAISituation::Note(FString::Printf(
			TEXT("MISSION %s: finished in %s (limit %s%s)."),
			*GetName(), *FMissionClockModel::FormatMMSS(Spent),
			*FMissionClockModel::FormatMMSS(TimeLimitSeconds),
			bClockExpired ? TEXT(", clock already expired") : TEXT("")));
	}

	const FMissionClockModel::EParVerdict Verdict =
		FMissionClockModel::EvaluatePar(ParTimeSeconds, Spent);
	switch (Verdict)
	{
	case FMissionClockModel::EParVerdict::Beaten:
		OnMissionAlert.Broadcast(this, TEXT("ParTimeBeaten"));
		SquadAISituation::Note(FString::Printf(
			TEXT("MISSION %s: PAR BEATEN - %s against a par of %s."),
			*GetName(), *FMissionClockModel::FormatMMSS(Spent),
			*FMissionClockModel::FormatMMSS(ParTimeSeconds)));
		break;
	case FMissionClockModel::EParVerdict::Missed:
		OnMissionAlert.Broadcast(this, TEXT("ParTimeMissed"));
		SquadAISituation::Note(FString::Printf(
			TEXT("MISSION %s: par missed - %s against a par of %s."),
			*GetName(), *FMissionClockModel::FormatMMSS(Spent),
			*FMissionClockModel::FormatMMSS(ParTimeSeconds)));
		break;
	default:
		break;
	}
}


// ===========================================================================
//  S19-SCORE / S19-ALARM: the debrief and the alarm poll
// ===========================================================================

void AMissionZone::ComputeAndResetScore()
{
	// The par baseline is what THIS mission actually asks for: its wave stream, its
	// commander, and every objective group it linked. Computed once per attempt so a
	// mid-mission reconfiguration cannot move the goalposts.
	int32 Waves = 2;
	int32 PerWave = 4;
	bool bCommander = false;
	if (LinkedSpawners.Num() > 0 && LinkedSpawners[0])
	{
		AEnemyWaveSpawner* Spawner = LinkedSpawners[0];
		Waves = FMath::Max(1, Spawner->MaxWaves);
		PerWave = FMath::Max(1, Spawner->EnemiesPerWave);
		bCommander = (Spawner->CommanderWavePolicy != ECommanderWavePolicy::Never);
	}
	const int32 Objectives = IntelSites.Num() + SupplyCrates.Num() + SabotageTargets.Num()
		+ POWCaptives.Num() + (EscortTarget ? 1 : 0) + (ExtractionZone ? 1 : 0)
		+ CapturePoints.Num() + (DefendedAsset ? 1 : 0) + (InterdictionDirector ? 1 : 0);

	ScoreState.Reset(FMissionScoreModel::ParScoreFor(Waves, PerWave, bCommander,
		Objectives, MissionType == EMissionType::Defend));
	bScoreReported = false;
	bSearchingBeatSaid = false;   // S24-STORY: a fresh attempt earns fresh words
	bFullAlarmBeatSaid = false;
}

// ===== S24-STORY: the war talks back =====
// Command speaks on the radio at the moments that change a fight. The line is
// deterministic (same act + same event = the same words) and rotates by act
// number, exactly like the briefing openers, so the net never repeats itself.
void AMissionZone::BroadcastStoryBeat(uint8 StoryEvent)
{
	USquadAIRadioChatterSubsystem* Radio = USquadAIRadioChatterSubsystem::Get(this);
	if (!Radio) return;
	const EMissionStoryEvent E = (EMissionStoryEvent)StoryEvent;
	const int32 Act = FMissionStoryModel::ParseActNumber(TitleCardDate.ToString());
	const FString Place = TitleCardPlace.IsEmpty() ? FString(TEXT("the ground")) : TitleCardPlace.ToString();
	Radio->BroadcastStoryTransmission(
		FMissionStoryModel::BuildStoryBeat(E, Act, Place, true),
		FMissionStoryModel::BuildStoryBeat(E, Act, Place, false));
}

void AMissionZone::TickMissionAlarm()
{
	USquadAIAlarmSubsystem* AlarmSys = USquadAIAlarmSubsystem::Get(this);
	if (!AlarmSys)
	{
		return;
	}

	// The ghost record only ever climbs; the score model reads it at completion.
	ScoreState.NoteAlarmValue(AlarmSys->GetValue());

	// S24-STORY: one word from command the first time their net wakes, and the
	// first time the whole line goes up. Once per attempt each - the radio must
	// never nag.
	if (!bSearchingBeatSaid && AlarmSys->GetLevel() == EAlarmLevel::Searching)
	{
		bSearchingBeatSaid = true;
		BroadcastStoryBeat((uint8)EMissionStoryEvent::AlarmSearching);
	}
	if (!bFullAlarmBeatSaid && AlarmSys->GetLevel() == EAlarmLevel::FullAlarm)
	{
		bFullAlarmBeatSaid = true;
		BroadcastStoryBeat((uint8)EMissionStoryEvent::AlarmFull);
	}

	if (bFailOnFullAlarm && AlarmSys->GetLevel() == EAlarmLevel::FullAlarm)
	{
		ScoreState.ApplyFullAlarmPenaltyOnce();   // the bill lands even as the run ends
		SquadAISituation::Note(FString::Printf(
			TEXT("MISSION %s: full alarm raised - the stealth requirement is blown."), *GetName()));
		FailMission();
	}
}

void AMissionZone::ReportScoreAtCompletion()
{
	if (bScoreReported)
	{
		return;   // the extraction re-entry runs the completion path twice by design
	}
	bScoreReported = true;

	// Deep-review fix B1: completing the mission as briefed is itself worth points -
	// without this a plain Clear read "Score 0  D" after winning it.
	ScoreState.Add(EMissionScoreEvent::MissionCompleted);

	const FMissionClockModel::EParVerdict Verdict =
		FMissionClockModel::EvaluatePar(ParTimeSeconds, ElapsedActiveSeconds);
	if (Verdict == FMissionClockModel::EParVerdict::Beaten)
	{
		ScoreState.Add(EMissionScoreEvent::ParBeaten);
	}
	else if (Verdict == FMissionClockModel::EParVerdict::Missed)
	{
		ScoreState.Add(EMissionScoreEvent::ParMissed);
	}
	if (bStealthBonus)
	{
		ScoreState.ApplyStealthBonusOnce();
	}
	if (FAssetDefenseModel::EarnsPreservedBonus(DefendedAsset != nullptr, DefendedAsset && DefendedAsset->IsAssetAlive()))
	{
		ScoreState.Add(EMissionScoreEvent::AssetPreserved);   // S19-ASSET: it held
	}

	SquadAISituation::Note(FString::Printf(
		TEXT("MISSION %s: %s (par %d, time %s)."),
		*GetName(),
		*FMissionScoreModel::DebriefLine(ScoreState.Total, ScoreState.Grade()),
		ScoreState.ParScore,
		*FMissionClockModel::FormatMMSS(ElapsedActiveSeconds)));
}

int32 AMissionZone::GetMissionScore() const
{
	return ScoreState.Total;
}

int32 AMissionZone::GetMissionParScore() const
{
	return ScoreState.ParScore;
}

FString AMissionZone::GetScoreGradeString() const
{
	return FMissionScoreModel::GradeLetter(ScoreState.Grade());
}


// ===========================================================================
//  S19-CAP / S19-ASSET / S19-INTERDICT: the batch-4 creators
// ===========================================================================

void AMissionZone::BindCaptureAndAssetAndInterdiction()
{
	for (const TObjectPtr<ACapturePointActor>& Point : CapturePoints)
	{
		if (!Point) continue;
		Point->OnCaptured.AddDynamic(this, &AMissionZone::OnCapturePointCapturedEvent);
		Point->OnLost.AddDynamic(this, &AMissionZone::OnCapturePointLostEvent);
		Point->OnHoldCompleted.AddDynamic(this, &AMissionZone::OnCaptureHoldCompletedEvent);
		Point->ResetPoint();   // every attempt starts with the flags neutral
	}
	if (DefendedAsset)
	{
		DefendedAsset->OnUnderAttack.AddDynamic(this, &AMissionZone::OnAssetUnderAttackEvent);
		DefendedAsset->OnAssetDestroyed.AddDynamic(this, &AMissionZone::OnAssetDestroyedEvent);
		DefendedAsset->ResetAsset();
	}
	if (InterdictionDirector)
	{
		InterdictionDirector->OnQuotaMet.AddDynamic(this, &AMissionZone::OnInterdictionQuotaMetEvent);
		InterdictionDirector->OnEscapeLimitReached.AddDynamic(this, &AMissionZone::OnInterdictionEscapeLimitEvent);
		InterdictionDirector->ResetRun();
		if (IsActive())
		{
			InterdictionDirector->StartRun();   // the run belongs to the mission's clock
		}
	}
}

void AMissionZone::UnbindCaptureAndAssetAndInterdiction()
{
	for (const TObjectPtr<ACapturePointActor>& Point : CapturePoints)
	{
		if (!Point) continue;
		Point->OnCaptured.RemoveDynamic(this, &AMissionZone::OnCapturePointCapturedEvent);
		Point->OnLost.RemoveDynamic(this, &AMissionZone::OnCapturePointLostEvent);
		Point->OnHoldCompleted.RemoveDynamic(this, &AMissionZone::OnCaptureHoldCompletedEvent);
	}
	if (DefendedAsset)
	{
		DefendedAsset->OnUnderAttack.RemoveDynamic(this, &AMissionZone::OnAssetUnderAttackEvent);
		DefendedAsset->OnAssetDestroyed.RemoveDynamic(this, &AMissionZone::OnAssetDestroyedEvent);
	}
	if (InterdictionDirector)
	{
		InterdictionDirector->OnQuotaMet.RemoveDynamic(this, &AMissionZone::OnInterdictionQuotaMetEvent);
		InterdictionDirector->OnEscapeLimitReached.RemoveDynamic(this, &AMissionZone::OnInterdictionEscapeLimitEvent);
	}
}

bool AMissionZone::AreAllCapturePointsHeld() const
{
	for (const TObjectPtr<ACapturePointActor>& Point : CapturePoints)
	{
		if (Point && !Point->IsHeld())
		{
			return false;
		}
	}
	return true;   // no points linked: no gate
}

bool AMissionZone::IsInterdictionGateMet() const
{
	if (!InterdictionDirector)
	{
		return true;   // no run linked: no gate
	}
	return bInterdictionQuotaMet || InterdictionDirector->WasQuotaMet();
}

void AMissionZone::OnCapturePointCapturedEvent(ACapturePointActor* Point)
{
	if (MissionState != EMissionZoneState::Active || !Point)
	{
		return;
	}
	ScoreState.Add(EMissionScoreEvent::CapturePointTaken);   // S19-SCORE
	OnMissionAlert.Broadcast(this, TEXT("CapturePointCaptured"));
	SquadAISituation::Note(FString::Printf(TEXT("MISSION %s: capture point taken (%d/%d held)."),
		*GetName(), GetHeldCapturePointCount(), CapturePoints.Num()));
}

void AMissionZone::OnCapturePointLostEvent(ACapturePointActor* Point)
{
	if (MissionState != EMissionZoneState::Active || !Point)
	{
		return;
	}
	ScoreState.Add(EMissionScoreEvent::CapturePointLost);    // S19-SCORE
	OnMissionAlert.Broadcast(this, TEXT("CapturePointLost"));
	UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: a capture point was lost - take it back."), *GetName());
}

void AMissionZone::OnCaptureHoldCompletedEvent(ACapturePointActor* Point)
{
	if (MissionState != EMissionZoneState::Active || !Point)
	{
		return;
	}
	OnMissionAlert.Broadcast(this, TEXT("CapturePointHeld"));
	SquadAISituation::Note(FString::Printf(TEXT("MISSION %s: capture point HELD (%d/%d)."),
		*GetName(), GetHeldCapturePointCount(), CapturePoints.Num()));
}

void AMissionZone::OnAssetUnderAttackEvent(ADefendedAssetActor* Asset)
{
	if (MissionState != EMissionZoneState::Active || !Asset)
	{
		return;
	}
	OnMissionAlert.Broadcast(this, TEXT("AssetUnderAttack"));
}

void AMissionZone::OnAssetDestroyedEvent(ADefendedAssetActor* Asset)
{
	if (MissionState != EMissionZoneState::Active || !Asset)
	{
		return;
	}
	ScoreState.Add(EMissionScoreEvent::AssetDestroyed);      // S19-SCORE
	OnMissionAlert.Broadcast(this, TEXT("AssetDestroyed"));
	if (bFailIfAssetDestroyed)
	{
		FailMission();
	}
}

void AMissionZone::OnInterdictionQuotaMetEvent(AInterdictionDirectorActor* Director)
{
	if (MissionState != EMissionZoneState::Active || !Director)
	{
		return;
	}
	bInterdictionQuotaMet = true;
	// Deep-review fix B5: the quota landing is when the stops get paid - without this
	// a WON interdiction mission scored 0 against its own par and graded D.
	ScoreState.AddPoints(Director->GetStoppedCount()
		* FMissionScoreModel::PointsFor(EMissionScoreEvent::CourierStopped));   // S19-SCORE
	OnMissionAlert.Broadcast(this, TEXT("InterdictionQuotaMet"));
	SquadAISituation::Note(FString::Printf(TEXT("MISSION %s: interdiction quota met - %s."),
		*GetName(), TEXT("nothing essential gets through")));
	CompleteMission();   // the whole gate list re-runs in order, extraction included
}

void AMissionZone::OnInterdictionEscapeLimitEvent(AInterdictionDirectorActor* Director)
{
	if (MissionState != EMissionZoneState::Active || !Director)
	{
		return;
	}
	// Every escape that pushed the limit pays its bill, not just the last one.
	ScoreState.AddPoints(Director->GetEscapedCount()
		* FMissionScoreModel::PointsFor(EMissionScoreEvent::CourierEscaped));    // S19-SCORE
	OnMissionAlert.Broadcast(this, TEXT("InterdictionFailed"));
	FailMission();
}

int32 AMissionZone::GetHeldCapturePointCount() const
{
	int32 Count = 0;
	for (const TObjectPtr<ACapturePointActor>& Point : CapturePoints)
	{
		if (Point && Point->IsHeld())
		{
			++Count;
		}
	}
	return Count;
}


void AMissionZone::DestroyFactorySpawnedActors()
{
	// Unbind first: nothing may broadcast into actors that are about to die, and the
	// interdiction director must not outlive the mission that owns its run.
	UnbindSabotageTargets();
	UnbindSupplyCrates();
	UnbindEscort();                         // S19-ESCORT
	UnbindIntelSites();                     // S19-INTEL
	UnbindExtraction();                     // S19-EXFIL
	UnbindCaptureAndAssetAndInterdiction(); // S19-CAP/ASSET/INTERDICT
	DeactivateLinkedSpawners();

	int32 Destroyed = 0;
	for (const TObjectPtr<AActor>& Spawned : FactorySpawnedActors)
	{
		if (Spawned)
		{
			Spawned->Destroy();
			++Destroyed;
		}
	}
	FactorySpawnedActors.Reset();
	UE_LOG(LogTemp, Warning, TEXT("[MissionZone] %s: tore down %d factory-spawned actor(s)."),
		*GetName(), Destroyed);
}

// InterdictionCourierActor.cpp - S19-INTERDICT: the walk, the death, the escape.

#include "Quest/InterdictionCourierActor.h"

#include "Actors/EnemyPatrolRoute.h"
#include "Components/HealthComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/World.h"

AInterdictionCourierActor::AInterdictionCourierActor()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 0.f;   // the walk is the visible thing

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SetRootComponent(SceneRoot);

	static ConstructorHelpers::FObjectFinder<UStaticMesh> CubeMesh(TEXT("/Engine/BasicShapes/Cube.Cube"));
	static ConstructorHelpers::FObjectFinder<UMaterialInterface> BaseMat(TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"));

	// The body: a truck-ish block. No collision - it must not wall off the road it
	// drives; the player's shots reach it through its health component.
	BodyMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("BodyMesh"));
	BodyMesh->SetupAttachment(SceneRoot);
	if (CubeMesh.Succeeded()) BodyMesh->SetStaticMesh(CubeMesh.Object);
	if (BaseMat.Succeeded()) BodyMesh->SetMaterial(0, BaseMat.Object);
	BodyMesh->SetRelativeScale3D(FVector(2.2f, 1.2f, 1.0f));
	BodyMesh->SetRelativeLocation(FVector(0.f, 0.f, 55.f));
	BodyMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	BodyMesh->SetCanEverAffectNavigation(false);

	HealthComp = CreateDefaultSubobject<UHealthComponent>(TEXT("HealthComp"));
	HealthComp->MaxHealth = 400.f;
	HealthComp->CurrentHealth = 400.f;
}

void AInterdictionCourierActor::BeginPlay()
{
	Super::BeginPlay();

	if (BodyMesh)
	{
		MeshMID = BodyMesh->CreateAndSetMaterialInstanceDynamic(0);
	}
	if (HealthComp && !bDeathBound)
	{
		HealthComp->OnDeath.AddDynamic(this, &AInterdictionCourierActor::HandleHealthDied);
		bDeathBound = true;
	}
	RefreshRoute();
}

void AInterdictionCourierActor::RefreshRoute()
{
	CachedPoints.Reset();

	if (!Route)
	{
		if (!bRouteWarned)
		{
			bRouteWarned = true;
			UE_LOG(LogTemp, Warning,
				TEXT("[S19-INTERDICT] %s has no Route - the courier cannot drive. Set 'Route' (an AEnemyPatrolRoute)."),
				*GetName());
		}
		return;
	}

	UWorld* World = GetWorld();
	const int32 Count = Route->GetPointCount();
	for (int32 i = 0; i < Count; ++i)
	{
		FVector P = Route->GetPointLocation(i);
		if (World)
		{
			// Ground every point the same way the convoy does.
			const FVector Start = P + FVector(0.f, 0.f, 1500.f);
			const FVector End = P - FVector(0.f, 0.f, 20000.f);
			FHitResult Hit;
			if (World->LineTraceSingleByChannel(Hit, Start, End, ECC_Visibility))
			{
				P = Hit.ImpactPoint + FVector(0.f, 0.f, 50.f);
			}
		}
		CachedPoints.Add(P);
	}
	CurrentPointIndex = FMath::Clamp(CurrentPointIndex, 0, FMath::Max(0, CachedPoints.Num() - 1));
}

float AInterdictionCourierActor::GetRouteProgress01() const
{
	const int32 Num = CachedPoints.Num();
	if (Num <= 1)
	{
		return 0.f;
	}
	return FMath::Clamp(static_cast<float>(CurrentPointIndex) / static_cast<float>(Num - 1), 0.f, 1.f);
}

void AInterdictionCourierActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (bStopped || bEscaped)
	{
		return;
	}
	if (!HealthComp || !HealthComp->IsAlive())
	{
		return;   // HandleHealthDied owns the stop
	}
	if (CachedPoints.Num() == 0)
	{
		RefreshRoute();   // the director may set the route just after spawning
		return;
	}

	const FVector Target = CachedPoints[CurrentPointIndex];
	const FVector ToPoint = Target - GetActorLocation();
	const float Distance = ToPoint.Size();

	if (Distance <= FMath::Max(50.f, MoveSpeedCmPerSec * DeltaTime))
	{
		SetActorLocation(Target);
		++CurrentPointIndex;
		if (CurrentPointIndex >= CachedPoints.Num())
		{
			// The far edge: it got through.
			bEscaped = true;
			if (MeshMID)
			{
				MeshMID->SetVectorParameterValue(TEXT("Color"), FLinearColor(0.2f, 0.2f, 0.2f, 1.f));
			}
			SetActorTickEnabled(false);
			OnEscaped.Broadcast(this);
			UE_LOG(LogTemp, Warning, TEXT("[S19-INTERDICT] %s: a courier ESCAPED."), *GetName());
		}
		return;   // one waypoint per frame at most
	}

	const FVector Dir = ToPoint / FMath::Max(Distance, KINDA_SMALL_NUMBER);
	SetActorLocation(GetActorLocation() + Dir * MoveSpeedCmPerSec * DeltaTime, /*bSweep=*/true);
	const FRotator Facing = Dir.Rotation();
	SetActorRotation(FRotator(0.f, Facing.Yaw, 0.f));
}

void AInterdictionCourierActor::HandleHealthDied(AActor* OwnerActor)
{
	if (bStopped || bEscaped)
	{
		return;
	}
	bStopped = true;
	if (MeshMID)
	{
		MeshMID->SetVectorParameterValue(TEXT("Color"), FLinearColor(0.08f, 0.08f, 0.08f, 1.f));
	}
	SetActorTickEnabled(false);
	OnStopped.Broadcast(this);
	UE_LOG(LogTemp, Warning, TEXT("[S19-INTERDICT] %s: a courier was STOPPED."), *GetName());
}

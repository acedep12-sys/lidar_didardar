// FallenNoteActor.cpp — S17-NOTE
#include "Quest/FallenNoteActor.h"
#include "Components/StaticMeshComponent.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "HUD/QuestNativeHUD.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/World.h"
#include "GameFramework/Pawn.h"
#include "EngineUtils.h"
#include "UObject/ConstructorHelpers.h"

AFallenNoteActor::AFallenNoteActor()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 0.f;

	USceneComponent* SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SetRootComponent(SceneRoot);

	static ConstructorHelpers::FObjectFinder<UStaticMesh> CubeMesh(TEXT("/Engine/BasicShapes/Cube.Cube"));
	static ConstructorHelpers::FObjectFinder<UStaticMesh> CylMesh(TEXT("/Engine/BasicShapes/Cylinder.Cylinder"));
	static ConstructorHelpers::FObjectFinder<UMaterialInterface> BaseMat(TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"));

	// A pale sheet of paper lying on the ground, slightly askew.
	PaperMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("PaperMesh"));
	PaperMesh->SetupAttachment(SceneRoot);
	if (CubeMesh.Succeeded()) PaperMesh->SetStaticMesh(CubeMesh.Object);
	if (BaseMat.Succeeded()) PaperMesh->SetMaterial(0, BaseMat.Object);
	PaperMesh->SetRelativeScale3D(FVector(0.28f, 0.40f, 0.008f));
	PaperMesh->SetRelativeLocation(FVector(0.f, 0.f, 3.f));
	PaperMesh->SetRelativeRotation(FRotator(0.f, 23.f, 0.f));
	PaperMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	PaperMesh->SetCanEverAffectNavigation(false);
	PaperMesh->SetCastShadow(false);

	// Faint warm glow disc so it reads from a distance.
	MarkerDisc = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("MarkerDisc"));
	MarkerDisc->SetupAttachment(SceneRoot);
	if (CylMesh.Succeeded()) MarkerDisc->SetStaticMesh(CylMesh.Object);
	if (BaseMat.Succeeded()) MarkerDisc->SetMaterial(0, BaseMat.Object);
	MarkerDisc->SetRelativeScale3D(FVector(0.6f, 0.6f, 0.015f));
	MarkerDisc->SetRelativeLocation(FVector(0.f, 0.f, 1.f));
	MarkerDisc->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	MarkerDisc->SetCanEverAffectNavigation(false);
	MarkerDisc->SetCastShadow(false);
}

void AFallenNoteActor::BeginPlay()
{
	Super::BeginPlay();
	if (PaperMesh && PaperMesh->GetMaterial(0))
	{
		if (UMaterialInstanceDynamic* PaperMID = PaperMesh->CreateAndSetMaterialInstanceDynamic(0))
		{
			PaperMID->SetVectorParameterValue(TEXT("Color"), FLinearColor(0.85f, 0.82f, 0.7f)); // aged paper
		}
	}
	if (MarkerDisc && MarkerDisc->GetMaterial(0))
	{
		MarkerMID = MarkerDisc->CreateAndSetMaterialInstanceDynamic(0);
	}
}

void AFallenNoteActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	if (bCollected) return;
	UWorld* World = GetWorld();
	if (!World) return;

	// Soft candle-like pulse.
	if (MarkerMID)
	{
		const float Pulse = 0.35f + 0.65f * (0.5f + 0.5f * FMath::Sin(World->GetTimeSeconds() * 2.2f));
		MarkerMID->SetVectorParameterValue(TEXT("Color"), FLinearColor(1.f * Pulse, 0.85f * Pulse, 0.45f * Pulse));
	}

	APawn* Player = UGameplayStatics::GetPlayerPawn(World, 0);
	if (!Player) return;
	const FVector PL = Player->GetActorLocation();
	if (FVector::DistSquared2D(PL, GetActorLocation()) <= PickupRadius * PickupRadius
		&& FMath::Abs(PL.Z - GetActorLocation().Z) < 300.f)
	{
		Collect();
	}
}

void AFallenNoteActor::Collect()
{
	if (bCollected) return;
	bCollected = true;

	// Census: how many notes exist in this level, how many found so far.
	int32 Total = 0, Found = 0;
	for (TActorIterator<AFallenNoteActor> It(GetWorld()); It; ++It)
	{
		Total++;
		if ((*It)->bCollected) Found++;
	}

	if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this))
	{
		HUD->ShowFallenNote(NoteTitle, NoteText, ReadDuration, Found, Total);
	}

	if (PaperMesh) PaperMesh->SetVisibility(false);
	if (MarkerDisc) MarkerDisc->SetVisibility(false);
	SetActorTickEnabled(false);

	UE_LOG(LogTemp, Warning, TEXT("[FallenNote] %s collected (%d/%d)."), *GetName(), Found, Total);
	OnCollected.Broadcast(this);
}

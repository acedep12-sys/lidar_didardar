// SupplyCrateActor.cpp — S17-SUPP
#include "Quest/SupplyCrateActor.h"
#include "Components/StaticMeshComponent.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/World.h"
#include "GameFramework/Pawn.h"
#include "EngineUtils.h"
#include "UObject/ConstructorHelpers.h"

ASupplyCrateActor::ASupplyCrateActor()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 0.f;

	USceneComponent* SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SetRootComponent(SceneRoot);

	static ConstructorHelpers::FObjectFinder<UStaticMesh> CubeMesh(TEXT("/Engine/BasicShapes/Cube.Cube"));
	static ConstructorHelpers::FObjectFinder<UStaticMesh> CylMesh(TEXT("/Engine/BasicShapes/Cylinder.Cylinder"));
	static ConstructorHelpers::FObjectFinder<UMaterialInterface> BaseMat(TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"));

	CrateMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("CrateMesh"));
	CrateMesh->SetupAttachment(SceneRoot);
	if (CubeMesh.Succeeded()) CrateMesh->SetStaticMesh(CubeMesh.Object);
	if (BaseMat.Succeeded()) CrateMesh->SetMaterial(0, BaseMat.Object);
	CrateMesh->SetRelativeScale3D(FVector(0.55f, 0.55f, 0.45f));
	CrateMesh->SetRelativeLocation(FVector(0.f, 0.f, 24.f));
	CrateMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	CrateMesh->SetCanEverAffectNavigation(false);
	CrateMesh->SetCastShadow(false);

	MarkerDisc = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("MarkerDisc"));
	MarkerDisc->SetupAttachment(SceneRoot);
	if (CylMesh.Succeeded()) MarkerDisc->SetStaticMesh(CylMesh.Object);
	if (BaseMat.Succeeded()) MarkerDisc->SetMaterial(0, BaseMat.Object);
	MarkerDisc->SetRelativeScale3D(FVector(1.1f, 1.1f, 0.03f));
	MarkerDisc->SetRelativeLocation(FVector(0.f, 0.f, 2.f));
	MarkerDisc->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	MarkerDisc->SetCanEverAffectNavigation(false);
	MarkerDisc->SetCastShadow(false);
}

void ASupplyCrateActor::BeginPlay()
{
	Super::BeginPlay();
	HomeTransform = GetActorTransform();
	bHomeCached = true;
	if (MarkerDisc && MarkerDisc->GetMaterial(0))
	{
		MarkerMID = MarkerDisc->CreateAndSetMaterialInstanceDynamic(0);
	}
	if (CrateMesh && CrateMesh->GetMaterial(0))
	{
		if (UMaterialInstanceDynamic* CrateMID = CrateMesh->CreateAndSetMaterialInstanceDynamic(0))
		{
			CrateMID->SetVectorParameterValue(TEXT("Color"), FLinearColor(0.35f, 0.24f, 0.12f)); // wooden crate
		}
	}
	SetMarkerColor(FLinearColor(0.1f, 0.7f, 1.f));
}

void ASupplyCrateActor::SetDeliveryTarget(const FVector& Location, float Radius)
{
	DeliveryLocation = Location;
	DeliveryRadius = Radius;
}

void ASupplyCrateActor::SetMarkerColor(const FLinearColor& C)
{
	if (MarkerMID)
	{
		MarkerMID->SetVectorParameterValue(TEXT("Color"), C);
	}
}

void ASupplyCrateActor::SetCrateVisible(bool bVisible)
{
	if (CrateMesh) CrateMesh->SetVisibility(bVisible);
	if (MarkerDisc) MarkerDisc->SetVisibility(bVisible);
}

void ASupplyCrateActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	UWorld* World = GetWorld();
	if (!World) return;

	APawn* Player = UGameplayStatics::GetPlayerPawn(World, 0);
	if (!Player) return;
	const FVector PL = Player->GetActorLocation();

	switch (State)
	{
	case ESupplyCrateState::AwaitingPickup:
	{
		// Cyan pulse while waiting.
		const float Pulse = 0.45f + 0.55f * (0.5f + 0.5f * FMath::Sin(World->GetTimeSeconds() * 3.f));
		SetMarkerColor(FLinearColor(0.1f * Pulse, 0.7f * Pulse, 1.f * Pulse));

		const bool bClose = FVector::DistSquared2D(PL, GetActorLocation()) <= PickupRadius * PickupRadius
			&& FMath::Abs(PL.Z - GetActorLocation().Z) < 350.f;
		if (!bClose) break;

		// One crate on the shoulder at a time.
		bool bAnotherCarried = false;
		for (TActorIterator<ASupplyCrateActor> It(World); It; ++It)
		{
			if (*It != this && (*It)->IsCarried()) { bAnotherCarried = true; break; }
		}
		if (bAnotherCarried) break;

		State = ESupplyCrateState::Carried;
		SetCrateVisible(false);
		UE_LOG(LogTemp, Warning, TEXT("[SupplyCrate] %s: supplies shouldered (%s) — carry them to the delivery point."),
			*GetName(), CrateLabel.IsEmpty() ? TEXT("Supplies") : *CrateLabel.ToString());
		OnPickedUp.Broadcast(this);
		break;
	}
	case ESupplyCrateState::Carried:
	{
		if (DeliveryRadius <= 0.f) break; // no target assigned yet
		if (FVector::DistSquared2D(PL, DeliveryLocation) <= DeliveryRadius * DeliveryRadius)
		{
			State = ESupplyCrateState::Delivered;
			// Drop the crate at the player's feet, painted green.
			SetActorLocation(PL);
			SetCrateVisible(true);
			if (MarkerDisc) MarkerDisc->SetVisibility(false);
			SetActorTickEnabled(false);
			UE_LOG(LogTemp, Warning, TEXT("[SupplyCrate] %s: supplies DELIVERED."), *GetName());
			OnDelivered.Broadcast(this);
		}
		break;
	}
	case ESupplyCrateState::Delivered:
	default:
		break;
	}
}

void ASupplyCrateActor::ResetCrate()
{
	State = ESupplyCrateState::AwaitingPickup;
	if (bHomeCached)
	{
		SetActorTransform(HomeTransform);
	}
	SetCrateVisible(true);
	SetMarkerColor(FLinearColor(0.1f, 0.7f, 1.f));
	SetActorTickEnabled(true);
}

// FireDamageZone.cpp — Fire damage zone that damages player when standing inside
// Shows red screen effect widget and applies damage every second.
// Works with BOTH SquadAI ASoldierCharacter AND TPWCS pack characters.
#include "Quest/FireDamageZone.h"
#include "Components/SphereComponent.h"
#include "Components/PrimitiveComponent.h"
#include "Components/AudioComponent.h"
#include "Sound/SoundBase.h"
#include "Blueprint/UserWidget.h"
#include "GameFramework/Pawn.h"
#include "Characters/SoldierCharacter.h"
#include "Components/HealthComponent.h"
#include "HUD/QuestNativeHUD.h"
#include "Engine/World.h"
#include "TimerManager.h"
#include "UObject/UnrealType.h"
#include "Kismet/GameplayStatics.h"

AFireDamageZone::AFireDamageZone()
{
	PrimaryActorTick.bCanEverTick = false;

	DamageZone = CreateDefaultSubobject<USphereComponent>(TEXT("DamageZone"));
	DamageZone->SetSphereRadius(150.f);
	DamageZone->SetCollisionProfileName(TEXT("OverlapAllDynamic"));
	DamageZone->SetGenerateOverlapEvents(true);
	DamageZone->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
	SetRootComponent(DamageZone);
}

void AFireDamageZone::BeginPlay()
{
	Super::BeginPlay();
	DamageZone->SetSphereRadius(DamageRadius);
	DamageZone->OnComponentBeginOverlap.AddDynamic(this, &AFireDamageZone::OnOverlapBegin);
	DamageZone->OnComponentEndOverlap.AddDynamic(this, &AFireDamageZone::OnOverlapEnd);

	UE_LOG(LogTemp, Warning, TEXT("[FireDamage] %s: BeginPlay. Radius=%.0f, DPS=%.1f"),
		*GetName(), DamageRadius, DamagePerSecond);
}

void AFireDamageZone::OnOverlapBegin(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
	UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	if (!OtherActor) return;
	APawn* Pawn = Cast<APawn>(OtherActor);
	if (!Pawn || !Pawn->IsPlayerControlled()) return;

	OverlappingPlayer = OtherActor;
	ShowBurnEffect();

	if (FireCrackleSound && GetWorld())
	{
		ActiveFireAudio = UGameplayStatics::SpawnSoundAtLocation(GetWorld(), FireCrackleSound, GetActorLocation(), FRotator::ZeroRotator, 0.9f);
	}

	UE_LOG(LogTemp, Warning, TEXT("[FireDamage] %s: Player entered fire zone! Starting damage (DPS=%.1f)"),
		*GetName(), DamagePerSecond);

	// Start damage timer — 1 second interval
	GetWorld()->GetTimerManager().SetTimer(DamageTimerHandle, this,
		&AFireDamageZone::ApplyFireDamage, 1.0f, true);
}

void AFireDamageZone::OnOverlapEnd(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
	UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
	if (OtherActor != OverlappingPlayer) return;

	OverlappingPlayer = nullptr;
	HideBurnEffect();
	GetWorld()->GetTimerManager().ClearTimer(DamageTimerHandle);

	if (ActiveFireAudio)
	{
		ActiveFireAudio->FadeOut(0.5f, 0.0f);
		ActiveFireAudio = nullptr;
	}

	UE_LOG(LogTemp, Warning, TEXT("[FireDamage] %s: Player left fire zone."), *GetName());
}

void AFireDamageZone::ApplyFireDamage()
{
	if (!OverlappingPlayer || !OverlappingPlayer->IsValidLowLevel())
	{
		OverlappingPlayer = nullptr;
		HideBurnEffect();
		GetWorld()->GetTimerManager().ClearTimer(DamageTimerHandle);
		return;
	}

	// === SquadAI character ===
	if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(OverlappingPlayer))
	{
		if (!Soldier->HealthComp || !Soldier->HealthComp->IsAlive())
		{
			// Already dead — stop the timer
			OverlappingPlayer = nullptr;
			HideBurnEffect();
			GetWorld()->GetTimerManager().ClearTimer(DamageTimerHandle);
			return;
		}

		Soldier->HealthComp->ApplyDamage(DamagePerSecond, this);

		UE_LOG(LogTemp, Verbose, TEXT("[FireDamage] %s: SquadAI damage %.1f (hp: %.1f)"),
			*GetName(), DamagePerSecond, Soldier->HealthComp->CurrentHealth);

		if (Soldier->HealthComp->CurrentHealth <= 0.f)
		{
			OverlappingPlayer = nullptr;
			HideBurnEffect();
			GetWorld()->GetTimerManager().ClearTimer(DamageTimerHandle);
		}
		return;
	}

	// === TPWCS pack character ===
	UActorComponent* Health = CachedPackHealth.Get();
	if (!Health || Health->GetOwner() != OverlappingPlayer)
	{
		Health = nullptr;
		TArray<UActorComponent*> Comps;
		OverlappingPlayer->GetComponents(Comps);
		for (UActorComponent* C : Comps)
		{
			if (!C) continue;
			if (!C->GetName().Contains(TEXT("BPC_Health"))) continue;
			Health = C;
			break;
		}
		CachedPackHealth = Health;
	}
	if (Health)
	{
		for (const FName& PropName : { FName(TEXT("currentHealth")), FName(TEXT("CurrentHealth")), FName(TEXT("Health")) })
		{
			if (FDoubleProperty* DP = FindFProperty<FDoubleProperty>(Health->GetClass(), PropName))
			{
				double HP = DP->GetPropertyValue_InContainer(Health);
				if (HP <= 0.0) return;

				double NewHP = FMath::Max(0.0, HP - static_cast<double>(DamagePerSecond));
				DP->SetPropertyValue_InContainer(Health, NewHP);

				UE_LOG(LogTemp, Verbose, TEXT("[FireDamage] %s: Pack damage %.1f (hp: %.1f -> %.1f)"),
					*GetName(), DamagePerSecond, HP, NewHP);

				if (NewHP <= 0.0)
				{
					UE_LOG(LogTemp, Warning, TEXT("[FireDamage] %s: Player KILLED by fire!"), *GetName());
				}
				return;
			}

			if (FFloatProperty* FP = FindFProperty<FFloatProperty>(Health->GetClass(), PropName))
			{
				float HP = FP->GetPropertyValue_InContainer(Health);
				if (HP <= 0.f) return;

				float NewHP = FMath::Max(0.f, HP - DamagePerSecond);
				FP->SetPropertyValue_InContainer(Health, NewHP);

				UE_LOG(LogTemp, Verbose, TEXT("[FireDamage] %s: Pack damage %.1f (hp: %.1f -> %.1f)"),
					*GetName(), DamagePerSecond, HP, NewHP);

				if (NewHP <= 0.f)
				{
					UE_LOG(LogTemp, Warning, TEXT("[FireDamage] %s: Player KILLED by fire!"), *GetName());
				}
				return;
			}
		}
	}

	UE_LOG(LogTemp, Error, TEXT("[FireDamage] %s: Could not find health component on player %s!"),
		*GetName(), *GetNameSafe(OverlappingPlayer));
}

void AFireDamageZone::ShowBurnEffect()
{
	// Native HUD procedural burn overlay fallback
	if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this))
	{
		HUD->SetPlayerBurning(true);
	}

	if (ActiveBurnEffect || !BurnScreenEffectClass || !GetWorld()) return;

	APlayerController* PC = GetWorld()->GetFirstPlayerController();
	if (!PC) return;

	ActiveBurnEffect = CreateWidget<UUserWidget>(PC, BurnScreenEffectClass);
	if (ActiveBurnEffect)
	{
		ActiveBurnEffect->AddToViewport(100);
		UE_LOG(LogTemp, Warning, TEXT("[FireDamage] %s: Show burn screen effect"), *GetName());
	}
}

void AFireDamageZone::HideBurnEffect()
{
	if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this))
	{
		HUD->SetPlayerBurning(false);
	}

	if (ActiveBurnEffect)
	{
		ActiveBurnEffect->RemoveFromParent();
		ActiveBurnEffect = nullptr;
		UE_LOG(LogTemp, Warning, TEXT("[FireDamage] %s: Hide burn screen effect"), *GetName());
	}
}

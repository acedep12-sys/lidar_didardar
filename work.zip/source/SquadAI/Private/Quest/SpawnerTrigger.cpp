// SpawnerTrigger.cpp — Trigger volume that activates linked enemy spawners
#include "Quest/SpawnerTrigger.h"
#include "Quest/EnemyWaveSpawner.h"
#include "Components/BoxComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/CapsuleComponent.h"
#include "GameFramework/Pawn.h"
#include "GenericTeamAgentInterface.h"
#include "Characters/SoldierCharacter.h"

ASpawnerTrigger::ASpawnerTrigger()
{
	PrimaryActorTick.bCanEverTick = false;

	// Root scene component
	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SetRootComponent(SceneRoot);

	// Trigger volume (box collision)
	TriggerVolume = CreateDefaultSubobject<UBoxComponent>(TEXT("TriggerVolume"));
	TriggerVolume->SetupAttachment(SceneRoot);
	TriggerVolume->SetBoxExtent(FVector(200.f, 200.f, 100.f));
	TriggerVolume->SetCollisionProfileName(TEXT("Trigger"));
	TriggerVolume->SetGenerateOverlapEvents(true);
	TriggerVolume->SetRelativeLocation(FVector(0.f, 0.f, 100.f));

	// Visual mesh for editor (a flat plane to show trigger area)
	VisualMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("VisualMesh"));
	VisualMesh->SetupAttachment(SceneRoot);
	VisualMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	VisualMesh->SetRelativeLocation(FVector(0.f, 0.f, 100.f));
	VisualMesh->SetRelativeScale3D(FVector(4.f, 4.f, 0.1f));
	VisualMesh->SetHiddenInGame(true);

#if WITH_EDITORONLY_DATA
	static ConstructorHelpers::FObjectFinder<UStaticMesh> PlaneMesh(TEXT("/Engine/BasicShapes/Plane.Plane"));
	if (PlaneMesh.Succeeded())
	{
		VisualMesh->SetStaticMesh(PlaneMesh.Object);
	}
#endif
}

void ASpawnerTrigger::BeginPlay()
{
	Super::BeginPlay();

	// Bind overlap event
	TriggerVolume->OnComponentBeginOverlap.AddDynamic(this, &ASpawnerTrigger::OnOverlapBegin);
}

void ASpawnerTrigger::OnOverlapBegin(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
	UPrimitiveComponent* OtherComp, int32 OtherBodyIndex,
	bool bFromSweep, const FHitResult& SweepResult)
{
	if (!ShouldTriggerForActor(OtherActor))
	{
		return;
	}

	// Check one-shot
	if (bOneShot && bHasBeenActivated)
	{
		return;
	}

	bHasBeenActivated = true;
	ActivationCount++;

	UE_LOG(LogTemp, Warning, TEXT("[SpawnerTrigger] %s activated by %s (count: %d). Activating %d linked spawners."),
		*GetName(), *GetNameSafe(OtherActor), ActivationCount, LinkedSpawners.Num());

	// Fire the Blueprint event
	OnTriggerActivated.Broadcast(this);

	// Activate all linked spawners
	for (AEnemyWaveSpawner* Spawner : LinkedSpawners)
	{
		if (Spawner && Spawner->IsValidLowLevel() && !Spawner->IsActorBeingDestroyed())
		{
			Spawner->ActivateSpawner();
		}
	}

	// Destroy if configured
	if (bOneShot && bDestroyAfterActivation)
	{
		Destroy();
	}
}

bool ASpawnerTrigger::ShouldTriggerForActor(AActor* Actor) const
{
	if (!Actor) return false;

	// Must be a pawn
	APawn* Pawn = Cast<APawn>(Actor);
	if (!Pawn) return false;

	// Must be player-controlled
	if (!Pawn->IsPlayerControlled()) return false;

	// Check team if required
	if (RequiredTeamId != 255)
	{
		IGenericTeamAgentInterface* TeamAgent = Cast<IGenericTeamAgentInterface>(Pawn);
		if (!TeamAgent) return false;
		if (TeamAgent->GetGenericTeamId().GetId() != RequiredTeamId) return false;
	}

	return true;
}

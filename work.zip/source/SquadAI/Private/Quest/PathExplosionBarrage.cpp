#include "Quest/PathExplosionBarrage.h"
#include "Performance/SquadAIFXManagerSubsystem.h"
#include "Quest/QuestChain.h"
#include "Performance/SquadAIAudioSubsystem.h"
#include "Performance/SoldierRegistrySubsystem.h"
#include "Actors/SquadAIAudioManager.h"
#include "SquadAITuning.h"
#include "Characters/SoldierCharacter.h"
#include "AI/SoldierAIController.h"
#include "Components/HealthComponent.h"
#include "Components/StaticMeshComponent.h"
#include "NiagaraSystem.h"
#include "NiagaraFunctionLibrary.h"
#include "NiagaraComponent.h"
#include "Kismet/GameplayStatics.h"
#include "GameFramework/Pawn.h"
#include "Engine/World.h"
#include "Engine/StaticMesh.h"
#include "Materials/MaterialInterface.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "TimerManager.h"
#include "DrawDebugHelpers.h"
#include "UObject/UnrealType.h"
#include "UObject/ConstructorHelpers.h"

APathExplosionBarrage::APathExplosionBarrage()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.bStartWithTickEnabled = false;
	PrimaryActorTick.TickInterval = 0.05f;

	USceneComponent* Root = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	SetRootComponent(Root);

	FExplosionSizeConfig Small;
	Small.SizeName = TEXT("Small");
	Small.Radius = 180.f;
	Small.Damage = 35.f;
	Small.Weight = 1.2f;
	Small.FXScale = 0.7f;
	Sizes.Add(Small);

	FExplosionSizeConfig Medium;
	Medium.SizeName = TEXT("Medium");
	Medium.Radius = 300.f;
	Medium.Damage = 75.f;
	Medium.Weight = 1.f;
	Medium.FXScale = 1.f;
	Sizes.Add(Medium);

	FExplosionSizeConfig Large;
	Large.SizeName = TEXT("Large");
	Large.Radius = 480.f;
	Large.Damage = 140.f;
	Large.Weight = 0.55f;
	Large.FXScale = 1.4f;
	Sizes.Add(Large);

	static ConstructorHelpers::FObjectFinder<UStaticMesh> PlaneMesh(TEXT("/Engine/BasicShapes/Plane.Plane"));
	if (PlaneMesh.Succeeded())
	{
		WarningDiscMesh = PlaneMesh.Object;
	}
}

void APathExplosionBarrage::BeginPlay()
{
	Super::BeginPlay();
	if (!bEnabled)
	{
		SetActorTickEnabled(false);
		return;
	}
	BindMissions();
	RefreshRunningState();
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().SetTimer(MissionPollHandle, this, &APathExplosionBarrage::RefreshRunningState, 0.5f, true);
	}
}

void APathExplosionBarrage::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	StopBarrage();
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(MissionPollHandle);
	}
	Super::EndPlay(EndPlayReason);
}

void APathExplosionBarrage::BindMissions()
{
	for (AMissionZone* M : LinkedMissions)
	{
		if (!M) continue;
		M->OnMissionStateChanged.RemoveDynamic(this, &APathExplosionBarrage::HandleMissionStateChanged);
		M->OnMissionStateChanged.AddDynamic(this, &APathExplosionBarrage::HandleMissionStateChanged);
	}
}

void APathExplosionBarrage::HandleMissionStateChanged(AMissionZone* Mission, EMissionZoneState NewState)
{
	RefreshRunningState();
}

bool APathExplosionBarrage::IsAnyLinkedMissionActive() const
{
	if (LinkedMissions.Num() > 0)
	{
		for (AMissionZone* M : LinkedMissions)
		{
			if (M && M->IsActive())
			{
				return true;
			}
		}
		return false;
	}

	UWorld* World = GetWorld();
	if (AQuestChain* Chain = AQuestChain::FindPreferred(World, true))
	{
		if (AMissionZone* Cur = Chain->GetCurrentMission())
		{
			return Cur->IsActive();
		}
	}
	return false;
}

void APathExplosionBarrage::RefreshRunningState()
{
	if (!bEnabled)
	{
		if (bRunning)
		{
			StopBarrage();
		}
		return;
	}

	const bool bWant = IsAnyLinkedMissionActive();
	if (bWant && !bRunning)
	{
		StartBarrage();
	}
	else if (!bWant && bRunning)
	{
		StopBarrage();
	}
}

void APathExplosionBarrage::StartBarrage()
{
	if (bRunning)
	{
		return;
	}
	bRunning = true;
	UE_LOG(LogTemp, Warning, TEXT("[BARRAGE] %s START — warning=%.2fs interval=%.1f-%.1f sizes=%d"),
		*GetName(), WarningTime, MinSecondsBetweenStrikes, MaxSecondsBetweenStrikes, Sizes.Num());
	ScheduleNextWarning(FMath::Max(0.1f, FirstDelayAfterMissionStart));
}

void APathExplosionBarrage::StopBarrage()
{
	bRunning = false;
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(ScheduleHandle);
	}
	ClearPending();
	SetActorTickEnabled(false);
	UE_LOG(LogTemp, Warning, TEXT("[BARRAGE] %s STOP"), *GetName());
}

void APathExplosionBarrage::TestStrikeNearPlayer()
{
	if (!GetWorld())
	{
		return;
	}
	const bool bWasRunning = bRunning;
	bRunning = true;
	SpawnWarning();
	bRunning = bWasRunning;
}

void APathExplosionBarrage::ScheduleNextWarning(float Delay)
{
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}
	World->GetTimerManager().SetTimer(ScheduleHandle, this, &APathExplosionBarrage::SpawnWarning, FMath::Max(0.1f, Delay), false);
}

void APathExplosionBarrage::SpawnWarning()
{
	if (!bRunning || Sizes.Num() == 0)
	{
		return;
	}

	if (Pending.Num() < MaxConcurrentWarnings)
	{
		FVector Loc = FVector::ZeroVector;
		if (PickGroundLocation(Loc))
		{
			const int32 SizeIndex = PickSizeIndex();
			const FExplosionSizeConfig& Cfg = Sizes[SizeIndex];
			FPendingStrike S;
			S.Id = NextStrikeId++;
			S.SizeIndex = SizeIndex;
			S.Loc = Loc;
			S.Radius = FMath::Max(50.f, Cfg.Radius);
			S.Damage = Cfg.Damage;
			S.ExplodeAt = GetWorld()->GetTimeSeconds() + WarningTime;
			S.Disc = SpawnWarningDisc(Loc, S.Radius);
			Pending.Add(S);
			SetActorTickEnabled(true);

			const int32 CapturedId = S.Id;
			FTimerHandle BoomHandle;
			GetWorld()->GetTimerManager().SetTimer(BoomHandle, FTimerDelegate::CreateWeakLambda(this, [this, CapturedId]()
			{
				ExplodeStrike(CapturedId);
			}), WarningTime, false);

			// Trigger tactical squad mortar warning voiceline
			if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
			{
				AudioSys->PlayTacticalVoiceline(ETacticalVoicelineType::Ally_IncomingGrenade, this);
			}

			// Alert nearby AI soldiers to duck / scatter for cover
			if (UWorld* World = GetWorld())
			{
				if (USoldierRegistrySubsystem* Reg = World->GetSubsystem<USoldierRegistrySubsystem>())
				{
					TArray<ASoldierCharacter*> Nearby = Reg->QueryRadius(Loc, S.Radius * 1.6f);
					for (ASoldierCharacter* Soldier : Nearby)
					{
						if (Soldier && Soldier->IsAlive())
						{
							if (ASoldierAIController* AIC = Cast<ASoldierAIController>(Soldier->GetController()))
							{
								AIC->AddSuppression(0.85f);
							}
						}
					}
				}
			}

			UE_LOG(LogTemp, Warning, TEXT("[BARRAGE] warning id=%d size=%s r=%.0f dmg=%.0f loc=%s in %.2fs"),
				S.Id, *Cfg.SizeName.ToString(), S.Radius, S.Damage, *Loc.ToString(), WarningTime);
		}
	}

	const float Next = FMath::FRandRange(
		FMath::Min(MinSecondsBetweenStrikes, MaxSecondsBetweenStrikes),
		FMath::Max(MinSecondsBetweenStrikes, MaxSecondsBetweenStrikes));
	ScheduleNextWarning(Next);
}

void APathExplosionBarrage::ExplodeStrike(int32 Id)
{
	int32 Index = Pending.IndexOfByPredicate([Id](const FPendingStrike& S) { return S.Id == Id; });
	if (!Pending.IsValidIndex(Index))
	{
		return;
	}

	FPendingStrike S = Pending[Index];
	Pending.RemoveAt(Index);

	if (UStaticMeshComponent* Disc = S.Disc.Get())
	{
		Disc->DestroyComponent();
	}

	const FExplosionSizeConfig* Cfg = Sizes.IsValidIndex(S.SizeIndex) ? &Sizes[S.SizeIndex] : nullptr;
	const FVector FXLoc = S.Loc + FVector(0.f, 0.f, 8.f);
	const float Scale = Cfg ? Cfg->FXScale : 1.f;

	// P1-P3: one budget gate covers the whole strike (fireball + dirt are intentional layers).
	USquadAIFXManagerSubsystem* BFXSys = USquadAIFXManagerSubsystem::Get(this);
	const bool bStrikeFXAllowed = !BFXSys || BFXSys->CanSpawnImpactVFX(FXLoc);
	// Niagara Visual FX
	if (bStrikeFXAllowed && Cfg && Cfg->ExplosionFX)
	{
		UNiagaraFunctionLibrary::SpawnSystemAtLocation(
			GetWorld(), Cfg->ExplosionFX, FXLoc, FRotator::ZeroRotator,
			FVector(Scale), true, true, ENCPoolMethod::AutoRelease);
	}
	if (bStrikeFXAllowed && Cfg && Cfg->DirtFX)
	{
		UNiagaraFunctionLibrary::SpawnSystemAtLocation(
			GetWorld(), Cfg->DirtFX, S.Loc, FRotator::ZeroRotator,
			FVector(Scale), true, true, ENCPoolMethod::AutoRelease);
	}

	// 3D Spatial Audio & Distance Attenuation Engine
	USoundBase* CloseSnd = Cfg ? Cfg->CloseExplosionSound.Get() : nullptr;
	USoundBase* DistantSnd = Cfg ? Cfg->DistantExplosionSound.Get() : nullptr;
	TSubclassOf<UCameraShakeBase> Shake = Cfg ? Cfg->CameraShake : nullptr;

	if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
	{
		if (ASquadAIAudioManager* Mgr = AudioSys->GetActiveAudioManager())
		{
			const FName SName = Cfg ? Cfg->SizeName : FName(TEXT("Medium"));
			if (!CloseSnd)
			{
				if (SName == FName(TEXT("Small"))) CloseSnd = Mgr->SmallExplosionCloseSound.Get();
				else if (SName == FName(TEXT("Large"))) CloseSnd = Mgr->LargeExplosionCloseSound.Get();
				else CloseSnd = Mgr->MediumExplosionCloseSound.Get();
			}
			if (!DistantSnd)
			{
				if (SName == FName(TEXT("Small"))) DistantSnd = Mgr->SmallExplosionDistantSound.Get();
				else if (SName == FName(TEXT("Large"))) DistantSnd = Mgr->LargeExplosionDistantSound.Get();
				else DistantSnd = Mgr->MediumExplosionDistantSound.Get();
			}
			if (!Shake)
			{
				Shake = Mgr->ExplosionCameraShake;
			}
		}

		if (!CloseSnd)
		{
			const USquadAITuning* Tuning = USquadAITuning::Get();
			if (Tuning)
			{
				CloseSnd = Tuning->DefaultExplosionCloseSound.Get();
				if (!DistantSnd) DistantSnd = Tuning->DefaultExplosionDistantSound.Get();
			}
		}

		const bool bSpeedOfSound = USquadAITuning::Get() ? USquadAITuning::Get()->bSimulateSpeedOfSound : true;

		AudioSys->PlaySpatialSoundWithDistanceLayers(
			CloseSnd,
			DistantSnd,
			S.Loc,
			2500.f,
			45000.f,
			bSpeedOfSound,
			1.0f,
			Cfg ? Cfg->SoundAttenuation.Get() : nullptr);

		// Camera Shake & Concussion
		AudioSys->TriggerExplosionConcussion(
			S.Loc,
			S.Radius * 1.5f,
			S.Radius * 4.5f,
			Shake);
	}

	ApplyExplosionDamage(S.Loc, S.Radius, S.Damage);

	UE_LOG(LogTemp, Warning, TEXT("[BARRAGE] BOOM id=%d size=%s r=%.0f"),
		S.Id, Cfg ? *Cfg->SizeName.ToString() : TEXT("?"), S.Radius);

	if (Pending.Num() == 0)
	{
		SetActorTickEnabled(false);
	}
}

void APathExplosionBarrage::ClearPending()
{
	for (FPendingStrike& S : Pending)
	{
		if (UStaticMeshComponent* Disc = S.Disc.Get())
		{
			Disc->DestroyComponent();
		}
	}
	Pending.Empty();
}

bool APathExplosionBarrage::PickGroundLocation(FVector& OutLoc) const
{
	UWorld* World = GetWorld();
	APawn* Player = UGameplayStatics::GetPlayerPawn(World, 0);
	if (!World || !Player)
	{
		return false;
	}

	const FVector Origin = Player->GetActorLocation();
	const float MinD = FMath::Min(MinDistanceFromPlayer, MaxDistanceFromPlayer);
	const float MaxD = FMath::Max(MinDistanceFromPlayer, MaxDistanceFromPlayer);

	for (int32 Attempt = 0; Attempt < 10; ++Attempt)
	{
		const float Angle = FMath::FRandRange(0.f, 2.f * PI);
		const float Dist = FMath::FRandRange(MinD, MaxD);
		FVector Candidate = Origin + FVector(FMath::Cos(Angle) * Dist, FMath::Sin(Angle) * Dist, 0.f);

		bool bTooClose = false;
		for (const FPendingStrike& S : Pending)
		{
			if (FVector::Dist2D(Candidate, S.Loc) < (S.Radius + 80.f))
			{
				bTooClose = true;
				break;
			}
		}
		if (bTooClose)
		{
			continue;
		}

		FHitResult Hit;
		const FVector Start = Candidate + FVector(0.f, 0.f, 900.f);
		const FVector End = Candidate - FVector(0.f, 0.f, 4000.f);
		FCollisionQueryParams Params(SCENE_QUERY_STAT(BarrageGround), false, Player);
		if (World->LineTraceSingleByChannel(Hit, Start, End, ECC_WorldStatic, Params))
		{
			OutLoc = Hit.Location;
			return true;
		}
	}
	return false;
}

int32 APathExplosionBarrage::PickSizeIndex() const
{
	float Total = 0.f;
	for (const FExplosionSizeConfig& C : Sizes)
	{
		Total += FMath::Max(0.f, C.Weight);
	}
	if (Total <= 0.f)
	{
		return 0;
	}
	float Roll = FMath::FRandRange(0.f, Total);
	for (int32 i = 0; i < Sizes.Num(); ++i)
	{
		Roll -= FMath::Max(0.f, Sizes[i].Weight);
		if (Roll <= 0.f)
		{
			return i;
		}
	}
	return Sizes.Num() - 1;
}

UStaticMeshComponent* APathExplosionBarrage::SpawnWarningDisc(const FVector& Loc, float Radius)
{
	if (!bShowFilledDisc || !WarningDiscMesh)
	{
		return nullptr;
	}

	UStaticMeshComponent* Disc = NewObject<UStaticMeshComponent>(this);
	if (!Disc)
	{
		return nullptr;
	}
	Disc->SetStaticMesh(WarningDiscMesh);
	Disc->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	Disc->SetCastShadow(false);
	Disc->SetCanEverAffectNavigation(false);
	Disc->RegisterComponent();
	Disc->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
	Disc->SetWorldLocation(Loc + FVector(0.f, 0.f, 4.f));
	Disc->SetWorldRotation(FRotator::ZeroRotator);
	const float ScaleXY = FMath::Max(0.1f, Radius / 50.f);
	Disc->SetWorldScale3D(FVector(ScaleXY, ScaleXY, 0.04f));

	if (!WarningDiscMaterial)
	{
		WarningDiscMaterial = LoadObject<UMaterialInterface>(nullptr,
			TEXT("/Engine/EngineMaterials/Widget3DPassThrough_Translucent_OneSided.Widget3DPassThrough_Translucent_OneSided"));
	}
	if (WarningDiscMaterial)
	{
		if (UMaterialInstanceDynamic* MID = Disc->CreateDynamicMaterialInstance(0, WarningDiscMaterial))
		{
			const FLinearColor C = WarningCircleColor;
			MID->SetVectorParameterValue(TEXT("TintColor"), C);
			MID->SetVectorParameterValue(TEXT("Color"), C);
			MID->SetVectorParameterValue(TEXT("BaseColor"), C);
			MID->SetScalarParameterValue(TEXT("Opacity"), 0.45f);
		}
	}
	return Disc;
}

void APathExplosionBarrage::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	UWorld* World = GetWorld();
	if (!World || Pending.Num() == 0)
	{
		SetActorTickEnabled(false);
		return;
	}

	const float Now = World->GetTimeSeconds();
	for (FPendingStrike& S : Pending)
	{
		const float Remain = FMath::Max(0.f, S.ExplodeAt - Now);
		const float Pulse = 1.f + 0.08f * FMath::Sin(Now * 14.f);
		if (UStaticMeshComponent* Disc = S.Disc.Get())
		{
			const float ScaleXY = FMath::Max(0.1f, S.Radius / 50.f) * Pulse;
			Disc->SetWorldScale3D(FVector(ScaleXY, ScaleXY, 0.04f));
		}

		const FColor Col = WarningCircleColor.ToFColor(true);
		DrawDebugCircle(World, S.Loc + FVector(0.f, 0.f, 6.f), S.Radius * Pulse, 48,
			Col, false, -1.f, 0, WarningLineThickness,
			FVector(1.f, 0.f, 0.f), FVector(0.f, 1.f, 0.f), false);

		if (Remain < 0.45f)
		{
			DrawDebugCircle(World, S.Loc + FVector(0.f, 0.f, 8.f), S.Radius * 0.92f, 32,
				FColor::Yellow, false, -1.f, 0, WarningLineThickness + 2.f,
				FVector(1.f, 0.f, 0.f), FVector(0.f, 1.f, 0.f), false);
		}
	}
}

void APathExplosionBarrage::ApplyExplosionDamage(const FVector& Loc, float Radius, float Damage)
{
	UWorld* World = GetWorld();
	if (!World) return;

	// 1. Damage Player with distance falloff
	if (APawn* Player = UGameplayStatics::GetPlayerPawn(World, 0))
	{
		const float Dist = FVector::Dist2D(Player->GetActorLocation(), Loc);
		if (Dist <= Radius)
		{
			const float Falloff = FMath::Clamp(1.f - (Dist / Radius) * 0.5f, 0.35f, 1.f);
			ApplyDamageToActor(Player, Damage * Falloff);
			UE_LOG(LogTemp, Warning, TEXT("[BARRAGE] player HIT dist=%.0f r=%.0f dmg=%.0f"), Dist, Radius, Damage * Falloff);
		}
	}

	// 2. Damage all AI Soldiers within blast radius & trigger dynamic ragdoll death impulses
	// S5-9a: the registry also registers the PLAYER's soldier character — pass 1 already
	// handled the player with falloff; skip them here (players took barrage damage TWICE).
	APawn* const PlayerPawn = UGameplayStatics::GetPlayerPawn(World, 0);
	if (USoldierRegistrySubsystem* Reg = World->GetSubsystem<USoldierRegistrySubsystem>())
	{
		TArray<ASoldierCharacter*> Nearby = Reg->QueryRadius(Loc, Radius);
		for (ASoldierCharacter* Soldier : Nearby)
		{
			if (!Soldier || !Soldier->IsAlive()) continue;
			if (Soldier == PlayerPawn) continue;

			const float Dist = FVector::Dist(Soldier->GetActorLocation(), Loc);
			if (Dist <= Radius)
			{
				const float Falloff = FMath::Clamp(1.f - (Dist / Radius) * 0.5f, 0.35f, 1.f);
				const float AppliedDmg = Damage * Falloff;
				ApplyDamageToActor(Soldier, AppliedDmg);

				if (!Soldier->IsAlive())
				{
					const FVector BlastDir = (Soldier->GetActorLocation() - Loc + FVector(0.f, 0.f, 150.f)).GetSafeNormal();
					Soldier->ApplyDeathImpulse(BlastDir, 750.f, NAME_None);
				}
			}
		}
	}
}

void APathExplosionBarrage::ApplyDamageToActor(AActor* Target, float Damage)
{
	if (!Target || Damage <= 0.f)
	{
		return;
	}

	if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(Target))
	{
		if (Soldier->HealthComp && Soldier->HealthComp->IsAlive())
		{
			Soldier->HealthComp->ApplyDamage(Damage, this);
		}
		return;
	}

	// S5-9b: pack (BPC_Health) carriers used to receive BOTH the generic ApplyDamage AND a
	// direct reflected HP subtraction — a double-dip. If a pack health component owns the
	// damage path, reflect-and-return; non-pack targets fall through to UGameplayStatics.
	TArray<UActorComponent*> Comps;
	Target->GetComponents(Comps);
	for (UActorComponent* C : Comps)
	{
		if (!C || !C->GetName().Contains(TEXT("BPC_Health")))
		{
			continue;
		}
		for (const FName& PropName : { FName(TEXT("currentHealth")), FName(TEXT("CurrentHealth")), FName(TEXT("Health")) })
		{
			if (FDoubleProperty* DP = FindFProperty<FDoubleProperty>(C->GetClass(), PropName))
			{
				const double HP = DP->GetPropertyValue_InContainer(C);
				DP->SetPropertyValue_InContainer(C, FMath::Max(0.0, HP - static_cast<double>(Damage)));
				return;
			}
			if (FFloatProperty* FP = FindFProperty<FFloatProperty>(C->GetClass(), PropName))
			{
				const float HP = FP->GetPropertyValue_InContainer(C);
				FP->SetPropertyValue_InContainer(C, FMath::Max(0.f, HP - Damage));
				return;
			}
		}
	}

	// No pack health component owns damage — generic engine path (S5-9b).
	UGameplayStatics::ApplyDamage(Target, Damage, nullptr, this, nullptr);
}

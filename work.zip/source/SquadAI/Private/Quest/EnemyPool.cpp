// EnemyPool.cpp — Pre-warmed enemy pool for zero-GC wave spawning
#include "Quest/EnemyPool.h"
#include "SquadTypes.h"
#include "AI/SoldierAIController.h"
#include "Characters/SoldierCharacter.h"
#include "Performance/DifficultySubsystem.h"
#include "Components/HealthComponent.h"
#include "Components/StateTreeAIComponent.h"
#include "Performance/SquadAIRecovery.h"   // S19-ENEMYST: dormant state-tree rescue
#include "TimerManager.h"
#include "Engine/World.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Navigation/PathFollowingComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Animation/AnimInstance.h"
#include "UObject/UnrealType.h"
#include "SquadAITuning.h"
#include "GameFramework/Character.h"

void UEnemyPoolSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
}

void UEnemyPoolSubsystem::Deinitialize()
{
	// Destroy all pooled enemies
	for (auto& Pair : Pool)
	{
		for (FPoolEntry& Entry : Pair.Value)
		{
			if (APawn* P = Entry.Pawn.Get())
			{
				P->Destroy();
			}
		}
	}
	Pool.Empty();
	Super::Deinitialize();
}

void UEnemyPoolSubsystem::Prewarm(TSubclassOf<APawn> EnemyClass, int32 Count)
{
	if (!EnemyClass || Count <= 0) return;

	UWorld* World = GetWorld();
	if (!World) return;

	TArray<FPoolEntry>& ClassPool = Pool.FindOrAdd(EnemyClass.Get());

	FActorSpawnParameters Params;
	Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	for (int32 i = 0; i < Count; ++i)
	{
		// Spawn far away and hidden
		APawn* Enemy = World->SpawnActor<APawn>(EnemyClass,
			FVector(0, 0, -10000.f), FRotator::ZeroRotator, Params);

		if (Enemy)
		{
			SleepEnemy(Enemy);

			// S19-ENEMYST: this is where the 15 x "Could not find context actor of type
			// Pawn ... Component tick is disabled" came from - the pack's state tree on
			// the freshly spawned pawn starts before it is possessed and never retries.
			// Start it now, and again after possession has had time to happen.
			SquadAIRecovery::EnsurePawnStateTreesRunning(Enemy, TEXT("pool prewarm"));
			if (UWorld* RescueWorld = GetWorld())
			{
				FTimerHandle RescueHandle;
				TWeakObjectPtr<APawn> WeakEnemy(Enemy);
				RescueWorld->GetTimerManager().SetTimer(RescueHandle, [WeakEnemy]()
				{
					if (APawn* E = WeakEnemy.Get())
					{
						SquadAIRecovery::EnsurePawnStateTreesRunning(E, TEXT("pool prewarm retry"));
					}
				}, 1.5f, false);
			}

			FPoolEntry Entry;
			Entry.Pawn = Enemy;
			Entry.bAvailable = true;
			ClassPool.Add(Entry);
		}
	}

	UE_LOG(LogSquadAI, Log, TEXT("EnemyPool: prewarmed %d of %s"), Count, *EnemyClass->GetName());
}

APawn* UEnemyPoolSubsystem::Acquire(TSubclassOf<APawn> EnemyClass, FVector Location, FRotator Rotation)
{
	if (!EnemyClass) return nullptr;

	TArray<FPoolEntry>* ClassPool = Pool.Find(EnemyClass.Get());
	if (!ClassPool) return nullptr;

	for (FPoolEntry& Entry : *ClassPool)
	{
		if (Entry.bAvailable && Entry.Pawn.IsValid())
		{
			Entry.bAvailable = false;
			WakeEnemy(Entry.Pawn.Get(), Location, Rotation);
			return Entry.Pawn.Get();
		}
	}

	return nullptr; // Pool exhausted — caller falls back to SpawnActor
}

void UEnemyPoolSubsystem::Release(APawn* Enemy)
{
	if (!Enemy) return;

	for (auto& Pair : Pool)
	{
		for (FPoolEntry& Entry : Pair.Value)
		{
			if (Entry.Pawn.Get() == Enemy)
			{
				SleepEnemy(Enemy);
				Entry.bAvailable = true;
				return;
			}
		}
	}
}

int32 UEnemyPoolSubsystem::GetAvailableCount(TSubclassOf<APawn> EnemyClass) const
{
	if (!EnemyClass) return 0;

	const TArray<FPoolEntry>* ClassPool = Pool.Find(EnemyClass.Get());
	if (!ClassPool) return 0;

	int32 Count = 0;
	for (const FPoolEntry& E : *ClassPool) { if (E.bAvailable) Count++; }
	return Count;
}

void UEnemyPoolSubsystem::SleepEnemy(APawn* Enemy)
{
	if (!Enemy) return;

	// S5-13: a corpse carries SetLifeSpan(10s) from death — a pooled corpse would destroy
	// itself inside the pool (stale entry). Cancel on sleep. S5-12: AI slate reset.
	Enemy->SetLifeSpan(0.f);
	if (ASoldierAIController* AICReset = Cast<ASoldierAIController>(Enemy->GetController()))
	{
		AICReset->ResetCombatState();
	}

	Enemy->SetActorHiddenInGame(true);
	Enemy->SetActorEnableCollision(false);
	Enemy->SetActorTickEnabled(false);
	Enemy->SetActorLocation(FVector(0, 0, -10000.f));

	if (ASoldierAIController* AIC = Cast<ASoldierAIController>(Enemy->GetController()))
	{
		if (UPathFollowingComponent* PFE = AIC->GetPathFollowingComponent())
		{
			PFE->AbortMove(*AIC, FPathFollowingResultFlags::ForcedScript);
		}
		AIC->SetActorTickEnabled(false);
		// Don't unpossess — keep the brain attached to the body to avoid leaks
	}

	if (ACharacter* Char = Cast<ACharacter>(Enemy))
	{
		if (UCharacterMovementComponent* CMC = Char->GetCharacterMovement())
		{
			CMC->StopMovementImmediately();
			CMC->DisableMovement();
		}

		// S14-POOL: released corpses are still RAGDOLLED (HandleDeath). A hidden,
		// collision-less actor with simulating bodies keeps falling forever while
		// it sits in the pool. Kill the physics at sleep; WakeEnemy re-attaches
		// and restores the authored transform.
		if (USkeletalMeshComponent* Mesh = Char->GetMesh())
		{
			// S14-STAB: guard the physics calls — on prewarm sleeps (fresh pawn,
			// collision already disabled) there are no bodies, and each call
			// logged "Invalid Bodies" (10+ warnings at PIE start).
			if (Mesh->Bodies.Num() > 0)
			{
				Mesh->SetAllBodiesSimulatePhysics(false);
				Mesh->SetSimulatePhysics(false);
				Mesh->PutAllRigidBodiesToSleep();
			}
			Mesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		}
	}

	if (UHealthComponent* HC = Enemy->FindComponentByClass<UHealthComponent>())
	{
		HC->CurrentHealth = HC->MaxHealth;
		HC->bIsDead = false;
	}
	// P1-Q2: symmetric unregister — sleeping pawns must not linger in Registry /
	// Significance queries (prewarm phantoms + released corpses). No-op for corpses
	// already unregistered by HandleDeath; WakeEnemy re-registers.
	if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(Enemy))
	{
		Soldier->UnregisterFromSystems();
	}
}

void UEnemyPoolSubsystem::WakeEnemy(APawn* Enemy, FVector Location, FRotator Rotation)
{
	if (!Enemy) return;

	// S14-POOL: defensive — a corpse carries SetLifeSpan(10) from HandleDeath.
	// SleepEnemy cancels it, but a woken pawn must NEVER keep a death timer.
	Enemy->SetLifeSpan(0.f);

	Enemy->SetActorLocation(Location);
	Enemy->SetActorRotation(Rotation);
	Enemy->SetActorHiddenInGame(false);
	Enemy->SetActorEnableCollision(true);
	Enemy->SetActorTickEnabled(true);

	if (ASoldierAIController* AIC = Cast<ASoldierAIController>(Enemy->GetController()))
	{
		AIC->SetActorTickEnabled(true);
		AIC->ResetCombatState(); // S5-12: defensive clean slate on wake as well.
		// Brain is already attached, wake up the StateTree
		if (AIC->StateTreeComp)
		{
			if (!AIC->StateTreeComp->IsRunning())
			{
				AIC->StateTreeComp->StartLogic();
			}
			else
			{
				AIC->StateTreeComp->RestartLogic();
			}
		}
	}
	else
	{
		// Only spawn if missing (first time)
		Enemy->SpawnDefaultController();
	}

	// S19-ENEMYST: the controller's own tree is handled just above; this covers the
	// pack's state tree on the PAWN (and any second tree on the controller), which
	// otherwise stays dead for the whole session after a failed auto-start.
	if (SquadAIRecovery::EnsurePawnStateTreesRunning(Enemy, TEXT("pool wake")) == 0 && GetWorld())
	{
		FTimerHandle WakeRescueHandle;
		TWeakObjectPtr<APawn> WeakWoken(Enemy);
		GetWorld()->GetTimerManager().SetTimer(WakeRescueHandle, [WeakWoken]()
		{
			if (APawn* W = WeakWoken.Get())
			{
				SquadAIRecovery::EnsurePawnStateTreesRunning(W, TEXT("pool wake retry"));
			}
		}, 1.5f, false);
	}

	if (ACharacter* Char = Cast<ACharacter>(Enemy))
	{
		if (UCharacterMovementComponent* CMC = Char->GetCharacterMovement())
		{
			CMC->SetMovementMode(MOVE_Walking);
		}
		
		if (USkeletalMeshComponent* Mesh = Char->GetMesh())
		{
			// S14-POOL: a recycled corpse arrives here RAGDOLLED - HandleDeath
			// calls SetAllBodiesSimulatePhysics(true), lets physics trash the
			// mesh transform, and leaves a death montage on the AnimInstance.
			// S14-POOL2: worse - the PACK death sequence also HIDES the mesh
			// components, and SetActorHiddenInGame(false) does NOT undo
			// component-level hiding. Recycled wave enemies were invisible
			// walking capsules: HUD hostile count climbing, empty-looking map,
			// clear-area quest never finishing. This now mirrors
			// CompleteRevive()'s battle-tested restore ("the pack death
			// sequence hides the mesh; revived allies stayed invisible without
			// this"), except collision comes from the ARCHETYPE (S14-HIT).
			// S14-STAB: physics calls only when bodies exist ("Invalid Bodies" spam).
			if (Mesh->Bodies.Num() > 0)
			{
				Mesh->SetAllPhysicsLinearVelocity(FVector::ZeroVector);
				Mesh->SetAllPhysicsAngularVelocityInDegrees(FVector::ZeroVector);
				Mesh->PutAllRigidBodiesToSleep();
				Mesh->SetAllBodiesSimulatePhysics(false);
				Mesh->SetAllBodiesBelowSimulatePhysics(NAME_None, false, false);
				Mesh->SetSimulatePhysics(false);
			}
			Mesh->SetVisibility(true);
			Mesh->SetHiddenInGame(false);

			const USkeletalMeshComponent* MeshArchXform = Cast<USkeletalMeshComponent>(Mesh->GetArchetype());
			if (UCapsuleComponent* CapParent = Char->GetCapsuleComponent())
			{
				Mesh->AttachToComponent(CapParent, FAttachmentTransformRules::SnapToTargetNotIncludingScale);
			}
			if (MeshArchXform)
			{
				Mesh->SetRelativeLocationAndRotation(
					MeshArchXform->GetRelativeLocation(), MeshArchXform->GetRelativeRotation(),
					false, nullptr, ETeleportType::TeleportPhysics);
			}
			// S14-POOL2: full anim re-init (was StopAllMontages) - clears the
			// death montage AND any lingering death-pose state, same as revive.
			if (UAnimInstance* AnimInst = Mesh->GetAnimInstance())
			{
				AnimInst->InitializeAnimation();
			}

			// S14-HIT: was SetCollisionProfileName("CharacterMesh") - the engine
			// preset whose responses IGNORE ECC_Visibility. The pack characters
			// are authored with a mesh profile that blocks visibility traces, so
			// stamping CharacterMesh here made every pooled enemy transparent to
			// the player's damage trace AND the pack crosshair trace: "bullets
			// won't damage the spawned enemies and the aim icon won't turn red -
			// unlike the one I placed in the map myself." A placed instance never
			// passes through WakeEnemy, which is exactly why only spawns broke.
			// Restore the component's ARCHETYPE profile instead - byte-for-byte
			// what a freshly placed instance of this Blueprint has.
			const USkeletalMeshComponent* MeshArch = Cast<USkeletalMeshComponent>(Mesh->GetArchetype());
			Mesh->SetCollisionProfileName(MeshArch ? MeshArch->GetCollisionProfileName() : TEXT("CharacterMesh"));
			// S14-POOL-B: SleepEnemy sets the mesh to NoCollision WITHOUT
			// changing the profile name — and SetCollisionProfileName EARLY-OUTS
			// when the name is unchanged, so it never re-applied the profile's
			// collision-enabled state. Every pooled mesh stayed NoCollision =
			// unhittable again. Restore the enabled state EXPLICITLY.
			Mesh->SetCollisionEnabled(MeshArch ? MeshArch->GetCollisionEnabled() : ECollisionEnabled::QueryOnly);
		}

		// S14-POOL2 (mirrors G-2): pack BPs own EXTRA skeletal meshes (e.g.
		// CharacterMesh0) that the pack death sequence ragdolls AND hides.
		// Freeze + re-show them too - sim/visibility only, the pack keeps
		// owning attachment, collision and animation.
		{
			TArray<USkeletalMeshComponent*> AllMeshes;
			Char->GetComponents<USkeletalMeshComponent>(AllMeshes);
			for (USkeletalMeshComponent* ExtraMesh : AllMeshes)
			{
				if (!ExtraMesh || ExtraMesh == Char->GetMesh()) continue;
				if (ExtraMesh->Bodies.Num() > 0) // S14-STAB: "Invalid Bodies" guard
				{
					ExtraMesh->SetAllPhysicsLinearVelocity(FVector::ZeroVector);
					ExtraMesh->SetAllPhysicsAngularVelocityInDegrees(FVector::ZeroVector);
					ExtraMesh->PutAllRigidBodiesToSleep();
					ExtraMesh->SetAllBodiesSimulatePhysics(false);
					ExtraMesh->SetSimulatePhysics(false);
				}
				ExtraMesh->SetVisibility(true);
				ExtraMesh->SetHiddenInGame(false);
			}
		}

		if (UCapsuleComponent* Capsule = Char->GetCapsuleComponent())
		{
			// S14-HIT: same archetype restore for the capsule (kill/ragdoll paths
			// may have altered it), then force queries back on.
			if (const UCapsuleComponent* CapArch = Cast<UCapsuleComponent>(Capsule->GetArchetype()))
			{
				Capsule->SetCollisionProfileName(CapArch->GetCollisionProfileName());
			}
			Capsule->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
		}
	}

	if (UHealthComponent* HC = Enemy->FindComponentByClass<UHealthComponent>())
	{
		HC->CurrentHealth = HC->MaxHealth;
		HC->bIsDead = false;
	}

	// S14-HIT: also reset the PACK health component (BPC_HealthAI). Wake only
	// refilled the SquadAI UHealthComponent, so a recycled corpse kept the pack
	// currentHealth at 0 - the pack crosshair saw a dead target (never turned
	// red) and DamagePackEnemy refused it (HP<=0 early-out). Same name-based
	// reflection scheme as the combat bridge.
	{
		TArray<UActorComponent*> PackComps;
		Enemy->GetComponents(PackComps);
		for (UActorComponent* C : PackComps)
		{
			if (!C || !C->GetName().Contains(TEXT("BPC_Health"))) continue;

			double MaxHP = 100.0;
			for (const FName MaxName : { FName(TEXT("maxHealth")), FName(TEXT("MaxHealth")) })
			{
				if (FDoubleProperty* DP = FindFProperty<FDoubleProperty>(C->GetClass(), MaxName)) { MaxHP = DP->GetPropertyValue_InContainer(C); break; }
				if (FFloatProperty* FP = FindFProperty<FFloatProperty>(C->GetClass(), MaxName)) { MaxHP = FP->GetPropertyValue_InContainer(C); break; }
			}
			for (const FName CurName : { FName(TEXT("currentHealth")), FName(TEXT("CurrentHealth")), FName(TEXT("Health")) })
			{
				if (FDoubleProperty* DP = FindFProperty<FDoubleProperty>(C->GetClass(), CurName)) { DP->SetPropertyValue_InContainer(C, MaxHP); break; }
				if (FFloatProperty* FP = FindFProperty<FFloatProperty>(C->GetClass(), CurName)) { FP->SetPropertyValue_InContainer(C, static_cast<float>(MaxHP)); break; }
			}
			for (const FName DeadName : { FName(TEXT("isDead")), FName(TEXT("bIsDead")), FName(TEXT("IsDead")), FName(TEXT("Dead")) })
			{
				if (FBoolProperty* BF = FindFProperty<FBoolProperty>(C->GetClass(), DeadName)) { BF->SetPropertyValue_InContainer(C, false); break; }
			}
		}

		// S14-POOL: HandleDeath propagates death to EVERY component, writing
		// "bIsDead?" (BP bools carry the '?') and "bIsDead" true across the
		// whole pack. Mirror that exactly on wake - clearing only BPC_Health*
		// left the pack anim/behavior components convinced the recycled enemy
		// was still a corpse.
		for (UActorComponent* C : PackComps)
		{
			if (!C) continue;
			if (FBoolProperty* BP = FindFProperty<FBoolProperty>(C->GetClass(), FName(TEXT("bIsDead?"))))
			{
				BP->SetPropertyValue_InContainer(C, false);
			}
			if (FBoolProperty* BP2 = FindFProperty<FBoolProperty>(C->GetClass(), FName(TEXT("bIsDead"))))
			{
				BP2->SetPropertyValue_InContainer(C, false);
			}
		}
	}
	// P1-Q2: pooled re-acquire skips BeginPlay — re-register (RegisterWithSystems applies
	// the CURRENT difficulty AFTER registration, superseding the P1-3 standalone apply).
	if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(Enemy))
	{
		// G-23: every pooled wake gets fresh arrival protection. Player shots still count;
		// HealthComponent only blocks non-player/environment/friendly damage for enemies.
		Soldier->ResetSpawnGracePeriod(14.0f);
		Soldier->RegisterWithSystems();
	}
}

#include "Quest/BattlefieldDecorator.h"
#include "Performance/SquadAIFXManagerSubsystem.h"
#include "Quest/MissionZone.h"
#include "NiagaraSystem.h"
#include "NiagaraFunctionLibrary.h"
#include "NiagaraComponent.h"
#include "Particles/ParticleSystem.h"
#include "Particles/ParticleSystemComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/World.h"
#include "TimerManager.h"

ABattlefieldDecorator::ABattlefieldDecorator()
{
	PrimaryActorTick.bCanEverTick = false;
	USceneComponent* Root = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	SetRootComponent(Root);
}

void ABattlefieldDecorator::BeginPlay()
{
	Super::BeginPlay();

	if (bAutoActivate)
	{
		ActivateEffects();
	}

	// Listen for mission state changes
	if (LinkedMission)
	{
		LinkedMission->OnMissionStateChanged.AddDynamic(this, &ABattlefieldDecorator::HandleMissionStateChanged);
	}
}

void ABattlefieldDecorator::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	DeactivateEffects();
	if (LinkedMission) LinkedMission->OnMissionStateChanged.RemoveDynamic(this, &ABattlefieldDecorator::HandleMissionStateChanged); // MEGA-5 (H-2b)
	Super::EndPlay(EndPlayReason);
}

void ABattlefieldDecorator::HandleMissionStateChanged(AMissionZone* Mission, EMissionZoneState NewState)
{
	if (!Mission) return;
	if (NewState == EMissionZoneState::Active && !bActive)
	{
		ActivateEffects();
	}
	else if ((NewState == EMissionZoneState::Completed || NewState == EMissionZoneState::Failed) && bActive)
	{
		DeactivateEffects();
	}
}

void ABattlefieldDecorator::ActivateEffects()
{
	if (bActive) return;
	bActive = true;

	for (const FBattlefieldEffectEntry& Entry : Effects)
	{
		for (int32 i = 0; i < Entry.SpawnCount; ++i)
		{
			SpawnEffect(Entry);
		}
	}

	if (bLoopEffects && LoopInterval > 0.f)
	{
		TWeakObjectPtr<ABattlefieldDecorator> WeakThis(this);
		GetWorld()->GetTimerManager().SetTimer(LoopTimerHandle, [WeakThis]()
		{
			if (!WeakThis.IsValid() || WeakThis->IsActorBeingDestroyed()) return;
			if (!WeakThis->bActive) return;
			for (const FBattlefieldEffectEntry& Entry : WeakThis->Effects)
			{
				WeakThis->SpawnEffect(Entry);
			}
		}, LoopInterval, true);
	}
}

void ABattlefieldDecorator::DeactivateEffects()
{
	bActive = false;

	if (GetWorld())
	{
		GetWorld()->GetTimerManager().ClearTimer(LoopTimerHandle);
	}

	// S5-8: SpawnedEffects was never filled (components vs actors mismatch above) —
	// deactivate/loop leaked emitters. Now tracked + cleaned.
	for (USceneComponent* Effect : SpawnedEffects)
	{
		if (!Effect || Effect->IsBeingDestroyed()) continue;
		if (UParticleSystemComponent* PSC = Cast<UParticleSystemComponent>(Effect))
		{
			PSC->DeactivateSystem();
		}
		else if (UNiagaraComponent* NC = Cast<UNiagaraComponent>(Effect))
		{
			NC->Deactivate();
		}
		Effect->DestroyComponent();
	}
	SpawnedEffects.Empty();
}

void ABattlefieldDecorator::SpawnEffect(const FBattlefieldEffectEntry& Entry)
{
	UWorld* World = GetWorld();
	if (!World) return;

	const FVector SpawnLoc = GetRandomSpawnLocation(Entry.SpawnRadius);

	// P1-P3: FX-budget gate (fail-open without manager).
	if (USquadAIFXManagerSubsystem* FXSys = USquadAIFXManagerSubsystem::Get(this))
	{
		if (!FXSys->CanSpawnImpactVFX(SpawnLoc)) return;
	}

	if (Entry.NiagaraEffect)
	{
		UNiagaraComponent* NC = UNiagaraFunctionLibrary::SpawnSystemAtLocation(
			World, Entry.NiagaraEffect, SpawnLoc, FRotator::ZeroRotator, Entry.Scale);
		if (NC)
		{
			SpawnedEffects.Add(NC);
		}
	}
	else if (Entry.CascadeEffect)
	{
		UParticleSystemComponent* PSC = UGameplayStatics::SpawnEmitterAtLocation(
			World, Entry.CascadeEffect, SpawnLoc, FRotator::ZeroRotator, Entry.Scale);
		if (PSC)
		{
			SpawnedEffects.Add(PSC);
		}
	}
}

FVector ABattlefieldDecorator::GetRandomSpawnLocation(float Radius) const
{
	const FVector Origin = GetActorLocation();
	const float Angle = FMath::FRandRange(0.f, 2.f * PI);
	const float Dist = FMath::FRandRange(0.f, Radius);
	FVector Point = Origin + FVector(FMath::Cos(Angle) * Dist, FMath::Sin(Angle) * Dist, 0.f);

	// Trace down to find ground
	FHitResult Hit;
	FVector TraceStart = Point + FVector(0, 0, 500.f);
	FVector TraceEnd = Point - FVector(0, 0, 2000.f);
	if (GetWorld()->LineTraceSingleByChannel(Hit, TraceStart, TraceEnd, ECC_WorldStatic))
	{
		return Hit.Location;
	}
	return Point;
}

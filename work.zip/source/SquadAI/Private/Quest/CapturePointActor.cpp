// CapturePointActor.cpp - S19-CAP: presence, colour, and the model's arithmetic applied.

#include "Quest/CapturePointActor.h"

#include "Characters/SoldierCharacter.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "GameFramework/Pawn.h"
#include "Kismet/GameplayStatics.h"

ACapturePointActor::ACapturePointActor()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 0.1f;   // presence does not need every frame

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SetRootComponent(SceneRoot);

	static ConstructorHelpers::FObjectFinder<UStaticMesh> CylMesh(TEXT("/Engine/BasicShapes/Cylinder.Cylinder"));
	static ConstructorHelpers::FObjectFinder<UStaticMesh> CubeMesh(TEXT("/Engine/BasicShapes/Cube.Cube"));
	static ConstructorHelpers::FObjectFinder<UMaterialInterface> BaseMat(TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"));

	// The radius disc: no collision, no shadow - a floor decal in all but name.
	MarkerDisc = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("MarkerDisc"));
	MarkerDisc->SetupAttachment(SceneRoot);
	if (CylMesh.Succeeded()) MarkerDisc->SetStaticMesh(CylMesh.Object);
	if (BaseMat.Succeeded()) MarkerDisc->SetMaterial(0, BaseMat.Object);
	MarkerDisc->SetRelativeScale3D(FVector(4.4f, 4.4f, 0.02f));   // 8.8 m across, ~1.1x the 8 m radius
	MarkerDisc->SetRelativeLocation(FVector(0.f, 0.f, 3.f));
	MarkerDisc->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	MarkerDisc->SetCanEverAffectNavigation(false);
	MarkerDisc->SetCastShadow(false);

	// The pole: a 4 m stick.
	PoleMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("PoleMesh"));
	PoleMesh->SetupAttachment(SceneRoot);
	if (CylMesh.Succeeded()) PoleMesh->SetStaticMesh(CylMesh.Object);
	if (BaseMat.Succeeded()) PoleMesh->SetMaterial(0, BaseMat.Object);
	PoleMesh->SetRelativeScale3D(FVector(0.12f, 0.12f, 2.0f));   // cylinder is 2 m tall x1 -> 4 m
	PoleMesh->SetRelativeLocation(FVector(0.f, 0.f, 100.f));   // S26-DETAIL: base on the ground, not floating 1 m up
	PoleMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	PoleMesh->SetCanEverAffectNavigation(false);

	// The flag: a small plate near the top, tints with ownership.
	FlagMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("FlagMesh"));
	FlagMesh->SetupAttachment(SceneRoot);
	if (CubeMesh.Succeeded()) FlagMesh->SetStaticMesh(CubeMesh.Object);
	if (BaseMat.Succeeded()) FlagMesh->SetMaterial(0, BaseMat.Object);
	FlagMesh->SetRelativeScale3D(FVector(0.9f, 0.08f, 0.6f));
	FlagMesh->SetRelativeLocation(FVector(0.f, 0.f, 170.f));   // S26-DETAIL: near the pole top (200), not 60 cm above it
	FlagMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	FlagMesh->SetCanEverAffectNavigation(false);
}

void ACapturePointActor::BeginPlay()
{
	Super::BeginPlay();

	if (MarkerDisc)
	{
		DiscMID = MarkerDisc->CreateAndSetMaterialInstanceDynamic(0);
	}
	if (FlagMesh)
	{
		FlagMID = FlagMesh->CreateAndSetMaterialInstanceDynamic(0);
	}
	SetMarkerColors(FLinearColor(0.35f, 0.35f, 0.35f, 0.55f), FLinearColor(0.5f, 0.5f, 0.5f, 1.f));
}

void ACapturePointActor::CountPresence(bool& bPlayerInside, bool& bHostileInside) const
{
	bPlayerInside = false;
	bHostileInside = false;

	const UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}

	const float RadiusSq = CaptureRadiusCm * CaptureRadiusCm;
	const float Tol = VerticalToleranceCm;

	if (const APawn* Player = UGameplayStatics::GetPlayerPawn(World, 0))
	{
		const FVector Delta = Player->GetActorLocation() - GetActorLocation();
		if (FVector::DistSquared2D(Player->GetActorLocation(), GetActorLocation()) <= RadiusSq
			&& FMath::Abs(Delta.Z) <= Tol)
		{
			bPlayerInside = true;
		}
	}

	for (TActorIterator<APawn> It(World); It; ++It)
	{
		const ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(*It);
		if (!Soldier || !Soldier->IsAlive() || Soldier->IsAlly())
		{
			continue;
		}
		const FVector Delta = It->GetActorLocation() - GetActorLocation();
		if (FVector::DistSquared2D(It->GetActorLocation(), GetActorLocation()) <= RadiusSq
			&& FMath::Abs(Delta.Z) <= Tol)
		{
			bHostileInside = true;
			break;
		}
	}
}

void ACapturePointActor::SetMarkerColors(const FLinearColor& Disc, const FLinearColor& Flag)
{
	if (DiscMID)
	{
		DiscMID->SetVectorParameterValue(TEXT("Color"), Disc);
	}
	if (FlagMID)
	{
		FlagMID->SetVectorParameterValue(TEXT("Color"), Flag);
	}
}

void ACapturePointActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	bool bPlayerInside = false;
	bool bHostileInside = false;
	CountPresence(bPlayerInside, bHostileInside);

	// -- progress --------------------------------------------------------------
	const float Old = Progress01;
	Progress01 = FCapturePointModel::AdvanceProgress(Progress01, bPlayerInside, bHostileInside,
		CapRate01PerSecond, DeltaTime);

	if (FCapturePointModel::CaptureCrossed(Old, Progress01))
	{
		bCaptured = true;
		OnCaptured.Broadcast(this);
		UE_LOG(LogTemp, Warning, TEXT("[S19-CAP] %s: CAPTURED - now hold it (%.0f s)."),
			*GetName(), PostCaptureHoldSeconds);
	}
	else if (FCapturePointModel::LostCrossed(Old, Progress01))
	{
		bCaptured = false;
		bHoldDone = false;
		bHoldAnnounced = false;
		HeldSeconds = 0.f;
		OnLost.Broadcast(this);
		UE_LOG(LogTemp, Warning, TEXT("[S19-CAP] %s: LOST - hostiles took the flag back."),
			*GetName());
	}

	// -- the hold phase ----------------------------------------------------------
	if (bCaptured && !bHoldDone)
	{
		HeldSeconds = FCapturePointModel::AdvanceHold(HeldSeconds, bPlayerInside, bHostileInside, DeltaTime);
		if (FCapturePointModel::HoldCompleted(HeldSeconds, PostCaptureHoldSeconds))
		{
			bHoldDone = true;
			if (!bHoldAnnounced)
			{
				bHoldAnnounced = true;
				OnHoldCompleted.Broadcast(this);
				UE_LOG(LogTemp, Warning, TEXT("[S19-CAP] %s: HELD - the point is ours."),
					*GetName());
			}
		}
	}

	// -- the colour language -------------------------------------------------------
	CurrentFlow = FCapturePointModel::StateFor(Progress01, bPlayerInside, bHostileInside, bHoldDone);
	switch (CurrentFlow)
	{
	case ECaptureFlowState::Held:
		SetMarkerColors(FLinearColor(0.1f, 0.85f, 0.25f, 0.55f), FLinearColor(0.1f, 0.9f, 0.3f, 1.f));
		break;
	case ECaptureFlowState::Contested:
		// The pulse: contested is the emergency colour.
		SetMarkerColors(FLinearColor(0.9f, 0.12f, 0.1f, 0.6f), FLinearColor(1.f, 0.2f, 0.15f, 1.f));
		break;
	case ECaptureFlowState::Capturing:
		SetMarkerColors(FLinearColor(0.95f, 0.62f, 0.1f, 0.55f), FLinearColor(1.f, 0.7f, 0.15f, 1.f));
		break;
	default:
		SetMarkerColors(FLinearColor(0.35f, 0.35f, 0.35f, 0.55f), FLinearColor(0.5f, 0.5f, 0.5f, 1.f));
		break;
	}
}

ECapturePointState ACapturePointActor::GetPointState() const
{
	switch (CurrentFlow)
	{
	case ECaptureFlowState::Held:      return ECapturePointState::Held;
	case ECaptureFlowState::Contested: return ECapturePointState::Contested;
	case ECaptureFlowState::Capturing: return ECapturePointState::Capturing;
	default:                           return ECapturePointState::Neutral;
	}
}

void ACapturePointActor::ResetPoint()
{
	Progress01 = 0.f;
	HeldSeconds = 0.f;
	bCaptured = false;
	bHoldDone = false;
	bHoldAnnounced = false;
	CurrentFlow = ECaptureFlowState::Neutral;
	SetMarkerColors(FLinearColor(0.35f, 0.35f, 0.35f, 0.55f), FLinearColor(0.5f, 0.5f, 0.5f, 1.f));
}

#include "Quest/SandstormWeatherDirector.h"
#include "Performance/SquadAIAudioSubsystem.h"
#include "Components/AudioComponent.h"
#include "Sound/SoundBase.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/World.h"

ASandstormWeatherDirector::ASandstormWeatherDirector()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 0.1f;

	USceneComponent* Root = CreateDefaultSubobject<USceneComponent>(TEXT("WeatherRoot"));
	SetRootComponent(Root);
}

void ASandstormWeatherDirector::BeginPlay()
{
	Super::BeginPlay();
	SetPhase(EWeatherStormPhase::Clear);
	PhaseTimer = FMath::FRandRange(MinClearDuration, MaxClearDuration);

	// S18-FOGFIX (1): create the howl once, silent, and keep it alive forever.
	if (bPersistentStormAudio && SandstormHowlSound && GetWorld() && GetWorld()->IsGameWorld())
	{
		StormAudioComp = UGameplayStatics::SpawnSound2D(GetWorld(), SandstormHowlSound,
			0.0f, 1.0f, 0.0f, nullptr, false, false);
		if (StormAudioComp)
		{
			StormAudioComp->bIsUISound = true;
			StormAudioComp->bAutoDestroy = false;
			StormAudioComp->SetVolumeMultiplier(0.0f);
			StormAudioComp->Play();
			UE_LOG(LogTemp, Log, TEXT("[WeatherDirector] S18-FOGFIX: storm howl pre-rolled silently at level start."));
		}
	}

	// S18-FOGFIX (2): silent FX prewarm pulse so the dust systems compile now.
	if (bPrewarmStormFX && GetWorld() && GetWorld()->IsGameWorld())
	{
		bPrewarmActive = true;
		PrewarmTimer = FMath::Max(0.1f, PrewarmSeconds);
		// S18-FOGFIX2: pinning intensity at exactly 0 meant any Blueprint that
		// gates its dust/fog on "intensity > 0" never spawned anything, so the
		// prewarm warmed nothing. A hair above zero activates the systems while
		// staying invisible (0.02 is ~2% density).
		StormIntensity = 0.02f;
		TargetIntensity = 0.02f;
		OnWeatherPhaseChanged.Broadcast(EWeatherStormPhase::ApproachingDust);
		UE_LOG(LogTemp, Log, TEXT("[WeatherDirector] S18-FOGFIX: prewarming storm FX for %.2fs (intensity stays 0)."), PrewarmTimer);
	}
}

void ASandstormWeatherDirector::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (StormAudioComp)
	{
		StormAudioComp->Stop();
		StormAudioComp->DestroyComponent(); // S18-FOGFIX: bAutoDestroy is off now
		StormAudioComp = nullptr;
	}
	Super::EndPlay(EndPlayReason);
}

void ASandstormWeatherDirector::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	// S18-FOGFIX: run out the silent prewarm pulse before anything else.
	if (bPrewarmActive)
	{
		PrewarmTimer -= DeltaTime;
		if (PrewarmTimer <= 0.f)
		{
			bPrewarmActive = false;
			StormIntensity = 0.f;
			TargetIntensity = 0.f;
			OnWeatherPhaseChanged.Broadcast(EWeatherStormPhase::Clear);
			UE_LOG(LogTemp, Log, TEXT("[WeatherDirector] S18-FOGFIX: prewarm done, storm FX are warm."));
		}
		return;
	}

	// Smoothly interpolate storm intensity. S18-FOGFIX: a constant-rate ramp over
	// IntensityRampSeconds instead of FInterpTo — the exponential curve dumped most
	// of the volumetric-fog / particle cost into the first second of the storm.
	const float RampStep = DeltaTime / FMath::Max(1.f, IntensityRampSeconds);
	StormIntensity = FMath::FInterpConstantTo(StormIntensity, TargetIntensity, 1.f, RampStep);
	UpdateStormAudio(DeltaTime);

	// S5-10: with auto-cycle disabled, manual TriggerSandstorm/StopSandstorm set a phase and
	// timer that then NEVER counted down (this early return skipped the decrement) — manual
	// storms stalled forever in ApproachingDust/Dissipating. Rule: always PROGRESS an active
	// phase; only block spontaneous storm CREATION (Clear -> ApproachingDust) when auto-cycle
	// is off. A storm that reaches Clear settles there and the timer freezes harmlessly.
	if (!bAutoCycleStorms && CurrentPhase == EWeatherStormPhase::Clear) return;

	PhaseTimer -= DeltaTime;
	if (PhaseTimer <= 0.0f)
	{
		AdvancePhase();
	}
}

void ASandstormWeatherDirector::TriggerSandstorm(float Duration)
{
	StormDuration = FMath::Max(15.f, Duration);
	SetPhase(EWeatherStormPhase::ApproachingDust);
	PhaseTimer = 8.0f; // 8s warning buildup before full haboob
}

void ASandstormWeatherDirector::StopSandstorm()
{
	SetPhase(EWeatherStormPhase::Dissipating);
	PhaseTimer = 10.0f;
}

float ASandstormWeatherDirector::GetCurrentAIVisibilityMultiplier() const
{
	return FMath::Lerp(1.0f, StormAIVisibilityMultiplier, StormIntensity);
}

void ASandstormWeatherDirector::AdvancePhase()
{
	switch (CurrentPhase)
	{
	case EWeatherStormPhase::Clear:
		SetPhase(EWeatherStormPhase::ApproachingDust);
		PhaseTimer = 12.0f;
		break;

	case EWeatherStormPhase::ApproachingDust:
		SetPhase(EWeatherStormPhase::FullHaboob);
		PhaseTimer = StormDuration;
		break;

	case EWeatherStormPhase::FullHaboob:
		SetPhase(EWeatherStormPhase::Dissipating);
		PhaseTimer = 15.0f;
		break;

	case EWeatherStormPhase::Dissipating:
	default:
		SetPhase(EWeatherStormPhase::Clear);
		PhaseTimer = FMath::FRandRange(MinClearDuration, MaxClearDuration);
		break;
	}
}

void ASandstormWeatherDirector::SetPhase(EWeatherStormPhase NewPhase)
{
	CurrentPhase = NewPhase;

	switch (NewPhase)
	{
	case EWeatherStormPhase::Clear:
		TargetIntensity = 0.0f;
		break;
	case EWeatherStormPhase::ApproachingDust:
		TargetIntensity = 0.35f;
		break;
	case EWeatherStormPhase::FullHaboob:
		TargetIntensity = 1.0f;
		break;
	case EWeatherStormPhase::Dissipating:
		TargetIntensity = 0.25f;
		break;
	}

	OnWeatherPhaseChanged.Broadcast(NewPhase);
	UE_LOG(LogTemp, Warning, TEXT("[WeatherDirector] Weather Phase Changed to: %d (Target Intensity: %.2f)"), static_cast<int32>(NewPhase), TargetIntensity);
}

void ASandstormWeatherDirector::UpdateStormAudio(float DeltaTime)
{
	if (!SandstormHowlSound || !GetWorld() || !GetWorld()->IsGameWorld()) return;

	// S18-FOGFIX: the old code spawned a NEW sound every time a storm started and
	// then dropped the pointer with bAutoDestroy = false, so every storm cycle
	// leaked an audio component AND paid a synchronous decode — that is the audio
	// stutter when the fog rolls in. Now there is exactly one component for the
	// lifetime of the level and we only animate its volume.
	if (bPrewarmActive && StormAudioComp)
	{
		StormAudioComp->SetVolumeMultiplier(0.f); // S18-FOGFIX2: silent while warming
		return;
	}

	if (bPersistentStormAudio)
	{
		if (!StormAudioComp)
		{
			return; // BeginPlay could not create it (no world / no sound asset)
		}
		if (!StormAudioComp->IsPlaying())
		{
			StormAudioComp->Play();
		}
		StormAudioComp->SetVolumeMultiplier(FMath::Clamp(StormIntensity, 0.f, 1.f) * 0.95f);
		return;
	}

	// --- legacy spawn-on-demand path (bPersistentStormAudio = false) ----------
	if (StormIntensity > 0.02f)
	{
		if (!StormAudioComp || !StormAudioComp->IsPlaying())
		{
			StormAudioComp = UGameplayStatics::SpawnSound2D(GetWorld(), SandstormHowlSound, 0.001f, 1.0f, 0.0f, nullptr, false, true);
			if (StormAudioComp)
			{
				StormAudioComp->bIsUISound = true;
				StormAudioComp->Play();
			}
		}
		if (StormAudioComp)
		{
			StormAudioComp->SetVolumeMultiplier(StormIntensity * 0.95f);
		}
	}
	else if (StormAudioComp && StormAudioComp->IsPlaying())
	{
		StormAudioComp->FadeOut(2.0f, 0.0f);
		StormAudioComp = nullptr;
	}
}

// QuestZone.cpp — Self-registering trigger volume
#include "Quest/QuestZone.h"
#include "Quest/QuestRegistry.h"
#include "Characters/SoldierCharacter.h"
#include "Components/BoxComponent.h"
#include "Components/SphereComponent.h"
#include "Kismet/GameplayStatics.h"
#include "GenericTeamAgentInterface.h"

AQuestZone::AQuestZone()
{
	PrimaryActorTick.bCanEverTick = false;

	BoxComp = CreateDefaultSubobject<UBoxComponent>(TEXT("Box"));
	BoxComp->SetCollisionProfileName(TEXT("OverlapAllDynamic"));
	BoxComp->SetGenerateOverlapEvents(true);
	BoxComp->SetHiddenInGame(true);
	BoxComp->ShapeColor = FColor::Cyan;
	RootComponent = BoxComp;

	SphereComp = CreateDefaultSubobject<USphereComponent>(TEXT("Sphere"));
	SphereComp->SetupAttachment(RootComponent);
	SphereComp->SetCollisionProfileName(TEXT("OverlapAllDynamic"));
	SphereComp->SetGenerateOverlapEvents(true);
	SphereComp->SetHiddenInGame(true);
}

void AQuestZone::BeginPlay()
{
	Super::BeginPlay();
	ConfigureShape();

	UPrimitiveComponent* ActiveComp = (Shape == EZoneShape::Box)
		? static_cast<UPrimitiveComponent*>(BoxComp)
		: static_cast<UPrimitiveComponent*>(SphereComp);

	ActiveComp->OnComponentBeginOverlap.AddDynamic(this, &AQuestZone::OnOverlapBegin);
	ActiveComp->OnComponentEndOverlap.AddDynamic(this, &AQuestZone::OnOverlapEnd);

	// Self-register with QuestRegistry
	if (ZoneTag.IsValid())
	{
		if (UQuestRegistry* Reg = GetWorld()->GetSubsystem<UQuestRegistry>())
		{
			Reg->Register(ZoneTag, this);
		}
	}
}

void AQuestZone::EndPlay(const EEndPlayReason::Type Reason)
{
	if (ZoneTag.IsValid())
	{
		if (UQuestRegistry* Reg = GetWorld()->GetSubsystem<UQuestRegistry>())
		{
			Reg->Unregister(ZoneTag);
		}
	}
	Super::EndPlay(Reason);
}

void AQuestZone::ConfigureShape()
{
	if (Shape == EZoneShape::Box)
	{
		BoxComp->SetBoxExtent(BoxExtent);
		BoxComp->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
		SphereComp->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		SphereComp->SetGenerateOverlapEvents(false);
	}
	else
	{
		SphereComp->SetSphereRadius(SphereRadius);
		SphereComp->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
		BoxComp->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		BoxComp->SetGenerateOverlapEvents(false);
	}
}

void AQuestZone::OnOverlapBegin(UPrimitiveComponent* Overlapped, AActor* Other,
	UPrimitiveComponent* OtherComp, int32 OtherIdx, bool bSweep, const FHitResult& Hit)
{
	if (Other && Other != this) ActorsInZone.AddUnique(Other);
}

void AQuestZone::OnOverlapEnd(UPrimitiveComponent* Overlapped, AActor* Other,
	UPrimitiveComponent* OtherComp, int32 OtherIdx)
{
	if (Other) ActorsInZone.Remove(Other);
}

bool AQuestZone::IsPlayerInZone() const
{
	APawn* P = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	if (!P) return false;
	return ActorsInZone.ContainsByPredicate([P](const TWeakObjectPtr<AActor>& A) { return A.Get() == P; });
}

static bool IsPackHostile(AActor* Actor, APawn* Player)
{
	// S5-10: pack (non-SquadAI) enemies were invisible to Clear-style checks.
	if (!Actor || Actor == Player) return false;
	const IGenericTeamAgentInterface* TeamAgent = Cast<IGenericTeamAgentInterface>(Actor);
	if (!TeamAgent || !Player) return false;
	if (TeamAgent->GetTeamAttitudeTowards(*Player) != ETeamAttitude::Hostile) return false;
	// No SquadAI IsAlive here — approximate: not destroyed, not hidden.
	return !Actor->IsActorBeingDestroyed() && !Actor->IsHidden();
}

int32 AQuestZone::CountHostilesInZone() const
{
	int32 Count = 0;
	APawn* Player = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	for (const auto& A : ActorsInZone)
	{
		AActor* Actor = A.Get();
		if (!Actor) continue;
		if (const ASoldierCharacter* S = Cast<ASoldierCharacter>(Actor))
		{
			if (S->IsEnemy() && S->IsAlive()) Count++;
		}
		else if (IsPackHostile(Actor, Player))
		{
			Count++;
		}
	}
	return Count;
}

TArray<AActor*> AQuestZone::GetHostilesInZone() const
{
	TArray<AActor*> Result;
	APawn* Player = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	for (const auto& A : ActorsInZone)
	{
		AActor* Actor = A.Get();
		if (!Actor) continue;
		if (ASoldierCharacter* S = Cast<ASoldierCharacter>(Actor))
		{
			if (S->IsEnemy() && S->IsAlive()) Result.Add(S);
		}
		else if (IsPackHostile(Actor, Player))
		{
			Result.Add(Actor);
		}
	}
	return Result;
}

float AQuestZone::GetZoneRadius() const
{
	return (Shape == EZoneShape::Sphere) ? SphereRadius : BoxExtent.GetMax();
}

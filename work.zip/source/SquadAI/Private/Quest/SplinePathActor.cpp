#include "Quest/SplinePathActor.h"
#include "Quest/QuestChain.h"
#include "Characters/SoldierCharacter.h"
#include "Characters/LeaderCharacter.h"
#include "AIController.h"
#include "Characters/EnemySoldier.h"
#include "Performance/SoldierRegistrySubsystem.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Kismet/GameplayStatics.h"
#include "EngineUtils.h"
#include "Engine/World.h"
#include "DrawDebugHelpers.h"

namespace
{
	TArray<TWeakObjectPtr<ASplinePathActor>> GSplineGuides;
}

ASplinePathActor::ASplinePathActor()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.bStartWithTickEnabled = false;
	PrimaryActorTick.TickInterval = 0.2f;
	SplinePath = CreateDefaultSubobject<USplineComponent>(TEXT("SplinePath"));
	SetRootComponent(SplinePath);
	SplinePath->SetClosedLoop(false);
#if WITH_EDITORONLY_DATA
	SplinePath->SetDrawDebug(true);
	SplinePath->EditorUnselectedSplineSegmentColor = FLinearColor(0.f, 0.85f, 1.f);
	SplinePath->EditorSelectedSplineSegmentColor = FLinearColor(1.f, 0.85f, 0.1f);
#endif
	SplinePath->ClearSplinePoints(false);
	SplinePath->AddSplinePoint(FVector(0.f, 0.f, 0.f), ESplineCoordinateSpace::Local, false);
	SplinePath->AddSplinePoint(FVector(1200.f, 0.f, 0.f), ESplineCoordinateSpace::Local, false);
	SplinePath->AddSplinePoint(FVector(2400.f, 400.f, 0.f), ESplineCoordinateSpace::Local, false);
	SplinePath->UpdateSpline();
}

void ASplinePathActor::BeginPlay()
{
	Super::BeginPlay();
	GSplineGuides.AddUnique(this);
	SplineLength = SplinePath ? SplinePath->GetSplineLength() : 0.f;
	if (TriggerMission)
	{
		TriggerMission->OnMissionStateChanged.AddDynamic(this, &ASplinePathActor::HandleMissionStateChanged);
	}
	SetActorTickEnabled(bMarchAlongSpline || bDrawDebug);
	UE_LOG(LogTemp, Warning, TEXT("[PATHDBG] spline BeginPlay %s"), *DescribeForLog());
}

void ASplinePathActor::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	GSplineGuides.RemoveAll([this](const TWeakObjectPtr<ASplinePathActor>& W)
	{
		return !W.IsValid() || W.Get() == this;
	});
	if (TriggerMission) TriggerMission->OnMissionStateChanged.RemoveDynamic(this, &ASplinePathActor::HandleMissionStateChanged); // MEGA-5 (H-2c)
	Super::EndPlay(EndPlayReason);
}

void ASplinePathActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	if (bMarchAlongSpline && bIsActive && !bCompleted)
	{
		MoveFollowersAlongSpline(DeltaTime);
	}
	if (bDrawDebug)
	{
		DrawDebugCorridor();
	}
	else if (!bMarchAlongSpline)
	{
		SetActorTickEnabled(false);
	}
}

#if WITH_EDITOR
void ASplinePathActor::PostEditChangeProperty(FPropertyChangedEvent& E)
{
	Super::PostEditChangeProperty(E);
	if (E.GetPropertyName() == GET_MEMBER_NAME_CHECKED(ASplinePathActor, bSpawnEnemies))
	{
		if (bSpawnEnemies)
		{
			SpawnEnemiesAlongSpline();
			bSpawnEnemies = false;
		}
	}
	if (E.GetPropertyName() == GET_MEMBER_NAME_CHECKED(ASplinePathActor, bRemoveEnemies))
	{
		if (bRemoveEnemies)
		{
			RemoveAllEnemies();
			bRemoveEnemies = false;
		}
	}
}
#endif

void ASplinePathActor::HandleMissionStateChanged(AMissionZone* Mission, EMissionZoneState NewState)
{
	if (Mission == TriggerMission && NewState == EMissionZoneState::Completed && !bIsActive)
	{
		StartSplinePath();
	}
}

void ASplinePathActor::StartSplinePath()
{
	if (bIsActive || bCompleted)
	{
		return;
	}
	if (!SplinePath || SplineLength <= 0.f)
	{
		SplineLength = SplinePath ? SplinePath->GetSplineLength() : 0.f;
	}
	if (SplineLength <= 0.f)
	{
		return;
	}
	bIsActive = true;
	CurrentProgress = 0.f;
	UE_LOG(LogTemp, Warning, TEXT("[PATHDBG] %s: Started. Length=%.0f freeWill=%d"),
		*GetName(), SplineLength, bFreeWill ? 1 : 0);
}

void ASplinePathActor::StopSplinePath()
{
	bIsActive = false;
}

float ASplinePathActor::GetLength() const
{
	return SplinePath ? SplinePath->GetSplineLength() : 0.f;
}

FString ASplinePathActor::DescribeForLog() const
{
	const float Len = GetLength();
	const int32 Pts = SplinePath ? SplinePath->GetNumberOfSplinePoints() : 0;
	return FString::Printf(
		TEXT("actor=%s path=%s pts=%d len=%.0f freeWill=%d to=%s from=%s trigger=%s nearby=%.0f corridor=%.0f look=%.0f"),
		*GetName(),
		*PathName.ToString(),
		Pts,
		Len,
		bFreeWill ? 1 : 0,
		*GetNameSafe(ToMission.Get()),
		*GetNameSafe(FromMission.Get()),
		*GetNameSafe(TriggerMission.Get()),
		NearbyFallbackDistance,
		CorridorHalfWidth,
		LookAheadDistance);
}

FString ASplinePathActor::EvaluateMatch(AMissionZone* CurrentMission, const FVector& PawnLoc, bool& bOutMatch, float& OutDist) const
{
	bOutMatch = false;
	OutDist = TNumericLimits<float>::Max();
	if (bFreeWill)
	{
		return TEXT("skip freeWill");
	}
	if (!SplinePath)
	{
		return TEXT("skip noSplineComp");
	}
	const float Len = SplinePath->GetSplineLength();
	if (Len <= 150.f)
	{
		return FString::Printf(TEXT("skip emptyLen=%.0f pts=%d (add spline points in the viewport — default 2-point spline is too short)"), Len, SplinePath->GetNumberOfSplinePoints());
	}
	if (FromMission && !FromMission->IsComplete())
	{
		return FString::Printf(TEXT("skip fromNotDone=%s"), *GetNameSafe(FromMission.Get()));
	}

	const float Key = SplinePath->FindInputKeyClosestToWorldLocation(PawnLoc);
	const FVector Closest = SplinePath->GetLocationAtSplineInputKey(Key, ESplineCoordinateSpace::World);
	OutDist = FVector::Dist2D(PawnLoc, Closest);

	const bool bTo = (ToMission != nullptr && ToMission == CurrentMission);
	const bool bLegacy = (TriggerMission && TriggerMission->IsComplete() && ToMission == nullptr);

	bool bNearby = false;
	FString NearbyWhy;
	if (!bTo && !bLegacy && ToMission == nullptr && CurrentMission)
	{
		if (OutDist <= NearbyFallbackDistance)
		{
			const FVector Start = SplinePath->GetLocationAtDistanceAlongSpline(0.f, ESplineCoordinateSpace::World);
			const FVector End = SplinePath->GetLocationAtDistanceAlongSpline(Len, ESplineCoordinateSpace::World);
			const FVector MissionLoc = CurrentMission->GetActorLocation();
			const float StartToM = FVector::Dist2D(Start, MissionLoc);
			const float EndToM = FVector::Dist2D(End, MissionLoc);
			const FVector Tang = SplinePath->GetTangentAtSplineInputKey(Key, ESplineCoordinateSpace::World).GetSafeNormal2D();
			const FVector ToM = (MissionLoc - PawnLoc).GetSafeNormal2D();
			const float Align = FVector::DotProduct(Tang, ToM);
			const bool bLeads = (FMath::Min(StartToM, EndToM) + 80.f < FMath::Max(StartToM, EndToM)) || Align > 0.15f;
			if (bLeads)
			{
				bNearby = true;
				NearbyWhy = FString::Printf(TEXT("nearby dist=%.0f startToM=%.0f endToM=%.0f align=%.2f"), OutDist, StartToM, EndToM, Align);
			}
			else
			{
				return FString::Printf(TEXT("skip nearbyNoAlign dist=%.0f startToM=%.0f endToM=%.0f align=%.2f"), OutDist, StartToM, EndToM, Align);
			}
		}
		else
		{
			return FString::Printf(TEXT("skip tooFar dist=%.0f max=%.0f (ToMission is None — set it, or stand closer)"), OutDist, NearbyFallbackDistance);
		}
	}
	else if (!bTo && !bLegacy && ToMission != nullptr)
	{
		return FString::Printf(TEXT("skip toMismatch to=%s current=%s dist=%.0f"),
			*GetNameSafe(ToMission.Get()), *GetNameSafe(CurrentMission), OutDist);
	}

	if (!(bTo || bLegacy || bNearby))
	{
		return TEXT("skip noRule");
	}

	bOutMatch = true;
	if (bTo)
	{
		return FString::Printf(TEXT("MATCH explicit ToMission dist=%.0f"), OutDist);
	}
	if (bLegacy)
	{
		return FString::Printf(TEXT("MATCH legacy TriggerMission dist=%.0f"), OutDist);
	}
	return FString::Printf(TEXT("MATCH %s"), *NearbyWhy);
}

ASplinePathActor* ASplinePathActor::FindGuide(UWorld* World, AMissionZone* CurrentMission, const FVector& PawnLoc, bool bLog)
{
	if (!World)
	{
		if (bLog)
		{
			UE_LOG(LogTemp, Error, TEXT("[PATHDBG] FindGuide world=NULL"));
		}
		return nullptr;
	}
	if (!CurrentMission)
	{
		if (bLog)
		{
			UE_LOG(LogTemp, Warning, TEXT("[PATHDBG] FindGuide currentMission=NULL — cannot match ToMission. Leader will go straight / free nav."));
		}
		return nullptr;
	}

	const float Now = World->GetTimeSeconds();
	const uint32 WorldId = World->GetUniqueID();
	static TWeakObjectPtr<ASplinePathActor> CachedGuide;
	static TWeakObjectPtr<AMissionZone> CachedMission;
	static FVector CachedLoc = FVector::ZeroVector;
	static float CachedTime = -1000.f;
	static uint32 CachedWorldId = 0;
	if (!bLog
		&& CachedWorldId == WorldId
		&& CachedMission.Get() == CurrentMission
		&& (Now - CachedTime) < 0.35f
		&& FVector::DistSquared2D(PawnLoc, CachedLoc) < 62500.f)
	{
		return CachedGuide.Get();
	}

	ASplinePathActor* Best = nullptr;
	float BestScore = TNumericLimits<float>::Max();
	int32 Count = 0;

	for (int32 i = GSplineGuides.Num() - 1; i >= 0; --i)
	{
		ASplinePathActor* S = GSplineGuides[i].Get();
		if (!S)
		{
			GSplineGuides.RemoveAtSwap(i, EAllowShrinking::No);
			continue;
		}
		if (S->GetWorld() != World)
		{
			continue;
		}
		Count++;
		bool bMatch = false;
		float Dist = 0.f;
		const FString Why = S->EvaluateMatch(CurrentMission, PawnLoc, bMatch, Dist);
		if (bLog)
		{
			UE_LOG(LogTemp, Warning, TEXT("[PATHDBG]   spline[%d] %s | %s"), Count - 1, *S->DescribeForLog(), *Why);
		}
		if (!bMatch)
		{
			continue;
		}
		const bool bExplicit = (S->ToMission == CurrentMission);
		const float Score = Dist + (bExplicit ? 0.f : 50000.f);
		if (Score < BestScore)
		{
			BestScore = Score;
			Best = S;
		}
	}

	// Fallback if BeginPlay has not registered yet (very early calls).
	if (Count == 0)
	{
		for (TActorIterator<ASplinePathActor> It(World); It; ++It)
		{
			ASplinePathActor* S = *It;
			if (!S)
			{
				continue;
			}
			GSplineGuides.AddUnique(S);
			Count++;
			bool bMatch = false;
			float Dist = 0.f;
			S->EvaluateMatch(CurrentMission, PawnLoc, bMatch, Dist);
			if (!bMatch)
			{
				continue;
			}
			const bool bExplicit = (S->ToMission == CurrentMission);
			const float Score = Dist + (bExplicit ? 0.f : 50000.f);
			if (Score < BestScore)
			{
				BestScore = Score;
				Best = S;
			}
		}
	}

	CachedGuide = Best;
	CachedMission = CurrentMission;
	CachedLoc = PawnLoc;
	CachedTime = Now;
	CachedWorldId = WorldId;

	if (bLog)
	{
		UE_LOG(LogTemp, Warning, TEXT("[PATHDBG] FindGuide scan=%d picked=%s currentMission=%s pawn=%s"),
			Count, Best ? *Best->GetName() : TEXT("NONE"), *GetNameSafe(CurrentMission), *PawnLoc.ToString());
	}
	return Best;
}

void ASplinePathActor::LogAllGuides(UWorld* World, AMissionZone* CurrentMission, const FVector& PawnLoc)
{
	FindGuide(World, CurrentMission, PawnLoc, true);
}

FVector ASplinePathActor::GetSoftFollowLocation(const FVector& PawnLoc, const FVector& FinalGoal) const
{
	if (!SplinePath)
	{
		return FinalGoal;
	}
	const float Len = SplinePath->GetSplineLength();
	if (Len <= 10.f)
	{
		return FinalGoal;
	}

	const float Key = SplinePath->FindInputKeyClosestToWorldLocation(PawnLoc);
	const float DistOn = SplinePath->GetDistanceAlongSplineAtSplineInputKey(Key);

	// Statically compute monotonic direction along the spline toward FinalGoal
	float Sign = 1.0f;
	if (!FinalGoal.IsNearlyZero())
	{
		const FVector SplineStart = SplinePath->GetLocationAtDistanceAlongSpline(0.f, ESplineCoordinateSpace::World);
		const FVector SplineEnd = SplinePath->GetLocationAtDistanceAlongSpline(Len, ESplineCoordinateSpace::World);
		const float DistStartToGoal = FVector::DistSquared(SplineStart, FinalGoal);
		const float DistEndToGoal = FVector::DistSquared(SplineEnd, FinalGoal);
		Sign = (DistEndToGoal <= DistStartToGoal) ? 1.0f : -1.0f;
	}

	const float EffectiveLookahead = FMath::Max(LookAheadDistance, 650.f);
	float Ahead = DistOn + Sign * EffectiveLookahead;
	Ahead = FMath::Clamp(Ahead, 0.f, Len);

	const bool bReachedMissionEnd = (Sign > 0.f && Ahead >= Len - 200.f) || (Sign < 0.f && Ahead <= 200.f);
	if (bReachedMissionEnd && !FinalGoal.IsNearlyZero())
	{
		return FinalGoal;
	}

	return SplinePath->GetLocationAtDistanceAlongSpline(Ahead, ESplineCoordinateSpace::World);
}

FVector ASplinePathActor::GetFollowLocationSkipping(
	const FVector& PawnLoc,
	const FVector& FinalGoal,
	const TArray<FVector>& HazardCenters,
	const TArray<float>& HazardRadii,
	float ExtraPad) const
{
	FVector Base = GetSoftFollowLocation(PawnLoc, FinalGoal);
	if (!SplinePath || HazardCenters.Num() == 0 || HazardCenters.Num() != HazardRadii.Num())
	{
		return Base;
	}

	auto Blocked = [&](const FVector& P) -> bool
	{
		for (int32 i = 0; i < HazardCenters.Num(); ++i)
		{
			if (FVector::Dist2D(P, HazardCenters[i]) <= (HazardRadii[i] + ExtraPad)
				&& FMath::Abs(P.Z - HazardCenters[i].Z) <= 180.f)
			{
				return true;
			}
		}
		return false;
	};

	if (!Blocked(Base))
	{
		return Base;
	}

	const float Len = SplinePath->GetSplineLength();
	const float Key = SplinePath->FindInputKeyClosestToWorldLocation(PawnLoc);
	const float DistOn = SplinePath->GetDistanceAlongSplineAtSplineInputKey(Key);
	
	float Sign = 1.0f;
	if (!FinalGoal.IsNearlyZero())
	{
		const FVector SplineStart = SplinePath->GetLocationAtDistanceAlongSpline(0.f, ESplineCoordinateSpace::World);
		const FVector SplineEnd = SplinePath->GetLocationAtDistanceAlongSpline(Len, ESplineCoordinateSpace::World);
		Sign = (FVector::DistSquared(SplineEnd, FinalGoal) <= FVector::DistSquared(SplineStart, FinalGoal)) ? 1.0f : -1.0f;
	}

	const float EffectiveLookahead = FMath::Max(LookAheadDistance, 450.f);
	for (int32 Step = 1; Step <= 24; ++Step)
	{
		float Ahead = DistOn + Sign * (EffectiveLookahead + static_cast<float>(Step) * 140.f);
		Ahead = FMath::Clamp(Ahead, 0.f, Len);
		const FVector P = SplinePath->GetLocationAtDistanceAlongSpline(Ahead, ESplineCoordinateSpace::World);
		if (!Blocked(P))
		{
			return P;
		}
		if ((Sign > 0.f && Ahead >= Len - 5.f) || (Sign < 0.f && Ahead <= 5.f))
		{
			break;
		}
	}
	return Base;
}

FVector ASplinePathActor::GetCorridorSlotLocation(const FVector& LeaderLoc, const FVector& FinalGoal, int32 Slot, float Spacing) const
{
	if (!SplinePath)
	{
		return LeaderLoc;
	}
	const float Len = SplinePath->GetSplineLength();
	if (Len <= 10.f)
	{
		return LeaderLoc;
	}

	const float Key = SplinePath->FindInputKeyClosestToWorldLocation(LeaderLoc);
	const float DistOn = SplinePath->GetDistanceAlongSplineAtSplineInputKey(Key);

	float Sign = 1.0f;
	if (!FinalGoal.IsNearlyZero())
	{
		const FVector SplineStart = SplinePath->GetLocationAtDistanceAlongSpline(0.f, ESplineCoordinateSpace::World);
		const FVector SplineEnd = SplinePath->GetLocationAtDistanceAlongSpline(Len, ESplineCoordinateSpace::World);
		Sign = (FVector::DistSquared(SplineEnd, FinalGoal) <= FVector::DistSquared(SplineStart, FinalGoal)) ? 1.0f : -1.0f;
	}

	const int32 Row = (Slot / 2) + 1;
	const float Side = (Slot % 2 == 0) ? 1.f : -1.f;
	const float RowBack = static_cast<float>(Row) * Spacing;
	const float AllyOn = FMath::Clamp(DistOn - Sign * RowBack, 0.f, Len);

	FVector On = SplinePath->GetLocationAtDistanceAlongSpline(AllyOn, ESplineCoordinateSpace::World);
	const FVector Right = SplinePath->GetRightVectorAtDistanceAlongSpline(AllyOn, ESplineCoordinateSpace::World).GetSafeNormal2D();
	const float HalfCorridor = FMath::Min(CorridorHalfWidth * 0.45f, 160.f);
	On += Right * (Side * HalfCorridor);
	return On;
}

void ASplinePathActor::DumpDebugNow()
{
	UE_LOG(LogTemp, Warning, TEXT("[PATHDBG] ==== DUMP %s ===="), *DescribeForLog());
	UWorld* World = GetWorld();
	if (!World)
	{
		UE_LOG(LogTemp, Error, TEXT("[PATHDBG] DumpDebugNow world=NULL"));
		return;
	}

	AMissionZone* Current = nullptr;
	if (AQuestChain* Chain = AQuestChain::FindPreferred(World, false))
	{
		Current = Chain->GetCurrentMission();
	}

	APawn* Leader = nullptr;
	if (USoldierRegistrySubsystem* SR = World->GetSubsystem<USoldierRegistrySubsystem>())
	{
		for (const TWeakObjectPtr<ASoldierCharacter>& W : SR->GetAllSoldiers())
		{
			if (ALeaderCharacter* L = Cast<ALeaderCharacter>(W.Get()))
			{
				Leader = L;
				break;
			}
		}
	}
	if (!Leader)
	{
		for (TActorIterator<ALeaderCharacter> It(World); It; ++It)
		{
			Leader = *It;
			break;
		}
	}
	const FVector PawnLoc = Leader ? Leader->GetActorLocation() : GetActorLocation();
	UE_LOG(LogTemp, Warning, TEXT("[PATHDBG] dump currentMission=%s leader=%s loc=%s"),
		*GetNameSafe(Current), *GetNameSafe(Leader), *PawnLoc.ToString());
	LogAllGuides(World, Current, PawnLoc);
	UE_LOG(LogTemp, Warning, TEXT("[PATHDBG] ==== END DUMP ===="));
}

void ASplinePathActor::DrawDebugCorridor() const
{
	UWorld* World = GetWorld();
	if (!World || !SplinePath)
	{
		return;
	}
	const float Len = SplinePath->GetSplineLength();
	if (Len <= 10.f)
	{
		DrawDebugSphere(World, GetActorLocation(), 80.f, 8, FColor::Red, false, 0.25f, 0, 4.f);
		return;
	}

	const int32 Steps = FMath::Clamp(FMath::CeilToInt(Len / 250.f), 2, 40);
	FVector Prev = SplinePath->GetLocationAtDistanceAlongSpline(0.f, ESplineCoordinateSpace::World);
	for (int32 i = 1; i <= Steps; ++i)
	{
		const float D = Len * (static_cast<float>(i) / static_cast<float>(Steps));
		const FVector Cur = SplinePath->GetLocationAtDistanceAlongSpline(D, ESplineCoordinateSpace::World);
		DrawDebugLine(World, Prev + FVector(0, 0, 40), Cur + FVector(0, 0, 40), FColor::Cyan, false, 0.25f, 0, 6.f);
		const FVector Right = SplinePath->GetRightVectorAtDistanceAlongSpline(D, ESplineCoordinateSpace::World).GetSafeNormal2D() * CorridorHalfWidth;
		DrawDebugLine(World, Cur + Right + FVector(0, 0, 20), Cur - Right + FVector(0, 0, 20), FColor::Yellow, false, 0.25f, 0, 2.f);
		Prev = Cur;
	}
	DrawDebugSphere(World, SplinePath->GetLocationAtDistanceAlongSpline(0.f, ESplineCoordinateSpace::World) + FVector(0, 0, 60), 30.f, 8, FColor::Green, false, 0.25f, 0, 2.f);
	DrawDebugSphere(World, SplinePath->GetLocationAtDistanceAlongSpline(Len, ESplineCoordinateSpace::World) + FVector(0, 0, 60), 30.f, 8, FColor::Orange, false, 0.25f, 0, 2.f);
}

void ASplinePathActor::MoveFollowersAlongSpline(float DeltaTime)
{
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}

	USoldierRegistrySubsystem* SR = World->GetSubsystem<USoldierRegistrySubsystem>();
	auto ForEachAlly = [World, SR](auto&& Fn)
	{
		if (SR)
		{
			for (const TWeakObjectPtr<ASoldierCharacter>& W : SR->GetAllSoldiers())
			{
				ASoldierCharacter* S = W.Get();
				if (!S || !S->IsAlive() || S->IsEnemy())
				{
					continue;
				}
				if (!Fn(S))
				{
					return;
				}
			}
			return;
		}
		for (TActorIterator<ASoldierCharacter> It(World); It; ++It)
		{
			ASoldierCharacter* S = *It;
			if (!S || !S->IsAlive() || S->IsEnemy())
			{
				continue;
			}
			if (!Fn(S))
			{
				return;
			}
		}
	};

	float MoveSpeed = 400.f;
	ForEachAlly([&](ASoldierCharacter* S) -> bool
	{
		if (UCharacterMovementComponent* CMC = S->GetCharacterMovement())
		{
			MoveSpeed = CMC->MaxWalkSpeed;
		}
		return false;
	});

	CurrentProgress += MoveSpeed * DeltaTime;
	if (CurrentProgress >= SplineLength)
	{
		CurrentProgress = SplineLength;
		bIsActive = false;
		bCompleted = true;
		OnSplinePathCompleted.Broadcast();
		UE_LOG(LogTemp, Warning, TEXT("[PATHDBG] %s: Completed!"), *GetName());
		return;
	}

	const FVector TargetLoc = GetSplinePointAtDistance(CurrentProgress);
	ForEachAlly([&](ASoldierCharacter* S) -> bool
	{
		if (AAIController* AIC = Cast<AAIController>(S->GetController()))
		{
			if (FVector::Dist(S->GetActorLocation(), TargetLoc) > AcceptanceRadius)
			{
				AIC->MoveToLocation(TargetLoc, AcceptanceRadius, false, true, true, false, nullptr, true);
			}
		}
		return true;
	});
}

FVector ASplinePathActor::GetSplinePointAtDistance(float Distance) const
{
	if (!SplinePath)
	{
		return GetActorLocation();
	}
	return SplinePath->GetLocationAtDistanceAlongSpline(Distance, ESplineCoordinateSpace::World);
}

void ASplinePathActor::SpawnEnemiesAlongSpline()
{
	UWorld* World = GetWorld();
	if (!World || !SplinePath)
	{
		return;
	}
	SplineLength = SplinePath->GetSplineLength();
	if (SplineLength <= 0.f)
	{
		return;
	}

	TSubclassOf<APawn> SpawnClass = EnemyClass ? EnemyClass : TSubclassOf<APawn>(AEnemySoldier::StaticClass());
	for (int32 i = 0; i < EnemyCount; ++i)
	{
		const float Dist = (SplineLength / (EnemyCount + 1)) * (i + 1);
		FVector BaseLoc = SplinePath->GetLocationAtDistanceAlongSpline(Dist, ESplineCoordinateSpace::World);
		const FVector Right = SplinePath->GetRightVectorAtDistanceAlongSpline(Dist, ESplineCoordinateSpace::World);
		BaseLoc += Right * FMath::FRandRange(-RandomOffset, RandomOffset);

		FHitResult Hit;
		if (World->LineTraceSingleByChannel(Hit, BaseLoc + FVector(0, 0, 500), BaseLoc - FVector(0, 0, 2000), ECC_WorldStatic))
		{
			BaseLoc = Hit.Location;
		}

		FActorSpawnParameters Params;
		Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;
		// S5-14c: WP/lifetime ownership for spawned children.
		Params.Owner = this;
		APawn* Enemy = World->SpawnActor<APawn>(SpawnClass, BaseLoc, FRotator(0, FMath::FRandRange(0.f, 360.f), 0), Params);
		if (Enemy)
		{
			SpawnedEnemies.Add(Enemy);
		}
	}
	UE_LOG(LogTemp, Warning, TEXT("[PATHDBG] %s: Spawned %d enemies along spline"), *GetName(), SpawnedEnemies.Num());
}

void ASplinePathActor::RemoveAllEnemies()
{
	for (APawn* E : SpawnedEnemies)
	{
		if (IsValid(E) && !E->IsActorBeingDestroyed())
		{
			E->Destroy();
		}
	}
	SpawnedEnemies.Empty();
}

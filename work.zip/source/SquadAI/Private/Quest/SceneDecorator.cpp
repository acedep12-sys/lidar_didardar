// SceneDecorator.cpp — Scatters effects and meshes across terrain
// Editor Rebuild spawns immediately as child components (timers do NOT tick in the editor world).
#include "Quest/SceneDecorator.h"
#include "Quest/FireDamageZone.h"
#include "NiagaraSystem.h"
#include "NiagaraFunctionLibrary.h"
#include "NiagaraComponent.h"
#include "Particles/ParticleSystem.h"
#include "Particles/ParticleSystemComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/SphereComponent.h"
#include "Components/SceneComponent.h"
#include "Blueprint/UserWidget.h"
#include "GameFramework/Pawn.h"
#include "GameFramework/PlayerController.h"
#include "Characters/SoldierCharacter.h"
#include "Components/HealthComponent.h"
#include "Engine/World.h"
#include "Engine/StaticMesh.h"
#include "TimerManager.h"
#include "Kismet/GameplayStatics.h"
#include "UObject/UnrealType.h"
#include "UObject/Class.h"
#include "UObject/UObjectIterator.h"
#include "Engine/DamageEvents.h"
#include "GameFramework/DamageType.h"
#include "HUD/QuestNativeHUD.h"

namespace
{
	TArray<TWeakObjectPtr<ASceneDecorator>> GSceneDecorators;
}

ASceneDecorator::ASceneDecorator()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.bStartWithTickEnabled = false;
	PrimaryActorTick.TickInterval = 0.25f;
	USceneComponent* Root = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	SetRootComponent(Root);
	TotalSpawnedCount = 0;
}

void ASceneDecorator::CollectFireHazards(const UWorld* World, TArray<FVector>& OutLoc, TArray<float>& OutRadius)
{
	OutLoc.Reset();
	OutRadius.Reset();
	if (!World)
	{
		return;
	}
	for (int32 i = GSceneDecorators.Num() - 1; i >= 0; --i)
	{
		ASceneDecorator* Deco = GSceneDecorators[i].Get();
		if (!Deco)
		{
			GSceneDecorators.RemoveAtSwap(i, EAllowShrinking::No);
			continue;
		}
		if (Deco->GetWorld() != World)
		{
			continue;
		}
		for (USphereComponent* Sp : Deco->SpawnedDamageSpheres)
		{
			if (!IsValid(Sp) || !Sp->ComponentHasTag(TEXT("SceneDecoratorFire")))
			{
				continue;
			}
			float Radius = Sp->GetScaledSphereRadius();
			if (Radius < 30.f)
			{
				Radius = 180.f;
			}
			OutLoc.Add(Sp->GetComponentLocation());
			OutRadius.Add(Radius);
		}
	}
}

void ASceneDecorator::BeginPlay()
{
	Super::BeginPlay();
	GSceneDecorators.AddUnique(this);

	const bool bHasVisuals = SpawnedNiagaraComps.Num() > 0 || SpawnedCascadeComps.Num() > 0
		|| SpawnedMeshComps.Num() > 0 || SpawnedActors.Num() > 0;
	if (Decorations.Num() > 0 && !bHasVisuals)
	{
		UE_LOG(LogTemp, Warning, TEXT("[SDDBG] %s: BeginPlay auto-rebuild (nothing was spawned in editor)."), *GetName());
		BuildAllDecorations();
	}

	EnsureFireHurtBoxes();
	BindFireHurtBoxes();

	UE_LOG(LogTemp, Warning,
		TEXT("[SDDBG] %s: BeginPlay. Decorations=%d niagara=%d mesh=%d hurtBoxes=%d enableFire=%d dps=%.1f radius=%.0f GameWorld=%d"),
		*GetName(), Decorations.Num(), SpawnedNiagaraComps.Num(), SpawnedMeshComps.Num(),
		SpawnedDamageSpheres.Num(), bEnableFireDamage ? 1 : 0, FireDamagePerSecond, FireDamageRadius,
		(GetWorld() && GetWorld()->IsGameWorld()) ? 1 : 0);

	if (GetWorld() && GetWorld()->IsGameWorld())
	{
		GetWorld()->GetTimerManager().SetTimer(FirePollHandle, this, &ASceneDecorator::PollFireDamage, 0.25f, true);
		// Tick is only a backup if the timer is dead.
		SetActorTickEnabled(!GetWorld()->GetTimerManager().IsTimerActive(FirePollHandle));
		UE_LOG(LogTemp, Warning, TEXT("[SDDBG] %s: Poll+Tick started. HurtBoxes=%d timerSet=%d tickEnabled=%d"),
			*GetName(), SpawnedDamageSpheres.Num(),
			GetWorld()->GetTimerManager().IsTimerActive(FirePollHandle) ? 1 : 0,
			IsActorTickEnabled() ? 1 : 0);
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("[SDDBG] %s: BeginPlay NOT a game world — poll will NOT run until PIE."), *GetName());
	}

	UE_LOG(LogTemp, Warning, TEXT("[SDDBG] %s: BeginPlay done. Call DumpDebugNow for a full snap."), *GetName());
}

void ASceneDecorator::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	// Timer already polls at 0.25s. Tick is only a backup if the timer is dead.
	if (GetWorld() && GetWorld()->IsGameWorld() && !GetWorld()->GetTimerManager().IsTimerActive(FirePollHandle))
	{
		PollFireDamage();
	}
}

void ASceneDecorator::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	GSceneDecorators.Remove(this);
	UE_LOG(LogTemp, Warning, TEXT("[SDDBG] %s: EndPlay reason=%d inFire=%d pollCount=%d"),
		*GetName(), (int32)EndPlayReason, bPlayerInFire ? 1 : 0, DebugPollCount);
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(FirePollHandle);
	}
	HideBurnEffect();
	Super::EndPlay(EndPlayReason);
}

void ASceneDecorator::DumpDebugNow()
{
	DumpDebugSnapshot(TEXT("DumpDebugNow"));
	if (APawn* P = FindPlayerPawn())
	{
		DumpPlayerProbe(P);
	}
}

void ASceneDecorator::RebuildNow()
{
	UE_LOG(LogTemp, Warning, TEXT("[SDDBG] %s: >>> REBUILD NOW. %d decoration entries. World=%s GameWorld=%d"),
		*GetName(), Decorations.Num(),
		GetWorld() ? *GetWorld()->GetName() : TEXT("NULL"),
		(GetWorld() && GetWorld()->IsGameWorld()) ? 1 : 0);
	BuildAllDecorations();
	DumpDebugSnapshot(TEXT("RebuildNow"));
}

void ASceneDecorator::ClearAllNow()
{
	ClearAllDecorations();
}

#if WITH_EDITOR
void ASceneDecorator::PostEditChangeProperty(FPropertyChangedEvent& E)
{
	Super::PostEditChangeProperty(E);

	if (bIsRebuilding)
	{
		return;
	}

	if (E.GetPropertyName() == GET_MEMBER_NAME_CHECKED(ASceneDecorator, bRebuild))
	{
		if (bRebuild)
		{
			bRebuild = false; // clear FIRST — adding components can re-enter this function
			UE_LOG(LogTemp, Warning, TEXT("[SDDBG] %s: >>> REBUILD triggered. %d decoration entries."),
				*GetName(), Decorations.Num());
			RebuildNow();
		}
	}
	if (E.GetPropertyName() == GET_MEMBER_NAME_CHECKED(ASceneDecorator, bClearAll))
	{
		if (bClearAll)
		{
			bClearAll = false;
			ClearAllDecorations();
		}
	}
}
#endif

void ASceneDecorator::ClearAllDecorations()
{
	int32 ActorCount = 0;
	int32 NiagaraCount = 0;
	int32 CascadeCount = 0;
	int32 MeshCount = 0;

	if (UWorld* World = GetWorld())
	{
		for (FTimerHandle& Handle : DeferredBuildHandles)
		{
			World->GetTimerManager().ClearTimer(Handle);
		}
	}
	DeferredBuildHandles.Empty();

	for (AActor* A : SpawnedActors)
	{
		if (IsValid(A) && !A->IsActorBeingDestroyed())
		{
			A->Destroy();
			ActorCount++;
		}
	}
	SpawnedActors.Empty();

	auto DestroyTrackedComponent = [](USceneComponent* Comp)
	{
		if (!IsValid(Comp) || Comp->IsBeingDestroyed())
		{
			return;
		}
		if (AActor* Owner = Comp->GetOwner())
		{
			Owner->RemoveInstanceComponent(Comp);
		}
		Comp->DestroyComponent();
	};

	for (UNiagaraComponent* NC : SpawnedNiagaraComps)
	{
		if (IsValid(NC))
		{
			DestroyTrackedComponent(NC);
			NiagaraCount++;
		}
	}
	SpawnedNiagaraComps.Empty();

	for (UParticleSystemComponent* PSC : SpawnedCascadeComps)
	{
		if (IsValid(PSC))
		{
			DestroyTrackedComponent(PSC);
			CascadeCount++;
		}
	}
	SpawnedCascadeComps.Empty();

	for (UStaticMeshComponent* SMC : SpawnedMeshComps)
	{
		if (IsValid(SMC))
		{
			DestroyTrackedComponent(SMC);
			MeshCount++;
		}
	}
	SpawnedMeshComps.Empty();

	int32 HurtCount = 0;
	for (USphereComponent* Sphere : SpawnedDamageSpheres)
	{
		if (IsValid(Sphere))
		{
			DestroyTrackedComponent(Sphere);
			HurtCount++;
		}
	}
	SpawnedDamageSpheres.Empty();
	FireDPSBySphere.Empty();

	// Also destroy any leftover tagged hurt boxes (PIE copies / stale instance comps)
	TArray<USphereComponent*> AllSpheres;
	GetComponents<USphereComponent>(AllSpheres);
	for (USphereComponent* Sphere : AllSpheres)
	{
		if (IsValid(Sphere) && Sphere->ComponentHasTag(TEXT("SceneDecoratorFire")))
		{
			DestroyTrackedComponent(Sphere);
			HurtCount++;
		}
	}

	TotalSpawnedCount = 0;
	UE_LOG(LogTemp, Warning, TEXT("[SDDBG] %s: Cleared %d actors, %d Niagara, %d Cascade, %d meshes, %d hurtBoxes"),
		*GetName(), ActorCount, NiagaraCount, CascadeCount, MeshCount, HurtCount);
}

void ASceneDecorator::BuildAllDecorations()
{
	if (bIsRebuilding)
	{
		return;
	}
	bIsRebuilding = true;

	ClearAllDecorations();

	if (Decorations.Num() == 0)
	{
		UE_LOG(LogTemp, Error, TEXT("[SDDBG] %s: REBUILD FAILED — Decorations array is EMPTY! Add entries in Details panel."),
			*GetName());
		bIsRebuilding = false;
		return;
	}

	UWorld* World = GetWorld();
	if (!World)
	{
		UE_LOG(LogTemp, Error, TEXT("[SDDBG] %s: REBUILD FAILED — GetWorld() is NULL (CDO / no level world). Place the actor in the map."),
			*GetName());
		bIsRebuilding = false;
		return;
	}

	UE_LOG(LogTemp, Warning, TEXT("[SDDBG] %s: Building %d decoration entries from location %s"),
		*GetName(), Decorations.Num(), *GetActorLocation().ToString());

	// CRITICAL: FTimerManager::SetTimer with Rate <= 0 does NOTHING.
	// Editor worlds also do not tick gameplay timers, so a 0.1s delay never fires
	// until PIE — and then the editor-world timer is gone. Spawn immediately in editor.
	const bool bGameWorld = World->IsGameWorld();
	const bool bDeferAllowed = bGameWorld && SpawnDelay > 0.f;

	float Delay = 0.f;
	int32 ImmediateCount = 0;
	int32 DeferredCount = 0;
	int32 SkippedCount = 0;

	for (int32 EntryIndex = 0; EntryIndex < Decorations.Num(); ++EntryIndex)
	{
		const FDecorationEntry& Entry = Decorations[EntryIndex];

		const bool bHasNiagara = (Entry.NiagaraEffect != nullptr) &&
			(Entry.Type == EDecorationType::NiagaraEffect || Entry.Type == EDecorationType::Both);
		const bool bHasCascade = (Entry.CascadeEffect != nullptr) &&
			(Entry.Type == EDecorationType::NiagaraEffect || Entry.Type == EDecorationType::Both);
		const bool bHasMesh = (Entry.GroundMesh != nullptr) &&
			(Entry.Type == EDecorationType::StaticMesh || Entry.Type == EDecorationType::Both);

		UE_LOG(LogTemp, Warning,
			TEXT("[SDDBG] %s: Entry[%d] '%s' Type=%d Count=%d Radius=%.0f Niagara=%s Cascade=%s Mesh=%s FireDamage=%d"),
			*GetName(), EntryIndex, *Entry.EntryName.ToString(), (int32)Entry.Type, Entry.Count, Entry.MaxRadius,
			Entry.NiagaraEffect ? *Entry.NiagaraEffect->GetName() : TEXT("NULL"),
			Entry.CascadeEffect ? *Entry.CascadeEffect->GetName() : TEXT("NULL"),
			Entry.GroundMesh ? *Entry.GroundMesh->GetName() : TEXT("NULL"),
			Entry.bFireDamage ? 1 : 0);

		if (!bHasNiagara && !bHasCascade && !bHasMesh && !Entry.bFireDamage)
		{
			UE_LOG(LogTemp, Error,
				TEXT("[SDDBG] %s: Entry '%s' SKIPPED — no Niagara/Cascade/Mesh assigned and bFireDamage=false. Set Type=NiagaraEffect or Both and assign a fire Niagara asset."),
				*GetName(), *Entry.EntryName.ToString());
			SkippedCount++;
			continue;
		}

		if (Entry.Count <= 0)
		{
			UE_LOG(LogTemp, Error, TEXT("[SDDBG] %s: Entry '%s' SKIPPED — Count is %d."),
				*GetName(), *Entry.EntryName.ToString(), Entry.Count);
			SkippedCount++;
			continue;
		}

		// Defer only subsequent entries in a running game (GPU courtesy delay).
		const bool bDeferThis = bDeferAllowed && Delay > 0.f;
		if (bDeferThis)
		{
			FTimerHandle TmpHandle;
			FDecorationEntry CapturedEntry = Entry;
			TWeakObjectPtr<ASceneDecorator> WeakThis(this);
			World->GetTimerManager().SetTimer(TmpHandle, [WeakThis, CapturedEntry]()
			{
				if (ASceneDecorator* Self = WeakThis.Get())
				{
					Self->BuildDecoration(CapturedEntry);
				}
			}, Delay, false);
			DeferredBuildHandles.Add(TmpHandle);
			DeferredCount++;
			Delay += SpawnDelay;
		}
		else
		{
			BuildDecoration(Entry);
			ImmediateCount++;
			if (bDeferAllowed)
			{
				Delay += SpawnDelay;
			}
		}
	}

	UE_LOG(LogTemp, Warning,
		TEXT("[SDDBG] %s: Rebuild dispatch done. Immediate=%d Deferred=%d Skipped=%d SpawnDelay=%.2f GameWorld=%d TotalSpawned=%d"),
		*GetName(), ImmediateCount, DeferredCount, SkippedCount, SpawnDelay, bGameWorld ? 1 : 0, TotalSpawnedCount);

	if (ImmediateCount == 0 && DeferredCount == 0)
	{
		UE_LOG(LogTemp, Error, TEXT("[SDDBG] %s: NOTHING was built. Assign a Niagara fire asset (or mesh) on the decoration entry."),
			*GetName());
	}

	bIsRebuilding = false;
}

void ASceneDecorator::BuildDecoration(const FDecorationEntry& Entry)
{
	UWorld* World = GetWorld();
	if (!World)
	{
		UE_LOG(LogTemp, Error, TEXT("[SDDBG] %s: BuildDecoration '%s' FAILED — World is NULL!"), *GetName(), *Entry.EntryName.ToString());
		return;
	}

	TArray<FVector> PlacedPoints;
	int32 Placed = 0;
	int32 Attempts = 0;
	int32 NiagaraSpawned = 0;
	int32 NiagaraFailed = 0;
	int32 GroundMisses = 0;
	const int32 MaxAttempts = FMath::Max(Entry.Count * 20, Entry.Count);

	UE_LOG(LogTemp, Warning,
		TEXT("[SDDBG] %s: Building '%s' — Count=%d Radius=%.0f Type=%d Niagara=%d Cascade=%d Mesh=%d RandomYaw=%d FixedRot=P%.1f Y%.1f R%.1f"),
		*GetName(), *Entry.EntryName.ToString(), Entry.Count, Entry.MaxRadius, (int32)Entry.Type,
		Entry.NiagaraEffect ? 1 : 0, Entry.CascadeEffect ? 1 : 0, Entry.GroundMesh ? 1 : 0,
		Entry.bRandomRotation ? 1 : 0, Entry.FixedRotation.Pitch, Entry.FixedRotation.Yaw, Entry.FixedRotation.Roll);

	while (Placed < Entry.Count && Attempts < MaxAttempts)
	{
		Attempts++;
		FVector RandomPoint = GetRandomPointInRadius(GetActorLocation(), Entry.MaxRadius);
		if (!IsFarEnough(RandomPoint, PlacedPoints, Entry.MinSpacing))
		{
			continue;
		}

		FVector GroundLoc = FindGroundLocation(RandomPoint);
		if (GroundLoc.Equals(RandomPoint, 1.f))
		{
			GroundMisses++;
		}
		PlacedPoints.Add(GroundLoc);

		const FRotator DecoRot = MakeDecorationRotation(Entry);
		if (Placed == 0)
		{
			UE_LOG(LogTemp, Warning, TEXT("[SDDBG] %s: '%s' instance 0 rotation P=%.1f Y=%.1f R=%.1f"),
				*GetName(), *Entry.EntryName.ToString(), DecoRot.Pitch, DecoRot.Yaw, DecoRot.Roll);
		}

		const bool bWantNiagara = Entry.NiagaraEffect &&
			(Entry.Type == EDecorationType::NiagaraEffect || Entry.Type == EDecorationType::Both);
		if (bWantNiagara)
		{
			FVector EffectLoc = GroundLoc + FVector(0, 0, Entry.GroundOffset);
			if (SpawnNiagaraAttached(Entry.NiagaraEffect, EffectLoc, DecoRot, Entry.NiagaraMaxDrawDistance))
			{
				NiagaraSpawned++;
			}
			else
			{
				NiagaraFailed++;
				UE_LOG(LogTemp, Error, TEXT("[SDDBG] %s: FAILED to spawn Niagara '%s' at %s"),
					*GetName(), *Entry.NiagaraEffect->GetName(), *EffectLoc.ToString());
			}
		}

		const bool bWantCascade = Entry.CascadeEffect &&
			(Entry.Type == EDecorationType::NiagaraEffect || Entry.Type == EDecorationType::Both);
		if (bWantCascade)
		{
			FVector EffectLoc = GroundLoc + FVector(0, 0, Entry.GroundOffset);
			if (!SpawnCascadeAttached(Entry.CascadeEffect, EffectLoc, DecoRot, Entry.NiagaraMaxDrawDistance))
			{
				UE_LOG(LogTemp, Error, TEXT("[SDDBG] %s: FAILED to spawn Cascade '%s' at %s"),
					*GetName(), *Entry.CascadeEffect->GetName(), *EffectLoc.ToString());
			}
		}

		const bool bWantMesh = Entry.GroundMesh &&
			(Entry.Type == EDecorationType::StaticMesh || Entry.Type == EDecorationType::Both);
		if (bWantMesh)
		{
			FVector MeshLoc = GroundLoc + FVector(0, 0, Entry.MeshGroundOffset);
			FVector Scale;
			Scale.X = FMath::FRandRange(Entry.MeshScaleMin.X, Entry.MeshScaleMax.X);
			Scale.Y = FMath::FRandRange(Entry.MeshScaleMin.Y, Entry.MeshScaleMax.Y);
			Scale.Z = FMath::FRandRange(Entry.MeshScaleMin.Z, Entry.MeshScaleMax.Z);

			if (!SpawnMeshAttached(Entry.GroundMesh, MeshLoc, DecoRot, Scale, Entry.MeshMaxDrawDistance))
			{
				UE_LOG(LogTemp, Error, TEXT("[SDDBG] %s: FAILED to spawn mesh at %s"),
					*GetName(), *MeshLoc.ToString());
			}
		}

		const bool bWantFireDamage = bEnableFireDamage || Entry.bFireDamage;
		if (bWantFireDamage)
		{
			// Use the entry radius (visual flame), not the large actor default.
			float Radius = Entry.FireDamageRadius > 0.f ? Entry.FireDamageRadius : FireDamageRadius;
			if (Radius > 220.f)
			{
				Radius = 180.f;
			}
			// P1-9: per-entry DPS with actor fallback (was: actor DPS always).
			const float DPS = Entry.FireDamagePerSecond > 0.f ? Entry.FireDamagePerSecond : FireDamagePerSecond;
			SpawnFireHurtBox(GroundLoc + FVector(0, 0, Entry.GroundOffset), Radius, DPS);
		}

		Placed++;
	}

	UE_LOG(LogTemp, Warning,
		TEXT("[SDDBG] %s: Placed '%s' — %d/%d (attempts=%d groundMisses=%d niagaraOk=%d niagaraFail=%d totalSpawned=%d)"),
		*GetName(), *Entry.EntryName.ToString(), Placed, Entry.Count, Attempts, GroundMisses, NiagaraSpawned, NiagaraFailed, TotalSpawnedCount);

	if (Placed == 0)
	{
		UE_LOG(LogTemp, Error,
			TEXT("[SDDBG] %s: Placed 0 copies of '%s'. Count=%d MinSpacing=%.0f MaxRadius=%.0f — spacing may be larger than the radius."),
			*GetName(), *Entry.EntryName.ToString(), Entry.Count, Entry.MinSpacing, Entry.MaxRadius);
	}
}

FRotator ASceneDecorator::MakeDecorationRotation(const FDecorationEntry& Entry) const
{
	FRotator Rot = Entry.FixedRotation;
	if (Entry.bRandomRotation)
	{
		Rot.Yaw += FMath::FRandRange(0.f, 360.f);
	}
	return Rot;
}

void ASceneDecorator::ApplyWorldTM(USceneComponent* Comp, const FVector& WorldLoc, const FRotator& WorldRot, const FVector& Scale)
{
	if (!Comp || !GetRootComponent())
	{
		return;
	}

	const FTransform ParentWorld = GetRootComponent()->GetComponentTransform();
	const FTransform WorldTM(WorldRot, WorldLoc, Scale);
	Comp->SetUsingAbsoluteLocation(false);
	Comp->SetUsingAbsoluteRotation(false);
	Comp->SetUsingAbsoluteScale(false);
	Comp->SetRelativeTransform(WorldTM.GetRelativeTransform(ParentWorld));
}

UNiagaraComponent* ASceneDecorator::SpawnNiagaraAttached(UNiagaraSystem* System, const FVector& WorldLoc, const FRotator& WorldRot, float CullDistance)
{
	if (!System || !GetRootComponent())
	{
		return nullptr;
	}

	UNiagaraComponent* NC = NewObject<UNiagaraComponent>(this, NAME_None, RF_Transactional);
	if (!NC)
	{
		return nullptr;
	}

	NC->SetAsset(System);
	NC->SetAutoDestroy(false);
	NC->SetAutoActivate(true);
	NC->SetupAttachment(GetRootComponent());
	NC->SetCullDistance(CullDistance);
	ApplyWorldTM(NC, WorldLoc, WorldRot, FVector::OneVector);
	NC->RegisterComponent();
	ApplyWorldTM(NC, WorldLoc, WorldRot, FVector::OneVector);
	AddInstanceComponent(NC);
	NC->Activate(true);

	SpawnedNiagaraComps.Add(NC);
	TotalSpawnedCount++;
	return NC;
}

UParticleSystemComponent* ASceneDecorator::SpawnCascadeAttached(UParticleSystem* Template, const FVector& WorldLoc, const FRotator& WorldRot, float CullDistance)
{
	if (!Template || !GetRootComponent())
	{
		return nullptr;
	}

	UParticleSystemComponent* PSC = NewObject<UParticleSystemComponent>(this, NAME_None, RF_Transactional);
	if (!PSC)
	{
		return nullptr;
	}

	PSC->SetTemplate(Template);
	PSC->bAutoDestroy = false;
	PSC->SetAutoActivate(true);
	PSC->SetupAttachment(GetRootComponent());
	PSC->SetCullDistance(CullDistance);
	ApplyWorldTM(PSC, WorldLoc, WorldRot, FVector::OneVector);
	PSC->RegisterComponent();
	ApplyWorldTM(PSC, WorldLoc, WorldRot, FVector::OneVector);
	AddInstanceComponent(PSC);
	PSC->Activate(true);

	SpawnedCascadeComps.Add(PSC);
	TotalSpawnedCount++;
	return PSC;
}

UStaticMeshComponent* ASceneDecorator::SpawnMeshAttached(UStaticMesh* Mesh, const FVector& WorldLoc, const FRotator& WorldRot, const FVector& Scale, float CullDistance)
{
	if (!Mesh || !GetRootComponent())
	{
		return nullptr;
	}

	UStaticMeshComponent* SMC = NewObject<UStaticMeshComponent>(this, NAME_None, RF_Transactional);
	if (!SMC)
	{
		return nullptr;
	}

	SMC->SetStaticMesh(Mesh);
	SMC->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	SMC->SetCullDistance(CullDistance);
	SMC->SetCastShadow(false);
	SMC->SetupAttachment(GetRootComponent());
	ApplyWorldTM(SMC, WorldLoc, WorldRot, Scale);
	SMC->RegisterComponent();
	ApplyWorldTM(SMC, WorldLoc, WorldRot, Scale);
	AddInstanceComponent(SMC);

	SpawnedMeshComps.Add(SMC);
	TotalSpawnedCount++;
	return SMC;
}

void ASceneDecorator::SpawnFireDamageZone(const FVector& Location, float Radius, float DamagePerSecond)
{
	// Kept for compatibility — separate FireDamageZone actors do not survive PIE / World Partition.
	SpawnFireHurtBox(Location, Radius, DamagePerSecond);
}

USphereComponent* ASceneDecorator::SpawnFireHurtBox(const FVector& WorldLoc, float Radius, float DamagePerSecond)
{
	if (!GetRootComponent())
	{
		UE_LOG(LogTemp, Error, TEXT("[SDDBG] %s: SpawnFireHurtBox FAILED — no root. loc=%s"), *GetName(), *WorldLoc.ToString());
		return nullptr;
	}

	USphereComponent* Sphere = NewObject<USphereComponent>(this, NAME_None, RF_Transactional);
	if (!Sphere)
	{
		return nullptr;
	}

	Sphere->SetupAttachment(GetRootComponent());
	Sphere->SetSphereRadius(Radius);
	Sphere->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
	Sphere->SetCollisionObjectType(ECC_WorldDynamic);
	Sphere->SetCollisionResponseToAllChannels(ECR_Overlap);
	Sphere->SetGenerateOverlapEvents(true);
	Sphere->SetCanEverAffectNavigation(false);
	Sphere->ComponentTags.Add(TEXT("SceneDecoratorFire"));
	ApplyWorldTM(Sphere, WorldLoc, FRotator::ZeroRotator, FVector::OneVector);
	Sphere->RegisterComponent();
	ApplyWorldTM(Sphere, WorldLoc, FRotator::ZeroRotator, FVector::OneVector);
	AddInstanceComponent(Sphere);
	Sphere->UpdateOverlaps();

	SpawnedDamageSpheres.Add(Sphere);
	// P1-9: remember this box's DPS so the poll can aggregate overlaps by max.
	FireDPSBySphere.Add(Sphere, DamagePerSecond);
	TotalSpawnedCount++;

	UE_LOG(LogTemp, Warning, TEXT("[SDDBG] %s: HurtBox spawned at %s radius=%.0f dps=%.1f (total=%d)"),
		*GetName(), *WorldLoc.ToString(), Radius, DamagePerSecond, SpawnedDamageSpheres.Num());
	return Sphere;
}

void ASceneDecorator::EnsureFireHurtBoxes()
{
	SpawnedDamageSpheres.Reset();
	TArray<USphereComponent*> AllSpheres;
	GetComponents<USphereComponent>(AllSpheres);
	for (USphereComponent* Sphere : AllSpheres)
	{
		if (IsValid(Sphere) && Sphere->ComponentHasTag(TEXT("SceneDecoratorFire")))
		{
			SpawnedDamageSpheres.AddUnique(Sphere);
		}
	}

	if (SpawnedDamageSpheres.Num() > 0)
	{
		UE_LOG(LogTemp, Warning, TEXT("[SDDBG] %s: Using %d existing tagged hurt boxes."),
			*GetName(), SpawnedDamageSpheres.Num());
		return;
	}

	if (!bEnableFireDamage)
	{
		UE_LOG(LogTemp, Warning, TEXT("[SDDBG] %s: bEnableFireDamage is OFF and no tagged hurt boxes."), *GetName());
		return;
	}

	auto SpawnAtNiagara = [this](UNiagaraComponent* NC)
	{
		if (IsValid(NC))
		{
			SpawnFireHurtBox(NC->GetComponentLocation(), FireDamageRadius, FireDamagePerSecond);
		}
	};

	int32 Before = SpawnedDamageSpheres.Num();
	for (UNiagaraComponent* NC : SpawnedNiagaraComps)
	{
		SpawnAtNiagara(NC);
	}
	if (SpawnedDamageSpheres.Num() == Before)
	{
		TArray<UNiagaraComponent*> NiagaraComps;
		GetComponents<UNiagaraComponent>(NiagaraComps);
		for (UNiagaraComponent* NC : NiagaraComps)
		{
			SpawnAtNiagara(NC);
		}
	}

	UE_LOG(LogTemp, Warning, TEXT("[SDDBG] %s: EnsureFireHurtBoxes created %d boxes (radius=%.0f dps=%.1f)."),
		*GetName(), SpawnedDamageSpheres.Num() - Before, FireDamageRadius, FireDamagePerSecond);
}

void ASceneDecorator::BindFireHurtBoxes()
{
	for (USphereComponent* Sphere : SpawnedDamageSpheres)
	{
		if (IsValid(Sphere))
		{
			Sphere->UpdateOverlaps();
		}
	}
}

APawn* ASceneDecorator::FindPlayerPawn() const
{
	UWorld* World = GetWorld();
	if (!World)
	{
		return nullptr;
	}
	if (APlayerController* PC = World->GetFirstPlayerController())
	{
		if (APawn* Pawn = PC->GetPawn())
		{
			return Pawn;
		}
	}
	return UGameplayStatics::GetPlayerPawn(World, 0);
}

void ASceneDecorator::PollFireDamage()
{
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}

	const float Now = World->GetTimeSeconds();
	if (LastPollTime >= 0.f && (Now - LastPollTime) < 0.20f)
	{
		return;
	}
	LastPollTime = Now;

	TArray<USphereComponent*> Boxes;
	for (USphereComponent* Sphere : SpawnedDamageSpheres)
	{
		if (IsValid(Sphere))
		{
			Boxes.Add(Sphere);
		}
	}

	APawn* Player = FindPlayerPawn();
	DebugPollCount++;
	if (Boxes.Num() == 0 || !Player)
	{
		if (Now - LastFireDebugLog >= 8.f)
		{
			LastFireDebugLog = Now;
			UE_LOG(LogTemp, Error, TEXT("[SDDBG] %s: poll IDLE boxes=%d player=%s poll#=%d — cannot damage"),
				*GetName(), Boxes.Num(), *GetNameSafe(Player), DebugPollCount);
		}
		return;
	}

	if (!bLoggedPlayerProbe)
	{
		bLoggedPlayerProbe = true;
		DumpPlayerProbe(Player);
	}

	const FVector PlayerLoc = Player->GetActorLocation();
	bool bInside = false;
	float BestRadius = 0.f;
	float BestDPS = 0.f;
	float NearestXY = TNumericLimits<float>::Max();
	FVector NearestFire = FVector::ZeroVector;
	float NearestRadius = 0.f;

	for (USphereComponent* Sphere : Boxes)
	{
		if (!IsValid(Sphere))
		{
			continue;
		}
		const FVector FireLoc = Sphere->GetComponentLocation();
		const float Radius = Sphere->GetScaledSphereRadius();
		const float DistXY = FVector::Dist2D(PlayerLoc, FireLoc);
		const float DistZ = FMath::Abs(PlayerLoc.Z - FireLoc.Z);
		if (DistXY < NearestXY)
		{
			NearestXY = DistXY;
			NearestFire = FireLoc;
			NearestRadius = Radius;
		}
		// Stand IN the flame only (capsule ~34uu). No 800uu inflate.
		if (DistXY <= Radius && DistZ <= 180.f)
		{
			bInside = true;
			BestRadius = Radius;
			// P1-9: overlapping boxes aggregate by MAX dps (never summed).
			const float BoxDPS = FireDPSBySphere.FindRef(Sphere);
			BestDPS = FMath::Max(BestDPS, BoxDPS > 0.f ? BoxDPS : FireDamagePerSecond);
		}
	}

	if (Now - LastFireDebugLog >= 8.f)
	{
		LastFireDebugLog = Now;
		const float DistZ = FMath::Abs(PlayerLoc.Z - NearestFire.Z);
		UE_LOG(LogTemp, Warning,
			TEXT("[SDDBG] HEART actor=%s poll#=%d boxes=%d player=%s loc=%s nearestXY=%.0f nearestZ=%.0f radius=%.0f fire=%s inside=%d inFireState=%d dps=%.1f accrue=%.2f"),
			*GetName(), DebugPollCount, Boxes.Num(), *GetNameSafe(Player), *PlayerLoc.ToString(),
			NearestXY, DistZ, NearestRadius, *NearestFire.ToString(), bInside ? 1 : 0,
			bPlayerInFire ? 1 : 0, FireDamagePerSecond, FireDamageAccrue);
	}

	if (bInside)
	{
		if (!bPlayerInFire)
		{
			bPlayerInFire = true;
			FireDamageAccrue = 0.f;
			EnterBurnVisualState(Player); // S5-8c
			UE_LOG(LogTemp, Warning, TEXT("[SDDBG] %s: Player ENTERED fire. DPS=%.1f radius=%.0f player=%s"),
				*GetName(), BestDPS, BestRadius, *GetNameSafe(Player));
			ApplyFireDamageToActor(Player, BestDPS);
		}

		FireDamageAccrue += 0.25f;
		if (FireDamageAccrue >= 1.0f)
		{
			FireDamageAccrue -= 1.0f;
			ApplyFireDamageToActor(Player, BestDPS);
		}
	}
	else if (bPlayerInFire)
	{
		bPlayerInFire = false;
		FireDamageAccrue = 0.f;
		LeaveBurnVisualState(Player); // S5-8c
		UE_LOG(LogTemp, Warning, TEXT("[SDDBG] %s: Player LEFT fire."), *GetName());
	}
}

UActorComponent* ASceneDecorator::FindPackHealthComp(AActor* Target) const
{
	if (!Target)
	{
		return nullptr;
	}
	if (UActorComponent* Cached = CachedPackHealthComp.Get())
	{
		if (Cached->GetOwner() == Target)
		{
			return Cached;
		}
	}
	TArray<UActorComponent*> Comps;
	Target->GetComponents(Comps);
	for (UActorComponent* C : Comps)
	{
		if (!C)
		{
			continue;
		}
		const FString N = C->GetName();
		const FString ClassN = C->GetClass()->GetName();
		if (N.Contains(TEXT("Health")) || ClassN.Contains(TEXT("Health")))
		{
			const_cast<ASceneDecorator*>(this)->CachedPackHealthComp = C;
			return C;
		}
	}
	return nullptr;
}

TSubclassOf<UDamageType> ASceneDecorator::ResolveFireDamageType(UActorComponent* Health) const
{
	if (bResolvedFireDamageType && CachedFireDamageType)
	{
		return CachedFireDamageType;
	}

	auto Cache = [this](TSubclassOf<UDamageType> Cls) -> TSubclassOf<UDamageType>
	{
		ASceneDecorator* Mut = const_cast<ASceneDecorator*>(this);
		Mut->CachedFireDamageType = Cls;
		Mut->bResolvedFireDamageType = true;
		return Cls;
	};

	if (Health)
	{
		if (FObjectProperty* OP = FindFProperty<FObjectProperty>(Health->GetClass(), TEXT("fireDamageType")))
		{
			if (UObject* Obj = OP->GetObjectPropertyValue_InContainer(Health))
			{
				if (UClass* Cls = Cast<UClass>(Obj))
				{
					if (Cls->IsChildOf(UDamageType::StaticClass()))
					{
						UE_LOG(LogTemp, Warning, TEXT("[SDDBG] fireDamageType class=%s"), *Cls->GetName());
						return Cache(Cls);
					}
				}
				if (UDamageType* DT = Cast<UDamageType>(Obj))
				{
					UE_LOG(LogTemp, Warning, TEXT("[SDDBG] fireDamageType instance class=%s"), *DT->GetClass()->GetName());
					return Cache(DT->GetClass());
				}
			}
		}
		if (FClassProperty* CP = FindFProperty<FClassProperty>(Health->GetClass(), TEXT("fireDamageType")))
		{
			if (UObject* ClsObj = CP->GetObjectPropertyValue_InContainer(Health))
			{
				if (UClass* Cls = Cast<UClass>(ClsObj))
				{
					UE_LOG(LogTemp, Warning, TEXT("[SDDBG] fireDamageType FClassProperty=%s"), *Cls->GetName());
					return Cache(Cls);
				}
			}
		}
	}

	for (TObjectIterator<UClass> It; It; ++It)
	{
		if (!It->IsChildOf(UDamageType::StaticClass()) || It->HasAnyClassFlags(CLASS_Abstract))
		{
			continue;
		}
		const FString N = It->GetName();
		if (N.Contains(TEXT("Fire")) || N.Contains(TEXT("Burn")) || N.Contains(TEXT("Flame")))
		{
			UE_LOG(LogTemp, Warning, TEXT("[SDDBG] found fire DamageType class=%s path=%s"), *N, *It->GetPathName());
			return Cache(*It);
		}
	}
	return Cache(UDamageType::StaticClass());
}

void ASceneDecorator::SetPackBurning(AActor* Target, bool bBurning)
{
	UActorComponent* Health = FindPackHealthComp(Target);
	if (!Health)
	{
		UE_LOG(LogTemp, Error, TEXT("[SDDBG] SetPackBurning: no health comp on %s"), *GetNameSafe(Target));
		return;
	}

	const double Dps = bBurning ? static_cast<double>(FireDamagePerSecond) : 0.0;
	if (FDoubleProperty* DP = FindFProperty<FDoubleProperty>(Health->GetClass(), TEXT("fireDamage")))
	{
		DP->SetPropertyValue_InContainer(Health, Dps);
		UE_LOG(LogTemp, Warning, TEXT("[SDDBG] set fireDamage=%.1f on %s (burning=%d)"),
			Dps, *Health->GetName(), bBurning ? 1 : 0);
	}
	else if (FFloatProperty* FP = FindFProperty<FFloatProperty>(Health->GetClass(), TEXT("fireDamage")))
	{
		FP->SetPropertyValue_InContainer(Health, static_cast<float>(Dps));
	}

	if (FObjectProperty* OP = FindFProperty<FObjectProperty>(Health->GetClass(), TEXT("fireDamageCauser")))
	{
		OP->SetObjectPropertyValue_InContainer(Health, bBurning ? this : nullptr);
	}

	const double HP = ReadPackDouble(Health, TEXT("currentHealth"));
	const double MaxHP = ReadPackDouble(Health, TEXT("maxHealth"));
	CallPackFunction(Health, FName(TEXT("SetIsOnFire")), Target, FireDamagePerSecond, HP, MaxHP, bBurning);
	if (!bBurning)
	{
		CallPackFunction(Health, FName(TEXT("SetOnFireClear")), Target, 0.f, HP, MaxHP, false);
	}
}

double ASceneDecorator::ReadPackDouble(UObject* Obj, const TCHAR* PropName) const
{
	if (!Obj)
	{
		return 0.0;
	}
	if (FDoubleProperty* DP = FindFProperty<FDoubleProperty>(Obj->GetClass(), PropName))
	{
		return DP->GetPropertyValue_InContainer(Obj);
	}
	if (FFloatProperty* FP = FindFProperty<FFloatProperty>(Obj->GetClass(), PropName))
	{
		return static_cast<double>(FP->GetPropertyValue_InContainer(Obj));
	}
	return 0.0;
}

void ASceneDecorator::BroadcastZeroParam(UObject* Obj, FName DelegateName)
{
	if (!Obj)
	{
		return;
	}
	if (FMulticastInlineDelegateProperty* Prop = FindFProperty<FMulticastInlineDelegateProperty>(Obj->GetClass(), DelegateName))
	{
		FMulticastScriptDelegate* Del = Prop->ContainerPtrToValuePtr<FMulticastScriptDelegate>(Obj);
		if (Del)
		{
			UE_LOG(LogTemp, Warning, TEXT("[SDDBG] broadcast %s on %s bound=%d"),
				*DelegateName.ToString(), *Obj->GetName(), Del->IsBound() ? 1 : 0);
			Del->template ProcessMulticastDelegate<UObject>(nullptr);
			return;
		}
	}
	UE_LOG(LogTemp, Warning, TEXT("[SDDBG] broadcast %s MISSING on %s"),
		*DelegateName.ToString(), *Obj->GetName());
}

bool ASceneDecorator::CallPackFunction(UObject* Obj, FName FuncName, AActor* Target, float Damage, double HealthNow, double MaxHealth, bool bBoolArg)
{
	if (!Obj)
	{
		return false;
	}
	UFunction* Fn = Obj->FindFunction(FuncName);
	if (!Fn)
	{
		UE_LOG(LogTemp, Warning, TEXT("[SDDBG] no func %s on %s"), *FuncName.ToString(), *Obj->GetName());
		return false;
	}

	TArray<uint8> Params;
	Params.SetNumZeroed(Fn->ParmsSize);

	int32 Index = 0;
	for (TFieldIterator<FProperty> Pit(Fn); Pit && (Pit->PropertyFlags & CPF_Parm); ++Pit, ++Index)
	{
		FProperty* P = *Pit;
		if (P->HasAnyPropertyFlags(CPF_ReturnParm))
		{
			continue;
		}
		const bool bOutOnly = P->HasAnyPropertyFlags(CPF_OutParm) && !P->HasAnyPropertyFlags(CPF_ReferenceParm);
		const FString Pn = P->GetName();
		UE_LOG(LogTemp, Warning, TEXT("[SDDBG]   %s arg[%d] %s type=%s size=%d out=%d"),
			*FuncName.ToString(), Index, *Pn, *P->GetClass()->GetName(), P->GetSize(), bOutOnly ? 1 : 0);
		if (bOutOnly)
		{
			continue;
		}

		const bool bMax = Pn.Contains(TEXT("Max"), ESearchCase::IgnoreCase);
		const bool bHealth = Pn.Contains(TEXT("Health"), ESearchCase::IgnoreCase) || Pn.Contains(TEXT("HP"), ESearchCase::CaseSensitive);
		const bool bDmg = Pn.Contains(TEXT("Damage"), ESearchCase::IgnoreCase) || Pn.Contains(TEXT("Dmg"), ESearchCase::IgnoreCase);
		const bool bDur = Pn.Contains(TEXT("Duration"), ESearchCase::IgnoreCase) || Pn.Contains(TEXT("Time"), ESearchCase::IgnoreCase);

		double NumVal = static_cast<double>(Damage);
		if (bMax)
		{
			NumVal = MaxHealth;
		}
		else if (bHealth)
		{
			NumVal = HealthNow;
		}
		else if (bDur)
		{
			NumVal = bBoolArg ? 3600.0 : 0.0;
		}
		else if (bDmg)
		{
			NumVal = static_cast<double>(Damage);
		}
		else if (Index == 0)
		{
			if (FuncName.ToString().Contains(TEXT("SetHealth")))
			{
				NumVal = HealthNow;
			}
		}

		if (FFloatProperty* FP = CastField<FFloatProperty>(P))
		{
			FP->SetPropertyValue_InContainer(Params.GetData(), static_cast<float>(NumVal));
			UE_LOG(LogTemp, Warning, TEXT("[SDDBG]     set float %s=%.3f"), *Pn, NumVal);
		}
		else if (FDoubleProperty* DP = CastField<FDoubleProperty>(P))
		{
			DP->SetPropertyValue_InContainer(Params.GetData(), NumVal);
			UE_LOG(LogTemp, Warning, TEXT("[SDDBG]     set double %s=%.3f"), *Pn, NumVal);
		}
		else if (FBoolProperty* BP = CastField<FBoolProperty>(P))
		{
			bool bVal = bBoolArg;
			if (Pn.Contains(TEXT("add"), ESearchCase::IgnoreCase))
			{
				bVal = bBoolArg; // caller passes add?
			}
			else if (Pn.Contains(TEXT("Dead"), ESearchCase::IgnoreCase) || Pn.Contains(TEXT("ragdoll"), ESearchCase::IgnoreCase))
			{
				bVal = HealthNow <= 0.0;
			}
			else if (Pn.Contains(TEXT("Fire"), ESearchCase::IgnoreCase) || Pn.Contains(TEXT("onFire"), ESearchCase::IgnoreCase))
			{
				bVal = bBoolArg;
			}
			BP->SetPropertyValue_InContainer(Params.GetData(), bVal);
			UE_LOG(LogTemp, Warning, TEXT("[SDDBG]     set bool %s=%d"), *Pn, bVal ? 1 : 0);
		}
		else if (FObjectProperty* OP = CastField<FObjectProperty>(P))
		{
			UObject* Val = nullptr;
			if (OP->PropertyClass && this->IsA(OP->PropertyClass))
			{
				Val = this;
			}
			else if (Target && OP->PropertyClass && Target->IsA(OP->PropertyClass))
			{
				Val = Target;
			}
			else if (OP->PropertyClass && OP->PropertyClass->IsChildOf(UDamageType::StaticClass()))
			{
				TSubclassOf<UDamageType> DT = ResolveFireDamageType(Cast<UActorComponent>(Obj));
				if (DT)
				{
					Val = DT->GetDefaultObject();
				}
			}
			OP->SetObjectPropertyValue_InContainer(Params.GetData(), Val);
		}
		else if (FClassProperty* CP = CastField<FClassProperty>(P))
		{
			if (CP->MetaClass && CP->MetaClass->IsChildOf(UDamageType::StaticClass()))
			{
				TSubclassOf<UDamageType> DT = ResolveFireDamageType(Cast<UActorComponent>(Obj));
				CP->SetObjectPropertyValue_InContainer(Params.GetData(), DT.Get());
			}
		}
	}

	Obj->ProcessEvent(Fn, Params.GetData());
	UE_LOG(LogTemp, Warning, TEXT("[SDDBG] called %s::%s parms=%d dmg=%.1f hp=%.1f bool=%d"),
		*Obj->GetName(), *FuncName.ToString(), Fn->NumParms, Damage, HealthNow, bBoolArg ? 1 : 0);
	return true;
}

void ASceneDecorator::NotifyPackHealthUI(UActorComponent* Health, AActor* Target, float Damage)
{
	if (!Health)
	{
		return;
	}
	const double HP = ReadPackDouble(Health, TEXT("currentHealth"));
	const double MaxHP = ReadPackDouble(Health, TEXT("maxHealth"));
	UE_LOG(LogTemp, Warning, TEXT("[SDDBG] NotifyUI hp=%.1f max=%.1f dmg=%.1f"), HP, MaxHP, Damage);

	// TPWCS: HI_SetHealth(add?=true, healthPoints=-Damage) is the HUD path.
	// add?=false + absolute HP was a no-op for the bar (maxHealth=100, currentHealth=2000).
	// One HUD-aware hit per second. Do not also call SetOnFireTakeDamage (that stacked and killed too fast).
	CallPackFunction(Health, FName(TEXT("HI_SetHealth")), Target, -Damage, -static_cast<double>(Damage), MaxHP, true);
}

int32 ASceneDecorator::CallNamedDamageFunctions(UObject* Obj, float Damage)
{
	if (!Obj)
	{
		return 0;
	}
	AActor* Target = Cast<AActor>(Obj);
	if (UActorComponent* AsComp = Cast<UActorComponent>(Obj))
	{
		Target = AsComp->GetOwner();
	}
	const double HP = ReadPackDouble(Obj, TEXT("currentHealth"));
	const double MaxHP = ReadPackDouble(Obj, TEXT("maxHealth"));
	int32 Called = 0;
	static const TCHAR* Names[] = {
		TEXT("SetOnFireTakeDamage"),
		TEXT("TakeHealthDamage"),
		TEXT("HI_TakeDamage"),
		TEXT("TakeHealthAndArmourDamage"),
	};
	for (const TCHAR* Name : Names)
	{
		if (CallPackFunction(Obj, FName(Name), Target, Damage, HP, MaxHP, true))
		{
			Called++;
		}
	}
	return Called;
}

namespace
{
	// S5-8c: process-static burn-visual state, guarded per-world so stays thread-consistent
	// across editor PIE instances and travel worlds.
	int32 GBurnVisualRefCount = 0;
	TWeakObjectPtr<UWorld> GBurnVisualWorld;
}

void ASceneDecorator::EnterBurnVisualState(AActor* Player)
{
	UWorld* World = GetWorld();
	if (GBurnVisualWorld.Get() != World)
	{
		GBurnVisualRefCount = 0;
		GBurnVisualWorld = World;
	}
	if (GBurnVisualRefCount++ == 0)
	{
		ShowBurnEffect();
		SetPackBurning(Player, true);
	}
}

void ASceneDecorator::LeaveBurnVisualState(AActor* Player)
{
	if (GBurnVisualRefCount <= 0)
	{
		GBurnVisualRefCount = 0; // defensive settle (double-leave paths)
		return;
	}
	if (--GBurnVisualRefCount == 0)
	{
		HideBurnEffect();
		SetPackBurning(Player, false);
	}
}

void ASceneDecorator::ApplyFireDamageToActor(AActor* Target, float Damage)
{
	if (!Target || Damage <= 0.f)
	{
		return;
	}

	// S5-8a: native UHealthComponent FIRST. The old flow matched the native component by name,
	// then routed only through pack reflection (HI_SetHealth / SetIsOnFire) — which does not
	// exist on the native component, so a NATIVE PLAYER took ZERO scene-fire damage.
	if (UHealthComponent* NativeHC = Target->FindComponentByClass<UHealthComponent>())
	{
		TSubclassOf<UDamageType> NativeDT = ResolveFireDamageType(NativeHC);
		if (!NativeDT) NativeDT = UDamageType::StaticClass();
		NativeHC->ApplyExternalDamage(Damage, this, nullptr, NativeDT);
		UE_LOG(LogTemp, Warning, TEXT("[SDDBG] ApplyFire NATIVE path target=%s dmg=%.1f"), *GetNameSafe(Target), Damage);
		return;
	}

	UActorComponent* Health = FindPackHealthComp(Target);
	TSubclassOf<UDamageType> FireDT = ResolveFireDamageType(Health);

	UE_LOG(LogTemp, Warning,
		TEXT("[SDDBG] ApplyFire path target=%s health=%s dmg=%.1f dt=%s canBeDamaged=%d"),
		*GetNameSafe(Target),
		Health ? *Health->GetName() : TEXT("NONE"),
		Damage,
		FireDT ? *FireDT->GetName() : TEXT("NULL"),
		Target->CanBeDamaged() ? 1 : 0);

	if (!Health)
	{
		UE_LOG(LogTemp, Error, TEXT("[SDDBG] no health component on %s"), *GetNameSafe(Target));
		UGameplayStatics::ApplyDamage(Target, Damage, nullptr, this, FireDT);
		return;
	}

	// Do NOT ApplyDamage here — that burns HP without touching the TPWCS HUD.
	// HI_SetHealth(add=true, -dps) + SetOnFireTakeDamage is the pack's own path.
	NotifyPackHealthUI(Health, Target, Damage);
	const double HPAfter = ReadPackDouble(Health, TEXT("currentHealth"));
	UE_LOG(LogTemp, Warning, TEXT("[SDDBG] currentHealth after pack HUD path=%.1f"), HPAfter);
}

void ASceneDecorator::ShowBurnEffect()
{
	if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this))
	{
		HUD->SetPlayerBurning(true);
	}

	if (ActiveBurnEffect)
	{
		return;
	}
	if (!BurnScreenEffectClass)
	{
		UE_LOG(LogTemp, Error, TEXT("[SDDBG] %s: BurnScreenEffectClass is NONE — no red overlay (damage can still apply)"), *GetName());
		return;
	}
	if (!GetWorld())
	{
		UE_LOG(LogTemp, Error, TEXT("[SDDBG] %s: ShowBurnEffect world NULL"), *GetName());
		return;
	}
	APlayerController* PC = GetWorld()->GetFirstPlayerController();
	if (!PC)
	{
		return;
	}
	ActiveBurnEffect = CreateWidget<UUserWidget>(PC, BurnScreenEffectClass);
	if (ActiveBurnEffect)
	{
		ActiveBurnEffect->AddToViewport(100);
	}
}

void ASceneDecorator::HideBurnEffect()
{
	if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this))
	{
		HUD->SetPlayerBurning(false);
	}

	if (ActiveBurnEffect)
	{
		ActiveBurnEffect->RemoveFromParent();
		ActiveBurnEffect = nullptr;
	}
}


void ASceneDecorator::DumpDebugSnapshot(const TCHAR* Reason)
{
	UWorld* World = GetWorld();
	APawn* Player = FindPlayerPawn();

	TArray<UActorComponent*> AllComps;
	GetComponents(AllComps);
	TArray<UNiagaraComponent*> NCs;
	GetComponents<UNiagaraComponent>(NCs);
	TArray<UParticleSystemComponent*> Cascades;
	GetComponents<UParticleSystemComponent>(Cascades);
	TArray<UStaticMeshComponent*> Meshes;
	GetComponents<UStaticMeshComponent>(Meshes);
	TArray<USphereComponent*> Spheres;
	GetComponents<USphereComponent>(Spheres);

	int32 Tagged = 0;
	int32 ValidTrackedHurt = 0;
	for (USphereComponent* S : Spheres)
	{
		if (IsValid(S) && S->ComponentHasTag(TEXT("SceneDecoratorFire")))
		{
			Tagged++;
		}
	}
	for (USphereComponent* S : SpawnedDamageSpheres)
	{
		if (IsValid(S))
		{
			ValidTrackedHurt++;
		}
	}

	const int32 TimerActive = (World && World->GetTimerManager().IsTimerActive(FirePollHandle)) ? 1 : 0;
	const int32 GameWorld = (World && World->IsGameWorld()) ? 1 : 0;
	const int32 PIE = (World && World->IsPlayInEditor()) ? 1 : 0;
	const int32 EditorWorld = (World && !World->IsGameWorld()) ? 1 : 0;

	UE_LOG(LogTemp, Warning, TEXT("[SDDBG] ==== SNAP %s ==== build=FIREDBG_HUD3 actor=%s class=%s loc=%s"),
		Reason, *GetName(), *GetClass()->GetName(), *GetActorLocation().ToString());
	UE_LOG(LogTemp, Warning,
		TEXT("[SDDBG] world=%s game=%d pie=%d editorWorld=%d begunPlay=%d tickEnabled=%d canEverTick=%d tickInterval=%.2f timerActive=%d poll#=%d"),
		World ? *World->GetName() : TEXT("NULL"),
		GameWorld, PIE, EditorWorld,
		HasActorBegunPlay() ? 1 : 0,
		IsActorTickEnabled() ? 1 : 0,
		PrimaryActorTick.bCanEverTick ? 1 : 0,
		PrimaryActorTick.TickInterval,
		TimerActive, DebugPollCount);
	UE_LOG(LogTemp, Warning,
		TEXT("[SDDBG] flags enableFire=%d dps=%.1f actorRadius=%.0f burnWidget=%s decorations=%d totalSpawned=%d inFire=%d accrue=%.2f"),
		bEnableFireDamage ? 1 : 0, FireDamagePerSecond, FireDamageRadius,
		BurnScreenEffectClass ? *BurnScreenEffectClass->GetName() : TEXT("NONE"),
		Decorations.Num(), TotalSpawnedCount, bPlayerInFire ? 1 : 0, FireDamageAccrue);
	UE_LOG(LogTemp, Warning,
		TEXT("[SDDBG] tracked niagara=%d cascade=%d mesh=%d actors=%d hurtArr=%d validHurt=%d | liveComps=%d liveNiagara=%d liveCascade=%d liveMesh=%d liveSpheres=%d taggedFire=%d"),
		SpawnedNiagaraComps.Num(), SpawnedCascadeComps.Num(), SpawnedMeshComps.Num(), SpawnedActors.Num(),
		SpawnedDamageSpheres.Num(), ValidTrackedHurt,
		AllComps.Num(), NCs.Num(), Cascades.Num(), Meshes.Num(), Spheres.Num(), Tagged);

	if (Decorations.Num() == 0)
	{
		UE_LOG(LogTemp, Error, TEXT("[SDDBG] ERROR decorations array EMPTY"));
	}
	for (int32 i = 0; i < Decorations.Num(); ++i)
	{
		const FDecorationEntry& E = Decorations[i];
		UE_LOG(LogTemp, Warning,
			TEXT("[SDDBG] entry[%d] name=%s type=%d count=%d maxR=%.0f niagara=%s cascade=%s mesh=%s fire=%d fireR=%.0f fireDps=%.1f randRot=%d fixed=P%.1f Y%.1f R%.1f"),
			i, *E.EntryName.ToString(), (int32)E.Type, E.Count, E.MaxRadius,
			E.NiagaraEffect ? *E.NiagaraEffect->GetName() : TEXT("NULL"),
			E.CascadeEffect ? *E.CascadeEffect->GetName() : TEXT("NULL"),
			E.GroundMesh ? *E.GroundMesh->GetName() : TEXT("NULL"),
			E.bFireDamage ? 1 : 0, E.FireDamageRadius, E.FireDamagePerSecond,
			E.bRandomRotation ? 1 : 0, E.FixedRotation.Pitch, E.FixedRotation.Yaw, E.FixedRotation.Roll);
	}

	int32 Ni = 0;
	for (UNiagaraComponent* NC : NCs)
	{
		if (!IsValid(NC))
		{
			continue;
		}
		UE_LOG(LogTemp, Warning, TEXT("[SDDBG] niagara[%d] %s loc=%s active=%d registered=%d asset=%s"),
			Ni++, *NC->GetName(), *NC->GetComponentLocation().ToString(),
			NC->IsActive() ? 1 : 0, NC->IsRegistered() ? 1 : 0,
			NC->GetAsset() ? *NC->GetAsset()->GetName() : TEXT("NULL"));
	}
	if (NCs.Num() == 0)
	{
		UE_LOG(LogTemp, Error, TEXT("[SDDBG] ERROR no live Niagara components on actor"));
	}

	int32 Hi = 0;
	for (USphereComponent* S : Spheres)
	{
		if (!IsValid(S))
		{
			continue;
		}
		const bool bTag = S->ComponentHasTag(TEXT("SceneDecoratorFire"));
		UE_LOG(LogTemp, Warning,
			TEXT("[SDDBG] sphere[%d] %s tagFire=%d r=%.0f loc=%s collide=%d genOverlap=%d registered=%d"),
			Hi++, *S->GetName(), bTag ? 1 : 0, S->GetScaledSphereRadius(),
			*S->GetComponentLocation().ToString(),
			(int32)S->GetCollisionEnabled(),
			S->GetGenerateOverlapEvents() ? 1 : 0,
			S->IsRegistered() ? 1 : 0);
	}
	if (Tagged == 0)
	{
		UE_LOG(LogTemp, Error, TEXT("[SDDBG] ERROR no tagged SceneDecoratorFire spheres — damage poll has nothing to test"));
	}

	if (Player)
	{
		const FVector PLoc = Player->GetActorLocation();
		float BestXY = TNumericLimits<float>::Max();
		FVector BestFire = FVector::ZeroVector;
		float BestR = 0.f;
		for (USphereComponent* S : Spheres)
		{
			if (!IsValid(S) || !S->ComponentHasTag(TEXT("SceneDecoratorFire")))
			{
				continue;
			}
			const float XY = FVector::Dist2D(PLoc, S->GetComponentLocation());
			if (XY < BestXY)
			{
				BestXY = XY;
				BestFire = S->GetComponentLocation();
				BestR = FMath::Max(S->GetScaledSphereRadius(), FireDamageRadius);
			}
		}
		UE_LOG(LogTemp, Warning,
			TEXT("[SDDBG] player=%s class=%s super=%s loc=%s distToDecorator=%.0f nearestFireXY=%.0f nearestFireZ=%.0f needRadius=%.0f wouldHit=%d"),
			*Player->GetName(),
			*Player->GetClass()->GetName(),
			Player->GetClass()->GetSuperClass() ? *Player->GetClass()->GetSuperClass()->GetName() : TEXT("NONE"),
			*PLoc.ToString(),
			FVector::Dist(PLoc, GetActorLocation()),
			BestXY,
			FMath::Abs(PLoc.Z - BestFire.Z),
			BestR,
			(BestXY <= (BestR + 80.f) && FMath::Abs(PLoc.Z - BestFire.Z) <= 400.f) ? 1 : 0);
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("[SDDBG] ERROR player pawn is NULL"));
	}

	UE_LOG(LogTemp, Warning, TEXT("[SDDBG] ==== END SNAP %s ===="), Reason);
}

void ASceneDecorator::DumpPlayerProbe(AActor* Player)
{
	if (!Player)
	{
		UE_LOG(LogTemp, Error, TEXT("[SDDBG] probe: player is NULL"));
		return;
	}

	UE_LOG(LogTemp, Warning, TEXT("[SDDBG] ---- PLAYER PROBE %s class=%s ----"),
		*Player->GetName(), *Player->GetClass()->GetName());

	auto DumpInterestingProps = [](UObject* Obj, const TCHAR* Label)
	{
		if (!Obj)
		{
			return;
		}
		for (TFieldIterator<FProperty> It(Obj->GetClass()); It; ++It)
		{
			FProperty* Prop = *It;
			if (!Prop)
			{
				continue;
			}
			const FString Pn = Prop->GetName();
			const bool bInteresting =
				Pn.Contains(TEXT("Health"), ESearchCase::IgnoreCase) ||
				Pn.Contains(TEXT("HP"), ESearchCase::CaseSensitive) ||
				Pn.Contains(TEXT("Damage"), ESearchCase::IgnoreCase) ||
				Pn.Contains(TEXT("Alive"), ESearchCase::IgnoreCase) ||
				Pn.Contains(TEXT("Dead"), ESearchCase::IgnoreCase) ||
				Pn.Contains(TEXT("Armor"), ESearchCase::IgnoreCase);
			if (!bInteresting)
			{
				continue;
			}
			if (const FDoubleProperty* DP = CastField<FDoubleProperty>(Prop))
			{
				UE_LOG(LogTemp, Warning, TEXT("[SDDBG]     %s prop %s double=%.3f"), Label, *Pn, DP->GetPropertyValue_InContainer(Obj));
			}
			else if (const FFloatProperty* FP = CastField<FFloatProperty>(Prop))
			{
				UE_LOG(LogTemp, Warning, TEXT("[SDDBG]     %s prop %s float=%.3f"), Label, *Pn, FP->GetPropertyValue_InContainer(Obj));
			}
			else if (const FIntProperty* IP = CastField<FIntProperty>(Prop))
			{
				UE_LOG(LogTemp, Warning, TEXT("[SDDBG]     %s prop %s int=%d"), Label, *Pn, IP->GetPropertyValue_InContainer(Obj));
			}
			else if (const FBoolProperty* BP = CastField<FBoolProperty>(Prop))
			{
				UE_LOG(LogTemp, Warning, TEXT("[SDDBG]     %s prop %s bool=%d"), Label, *Pn, BP->GetPropertyValue_InContainer(Obj) ? 1 : 0);
			}
			else
			{
				UE_LOG(LogTemp, Warning, TEXT("[SDDBG]     %s prop %s type=%s"), Label, *Pn, *Prop->GetClass()->GetName());
			}
		}
	};

	DumpInterestingProps(Player, TEXT("actor"));

	UClass* Cls = Player->GetClass();
	int32 Depth = 0;
	while (Cls && Depth < 8)
	{
		UE_LOG(LogTemp, Warning, TEXT("[SDDBG] hierarchy[%d] %s"), Depth, *Cls->GetName());
		Cls = Cls->GetSuperClass();
		Depth++;
	}

	TArray<UActorComponent*> Comps;
	Player->GetComponents(Comps);
	UE_LOG(LogTemp, Warning, TEXT("[SDDBG] player has %d components"), Comps.Num());

	for (UActorComponent* C : Comps)
	{
		if (!C)
		{
			continue;
		}
		const FString N = C->GetName();
		const FString ClassN = C->GetClass()->GetName();
		UE_LOG(LogTemp, Warning, TEXT("[SDDBG]   comp name=%s class=%s"), *N, *ClassN);
		DumpInterestingProps(C, *N);
	}

	if (UActorComponent* Health = FindPackHealthComp(Player))
	{
		UE_LOG(LogTemp, Warning, TEXT("[SDDBG] health funcs on %s class=%s:"), *Health->GetName(), *Health->GetClass()->GetName());
		int32 Fi = 0;
		for (TFieldIterator<UFunction> It(Health->GetClass()); It; ++It)
		{
			UFunction* Fn = *It;
			if (!Fn)
			{
				continue;
			}
			UE_LOG(LogTemp, Warning, TEXT("[SDDBG]   func[%d] %s parms=%d flags=0x%x"),
				Fi++, *Fn->GetName(), Fn->NumParms, Fn->FunctionFlags);
		}
	}

	UE_LOG(LogTemp, Warning, TEXT("[SDDBG] ---- END PLAYER PROBE ----"));
}

FVector ASceneDecorator::FindGroundLocation(const FVector& Origin) const
{
	UWorld* World = GetWorld();
	if (!World)
	{
		return Origin;
	}

	FHitResult Hit;
	FVector Start = Origin + FVector(0, 0, GroundTraceUp);
	FVector End = Origin - FVector(0, 0, GroundTraceDown);
	FCollisionQueryParams Params(SCENE_QUERY_STAT(SceneDecoratorGround), false, this);
	Params.bReturnPhysicalMaterial = false;

	if (World->LineTraceSingleByChannel(Hit, Start, End, ECC_WorldStatic, Params))
	{
		return Hit.Location;
	}

	// Landscape / WP collision is often WorldDynamic or Visibility, not WorldStatic.
	if (World->LineTraceSingleByChannel(Hit, Start, End, ECC_Visibility, Params))
	{
		return Hit.Location;
	}

	if (World->LineTraceSingleByChannel(Hit, Start, End, ECC_WorldDynamic, Params))
	{
		return Hit.Location;
	}

	UE_LOG(LogTemp, Warning, TEXT("[SDDBG] %s: Ground trace FAILED at %s — using raw point (fire may float). TraceUp=%.0f TraceDown=%.0f"),
		*GetName(), *Origin.ToString(), GroundTraceUp, GroundTraceDown);
	return Origin;
}

FVector ASceneDecorator::GetRandomPointInRadius(const FVector& Center, float Radius) const
{
	const float Angle = FMath::FRandRange(0.f, 2.f * PI);
	const float Dist = FMath::FRandRange(0.f, Radius);
	return Center + FVector(FMath::Cos(Angle) * Dist, FMath::Sin(Angle) * Dist, 0.f);
}

bool ASceneDecorator::IsFarEnough(const FVector& NewPoint, const TArray<FVector>& Placed, float MinDist) const
{
	for (const FVector& P : Placed)
	{
		if (FVector::Dist2D(NewPoint, P) < MinDist)
		{
			return false;
		}
	}
	return true;
}

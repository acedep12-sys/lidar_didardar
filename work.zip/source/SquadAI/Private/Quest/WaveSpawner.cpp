// WaveSpawner.cpp — Timer-driven batched spawning with NavMesh validation
#include "Quest/WaveSpawner.h"
#include "Performance/SquadAIRecovery.h" // S19-HUNT: IsActorDead covers pack pawns
#include "Quest/WaveTemplate.h"
#include "Quest/QuestRegistry.h"
#include "Quest/EnemyPool.h"
#include "AI/EnemyAttackCoordinator.h"
#include "AI/EnemyFireteamSubsystem.h"
#include "Characters/SoldierCharacter.h"
#include "Characters/EnemySoldier.h"
#include "Components/HealthComponent.h"
#include "NavigationSystem.h"
#include "TimerManager.h"
#include "SquadAITuning.h"

AWaveSpawner::AWaveSpawner()
{
	PrimaryActorTick.bCanEverTick = false;
	SpawnPointSearchExtent = USquadAITuning::Get()->SpawnPointNavProjectExtent;
}

void AWaveSpawner::BeginPlay()
{
	Super::BeginPlay();

	if (SpawnerTag.IsValid())
	{
		if (UQuestRegistry* Reg = GetWorld()->GetSubsystem<UQuestRegistry>())
		{
			Reg->Register(SpawnerTag, this);
		}
	}
	
	// AUTO-LYRA SETUP: Allow the spawner to trigger itself automatically
	if (bAutoStartOnBeginPlay)
	{
		StartWaves();
	}
}

void AWaveSpawner::EndPlay(const EEndPlayReason::Type Reason)
{
	StopWaves();
	if (SpawnerTag.IsValid())
	{
		if (UQuestRegistry* Reg = GetWorld()->GetSubsystem<UQuestRegistry>())
		{
			Reg->Unregister(SpawnerTag);
		}
	}
	Super::EndPlay(Reason);
}

void AWaveSpawner::StartWaves()
{
	if (!WaveTemplate || WaveTemplate->Waves.Num() == 0) return;

	// S5-6: make restarts idempotent (mission retry re-enters here). Release leftovers of
	// the previous run into the pool so the retry starts from an empty board.
	StopWaves(true);

	// S5-7: top up the pool (capped — templates can declare hundreds of enemies).
	if (UEnemyPoolSubsystem* Pool = GetWorld()->GetSubsystem<UEnemyPoolSubsystem>())
	{
		TSubclassOf<APawn> PoolClass = WaveTemplate->DefaultEnemyClass;
		if (!PoolClass && WaveTemplate->Waves.Num() > 0)
		{
			PoolClass = WaveTemplate->Waves[0].EnemyClassOverride;
		}
		if (!PoolClass)
		{
			PoolClass = AEnemySoldier::StaticClass();
		}
		const int32 Want = FMath::Min(WaveTemplate->GetTotalEnemyCount(), 20);
		const int32 Have = Pool->GetAvailableCount(PoolClass);
		if (Want > Have)
		{
			Pool->Prewarm(PoolClass, Want - Have);
		}
	}

	CurrentWaveIndex = -1;
	TotalSpawned = 0;
	TotalKilled = 0;
	CachedLiving = 0;
	bSpawningActive = true;

	StartNextWave();
}

void AWaveSpawner::StopWaves(bool bReleaseLiveEnemies)
{
	bSpawningActive = false;
	GetWorldTimerManager().ClearTimer(WaveDelayTimer);
	GetWorldTimerManager().ClearTimer(BatchTimer);

	// S5-6c: sever ownership of the previous run. Live enemies kept THIS spawner as their
	// death delegate owner; their later deaths would otherwise corrupt the NEW run's 	counters
	// (double wave-clear, phantom kills), and save/load restores left whole armies behind.
	for (const TWeakObjectPtr<APawn>& WeakP : AllSpawned)
	{
		APawn* P = WeakP.Get();
		if (!P || P->IsActorBeingDestroyed()) continue;
		if (UHealthComponent* HC = P->FindComponentByClass<UHealthComponent>())
		{
			HC->OnDeath.RemoveDynamic(this, &AWaveSpawner::HandleSpawnedDied);
		}
		if (bReleaseLiveEnemies)
		{
			if (UWorld* World = GetWorld())
			{
				if (UEnemyPoolSubsystem* Pool = World->GetSubsystem<UEnemyPoolSubsystem>())
				{
					Pool->Release(P);
				}
			}
		}
	}
	AllSpawned.Empty();
	SpawnedThisWave = 0;
	TargetThisWave = 0;
	BatchesDone = 0;
	CachedLiving = 0;
	CurrentWaveIndex = -1;
	// TotalSpawned / TotalKilled are lifetime stats — StartWaves() re-inits them explicitly.
}

void AWaveSpawner::StartNextWave()
{
	if (!bSpawningActive || !WaveTemplate) return;

	CurrentWaveIndex++;
	if (CurrentWaveIndex >= WaveTemplate->Waves.Num())
	{
		// All waves done — but enemies might still be alive
		return;
	}

	const FWaveDefinition& Wave = WaveTemplate->Waves[CurrentWaveIndex];

	// S5-6d: empty/malformed wave (no soldiers, no batch size, no enemy class anywhere) —
	// never stall the chain: report started+cleared and fast-forward.
	{
		const TSubclassOf<APawn> AnyClass = Wave.EnemyClassOverride
			? Wave.EnemyClassOverride
			: (DefaultEnemyClass ? DefaultEnemyClass : WaveTemplate->DefaultEnemyClass);
		if (Wave.NumSoldiers <= 0 || Wave.BatchSize <= 0 || !AnyClass)
		{
			SpawnedThisWave = 0;
			TargetThisWave = 0;
			BatchesDone = 0;
			OnWaveStarted.Broadcast(CurrentWaveIndex);
			OnWaveCleared.Broadcast(CurrentWaveIndex);
			if (CurrentWaveIndex + 1 >= WaveTemplate->Waves.Num())
			{
				OnAllWavesCleared.Broadcast();
				bSpawningActive = false;
			}
			else
			{
				StartNextWave();
			}
			return;
		}
	}

	// Delay before this wave
	if (Wave.DelayAfterPreviousSeconds > 0.f && CurrentWaveIndex > 0)
	{
		TWeakObjectPtr<AWaveSpawner> WeakThis(this);
		GetWorldTimerManager().SetTimer(WaveDelayTimer, [WeakThis]()
		{
			if (!WeakThis.IsValid() || !WeakThis->WaveTemplate) return;
			if (WeakThis->CurrentWaveIndex >= WeakThis->WaveTemplate->Waves.Num()) return;
			const FWaveDefinition& W = WeakThis->WaveTemplate->Waves[WeakThis->CurrentWaveIndex];
			WeakThis->SpawnedThisWave = 0;
			WeakThis->TargetThisWave = W.NumSoldiers;
			WeakThis->BatchesDone = 0;
			WeakThis->OnWaveStarted.Broadcast(WeakThis->CurrentWaveIndex);
			WeakThis->SpawnNextBatch();
		}, Wave.DelayAfterPreviousSeconds, false);
	}
	else
	{
		SpawnedThisWave = 0;
		TargetThisWave = Wave.NumSoldiers;
		BatchesDone = 0;
		OnWaveStarted.Broadcast(CurrentWaveIndex);
		SpawnNextBatch();
	}
}

void AWaveSpawner::SpawnNextBatch()
{
	if (!bSpawningActive || !WaveTemplate) return;
	if (CurrentWaveIndex >= WaveTemplate->Waves.Num()) return;

	const FWaveDefinition& Wave = WaveTemplate->Waves[CurrentWaveIndex];
	TSubclassOf<APawn> EnemyClass = Wave.EnemyClassOverride
		? Wave.EnemyClassOverride
		: (DefaultEnemyClass ? DefaultEnemyClass : WaveTemplate->DefaultEnemyClass);

	if (!EnemyClass)
	{
		// S5-6d: wave has no enemy class anywhere — treat as instantly cleared instead
		// of stalling forever.
		SpawnedThisWave = TargetThisWave;
		if (CachedLiving <= 0)
		{
			OnWaveCleared.Broadcast(CurrentWaveIndex);
			if (CurrentWaveIndex + 1 >= WaveTemplate->Waves.Num())
			{
				OnAllWavesCleared.Broadcast();
				bSpawningActive = false;
			}
			else
			{
				StartNextWave();
			}
		}
		return;
	}

	const int32 Remaining = TargetThisWave - SpawnedThisWave;
	const int32 ThisBatch = FMath::Min(Wave.BatchSize, Remaining);

	for (int32 i = 0; i < ThisBatch; ++i)
	{
		APawn* Enemy = SpawnOneEnemy(EnemyClass);
		if (Enemy)
		{
			SpawnedThisWave++;
			TotalSpawned++;
			CachedLiving++;
			AllSpawned.Add(Enemy);
			OnEnemySpawned.Broadcast(Enemy);

			// Register with coordinator if available
			if (Coordinator.IsValid())
			{
				if (AEnemySoldier* ES = Cast<AEnemySoldier>(Enemy))
				{
					Coordinator->AddEnemy(ES);
				}
			}

			if (UEnemyFireteamSubsystem* FT = GetWorld()->GetSubsystem<UEnemyFireteamSubsystem>())
			{
				FT->RegisterMember(Enemy, GetUniqueID());
			}

			// Subscribe to death (P1-Q1: Remove-before-Add — pooled pawns must carry
			// exactly one owner binding or the stale owner double-counts the death).
			if (UHealthComponent* HC = Enemy->FindComponentByClass<UHealthComponent>())
			{
				HC->OnDeath.RemoveDynamic(this, &AWaveSpawner::HandleSpawnedDied);
				HC->OnDeath.AddDynamic(this, &AWaveSpawner::HandleSpawnedDied);
			}
		}
	}

	// More batches needed?
	if (SpawnedThisWave < TargetThisWave)
	{
		GetWorldTimerManager().SetTimer(BatchTimer, this,
			&AWaveSpawner::SpawnNextBatch, Wave.SecondsBetweenBatches, false);
	}
}

APawn* AWaveSpawner::SpawnOneEnemy(TSubclassOf<APawn> Class)
{
	UWorld* World = GetWorld();
	if (!World) return nullptr;

	// Try enemy pool first
	UEnemyPoolSubsystem* Pool = World->GetSubsystem<UEnemyPoolSubsystem>();
	if (Pool)
	{
		APawn* Pooled = Pool->Acquire(Class, GetNextSpawnLocation(), GetActorRotation());
		if (Pooled)
		{
			if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(Pooled))
			{
				// G-23: pooled enemies must not lose their protection when re-used.
				Soldier->ResetSpawnGracePeriod(14.0f);
			}
			return Pooled;
		}
	}

	// Fallback: direct spawn
	FActorSpawnParameters Params;
	Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;

	APawn* SpawnedPawn = World->SpawnActor<APawn>(Class, GetNextSpawnLocation(), GetActorRotation(), Params);

	if (SpawnedPawn && SpawnedPawn->GetController() == nullptr)
	{
		SpawnedPawn->SpawnDefaultController();
	}
	if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(SpawnedPawn))
	{
		// G-23: direct-spawn enemies also get the same non-player arrival protection.
		Soldier->ResetSpawnGracePeriod(14.0f);
	}
	
	return SpawnedPawn;
}

FVector AWaveSpawner::GetNextSpawnLocation()
{
	if (SpawnPointLocations.Num() == 0) return GetActorLocation();

	// Round-robin through spawn points
	SpawnPointRoundRobin = (SpawnPointRoundRobin + 1) % SpawnPointLocations.Num();
	
	// AUTO-LYRA SETUP: Because we use MakeEditWidget, the locations are relative to the actor!
	// We must convert them to World Space so the enemies don't spawn inside the Spawner origin.
	// F-G5: only transform LOCAL entries — world-space entries (AutoSpawnZone) used to be double-transformed.
	const FVector SpawnEntry = SpawnPointLocations[SpawnPointRoundRobin];
	FVector Loc = bSpawnPointLocationsAreWorldSpace ? SpawnEntry : GetTransform().TransformPosition(SpawnEntry);

	// Add random offset
	Loc += FVector(FMath::RandRange(-200.f, 200.f), FMath::RandRange(-200.f, 200.f), 0.f);

	// NavMesh project
	UNavigationSystemV1* NavSys = UNavigationSystemV1::GetCurrent(GetWorld());
	if (NavSys)
	{
		FNavLocation NavLoc;
		if (NavSys->ProjectPointToNavigation(Loc, NavLoc,
			FVector(SpawnPointSearchExtent, SpawnPointSearchExtent, 400.f)))
		{
			Loc = NavLoc.Location;
		}
	}

	return Loc;
}

void AWaveSpawner::HandleSpawnedDied(AActor* DeadActor)
{
	CachedLiving = FMath::Max(0, CachedLiving - 1);
	TotalKilled++;
	// P1-Q1: exactly-one authoritative notification — release the binding so a pooled
	// re-acquire by another spawner never notifies this (stale) owner again.
	if (APawn* DeadPawn = Cast<APawn>(DeadActor))
	{
		if (UHealthComponent* HC = DeadPawn->FindComponentByClass<UHealthComponent>())
		{
			HC->OnDeath.RemoveDynamic(this, &AWaveSpawner::HandleSpawnedDied);
		}
	}

	// Release to pool after a delay (corpse linger)
	if (APawn* P = Cast<APawn>(DeadActor))
	{
		UWorld* World = GetWorld();
		const float Linger = USquadAITuning::Get()->CorpseLingerSeconds;

		FTimerHandle ReleaseTimer;
		World->GetTimerManager().SetTimer(ReleaseTimer, [World, P]()
		{
			if (UEnemyPoolSubsystem* Pool = World->GetSubsystem<UEnemyPoolSubsystem>())
			{
				Pool->Release(P);
			}
			else
			{
				P->Destroy();
			}
		}, Linger, false);
	}

	// Auto-compact stale weak refs when the array is 2x the living count
	if (AllSpawned.Num() > CachedLiving * 2 + 10)
	{
		CompactStaleRefs();
	}

	// Check if current wave is cleared
	if (CachedLiving <= 0 && SpawnedThisWave >= TargetThisWave)
	{
		OnWaveCleared.Broadcast(CurrentWaveIndex);

		if (CurrentWaveIndex + 1 >= WaveTemplate->Waves.Num())
		{
			OnAllWavesCleared.Broadcast();
			bSpawningActive = false;
		}
		else
		{
			StartNextWave();
		}
	}
}

void AWaveSpawner::CompactStaleRefs()
{
	AllSpawned.RemoveAll([](const TWeakObjectPtr<APawn>& P) { return !P.IsValid(); });
}

bool AWaveSpawner::AreAllWavesComplete() const
{
	return WaveTemplate && CurrentWaveIndex >= WaveTemplate->Waves.Num() - 1
		&& SpawnedThisWave >= TargetThisWave && CachedLiving <= 0;
}

// ===== S19-HUNT: what is left of this spawner's output =====
// IsActorDead() is the death test that works for pack pawns as well as native ones (pack
// enemies are not ASoldierCharacter, so IsAlive() alone would keep corpses "alive").
bool AWaveSpawner::HasAliveEnemies() const
{
	return CountAliveEnemies() > 0;
}

int32 AWaveSpawner::CountAliveEnemies() const
{
	int32 Count = 0;
	for (const TWeakObjectPtr<APawn>& Entry : AllSpawned)
	{
		APawn* Pawn = Entry.Get();
		if (!Pawn || Pawn->IsActorBeingDestroyed()) continue;
		if (SquadAIRecovery::IsActorDead(Pawn)) continue;
		++Count;
	}
	return Count;
}

APawn* AWaveSpawner::GetNearestAliveEnemy(const FVector& From) const
{
	APawn* Best = nullptr;
	float BestDistSq = -1.f;
	for (const TWeakObjectPtr<APawn>& Entry : AllSpawned)
	{
		APawn* Pawn = Entry.Get();
		if (!Pawn || Pawn->IsActorBeingDestroyed()) continue;
		if (SquadAIRecovery::IsActorDead(Pawn)) continue;
		const float DistSq = FVector::DistSquared(Pawn->GetActorLocation(), From);
		if (BestDistSq < 0.f || DistSq < BestDistSq)
		{
			BestDistSq = DistSq;
			Best = Pawn;
		}
	}
	return Best;
}

int32 AWaveSpawner::GetTotalWaveCount() const
{
	return WaveTemplate ? WaveTemplate->Waves.Num() : 0;
}

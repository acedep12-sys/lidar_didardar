// AutoSpawnZone.cpp — One-drop encounter: spawns zone + spawner + coordinator + spawn points
#include "Quest/AutoSpawnZone.h"
#include "SquadTypes.h"
#include "Quest/QuestZone.h"
#include "Quest/WaveSpawner.h"
#include "Quest/WaveTemplate.h"
#include "AI/EnemyAttackCoordinator.h"
#include "Components/BillboardComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Components/ArrowComponent.h"

AAutoSpawnZone::AAutoSpawnZone()
{
	PrimaryActorTick.bCanEverTick = false;

	USceneComponent* Root = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	RootComponent = Root;

#if WITH_EDITORONLY_DATA
	EditorIcon = CreateDefaultSubobject<UBillboardComponent>(TEXT("Icon"));
	EditorIcon->SetupAttachment(Root);
	EditorIcon->bIsEditorOnly = true;
#endif
}

void AAutoSpawnZone::BeginPlay()
{
	Super::BeginPlay();
	SpawnChildActors();
}

void AAutoSpawnZone::SpawnChildActors()
{
	UWorld* World = GetWorld();
	if (!World) return;

	const FVector Center = GetActorLocation();
	FActorSpawnParameters Params;
	Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	// 1. Spawn QuestZone — DEFERRED. AQuestZone::BeginPlay() consumes ZoneTag/Shape/BoxExtent
	// (shape conf + registry registration); setting them after a direct SpawnActor silently
	// registered nothing and left a default-sized box. Configure first, then finish spawning.
	SpawnedZone = World->SpawnActorDeferred<AQuestZone>(AQuestZone::StaticClass(), FTransform(FRotator::ZeroRotator, Center), this, nullptr, Params.SpawnCollisionHandlingOverride);
	if (SpawnedZone)
	{
		SpawnedZone->ZoneTag = Tag;
		SpawnedZone->Shape = EZoneShape::Box;
		SpawnedZone->BoxExtent = ZoneExtents;
		UGameplayStatics::FinishSpawningActor(SpawnedZone, FTransform(FRotator::ZeroRotator, Center));
	}

	// 2. Generate spawn point locations
	TArray<FVector> SpawnLocs = GenerateSpawnPointLocations();

	// 3. Spawn WaveSpawner — DEFERRED for the same reason: BeginPlay registers SpawnerTag
	// and honors bAutoStartOnBeginPlay. Configuring after BeginPlay meant the auto-start
	// saw an empty template and the tag never registered.
	SpawnedSpawner = World->SpawnActorDeferred<AWaveSpawner>(AWaveSpawner::StaticClass(), FTransform(FRotator::ZeroRotator, Center), this, nullptr, Params.SpawnCollisionHandlingOverride);
	if (SpawnedSpawner)
	{
		FQuestTag SpawnerTag;
		SpawnerTag.Tag = FName(*(Tag.Tag.ToString() + TEXT("_Spawner")));
		SpawnedSpawner->SpawnerTag = SpawnerTag;
		SpawnedSpawner->Tags.AddUnique(Tag.Tag); // F-G6: Defend lookup searches ACTOR tags (QuestObjective::ActorHasTag) — the registry tag alone never matched.
		SpawnedSpawner->WaveTemplate = WaveTemplate;
		SpawnedSpawner->DefaultEnemyClass = DefaultEnemyClass;
		SpawnedSpawner->SpawnPointLocations = SpawnLocs;
		SpawnedSpawner->bSpawnPointLocationsAreWorldSpace = true; // F-G5: ring coords are world-space (GenerateSpawnPointLocations adds Center).
		UGameplayStatics::FinishSpawningActor(SpawnedSpawner, FTransform(FRotator::ZeroRotator, Center));
	}

	// 4. Spawn EnemyAttackCoordinator (optional)
	if (bUseAttackCoordinator)
	{
		SpawnedCoordinator = World->SpawnActor<AEnemyAttackCoordinator>(
			AEnemyAttackCoordinator::StaticClass(), Center, FRotator::ZeroRotator, Params);

		if (SpawnedCoordinator)
		{
			SpawnedCoordinator->AttackPointLocation = Center;
			SpawnedCoordinator->StagingAreaLocation = Center + FVector(SpawnPointRadius * 0.7f, 0, 0);

			// Link spawner to coordinator
			if (SpawnedSpawner)
			{
				SpawnedSpawner->Coordinator = SpawnedCoordinator;
			}
		}
	}

	UE_LOG(LogSquadAI, Log, TEXT("AutoSpawnZone '%s': spawned zone + spawner + %d spawn points + %s coordinator"),
		*Tag.Tag.ToString(), SpawnLocs.Num(), bUseAttackCoordinator ? TEXT("with") : TEXT("no"));
}

TArray<FVector> AAutoSpawnZone::GenerateSpawnPointLocations() const
{
	TArray<FVector> Result;
	const FVector Center = GetActorLocation();

	for (int32 i = 0; i < NumSpawnPoints; ++i)
	{
		const float Angle = (360.f / NumSpawnPoints) * i;
		const float Rad = FMath::DegreesToRadians(Angle);
		FVector Offset(FMath::Cos(Rad) * SpawnPointRadius, FMath::Sin(Rad) * SpawnPointRadius, 0.f);
		Result.Add(Center + Offset);
	}

	return Result;
}

#if WITH_EDITORONLY_DATA
void AAutoSpawnZone::OnConstruction(const FTransform& Transform)
{
	Super::OnConstruction(Transform);

	// Clear old editor arrows
	for (UArrowComponent* Arrow : EditorArrows)
	{
		if (Arrow) Arrow->DestroyComponent();
	}
	EditorArrows.Empty();

	// Generate preview arrows showing spawn point locations
	TArray<FVector> SpawnLocs = GenerateSpawnPointLocations();
	for (int32 i = 0; i < SpawnLocs.Num(); ++i)
	{
		UArrowComponent* Arrow = NewObject<UArrowComponent>(this);
		Arrow->SetupAttachment(RootComponent);
		Arrow->RegisterComponent();
		Arrow->bIsEditorOnly = true;
		Arrow->ArrowColor = FColor::Red;
		Arrow->ArrowSize = 1.5f;
		Arrow->SetWorldLocation(SpawnLocs[i]);

		// Point toward center
		FVector ToCenter = (GetActorLocation() - SpawnLocs[i]).GetSafeNormal();
		Arrow->SetWorldRotation(ToCenter.Rotation());

		EditorArrows.Add(Arrow);
	}
}
#endif

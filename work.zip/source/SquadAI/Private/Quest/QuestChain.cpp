// QuestChain.cpp — Manages a sequence of MissionZones
#include "Quest/QuestChain.h"
#include "Quest/QuestChainModel.h"   // S20-WP: the streaming-safe sequencing rules
#include "GameFramework/SquadAIProgressionSubsystem.h"
#include "Quest/MissionZone.h"
#include "Quest/SplinePathActor.h"
#include "HUD/QuestNativeHUD.h"
#include "Engine/World.h"
#include "TimerManager.h"
#include "Kismet/GameplayStatics.h"
#include "EngineUtils.h"

namespace
{
	TArray<TWeakObjectPtr<AQuestChain>> GQuestChains;
}

AQuestChain::AQuestChain()
{
	PrimaryActorTick.bCanEverTick = false;
}

AQuestChain* AQuestChain::FindPreferred(UWorld* World, bool bActiveOnly)
{
	AQuestChain* Fallback = nullptr;
	for (int32 i = GQuestChains.Num() - 1; i >= 0; --i)
	{
		AQuestChain* C = GQuestChains[i].Get();
		if (!C)
		{
			GQuestChains.RemoveAtSwap(i);
			continue;
		}
		if (World && C->GetWorld() != World) continue;
		if (C->bIsActive) return C;
		if (!bActiveOnly && !Fallback) Fallback = C;
	}
	return Fallback;
}

void AQuestChain::OnConstruction(const FTransform& Transform)
{
	Super::OnConstruction(Transform);
	// S5-15: editor-placed chains mint their save ID here so it is baked into the
	// level asset (stable across sessions). Once minted it is never regenerated.
	if (!ChainSaveId.IsValid())
	{
		ChainSaveId = FGuid::NewGuid();
	}
}

void AQuestChain::BeginPlay()
{
	Super::BeginPlay();
	GQuestChains.AddUnique(this);

	// S5-15: runtime-spawned chains never saw OnConstruction with a persistent ID;
	// mint a session ID now (restore still works in-session; cross-session matching
	// falls back to the chain's actor name, then to legacy order).
	if (!ChainSaveId.IsValid())
	{
		ChainSaveId = FGuid::NewGuid();
	}

	// Auto-discover mission zones if not explicitly wired in editor
	if (Missions.Num() == 0 && GetWorld())
	{
		for (TActorIterator<AMissionZone> It(GetWorld()); It; ++It)
		{
			if (AMissionZone* Zone = *It)
			{
				Missions.Add(Zone);
			}
		}

		// Sort by MissionIndex ascending
		Missions.Sort([](const AMissionZone& A, const AMissionZone& B)
		{
			return A.MissionIndex < B.MissionIndex;
		});

		if (Missions.Num() > 0)
		{
			UE_LOG(LogTemp, Warning, TEXT("[QuestChain] %s: Auto-discovered and sequenced %d MissionZone(s) in level"),
				*GetName(), Missions.Num());
		}
	}

	for (AMissionZone* Mission : Missions)
	{
		if (Mission)
		{
			Mission->OwningChain = this;
		}
	}

	if (bAutoStart)
	{
		if (StartDelay > 0.f)
		{
			// FIX: Use CreateUObject for safe weak reference
			GetWorld()->GetTimerManager().SetTimer(StartDelayHandle,
				FTimerDelegate::CreateUObject(this, &AQuestChain::StartChain),
				StartDelay, false);
		}
		else
		{
			StartChain();
		}
	}
}

void AQuestChain::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	bWaitingForMission = false;
	GetWorld()->GetTimerManager().ClearTimer(WaitForMissionHandle);
	GQuestChains.Remove(this);
	Super::EndPlay(EndPlayReason);
}

void AQuestChain::StartChain()
{
	if (bIsActive) return;
	if (bIsCompleted) return;

	bIsActive = true;
	bIsCompleted = false;
	CurrentMissionIndex = -1;
	CompletedMissionCount = 0;

	AdvanceToNextMission();
}

void AQuestChain::RestartChain()
{
	// Unbind all mission events first
	for (AMissionZone* Mission : Missions)
	{
		if (Mission)
		{
			Mission->OnMissionStateChanged.RemoveDynamic(this, &AQuestChain::HandleMissionStateChanged);
			Mission->ResetMission();
		}
	}

	bWaitingForMission = false;
	GetWorld()->GetTimerManager().ClearTimer(WaitForMissionHandle);
	bIsActive = false;
	bIsCompleted = false;
	CurrentMissionIndex = -1;
	CompletedMissionCount = 0;

	StartChain();
}

AMissionZone* AQuestChain::FindByMissionIndex(int32 MissionIndexValue) const
{
	for (const TObjectPtr<AMissionZone>& M : Missions)
	{
		if (M && M->MissionIndex == MissionIndexValue)
		{
			return M;
		}
	}
	return nullptr;
}

AMissionZone* AQuestChain::GetCurrentMission() const
{
	// S20-WP: CurrentMissionIndex is the mission's MissionIndex VALUE (the stamped
	// act number), not a slot in a possibly-partial array - late registrations
	// insert into the sorted list, so slot and value diverge.
	return FindByMissionIndex(CurrentMissionIndex);
}

void AQuestChain::TryStartWaitingMission()
{
	if (!bWaitingForMission || bIsCompleted)
	{
		bWaitingForMission = false;
		GetWorld()->GetTimerManager().ClearTimer(WaitForMissionHandle);
		return;
	}
	if (FindByMissionIndex(CurrentMissionIndex))
	{
		bWaitingForMission = false;
		GetWorld()->GetTimerManager().ClearTimer(WaitForMissionHandle);
		StartMissionAtIndex(CurrentMissionIndex);   // the act just streamed in - go
		return;
	}
	++WaitRetries;
	if (WaitRetries % FQuestChainModel::RetryLogEvery() == 1)
	{
		UE_LOG(LogTemp, Warning, TEXT("[QuestChain] %s: waiting for mission %d to stream in (World Partition - the player walking there is the trigger)"),
			*GetName(), CurrentMissionIndex);
	}
}

void AQuestChain::RegisterMission(AMissionZone* Zone)
{
	if (!Zone)
	{
		return;
	}
	for (const TObjectPtr<AMissionZone>& M : Missions)
	{
		if (M == Zone)
		{
			return;   // already a member
		}
	}
	Zone->OwningChain = this;
	Missions.Add(Zone);
	Missions.Sort([](const AMissionZone& A, const AMissionZone& B)
	{
		return A.MissionIndex < B.MissionIndex;
	});
	UE_LOG(LogTemp, Warning, TEXT("[QuestChain] %s: mission %d registered late (World Partition cell loaded) - %d/%d known"),
		*GetName(), Zone->MissionIndex, Missions.Num(), GetTotalMissions());

	// the chain was waiting for exactly this act - start it now
	if (bWaitingForMission && Zone->MissionIndex == CurrentMissionIndex)
	{
		bWaitingForMission = false;
		GetWorld()->GetTimerManager().ClearTimer(WaitForMissionHandle);
		StartMissionAtIndex(CurrentMissionIndex);
	}
}

void AQuestChain::AdoptOrphanZone(AMissionZone* Zone)
{
	if (!Zone || Zone->OwningChain)
	{
		return;
	}
	for (const TWeakObjectPtr<AQuestChain>& C : GQuestChains)
	{
		if (AQuestChain* Chain = C.Get())
		{
			Chain->RegisterMission(Zone);
			return;
		}
	}
	// no chain alive yet: the chain's own discovery will collect this zone when
	// the chain begins (it is loaded - that is why it got here first)
}

float AQuestChain::GetOverallProgress() const
{
	if (Missions.Num() == 0) return 0.f;

	float TotalProgress = 0.f;
	for (int32 i = 0; i < Missions.Num(); ++i)
	{
		if (Missions[i])
		{
			if (Missions[i]->MissionState == EMissionZoneState::Completed)
			{
				TotalProgress += 1.f;
			}
			else if (Missions[i]->MissionIndex == CurrentMissionIndex)
			{
				TotalProgress += Missions[i]->MissionProgress;
			}
		}
	}
	const int32 Total = GetTotalMissions();
	return Total > 0 ? TotalProgress / static_cast<float>(Total) : 0.f;
}

FText AQuestChain::GetCurrentMissionDescription() const
{
	AMissionZone* Current = GetCurrentMission();
	return Current ? Current->MissionDescription : FText::FromString(TEXT("No active mission"));
}

AActor* AQuestChain::SpawnLeaderSplinePath()
{
	UWorld* World = GetWorld();
	if (!World)
	{
		UE_LOG(LogTemp, Error, TEXT("[PATHDBG] SpawnLeaderSplinePath: no world. Place the QuestChain in the map first."));
		return nullptr;
	}

	FActorSpawnParameters Params;
	Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	// S5-14c: WP/lifetime ownership for spawned children.
	Params.Owner = this;
	ASplinePathActor* Spline = World->SpawnActor<ASplinePathActor>(ASplinePathActor::StaticClass(), GetActorLocation(), GetActorRotation(), Params);
	if (!Spline)
	{
		UE_LOG(LogTemp, Error, TEXT("[PATHDBG] SpawnLeaderSplinePath FAILED. Compile SquadAI first (Live Coding OFF) so ASplinePathActor exists."));
		return nullptr;
	}

	if (Missions.IsValidIndex(0))
	{
		Spline->ToMission = Missions[0];
	}
#if WITH_EDITOR
	Spline->SetActorLabel(TEXT("LeaderSplinePath"));
#endif
	UE_LOG(LogTemp, Warning, TEXT("[PATHDBG] Spawned %s at %s ToMission=%s — select it and drag spline points along the trench."),
		*Spline->GetName(), *Spline->GetActorLocation().ToString(), *GetNameSafe(Spline->ToMission.Get()));
	return Spline;
}

void AQuestChain::StartMissionAtIndex(int32 Index)
{
	// S20-WP: Index is the MissionIndex VALUE. The mission may not exist yet -
	// its World Partition cell only streams in when the player walks there. The
	// old code returned silently here and the whole campaign stalled forever.
	CurrentMissionIndex = Index;
	AMissionZone* Mission = FindByMissionIndex(Index);
	if (!Mission)
	{
		if (!bWaitingForMission)
		{
			bWaitingForMission = true;
			WaitRetries = 0;
			GetWorld()->GetTimerManager().SetTimer(WaitForMissionHandle,
				FTimerDelegate::CreateUObject(this, &AQuestChain::TryStartWaitingMission),
				FQuestChainModel::RetryDelaySeconds(), true);   // polite poll until it streams
			UE_LOG(LogTemp, Warning, TEXT("[QuestChain] %s: mission %d not in memory yet (unloaded cell) - waiting instead of stalling"),
				*GetName(), Index);
		}
		return;
	}

	// restored saves / eager players: an act already Completed counts and advances
	if (Mission->MissionState == EMissionZoneState::Completed)
	{
		UE_LOG(LogTemp, Warning, TEXT("[QuestChain] %s: mission %d was already completed - advancing"),
			*GetName(), Index);
		OnMissionCompleted(Mission);
		return;
	}

	UE_LOG(LogTemp, Warning, TEXT("[QuestChain] %s: Starting mission %d/%d — '%s'"),
		*GetName(), Index + 1, GetTotalMissions(), *Mission->MissionDescription.ToString());

	// FIX: Remove first to prevent double-binding
	Mission->OnMissionStateChanged.RemoveDynamic(this, &AQuestChain::HandleMissionStateChanged);
	Mission->OnMissionStateChanged.AddDynamic(this, &AQuestChain::HandleMissionStateChanged);

	Mission->ActivateMission();

	OnChainProgressChanged.Broadcast(CurrentMissionIndex, GetTotalMissions());
}

void AQuestChain::AdvanceToNextMission()
{
	const int32 NextIndex = CurrentMissionIndex + 1;
	// S20-WP: the total is the STAMPED campaign size, not how many missions
	// happen to be in memory - far acts register late, the finale last of all.
	const int32 Total = GetTotalMissions();

	if (FQuestChainModel::ShouldComplete(NextIndex, Total, CompletedMissionCount))
	{
		bIsActive = false;
		bIsCompleted = true;

		// Award bonus operation XP & update achievements
		if (USquadAIProgressionSubsystem* Prog = USquadAIProgressionSubsystem::Get(this))
		{
			Prog->AwardXP(1500, TEXT("Theater Operation Victory"));
			Prog->UpdateAchievementProgress(FName("DehlaviehDefender"), 3.0f);
		}

		UE_LOG(LogTemp, Warning, TEXT("[QuestChain] %s: ALL %d MISSIONS COMPLETED!"),
			*GetName(), Total);
		OnChainCompleted.Broadcast();
		return;
	}

	// the next act may be an unregistered/unloaded mission - StartMissionAtIndex
	// waits for it (polite poll) instead of ending the campaign early
	StartMissionAtIndex(NextIndex);
}

void AQuestChain::OnMissionCompleted(AMissionZone* Mission)
{
	CompletedMissionCount++;

	UE_LOG(LogTemp, Warning, TEXT("[QuestChain] %s: Mission %d completed (%d/%d total)"),
		*GetName(), CurrentMissionIndex + 1, CompletedMissionCount, GetTotalMissions());

	Mission->OnMissionStateChanged.RemoveDynamic(this, &AQuestChain::HandleMissionStateChanged);

	AdvanceToNextMission();
}

void AQuestChain::OnMissionFailed(AMissionZone* Mission)
{
	UE_LOG(LogTemp, Warning, TEXT("[QuestChain] %s: Mission %d FAILED — restarting mission"),
		*GetName(), CurrentMissionIndex + 1);

	Mission->OnMissionStateChanged.RemoveDynamic(this, &AQuestChain::HandleMissionStateChanged);

	if (bRestartChainOnFailure)
	{
		RestartChain();
	}
	else
	{
		OnChainFailed.Broadcast(Mission);
		Mission->ResetMission();

		// FIX: Use CreateUObject for safe weak reference
		FTimerHandle RestartHandle;
		GetWorld()->GetTimerManager().SetTimer(RestartHandle,
			FTimerDelegate::CreateWeakLambda(this, [this]()
			{
				if (this && !this->IsActorBeingDestroyed())
				{
					StartMissionAtIndex(CurrentMissionIndex);
				}
			}),
			1.0f, false);
	}
}

void AQuestChain::HandleMissionStateChanged(AMissionZone* Mission, EMissionZoneState NewState)
{
	if (!Mission) return;

	// FIX: Only process events from the current mission
	if (Mission != GetCurrentMission()) return;

	switch (NewState)
	{
	case EMissionZoneState::Completed:
		OnMissionCompleted(Mission);
		break;
	case EMissionZoneState::Failed:
		OnMissionFailed(Mission);
		break;
	default:
		break;
	}
}

// F-P03: public save/restore entry point. The save subsystem calls this (not the
// private StartMissionAtIndex) when rebuilding chain state after load.
void AQuestChain::RestoreMissionState(int32 SavedActiveIndex)
{
	StartMissionAtIndex(SavedActiveIndex);
}

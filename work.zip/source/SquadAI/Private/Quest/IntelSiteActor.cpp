// IntelSiteActor.cpp - S19-INTEL
#include "Quest/IntelSiteActor.h"
#include "Components/StaticMeshComponent.h"
#include "Diagnostics/SquadAISituationLog.h"
#include "Engine/World.h"
#include "GameFramework/Pawn.h"
#include "Kismet/GameplayStatics.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "UObject/ConstructorHelpers.h"

AIntelSiteActor::AIntelSiteActor()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 0.f; // the pulse and the scan both read better per-frame

	USceneComponent* Root = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SetRootComponent(Root);

	static ConstructorHelpers::FObjectFinder<UStaticMesh> CylMesh(TEXT("/Engine/BasicShapes/Cylinder.Cylinder"));
	static ConstructorHelpers::FObjectFinder<UStaticMesh> CubeMesh(TEXT("/Engine/BasicShapes/Cube.Cube"));
	static ConstructorHelpers::FObjectFinder<UMaterialInterface> BaseMat(TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"));

	// Painted disc on the ground: tells the player WHERE to scan (same language as the
	// demolition charge's marker, so the two objective types read identically in-world).
	MarkerDisc = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("MarkerDisc"));
	MarkerDisc->SetupAttachment(Root);
	if (CylMesh.Succeeded()) MarkerDisc->SetStaticMesh(CylMesh.Object);
	if (BaseMat.Succeeded()) MarkerDisc->SetMaterial(0, BaseMat.Object);
	MarkerDisc->SetRelativeScale3D(FVector(1.3f, 1.3f, 0.03f));
	MarkerDisc->SetRelativeLocation(FVector(0.f, 0.f, 2.f));
	MarkerDisc->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	MarkerDisc->SetCanEverAffectNavigation(false);
	MarkerDisc->SetCastShadow(false);

	// The set itself - hidden until the scan finishes.
	AntennaMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("AntennaMesh"));
	AntennaMesh->SetupAttachment(Root);
	if (CubeMesh.Succeeded()) AntennaMesh->SetStaticMesh(CubeMesh.Object);
	if (BaseMat.Succeeded()) AntennaMesh->SetMaterial(0, BaseMat.Object);
	AntennaMesh->SetRelativeScale3D(FVector(0.12f, 0.12f, 1.0f));
	AntennaMesh->SetRelativeLocation(FVector(0.f, 0.f, 50.f));
	AntennaMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	AntennaMesh->SetCanEverAffectNavigation(false);
	AntennaMesh->SetVisibility(false);
}

void AIntelSiteActor::BeginPlay()
{
	Super::BeginPlay();

	if (MarkerDisc)
	{
		MarkerMID = MarkerDisc->CreateAndSetMaterialInstanceDynamic(0);
	}

	// Start from a known state, so a site replaced or re-enabled mid-session cannot
	// inherit a half-finished scan.
	ScanProgressSeconds = 0.f;
	TransmitSeconds = 0.f;
	ProbeProgress01 = 0.f;
	TransmitProgress01 = 0.f;
	SiteState = EIntelSiteState::AwaitingScan;
	if (AntennaMesh)
	{
		AntennaMesh->SetVisibility(false);
	}
	SetMarkerColor(FLinearColor(0.10f, 0.55f, 1.0f));
}

void AIntelSiteActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}
	const float NowSeconds = World->GetTimeSeconds();

	// Is the player standing here? The same shape as the charge's test: 2D distance for
	// the radius, a generous vertical window so a site on a roof is not scanned from the
	// street below it.
	bool bPlayerClose = false;
	if (const APawn* Player = UGameplayStatics::GetPlayerPawn(World, 0))
	{
		const FVector PlayerLoc = Player->GetActorLocation();
		const FVector Here = GetActorLocation();
		bPlayerClose = FVector::DistSquared2D(PlayerLoc, Here) <= ScanRadius * ScanRadius
			&& FMath::Abs(PlayerLoc.Z - Here.Z) < 350.f;
	}

	switch (SiteState)
	{
	case EIntelSiteState::AwaitingScan:
	case EIntelSiteState::Scanning:
	{
		if (bPlayerClose && SiteState == EIntelSiteState::AwaitingScan)
		{
			SiteState = EIntelSiteState::Scanning;
			UE_LOG(LogTemp, Warning, TEXT("[S19-INTEL] %s: scanning '%s' — hold position %.1f s"),
				*GetName(), *SiteName.ToString(), ScanTime);
		}

		const float Before = ProbeProgress01;
		ScanProgressSeconds = FIntelScanModel::AdvanceProgress(
			ScanProgressSeconds, DeltaTime, ScanTime, bPlayerClose);
		ProbeProgress01 = FIntelScanModel::Progress01(ScanProgressSeconds, ScanTime);

		if (Before != ProbeProgress01)
		{
			OnIntelScanProgress.Broadcast(this, ProbeProgress01);
		}
		if (!bPlayerClose && ScanProgressSeconds <= 0.f && SiteState == EIntelSiteState::Scanning)
		{
			SiteState = EIntelSiteState::AwaitingScan; // walked away before starting: reset the label
		}

		if (FIntelScanModel::IsPlanted(ScanProgressSeconds, ScanTime))
		{
			BeginTransmit();
		}

		// Amber pulse while scanning, bright and faster as it fills.
		const float Pulse = 0.45f + 0.55f * (0.5f + 0.5f * FMath::Sin(NowSeconds * (2.5f + 6.f * ProbeProgress01)));
		SetMarkerColor(FLinearColor(0.15f * Pulse, 0.55f * Pulse + 0.25f, 1.f * Pulse));
		break;
	}
	case EIntelSiteState::Transmitting:
	{
		bool bTransmitting = true;
		if (bTransmitNeedsPlayerNearby)
		{
			bool bNearby = false;
			if (const APawn* Player = UGameplayStatics::GetPlayerPawn(World, 0))
			{
				const FVector PlayerLoc = Player->GetActorLocation();
				bNearby = FVector::DistSquared2D(PlayerLoc, GetActorLocation())
					<= TransmitRadius * TransmitRadius;
			}
			bTransmitting = bNearby;
		}

		TransmitSeconds = FIntelScanModel::AdvanceTransmit(TransmitSeconds, DeltaTime, bTransmitting);
		TransmitProgress01 = (TransmitTime > KINDA_SMALL_NUMBER)
			? FMath::Clamp(TransmitSeconds / TransmitTime, 0.f, 1.f) : 1.f;

		// Green strobe while the set is up - unmistakably "this one is working".
		const float Pulse = 0.5f + 0.5f * FMath::Sin(NowSeconds * 9.f);
		SetMarkerColor(FLinearColor(0.10f + 0.15f * Pulse, 0.85f, 0.35f * Pulse));

		if (FIntelScanModel::IsReported(TransmitSeconds, TransmitTime))
		{
			ReportNow();
		}
		break;
	}
	case EIntelSiteState::Reported:
	default:
	{
		// Steady green: the set is done and the player can see it from across the field.
		SetMarkerColor(FLinearColor(0.10f, 0.90f, 0.30f));
		break;
	}
	}
}

void AIntelSiteActor::BeginTransmit()
{
	SiteState = EIntelSiteState::Transmitting;
	TransmitSeconds = 0.f;
	TransmitProgress01 = (TransmitTime > KINDA_SMALL_NUMBER) ? 0.f : 1.f;
	ProbeProgress01 = 1.f;
	if (AntennaMesh)
	{
		AntennaMesh->SetVisibility(true);
	}
	UE_LOG(LogTemp, Warning, TEXT("[S19-INTEL] %s: '%s' SCANNED — beacon transmitting (%.0f s%s)"),
		*GetName(), *SiteName.ToString(), TransmitTime,
		bTransmitNeedsPlayerNearby ? TEXT(", must stay close") : TEXT(""));
	SquadAISituation::Note(FString::Printf(TEXT("INTEL %s: '%s' scanned, transmitting."),
		*GetName(), *SiteName.ToString()));
}

void AIntelSiteActor::ReportNow()
{
	if (SiteState == EIntelSiteState::Reported)
	{
		return;
	}
	SiteState = EIntelSiteState::Reported;
	TransmitProgress01 = 1.f;
	OnIntelReported.Broadcast(this);
	SquadAISituation::Note(FString::Printf(TEXT("INTEL %s: '%s' REPORTED."),
		*GetName(), *SiteName.ToString()));
}

void AIntelSiteActor::ResetSite()
{
	ScanProgressSeconds = 0.f;
	TransmitSeconds = 0.f;
	ProbeProgress01 = 0.f;
	TransmitProgress01 = 0.f;
	SiteState = EIntelSiteState::AwaitingScan;
	if (AntennaMesh)
	{
		AntennaMesh->SetVisibility(false);
	}
}

void AIntelSiteActor::SetMarkerColor(const FLinearColor& C)
{
	if (MarkerMID)
	{
		MarkerMID->SetVectorParameterValue(TEXT("Color"), C);
	}
}

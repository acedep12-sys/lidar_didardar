#include "Quest/AtmosphericDustScatterer.h"
#include "Performance/SquadAIFXManagerSubsystem.h"
#include "NiagaraSystem.h"
#include "NiagaraFunctionLibrary.h"
#include "NiagaraComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/World.h"
#include "TimerManager.h"
#include "Components/PrimitiveComponent.h"
#include "Materials/MaterialInterface.h"
#include "CollisionQueryParams.h"
#include "UObject/UnrealType.h"

AAtmosphericDustScatterer::AAtmosphericDustScatterer()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 0.25f;

	USceneComponent* Root = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	SetRootComponent(Root);
}

void AAtmosphericDustScatterer::BeginPlay()
{
	Super::BeginPlay();
	StartZoneBuild();
}

void AAtmosphericDustScatterer::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	CleanupAllSpawned();
	Super::EndPlay(EndPlayReason);
}

#if WITH_EDITOR
void AAtmosphericDustScatterer::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	if (PropertyChangedEvent.GetPropertyName() == GET_MEMBER_NAME_CHECKED(AAtmosphericDustScatterer, bRebuildZones))
	{
		if (bRebuildZones)
		{
			RebuildAll();
			bRebuildZones = false;
		}
	}
}
#endif

void AAtmosphericDustScatterer::RebuildAll()
{
	CleanupAllSpawned();
	StartZoneBuild();
}

void AAtmosphericDustScatterer::CleanupAllSpawned()
{
	// Clean active Niagara components
	for (UNiagaraComponent* NC : ActiveParticles)
	{
		if (NC && NC->IsValidLowLevel())
		{
			NC->DeactivateImmediate();
			NC->DestroyComponent();
		}
	}
	ActiveParticles.Empty();

	// Clean active Ambient Volume actors
	for (AActor* VolActor : ActiveAmbientVolumes)
	{
		if (VolActor && VolActor->IsValidLowLevel() && !VolActor->IsActorBeingDestroyed())
		{
			VolActor->Destroy();
		}
	}
	ActiveAmbientVolumes.Empty();

	// Clean active Ditch Volume actors
	for (AActor* DitchActor : ActiveDitchVolumes)
	{
		if (DitchActor && DitchActor->IsValidLowLevel() && !DitchActor->IsActorBeingDestroyed())
		{
			DitchActor->Destroy();
		}
	}
	ActiveDitchVolumes.Empty();
}

void AAtmosphericDustScatterer::StartZoneBuild()
{
	ZoneCenters.Empty();
	DetectedDitchCenters.Empty();
	ZonesBuilt = 0;
	bBuilding = true;

	UE_LOG(LogTemp, Warning, TEXT("[DustScatterer] %s: Initializing near-player dust system (%d zones)..."),
		*GetName(), AutoZoneCount);
}

void AAtmosphericDustScatterer::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	// Incremental zone build during initialization
	if (bBuilding)
	{
		BuildNextZoneBatch();
		return;
	}

	UpdateTimer += DeltaTime;
	if (UpdateTimer >= UpdateInterval)
	{
		UpdateTimer = 0.f;
		UpdateStreaming();
	}
}

void AAtmosphericDustScatterer::BuildNextZoneBatch()
{
	UWorld* World = GetWorld();
	if (!World) return;

	const FVector Origin = GetActorLocation();
	const float TotalRadius = AutoZoneRadius * FMath::Sqrt(static_cast<float>(AutoZoneCount));

	int32 Built = 0;
	const int32 ZonesPerTick = 5;

	while (ZonesBuilt < AutoZoneCount && Built < ZonesPerTick)
	{
		const float Angle = FMath::FRandRange(0.f, 2.f * PI);
		const float Dist = FMath::FRandRange(0.f, TotalRadius);
		FVector Center = Origin + FVector(FMath::Cos(Angle) * Dist, FMath::Sin(Angle) * Dist, 0.f);

		// Ground trace to lock zone to terrain surface
		FHitResult Hit;
		FVector TraceStart = Center + FVector(0.f, 0.f, 4000.f);
		FVector TraceEnd = Center - FVector(0.f, 0.f, 8000.f);
		FCollisionQueryParams QueryParams(SCENE_QUERY_STAT(DustGroundTrace), false, this);

		if (World->LineTraceSingleByChannel(Hit, TraceStart, TraceEnd, ECC_WorldStatic, QueryParams))
		{
			Center = Hit.Location + FVector(0.f, 0.f, 15.f);

			// Check if this point falls into a low-ground ditch or berm depression
			float Depth = 0.f;
			if (bEnableDitchDust && CheckIfPointIsInDitch(Hit.Location, Depth))
			{
				DetectedDitchCenters.Add(Hit.Location + FVector(0.f, 0.f, 25.f));
			}
		}

		ZoneCenters.Add(Center);
		ZonesBuilt++;
		Built++;
	}

	// Add manual zones and manual ditches
	if (ZonesBuilt >= AutoZoneCount && ZoneCenters.Num() <= AutoZoneCount)
	{
		for (const FDustZone& Zone : ManualZones)
		{
			ZoneCenters.Add(Zone.Center);
		}

		for (const FVector& DitchLoc : ManualDitchLocations)
		{
			DetectedDitchCenters.Add(DitchLoc);
		}
	}

	if (ZonesBuilt >= AutoZoneCount)
	{
		bBuilding = false;
		PrimaryActorTick.TickInterval = UpdateInterval;
		UE_LOG(LogTemp, Warning, TEXT("[DustScatterer] %s: Ready. %d local zones, %d ditch pockets found."),
			*GetName(), ZoneCenters.Num(), DetectedDitchCenters.Num());
	}
}

bool AAtmosphericDustScatterer::CheckIfPointIsInDitch(const FVector& Location, float& OutDepth) const
{
	UWorld* World = GetWorld();
	if (!World) return false;

	const float CheckOffset = 400.f;
	const FVector SampleOffsets[4] = {
		FVector(CheckOffset, 0.f, 0.f),
		FVector(-CheckOffset, 0.f, 0.f),
		FVector(0.f, CheckOffset, 0.f),
		FVector(0.f, -CheckOffset, 0.f)
	};

	float SurroundingHeightSum = 0.f;
	int32 ValidSurroundingSamples = 0;
	FCollisionQueryParams QueryParams(SCENE_QUERY_STAT(DitchCheck), false, this);

	for (int32 i = 0; i < 4; ++i)
	{
		FHitResult SampleHit;
		FVector Start = Location + SampleOffsets[i] + FVector(0.f, 0.f, 2000.f);
		FVector End = Location + SampleOffsets[i] - FVector(0.f, 0.f, 4000.f);

		if (World->LineTraceSingleByChannel(SampleHit, Start, End, ECC_WorldStatic, QueryParams))
		{
			SurroundingHeightSum += SampleHit.Location.Z;
			ValidSurroundingSamples++;
		}
	}

	if (ValidSurroundingSamples >= 3)
	{
		const float AvgSurroundingZ = SurroundingHeightSum / static_cast<float>(ValidSurroundingSamples);
		OutDepth = AvgSurroundingZ - Location.Z;
		return OutDepth >= DitchDepthThreshold;
	}

	return false;
}

void AAtmosphericDustScatterer::UpdateStreaming()
{
	APawn* Player = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	if (!Player) return;

	const FVector PlayerLoc = Player->GetActorLocation();
	const float ActRadSq = ActivationRadius * ActivationRadius;

	// 1. Ambient Walking Dust (Niagara + Slot 3 Volume)
	UpdateNiagaraParticles(PlayerLoc, ActRadSq);
	UpdateAmbientVolumes(PlayerLoc, ActRadSq);

	// 2. Low-Ground / Ditch Dust (Slot 14 Volume)
	if (bEnableDitchDust)
	{
		UpdateDitchVolumes(PlayerLoc, ActRadSq);
	}
}

void AAtmosphericDustScatterer::UpdateNiagaraParticles(const FVector& PlayerLoc, float ActivationRadiusSq)
{
	if (!DustEffect) return;

	const float CullRadiusSq = ActivationRadiusSq * 1.6f;

	// Cull far particles using fast squared distance
	for (int32 i = ActiveParticles.Num() - 1; i >= 0; --i)
	{
		UNiagaraComponent* NC = ActiveParticles[i];
		if (!NC || !NC->IsValidLowLevel())
		{
			ActiveParticles.RemoveAtSwap(i);
			continue;
		}

		if (FVector::DistSquared(NC->GetComponentLocation(), PlayerLoc) > CullRadiusSq)
		{
			NC->DeactivateImmediate();
			NC->DestroyComponent();
			ActiveParticles.RemoveAtSwap(i);
		}
	}

	// Stream in closest zones within budget
	for (const FVector& ZoneCenter : ZoneCenters)
	{
		if (ActiveParticles.Num() >= MaxActiveParticles) break;

		if (FVector::DistSquared(ZoneCenter, PlayerLoc) > ActivationRadiusSq) continue;

		bool bAlreadyActive = false;
		const float ProximityCheckSq = FMath::Square(AutoZoneRadius * 0.5f);

		for (UNiagaraComponent* NC : ActiveParticles)
		{
			if (NC && NC->IsValidLowLevel())
			{
				if (FVector::DistSquared(NC->GetComponentLocation(), ZoneCenter) < ProximityCheckSq)
				{
					bAlreadyActive = true;
					break;
				}
			}
		}

		if (bAlreadyActive) continue;

		const FVector SpawnLoc = GetRandomPointInZone(ZoneCenter, AutoZoneRadius * 0.35f);
		// P1-P3: FX-budget gate (distance cull + per-second throttle; fail-open).
		USquadAIFXManagerSubsystem* FXSys = USquadAIFXManagerSubsystem::Get(this);
		if (FXSys && !FXSys->CanSpawnImpactVFX(SpawnLoc)) continue;
		UNiagaraComponent* NC = UNiagaraFunctionLibrary::SpawnSystemAtLocation(
			GetWorld(), DustEffect, SpawnLoc, FRotator::ZeroRotator,
			FVector(AmbientScale), true, true, ENCPoolMethod::AutoRelease);

		if (NC)
		{
			NC->SetAutoDestroy(false);
			ActiveParticles.Add(NC);
		}
	}
}

void AAtmosphericDustScatterer::UpdateAmbientVolumes(const FVector& PlayerLoc, float ActivationRadiusSq)
{
	if (!AmbientVolumeActorClass && !AmbientVolumeMaterial) return;

	const float CullRadiusSq = ActivationRadiusSq * 1.8f;

	// Cull far ambient volumes
	for (int32 i = ActiveAmbientVolumes.Num() - 1; i >= 0; --i)
	{
		AActor* VolActor = ActiveAmbientVolumes[i];
		if (!VolActor || !VolActor->IsValidLowLevel() || VolActor->IsActorBeingDestroyed())
		{
			ActiveAmbientVolumes.RemoveAtSwap(i);
			continue;
		}

		if (FVector::DistSquared(VolActor->GetActorLocation(), PlayerLoc) > CullRadiusSq)
		{
			VolActor->Destroy();
			ActiveAmbientVolumes.RemoveAtSwap(i);
		}
	}

	// Stream in ambient volume within strict GPU budget
	if (ActiveAmbientVolumes.Num() < MaxActiveAmbientVolumes)
	{
		for (const FVector& ZoneCenter : ZoneCenters)
		{
			if (ActiveAmbientVolumes.Num() >= MaxActiveAmbientVolumes) break;

			if (FVector::DistSquared(ZoneCenter, PlayerLoc) > ActivationRadiusSq) continue;

			bool bAlreadyPresent = false;
			for (AActor* VolActor : ActiveAmbientVolumes)
			{
				if (VolActor && FVector::DistSquared(VolActor->GetActorLocation(), ZoneCenter) < (ActivationRadiusSq * 0.5f))
				{
					bAlreadyPresent = true;
					break;
				}
			}

			if (!bAlreadyPresent)
			{
				AActor* NewVol = SpawnVolumeInstance(AmbientVolumeActorClass, AmbientVolumeMaterial,
					ZoneCenter + FVector(0.f, 0.f, 50.f), FVector(AmbientScale), FRotator::ZeroRotator);
				if (NewVol)
				{
					ActiveAmbientVolumes.Add(NewVol);
				}
			}
		}
	}
}

void AAtmosphericDustScatterer::UpdateDitchVolumes(const FVector& PlayerLoc, float ActivationRadiusSq)
{
	if (!DitchVolumeActorClass && !DitchVolumeMaterial) return;

	const float CullRadiusSq = ActivationRadiusSq * 1.8f;

	// Cull far ditch volumes
	for (int32 i = ActiveDitchVolumes.Num() - 1; i >= 0; --i)
	{
		AActor* DitchActor = ActiveDitchVolumes[i];
		if (!DitchActor || !DitchActor->IsValidLowLevel() || DitchActor->IsActorBeingDestroyed())
		{
			ActiveDitchVolumes.RemoveAtSwap(i);
			continue;
		}

		if (FVector::DistSquared(DitchActor->GetActorLocation(), PlayerLoc) > CullRadiusSq)
		{
			DitchActor->Destroy();
			ActiveDitchVolumes.RemoveAtSwap(i);
		}
	}

	// Spawn in nearby detected ditches within strict budget
	if (ActiveDitchVolumes.Num() < MaxActiveDitchVolumes)
	{
		for (const FVector& DitchCenter : DetectedDitchCenters)
		{
			if (ActiveDitchVolumes.Num() >= MaxActiveDitchVolumes) break;

			if (FVector::DistSquared(DitchCenter, PlayerLoc) > ActivationRadiusSq) continue;

			bool bAlreadyPresent = false;
			for (AActor* DitchActor : ActiveDitchVolumes)
			{
				if (DitchActor && FVector::DistSquared(DitchActor->GetActorLocation(), DitchCenter) < FMath::Square(1000.f))
				{
					bAlreadyPresent = true;
					break;
				}
			}

			if (!bAlreadyPresent)
			{
				// S6-D: seeded per-ditch variation — identical volumes read as one sheet.
				// Seed mixes position so the SAME ditch keeps its shape across cull cycles.
				const FRandomStream DustStream((int32)(DitchCenter.X + DitchCenter.Y * 1.31 + DitchCenter.Z * 0.77) ^ DitchVariationSeed);
				const FVector VarScale = bDitchVariation
					? FVector(DitchVolumeScale) * DustStream.FRandRange(0.85f, 1.20f)
					: FVector(DitchVolumeScale);
				const FRotator VarRot = bDitchVariation
					? FRotator(0.f, DustStream.FRandRange(0.f, 360.f), 0.f)
					: FRotator::ZeroRotator;
				AActor* NewDitchVol = SpawnVolumeInstance(DitchVolumeActorClass, DitchVolumeMaterial,
					DitchCenter, VarScale, VarRot);
				if (NewDitchVol)
				{
					ActiveDitchVolumes.Add(NewDitchVol);
				}
			}
		}
	}
}

AActor* AAtmosphericDustScatterer::SpawnVolumeInstance(TSubclassOf<AActor> ActorClass, UMaterialInterface* Material, const FVector& Location, const FVector& Scale3D, const FRotator& Rotation)
{
	UWorld* World = GetWorld();
	if (!World) return nullptr;

	TSubclassOf<AActor> EffectiveClass = ActorClass;
	if (!EffectiveClass)
	{
		EffectiveClass = ResolveDefaultHeterogeneousVolumeClass();
	}

	FActorSpawnParameters SpawnParams;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	SpawnParams.Owner = this;

	AActor* SpawnedActor = nullptr;
	if (EffectiveClass)
	{
		SpawnedActor = World->SpawnActor<AActor>(EffectiveClass, Location, Rotation, SpawnParams);
	}

	if (SpawnedActor)
	{
		SpawnedActor->SetActorScale3D(Scale3D);

		if (Material)
		{
			ApplyMaterialToActor(SpawnedActor, Material);
		}
	}

	return SpawnedActor;
}

void AAtmosphericDustScatterer::ApplyMaterialToActor(AActor* TargetActor, UMaterialInterface* Material)
{
	if (!TargetActor || !Material) return;

	TArray<UPrimitiveComponent*> PrimComps;
	TargetActor->GetComponents(PrimComps);
	for (UPrimitiveComponent* PrimComp : PrimComps)
	{
		if (PrimComp)
		{
			PrimComp->SetMaterial(0, Material);
		}
	}

	for (const FName& PropName : { FName(TEXT("Material")), FName(TEXT("VolumeMaterial")), FName(TEXT("MaterialInterface")) })
	{
		if (FObjectProperty* ObjProp = FindFProperty<FObjectProperty>(TargetActor->GetClass(), PropName))
		{
			ObjProp->SetObjectPropertyValue_InContainer(TargetActor, Material);
		}
	}
}

UClass* AAtmosphericDustScatterer::ResolveDefaultHeterogeneousVolumeClass() const
{
	if (UClass* FoundClass = StaticLoadClass(AActor::StaticClass(), nullptr, TEXT("/Script/Engine.HeterogeneousVolume")))
	{
		return FoundClass;
	}

	// S5-10: was a bare AActor fallback — dead weight (an empty actor per zone holding
	// no volume). Callers already null-check, so fail clean.
	UE_LOG(LogTemp, Warning, TEXT("[DustScatterer] HeterogeneousVolume class not found — skipping volume spawn"));
	return nullptr;
}

FVector AAtmosphericDustScatterer::GetRandomPointInZone(const FVector& Center, float Radius) const
{
	const float Angle = FMath::FRandRange(0.f, 2.f * PI);
	const float Dist = FMath::FRandRange(0.f, Radius);
	return Center + FVector(FMath::Cos(Angle) * Dist, FMath::Sin(Angle) * Dist, 0.f);
}

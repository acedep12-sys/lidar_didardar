// InterdictionDirectorActor.cpp - S19-INTERDICT: the schedule, the counts, the two outcomes.

#include "Quest/InterdictionDirectorActor.h"

#include "Actors/EnemyPatrolRoute.h"
#include "Quest/InterdictionCourierActor.h"
#include "Quest/InterdictionModel.h"
#include "Engine/World.h"
#include "TimerManager.h"

AInterdictionDirectorActor::AInterdictionDirectorActor()
{
	PrimaryActorTick.bCanEverTick = false;
	CourierClass = AInterdictionCourierActor::StaticClass();
}

void AInterdictionDirectorActor::StartRun()
{
	if (bRunStarted)
	{
		return;
	}
	if (!CourierRoute)
	{
		UE_LOG(LogTemp, Warning,
			TEXT("[S19-INTERDICT] %s: no CourierRoute - the run cannot start. Point 'Courier Route' at an AEnemyPatrolRoute."),
			*GetName());
		return;
	}

	bRunStarted = true;
	bRunOver = false;
	UE_LOG(LogTemp, Warning, TEXT("[S19-INTERDICT] %s: run started - %d courier(s), stop %d, max %d escape(s)."),
		*GetName(), CourierCount, StopQuota, MaxEscapes);

	// First courier: the spawn schedule is the model's.
	UWorld* World = GetWorld();
	if (World)
	{
		World->GetTimerManager().SetTimer(SpawnTimerHandle, this,
			&AInterdictionDirectorActor::SpawnCourier,
			FInterdictionModel::NextSpawnDelay(0, FirstDelaySeconds, SpawnIntervalSeconds), false);
	}
}

void AInterdictionDirectorActor::ResetRun()
{
	UWorld* World = GetWorld();
	if (World)
	{
		World->GetTimerManager().ClearTimer(SpawnTimerHandle);
	}
	for (const TWeakObjectPtr<AInterdictionCourierActor>& Weak : LiveCouriers)
	{
		if (AInterdictionCourierActor* Courier = Weak.Get())
		{
			Courier->Destroy();
		}
	}
	LiveCouriers.Reset();
	SpawnedCount = 0;
	StoppedCount = 0;
	EscapedCount = 0;
	bQuotaMet = false;
	bEscapeLimitHit = false;
	bRunStarted = false;
	bRunOver = false;
}

void AInterdictionDirectorActor::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(SpawnTimerHandle);
	}
	Super::EndPlay(EndPlayReason);
}

void AInterdictionDirectorActor::SpawnCourier()
{
	if (bRunOver || !CourierRoute)
	{
		return;
	}
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}

	// The model's reachability rule: a run that can no longer meet its quota stops
	// spawning instead of dribbling trucks into a lost field.
	const int32 LeftToBecome = FMath::Max(0, CourierCount - SpawnedCount);
	if (!FInterdictionModel::QuotaStillReachable(StoppedCount, StopQuota, LeftToBecome))
	{
		bRunOver = true;
		UE_LOG(LogTemp, Warning, TEXT("[S19-INTERDICT] %s: the quota is no longer reachable - the run is over (%s)."),
			*GetName(), *FInterdictionModel::SummaryLine(StoppedCount, StopQuota, EscapedCount));
		return;
	}
	if (SpawnedCount >= CourierCount)
	{
		return;
	}

	FActorSpawnParameters Params;
	Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;

	const FVector Origin = CourierRoute->GetPointCount() > 0
		? CourierRoute->GetPointLocation(0)
		: CourierRoute->GetActorLocation();

	AInterdictionCourierActor* Courier = World->SpawnActor<AInterdictionCourierActor>(
		CourierClass ? CourierClass : TSubclassOf<AInterdictionCourierActor>(AInterdictionCourierActor::StaticClass()),
		Origin, CourierRoute->GetActorRotation(), Params);
	if (!Courier)
	{
		UE_LOG(LogTemp, Warning, TEXT("[S19-INTERDICT] %s: courier %d failed to spawn - retrying on the next beat."),
			*GetName(), SpawnedCount + 1);
	}
	else
	{
		Courier->Route = CourierRoute;
		Courier->RefreshRoute();
		Courier->OnStopped.AddDynamic(this, &AInterdictionDirectorActor::HandleCourierStopped);
		Courier->OnEscaped.AddDynamic(this, &AInterdictionDirectorActor::HandleCourierEscaped);
		LiveCouriers.Add(Courier);
		++SpawnedCount;
		UE_LOG(LogTemp, Warning, TEXT("[S19-INTERDICT] %s: courier %d/%d is rolling."),
			*GetName(), SpawnedCount, CourierCount);
	}

	// The next beat (the model: interval from the second courier on).
	if (SpawnedCount < CourierCount)
	{
		World->GetTimerManager().SetTimer(SpawnTimerHandle, this,
			&AInterdictionDirectorActor::SpawnCourier,
			FInterdictionModel::NextSpawnDelay(SpawnedCount, FirstDelaySeconds, SpawnIntervalSeconds), false);
	}
}

void AInterdictionDirectorActor::HandleCourierStopped(AInterdictionCourierActor* Courier)
{
	if (bRunOver || !Courier)
	{
		return;
	}
	++StoppedCount;
	HandleCourierResolved();
}

void AInterdictionDirectorActor::HandleCourierEscaped(AInterdictionCourierActor* Courier)
{
	if (bRunOver || !Courier)
	{
		return;
	}
	++EscapedCount;
	HandleCourierResolved();
}

void AInterdictionDirectorActor::HandleCourierResolved()
{
	UE_LOG(LogTemp, Warning, TEXT("[S19-INTERDICT] %s: %s."),
		*GetName(), *FInterdictionModel::SummaryLine(StoppedCount, StopQuota, EscapedCount));

	// The double bar: quota (success) and escape limit (failure), quota read first.
	if (!bQuotaMet && FInterdictionModel::QuotaMet(StoppedCount, StopQuota))
	{
		bQuotaMet = true;
		OnQuotaMet.Broadcast(this);
	}
	if (!bEscapeLimitHit && FInterdictionModel::EscapeLimitReached(EscapedCount, MaxEscapes))
	{
		bEscapeLimitHit = true;
		OnEscapeLimitReached.Broadcast(this);
	}
	if (FInterdictionModel::RunIsOver(StoppedCount, EscapedCount, CourierCount, StopQuota, MaxEscapes))
	{
		bRunOver = true;
		if (UWorld* World = GetWorld())
		{
			World->GetTimerManager().ClearTimer(SpawnTimerHandle);
		}
		UE_LOG(LogTemp, Warning, TEXT("[S19-INTERDICT] %s: run over - %s."),
			*GetName(), *FInterdictionModel::SummaryLine(StoppedCount, StopQuota, EscapedCount));
	}
}

// QuestObjective.cpp — The Direct Command Injector
#include "Quest/QuestObjective.h"
#include "Quest/QuestRegistry.h"
#include "Quest/QuestZone.h"
#include "Quest/WaveSpawner.h"
#include "AI/SoldierAIController.h"
#include "AI/SquadAICommandTypes.h"
#include "Performance/SoldierRegistrySubsystem.h"
#include "Characters/SoldierCharacter.h"
#include "EngineUtils.h"
#include "GameFramework/Pawn.h"

void UQuestObjective_AutoZone::OnStart(UWorld* World)
{
	Super::OnStart(World);
	if (!World) return;
	UQuestRegistry* Reg = World->GetSubsystem<UQuestRegistry>();
	if (!Reg) return;
	
	AActor* Found = Reg->Find(ZoneTag);
	CachedZone = Cast<AQuestZone>(Found);
	FVector GoalLoc = Found ? Found->GetActorLocation() : FVector::ZeroVector;

	// SET THE GPS BEACON
	Reg->CurrentActiveGoal = GoalLoc;

	// ---- DIRECT COMMAND: Force-push the goal to allied AI brains only ----
	auto PushAllyGoal = [GoalLoc](ASoldierAIController* AIC)
	{
		if (!AIC || AIC->GetGenericTeamId().GetId() != 0)
		{
			return;
		}
		FSquadAIMoveCommand MoveCommand;
		MoveCommand.Mode = ESquadAIMoveMode::QuestGoal;
		MoveCommand.GoalLocation = GoalLoc;
		MoveCommand.AcceptanceRadius = 500.f;
		MoveCommand.bAllowPartialPath = true;
		AIC->SetMoveCommand(MoveCommand);
	};

	int32 Pushed = 0;
	if (USoldierRegistrySubsystem* SR = World->GetSubsystem<USoldierRegistrySubsystem>())
	{
		for (const TWeakObjectPtr<ASoldierCharacter>& W : SR->GetAllSoldiers())
		{
			ASoldierCharacter* S = W.Get();
			if (!S)
			{
				continue;
			}
			if (ASoldierAIController* AIC = Cast<ASoldierAIController>(S->GetController()))
			{
				if (AIC->GetGenericTeamId().GetId() == 0)
				{
					PushAllyGoal(AIC);
					++Pushed;
				}
			}
		}
	}
	if (Pushed == 0)
	{
		for (TActorIterator<ASoldierAIController> It(World); It; ++It)
		{
			PushAllyGoal(*It);
		}
	}

	// S5-3: resolve a same-tagged template spawner for Defend completion, and snapshot
	// hostiles for Clear completion. (The registry holds one actor per tag, so scan.)
	if (ZoneTag.IsValid())
	{
		for (TActorIterator<AWaveSpawner> It(World); It; ++It)
		{
			if (*It && (*It)->ActorHasTag(ZoneTag.Tag))
			{
				CachedSpawner = *It;
				break;
			}
		}
	}
	OutsideTimer = 0.f;
	DefendTimer = 0.f;
	InitialHostileCount = CachedZone.IsValid() ? CachedZone->CountHostilesInZone() : 0;

	ResolveMode(World);
}

void UQuestObjective_AutoZone::Tick(float DeltaTime, UWorld* World)
{
	if (State != EObjectiveState::Active) return;
	
	UQuestRegistry* Reg = World->GetSubsystem<UQuestRegistry>();
	if (!Reg) return;

	const bool bPlayerInZone = CachedZone.IsValid() && CachedZone->IsPlayerInZone();

	// S5-3: modes beyond Reach finally behave (ResolveMode was hardcoded).
	switch (ResolvedMode)
	{
	case EObjectiveMode::Defend:
	{
		// Succeed: linked spawner cleared all waves, or survived the duration.
		if (CachedSpawner.IsValid() && CachedSpawner->AreAllWavesComplete())
		{
			State = EObjectiveState::Succeeded;
			return;
		}
		DefendTimer += DeltaTime;
		if (DefendTimer >= DefendDurationSeconds)
		{
			State = EObjectiveState::Succeeded;
			return;
		}
		// Fail: outside the zone too long (when a limit is set).
		if (bPlayerInZone == false && MaxSecondsOutsideZone >= 0.f)
		{
			OutsideTimer += DeltaTime;
			if (OutsideTimer >= MaxSecondsOutsideZone)
			{
				State = EObjectiveState::Failed;
				return;
			}
		}
		else
		{
			OutsideTimer = 0.f;
		}
		break;
	}
	case EObjectiveMode::Clear:
	{
		// Succeed when no hostiles remain. The age grace avoids instant-succeeding a
		// zone that simply starts empty (waves may still be inbound).
		DefendTimer += DeltaTime;
		const int32 Remaining = CachedZone.IsValid() ? CachedZone->CountHostilesInZone() : 0;
		if (Remaining <= 0 && (InitialHostileCount > 0 || DefendTimer > 5.f))
		{
			State = EObjectiveState::Succeeded;
			return;
		}
		break;
	}
	case EObjectiveMode::Reach:
	default:
	{
		if (bPlayerInZone)
		{
			State = EObjectiveState::Succeeded;
			return;
		}
		break;
	}
	}

	// Ally-arrival fallback is Reach-only (Defend/Clear have their own completion).
	if (ResolvedMode != EObjectiveMode::Reach) return;

	const FVector Goal = CachedZone.IsValid()
		? CachedZone->GetActorLocation()
		: Reg->CurrentActiveGoal;
	if (Goal.IsNearlyZero())
	{
		return;
	}

	// Fallback: allied squad arrival also counts. Distance to the zone, not GetEffectiveMoveGoal
	// (that would run spline/fire pathing on every objective tick).
	if (USoldierRegistrySubsystem* SR = World->GetSubsystem<USoldierRegistrySubsystem>())
	{
		for (const TWeakObjectPtr<ASoldierCharacter>& W : SR->GetAllSoldiers())
		{
			ASoldierCharacter* S = W.Get();
			if (!S || !S->IsAlive() || S->GetGenericTeamId().GetId() != 0)
			{
				continue;
			}
			if (FVector::Dist(S->GetActorLocation(), Goal) < 600.f)
			{
				State = EObjectiveState::Succeeded;
				break;
			}
		}
	}
}

void UQuestObjective_AutoZone::OnFinish() { Super::OnFinish(); }
void UQuestObjective_AutoZone::ResolveMode(UWorld*)
{
	// S5-3: was hardcoded Reach - honor the designer mode (Auto falls back to Reach).
	ResolvedMode = (Mode == EObjectiveMode::Auto) ? EObjectiveMode::Reach : Mode;
}

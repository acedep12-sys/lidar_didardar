// EscortTargetActor.cpp - S19-ESCORT
#include "Quest/EscortTargetActor.h"
#include "Actors/EnemyPatrolRoute.h"
#include "Components/HealthComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Diagnostics/SquadAISituationLog.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "GameFramework/Pawn.h"
#include "Kismet/GameplayStatics.h"
#include "UObject/ConstructorHelpers.h"

AEscortTargetActor::AEscortTargetActor()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 0.f; // a moving objective: no visible stepping

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SetRootComponent(SceneRoot);

	static ConstructorHelpers::FObjectFinder<UStaticMesh> CubeMesh(TEXT("/Engine/BasicShapes/Cube.Cube"));
	static ConstructorHelpers::FObjectFinder<UMaterialInterface> BaseMat(TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"));

	// A stand-in convoy body so the actor is visible while a level is being built; a
	// designer replaces this with the real truck/APC in a Blueprint child.
	ConvoyMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("ConvoyMesh"));
	ConvoyMesh->SetupAttachment(SceneRoot);
	if (CubeMesh.Succeeded()) ConvoyMesh->SetStaticMesh(CubeMesh.Object);
	if (BaseMat.Succeeded()) ConvoyMesh->SetMaterial(0, BaseMat.Object);
	ConvoyMesh->SetRelativeScale3D(FVector(1.2f, 2.6f, 0.9f));
	ConvoyMesh->SetRelativeLocation(FVector(0.f, 0.f, 45.f));
	// No collision at all: the convoy must never shove the player, the squad or an enemy
	// around, and it must never be pushed off its own route by them either.
	ConvoyMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	ConvoyMesh->SetCanEverAffectNavigation(false);
	ConvoyMesh->SetCastShadow(true);

	HealthComp = CreateDefaultSubobject<UHealthComponent>(TEXT("HealthComp"));
}

void AEscortTargetActor::BeginPlay()
{
	Super::BeginPlay();

	if (HealthComp)
	{
		HealthComp->MaxHealth = FMath::Max(1.f, MaxHealth);
		HealthComp->CurrentHealth = HealthComp->MaxHealth;
		HealthComp->bInvincible = !bCanBeWounded;
		HealthComp->OnDeath.RemoveDynamic(this, &AEscortTargetActor::OnEscortHealthDied);
		HealthComp->OnDeath.AddDynamic(this, &AEscortTargetActor::OnEscortHealthDied);
	}

	RefreshRoute();
}

void AEscortTargetActor::RefreshRoute()
{
	CachedPoints.Reset();
	CachedWaits.Reset();

	if (!Route)
	{
		if (!bRouteWarned)
		{
			bRouteWarned = true;
			UE_LOG(LogTemp, Warning,
				TEXT("[S19-ESCORT] %s has no Route - the convoy cannot move. Point 'Route' at an AEnemyPatrolRoute."),
				*GetName());
		}
		return;
	}

	const int32 Count = Route->GetPointCount();
	UWorld* World = GetWorld();
	for (int32 i = 0; i < Count; ++i)
	{
		FVector P = Route->GetPointLocation(i);

		// Ground each point once, here, rather than tracing every tick: the convoy walks a
		// straight line between grounded points, which is what keeps it on the terrain.
		if (World)
		{
			const FVector Start = P + FVector(0.f, 0.f, 1500.f);
			const FVector End = P - FVector(0.f, 0.f, 20000.f);
			FCollisionQueryParams Params(SCENE_QUERY_STAT(EscortGroundTrace), /*bTraceComplex=*/false, this);
			FHitResult Hit;
			if (World->LineTraceSingleByChannel(Hit, Start, End, ECC_Visibility, Params))
			{
				// 40 cm up: the convoy body hangs under this origin, so the origin rides at
				// roughly chassis height rather than in the dirt.
				P = Hit.ImpactPoint + FVector(0.f, 0.f, 40.f);
			}
		}
		CachedPoints.Add(P);
	}

	// Waits come from the route: a point's own value, else the route's default.
	const float RouteDefault = Route ? Route->DefaultPointWaitSeconds : 0.f;
	for (int32 i = 0; i < Count; ++i)
	{
		// The route actor stores per-point overrides; -1 means "use the default".
		const float PointWait = (Route && Route->Points.IsValidIndex(i)) ? Route->Points[i].WaitSeconds : -1.f;
		CachedWaits.Add(FEscortModel::ResolveWaitSeconds(PointWait, RouteDefault));
	}

	const float LengthM = FEscortModel::RouteLengthCm(CachedPoints) / 100.f;
	SquadAISituation::Note(FString::Printf(
		TEXT("ESCORT %s: route '%s' read - %d point(s), %.0f m, speed %.0f cm/s%s"),
		*GetName(), Route ? *Route->RouteName : TEXT("none"), CachedPoints.Num(), LengthM, MoveSpeedCmPerSec,
		bWaitForPlayer ? TEXT(", waiting for the player") : TEXT("")));
}

void AEscortTargetActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (bDead || bArrived)
	{
		return;
	}
	if (!HealthComp || !HealthComp->IsAlive())
	{
		return;
	}
	if (CachedPoints.Num() == 0)
	{
		// No usable route: nothing to walk. RefreshRoute already said so once; keep
		// re-reading cheaply in case the designer sets the route during PIE.
		RefreshRoute();
		return;
	}
	if (!CachedPoints.IsValidIndex(CurrentPointIndex))
	{
		// CurrentPointIndex >= NumPoints happens the moment the route is finished, which
		// is handled below via the arrival branch - this guards a route SHORTENED under us.
		CurrentPointIndex = FMath::Clamp(CurrentPointIndex, 0, CachedPoints.Num() - 1);
	}

	// ---- an immobilized (badly hurt) convoy goes nowhere ----
	const bool bImmobilized = ImmobilizedBelowHealthFraction > 0.f
		&& HealthComp->GetHealthPercent() < ImmobilizedBelowHealthFraction;

	// ---- the mercy leash ----
	float PlayerDistance = -1.f;
	bool bPlayerKnown = false;
	if (bWaitForPlayer)
	{
		if (const APawn* Player = UGameplayStatics::GetPlayerPawn(GetWorld(), 0))
		{
			PlayerDistance = FVector::Dist(GetActorLocation(), Player->GetActorLocation());
			bPlayerKnown = true;
		}
	}
	const bool bHoldNow = bPlayerKnown && FEscortModel::ShouldHoldForPlayer(
		bWaitForPlayer, bHoldingForPlayer, PlayerDistance, PlayerHaltRadiusCm, PlayerResumeRadiusCm);

	if (bHoldNow != bHoldingForPlayer)
	{
		bHoldingForPlayer = bHoldNow;
		OnEscortHoldChanged.Broadcast(this, bHoldingForPlayer);
		SquadAISituation::Note(FString::Printf(TEXT("ESCORT %s: %s (player %.0f m)"), *GetName(),
			bHoldingForPlayer ? TEXT("HALTED for the player") : TEXT("moving again"), PlayerDistance / 100.f));
	}

	const FVector Point = CachedPoints[CurrentPointIndex];
	const float ArriveRadius = FMath::Max(20.f, ArriveRadiusCm);
	const bool bAtPoint = FEscortModel::HasArrivedAt(GetActorLocation(), Point, ArriveRadius);

	// ---- pausing at a point ----
	if (bAtPoint && WaitRemaining > 0.f)
	{
		WaitRemaining = FMath::Max(0.f, WaitRemaining - DeltaTime);
		return;
	}

	// ---- arrive / finish ----
	const bool bLoop = Route ? Route->IsClosedLoop() : false;
	if (bAtPoint)
	{
		CurrentPointIndex = FEscortModel::AdvanceIndex(CurrentPointIndex, CachedPoints.Num(), bLoop);

		if (CurrentPointIndex >= CachedPoints.Num())
		{
			// ROUTE FINISHED.
			bArrived = true;
			Progress = 1.f;
			OnEscortProgress.Broadcast(this, Progress);
			SquadAISituation::Note(FString::Printf(
				TEXT("ESCORT %s: ARRIVED - '%s' is at the destination."), *GetName(), *EscortName.ToString()));
			OnEscortArrived.Broadcast(this);
			return;
		}

		// Stop here for this point's own pause before walking on.
		WaitRemaining = CachedWaits.IsValidIndex(CurrentPointIndex - 1) ? CachedWaits[CurrentPointIndex - 1] : 0.f;
		Progress = FEscortModel::Progress01(CurrentPointIndex, CachedPoints.Num());
		if (FMath::Abs(Progress - LastProgressBroadcast) > 0.005f)
		{
			LastProgressBroadcast = Progress;
			OnEscortProgress.Broadcast(this, Progress);
		}
		return; // one waypoint per frame at most: no double-advance on a big DeltaTime
	}

	if (bHoldNow || bImmobilized)
	{
		return; // waiting for the player / too hurt to drive
	}

	// ---- walk ----
	const FVector ToPoint = Point - GetActorLocation();
	const float Distance = ToPoint.Size();
	const float Step = FMath::Min(Distance, FMath::Max(10.f, MoveSpeedCmPerSec) * DeltaTime);
	if (Step > 0.f)
	{
		const FVector Dir = ToPoint / FMath::Max(Distance, KINDA_SMALL_NUMBER);
		// bSweep = true: the convoy slides along a wall instead of clipping through it.
		SetActorLocation(GetActorLocation() + Dir * Step, /*bSweep=*/true);
		if (bFaceMovementDirection)
		{
			const FRotator Facing = Dir.Rotation();
			SetActorRotation(FRotator(0.f, Facing.Yaw, 0.f));
		}
	}

	// ---- stuck detection: a convoy that stops making progress says so, once ----
	if (LastDistanceToNext >= 0.f && Distance > LastDistanceToNext - 1.f)
	{
		NoProgressSeconds += DeltaTime;
		if (NoProgressSeconds > 6.f && !bStuckWarned)
		{
			bStuckWarned = true;
			SquadAISituation::Note(FString::Printf(
				TEXT("ESCORT %s: no progress for %.0f s toward point %d/%d (%.0f m away) - something is in the way."),
				*GetName(), NoProgressSeconds, CurrentPointIndex + 1, CachedPoints.Num(), Distance / 100.f));
		}
	}
	else
	{
		NoProgressSeconds = 0.f;
	}
	LastDistanceToNext = Distance;
}

void AEscortTargetActor::OnEscortHealthDied(AActor* OwnerActor)
{
	if (bDead)
	{
		return;
	}
	bDead = true;
	SquadAISituation::Note(FString::Printf(
		TEXT("ESCORT %s: '%s' DESTROYED at point %d/%d."),
		*GetName(), *EscortName.ToString(), CurrentPointIndex, CachedPoints.Num()));
	OnEscortDied.Broadcast(this);
}

int32 AEscortTargetActor::GetPointsRemaining() const
{
	return FEscortModel::PointsRemaining(CurrentPointIndex, CachedPoints.Num());
}

float AEscortTargetActor::GetDistanceToNextPoint() const
{
	if (bArrived || !CachedPoints.IsValidIndex(CurrentPointIndex))
	{
		return -1.f;
	}
	return FVector::Dist(GetActorLocation(), CachedPoints[CurrentPointIndex]);
}

void AEscortTargetActor::ForceArrival()
{
	if (bArrived)
	{
		return;
	}
	CurrentPointIndex = CachedPoints.Num();
	bArrived = true;
	Progress = 1.f;
	OnEscortProgress.Broadcast(this, Progress);
	SquadAISituation::Note(FString::Printf(TEXT("ESCORT %s: arrival forced (debug)."), *GetName()));
	OnEscortArrived.Broadcast(this);
}

void AEscortTargetActor::ResetEscort()
{
	bDead = false;
	bArrived = false;
	bHoldingForPlayer = false;
	bStuckWarned = false;
	CurrentPointIndex = 0;
	WaitRemaining = 0.f;
	Progress = 0.f;
	LastProgressBroadcast = -1.f;
	NoProgressSeconds = 0.f;
	LastDistanceToNext = -1.f;

	if (HealthComp)
	{
		HealthComp->Revive();
		HealthComp->MaxHealth = FMath::Max(1.f, MaxHealth);
		HealthComp->CurrentHealth = HealthComp->MaxHealth;
		HealthComp->bInvincible = !bCanBeWounded;
	}
	RefreshRoute();
}

// ExtractionZoneActor.cpp - S19-EXFIL
#include "Quest/ExtractionZoneActor.h"
#include "Components/StaticMeshComponent.h"
#include "Diagnostics/SquadAISituationLog.h"
#include "Engine/World.h"
#include "GameFramework/Pawn.h"
#include "Kismet/GameplayStatics.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Quest/EnemyWaveSpawner.h"
#include "UObject/ConstructorHelpers.h"

AExtractionZoneActor::AExtractionZoneActor()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 0.f; // the hold clock is read by the player every frame

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SetRootComponent(SceneRoot);

	static ConstructorHelpers::FObjectFinder<UStaticMesh> CylMesh(TEXT("/Engine/BasicShapes/Cylinder.Cylinder"));
	static ConstructorHelpers::FObjectFinder<UMaterialInterface> BaseMat(TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"));

	// The pad itself. Drawn at 1.55x the server-side radius so the player can see the
	// edge he must stay inside, and hollow: no collision, so it can never trip anyone.
	PadDisc = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("PadDisc"));
	PadDisc->SetupAttachment(SceneRoot);
	if (CylMesh.Succeeded()) PadDisc->SetStaticMesh(CylMesh.Object);
	if (BaseMat.Succeeded()) PadDisc->SetMaterial(0, BaseMat.Object);
	PadDisc->SetRelativeScale3D(FVector(6.2f, 6.2f, 0.02f));
	PadDisc->SetRelativeLocation(FVector(0.f, 0.f, 3.f));
	PadDisc->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	PadDisc->SetCanEverAffectNavigation(false);
	PadDisc->SetCastShadow(false);
	PadDisc->SetVisibility(false); // dormant until armed
}

void AExtractionZoneActor::BeginPlay()
{
	Super::BeginPlay();

	if (PadDisc)
	{
		PadMID = PadDisc->CreateAndSetMaterialInstanceDynamic(0);
	}

	HoldSecondsAccum = 0.f;
	LastBroadcastProgress = -1.f;
	HoldProgress01 = 0.f;
	HoldRemainingSeconds = FMath::Max(0.f, HoldSeconds);
	ExtractionState = EExtractionState::Dormant;
	if (PadDisc)
	{
		PadDisc->SetVisibility(bStartArmed);
	}
	if (bStartArmed)
	{
		ArmExtraction();
	}
}

void AExtractionZoneActor::SetState(EExtractionState NewState)
{
	if (ExtractionState == NewState)
	{
		return;
	}
	ExtractionState = NewState;
}

void AExtractionZoneActor::ArmExtraction()
{
	if (ExtractionState == EExtractionState::Ready || ExtractionState == EExtractionState::Holding
		|| ExtractionState == EExtractionState::Active)
	{
		return; // already armed: arming twice must not restart the hold
	}
	SetState(EExtractionState::Active);
	HoldSecondsAccum = 0.f;
	HoldProgress01 = 0.f;
	HoldRemainingSeconds = FMath::Max(0.f, HoldSeconds);
	if (PadDisc)
	{
		PadDisc->SetVisibility(true);
	}
	SquadAISituation::Note(FString::Printf(
		TEXT("EXFIL %s: '%s' ARMED - hold the pad %.0f s (radius %.0f m)."),
		*GetName(), *CallSign.ToString(), HoldSeconds, HoldRadiusCm / 100.f));
	OnExtractionArmed.Broadcast(this);
}

void AExtractionZoneActor::NotifySmokeMarker(const FVector& MarkerLocation)
{
	if (!bArmOnSmokeGrenade || ExtractionState != EExtractionState::Dormant)
	{
		return;
	}
	const float DistSq = FVector::DistSquared2D(MarkerLocation, GetActorLocation());
	if (DistSq > SmokeCallRadiusCm * SmokeCallRadiusCm)
	{
		return; // smoke somewhere else on the map: not this pad's call
	}
	SquadAISituation::Note(FString::Printf(
		TEXT("EXFIL %s: smoke marker %.0f m from the pad - extraction called."),
		*GetName(), FMath::Sqrt(DistSq) / 100.f));
	ArmExtraction();
}

void AExtractionZoneActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (ExtractionState == EExtractionState::Dormant || ExtractionState == EExtractionState::Ready)
	{
		return;
	}

	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}

	// Is the player on the pad? Same 2D test as every other hold in the module, with a
	// vertical window so a pad under a bridge is not held from the road above.
	bool bPlayerOnPad = false;
	if (const APawn* Player = UGameplayStatics::GetPlayerPawn(World, 0))
	{
		const FVector PlayerLoc = Player->GetActorLocation();
		const FVector Here = GetActorLocation();
		bPlayerOnPad = FVector::DistSquared2D(PlayerLoc, Here) <= HoldRadiusCm * HoldRadiusCm
			&& FMath::Abs(PlayerLoc.Z - Here.Z) < 500.f;
	}

	if (bPlayerOnPad && ExtractionState == EExtractionState::Active)
	{
		SetState(EExtractionState::Holding);
		StartHoldPressure();
		SquadAISituation::Note(FString::Printf(TEXT("EXFIL %s: hold started - %.0f s to go."),
			*GetName(), FMath::Max(0.f, HoldSeconds - HoldSecondsAccum)));
	}

	if (bPlayerOnPad)
	{
		HoldSecondsAccum = FMath::Min(HoldSeconds, HoldSecondsAccum + FMath::Max(0.f, DeltaTime));
	}
	else if (HoldProgressDecayRate > 0.f)
	{
		HoldSecondsAccum = FMath::Max(0.f, HoldSecondsAccum - FMath::Max(0.f, DeltaTime) * HoldProgressDecayRate);
	}

	HoldRemainingSeconds = FMath::Max(0.f, HoldSeconds - HoldSecondsAccum);
	HoldProgress01 = (HoldSeconds > KINDA_SMALL_NUMBER)
		? FMath::Clamp(HoldSecondsAccum / HoldSeconds, 0.f, 1.f) : 1.f;
	if (FMath::Abs(HoldProgress01 - LastBroadcastProgress) > 0.005f)
	{
		LastBroadcastProgress = HoldProgress01;
		OnExtractionHoldProgress.Broadcast(this, HoldProgress01);
	}

	// Pad colour: amber while armed, pulsing cyan while held, steady green when ready.
	if (ExtractionState == EExtractionState::Holding)
	{
		const float Pulse = 0.5f + 0.5f * FMath::Sin(World->GetTimeSeconds() * 5.f);
		SetPadColor(FLinearColor(0.10f, 0.55f + 0.35f * Pulse, 0.90f));
	}
	else
	{
		SetPadColor(FLinearColor(1.0f, 0.62f, 0.10f));
	}

	if (HoldSecondsAccum >= HoldSeconds)
	{
		ForceReady();
	}
}

void AExtractionZoneActor::ForceReady()
{
	if (ExtractionState == EExtractionState::Ready)
	{
		return;
	}
	SetState(EExtractionState::Ready);
	HoldProgress01 = 1.f;
	HoldRemainingSeconds = 0.f;
	SetPadColor(FLinearColor(0.10f, 0.90f, 0.35f));
	OnExtractionHoldProgress.Broadcast(this, 1.f);
	if (bDeactivateSpawnersOnReady)
	{
		StopHoldPressure();
	}
	SquadAISituation::Note(FString::Printf(TEXT("EXFIL %s: '%s' READY - the mission can end."),
		*GetName(), *CallSign.ToString()));
	OnExtractionReady.Broadcast(this);
}

void AExtractionZoneActor::StartHoldPressure()
{
	for (const TObjectPtr<AEnemyWaveSpawner>& S : HoldSpawners)
	{
		if (S && !S->bCompleted)
		{
			S->ActivateSpawner();
		}
	}
}

void AExtractionZoneActor::StopHoldPressure()
{
	for (const TObjectPtr<AEnemyWaveSpawner>& S : HoldSpawners)
	{
		if (S)
		{
			S->DeactivateSpawner();
		}
	}
}

void AExtractionZoneActor::ResetExtraction()
{
	SetState(EExtractionState::Dormant);
	HoldSecondsAccum = 0.f;
	HoldProgress01 = 0.f;
	HoldRemainingSeconds = FMath::Max(0.f, HoldSeconds);
	LastBroadcastProgress = -1.f;
	StopHoldPressure();
	if (PadDisc)
	{
		PadDisc->SetVisibility(bStartArmed);
	}
	// A standalone pad (`bStartArmed`) is armed again immediately: a mission zone that
	// BINDS this pad must not silently cancel the arming the designer asked for.
	if (bStartArmed)
	{
		ArmExtraction();
	}
}

void AExtractionZoneActor::SetPadColor(const FLinearColor& C)
{
	if (PadMID)
	{
		PadMID->SetVectorParameterValue(TEXT("Color"), C);
	}
}

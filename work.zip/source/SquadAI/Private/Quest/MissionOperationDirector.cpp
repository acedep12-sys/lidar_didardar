// MissionOperationDirector.cpp - S19-OP: the sequencer; the policy is OperationModel.h.

#include "Quest/MissionOperationDirector.h"

#include "BlueprintLibraries/SquadAIAutoSetupEditorLibrary.h"
#include "Quest/MissionArchetypeModel.h"
#include "Quest/MissionTemplateAsset.h"
#include "Quest/MissionZone.h"
#include "Engine/World.h"
#include "TimerManager.h"

AMissionOperationDirector::AMissionOperationDirector()
{
	PrimaryActorTick.bCanEverTick = false;
	ResetRun();
}

void AMissionOperationDirector::ResetRun()
{
	CurrentStepIndex = -1;
	bOperationActive = false;
	bOperationFailed = false;
	OperationReport.Reset();
	CompletedSteps = 0;
	FailedSteps = 0;
	TotalScore = 0;
	LiveZone.Reset();
	for (int32 i = 0; i < MaxSteps; ++i)
	{
		StepStates[i] = EOperationStepState::Pending;
		RetriesUsed[i] = 0;
		StepScores[i] = 0;
		StepPars[i] = 0;
	}
}

float AMissionOperationDirector::GetOperationProgress() const
{
	const int32 Total = FMath::Min(Steps.Num(), MaxSteps);
	return FMissionOperationModel::Progress01(CompletedSteps, Total);
}

void AMissionOperationDirector::StartOperation()
{
	if (bOperationActive)
	{
		UE_LOG(LogTemp, Warning, TEXT("[SquadAIOperation] Start ignored - an operation is already running."));
		return;
	}
	if (Steps.Num() == 0)
	{
		UE_LOG(LogTemp, Warning, TEXT("[SquadAIOperation] Start ignored - no steps configured."));
		return;
	}
	if (Steps.Num() > MaxSteps)
	{
		UE_LOG(LogTemp, Warning, TEXT("[SquadAIOperation] %d steps configured but the cap is %d - the rest are refused."),
			Steps.Num(), MaxSteps);
	}

	ResetRun();
	bOperationActive = true;

	UE_LOG(LogTemp, Warning, TEXT("[SquadAIOperation] Operation start: %d step(s)."), FMath::Min(Steps.Num(), MaxSteps));
	StampStep(0);
}

void AMissionOperationDirector::AbortOperation()
{
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(NextStepTimerHandle);
	}
	UnbindLiveZone();
	bOperationActive = false;
	UE_LOG(LogTemp, Warning, TEXT("[SquadAIOperation] Operation aborted at step %d."), CurrentStepIndex + 1);
}

void AMissionOperationDirector::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	AbortOperation();
	Super::EndPlay(EndPlayReason);
}

FVector AMissionOperationDirector::LocationForStep(int32 StepIndex, bool bRetry) const
{
	if (StepLocations.IsValidIndex(StepIndex))
	{
		return bRetry ? StepLocations[StepIndex] + FVector(1500.f, 0.f, 0.f) : StepLocations[StepIndex];
	}
	// The deterministic ring: 40 m steps around this actor, the same every run.
	const TArray<FVector> Ring = FMissionArchetypeModel::PropRingOffsets(
		FMath::Min(Steps.Num(), MaxSteps), 4000.f, 0.f, 360.f);
	const FVector Base = GetActorLocation()
		+ (Ring.IsValidIndex(StepIndex) ? Ring[StepIndex] : FVector::ZeroVector);
	// A retry re-stamps 15 m along +X so the new props never land on the old ones.
	return bRetry ? Base + FVector(1500.f, 0.f, 0.f) : Base;
}

void AMissionOperationDirector::StampStep(int32 StepIndex)
{
	if (!Steps.IsValidIndex(StepIndex) || StepIndex >= MaxSteps)
	{
		FinishStep(FMath::Max(0, StepIndex), false);   // a missing template cannot pass
		return;
	}
	UMissionTemplateAsset* Template = Steps[StepIndex];
	if (!Template)
	{
		UE_LOG(LogTemp, Warning, TEXT("[SquadAIOperation] Step %d has no template - the operation fails there."), StepIndex + 1);
		FinishStep(StepIndex, false);
		return;
	}

	const bool bRetry = (StepStates[StepIndex] == EOperationStepState::RetryQueued);
	const FVector Origin = LocationForStep(StepIndex, bRetry);

	FString Report;
	AMissionZone* Zone = USquadAIAutoSetupEditorLibrary::BuildMissionFromTemplate_GetZone(
		GetWorld(), Template, Origin, GetActorRotation(), /*bAppendToQuestChain=*/false, &Report);
	UE_LOG(LogTemp, Warning, TEXT("[SquadAIOperation] Step %d:%s"), StepIndex + 1, *Report);

	if (!Zone)
	{
		UE_LOG(LogTemp, Warning, TEXT("[SquadAIOperation] Step %d failed to stamp - the operation fails there."), StepIndex + 1);
		FinishStep(StepIndex, false);
		return;
	}

	// S19-OP: the director owns the step outright - no quest chain, no other binder.
	UnbindLiveZone();
	LiveZone = Zone;
	Zone->OnMissionStateChanged.AddDynamic(this, &AMissionOperationDirector::HandleZoneStateChanged);

	CurrentStepIndex = StepIndex;
	StepStates[StepIndex] = EOperationStepState::Live;
}

void AMissionOperationDirector::HandleZoneStateChanged(AMissionZone* Zone, EMissionZoneState NewState)
{
	if (!bOperationActive || !Zone || Zone != LiveZone.Get())
	{
		return;   // a stale or foreign zone's state is not ours to act on
	}

	if (NewState == EMissionZoneState::Completed)
	{
		FinishStep(CurrentStepIndex, true);
	}
	else if (NewState == EMissionZoneState::Failed)
	{
		FinishStep(CurrentStepIndex, false);
	}
	// Locked (a silent load reset) leaves the step live by design - nothing else to do.
}

void AMissionOperationDirector::FinishStep(int32 StepIndex, bool bSucceeded)
{
	UnbindLiveZone();

	// Bank the attempt's score and par before anything else (a retry replaces both).
	if (AMissionZone* Zone = LiveZone.Get())
	{
		StepScores[StepIndex] = Zone->GetMissionScore();
		StepPars[StepIndex] = Zone->GetMissionParScore();
		if (!bSucceeded && bRetryFailedSteps)
		{
			// Deep-review fix B2: destroying the zone alone left every factory-spawned
			// prop alive - and an orphaned interdiction director kept spawning couriers
			// forever while the fresh attempt stamped a duplicate set next door.
			Zone->DestroyFactorySpawnedActors();
			Zone->Destroy();   // the fresh attempt re-stamps; the failed zone never lingers
		}
	}
	TotalScore += StepScores[StepIndex];
	LiveZone.Reset();

	if (bSucceeded)
	{
		StepStates[StepIndex] = EOperationStepState::Completed;
		++CompletedSteps;
		UE_LOG(LogTemp, Warning, TEXT("[SquadAIOperation] Step %d complete (score %d, %d/%d)."),
			StepIndex + 1, StepScores[StepIndex], CompletedSteps, FMath::Min(Steps.Num(), MaxSteps));
	}
	else
	{
		const EOperationStepState Resolved = FMissionOperationModel::ResolveFailedStep(
			bRetryFailedSteps, MaxStepRetries, RetriesUsed[StepIndex]);
		StepStates[StepIndex] = Resolved;
		if (Resolved == EOperationStepState::RetryQueued)
		{
			++RetriesUsed[StepIndex];
			TotalScore -= StepScores[StepIndex];   // the retry's score replaces this attempt's
			StepScores[StepIndex] = 0;
			StepPars[StepIndex] = 0;
			UE_LOG(LogTemp, Warning, TEXT("[SquadAIOperation] Step %d failed - retry %d/%d."),
				StepIndex + 1, RetriesUsed[StepIndex], MaxStepRetries);
		}
		else
		{
			++FailedSteps;
		}
	}

	// -- what does the model say comes next? -------------------------------------
	if (FMissionOperationModel::IsOperationOver(StepStates[StepIndex]))
	{
		bOperationActive = false;
		bOperationFailed = true;
		OperationReport = FString::Printf(TEXT("Operation failed at step %d - %d step%s completed, score %d."),
			StepIndex + 1, CompletedSteps, CompletedSteps == 1 ? TEXT("") : TEXT("s"), TotalScore);
		UE_LOG(LogTemp, Warning, TEXT("[SquadAIOperation] %s"), *OperationReport);
		return;
	}

	const int32 NextIndex = FMissionOperationModel::NextStepIndex(StepIndex, StepStates[StepIndex]);
	if (NextIndex >= FMath::Min(Steps.Num(), MaxSteps))
	{
		// -- the debrief: the worst step's grade, over real pars -----------------------
		bOperationActive = false;
		TArray<EMissionGrade> Grades;
		for (int32 i = 0; i < NextIndex; ++i)
		{
			if (StepStates[i] == EOperationStepState::Completed)
			{
				Grades.Add(FMissionScoreModel::GradeFor(StepScores[i], FMath::Max(1, StepPars[i])));
			}
		}
		const EMissionGrade Grade = FMissionOperationModel::OperationGrade(Grades, FailedSteps);
		OperationReport = FMissionOperationModel::ReportLine(CompletedSteps, FailedSteps, TotalScore, Grade);
		UE_LOG(LogTemp, Warning, TEXT("[SquadAIOperation] %s"), *OperationReport);
		return;
	}

	if (UWorld* World = GetWorld())
	{
		FTimerDelegate Del;
		Del.BindWeakLambda(this, [this, NextIndex]()
		{
			if (bOperationActive)
			{
				StampStep(NextIndex);
			}
		});
		World->GetTimerManager().SetTimer(NextStepTimerHandle, Del,
			FMath::Max(0.f, NextStepDelaySeconds), false);
	}
}

void AMissionOperationDirector::UnbindLiveZone()
{
	// S19-OP: one binder at a time, and every bind site shares this one remove site.
	if (AMissionZone* Zone = LiveZone.Get())
	{
		Zone->OnMissionStateChanged.RemoveDynamic(this, &AMissionOperationDirector::HandleZoneStateChanged);
	}
}

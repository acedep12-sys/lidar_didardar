// QuestTickerSubsystem.cpp — 4Hz timer for active missions only
#include "Quest/QuestTickerSubsystem.h"
#include "Quest/QuestDirector.h"
#include "Quest/QuestMission.h"
#include "SquadAITuning.h"
#include "EngineUtils.h"
#include "Engine/World.h"
#include "TimerManager.h"

void UQuestTickerSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
	bQuestMapConfirmed = false;
	bQuestMapEnabled = false;
}

void UQuestTickerSubsystem::Deinitialize()
{
	StopMissionTimer();
	Super::Deinitialize();
}

bool UQuestTickerSubsystem::IsTickable() const
{
	// After we know whether this map uses quests, never sit on the tickable list.
	return !bQuestMapConfirmed;
}

void UQuestTickerSubsystem::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (!bQuestMapConfirmed)
	{
		FindDirector();
	}
}

void UQuestTickerSubsystem::FindDirector()
{
	AQuestDirector* FoundDirector = nullptr;
	for (TActorIterator<AQuestDirector> It(GetWorld()); It; ++It)
	{
		FoundDirector = *It;
		break;
	}

	bQuestMapConfirmed = true;
	bQuestMapEnabled = (FoundDirector != nullptr);
	Director = FoundDirector;
	if (bQuestMapEnabled)
	{
		EnsureMissionTimer();
	}
	else
	{
		StopMissionTimer();
	}
}

void UQuestTickerSubsystem::SetDirector(AQuestDirector* Dir)
{
	Director = Dir;
	bQuestMapConfirmed = true;
	bQuestMapEnabled = (Dir != nullptr);
	if (bQuestMapEnabled)
	{
		EnsureMissionTimer();
	}
	else
	{
		StopMissionTimer();
	}
}

void UQuestTickerSubsystem::EnsureMissionTimer()
{
	UWorld* World = GetWorld();
	if (!World || World->GetTimerManager().IsTimerActive(MissionTimer))
	{
		return;
	}
	World->GetTimerManager().SetTimer(MissionTimer, this, &UQuestTickerSubsystem::RunMissionTick, 0.25f, true);
}

void UQuestTickerSubsystem::StopMissionTimer()
{
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(MissionTimer);
	}
}

void UQuestTickerSubsystem::RunMissionTick()
{
	if (!Director.IsValid())
	{
		return;
	}

	AQuestMission* Current = Director->GetCurrentMission();
	if (!Current || Current->MissionState != EMissionState::Active)
	{
		return;
	}

	Current->TickMission(0.25f);
	BroadcastHUD(Current);

	if (Current->MissionState == EMissionState::Succeeded)
	{
		Director->OnMissionCompleted(Current);
	}
	else if (Current->MissionState == EMissionState::Failed)
	{
		// S5-4: failures used to stall the director forever — advance past them.
		Director->OnMissionFailed(Current);
	}
}

void UQuestTickerSubsystem::BroadcastHUD(AQuestMission* Mission)
{
	if (!Mission) return;

	FQuestHudSnapshot Snap = Mission->GetHudSnapshot();
	OnHudUpdated.Broadcast(Snap);
}

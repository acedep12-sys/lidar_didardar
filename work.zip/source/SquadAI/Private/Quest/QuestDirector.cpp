// QuestDirector.cpp — Auto-discovers missions, chains by Order integer
#include "Quest/QuestDirector.h"
#include "SquadTypes.h"
#include "Quest/QuestMission.h"
#include "Quest/QuestLog.h"
#include "EngineUtils.h"
#include "Engine/GameInstance.h"

AQuestDirector::AQuestDirector()
{
	PrimaryActorTick.bCanEverTick = false;
}

void AQuestDirector::BeginPlay()
{
	Super::BeginPlay();
	CollectMissions();

	if (bAutoStart && Missions.Num() > 0)
	{
		// Slight delay for level to finish loading
		FTimerHandle Handle;
		GetWorldTimerManager().SetTimer(Handle, this,
			&AQuestDirector::StartFirstMission, 1.f, false);
	}
}

void AQuestDirector::CollectMissions()
{
	Missions.Empty();

	if (bUseOutlinerHierarchy)
	{
		// Only pick up missions attached to us in the Outliner
		TArray<AActor*> AttachedChildren;
		GetAttachedActors(AttachedChildren, true);
		for (AActor* Child : AttachedChildren)
		{
			if (AQuestMission* M = Cast<AQuestMission>(Child))
			{
				Missions.Add(M);
			}
		}
	}
	else
	{
		// Find ALL missions in the level
		for (TActorIterator<AQuestMission> It(GetWorld()); It; ++It)
		{
			Missions.Add(*It);
		}
	}

	// Sort by Order (stable sort preserves Outliner order for same-Order missions)
	Missions.StableSort([](AQuestMission& A, AQuestMission& B) {
		return A.Order < B.Order;
	});

	UE_LOG(LogSquadAI, Log, TEXT("QuestDirector: found %d missions"), Missions.Num());
}

void AQuestDirector::StartFirstMission()
{
	if (Missions.Num() == 0) return;

	CurrentMissionIndex = 0;
	Missions[0]->StartMission();
}

void AQuestDirector::OnMissionCompleted(AQuestMission* Mission)
{
	RecordMissionToLog(Mission);
	AdvanceToNextMission();
}

void AQuestDirector::OnMissionFailed(AQuestMission* Mission)
{
	UE_LOG(LogSquadAI, Warning, TEXT("QuestDirector: mission '%s' FAILED — advancing"),
		Mission ? *Mission->MissionTitle.ToString() : TEXT("<null>"));
	RecordMissionToLog(Mission);
	AdvanceToNextMission();
}

void AQuestDirector::RecordMissionToLog(AQuestMission* Mission)
{
	// S5-5: RecordMission had zero callers — history + save bytes were always empty.
	if (!Mission || !GetWorld()) return;
	if (UGameInstance* GameInstance = GetGameInstance())
	{
		if (UQuestLogSubsystem* Log = GameInstance->GetSubsystem<UQuestLogSubsystem>())
		{
			Log->RecordMission(Mission->MissionTitle, Mission->Order, Mission->MissionState, Mission->ElapsedTime);
		}
	}
}

void AQuestDirector::AdvanceToNextMission()
{
	CurrentMissionIndex++;

	if (CurrentMissionIndex >= Missions.Num())
	{
		UE_LOG(LogSquadAI, Log, TEXT("QuestDirector: all missions complete!"));
		return;
	}

	// Brief delay between missions
	FTimerHandle Handle;
	const int32 NextIdx = CurrentMissionIndex;
	TWeakObjectPtr<AQuestDirector> WeakThis(this);
	GetWorldTimerManager().SetTimer(Handle, [WeakThis, NextIdx]()
	{
		if (WeakThis.IsValid() && NextIdx < WeakThis->Missions.Num() && WeakThis->Missions[NextIdx])
		{
			WeakThis->Missions[NextIdx]->StartMission();
		}
	}, 3.f, false);
}

AQuestMission* AQuestDirector::GetCurrentMission() const
{
	if (CurrentMissionIndex >= 0 && CurrentMissionIndex < Missions.Num())
	{
		return Missions[CurrentMissionIndex];
	}
	return nullptr;
}

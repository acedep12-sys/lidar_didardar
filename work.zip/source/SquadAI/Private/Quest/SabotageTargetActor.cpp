// SabotageTargetActor.cpp — S17-SAB
#include "Quest/SabotageTargetActor.h"
#include "Components/StaticMeshComponent.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Performance/SquadAIAudioSubsystem.h"
#include "Actors/SquadAIAudioManager.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/World.h"
#include "GameFramework/Pawn.h"
#include "Perception/AISense_Hearing.h"
#include "UObject/ConstructorHelpers.h"

ASabotageTargetActor::ASabotageTargetActor()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 0.f;

	USceneComponent* SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SetRootComponent(SceneRoot);

	static ConstructorHelpers::FObjectFinder<UStaticMesh> CylMesh(TEXT("/Engine/BasicShapes/Cylinder.Cylinder"));
	static ConstructorHelpers::FObjectFinder<UStaticMesh> CubeMesh(TEXT("/Engine/BasicShapes/Cube.Cube"));
	static ConstructorHelpers::FObjectFinder<UMaterialInterface> BaseMat(TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"));

	// Painted target disc on the ground — tells the player WHERE to plant.
	MarkerDisc = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("MarkerDisc"));
	MarkerDisc->SetupAttachment(SceneRoot);
	if (CylMesh.Succeeded()) MarkerDisc->SetStaticMesh(CylMesh.Object);
	if (BaseMat.Succeeded()) MarkerDisc->SetMaterial(0, BaseMat.Object);
	MarkerDisc->SetRelativeScale3D(FVector(1.3f, 1.3f, 0.03f));
	MarkerDisc->SetRelativeLocation(FVector(0.f, 0.f, 2.f));
	MarkerDisc->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	MarkerDisc->SetCanEverAffectNavigation(false);
	MarkerDisc->SetCastShadow(false);

	// The satchel charge itself — hidden until planted.
	ChargeMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("ChargeMesh"));
	ChargeMesh->SetupAttachment(SceneRoot);
	if (CubeMesh.Succeeded()) ChargeMesh->SetStaticMesh(CubeMesh.Object);
	if (BaseMat.Succeeded()) ChargeMesh->SetMaterial(0, BaseMat.Object);
	ChargeMesh->SetRelativeScale3D(FVector(0.30f, 0.20f, 0.12f));
	ChargeMesh->SetRelativeLocation(FVector(0.f, 0.f, 8.f));
	ChargeMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	ChargeMesh->SetCanEverAffectNavigation(false);
	ChargeMesh->SetCastShadow(false);
	ChargeMesh->SetVisibility(false);
}

void ASabotageTargetActor::BeginPlay()
{
	Super::BeginPlay();
	if (MarkerDisc && MarkerDisc->GetMaterial(0))
	{
		MarkerMID = MarkerDisc->CreateAndSetMaterialInstanceDynamic(0);
	}
	if (ChargeMesh && ChargeMesh->GetMaterial(0))
	{
		if (UMaterialInstanceDynamic* ChargeMID = ChargeMesh->CreateAndSetMaterialInstanceDynamic(0))
		{
			ChargeMID->SetVectorParameterValue(TEXT("Color"), FLinearColor(0.16f, 0.17f, 0.11f)); // olive satchel
		}
	}
	SetMarkerColor(FLinearColor(1.f, 0.45f, 0.05f));
}

void ASabotageTargetActor::SetMarkerColor(const FLinearColor& C)
{
	if (MarkerMID)
	{
		MarkerMID->SetVectorParameterValue(TEXT("Color"), C);
	}
}

void ASabotageTargetActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	UWorld* World = GetWorld();
	if (!World) return;
	const float Now = World->GetTimeSeconds();

	switch (State)
	{
	case ESabotageState::Idle:
	case ESabotageState::Planting:
	{
		// Proximity plant: hold position near the marker.
		bool bPlayerClose = false;
		if (APawn* P = UGameplayStatics::GetPlayerPawn(World, 0))
		{
			const FVector PL = P->GetActorLocation();
			bPlayerClose = FVector::DistSquared2D(PL, GetActorLocation()) <= PlantRadius * PlantRadius
				&& FMath::Abs(PL.Z - GetActorLocation().Z) < 350.f;
		}
		if (bPlayerClose)
		{
			if (State == ESabotageState::Idle)
			{
				State = ESabotageState::Planting;
				UE_LOG(LogTemp, Warning, TEXT("[Sabotage] %s: planting charge... hold position %.1f s"), *GetName(), PlantTime);
			}
			PlantProgress += DeltaTime;
			OnPlantProgress.Broadcast(this, FMath::Clamp(PlantProgress / PlantTime, 0.f, 1.f));
			if (PlantProgress >= PlantTime)
			{
				State = ESabotageState::Armed;
				FuseRemaining = FuseTime;
				if (ChargeMesh) ChargeMesh->SetVisibility(true);
				UE_LOG(LogTemp, Warning, TEXT("[Sabotage] %s: CHARGE PLANTED — fuse %.0f s, GET CLEAR!"), *GetName(), FuseTime);
			}
		}
		else if (PlantProgress > 0.f)
		{
			PlantProgress = FMath::Max(0.f, PlantProgress - DeltaTime * 1.5f);
			OnPlantProgress.Broadcast(this, FMath::Clamp(PlantProgress / PlantTime, 0.f, 1.f));
			if (PlantProgress <= 0.f && State == ESabotageState::Planting)
			{
				State = ESabotageState::Idle;
			}
		}
		// Marker pulse: slow amber idle, fast bright while planting.
		const float Speed = (State == ESabotageState::Planting) ? 7.f : 2.5f;
		const float Pulse = 0.45f + 0.55f * (0.5f + 0.5f * FMath::Sin(Now * Speed));
		SetMarkerColor(FLinearColor(1.f * Pulse, 0.45f * Pulse, 0.05f * Pulse));
		break;
	}
	case ESabotageState::Armed:
	{
		FuseRemaining -= DeltaTime;
		// Urgent red strobe, accelerating as the fuse runs out.
		const float Urgency = FMath::Clamp(1.f - FuseRemaining / FMath::Max(1.f, FuseTime), 0.f, 1.f);
		const float Pulse = 0.5f + 0.5f * FMath::Sin(Now * (6.f + Urgency * 14.f));
		SetMarkerColor(FLinearColor(0.9f + 0.1f * Pulse, 0.06f * Pulse, 0.02f));
		if (FuseRemaining <= 0.f)
		{
			Detonate();
		}
		break;
	}
	case ESabotageState::Detonated:
	default:
		break;
	}
}

void ASabotageTargetActor::Detonate()
{
	if (State == ESabotageState::Detonated) return;
	State = ESabotageState::Detonated;

	UWorld* World = GetWorld();
	if (!World) return;
	const FVector BlastLoc = GetActorLocation();

	if (MarkerDisc) MarkerDisc->SetVisibility(false);
	if (ChargeMesh) ChargeMesh->SetVisibility(false);
	SetActorTickEnabled(false);

	// Same recipe as the explosive barrel (proven): AI hearing + radial falloff.
	// Nearby ExplosiveBarrelActors chain-react and provide the big fireball.
	TArray<AActor*> IgnoreActors;
	IgnoreActors.Add(this);
	UAISense_Hearing::ReportNoiseEvent(World, BlastLoc, 1.0f, nullptr, 6500.0, FName(TEXT("Explosion")));
	UGameplayStatics::ApplyRadialDamageWithFalloff(
		World,
		ExplosionDamage,
		ExplosionDamage * 0.25f,
		BlastLoc,
		ExplosionRadius * 0.4f,
		ExplosionRadius,
		1.0f,
		UDamageType::StaticClass(),
		IgnoreActors,
		this,
		nullptr,
		ECC_Visibility);

	USoundBase* Snd = ExplosionSound;
	if (!Snd)
	{
		if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
		{
			if (ASquadAIAudioManager* Mgr = AudioSys->GetActiveAudioManager())
			{
				Snd = Mgr->MediumExplosionCloseSound.Get();
			}
		}
	}
	if (Snd)
	{
		UGameplayStatics::PlaySoundAtLocation(World, Snd, BlastLoc, 1.4f);
	}

	UE_LOG(LogTemp, Warning, TEXT("[Sabotage] %s: DETONATED."), *GetName());
	OnDetonated.Broadcast(this);
	// Actor intentionally NOT destroyed — the mission zone reads its state.
}

void ASabotageTargetActor::ResetTarget()
{
	State = ESabotageState::Idle;
	PlantProgress = 0.f;
	FuseRemaining = 0.f;
	if (MarkerDisc) MarkerDisc->SetVisibility(true);
	if (ChargeMesh) ChargeMesh->SetVisibility(false);
	SetMarkerColor(FLinearColor(1.f, 0.45f, 0.05f));
	SetActorTickEnabled(true);
}

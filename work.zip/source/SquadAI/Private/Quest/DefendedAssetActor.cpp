// DefendedAssetActor.cpp - S19-ASSET: sappers, condition colours, one death event.

#include "Quest/DefendedAssetActor.h"

#include "Characters/SoldierCharacter.h"
#include "Components/HealthComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "GameFramework/Pawn.h"

ADefendedAssetActor::ADefendedAssetActor()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 0.25f;   // sapper damage is a slow burn

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SetRootComponent(SceneRoot);

	static ConstructorHelpers::FObjectFinder<UStaticMesh> CubeMesh(TEXT("/Engine/BasicShapes/Cube.Cube"));
	static ConstructorHelpers::FObjectFinder<UStaticMesh> CylMesh(TEXT("/Engine/BasicShapes/Cylinder.Cylinder"));
	static ConstructorHelpers::FObjectFinder<UMaterialInterface> BaseMat(TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"));

	// The body: a chunky crate-sized block with no collision of its own (it must not
	// block the fights that happen around it - the sapper rule is what threatens it).
	AssetMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("AssetMesh"));
	AssetMesh->SetupAttachment(SceneRoot);
	if (CubeMesh.Succeeded()) AssetMesh->SetStaticMesh(CubeMesh.Object);
	if (BaseMat.Succeeded()) AssetMesh->SetMaterial(0, BaseMat.Object);
	AssetMesh->SetRelativeScale3D(FVector(2.0f, 2.0f, 1.6f));
	AssetMesh->SetRelativeLocation(FVector(0.f, 0.f, 80.f));
	AssetMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	AssetMesh->SetCanEverAffectNavigation(false);

	MarkerDisc = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("MarkerDisc"));
	MarkerDisc->SetupAttachment(SceneRoot);
	if (CylMesh.Succeeded()) MarkerDisc->SetStaticMesh(CylMesh.Object);
	if (BaseMat.Succeeded()) MarkerDisc->SetMaterial(0, BaseMat.Object);
	MarkerDisc->SetRelativeScale3D(FVector(4.0f, 4.0f, 0.02f));
	MarkerDisc->SetRelativeLocation(FVector(0.f, 0.f, 3.f));
	MarkerDisc->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	MarkerDisc->SetCanEverAffectNavigation(false);
	MarkerDisc->SetCastShadow(false);

	HealthComp = CreateDefaultSubobject<UHealthComponent>(TEXT("HealthComp"));
	HealthComp->MaxHealth = 1500.f;
	HealthComp->CurrentHealth = 1500.f;
}

void ADefendedAssetActor::BeginPlay()
{
	Super::BeginPlay();

	if (MarkerDisc)
	{
		DiscMID = MarkerDisc->CreateAndSetMaterialInstanceDynamic(0);
	}
	if (AssetMesh)
	{
		MeshMID = AssetMesh->CreateAndSetMaterialInstanceDynamic(0);
	}
	if (HealthComp && !bDeathBound)
	{
		HealthComp->OnDeath.AddDynamic(this, &ADefendedAssetActor::HandleHealthDied);
		bDeathBound = true;
	}
	SetConditionColor(EAssetHealthCondition::Pristine);
}

bool ADefendedAssetActor::IsAssetAlive() const
{
	return !bDestroyed && HealthComp && HealthComp->IsAlive();
}

float ADefendedAssetActor::GetAssetHealth01() const
{
	return HealthComp ? HealthComp->GetHealthPercent() : 0.f;
}

int32 ADefendedAssetActor::CountSappers() const
{
	const UWorld* World = GetWorld();
	if (!World)
	{
		return 0;
	}
	int32 Count = 0;
	const float RadiusSq = SapperRadiusCm * SapperRadiusCm;
	for (TActorIterator<APawn> It(World); It; ++It)
	{
		const ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(*It);
		if (!Soldier || !Soldier->IsAlive() || Soldier->IsAlly())
		{
			continue;
		}
		const FVector Delta = It->GetActorLocation() - GetActorLocation();
		if (FVector::DistSquared2D(It->GetActorLocation(), GetActorLocation()) <= RadiusSq
			&& FMath::Abs(Delta.Z) <= VerticalToleranceCm)
		{
			++Count;
		}
	}
	return Count;
}

void ADefendedAssetActor::SetConditionColor(EAssetHealthCondition Condition)
{
	FLinearColor Disc(0.1f, 0.85f, 0.25f, 0.55f);
	FLinearColor Body(0.55f, 0.85f, 0.6f, 1.f);
	switch (Condition)
	{
	case EAssetHealthCondition::Damaged:
		Disc = FLinearColor(0.95f, 0.62f, 0.1f, 0.55f);
		Body = FLinearColor(0.9f, 0.7f, 0.35f, 1.f);
		break;
	case EAssetHealthCondition::Critical:
		Disc = FLinearColor(0.9f, 0.12f, 0.1f, 0.65f);
		Body = FLinearColor(0.85f, 0.25f, 0.2f, 1.f);
		break;
	case EAssetHealthCondition::Destroyed:
		Disc = FLinearColor(0.05f, 0.05f, 0.05f, 0.6f);
		Body = FLinearColor(0.12f, 0.12f, 0.12f, 1.f);
		break;
	default:
		break;
	}
	if (DiscMID)
	{
		DiscMID->SetVectorParameterValue(TEXT("Color"), Disc);
	}
	if (MeshMID)
	{
		MeshMID->SetVectorParameterValue(TEXT("Color"), Body);
	}
}

void ADefendedAssetActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (bDestroyed)
	{
		return;
	}

	const int32 Sappers = CountSappers();
	const float Damage = FAssetDefenseModel::SapperDamagePerSecond(Sappers, DamagePerSapperPerSecond);
	if (Damage > 0.f && HealthComp)
	{
		HealthComp->ApplyDamage(Damage, this);

		if (FAssetDefenseModel::ShouldAnnounceAttack(SecondsSinceLastAnnouncement, AttackAnnounceQuietSeconds))
		{
			SecondsSinceLastAnnouncement = 0.f;
			OnUnderAttack.Broadcast(this);
			const float Health01 = GetAssetHealth01();
			const float SecondsLeft = FAssetDefenseModel::SecondsUntilDestroyed(Health01, Damage);
			UE_LOG(LogTemp, Warning,
				TEXT("[S19-ASSET] %s: UNDER ATTACK - %d sapper(s), about %.0f s at this rate."),
				*GetName(), Sappers, SecondsLeft > 0.f ? SecondsLeft : 0.f);
		}
	}
	SecondsSinceLastAnnouncement += FMath::Max(0.f, DeltaTime);

	// -- the condition floor: never show a better phase than the worst so far -------
	const EAssetHealthCondition Now = FAssetDefenseModel::ConditionFor01(GetAssetHealth01());
	const EAssetHealthCondition Worst = FAssetDefenseModel::WorseCondition(Now, WorstCondition);
	if (Worst != WorstCondition)
	{
		WorstCondition = Worst;
		SetConditionColor(Worst);
	}
}

void ADefendedAssetActor::HandleHealthDied(AActor* OwnerActor)
{
	if (bDestroyed)
	{
		return;
	}
	bDestroyed = true;
	SetConditionColor(EAssetHealthCondition::Destroyed);
	OnAssetDestroyed.Broadcast(this);
	UE_LOG(LogTemp, Warning, TEXT("[S19-ASSET] %s: DESTROYED."), *GetName());
}

EAssetCondition ADefendedAssetActor::GetCondition() const
{
	switch (WorstCondition)
	{
	case EAssetHealthCondition::Damaged:   return EAssetCondition::Damaged;
	case EAssetHealthCondition::Critical:  return EAssetCondition::Critical;
	case EAssetHealthCondition::Destroyed: return EAssetCondition::Destroyed;
	default:                               return EAssetCondition::Pristine;
	}
}

void ADefendedAssetActor::ResetAsset()
{
	bDestroyed = false;
	WorstCondition = EAssetHealthCondition::Pristine;
	SecondsSinceLastAnnouncement = 1e9f;
	if (HealthComp)
	{
		HealthComp->Revive();   // full health, alive again
	}
	SetConditionColor(EAssetHealthCondition::Pristine);
}

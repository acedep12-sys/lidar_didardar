// SquadAIFirstPersonComponent.cpp — runtime third- to first-person conversion for the pack player.
// See the header for the contract. Everything here is defensive about the pack: components are
// FOUND (by class, tag and name), never assumed, and every write is paired with a saved original
// so SquadAI.FP.Enable 0 / F6 / EndPlay puts the pack's camera exactly back where it was.
#include "Components/SquadAIFirstPersonComponent.h"

#include "Camera/CameraComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "GameFramework/Character.h"
#include "GameFramework/Pawn.h"
#include "GameFramework/PlayerController.h"
#include "InputCoreTypes.h"
#include "Components/MeshComponent.h"
#include "Components/PrimitiveComponent.h"   // S27-FPFIX: the viewmodel clone is held as UPrimitiveComponent*
#include "Components/SkeletalMeshComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/World.h"
#include "HAL/IConsoleManager.h"

namespace
{
	// S27-FP: one switch for the whole feature. The diagnostic subsystem attaches this
	// component to the gameplay pawn; the cvar decides whether it engages (default: yes —
	// the game is meant to be played first person). F6 flips it at runtime.
	TAutoConsoleVariable<int32> CVarFPEnable(
		TEXT("SquadAI.FP.Enable"),
		0,
		TEXT("0/1 — play in first person (default 0: third-person)."));

	// Camera geometry. ArmLength stays slightly POSITIVE so the camera sits a few cm
	// behind the eyes instead of at the cornea — the head is owner-hidden anyway, and
	// the slack keeps the near plane out of the skull.
	TAutoConsoleVariable<float> CVarFPArmLength(
		TEXT("SquadAI.FP.ArmLength"),
		10.f,
		TEXT("Boom length while in first person, cm (default 10)."));

	// Viewmodel: 1 = hide the pack's weapon and show a camera-attached copy (classic FPS
	// pose); 0 = keep the pack's real weapon visible with all of its pack animations
	// (hybrid look: gun at the hands, no body).
	TAutoConsoleVariable<int32> CVarFPViewmodel(
		TEXT("SquadAI.FP.Viewmodel"),
		1,
		TEXT("0/1 — camera-attached weapon copy instead of the third-person weapon (default 1)."));

	// Body hiding can be turned off to check what the camera is doing to the skeleton.
	TAutoConsoleVariable<int32> CVarFPHideBody(
		TEXT("SquadAI.FP.HideBody"),
		1,
		TEXT("0/1 — hide the player's own meshes from the owner view (default 1)."));

	// Hip pose of the viewmodel, relative to the camera (cm).
	TAutoConsoleVariable<float> CVarFPWeaponX(TEXT("SquadAI.FP.WeaponX"), 24.f, TEXT("Viewmodel hip pose X, cm (default 24)."));
	TAutoConsoleVariable<float> CVarFPWeaponY(TEXT("SquadAI.FP.WeaponY"), 9.f, TEXT("Viewmodel hip pose Y, cm (default 9)."));
	TAutoConsoleVariable<float> CVarFPWeaponZ(TEXT("SquadAI.FP.WeaponZ"), -15.f, TEXT("Viewmodel hip pose Z, cm (default -15)."));
	TAutoConsoleVariable<float> CVarFPWeaponPitch(TEXT("SquadAI.FP.WeaponPitch"), 0.f, TEXT("Viewmodel pitch, degrees (default 0)."));
	TAutoConsoleVariable<float> CVarFPWeaponYaw(TEXT("SquadAI.FP.WeaponYaw"), 0.f, TEXT("Viewmodel yaw, degrees (default 0)."));

	// Aim pose (right mouse held): viewmodel slides toward the screen centre and the
	// FOV eases in. AdsZoom 0 turns the zoom off if the pack ever does its own.
	TAutoConsoleVariable<float> CVarFPAdsX(TEXT("SquadAI.FP.AdsX"), 14.f, TEXT("Viewmodel aim pose X, cm (default 14)."));
	TAutoConsoleVariable<float> CVarFPAdsY(TEXT("SquadAI.FP.AdsY"), 0.f, TEXT("Viewmodel aim pose Y, cm (default 0)."));
	TAutoConsoleVariable<float> CVarFPAdsZ(TEXT("SquadAI.FP.AdsZ"), -9.f, TEXT("Viewmodel aim pose Z, cm (default -9)."));
	TAutoConsoleVariable<float> CVarFPAdsFov(TEXT("SquadAI.FP.AdsFov"), 55.f, TEXT("Field of view while aiming (default 55)."));
	TAutoConsoleVariable<int32> CVarFPAdsZoom(
		TEXT("SquadAI.FP.AdsZoom"),
		1,
		TEXT("0/1 — ease the FOV in while the right mouse button is held (default 1; set 0 if the pack zooms too)."));

	TAutoConsoleVariable<float> CVarFPInterpSpeed(
		TEXT("SquadAI.FP.InterpSpeed"),
		14.f,
		TEXT("Aim-pose ease speed (default 14); higher is snappier."));

	// S27-FP: the viewmodel clone's tag. The body sweep must skip the clone itself, and
	// no other SquadAI system resolves meshes by this name, so it doubles as ownership
	// mark. A function-local static, NOT a namespace-scope FName: those initialise
	// before the engine's name pool exists.
	static const FName& FPKeepTag()
	{
		static FName Tag = TEXT("SquadAI_FPKeep");
		return Tag;
	}
}

USquadAIFirstPersonComponent::USquadAIFirstPersonComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.bStartWithTickEnabled = true;
	// S27-FP: enforcement has to run AFTER the pack's own per-frame camera writes
	// (shoulder offsets, aim offsets), or the pack overwrites us a frame later.
	PrimaryComponentTick.TickGroup = TG_PostPhysics;
}

void USquadAIFirstPersonComponent::BeginPlay()
{
	Super::BeginPlay();

	// S27-FP: engage immediately when enabled — attaching one frame late already
	// shows a third-person flash. If the rig is not ready yet the tick retries.
	if (CVarFPEnable.GetValueOnGameThread() != 0)
	{
		SetFirstPersonEnabled(true);
	}
}

void USquadAIFirstPersonComponent::EndPlay(const EEndPlayReason::Type Reason)
{
	// S27-FP: the pawn is going away — put the pack's camera back first so a later
	// possess of the same class (menu, spectate, respawn hand-off) starts clean.
	if (bFirstPersonActive)
	{
		RestoreThirdPerson();
	}
	Super::EndPlay(Reason);
}

bool USquadAIFirstPersonComponent::SetFirstPersonEnabled(bool bEnabled)
{
	if (bEnabled == bFirstPersonActive)
	{
		return bFirstPersonActive;
	}

	if (bEnabled)
	{
		return ApplyFirstPerson();
	}

	RestoreThirdPerson();
	return true;
}

bool USquadAIFirstPersonComponent::ResolveCameraRig()
{
	APawn* Pawn = Cast<APawn>(GetOwner());
	if (!Pawn)
	{
		return false;
	}

	TArray<UCameraComponent*> Cameras;
	Pawn->GetComponents<UCameraComponent>(Cameras);

	UCameraComponent* BestCamera = nullptr;
	USpringArmComponent* BestArm = nullptr;

	// Prefer a camera that hangs off a spring arm — that is the boom the pack retracts
	// by. A camera with no arm is handled by re-parenting it (see ApplyFirstPerson).
	for (UCameraComponent* Cam : Cameras)
	{
		if (!Cam)
		{
			continue;
		}
		USceneComponent* Parent = Cam->GetAttachParent();
		USpringArmComponent* Arm = nullptr;
		for (int32 Hop = 0; Parent && Hop < 4; ++Hop)
		{
			if (USpringArmComponent* AsArm = Cast<USpringArmComponent>(Parent))
			{
				Arm = AsArm;
				break;
			}
			Parent = Parent->GetAttachParent();
		}
		if (Arm)
		{
			BestCamera = Cam;
			BestArm = Arm;
			break;
		}
		if (!BestCamera)
		{
			BestCamera = Cam;
		}
	}

	if (!BestCamera)
	{
		return false;
	}

	CameraComp = BestCamera;
	CameraArm = BestArm;
	bRigResolved = true;
	return true;
}

float USquadAIFirstPersonComponent::GetDesiredArmLength() const
{
	return FMath::Max(0.f, CVarFPArmLength.GetValueOnGameThread());
}

// S27-FP: how far the eye is above the boom's current pivot, in world Z. The default
// pawn view location (actor origin + BaseEyeHeight) is the estimate; a head socket on
// the body mesh wins when the pack has one.
FVector USquadAIFirstPersonComponent::ComputeEyeDelta() const
{
	APawn* Pawn = Cast<APawn>(GetOwner());
	if (!Pawn)
	{
		return FVector::ZeroVector;
	}

	FVector EyeWorld = Pawn->GetPawnViewLocation();

	if (const ACharacter* Char = Cast<ACharacter>(Pawn))
	{
		if (const USkeletalMeshComponent* BodyMesh = Char->GetMesh())
		{
			static const FName HeadSocket = TEXT("head");
			if (BodyMesh->DoesSocketExist(HeadSocket))
			{
				EyeWorld = BodyMesh->GetSocketLocation(HeadSocket);
			}
		}
	}

	// S27-FPFIX: no ternary here - USpringArmComponent* and UCameraComponent* are
	// sibling types and MSVC refuses the mixed conditional (C2446).
	USceneComponent* Pivot = nullptr;
	if (USpringArmComponent* Arm = CameraArm.Get())
	{
		Pivot = Arm;
	}
	else if (UCameraComponent* Cam = CameraComp.Get())
	{
		Pivot = Cam;
	}
	if (!Pivot)
	{
		return FVector::ZeroVector;
	}
	const FVector PivotWorld = Pivot->GetComponentLocation();
	return FVector(0.f, 0.f, EyeWorld.Z - PivotWorld.Z);
}

bool USquadAIFirstPersonComponent::ApplyFirstPerson()
{
	if (bFirstPersonActive)
	{
		return true;
	}

	if (!bRigResolved && !ResolveCameraRig())
	{
		// The pack pawn's camera should exist by the time we attach, but a Blueprint
		// that spawns it late must not brick the feature — tick retries quietly.
		if (!bLoggedNoCamera)
		{
			bLoggedNoCamera = true;
			UE_LOG(LogTemp, Warning, TEXT("[FirstPerson] no camera component on %s yet - retrying"), *GetNameSafe(GetOwner()));
		}
		return false;
	}
	bLoggedNoCamera = false;

	UCameraComponent* Cam = CameraComp.Get();
	if (!Cam)
	{
		return false;
	}

	// ---- save the third-person rig -----------------------------------------
	if (USpringArmComponent* Arm = CameraArm.Get())
	{
		bArmStateSaved = true;
		SavedArmLength = Arm->TargetArmLength;
		SavedSocketOffset = Arm->SocketOffset;
		SavedTargetOffset = Arm->TargetOffset;
		SavedArmRelativeLocation = Arm->GetRelativeLocation();
		bSavedDoCollisionTest = Arm->bDoCollisionTest;
		bSavedCameraLag = Arm->bEnableCameraLag;
		bSavedCameraRotationLag = Arm->bEnableCameraRotationLag;
		bSavedArmUsePawnControlRotation = Arm->bUsePawnControlRotation;

		// Raise the boom PIVOT to eye height (not the socket offset — that would swing
		// with pitch because it lives in arm space). With the pivot at the eyes, pitch
		// orbits the eye point, which is what a first-person camera must do.
		const FVector EyeDelta = ComputeEyeDelta();
		if (FMath::Abs(EyeDelta.Z) > 2.f)
		{
			Arm->SetRelativeLocation(SavedArmRelativeLocation + EyeDelta);
		}

		Arm->TargetArmLength = GetDesiredArmLength();
		Arm->SocketOffset = FVector::ZeroVector;
		Arm->TargetOffset = SavedTargetOffset; // keep the pack's own pivot aim bias
		Arm->bDoCollisionTest = false;         // a 10 cm arm must never push the camera
		Arm->bEnableCameraLag = false;         // lag on a 10 cm arm is mushy aim
		Arm->bEnableCameraRotationLag = false;
		Arm->bUsePawnControlRotation = true;   // view owns the camera, always
	}
	else
	{
		// No boom: park the camera on the pawn root at eye height and let the control
		// rotation drive it directly. State is saved even when the parent is already
		// the root — the writes below still need their restore pair.
		APawn* Pawn = Cast<APawn>(GetOwner());
		USceneComponent* Root = Pawn ? Pawn->GetRootComponent() : nullptr;
		if (!Root)
		{
			return false;
		}

		SavedCameraParent = Cam->GetAttachParent();
		SavedCameraRelativeLocation = Cam->GetRelativeLocation();
		SavedCameraRelativeRotation = Cam->GetRelativeRotation();
		bSavedCameraUsePawnControlRotation = Cam->bUsePawnControlRotation;
		bCameraReparented = true;

		if (Cam->GetAttachParent() != Root)
		{
			Cam->AttachToComponent(Root, FAttachmentTransformRules::KeepWorldTransform);
		}
		Cam->SetRelativeRotation(FRotator::ZeroRotator);
		if (Pawn)
		{
			Cam->SetRelativeLocation(FVector(GetDesiredArmLength(), 0.f, Pawn->BaseEyeHeight));
		}
		Cam->bUsePawnControlRotation = true;
	}

	SavedBaseFov = Cam->FieldOfView;
	CurrentFov = SavedBaseFov;
	bAimStateInitialized = false;
	bFovTouched = false;

	// ---- body + weapon ------------------------------------------------------
	PackWeaponMesh = ResolvePackWeaponMesh();
	HideBodyMeshes();
	if (CVarFPViewmodel.GetValueOnGameThread() != 0)
	{
		BuildViewmodel();
	}

	bFirstPersonActive = true;
	UE_LOG(LogTemp, Warning, TEXT("[FirstPerson] ON for %s (arm %.0f cm, viewmodel %d, hide body %d)"),
		*GetNameSafe(GetOwner()), GetDesiredArmLength(),
		CVarFPViewmodel.GetValueOnGameThread(), CVarFPHideBody.GetValueOnGameThread());
	return true;
}

void USquadAIFirstPersonComponent::RestoreThirdPerson()
{
	if (!bFirstPersonActive)
	{
		return;
	}

	RestoreBodyMeshes();
	DestroyViewmodel();

	if (UCameraComponent* Cam = CameraComp.Get())
	{
		if (USpringArmComponent* Arm = CameraArm.Get())
		{
			if (bArmStateSaved)
			{
				Arm->TargetArmLength = SavedArmLength;
				Arm->SocketOffset = SavedSocketOffset;
				Arm->TargetOffset = SavedTargetOffset;
				Arm->SetRelativeLocation(SavedArmRelativeLocation);
				Arm->bDoCollisionTest = bSavedDoCollisionTest;
				Arm->bEnableCameraLag = bSavedCameraLag;
				Arm->bEnableCameraRotationLag = bSavedCameraRotationLag;
				Arm->bUsePawnControlRotation = bSavedArmUsePawnControlRotation;
			}
		}
		else if (bCameraReparented)
		{
			if (USceneComponent* Parent = SavedCameraParent.Get())
			{
				Cam->AttachToComponent(Parent, FAttachmentTransformRules::KeepWorldTransform);
			}
			Cam->SetRelativeLocation(SavedCameraRelativeLocation);
			Cam->SetRelativeRotation(SavedCameraRelativeRotation);
			Cam->bUsePawnControlRotation = bSavedCameraUsePawnControlRotation;
			bCameraReparented = false;
		}
		// S27-FP: only the writer restores — with SquadAI.FP.AdsZoom 0 the pack owned
		// the FOV the whole time and stomping it here would undo the pack's zoom.
		if (bFovTouched)
		{
			Cam->SetFieldOfView(SavedBaseFov);
			bFovTouched = false;
		}
	}

	PackWeaponMesh = nullptr;
	bFirstPersonActive = false;
	UE_LOG(LogTemp, Warning, TEXT("[FirstPerson] OFF - third-person rig restored"));
}

void USquadAIFirstPersonComponent::HideBodyMeshes()
{
	AActor* Owner = GetOwner();
	if (!Owner)
	{
		return;
	}

	// S27-FP: two independent knobs.
	//   Viewmodel 1 -> the pack's weapon mesh is replaced by the camera clone, so it is
	//                  hidden from the owner no matter what HideBody says.
	//   HideBody   -> every OTHER mesh (body, helmet, gear) hides from the owner.
	const bool bUseClone = CVarFPViewmodel.GetValueOnGameThread() != 0;
	const bool bHideBody = CVarFPHideBody.GetValueOnGameThread() != 0;
	const UMeshComponent* Weapon = PackWeaponMesh.Get();

	TArray<UMeshComponent*> Meshes;
	Owner->GetComponents<UMeshComponent>(Meshes);
	for (UMeshComponent* Mesh : Meshes)
	{
		if (!Mesh || Mesh->ComponentHasTag(FPKeepTag()))
		{
			continue; // our own viewmodel clone
		}

		const bool bIsWeapon = (Mesh == Weapon);
		if (bIsWeapon && !bUseClone)
		{
			continue; // hybrid mode: the pack weapon stays visible
		}
		if (!bIsWeapon && !bHideBody)
		{
			continue; // body shown on purpose (debugging the skeleton)
		}

		bool bAlreadyKnown = false;
		for (const TPair<TWeakObjectPtr<UMeshComponent>, bool>& Entry : SavedOwnerNoSeeStates)
		{
			if (Entry.Key.Get() == Mesh)
			{
				bAlreadyKnown = true;
				break;
			}
		}
		if (bAlreadyKnown)
		{
			continue;
		}

		// S27-FPFIX: bOwnerNoSee is a bitfield - it cannot bind to Emplace's
		// forwarding reference, so the previous value is read into a real bool
		// first and the pair is constructed explicitly.
		const bool bPrevOwnerNoSee = Mesh->bOwnerNoSee;
		SavedOwnerNoSeeStates.Add(TPair<TWeakObjectPtr<UMeshComponent>, bool>(Mesh, bPrevOwnerNoSee));
		Mesh->SetOwnerNoSee(true);
	}
}

void USquadAIFirstPersonComponent::RestoreBodyMeshes()
{
	for (const TPair<TWeakObjectPtr<UMeshComponent>, bool>& Entry : SavedOwnerNoSeeStates)
	{
		if (UMeshComponent* Mesh = Entry.Key.Get())
		{
			Mesh->SetOwnerNoSee(Entry.Value);
		}
	}
	SavedOwnerNoSeeStates.Empty();
}

// S27-FP: slow maintenance (2 s) — the pack can spawn gear meshes after our one-time
// sweep, and a weapon swap can kill our cached WeaponMesh component outright.
void USquadAIFirstPersonComponent::RefreshBodyMeshSweep()
{
	if (!PackWeaponMesh.IsValid())
	{
		PackWeaponMesh = ResolvePackWeaponMesh();
	}
	RefreshViewmodel();
	HideBodyMeshes();
}

UMeshComponent* USquadAIFirstPersonComponent::ResolvePackWeaponMesh() const
{
	AActor* Owner = GetOwner();
	if (!Owner)
	{
		return nullptr;
	}

	TArray<UMeshComponent*> Meshes;
	Owner->GetComponents<UMeshComponent>(Meshes);

	// Same resolution order the pack components use: tag first, then name, then
	// "the skeletal mesh that is not the body".
	for (UMeshComponent* Mesh : Meshes)
	{
		if (Mesh && Mesh->ComponentHasTag(TEXT("TPWCS_WeaponMesh")))
		{
			return Mesh;
		}
	}
	for (UMeshComponent* Mesh : Meshes)
	{
		if (Mesh && Mesh->GetFName() == TEXT("WeaponMesh"))
		{
			return Mesh;
		}
	}
	UMeshComponent* Fallback = nullptr;
	for (UMeshComponent* Mesh : Meshes)
	{
		if (!Mesh)
		{
			continue;
		}
		const FName N = Mesh->GetFName();
		if (N == TEXT("CharacterMesh0") || N == TEXT("Mesh") || N == TEXT("Mesh0") || Mesh->ComponentHasTag(FPKeepTag()))
		{
			continue;
		}
		Fallback = Mesh;
	}
	return Fallback;
}

void USquadAIFirstPersonComponent::BuildViewmodel()
{
	DestroyViewmodel();

	AActor* Owner = GetOwner();
	UCameraComponent* Cam = CameraComp.Get();
	UMeshComponent* Source = PackWeaponMesh.Get();
	if (!Owner || !Cam || !Source)
	{
		return;
	}

	// S27-FP: the clone is a plain component pair — same mesh asset + materials as the
	// pack weapon, no anim instance (the pack's anim BP targets the third-person rig
	// and would spam bindings on a camera-attached copy). No shadow, no collision.
	// S27-FPFIX: the clone is held as UPrimitiveComponent* - SetCollisionEnabled,
	// SetCastShadow, SetOwnerNoSee and SetGenerateOverlapEvents live there, not on
	// USceneComponent (C2039 x4 on the first real build).
	UPrimitiveComponent* Clone = nullptr;
	UObject* SourceAsset = nullptr;
	if (USkeletalMeshComponent* SrcSkel = Cast<USkeletalMeshComponent>(Source))
	{
		USkeletalMeshComponent* SkelClone = NewObject<USkeletalMeshComponent>(Owner, TEXT("SquadAIFPWeapon"));
		// S27-FPFIX: SkeletalMesh the member is deprecated in 5.7 - the typed
		// accessor is the supported API (and SetSkeletalMesh is not deprecated).
		SkelClone->SetSkeletalMesh(SrcSkel->GetSkeletalMeshAsset());
		for (int32 MatIdx = 0; MatIdx < SrcSkel->GetNumMaterials(); ++MatIdx)
		{
			SkelClone->SetMaterial(MatIdx, SrcSkel->GetMaterial(MatIdx));
		}
		SourceAsset = SrcSkel->GetSkeletalMeshAsset();
		Clone = SkelClone;
	}
	else if (UStaticMeshComponent* SrcStatic = Cast<UStaticMeshComponent>(Source))
	{
		UStaticMeshComponent* StaticClone = NewObject<UStaticMeshComponent>(Owner, TEXT("SquadAIFPWeapon"));
		StaticClone->SetStaticMesh(SrcStatic->GetStaticMesh());
		for (int32 MatIdx = 0; MatIdx < SrcStatic->GetNumMaterials(); ++MatIdx)
		{
			StaticClone->SetMaterial(MatIdx, SrcStatic->GetMaterial(MatIdx));
		}
		SourceAsset = SrcStatic->GetStaticMesh();
		Clone = StaticClone;
	}

	if (!Clone || !SourceAsset)
	{
		// Neither skeletal nor static (or no asset at all): the clone cannot be built.
		// Stay honest about it instead of silently showing a hidden weapon.
		UE_LOG(LogTemp, Warning, TEXT("[FirstPerson] no viewmodel for %s (%s has no mesh asset)"),
			*GetNameSafe(Source), *Source->GetClass()->GetName());
		return;
	}

	Clone->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	Clone->SetCastShadow(false);
	Clone->SetOwnerNoSee(false);
	Clone->SetGenerateOverlapEvents(false);
	Clone->ComponentTags.Add(FPKeepTag());
	Clone->SetupAttachment(Cam);
	CurrentWeaponOffset = FVector(CVarFPWeaponX.GetValueOnGameThread(), CVarFPWeaponY.GetValueOnGameThread(), CVarFPWeaponZ.GetValueOnGameThread());
	bAimStateInitialized = false;
	Clone->SetRelativeLocation(CurrentWeaponOffset);
	Clone->SetRelativeRotation(FRotator(CVarFPWeaponPitch.GetValueOnGameThread(), CVarFPWeaponYaw.GetValueOnGameThread(), 0.f));
	Clone->RegisterComponent();
	Owner->AddInstanceComponent(Cast<UActorComponent>(Clone));

	ViewmodelMesh = Clone;
	ViewmodelSourceAsset = SourceAsset;
	UE_LOG(LogTemp, Warning, TEXT("[FirstPerson] viewmodel built from %s"), *GetNameSafe(Source));
}

void USquadAIFirstPersonComponent::DestroyViewmodel()
{
	if (USceneComponent* Clone = ViewmodelMesh.Get())
	{
		Clone->DestroyComponent();
		// Detach from the instanced-component list so the pawn's details stay clean.
		if (AActor* Owner = GetOwner())
		{
			Owner->RemoveInstanceComponent(Cast<UActorComponent>(Clone));
		}
	}
	ViewmodelMesh = nullptr;
	ViewmodelSourceAsset = nullptr;
}

bool USquadAIFirstPersonComponent::ViewmodelSourceChanged() const
{
	UMeshComponent* Source = PackWeaponMesh.Get();
	if (!Source)
	{
		return ViewmodelSourceAsset != nullptr;
	}
	if (const USkeletalMeshComponent* SrcSkel = Cast<USkeletalMeshComponent>(Source))
	{
		return SrcSkel->GetSkeletalMeshAsset() != ViewmodelSourceAsset;   // S27-FPFIX: 5.7 accessor
	}
	if (const UStaticMeshComponent* SrcStatic = Cast<UStaticMeshComponent>(Source))
	{
		return SrcStatic->GetStaticMesh() != ViewmodelSourceAsset;
	}
	return false;
}

void USquadAIFirstPersonComponent::RefreshViewmodel()
{
	if (CVarFPViewmodel.GetValueOnGameThread() == 0)
	{
		if (ViewmodelMesh.IsValid())
		{
			DestroyViewmodel();
		}
		return;
	}
	if (!ViewmodelMesh.IsValid() || ViewmodelSourceChanged())
	{
		BuildViewmodel();
	}
}

// S27-FP: the pack writes its own camera offsets every frame while aiming; the only
// reliable way to stay first person is to re-assert ours after its tick. Compare
// first, write only on drift — the common frame costs three float compares.
void USquadAIFirstPersonComponent::EnforceCameraRig()
{
	if (USpringArmComponent* Arm = CameraArm.Get())
	{
		const float WantLen = GetDesiredArmLength();
		if (!FMath::IsNearlyEqual(Arm->TargetArmLength, WantLen))
		{
			Arm->TargetArmLength = WantLen;
		}
		if (!Arm->SocketOffset.Equals(FVector::ZeroVector, 0.01f))
		{
			Arm->SocketOffset = FVector::ZeroVector;
		}
		if (Arm->bDoCollisionTest)
		{
			Arm->bDoCollisionTest = false;
		}
		if (Arm->bEnableCameraLag)
		{
			Arm->bEnableCameraLag = false;
		}
		if (Arm->bEnableCameraRotationLag)
		{
			Arm->bEnableCameraRotationLag = false;
		}
		if (!Arm->bUsePawnControlRotation)
		{
			Arm->bUsePawnControlRotation = true;
		}
	}
	else if (UCameraComponent* Cam = CameraComp.Get())
	{
		// No-boom path: keep the camera parked at the eye point.
		APawn* Pawn = Cast<APawn>(GetOwner());
		const FVector WantLoc = Pawn
			? FVector(GetDesiredArmLength(), 0.f, Pawn->BaseEyeHeight)
			: FVector(GetDesiredArmLength(), 0.f, 0.f);
		if (!Cam->GetRelativeLocation().Equals(WantLoc, 0.01f))
		{
			Cam->SetRelativeLocation(WantLoc);
		}
		if (!Cam->GetRelativeRotation().IsNearlyZero(0.01f))
		{
			Cam->SetRelativeRotation(FRotator::ZeroRotator);
		}
		if (!Cam->bUsePawnControlRotation)
		{
			Cam->bUsePawnControlRotation = true;
		}
	}
}

void USquadAIFirstPersonComponent::UpdateAimPose(float DeltaTime)
{
	APawn* Pawn = Cast<APawn>(GetOwner());
	APlayerController* PC = Pawn ? Cast<APlayerController>(Pawn->GetController()) : nullptr;
	if (!PC)
	{
		return;
	}

	const bool bAiming = PC->IsInputKeyDown(EKeys::RightMouseButton);
	const float Speed = FMath::Max(0.1f, CVarFPInterpSpeed.GetValueOnGameThread());

	const float TargetFov = bAiming ? CVarFPAdsFov.GetValueOnGameThread() : SavedBaseFov;
	const FVector HipOffset(CVarFPWeaponX.GetValueOnGameThread(), CVarFPWeaponY.GetValueOnGameThread(), CVarFPWeaponZ.GetValueOnGameThread());
	const FVector AdsOffset(CVarFPAdsX.GetValueOnGameThread(), CVarFPAdsY.GetValueOnGameThread(), CVarFPAdsZ.GetValueOnGameThread());
	const FVector TargetOffset = bAiming ? AdsOffset : HipOffset;

	// First frame after apply / viewmodel rebuild: snap, do not ease in from a pose the
	// player never chose (spawn with the right button already held).
	if (!bAimStateInitialized)
	{
		CurrentFov = TargetFov;
		CurrentWeaponOffset = TargetOffset;
		bAimStateInitialized = true;
	}
	else
	{
		CurrentFov = FMath::FInterpTo(CurrentFov, TargetFov, DeltaTime, Speed);
		CurrentWeaponOffset = FMath::VInterpTo(CurrentWeaponOffset, TargetOffset, DeltaTime, Speed);
	}

	// FOV: ease between the saved third-person base and the aim FOV. When the zoom is
	// switched off (the pack may zoom on its own) the FOV is simply left alone.
	if (CVarFPAdsZoom.GetValueOnGameThread() != 0)
	{
		if (UCameraComponent* Cam = CameraComp.Get())
		{
			if (!FMath::IsNearlyEqual(Cam->FieldOfView, CurrentFov, 0.01f))
			{
				Cam->SetFieldOfView(CurrentFov);
				bFovTouched = true;
			}
		}
	}

	// Viewmodel pose: hip <-> aim.
	if (USceneComponent* Clone = ViewmodelMesh.Get())
	{
		if (!Clone->GetRelativeLocation().Equals(CurrentWeaponOffset, 0.01f))
		{
			Clone->SetRelativeLocation(CurrentWeaponOffset);
		}
	}
}

void USquadAIFirstPersonComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	APawn* Pawn = Cast<APawn>(GetOwner());
	if (!Pawn)
	{
		return;
	}
	APlayerController* PC = Cast<APlayerController>(Pawn->GetController());

	// F6 — live toggle. Writes the cvar (not just the local flag) so the choice
	// survives death: the respawned pawn auto-engages from the cvar again.
	if (PC)
	{
		const bool bF6Down = PC->IsInputKeyDown(EKeys::F6);
		if (bF6Down && !bF6KeyDownPrev)
		{
			const int32 NewValue = bFirstPersonActive ? 0 : 1;
			// S27-FPFIX: ECVF_SetByGame no longer exists - ECVF_SetByGameSetting is
			// the 5.7 name for a gameplay write (console commands still outrank it).
			CVarFPEnable->Set(NewValue, ECVF_SetByGameSetting);
			UE_LOG(LogTemp, Warning, TEXT("[FirstPerson] F6 - %s"), NewValue ? TEXT("first person") : TEXT("third person"));
		}
		bF6KeyDownPrev = bF6Down;
	}

	// The cvar is the single source of truth for the desired mode.
	const bool bWantsFirstPerson = CVarFPEnable.GetValueOnGameThread() != 0;
	if (bWantsFirstPerson != bFirstPersonActive)
	{
		SetFirstPersonEnabled(bWantsFirstPerson);
	}

	if (!bFirstPersonActive)
	{
		return;
	}

	EnforceCameraRig();
	UpdateAimPose(DeltaTime);

	// Slow sweep: new gear meshes, dead weapon component, weapon swaps.
	MeshSweepAccum += DeltaTime;
	if (MeshSweepAccum >= 2.f)
	{
		MeshSweepAccum = 0.f;
		RefreshBodyMeshSweep();
	}
}

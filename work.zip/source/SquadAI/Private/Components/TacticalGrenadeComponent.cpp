#include "Components/TacticalGrenadeComponent.h"
#include "GameFramework/ProjectileMovementComponent.h"   // S19-GRENARC: the flight numbers live here
#include "Tactical/TacticalGrenadeActor.h"
#include "Performance/SquadAIAudioSubsystem.h"
#include "GameFramework/SquadAIInventorySubsystem.h"
#include "Performance/SquadAIPlayerCombatBridge.h"
#include "GameFramework/Pawn.h"
#include "GameFramework/PlayerController.h"
#include "Engine/World.h"
#include "Kismet/GameplayStatics.h"
#include "CollisionQueryParams.h"   // S19-TUT: FCollisionQueryParams
#include "Engine/EngineTypes.h"     // S19-TUT: FHitResult

UTacticalGrenadeComponent::UTacticalGrenadeComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.TickInterval = 0.0f; // Tick every frame for crisp input response

	GrenadeClass = ATacticalGrenadeActor::StaticClass();
}

void UTacticalGrenadeComponent::BeginPlay()
{
	Super::BeginPlay();

	// Sync with global inventory subsystem if player pawn
	if (APawn* OwnerPawn = Cast<APawn>(GetOwner()))
	{
		if (OwnerPawn->IsPlayerControlled() || OwnerPawn->IsLocallyControlled())
		{
			if (USquadAIInventorySubsystem* Inv = USquadAIInventorySubsystem::Get(this))
			{
				FragGrenadesRemaining = Inv->FragGrenades;
				SmokeGrenadesRemaining = Inv->SmokeGrenades;
			}
		}
	}

	FragGrenadesRemaining = FMath::Clamp(FragGrenadesRemaining, 0, MaxFragGrenades);
	SmokeGrenadesRemaining = FMath::Clamp(SmokeGrenadesRemaining, 0, MaxSmokeGrenades);
	bGKeyDownPrev = false;
	bHKeyDownPrev = false;
}

void UTacticalGrenadeComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	// Edge-triggered key listener for [G] (Frag) and [H] (Smoke)
	if (APawn* OwnerPawn = Cast<APawn>(GetOwner()))
	{
		APlayerController* PC = Cast<APlayerController>(OwnerPawn->GetController());
		if (!PC && OwnerPawn->IsLocallyControlled())
		{
			PC = UGameplayStatics::GetPlayerController(GetWorld(), 0);
		}

		if (PC)
		{
			const bool bGDown = PC->IsInputKeyDown(EKeys::G);
			const bool bHDown = PC->IsInputKeyDown(EKeys::H);

			// Single-listener rule: when the combat bridge is attached it owns player G/H
			// input (inventory gating + fallback spawn). This component only listens as a
			// fallback for pawns without a bridge; AI always calls Throw* directly.
			if (!OwnerPawn->FindComponentByClass<USquadAIPlayerCombatBridge>())
			{
				// S19-AIM: hold to aim, release to throw.
				const bool bGPress   =  bGDown && !bGKeyDownPrev;
				const bool bGRelease = !bGDown &&  bGKeyDownPrev;
				const bool bHPress   =  bHDown && !bHKeyDownPrev;
				const bool bHRelease = !bHDown &&  bHKeyDownPrev;

				if (bHoldToAim)
				{
					// S19-GRENARC: the same BeginAim/ReleaseAim pair the combat bridge
					// uses, so the HUD arrow behaves identically whichever listener is
					// live. (PC->GetControlRotation() is what GetCurrentThrowDirection()
					// reads, so the thrown direction is unchanged.)
					if (bGPress || bHPress)
					{
						BeginAim(bGPress ? EGrenadeType::Fragmentation : EGrenadeType::SmokeScreen);
					}

					if (bIsAimingGrenade)
					{
						// Cancel if it became unavailable mid-aim (ammo spent elsewhere,
						// pawn lost, owner swapped).
						if (!CanThrowGrenade(AimingGrenadeType))
						{
							CancelAim();
						}
						else
						{
							const bool bReleasedThisKey =
								(AimingGrenadeType == EGrenadeType::SmokeScreen) ? bHRelease : bGRelease;
							if (bReleasedThisKey)
							{
								ReleaseAim();
							}
						}
					}
				}
				else
				{
					// Legacy: throw immediately on the key press.
					if (bGPress)
					{
						const FVector AimDir = PC->GetControlRotation().Vector();
						ThrowGrenadeInDirection(EGrenadeType::Fragmentation, AimDir);
					}
					if (bHPress)
					{
						const FVector AimDir = PC->GetControlRotation().Vector();
						ThrowGrenadeInDirection(EGrenadeType::SmokeScreen, AimDir);
					}
				}
			}

			bGKeyDownPrev = bGDown;
			bHKeyDownPrev = bHDown;
		}
	}
}

bool UTacticalGrenadeComponent::ThrowFragForward()
{
	return ThrowTowardControlRotation(EGrenadeType::Fragmentation);
}

bool UTacticalGrenadeComponent::ThrowSmokeForward()
{
	return ThrowTowardControlRotation(EGrenadeType::SmokeScreen);
}

bool UTacticalGrenadeComponent::ThrowTowardControlRotation(EGrenadeType Type)
{
	APawn* OwnerPawn = Cast<APawn>(GetOwner());
	APlayerController* PC = OwnerPawn ? Cast<APlayerController>(OwnerPawn->GetController()) : nullptr;
	if (!PC && OwnerPawn && OwnerPawn->IsLocallyControlled())
	{
		PC = UGameplayStatics::GetPlayerController(GetWorld(), 0);
	}
	if (!PC) return false;
	return ThrowGrenadeInDirection(Type, PC->GetControlRotation().Vector());
}

bool UTacticalGrenadeComponent::CanThrowGrenade(EGrenadeType Type) const
{
	const UWorld* World = GetWorld();
	if (!World) return false;

	const float Now = World->GetTimeSeconds();
	// S19-TUT: the cooldown still applies with free ammo — the lesson teaches
	// aiming, not how fast you can click.
	if (Now - LastThrowTime < ThrowCooldown) return false;

	if (bUnlimitedGrenades) return true;   // S19-TUT

	if (Type == EGrenadeType::Fragmentation)
	{
		return FragGrenadesRemaining > 0;
	}
	else
	{
		return SmokeGrenadesRemaining > 0;
	}
}

bool UTacticalGrenadeComponent::ThrowGrenadeInDirection(EGrenadeType Type, const FVector& Direction)
{
	if (!CanThrowGrenade(Type)) return false;

	UWorld* World = GetWorld();
	if (!World) return false;

	AActor* OwnerActor = GetOwner();
	if (!OwnerActor) return false;

	const FVector SpawnLoc = OwnerActor->GetActorLocation() + FVector(0.f, 0.f, 60.f) + Direction.GetSafeNormal() * 50.f;
	const FRotator SpawnRot = Direction.Rotation();

	FActorSpawnParameters SpawnParams;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	SpawnParams.Instigator = Cast<APawn>(OwnerActor);

	TSubclassOf<ATacticalGrenadeActor> ClassToSpawn = GrenadeClass ? GrenadeClass : TSubclassOf<ATacticalGrenadeActor>(ATacticalGrenadeActor::StaticClass());
	ATacticalGrenadeActor* Grenade = World->SpawnActor<ATacticalGrenadeActor>(ClassToSpawn, SpawnLoc, SpawnRot, SpawnParams);
	if (Grenade)
	{
		Grenade->GrenadeType = Type;
		// Add upward ballistic arc
		FVector LaunchDir = (Direction.GetSafeNormal() + FVector(0.f, 0.f, 0.28f)).GetSafeNormal();
		Grenade->LaunchGrenade(LaunchDir * LaunchSpeed, OwnerActor);

		LastThrowTime = World->GetTimeSeconds();

		if (!bUnlimitedGrenades)   // S19-TUT: free ammo while the tutorial teaches
		{
			if (Type == EGrenadeType::Fragmentation)
			{
				FragGrenadesRemaining = FMath::Max(0, FragGrenadesRemaining - 1);
			}
			else
			{
				SmokeGrenadesRemaining = FMath::Max(0, SmokeGrenadesRemaining - 1);
			}
		}

		if (USquadAIInventorySubsystem* Inv = USquadAIInventorySubsystem::Get(this))
		{
			if (Cast<APawn>(OwnerActor) && Cast<APawn>(OwnerActor)->IsPlayerControlled())
			{
				Inv->FragGrenades = FragGrenadesRemaining;
				Inv->SmokeGrenades = SmokeGrenadesRemaining;
			}
		}

		if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
		{
			AudioSys->PlayTacticalVoiceline(ETacticalVoicelineType::Leader_OrderEngage, OwnerActor);
		}

		OnGrenadeThrown.Broadcast(OwnerActor, Type, SpawnLoc + Direction * 1500.f);
		OnGrenadeInventoryChanged.Broadcast(FragGrenadesRemaining, SmokeGrenadesRemaining);

		UE_LOG(LogTemp, Log, TEXT("[TacticalGrenade] %s threw %s grenade (Remaining: Frag %d, Smoke %d)"),
			*GetNameSafe(OwnerActor),
			Type == EGrenadeType::Fragmentation ? TEXT("FRAG") : TEXT("SMOKE"),
			FragGrenadesRemaining, SmokeGrenadesRemaining);

		return true;
	}

	return false;
}

bool UTacticalGrenadeComponent::ThrowGrenadeAtLocation(EGrenadeType Type, const FVector& TargetLocation)
{
	if (!CanThrowGrenade(Type)) return false;

	AActor* OwnerActor = GetOwner();
	if (!OwnerActor) return false;

	const FVector StartLoc = OwnerActor->GetActorLocation() + FVector(0.f, 0.f, 60.f);
	FVector ToTarget = TargetLocation - StartLoc;
	const float Dist2D = FVector(ToTarget.X, ToTarget.Y, 0.f).Size();
	const float ArcHeight = FMath::Clamp(Dist2D * 0.35f, 150.f, 600.f);

	FVector Dir = (ToTarget + FVector(0.f, 0.f, ArcHeight)).GetSafeNormal();
	return ThrowGrenadeInDirection(Type, Dir);
}

void UTacticalGrenadeComponent::RefillGrenades(int32 FragCount, int32 SmokeCount)
{
	FragGrenadesRemaining = FMath::Clamp(FragGrenadesRemaining + FragCount, 0, MaxFragGrenades);
	SmokeGrenadesRemaining = FMath::Clamp(SmokeGrenadesRemaining + SmokeCount, 0, MaxSmokeGrenades);

	if (USquadAIInventorySubsystem* Inv = USquadAIInventorySubsystem::Get(this))
	{
		if (APawn* OwnerPawn = Cast<APawn>(GetOwner()))
		{
			if (OwnerPawn->IsPlayerControlled() || OwnerPawn->IsLocallyControlled())
			{
				Inv->FragGrenades = FragGrenadesRemaining;
				Inv->SmokeGrenades = SmokeGrenadesRemaining;
			}
		}
	}

	OnGrenadeInventoryChanged.Broadcast(FragGrenadesRemaining, SmokeGrenadesRemaining);
}

// ==========================================================================
//  S19-TUT: throw preview
//  The player is told to "put a grenade in the barrel" with no way to judge
//  distance, so the lesson turns into blind luck. These three helpers expose
//  the exact numbers ThrowGrenadeInDirection() uses, so the HUD can draw the
//  real arc instead of a guess. Change the throw, and the arc follows.
// ==========================================================================

FVector UTacticalGrenadeComponent::GetThrowOrigin(const FVector& Direction) const
{
	const AActor* OwnerActor = GetOwner();
	if (!OwnerActor)
	{
		return FVector::ZeroVector;
	}
	// Mirrors ThrowGrenadeInDirection(): chest height, 50 cm out along the aim.
	return OwnerActor->GetActorLocation()
		+ FVector(0.f, 0.f, 60.f)
		+ Direction.GetSafeNormal() * 50.f;
}

FVector UTacticalGrenadeComponent::GetThrowVelocity(const FVector& Direction) const
{
	const FVector Dir = Direction.GetSafeNormal();
	// Same fixed upward bias the real throw adds, so the drawn arc is the
	// arc you actually get.
	const FVector LaunchDir = (Dir + FVector(0.f, 0.f, 0.28f)).GetSafeNormal();
	return LaunchDir * LaunchSpeed;
}

FVector UTacticalGrenadeComponent::GetCurrentThrowDirection() const
{
	const APawn* OwnerPawn = Cast<APawn>(GetOwner());
	if (OwnerPawn)
	{
		if (const AController* C = OwnerPawn->GetController())
		{
			return C->GetControlRotation().Vector();
		}
		return OwnerPawn->GetActorForwardVector();
	}
	const AActor* OwnerActor = GetOwner();
	return OwnerActor ? OwnerActor->GetActorForwardVector() : FVector::ForwardVector;
}

bool UTacticalGrenadeComponent::PredictThrowPath(const FVector& Direction,
	TArray<FVector>& OutPath, FVector& OutImpact, bool& bOutImpacted) const
{
	// S19-GRENARC: one implementation. This is the S19-TUT entry point (path to the first
	// contact) and it now runs the shared flight model, so the tutorial preview, the
	// aiming arrow and the grenade itself agree by construction.
	TArray<FVector> Tail;
	FGrenadeFlightResult R;
	if (!PredictThrowDetailed(AimingGrenadeType, Direction, OutPath, Tail, R))
	{
		OutPath.Reset();
		OutImpact = FVector::ZeroVector;
		bOutImpacted = false;
		return false;
	}

	// "Impacted" keeps its old meaning: the ray hit something. A fuse cut in mid-air is
	// reported as not-impacted, so the HUD keeps fading the marker as it used to.
	bOutImpacted = R.bHit;
	OutImpact = R.DetonationPoint;
	return true;
}

// ============================================================================
//  S19-GRENARC: the aim phase
// ============================================================================
bool UTacticalGrenadeComponent::BeginAim(EGrenadeType Type)
{
	if (!CanThrowGrenade(Type))
	{
		return false;
	}
	bIsAimingGrenade = true;
	AimingGrenadeType = Type;
	return true;
}

void UTacticalGrenadeComponent::CancelAim()
{
	bIsAimingGrenade = false;
}

bool UTacticalGrenadeComponent::ReleaseAim()
{
	if (!bIsAimingGrenade)
	{
		return false;
	}
	const EGrenadeType Type = AimingGrenadeType;
	bIsAimingGrenade = false;      // the aim ends whatever the throw decides

	const FVector Dir = GetCurrentThrowDirection();
	return ThrowGrenadeInDirection(Type, Dir);
}

// ============================================================================
//  S19-GRENARC: flight model plumbing
// ============================================================================
FGrenadeFlightParams UTacticalGrenadeComponent::GetFlightParams(EGrenadeType Type) const
{
	FGrenadeFlightParams P;

	// The numbers come off the class that will actually be spawned, not off this
	// component's idea of them: retune the actor's fuse or its ProjectileMovement in
	// the editor and the arrow follows automatically.
	const ATacticalGrenadeActor* CDO = GrenadeClass
		? GrenadeClass->GetDefaultObject<ATacticalGrenadeActor>()
		: ATacticalGrenadeActor::StaticClass()->GetDefaultObject<ATacticalGrenadeActor>();

	const float WorldGravity = GetWorld() ? GetWorld()->GetGravityZ() : -980.f;

	if (CDO)
	{
		P.FuseTime = CDO->FuseTime;
		P.BlastRadius = CDO->BlastRadius;
		if (const UProjectileMovementComponent* PM = CDO->ProjectileMovement)
		{
			P.Bounciness = PM->Bounciness;
			P.Friction = PM->Friction;
			P.StopSpeed = PM->BounceVelocityStopSimulatingThreshold;
			P.MaxSpeed = PM->MaxSpeed;
			P.bShouldBounce = PM->bShouldBounce;
			// ProjectileGravityScale is the name on UProjectileMovementComponent
			// (GravityScale belongs to UCharacterMovementComponent).
			P.GravityZ = WorldGravity * PM->ProjectileGravityScale;
		}
		else
		{
			P.GravityZ = WorldGravity;
		}
	}
	else
	{
		P.GravityZ = WorldGravity;
	}

	P.bIsFrag = (Type == EGrenadeType::Fragmentation);
	P.StepTime = PreviewStepTime;
	P.MaxSteps = PreviewMaxSteps;
	P.MaxBounces = PreviewMaxBounces;
	return P;
}

bool UTacticalGrenadeComponent::PredictThrowDetailed(EGrenadeType Type, const FVector& Direction,
	TArray<FVector>& OutPath, TArray<FVector>& OutTail, FGrenadeFlightResult& OutResult) const
{
	OutPath.Reset();
	OutTail.Reset();
	OutResult = FGrenadeFlightResult();

	UWorld* World = GetWorld();
	const AActor* OwnerActor = GetOwner();
	if (!World || !OwnerActor)
	{
		return false;
	}

	const FGrenadeFlightParams P = GetFlightParams(Type);

	// Same collision setup as the line-trace version this replaces (visibility channel,
	// owner ignored, simple shapes): the trace is the world, the arithmetic is the shared
	// flight model - one implementation for the preview, the HUD and the test bench.
	FCollisionQueryParams Params(SCENE_QUERY_STAT(GrenadeThrowPreview), false, OwnerActor);
	Params.bReturnPhysicalMaterial = false;
	Params.bTraceComplex = false;
	TWeakObjectPtr<UWorld> WeakWorld(World);

	auto TraceFn = [&WeakWorld, &Params](const FVector& From, const FVector& To,
		FVector& OutPoint, FVector& OutNormal, float& OutFraction) -> bool
	{
		UWorld* W = WeakWorld.Get();
		if (!W)
		{
			return false;
		}
		FHitResult Hit;
		if (W->LineTraceSingleByChannel(Hit, From, To, ECC_Visibility, Params))
		{
			OutPoint = Hit.ImpactPoint;
			OutNormal = Hit.ImpactNormal;
			OutFraction = FMath::Clamp(Hit.Time, 0.f, 1.f);
			return true;
		}
		return false;
	};

	const FVector Origin = GetThrowOrigin(Direction);
	const FVector Velocity = GetThrowVelocity(Direction);
	return SimulateGrenadeFlight(P, Origin, Velocity, TraceFn, OutPath, OutTail, OutResult);
}

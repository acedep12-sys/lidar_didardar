// SquadAITPWCSVisualsComponent.cpp — PURE VISUAL bridge
// Only spawns particles, plays montages, and sets pose properties.
// Does NOT call any TPWCS firing/damage/projectile functions.
#include "Components/SquadAITPWCSVisualsComponent.h"
#include "Performance/SquadAIFXManagerSubsystem.h"
#include "Components/SkeletalMeshComponent.h"
#include "GameFramework/Character.h"
#include "Particles/ParticleSystem.h"
#include "Particles/ParticleSystemComponent.h"
#include "NiagaraSystem.h"
#include "NiagaraFunctionLibrary.h"
#include "NiagaraComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Animation/AnimMontage.h"
#include "Sound/SoundBase.h"
#include "Engine/DataTable.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "TimerManager.h"
#include "DrawDebugHelpers.h"
#include "UObject/UnrealType.h"
#include "Performance/SquadAIAudioSubsystem.h"
#include "Actors/SquadAIAudioManager.h"

USquadAITPWCSVisualsComponent::USquadAITPWCSVisualsComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
}

void USquadAITPWCSVisualsComponent::BeginPlay()
{
	Super::BeginPlay();
	FindComponents();
	ResolvePreset();
	if (WeaponComp) InitializeWeaponPose();
}

void USquadAITPWCSVisualsComponent::FindComponents()
{
	AActor* Owner = GetOwner();
	if (!Owner) return;

	TArray<UActorComponent*> Comps;
	Owner->GetComponents(Comps);

	for (UActorComponent* C : Comps)
	{
		if (!C) continue;
		const FString N = C->GetName();
		const FString CN = C->GetClass() ? C->GetClass()->GetName() : TEXT("");
		if (N.Contains(TEXT("BPC_Weapon")) || CN.Contains(TEXT("WeaponCharacterAI")) || CN.Contains(TEXT("WeaponCharacter")))
		{
			WeaponComp = C;
			break;
		}
	}

	TArray<USkeletalMeshComponent*> Meshes;
	Owner->GetComponents<USkeletalMeshComponent>(Meshes);
	for (USkeletalMeshComponent* M : Meshes)
	{
		if (!M) continue;
		if (M->ComponentHasTag(TEXT("TPWCS_WeaponMesh")) || M->GetFName() == TEXT("WeaponMesh"))
			ResolvedWeaponMesh = M;
		else if (M->GetFName() == TEXT("Mesh") || M->GetFName() == TEXT("CharacterMesh0"))
			ResolvedCharacterMesh = M;
	}
	if (!ResolvedCharacterMesh)
	{
		if (ACharacter* Ch = Cast<ACharacter>(Owner)) ResolvedCharacterMesh = Ch->GetMesh();
		else if (Meshes.Num() > 0) ResolvedCharacterMesh = Meshes[0];
	}
	if (!ResolvedWeaponMesh && Meshes.Num() > 1)
	{
		for (USkeletalMeshComponent* M : Meshes)
			if (M && M != ResolvedCharacterMesh) { ResolvedWeaponMesh = M; break; }
	}

	if (ResolvedCharacterMesh)
	{
		UAnimInstance* AnimBP = ResolvedCharacterMesh->GetAnimInstance();
		UE_LOG(LogTemp, Warning, TEXT("[TPWCSVisuals] %s: AnimBP=%s WeaponComp=%s Weapon=%s"),
			*GetNameSafe(Owner),
			AnimBP ? *AnimBP->GetClass()->GetName() : TEXT("NULL"),
			*GetNameSafe(WeaponComp),
			*WeaponID.ToString());
	}
}

void USquadAITPWCSVisualsComponent::ResolvePreset()
{
	// If preset is already assigned, load its assets
	if (WeaponPreset)
	{
		WeaponPreset->LoadAllAssets();
		UE_LOG(LogTemp, Warning, TEXT("[TPWCSVisuals] Using preset '%s' for weapon '%s'"),
			*WeaponPreset->GetName(), *WeaponID.ToString());
		bSetupComplete = true;
		return;
	}

	// Try to auto-find a preset matching WeaponID
	TryAutoFindPreset();

	if (WeaponPreset)
	{
		WeaponPreset->LoadAllAssets();
		UE_LOG(LogTemp, Warning, TEXT("[TPWCSVisuals] Auto-found preset '%s' for weapon '%s'"),
			*WeaponPreset->GetName(), *WeaponID.ToString());
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("[TPWCSVisuals] No preset found for weapon '%s'. Set WeaponPreset manually in BP editor."), *WeaponID.ToString());
	}
	bSetupComplete = true;
}

void USquadAITPWCSVisualsComponent::TryAutoFindPreset()
{
	// Search asset registry for USquadAIWeaponVisualPreset assets
	FAssetRegistryModule& ARM = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	TArray<FAssetData> Assets;
	ARM.Get().GetAssetsByClass(USquadAIWeaponVisualPreset::StaticClass()->GetClassPathName(), Assets);

	for (const FAssetData& A : Assets)
	{
		USquadAIWeaponVisualPreset* Preset = Cast<USquadAIWeaponVisualPreset>(A.GetAsset());
		if (Preset && Preset->WeaponID == WeaponID)
		{
			WeaponPreset = Preset;
			return;
		}
	}
}

void USquadAITPWCSVisualsComponent::InitializeWeaponPose()
{
	if (!WeaponComp || bInitialized) return;
	bInitialized = true;

	// ONLY set left hand IK — let the TPWCS AnimBP handle everything else on its own.
	// Setting Ground State, Weapon Anim State, aimingState etc. here was breaking the AnimBP
	// because it was overriding values the AnimBP needs to read from BPC_WeaponCharacterAI.
	SetBoolOnWeapon({ TEXT("bLeftHandIK"), TEXT("bLeftHandIK?"), TEXT("Left Hand IK") }, true);

	UE_LOG(LogTemp, Warning, TEXT("[TPWCSVisuals] Pose initialized for '%s' (IK only)"), *WeaponID.ToString());
}

void USquadAITPWCSVisualsComponent::SetAimPose(AActor* AimTarget, const FVector& AimLocation)
{
	if (!WeaponComp) return;

	// Only set aim properties — don't touch Ground State, Weapon Anim State, etc.
	SetByteOnWeapon({ TEXT("aimingState"), TEXT("AimingState") }, 1); // Aiming
	SetVectorOnWeapon({ TEXT("traceEndPoint"), TEXT("TraceEndPoint") }, AimLocation);
	SetObjectOnWeapon({ TEXT("aimedActor"), TEXT("AimedActor") }, AimTarget);

	if (APawn* Pawn = Cast<APawn>(GetOwner()))
		SetObjectOnWeapon({ TEXT("AI Controller Handle"), TEXT("AIControllerHandle") }, Pawn->GetController());

	bIsAiming = true;
}

void USquadAITPWCSVisualsComponent::ClearAimPose()
{
	if (!WeaponComp || !bIsAiming) return;

	SetByteOnWeapon({ TEXT("aimingState"), TEXT("AimingState") }, 0); // NotAiming
	bIsAiming = false;
}

void USquadAITPWCSVisualsComponent::PlayShotVisuals(const FVector& HitLocation)
{
	if (!WeaponPreset) return;
	// P1-A4: FX-budget gates below fail open when no manager exists.
	USquadAIFXManagerSubsystem* FXSys = USquadAIFXManagerSubsystem::Get(this);

	// 1. Play firing montage on character mesh
	if (WeaponPreset->LoadedFiringMontage && ResolvedCharacterMesh)
	{
		if (ACharacter* Char = Cast<ACharacter>(GetOwner()))
		{
			Char->PlayAnimMontage(WeaponPreset->LoadedFiringMontage, 1.5f);
		}
	}

	// 2. Set bIsShooting briefly so AnimBP shows firing pose, then auto-reset
	SetBoolOnWeapon({ TEXT("bIsShooting?"), TEXT("bIsShooting") }, true);

	// Auto-reset bIsShooting? after a short delay so AnimBP returns to idle pose
	if (UWorld* World = GetWorld())
	{
		TWeakObjectPtr<USquadAITPWCSVisualsComponent> WeakThis(this);
		FTimerHandle ResetHandle;
		World->GetTimerManager().SetTimer(ResetHandle, [WeakThis]()
		{
			if (!WeakThis.IsValid()) return;
			WeakThis->SetBoolOnWeapon({ TEXT("bIsShooting?"), TEXT("bIsShooting") }, false);
		}, 0.1f, false);
	}

	// 3. Resolve Muzzle Transform
	FVector MuzzleLoc = GetOwner() ? GetOwner()->GetActorLocation() : FVector::ZeroVector;
	FRotator MuzzleRot = GetOwner() ? GetOwner()->GetActorRotation() : FRotator::ZeroRotator;

	if (ResolvedWeaponMesh)
	{
		const FName MuzzleSocket = WeaponPreset->MuzzleSocketName;
		const FTransform MuzzleTransform = ResolvedWeaponMesh->GetSocketTransform(MuzzleSocket, RTS_World);
		MuzzleLoc = MuzzleTransform.GetLocation();
		MuzzleRot = MuzzleTransform.GetRotation().Rotator();

		// P1-A4: one pipeline per preset (Niagara preferred) + FX-budget gate (was: both + ungated).
		const bool bMuzzleAllowed = !FXSys || FXSys->CanSpawnImpactVFX(MuzzleLoc);
		if (WeaponPreset->LoadedMuzzleFlashNS && bMuzzleAllowed)
			UNiagaraFunctionLibrary::SpawnSystemAtLocation(GetWorld(), WeaponPreset->LoadedMuzzleFlashNS, MuzzleLoc, MuzzleRot);
		else if (WeaponPreset->LoadedMuzzleFlash && bMuzzleAllowed)
			UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), WeaponPreset->LoadedMuzzleFlash, MuzzleTransform);

		// 4. Spawn bullet trail from muzzle to hit point
		if (!HitLocation.IsNearlyZero())
		{
			// P1-A4: budget gate for trail + impact (fail-open without FX manager).
			const bool bTrailAllowed = !FXSys || FXSys->CanSpawnImpactVFX(HitLocation);
			// P1-A4: Cascade trail only when no Niagara equivalent is loaded (single pipeline).
			if (WeaponPreset->LoadedBulletTrail && !WeaponPreset->LoadedBulletTrailNS && bTrailAllowed)
			{
				// TPWCS P_BulletTrail is a Cascade beam particle.
				UParticleSystemComponent* PSC = UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), WeaponPreset->LoadedBulletTrail, MuzzleLoc);
				if (PSC)
				{
					PSC->SetBeamSourcePoint(0, MuzzleLoc, 0);
					PSC->SetBeamTargetPoint(0, HitLocation, 0);
					PSC->SetVectorParameter(TEXT("Source"), MuzzleLoc);
					PSC->SetVectorParameter(TEXT("End"), HitLocation);
					PSC->SetVectorParameter(TEXT("Target"), HitLocation);
					PSC->SetFloatParameter(TEXT("Scale"), WeaponPreset->BulletTrailScale);
				}
			}
			if (WeaponPreset->LoadedBulletTrailNS && bTrailAllowed)
			{
				UNiagaraComponent* NC = UNiagaraFunctionLibrary::SpawnSystemAtLocation(GetWorld(), WeaponPreset->LoadedBulletTrailNS, MuzzleLoc);
				if (NC)
				{
					NC->SetVariableVec3(TEXT("Source"), MuzzleLoc);
					NC->SetVariableVec3(TEXT("End"), HitLocation);
					NC->SetVariableVec3(TEXT("Target"), HitLocation);
					NC->SetVariableFloat(TEXT("Scale"), WeaponPreset->BulletTrailScale);
				}
			}

			// 5. Spawn bullet impact at hit point
			if (WeaponPreset->LoadedBulletImpact && bTrailAllowed)
				UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), WeaponPreset->LoadedBulletImpact, HitLocation);
		}
	}

	// 6. Play spatialized fire sound with distance layers and speed-of-sound physics
	USoundBase* FireSnd = WeaponPreset ? WeaponPreset->LoadedFireSound.Get() : nullptr;
	USoundBase* TailSnd = WeaponPreset ? WeaponPreset->LoadedFireTailSound.Get() : nullptr;

	if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
	{
		if (ASquadAIAudioManager* Mgr = AudioSys->GetActiveAudioManager())
		{
			if (!FireSnd) FireSnd = Mgr->DefaultGunshotCloseSound.Get();
			if (!TailSnd) TailSnd = Mgr->DefaultGunshotTailSound ? Mgr->DefaultGunshotTailSound.Get() : Mgr->DefaultGunshotDistantSound.Get();
		}
	}

	if (FireSnd)
	{
		const FVector SoundLoc = MuzzleLoc.IsNearlyZero() ? (GetOwner() ? GetOwner()->GetActorLocation() : FVector::ZeroVector) : MuzzleLoc;
		if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
		{
			AudioSys->PlaySpatialSoundWithDistanceLayers(
				FireSnd,
				TailSnd,
				SoundLoc,
				1800.f,
				30000.f,
				true,
				1.0f);
		}
		else
		{
			UGameplayStatics::PlaySoundAtLocation(GetWorld(), FireSnd, SoundLoc, 1.0f);
		}
	}
}

void USquadAITPWCSVisualsComponent::PlayReloadVisuals()
{
	if (!WeaponPreset || !WeaponPreset->LoadedReloadMontage) return;
	if (ACharacter* Char = Cast<ACharacter>(GetOwner()))
		Char->PlayAnimMontage(WeaponPreset->LoadedReloadMontage, 1.0f);
}

void USquadAITPWCSVisualsComponent::PlayEquipVisuals()
{
	if (!WeaponPreset || !WeaponPreset->LoadedEquipMontage) return;
	if (ACharacter* Char = Cast<ACharacter>(GetOwner()))
		Char->PlayAnimMontage(WeaponPreset->LoadedEquipMontage, 1.0f);
}

// === Property helpers ===

bool USquadAITPWCSVisualsComponent::SetBoolOnWeapon(const TArray<FName>& Names, bool bValue)
{
	if (!WeaponComp) return false;
	for (const FName& N : Names)
		if (FBoolProperty* P = FindFProperty<FBoolProperty>(WeaponComp->GetClass(), N))
		{ P->SetPropertyValue_InContainer(WeaponComp, bValue); return true; }
	return false;
}

bool USquadAITPWCSVisualsComponent::SetByteOnWeapon(const TArray<FName>& Names, uint8 Value)
{
	if (!WeaponComp) return false;
	for (const FName& N : Names)
		if (FByteProperty* P = FindFProperty<FByteProperty>(WeaponComp->GetClass(), N))
		{ P->SetPropertyValue_InContainer(WeaponComp, Value); return true; }
	return false;
}

bool USquadAITPWCSVisualsComponent::SetVectorOnWeapon(const TArray<FName>& Names, const FVector& Value)
{
	if (!WeaponComp) return false;
	for (const FName& N : Names)
		if (FStructProperty* P = FindFProperty<FStructProperty>(WeaponComp->GetClass(), N))
			if (P->Struct == TBaseStructure<FVector>::Get())
			{ *P->ContainerPtrToValuePtr<FVector>(WeaponComp) = Value; return true; }
	return false;
}

bool USquadAITPWCSVisualsComponent::SetObjectOnWeapon(const TArray<FName>& Names, UObject* Value)
{
	if (!WeaponComp || !Value) return false;
	for (const FName& N : Names)
		if (FObjectProperty* P = FindFProperty<FObjectProperty>(WeaponComp->GetClass(), N))
		{ P->SetObjectPropertyValue_InContainer(WeaponComp, Value); return true; }
	return false;
}

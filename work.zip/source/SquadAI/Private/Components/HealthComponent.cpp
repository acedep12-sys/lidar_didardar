// HealthComponent.cpp — Damage chokepoint with invincibility & downed support
#include "Components/HealthComponent.h"
#include "Characters/SoldierCharacter.h"
#include "SquadAITuning.h"
#include "HUD/QuestNativeHUD.h"
#include "GameFramework/Pawn.h"

namespace
{
	ASoldierCharacter* SquadAIResolveHealthDamageSoldier(AActor* Actor)
	{
		if (!Actor) return nullptr;
		if (ASoldierCharacter* Direct = Cast<ASoldierCharacter>(Actor)) return Direct;
		if (ASoldierCharacter* OwnerSoldier = Cast<ASoldierCharacter>(Actor->GetOwner())) return OwnerSoldier;
		if (ASoldierCharacter* InstigatorSoldier = Cast<ASoldierCharacter>(Actor->GetInstigator())) return InstigatorSoldier;
		return nullptr;
	}

	APawn* SquadAIResolveHealthDamagePawn(AActor* Actor)
	{
		if (!Actor) return nullptr;
		if (APawn* DirectPawn = Cast<APawn>(Actor)) return DirectPawn;
		if (APawn* OwnerPawn = Cast<APawn>(Actor->GetOwner())) return OwnerPawn;
		return Actor->GetInstigator();
	}
}

UHealthComponent::UHealthComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
}

void UHealthComponent::BeginPlay()
{
	Super::BeginPlay();

	const USquadAITuning* T = USquadAITuning::Get();
	if (MaxHealth <= 0.f) MaxHealth = T->DefaultMaxHealth;
	if (bInvincible && InvincibleMinHealth <= 0.f) InvincibleMinHealth = T->InvincibleMinHealth;

	CurrentHealth = MaxHealth;
}

// S19-PLAYERDEATH: A player-controlled ally must take the mission death route, not enter the ally downed path (which does not broadcast OnDeath).
float UHealthComponent::ApplyDamage(float DamageAmount, AActor* DamageCauser)
{
	// B7-5 reader: dev god-mode cheat ignores damage entirely (also covers
	// ApplyExternalDamage, which routes through here).
	if (bCheatGodMode) return 0.f;
	if (bIsDead || DamageAmount <= 0.f) return 0.f;

	// S19-ELITE: the armour layer, right at the chokepoint so it covers bullets,
	// explosives and everything else. Both are pure multipliers/caps: with the defaults
	// (1.0 / 0.0) the behaviour below is bit-for-bit what it was before this round.
	float ScaledDamage = DamageAmount * FMath::Clamp(IncomingDamageMultiplier, 0.f, 2.f);
	if (MaxSingleHitFraction > 0.f && MaxHealth > 0.f)
	{
		const float Cap = FMath::Max(MaxHealth * FMath::Clamp(MaxSingleHitFraction, 0.05f, 1.f), 1.f);
		if (ScaledDamage > Cap)
		{
			// Only an elite reads this, and the log line is how you know the cap saved him
			// - otherwise "he survived a headshot" looks like a bug in PIE.
			UE_LOG(LogTemp, Verbose, TEXT("[S19-ELITE] single hit capped on %s: %.1f -> %.1f (%.0f%% of %.0f max)"),
				*GetNameSafe(GetOwner()), ScaledDamage, Cap, MaxSingleHitFraction * 100.f, MaxHealth);
			ScaledDamage = Cap;
		}
	}
	DamageAmount = ScaledDamage;

	ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(GetOwner());
	ASoldierCharacter* CauserSoldier = SquadAIResolveHealthDamageSoldier(DamageCauser);
	APawn* OwnerPawn = Cast<APawn>(GetOwner());
	const bool bPlayerControlled = OwnerPawn && OwnerPawn->IsPlayerControlled();
	const bool bHasDownedMechanic = Soldier && Soldier->bCanBeDowned && !bPlayerControlled;

	// G-23: no friendly fire and no ally-origin player damage indicators. This stops
	// random damage flashes coming from squadmates and prevents same-team enemies from
	// killing each other before they reach the quest zone.
	if (Soldier && CauserSoldier && Soldier != CauserSoldier)
	{
		const bool bSameTeam = (Soldier->IsEnemy() && CauserSoldier->IsEnemy()) || (!Soldier->IsEnemy() && !CauserSoldier->IsEnemy());
		if (bSameTeam)
		{
			return 0.f;
		}
	}
	if (bPlayerControlled && CauserSoldier && !CauserSoldier->IsEnemy())
	{
		return 0.f;
	}

	// G-23: enemies also get arrival/spawn protection against non-player damage.
	// This prevents allies, pack-side startup impulses, falls, or enemy crossfire from
	// deleting a wave before it has time to move into the quest zone. Player shots still count.
	if (Soldier && Soldier->IsEnemy() && Soldier->HasSpawnGracePeriod())
	{
		APawn* CauserPawn = SquadAIResolveHealthDamagePawn(DamageCauser);
		if (!CauserPawn || !CauserPawn->IsPlayerControlled())
		{
			return 0.f;
		}
	}

	// Spawn/respawn grace: friendlies (player, Shahid Rostami, allies) take no damage while
	// InitialCombatGraceTimer is active (previously declared but never enforced anywhere,
	// which caused phantom hits right after spawn/revive). Enemies are exempt so fresh
	// waves stay killable.
	if (Soldier && Soldier->HasSpawnGracePeriod() && !Soldier->IsEnemy())
	{
		return 0.f;
	}

	// AAA-MW-22: leader is fully immortal. His HP must not decrease when shot,
	// regardless of whether damage arrives through bullets, radial damage, TPWCS,
	// pack health polling or Blueprint ApplyDamage calls.
	if (Soldier && Soldier->IsSquadLeader())
	{
		bInvincible = true;
		bIsDead = false;
		CurrentHealth = MaxHealth;
		OnHealthChanged.Broadcast(GetHealthPercent());
		return 0.f;
	}

	CurrentHealth -= DamageAmount;

	// Invincible: clamp only if downed mechanics are NOT active
	if (bInvincible && !bHasDownedMechanic)
	{
		CurrentHealth = FMath::Max(CurrentHealth, InvincibleMinHealth);
	}

	UE_LOG(LogTemp, Verbose, TEXT("Health: %s took %.1f from %s, HP %.1f/%.1f%s"),
		*GetNameSafe(GetOwner()), DamageAmount, *GetNameSafe(DamageCauser), CurrentHealth, MaxHealth,
		(bInvincible && !bHasDownedMechanic) ? TEXT(" invincible") : TEXT(""));

	// Broadcast damage event (for flinch animations, hit reactions, HUD)
	OnDamaged.Broadcast(DamageAmount, DamageCauser, CurrentHealth);
	OnHealthChanged.Broadcast(GetHealthPercent());

	// If player pawn took damage, trigger directional damage indicator on HUD
	if (bPlayerControlled)
	{
		if (DamageCauser && DamageCauser != OwnerPawn && !DamageCauser->GetActorLocation().IsNearlyZero())
		{
			if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this))
			{
				HUD->NotifyDamageReceived(DamageCauser->GetActorLocation(), DamageAmount);
			}
		}
	}

	// Downed or Death check
	if (CurrentHealth <= 0.f)
	{
		if (bHasDownedMechanic && !Soldier->bIsDowned)
		{
			Soldier->EnterDownedState();
		}
		else if (!bInvincible && (!bHasDownedMechanic || (Soldier && !Soldier->bIsDowned)))
		{
			bIsDead = true;
			UE_LOG(LogTemp, Warning, TEXT("Health: %s died"), *GetNameSafe(GetOwner()));
			OnDeath.Broadcast(GetOwner());
		}
	}

	return DamageAmount;
}

float UHealthComponent::ApplyExternalDamage(float DamageAmount, AActor* DamageCauser, AController* InstigatorController, TSubclassOf<UDamageType> DamageTypeClass)
{
	const float Applied = ApplyDamage(DamageAmount, DamageCauser);
	if (Applied > 0.f)
	{
		OnExternalDamageReceived.Broadcast(Applied, DamageCauser, InstigatorController, DamageTypeClass);
	}
	return Applied;
}

void UHealthComponent::Heal(float Amount)
{
	// F-G9: Heal must not resurrect — Revive() is the only path that clears bIsDead.
	if (Amount <= 0.f || bIsDead) return;

	CurrentHealth = FMath::Clamp(CurrentHealth + Amount, 0.f, MaxHealth);
	OnHealthChanged.Broadcast(GetHealthPercent());
}

void UHealthComponent::Revive()
{
	bIsDead = false;
	CurrentHealth = MaxHealth;
	OnHealthChanged.Broadcast(GetHealthPercent());
}

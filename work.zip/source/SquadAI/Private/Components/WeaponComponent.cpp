// WeaponComponent.cpp — Hitscan weapon with recoil, falloff, and suppression
#include "Components/WeaponComponent.h"
#include "Diagnostics/SquadAISituationLog.h"   // S19-LOGGER
#include "Components/HealthComponent.h"
#include "Components/CapsuleComponent.h"
#include "Characters/SoldierCharacter.h"
#include "Engine/DamageEvents.h"
#include "SquadAITuning.h"
#include "GameFramework/Character.h"
#include "GenericTeamAgentInterface.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/World.h"
#include "DrawDebugHelpers.h"
#include "Performance/SoldierRegistrySubsystem.h"
#include "Performance/SquadAIAudioSubsystem.h"
#include "Actors/SquadAIAudioManager.h"
#include "HUD/QuestNativeHUD.h"
#include "Kismet/GameplayStatics.h"

// Forward declare — defined in Performance module
class USoldierRegistrySubsystem;

UWeaponComponent::UWeaponComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.bStartWithTickEnabled = false;
	PrimaryComponentTick.TickInterval = 0.05f;
}

void UWeaponComponent::BeginPlay()
{
	Super::BeginPlay();

	const USquadAITuning* T = USquadAITuning::Get();
	// Only set defaults if the value hasn't been overridden in Blueprint
	if (Damage == 8.f) Damage = T->DefaultDamage; // F-G11: sentinel must match the header default (8), was 15 → tuning fill never ran.
	if (FireRatePerSec == 12.f) FireRatePerSec = T->DefaultFireRate; // F-G11: header default is 12, was 8.
	if (BaseSpreadDegrees == 1.5f) BaseSpreadDegrees = T->DefaultBaseSpread;
	if (SpreadPerShot == 0.3f) SpreadPerShot = T->DefaultSpreadPerShot; // F-G11: header default is 0.3, was 0.4.
	if (SpreadDecayPerSec == 5.f) SpreadDecayPerSec = T->DefaultSpreadDecay; // F-G11: header default is 5, was 4.
	if (MaxRange == 10000.f) MaxRange = T->DefaultMaxRange;
	if (FalloffStart == 2500.f) FalloffStart = T->DefaultFalloffStart;
	if (MinDamageMultiplier == 0.35f) MinDamageMultiplier = T->DefaultMinDamageMultiplier;
	if (SuppressionRadius == 250.f) SuppressionRadius = T->SuppressionRadius;
	if (SuppressionAmount == 0.35f) SuppressionAmount = T->SuppressionAmountPerBullet;

	CurrentSpread = BaseSpreadDegrees;
}

void UWeaponComponent::TickComponent(float DeltaTime, ELevelTick TickType,
	FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	const float Now = GetWorld()->GetTimeSeconds();

	// Spread recovery
	if (!bBurstActive && CurrentSpread > BaseSpreadDegrees)
	{
		CurrentSpread = FMath::Max(BaseSpreadDegrees, CurrentSpread - SpreadDecayPerSec * DeltaTime);
	}

	// Barrel heat dissipation
	if (BarrelHeat > 0.f)
	{
		BarrelHeat = FMath::FInterpConstantTo(BarrelHeat, 0.f, DeltaTime, HeatCoolingRate);
	}

	// Cooldown completion
	if (CurrentState == EWeaponState::Cooldown && Now >= CooldownUntil)
	{
		CurrentState = EWeaponState::Idle;
		if (bBurstActive)
		{
			ShotsRemaining = BurstShots;
		}
	}

	if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(GetOwner()))
	{
		// Short pulse for AnimBP boolean users. Montage users are unaffected.
		if (Soldier->bWantsToFire && (Now - Soldier->LastFireAnimTime) > 0.25f)
		{
			Soldier->bWantsToFire = false;
		}
	}

	// Burst sequencing
	if (bBurstActive && CurrentState != EWeaponState::Cooldown && Now >= NextShotTime)
	{
		if (ShotsRemaining > 0)
		{
			FireAtTarget(BurstTarget);
		}
		else
		{
			// Burst complete → cooldown
			CurrentState = EWeaponState::Cooldown;
			CooldownUntil = Now + CooldownSeconds;
		}
	}

	if (!bBurstActive && CurrentState != EWeaponState::Cooldown && CurrentSpread <= BaseSpreadDegrees + 0.01f && BarrelHeat <= 0.01f)
	{
		SetComponentTickEnabled(false);
	}
}

static void AddAttachedActorsRecursive(AActor* Actor, TArray<AActor*>& OutActors)
{
	if (!Actor) return;
	TArray<AActor*> Attached;
	Actor->GetAttachedActors(Attached);
	for (AActor* Child : Attached)
	{
		if (Child)
		{
			OutActors.AddUnique(Child);
			AddAttachedActorsRecursive(Child, OutActors);
		}
	}
}

static UHealthComponent* FindHealthFromHitActor(AActor* HitActor)
{
	AActor* Cursor = HitActor;
	while (Cursor)
	{
		if (UHealthComponent* HC = Cursor->FindComponentByClass<UHealthComponent>())
		{
			return HC;
		}
		Cursor = Cursor->GetAttachParentActor();
	}
	return nullptr;
}

// ---------------------------------------------------------------------------
//  TPWCS player health helpers (reflection only — the TPWCS BPI_HealthInterface
//  is a pure-Blueprint asset with no C++ wrapper in this project).
//  These exist ONLY to guarantee the player's pack health component is
//  initialized (Max Health > 0 and Current Health filled). Actual damage is
//  applied via the TPWCS health interface HI_TakeDamage (see ApplyTPWCSPlayerDamage).
// ---------------------------------------------------------------------------

static UActorComponent* FindTPWCSPlayerHealthComponent(AActor* Actor)
{
	if (!Actor) return nullptr;
	TArray<UActorComponent*> Comps;
	Actor->GetComponents(Comps);

	// Prefer the actual TPWCS health component (class BPC_HealthPlayer / BPC_HealthAI /
	// BPC_HealthBase / BPC_HealthMaster). This avoids matching the health-BAR widget
	// component, whose instance name often contains "Health" too.
	for (UActorComponent* C : Comps)
	{
		if (!C) continue;
		const FString ClassName = C->GetClass() ? C->GetClass()->GetName() : TEXT("");
		if (ClassName.Contains(TEXT("BPC_Health")) || ClassName.Contains(TEXT("HealthBase")) || ClassName.Contains(TEXT("HealthMaster")))
		{
			return C;
		}
	}

	// Fallback: any health-named component that is not a widget.
	for (UActorComponent* C : Comps)
	{
		if (!C) continue;
		const FString ClassName = C->GetClass() ? C->GetClass()->GetName() : TEXT("");
		if (ClassName.Contains(TEXT("Widget"))) continue;
		if (ClassName.Contains(TEXT("Health")) || C->GetName().Contains(TEXT("Health")))
		{
			return C;
		}
	}
	return nullptr;
}

static double ReadTPWCSHealthDouble(UActorComponent* Comp, const TCHAR* PropName)
{
	if (!Comp) return -1.0;
	for (TFieldIterator<FProperty> It(Comp->GetClass()); It; ++It)
	{
		if (It->GetName().Equals(PropName, ESearchCase::IgnoreCase))
		{
			if (FDoubleProperty* DP = CastField<FDoubleProperty>(*It))
				return DP->GetPropertyValue_InContainer(Comp);
			if (FFloatProperty* FP = CastField<FFloatProperty>(*It))
				return (double)FP->GetPropertyValue_InContainer(Comp);
		}
	}
	return -1.0;
}

static void WriteTPWCSHealthDouble(UActorComponent* Comp, const TCHAR* PropName, double Value)
{
	if (!Comp) return;
	for (TFieldIterator<FProperty> It(Comp->GetClass()); It; ++It)
	{
		if (It->GetName().Equals(PropName, ESearchCase::IgnoreCase))
		{
			if (FDoubleProperty* DP = CastField<FDoubleProperty>(*It))
			{ DP->SetPropertyValue_InContainer(Comp, Value); return; }
			if (FFloatProperty* FP = CastField<FFloatProperty>(*It))
			{ FP->SetPropertyValue_InContainer(Comp, (float)Value); return; }
		}
	}
}

static bool ReadTPWCSHealthBool(UActorComponent* Comp, const TCHAR* PropName)
{
	if (!Comp) return false;
	for (TFieldIterator<FProperty> It(Comp->GetClass()); It; ++It)
	{
		if (It->GetName().Equals(PropName, ESearchCase::IgnoreCase))
		{
			if (FBoolProperty* BP = CastField<FBoolProperty>(*It))
				return BP->GetPropertyValue_InContainer(Comp);
		}
	}
	return false;
}

// Returns true if the component reports the actor as already dead. TPWCS names
// the flag "bIsDead?" (with a literal '?' in the property name).
static bool IsTPWCSPlayerDead(UActorComponent* Comp)
{
	return ReadTPWCSHealthBool(Comp, TEXT("bIsDead?"))
		|| ReadTPWCSHealthBool(Comp, TEXT("bIsDead"))
		|| ReadTPWCSHealthBool(Comp, TEXT("IsDead"));
}

// S19-PACKHP: a TPWCS pack health component can report MORE health than its own
// maxHealth (observed live on the player: currentHealth 1998.338 / maxHealth 100).
// While that is true, every bullet is real but invisible: the HUD percent is
// clamped to 1.0, the pack's own bar cannot move, and the player cannot die from
// gunfire - i.e. "the first enemy shot does no damage". Cap it back to maxHealth
// and say so once, with the numbers, so the next log names the culprit.
static void ClampTPWCSPlayerHealthToMax(UActorComponent* HC, const TCHAR* Where)
{
	if (!HC || IsTPWCSPlayerDead(HC)) return;

	const double MaxHP = ReadTPWCSHealthDouble(HC, TEXT("maxHealth"));
	if (MaxHP <= 0.0) return;

	const double CurHP = ReadTPWCSHealthDouble(HC, TEXT("currentHealth"));
	if (CurHP <= MaxHP) return;

	WriteTPWCSHealthDouble(HC, TEXT("currentHealth"), MaxHP);
	UE_LOG(LogTemp, Warning,
		TEXT("[Weapon] S19-PACKHP %s: pack health was %.3f but maxHealth is %.3f - clamped to max (damage from now on is visible)."),
		Where, CurHP, MaxHP);
	SquadAISituation::Note(FString::Printf(
		TEXT("PACKHP-CLAMP %s on %s: currentHealth %.3f > maxHealth %.3f -> clamped"),
		Where, *GetNameSafe(HC->GetOwner()), CurHP, MaxHP));
}

// First-hit safety net. If the player's TPWCS health was left uninitialized
// (Max Health == 0, or Current Health never filled) the player would appear to
// have 0 HP and die on the first bullet. Refill it before applying damage.
// Never refills a player that is genuinely already dead.
static void EnsureTPWCSPlayerHealthInitialized(APawn* Player)
{
	UActorComponent* HC = FindTPWCSPlayerHealthComponent(Player);
	if (!HC) return;

	// S19-PACKHP: never leave the component above its own max - that state makes
	// every incoming shot invisible (see ClampTPWCSPlayerHealthToMax).
	ClampTPWCSPlayerHealthToMax(HC, TEXT("before damage"));

	const double MaxHP = ReadTPWCSHealthDouble(HC, TEXT("maxHealth"));

	if (MaxHP > 0.0)
	{
		// Max Health is configured. If Current Health is still empty (<=0) at the
		// first hit, refill it from Max Health so we don't instakill the player —
		// unless the actor is genuinely dead (then leave it alone).
		const double CurHP = ReadTPWCSHealthDouble(HC, TEXT("currentHealth"));
		if (CurHP <= 0.0 && !IsTPWCSPlayerDead(HC))
		{
			if (UFunction* Reinit = HC->FindFunction(TEXT("HI_ReinitializeHealth")))
			{
				TArray<uint8> Buf;
				Buf.SetNumZeroed(Reinit->ParmsSize);
				HC->ProcessEvent(Reinit, Buf.Num() ? Buf.GetData() : nullptr);
				// S19-PACKHP: the pack's own reinitialise can come back over max
				// (it may scale by difficulty multipliers) - cap it, otherwise the
				// refill itself is what makes the next shots look like they missed.
				ClampTPWCSPlayerHealthToMax(HC, TEXT("after HI_ReinitializeHealth"));
			}
			else
			{
				WriteTPWCSHealthDouble(HC, TEXT("currentHealth"), MaxHP);
			}
		}
		return;
	}

	// Max Health is 0/unset (CDO default). Give the player a sane max and refill
	// (only if not already dead).
	const double DefaultMax = 100.0;
	WriteTPWCSHealthDouble(HC, TEXT("maxHealth"), DefaultMax);
	if (!IsTPWCSPlayerDead(HC))
	{
		if (UFunction* Reinit = HC->FindFunction(TEXT("HI_ReinitializeHealth")))
		{
			TArray<uint8> Buf;
			Buf.SetNumZeroed(Reinit->ParmsSize);
			HC->ProcessEvent(Reinit, Buf.Num() ? Buf.GetData() : nullptr);
			ClampTPWCSPlayerHealthToMax(HC, TEXT("after reinit (MaxHealth was 0)"));
		}
		else
		{
			WriteTPWCSHealthDouble(HC, TEXT("currentHealth"), DefaultMax);
		}
		UE_LOG(LogTemp, Warning, TEXT("Weapon: Player TPWCS health was uninitialized (MaxHealth=0). Set MaxHealth=%.0f and refilled CurrentHealth."), DefaultMax);
	}
}

// Locate the TPWCS damage function on the player's health component.
//
// The exact reflected name of the BPI_HealthInterface damage function can vary between
// projects/packs, and Blueprint-implemented interface functions are NOT always reachable
// through UObject::FindFunction() in UE5 — but they ARE reachable by enumerating the
// class's functions. So we resolve it with a couple of fallbacks:
//   1. FindFunction("HI_TakeDamage")  — the canonical TPWCS interface name (fast path).
//   2. Enumerate every function on the class and pick one whose name contains
//      "TakeDamage" (covers interface variants such as
//      "BPI_HealthInterface_HI_TakeDamage" or "TakeHealthDamage"), preferring an exact
//      "HI_TakeDamage" match when present.
static UFunction* ResolveTPWCSDamageFunction(UObject* Object)
{
	if (!Object) return nullptr;
	UClass* Class = Object->GetClass();
	if (!Class) return nullptr;

	// 1) Canonical name via FindFunction (handles supers + interfaces).
	if (UFunction* F = Class->FindFunctionByName(TEXT("HI_TakeDamage"), EIncludeSuperFlag::IncludeSuper))
	{
		return F;
	}

	// 2) Enumerate all functions (incl. interface/Blueprint event functions that
	//    FindFunction sometimes misses) and pick a "TakeDamage" candidate.
	UFunction* Fallback = nullptr;
	for (TFieldIterator<UFunction> It(Class, EFieldIteratorFlags::IncludeSuper); It; ++It)
	{
		const FString Name = It->GetName();
		if (!Name.Contains(TEXT("TakeDamage"))) continue;

		// Prefer the exact interface name if it exists.
		if (Name == TEXT("HI_TakeDamage") || Name.EndsWith(TEXT("HI_TakeDamage")))
		{
			return *It;
		}
		if (!Fallback) Fallback = *It;
	}
	return Fallback;
}

// Apply damage through the TPWCS BPI_HealthInterface (HI_TakeDamage by default).
// This is the canonical TPWCS damage entry point (it's what TPWCS projectiles call):
// it reduces health, drives the health-bar widget (OnHealthSet) and runs the real
// death/ragdoll/despawn flow when HP reaches 0. Crucially it does NOT depend on the
// actor's OnTakeAnyDamage delegate being bound — which is why routing through
// UGameplayStatics::ApplyDamage did nothing for the player.
//
// Parameters are filled by TYPE (not by assumed order) so this is robust to however the
// Blueprint interface function declares them. If no damage function can be resolved we
// fall back to the standard actor damage pipeline as a last resort so the player still
// takes damage.
static const ASoldierCharacter* SquadAIResolveDamageSoldier(const AActor* Actor)
{
	if (!Actor) return nullptr;
	if (const ASoldierCharacter* Direct = Cast<ASoldierCharacter>(Actor)) return Direct;
	if (const ASoldierCharacter* OwnerSoldier = Cast<ASoldierCharacter>(Actor->GetOwner())) return OwnerSoldier;
	if (const ASoldierCharacter* InstigatorSoldier = Cast<ASoldierCharacter>(Actor->GetInstigator())) return InstigatorSoldier;
	return nullptr;
}

static bool SquadAIShouldIgnoreFriendlyDamage(AActor* Target, AActor* Causer)
{
	if (!Target || !Causer || Target == Causer) return false;
	const ASoldierCharacter* Shooter = SquadAIResolveDamageSoldier(Causer);
	const ASoldierCharacter* TargetSoldier = SquadAIResolveDamageSoldier(Target);
	if (Shooter && TargetSoldier)
	{
		return (Shooter->IsEnemy() && TargetSoldier->IsEnemy()) || (!Shooter->IsEnemy() && !TargetSoldier->IsEnemy());
	}
	if (Shooter && !Shooter->IsEnemy())
	{
		if (const APawn* TargetPawn = Cast<APawn>(Target))
		{
			return TargetPawn->IsPlayerControlled();
		}
	}
	return false;
}

static void ApplyTPWCSPlayerDamage(APawn* Player, float Damage, AController* InstigatorController, AActor* Causer)
{
	if (!Player || SquadAIShouldIgnoreFriendlyDamage(Player, Causer)) return;

	// P1-1: exactly ONE SquadAI-side application (was 3x: direct + TakeDamage + ApplyDamage).
	// SoldierCharacter routes through its TakeDamage override (leader branch, ApplyDamage
	// chokepoint, hit-react, AI damage sense); other pawns keep direct HealthComp damage
	// (base TakeDamage would not reach it) plus one TakeDamage for BP/pack handling.
	ASoldierCharacter* SoldierTarget = Cast<ASoldierCharacter>(Player);
	FDamageEvent DmgEvent;
	if (SoldierTarget)
	{
		Player->TakeDamage(Damage, DmgEvent, InstigatorController, Causer);
	}
	else
	{
		if (UHealthComponent* DirectHC = Player->FindComponentByClass<UHealthComponent>())
		{
			if (DirectHC->IsAlive())
			{
				DirectHC->ApplyDamage(Damage, Causer);
			}
		}
		Player->TakeDamage(Damage, DmgEvent, InstigatorController, Causer);
	}

	// 3. Notify HUD for directional hit indicators and blood vignette
	if (UWorld* World = Player->GetWorld())
	{
		if (APlayerController* PC = World->GetFirstPlayerController())
		{
			if (AQuestNativeHUD* HUD = Cast<AQuestNativeHUD>(PC->GetHUD()))
			{
				if (Causer && Causer != Player && !Causer->GetActorLocation().IsNearlyZero())
				{
					HUD->NotifyDamageReceived(Causer->GetActorLocation(), Damage);
				}
			}
		}
	}

	UActorComponent* HC = FindTPWCSPlayerHealthComponent(Player);
	if (!HC)
	{
		UE_LOG(LogTemp, Verbose, TEXT("Weapon: Player took %.1f standard damage (no TPWCS comp)."), Damage);
		return;
	}

	// S19-LOGGER: "the first enemy shot did nothing" is only answerable if the log
	// shows the hit AND the health before/after it. Read before, apply, read after.
	const double HPBefore = ReadTPWCSHealthDouble(HC, TEXT("currentHealth"));
	const double HPMaxBefore = ReadTPWCSHealthDouble(HC, TEXT("maxHealth"));

	// P1-1: resolve the pack canonical damage path FIRST — the property write below is
	// only a fallback when the pack exposes no damage function (was: both = 2x pack-side).
	UFunction* Func = ResolveTPWCSDamageFunction(HC);
	if (!Func)
	{
		Func = ResolveTPWCSDamageFunction(Player);
	}
	const double CurHP = ReadTPWCSHealthDouble(HC, TEXT("currentHealth"));
	if (!Func && CurHP > 0.0)
	{
		const double NewHP = FMath::Max(0.0, CurHP - (double)Damage);
		WriteTPWCSHealthDouble(HC, TEXT("currentHealth"), NewHP);
	}

	if (Func)
	{
		UObject* TargetObj = HC->FindFunction(Func->GetFName()) ? (UObject*)HC : (UObject*)Player;
		TArray<uint8> Params;
		Params.SetNumZeroed(Func->ParmsSize);
		void* Buf = Params.GetData();

		bool bDamageParamSet = false;
		for (TFieldIterator<FProperty> It(Func); It; ++It)
		{
			FProperty* P = *It;
			if (!P || P->HasAnyPropertyFlags(CPF_ReturnParm | CPF_OutParm))
			{
				continue;
			}

			if (FFloatProperty* FP = CastField<FFloatProperty>(P))
			{
				if (!bDamageParamSet)
				{
					FP->SetPropertyValue_InContainer(Buf, Damage);
					bDamageParamSet = true;
				}
			}
			else if (FDoubleProperty* DP = CastField<FDoubleProperty>(P))
			{
				if (!bDamageParamSet)
				{
					DP->SetPropertyValue_InContainer(Buf, (double)Damage);
					bDamageParamSet = true;
				}
			}
			else if (FClassProperty* CP = CastField<FClassProperty>(P))
			{
				CP->SetObjectPropertyValue_InContainer(Buf, UDamageType::StaticClass());
			}
			else if (FObjectProperty* OP = CastField<FObjectProperty>(P))
			{
				UClass* PC = OP->PropertyClass;
				if (PC && PC->IsChildOf(AController::StaticClass()))
				{
					OP->SetObjectPropertyValue_InContainer(Buf, InstigatorController);
				}
				else
				{
					OP->SetObjectPropertyValue_InContainer(Buf, Causer);
				}
			}
		}

		TargetObj->ProcessEvent(Func, Buf);
	}

	// P1-1: re-sync the bridge baseline AFTER all pack writes (fallback write and/or HI
	// func both move pack HP). Without this the next poll mistakes our mirrored damage
	// for fresh pack damage and routes it through ApplyDamage a second time.
	if (SoldierTarget)
	{
		const double SyncedPackHP = ReadTPWCSHealthDouble(HC, TEXT("currentHealth"));
		if (SyncedPackHP >= 0.0)
		{
			SoldierTarget->PostMirroredPackDamage(static_cast<float>(SyncedPackHP));
		}
	}

	// S19-LOGGER: one event line per hit on the player, with the health it really moved.
	// If "the first enemy shot does nothing" ever happens again, this line says why:
	// HP unchanged (pack ignored the hit / wrong component), or the value was already
	// above maxHealth (PACKHP-CLAMP lines above will have flagged it), or the pack
	// function was not found (Func == null + no property write).
	const double HPAfter = ReadTPWCSHealthDouble(HC, TEXT("currentHealth"));
	SquadAISituation::Note(FString::Printf(
		TEXT("PLAYER-DMG %.2f from %s (path=%s) -> hp %.3f/%.1f => %.3f (%s)"),
		Damage,
		*GetNameSafe(Causer),
		Func ? TEXT("pack fn") : TEXT("property write"),
		HPBefore, HPMaxBefore, HPAfter,
		(HPAfter < HPBefore - 0.01) ? TEXT("APPLIED") : TEXT("NO HEALTH CHANGE")));
}

static ASoldierCharacter* FindSoldierAlongShot(UWorld* World, AActor* Shooter, const FVector& Start, const FVector& Dir, float MaxDistance, float HitRadius)
{
	if (!World || !Shooter || MaxDistance <= 0.f) return nullptr;

	USoldierRegistrySubsystem* Registry = World->GetSubsystem<USoldierRegistrySubsystem>();
	if (!Registry) return nullptr;

	ASoldierCharacter* ShooterSoldier = Cast<ASoldierCharacter>(Shooter);
	const uint8 ShooterTeam = ShooterSoldier ? ShooterSoldier->GetGenericTeamId().GetId() : 255;

	const FVector QueryCenter = Start + Dir * (MaxDistance * 0.5f);
	TArray<ASoldierCharacter*> Candidates = Registry->QueryRadius(QueryCenter, MaxDistance * 0.5f + HitRadius + 250.f);

	ASoldierCharacter* Best = nullptr;
	float BestProjection = FLT_MAX;
	const float HitRadiusSq = HitRadius * HitRadius;

	for (ASoldierCharacter* Candidate : Candidates)
	{
		if (!Candidate || Candidate == Shooter || !Candidate->IsAlive()) continue;
		if (ShooterSoldier && Candidate->GetGenericTeamId().GetId() == ShooterTeam) continue;

		// Test against a few body points so capsule/mesh Visibility settings are not required.
		const FVector BodyPoints[] = {
			Candidate->GetActorLocation() + FVector(0.f, 0.f, 45.f),
			Candidate->GetActorLocation() + FVector(0.f, 0.f, 90.f),
			Candidate->GetActorLocation() + FVector(0.f, 0.f, 135.f)
		};

		for (const FVector& Point : BodyPoints)
		{
			const FVector ToPoint = Point - Start;
			const float Projection = FVector::DotProduct(ToPoint, Dir);
			if (Projection < 0.f || Projection > MaxDistance) continue;

			const FVector Closest = Start + Dir * Projection;
			const float PerpSq = FVector::DistSquared(Point, Closest);
			if (PerpSq <= HitRadiusSq && Projection < BestProjection)
			{
				BestProjection = Projection;
				Best = Candidate;
			}
		}
	}

	return Best;
}

bool UWeaponComponent::FireAtTarget(FVector TargetLocation)
{
	if (!CanFire()) return false;
	if (ASoldierCharacter* OwnerSoldier = Cast<ASoldierCharacter>(GetOwner()))
	{
		if (OwnerSoldier->IsUsingPackPresentationMode() && !bAllowFireInPackPresentationMode)
		{
			return false;
		}

		if (!OwnerSoldier->IsAlive())
		{
			StopFiring();
			return false;
		}
	}

	UWorld* World = GetWorld();
	if (!World) return false;

	SetComponentTickEnabled(true);

	const FVector MuzzleLoc = GetMuzzleLocation();

	// Target prediction logic
	FVector AimTarget = TargetLocation;
	if (BulletSpeed > 0.f)
	{
		// Try to find the target character for velocity
		AActor* TargetActor = nullptr;
		USoldierRegistrySubsystem* Registry = World->GetSubsystem<USoldierRegistrySubsystem>();
		if (Registry)
		{
			TArray<ASoldierCharacter*> Nearby = Registry->QueryRadius(TargetLocation, 200.f);
			if (Nearby.Num() > 0) TargetActor = Nearby[0];
		}
		
		if (!TargetActor)
		{
			// Fallback: check player
			APawn* Player = World->GetFirstPlayerController() ? World->GetFirstPlayerController()->GetPawn() : nullptr;
			if (Player && FVector::DistSquared(Player->GetActorLocation(), TargetLocation) < 200.f * 200.f)
			{
				TargetActor = Player;
			}
		}

		if (TargetActor)
		{
			const float Dist = FVector::Dist(MuzzleLoc, TargetLocation);
			const float TimeToHit = Dist / BulletSpeed;
			AimTarget += TargetActor->GetVelocity() * TimeToHit;
		}
	}

	// Central muzzle visibility gate. Actor/eye LOS may be clear while the gun barrel is behind
	// a hill, sandbag, wall, or low cover. In that case do not fire a gameplay shot.
	if (bRequireMuzzleLineOfSightToFire)
	{
		FHitResult MuzzleLOSHit;
		FCollisionQueryParams MuzzleLOSParams(SCENE_QUERY_STAT(SquadAIMuzzleLOS), false);
		MuzzleLOSParams.AddIgnoredActor(GetOwner());
		TArray<AActor*> AttachedActors;
		AddAttachedActorsRecursive(GetOwner(), AttachedActors);
		for (AActor* Attached : AttachedActors)
		{
			MuzzleLOSParams.AddIgnoredActor(Attached);
		}

		const bool bBlockedBeforeTarget = World->LineTraceSingleByChannel(MuzzleLOSHit, MuzzleLoc, AimTarget, ECC_Visibility, MuzzleLOSParams);
		if (bBlockedBeforeTarget)
		{
			// If we hit a damageable actor, allow the shot. If we hit world/static/non-health geometry,
			// the muzzle is blocked and firing would just draw red lines into cover.
			if (!FindHealthFromHitActor(MuzzleLOSHit.GetActor()))
			{
				UE_LOG(LogTemp, Verbose, TEXT("Weapon: %s muzzle blocked by %s before target; shot suppressed."), *GetNameSafe(GetOwner()), *GetNameSafe(MuzzleLOSHit.GetActor()));
				return false;
			}
		}
	}

	FVector AimDir = (AimTarget - MuzzleLoc).GetSafeNormal();
	AimDir = ApplySpread(AimDir);

	PerformHitscan(MuzzleLoc, AimDir);
	ApplySuppression(MuzzleLoc, MuzzleLoc + AimDir * MaxRange);

	BarrelHeat = FMath::Clamp(BarrelHeat + HeatPerShot, 0.f, 1.f);
	CurrentSpread = FMath::Min(CurrentSpread + SpreadPerShot, 20.f);
	LastFireTime = World->GetTimeSeconds();
	NextShotTime = LastFireTime + (1.f / FMath::Max(1.f, FireRatePerSec));
	ShotsRemaining--;
	CurrentState = EWeaponState::Firing;

	if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(GetOwner()))
	{
		Soldier->PlayFireAnimation();
	}

	// Trigger spent brass casing audio clatter
	if (World)
	{
		FTimerHandle CasingHandle;
		const FVector CasingLoc = MuzzleLoc - AimDir * 20.f;
		World->GetTimerManager().SetTimer(CasingHandle, [World, CasingLoc]()
		{
			if (!World) return;
			if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(World))
			{
				if (ASquadAIAudioManager* Mgr = AudioSys->GetActiveAudioManager())
				{
					if (Mgr->SpentShellCasingSound)
					{
						UGameplayStatics::PlaySoundAtLocation(World, Mgr->SpentShellCasingSound, CasingLoc, 0.45f, FMath::RandRange(0.9f, 1.1f), 0.f, Mgr->GunshotAttenuationSettings.Get());
					}
				}
			}
		}, 0.35f, false);
	}

	if (ShotsRemaining <= 0)
	{
		if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(GetOwner()))
		{
			if (Soldier->IsAlly())
			{
				if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
				{
					AudioSys->PlayTacticalVoiceline(ETacticalVoicelineType::Ally_Reloading, Soldier);
				}
			}
		}
	}

	OnFired.Broadcast(GetOwner(), MuzzleLoc, MuzzleLoc + AimDir * MaxRange);

	return true;
}

void UWeaponComponent::StartBurst(FVector TargetLocation)
{
	bool bPackMode = false;
	if (const ASoldierCharacter* OwnerSoldier = Cast<ASoldierCharacter>(GetOwner()))
	{
		if (OwnerSoldier->IsUsingPackPresentationMode())
		{
			if (!bAllowFireInPackPresentationMode)
			{
				return;
			}
			bPackMode = true;
		}
	}

	BurstTarget = TargetLocation;
	ShotsRemaining = BurstShots;
	bBurstActive = true;
	SetComponentTickEnabled(true);

	if (CanFire())
	{
		if (bPackMode && GetWorld())
		{
			// Give TPWCS V2 0.25 seconds to raise weapon and begin firing animation before tracing gameplay shots
			LastFireTime = GetWorld()->GetTimeSeconds();
			NextShotTime = LastFireTime + 0.25f;
		}
		else
		{
			FireAtTarget(TargetLocation);
		}
	}
}

void UWeaponComponent::StopFiring()
{
	bBurstActive = false;
	ShotsRemaining = 0;
	if (CurrentState == EWeaponState::Firing)
	{
		CurrentState = EWeaponState::Idle;
	}

	if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(GetOwner()))
	{
		Soldier->bWantsToFire = false;
	}
}

bool UWeaponComponent::CanFire() const
{
	return CurrentState != EWeaponState::Cooldown;
}

// =====================================================================
//  HITSCAN
// =====================================================================
void UWeaponComponent::PerformHitscan(FVector Start, FVector Direction, float DamageOverride, int32 PenetrationDepth)
{
	UWorld* World = GetWorld();
	if (!World) return;

	const float EffectiveDamage = (DamageOverride > 0.f) ? DamageOverride : Damage;

	// MUZZLE CLEARANCE: Ensure we aren't shooting the wall we are standing inside of
	if (PenetrationDepth == 0)
	{
		FHitResult ClearanceHit;
		FCollisionQueryParams ClearanceParams;
		ClearanceParams.AddIgnoredActor(GetOwner());
		
		// Check first 30cm of flight
		if (World->LineTraceSingleByChannel(ClearanceHit, Start, Start + Direction * 30.f, ECC_Visibility, ClearanceParams))
		{
			// ONLY offset if we hit static world geometry. 
			if (ClearanceHit.bBlockingHit && !Cast<APawn>(ClearanceHit.GetActor()))
			{
				Start = ClearanceHit.ImpactPoint + Direction * 5.f;
			}
		}
	}

	const FVector End = Start + Direction * MaxRange;

	FHitResult Hit;
	FCollisionQueryParams Params;
	Params.AddIgnoredActor(GetOwner());
	TArray<AActor*> AttachedActors;
	AddAttachedActorsRecursive(GetOwner(), AttachedActors);
	for (AActor* Attached : AttachedActors)
	{
		Params.AddIgnoredActor(Attached);
	}
	Params.bReturnPhysicalMaterial = true;

	const bool bBlocked = World->LineTraceSingleByChannel(Hit, Start, End, ECC_Visibility, Params);
	const float BlockDistance = bBlocked ? Hit.Distance : MaxRange;
	const FVector TraceEnd = bBlocked ? Hit.ImpactPoint : End;

	// Robust soldier hit pass: character meshes/capsules in many projects do not block
	// Visibility. This checks the SoldierRegistry along the bullet ray up to the first
	// world blocker, so direct shots damage soldiers while sandbags/landscape still stop bullets.
	if (ASoldierCharacter* SoldierHit = FindSoldierAlongShot(World, GetOwner(), Start, Direction, BlockDistance, 95.f))
	{
		if (SquadAIShouldIgnoreFriendlyDamage(SoldierHit, GetOwner()))
		{
			return;
		}
		const float SoldierDist = FVector::Dist(Start, SoldierHit->GetActorLocation());
		const float FalloffMult = CalcFalloff(SoldierDist);
		const float BaseDmg = (EffectiveDamage > 0.f) ? EffectiveDamage : (Damage > 0.f ? Damage : 25.0f);
		const float FinalDamage = BaseDmg * FalloffMult * DamageMultiplier * (USquadAITuning::Get() ? USquadAITuning::Get()->DamageMultiplier : 1.0f);

		if (SoldierHit->IsPlayerControlled() || (World->GetFirstPlayerController() && World->GetFirstPlayerController()->GetPawn() == SoldierHit))
		{
			AController* Instigator = GetOwner() ? GetOwner()->GetInstigatorController() : nullptr;
			EnsureTPWCSPlayerHealthInitialized(SoldierHit);
			ApplyTPWCSPlayerDamage(SoldierHit, FinalDamage, Instigator, GetOwner());
			OnHitTarget.Broadcast(SoldierHit, FinalDamage);
			return;
		}

		if (UHealthComponent* HC = SoldierHit->FindComponentByClass<UHealthComponent>())
		{
			if (bUseOwnerHealthComponentDamagePath)
			{
				HC->ApplyExternalDamage(FinalDamage, GetOwner(), GetOwner() ? GetOwner()->GetInstigatorController() : nullptr, UDamageType::StaticClass());
			}
			else
			{
				HC->ApplyDamage(FinalDamage, GetOwner());
			}
			OnHitTarget.Broadcast(SoldierHit, FinalDamage);
		}

#if ENABLE_DRAW_DEBUG
		if (bDrawDebugTraces)
		{
			DrawDebugLine(World, Start, SoldierHit->GetActorLocation() + FVector(0,0,90), FColor::Red, false, 0.3f, 0, 1.5f);
		}
#endif
		return;
	}

	// Check if shot ray passes near the local player pawn (ensures enemies damage the player even if the player pawn
	// ignores ECC_Visibility traces or is outside the SoldierRegistry).
	if (APawn* PlayerPawn = World->GetFirstPlayerController() ? World->GetFirstPlayerController()->GetPawn() : nullptr)
	{
		if (PlayerPawn && PlayerPawn != GetOwner())
		{
			if (SquadAIShouldIgnoreFriendlyDamage(PlayerPawn, GetOwner()))
			{
				return;
			}
			// Use player's center mass (origin + half height) instead of feet.
			// Shots are aimed at chest height, so checking against feet would miss.
			float PlayerHalfHeight = 88.f; // Default capsule half height
			if (const ACharacter* PlayerChar = Cast<ACharacter>(PlayerPawn))
			{
				if (const UCapsuleComponent* Capsule = PlayerChar->GetCapsuleComponent())
				{
					PlayerHalfHeight = Capsule->GetScaledCapsuleHalfHeight();
				}
			}
			const FVector PlayerCenter = PlayerPawn->GetActorLocation() + FVector(0.f, 0.f, PlayerHalfHeight);

			// Check multiple body points for robustness (head, chest, pelvis)
			const FVector BodyPoints[] = {
				PlayerCenter + FVector(0.f, 0.f, PlayerHalfHeight * 0.8f),  // Head
				PlayerCenter,                                                 // Chest
				PlayerCenter - FVector(0.f, 0.f, PlayerHalfHeight * 0.5f),  // Pelvis
			};

			bool bHitPlayer = false;
			float BestDist = FLT_MAX;
			float BestAlong = 0.f;

			for (const FVector& Point : BodyPoints)
			{
				const float DistToRay = FMath::PointDistToSegment(Point, Start, End);
				const float AlongSegment = FVector::DotProduct(Point - Start, Direction);
				if (DistToRay < 150.f && AlongSegment > 0.f && AlongSegment < BlockDistance)
				{
					if (DistToRay < BestDist)
					{
						BestDist = DistToRay;
						BestAlong = AlongSegment;
						bHitPlayer = true;
					}
				}
			}

			if (bHitPlayer)
			{
				bool bFriendlyFire = false;
				if (const IGenericTeamAgentInterface* ShooterTeamAgent = Cast<IGenericTeamAgentInterface>(GetOwner()))
				{
					if (const IGenericTeamAgentInterface* PlayerTeamAgent = Cast<IGenericTeamAgentInterface>(PlayerPawn))
					{
						const FGenericTeamId ShooterTeam = ShooterTeamAgent->GetGenericTeamId();
						const FGenericTeamId PlayerTeam = PlayerTeamAgent->GetGenericTeamId();
						if (ShooterTeam != FGenericTeamId::NoTeam && ShooterTeam == PlayerTeam)
						{
							bFriendlyFire = true;
						}
					}
				}

				if (!bFriendlyFire)
				{
					const float FalloffMult = CalcFalloff(BestAlong);
					const float BaseDmg = (EffectiveDamage > 0.f) ? EffectiveDamage : (Damage > 0.f ? Damage : 25.0f);
					const float FinalDamage = BaseDmg * FalloffMult * DamageMultiplier * (USquadAITuning::Get() ? USquadAITuning::Get()->DamageMultiplier : 1.0f);

					EnsureTPWCSPlayerHealthInitialized(PlayerPawn);

					AController* Instigator = GetOwner() ? GetOwner()->GetInstigatorController() : nullptr;
					ApplyTPWCSPlayerDamage(PlayerPawn, FinalDamage, Instigator, GetOwner());

					OnHitTarget.Broadcast(PlayerPawn, FinalDamage);
					UE_LOG(LogTemp, Verbose, TEXT("Weapon: %s hit player for %.1f damage (dist=%.0f)"), *GetNameSafe(GetOwner()), FinalDamage, BestAlong);
				}
				return;
			}

		}
	}

	if (bBlocked)
	{
		if (AActor* HitActor = Hit.GetActor())
		{
			const float FalloffMult = CalcFalloff(Hit.Distance);
			const float BaseDmg = (EffectiveDamage > 0.f) ? EffectiveDamage : (Damage > 0.f ? Damage : 25.0f);
			const float FinalDamage = BaseDmg * FalloffMult * DamageMultiplier * (USquadAITuning::Get() ? USquadAITuning::Get()->DamageMultiplier : 1.0f);

			if (APawn* PlayerPawn = World->GetFirstPlayerController() ? World->GetFirstPlayerController()->GetPawn() : nullptr)
			{
				if (HitActor == PlayerPawn || HitActor->IsAttachedTo(PlayerPawn))
				{
						if (SquadAIShouldIgnoreFriendlyDamage(PlayerPawn, GetOwner()))
						{
							return;
						}
					AController* Instigator = GetOwner() ? GetOwner()->GetInstigatorController() : nullptr;
					EnsureTPWCSPlayerHealthInitialized(PlayerPawn);
					ApplyTPWCSPlayerDamage(PlayerPawn, FinalDamage, Instigator, GetOwner());
					OnHitTarget.Broadcast(PlayerPawn, FinalDamage);
					return;
				}
			}

			if (UHealthComponent* HC = FindHealthFromHitActor(HitActor))
			{
					AActor* HealthOwner = HC->GetOwner() ? HC->GetOwner() : HitActor;
					if (SquadAIShouldIgnoreFriendlyDamage(HealthOwner, GetOwner()))
					{
						return;
					}
				if (bUseOwnerHealthComponentDamagePath)
				{
					HC->ApplyExternalDamage(FinalDamage, GetOwner(), GetOwner() ? GetOwner()->GetInstigatorController() : nullptr, UDamageType::StaticClass());
				}
				else
				{
					HC->ApplyDamage(FinalDamage, GetOwner());
				}
				OnHitTarget.Broadcast(HitActor, FinalDamage);
			}
			else
			{
					if (SquadAIShouldIgnoreFriendlyDamage(HitActor, GetOwner()))
					{
						return;
					}
				FDamageEvent DmgEvent;
				HitActor->TakeDamage(FinalDamage, DmgEvent,
					GetOwner() ? GetOwner()->GetInstigatorController() : nullptr, GetOwner());
				UE_LOG(LogTemp, Verbose, TEXT("Weapon: %s hit %s but found no HealthComponent"),
					*GetNameSafe(GetOwner()), *GetNameSafe(HitActor));
			}
		}

		// Material Bullet Penetration
		if (bEnableMaterialPenetration && PenetrationDepth < 2)
		{
			FHitResult ExitHit;
			FCollisionQueryParams ExitParams(SCENE_QUERY_STAT(SquadAIPenetration), false);
			ExitParams.AddIgnoredActor(GetOwner());
			if (Hit.GetActor()) ExitParams.AddIgnoredActor(Hit.GetActor());

			const FVector DeepPoint = Hit.ImpactPoint + Direction * MaxPenetrationThickness;
			if (World->LineTraceSingleByChannel(ExitHit, DeepPoint, Hit.ImpactPoint, ECC_Visibility, ExitParams))
			{
				const float Thickness = FVector::Dist(Hit.ImpactPoint, ExitHit.ImpactPoint);
				if (Thickness > 2.f && Thickness <= MaxPenetrationThickness)
				{
					const FVector ExitPoint = ExitHit.ImpactPoint + Direction * 4.f;
					PerformHitscan(ExitPoint, Direction, EffectiveDamage * PenetrationDamageMultiplier, PenetrationDepth + 1);
				}
			}
		}

#if ENABLE_DRAW_DEBUG
		if (bDrawDebugTraces)
		{
			DrawDebugLine(World, Start, TraceEnd, FColor::Red, false, 0.3f, 0, 1.f);
		}
#endif
	}
	else
	{
#if ENABLE_DRAW_DEBUG
		if (bDrawDebugTraces)
		{
			DrawDebugLine(World, Start, End, FColor(255, 100, 100, 40), false, 0.2f, 0, 0.5f);
		}
#endif
	}
}

// =====================================================================
//  SPREAD — applies accuracy multiplier
// =====================================================================
FVector UWeaponComponent::ApplySpread(FVector AimDir) const
{
	// Effective spread = base spread / accuracy multiplier
	// AccuracyMultiplier of 0.25 (ally) → spread * 4 = very inaccurate
	// AccuracyMultiplier of 0.65 (enemy) → spread * 1.54 = moderate
	const float EffectiveSpread = CurrentSpread / FMath::Max(0.05f, AccuracyMultiplier);
	const float HalfAngleRad = FMath::DegreesToRadians(FMath::Min(EffectiveSpread, 20.f) * 0.5f);

	return FMath::VRandCone(AimDir, HalfAngleRad);
}

// =====================================================================
//  FALLOFF
// =====================================================================
float UWeaponComponent::CalcFalloff(float Distance) const
{
	if (Distance <= FalloffStart) return 1.f;

	const float FalloffRange = MaxRange - FalloffStart;
	if (FalloffRange <= 0.f) return 1.f;

	const float Alpha = FMath::Clamp((Distance - FalloffStart) / FalloffRange, 0.f, 1.f);
	return FMath::Lerp(1.f, MinDamageMultiplier, Alpha);
}

// =====================================================================
//  SUPPRESSION — walk the SoldierRegistry for O(K) nearby check
// =====================================================================
void UWeaponComponent::ApplySuppression(FVector Start, FVector End)
{
	UWorld* World = GetWorld();
	if (!World) return;

	USoldierRegistrySubsystem* Registry = World->GetSubsystem<USoldierRegistrySubsystem>();
	if (!Registry) return;

	// Apply suppression to nearby AI soldiers
	Registry->ApplySuppressionAlongPath(Start, End, SuppressionRadius, SuppressionAmount, GetOwner());

	// BULLET WHIZ: Check if bullet passes near the player (idea from UE forums)
	// Play a 2D stereo whiz sound when a bullet passes within 500cm of the player
	APawn* Player = World->GetFirstPlayerController() ? World->GetFirstPlayerController()->GetPawn() : nullptr;
	if (Player && GetOwner() != Player) // Don't whiz your own bullets
	{
		const FVector PlayerLoc = Player->GetActorLocation();
		const FVector BulletDir = (End - Start).GetSafeNormal();
		const float BulletLen = FVector::Dist(Start, End);

		// Point-to-line distance
		const FVector ToPlayer = PlayerLoc - Start;
		const float Projection = FVector::DotProduct(ToPlayer, BulletDir);

		if (Projection > 0.f && Projection < BulletLen) // Bullet passes by, not toward/away
		{
			const FVector ClosestPoint = Start + BulletDir * Projection;
			const float DistToPlayer = FVector::Dist(PlayerLoc, ClosestPoint);

			if (DistToPlayer < 500.f && DistToPlayer > 50.f) // Near miss zone: 0.5m - 5m
			{
				// Play whiz sound at the closest point (3D positioned)
				// The sound should be a short "psssht" or "whip" sound
				// Designers assign the sound via Blueprint on the weapon
				USoundBase* Whiz = BulletWhizSound;
				if (!Whiz)
				{
					if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(World))
					{
						if (ASquadAIAudioManager* Mgr = AudioSys->GetActiveAudioManager())
						{
							Whiz = Mgr->BulletWhizBySound.Get();
						}
					}
				}

				if (Whiz)
				{
					UGameplayStatics::PlaySoundAtLocation(World, Whiz,
						ClosestPoint, FRotator::ZeroRotator,
						FMath::Clamp(1.f - (DistToPlayer / 500.f), 0.3f, 1.f),
						FMath::RandRange(0.85f, 1.15f));
				}
			}
		}
	}
}

// =====================================================================
//  MUZZLE LOCATION
// =====================================================================
FVector UWeaponComponent::GetMuzzleLocation() const
{
	if (const ACharacter* OwnerChar = Cast<ACharacter>(GetOwner()))
	{
		// In pack presentation mode, prefer the TPWCS/pack weapon mesh muzzle/trace source.
		// This keeps gameplay shots reliable while avoiding the old head/shoulder logical muzzle.
		if (const ASoldierCharacter* SoldierOwner = Cast<ASoldierCharacter>(OwnerChar))
		{
			if (SoldierOwner->IsUsingPackPresentationMode())
			{
				FTransform PackMuzzleTransform;
				if (SoldierOwner->GetMuzzleWorldTransform(PackMuzzleTransform))
				{
					return PackMuzzleTransform.GetLocation();
				}

				if (UMeshComponent* PackWeaponMesh = SoldierOwner->GetEquippedWeaponVisual())
				{
					static const FName MuzzleNames[] = { FName(TEXT("Muzzle")), FName(TEXT("muzzle")), FName(TEXT("Barrel")), FName(TEXT("barrel")) };
					for (const FName SocketName : MuzzleNames)
					{
						if (PackWeaponMesh->DoesSocketExist(SocketName))
						{
							return PackWeaponMesh->GetSocketLocation(SocketName);
						}
					}
					return PackWeaponMesh->GetComponentLocation();
				}
			}
		}

		// AI gameplay muzzle: independent of current hand animation/socket pose.
		// The visual weapon can still be in the hand, but the ballistic trace starts from
		// a stable shoulder/eye position so AI can shoot before final animations are done.
		if (bUseLogicalAIMuzzle && Cast<ASoldierCharacter>(OwnerChar))
		{
			return OwnerChar->GetActorLocation()
				+ FVector(0.f, 0.f, LogicalMuzzleHeight)
				+ OwnerChar->GetActorForwardVector() * LogicalMuzzleForwardOffset;
		}

		if (USkeletalMeshComponent* Mesh = OwnerChar->GetMesh())
		{
			if (Mesh->DoesSocketExist(MuzzleSocketName))
			{
				return Mesh->GetSocketLocation(MuzzleSocketName);
			}
		}

		return OwnerChar->GetActorLocation() +
			FVector(0, 0, OwnerChar->BaseEyeHeight) +
			OwnerChar->GetActorForwardVector() * 50.f;
	}

	return GetOwner() ? GetOwner()->GetActorLocation() : FVector::ZeroVector;
}

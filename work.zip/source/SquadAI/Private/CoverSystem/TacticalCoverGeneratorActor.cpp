#include "CoverSystem/TacticalCoverGeneratorActor.h"
#include "CoverSystem/CoverSystemSubsystem.h"
#include "Components/BoxComponent.h"
#include "Engine/World.h"
#include "DrawDebugHelpers.h"

ATacticalCoverGeneratorActor::ATacticalCoverGeneratorActor()
{
	PrimaryActorTick.bCanEverTick = false;

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SetRootComponent(SceneRoot);

	GenerationBounds = CreateDefaultSubobject<UBoxComponent>(TEXT("GenerationBounds"));
	GenerationBounds->SetupAttachment(SceneRoot);
	GenerationBounds->SetBoxExtent(FVector(2000.f, 2000.f, 500.f));
	GenerationBounds->SetCollisionProfileName(TEXT("NoCollision"));
}

void ATacticalCoverGeneratorActor::BeginPlay()
{
	Super::BeginPlay();

	if (bGenerateOnBeginPlay)
	{
		BakeCoverPoints();
	}
}

int32 ATacticalCoverGeneratorActor::BakeCoverPoints()
{
	ClearCoverPoints();

	UWorld* World = GetWorld();
	if (!World) return 0;

	const FVector Origin = GetActorLocation();
	const FVector Extents = GenerationBounds->GetUnscaledBoxExtent();

	// 1. Force scan via CoverSystemSubsystem
	if (UCoverSystemSubsystem* CoverSys = World->GetSubsystem<UCoverSystemSubsystem>())
	{
		const float Radius = FMath::Max(Extents.X, Extents.Y);
		CoverSys->ForceScanArea(Origin, Radius);
	}

	// 2. Raycast grid to find physical low/high obstacles
	const float Step = FMath::Clamp(GridSpacing, 100.f, 1000.f);
	FCollisionQueryParams QueryParams;
	QueryParams.AddIgnoredActor(this);

	for (float X = -Extents.X; X <= Extents.X; X += Step)
	{
		for (float Y = -Extents.Y; Y <= Extents.Y; Y += Step)
		{
			const FVector Start = Origin + FVector(X, Y, Extents.Z);
			const FVector End = Origin + FVector(X, Y, -Extents.Z);

			FHitResult GroundHit;
			if (World->LineTraceSingleByChannel(GroundHit, Start, End, ECC_Visibility, QueryParams))
			{
				const FVector FloorLoc = GroundHit.ImpactPoint;

				// Cast 4 horizontal rays in cardinal directions to detect nearby cover walls
				const FVector Dirs[4] = { FVector(1, 0, 0), FVector(-1, 0, 0), FVector(0, 1, 0), FVector(0, -1, 0) };
				for (int32 d = 0; d < 4; ++d)
				{
					const FVector RayStart = FloorLoc + FVector(0.f, 0.f, LowCoverHeight);
					const FVector RayEnd = RayStart + Dirs[d] * 120.f;

					FHitResult WallHit;
					if (World->LineTraceSingleByChannel(WallHit, RayStart, RayEnd, ECC_Visibility, QueryParams))
					{
						// Detected obstacle - test if low or high cover
						const FVector HighRayStart = FloorLoc + FVector(0.f, 0.f, HighCoverHeight);
						const FVector HighRayEnd = HighRayStart + Dirs[d] * 120.f;
						const bool bHigh = World->LineTraceSingleByChannel(WallHit, HighRayStart, HighRayEnd, ECC_Visibility, QueryParams);

						const FVector CoverSpot = FloorLoc - Dirs[d] * 40.f;
						++GeneratedCoverCount; // S4-4: count only (the subsystem scan feeds the AI)
						break;
					}
				}
			}
		}
	}

	UE_LOG(LogTemp, Log, TEXT("[TacticalCoverGenerator] %s generated %d cover locations across bounds"), *GetName(), GeneratedCoverCount);
	return GeneratedCoverCount;
}

void ATacticalCoverGeneratorActor::ClearCoverPoints()
{
	GeneratedCoverCount = 0;
}

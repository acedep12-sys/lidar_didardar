// EnemyPatrolAIController.cpp - S19-PATROL
#include "AI/EnemyPatrolAIController.h"
#include "Characters/EnemyPatroller.h"

AEnemyPatrolAIController::AEnemyPatrolAIController(const FObjectInitializer& OI)
	: Super(OI)
{
}

void AEnemyPatrolAIController::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (const AEnemyPatroller* Patroller = Cast<AEnemyPatroller>(GetPawn()))
	{
		ApplyPatrolEnvelope(this, Patroller->GetSpotRange(), Patroller->GetSpotHearRange());
	}
}

void AEnemyPatrolAIController::ApplyPatrolEnvelope(ASoldierAIController* Controller,
	float SpotRange, float SpotHearRange)
{
	if (!Controller)
	{
		return;
	}

	// "If they see me or allies in SHORT range, they will attack" - and, just as important, that
	// they ignore you past it. Three Min() writes; for every other enemy the values are already
	// the tuning defaults, so this is a no-op.
	Controller->DirectCombatRange = FMath::Min(Controller->DirectCombatRange, SpotRange);
	Controller->DirectCombatFallbackFireRange = FMath::Min(Controller->DirectCombatFallbackFireRange, SpotRange);
	Controller->DirectCombatCloseRangeOverride = FMath::Min(Controller->DirectCombatCloseRangeOverride,
		FMath::Max(200.f, SpotHearRange));
}

FVector AEnemyPatrolAIController::GetEffectiveMoveGoal() const
{
	if (const AEnemyPatroller* Patroller = Cast<AEnemyPatroller>(GetPawn()))
	{
		// Engaged, not merely alerted: a shout or a scripted alert leaves him on his beat
		// (walking it faster, looking around), and the move goal stays the patrol point.
		if (!Patroller->IsEngaged())
		{
			const FVector Point = Patroller->GetCurrentPatrolPoint();
			if (!Point.IsNearlyZero())
			{
				return Point;
			}
		}
	}

	// Alerted, or no route bound: behave exactly like any other enemy.
	return Super::GetEffectiveMoveGoal();
}

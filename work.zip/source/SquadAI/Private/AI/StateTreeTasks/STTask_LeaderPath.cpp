// STTask_LeaderPath.cpp
#include "AI/StateTreeTasks/STTask_LeaderPath.h"
#include "AI/SoldierAIController.h"
#include "Characters/LeaderCharacter.h"
#include "Characters/SoldierCharacter.h"
#include "Components/AimComponent.h"
#include "HUD/QuestNativeHUD.h"
#include "Quest/QuestRegistry.h"
#include "Quest/MissionZone.h" // S18-LEAD
#include "Diagnostics/SquadAISituationLog.h" // S19-HUNT
#include "SquadAITuning.h"
#include "Tasks/AITask_MoveTo.h"
#include "StateTreeExecutionContext.h"
#include "GameFramework/Pawn.h"
#include "Navigation/PathFollowingComponent.h"
#include "Kismet/GameplayStatics.h"

const UStruct* FSTTask_LeaderPath::GetInstanceDataType() const { return FSTTask_LeaderPathData::StaticStruct(); }

static ASoldierAIController* GetLeaderPathController(FStateTreeExecutionContext& Context)
{
	if (ASoldierAIController* AIC = Cast<ASoldierAIController>(Context.GetOwner()))
	{
		return AIC;
	}

	if (APawn* Pawn = Cast<APawn>(Context.GetOwner()))
	{
		return Cast<ASoldierAIController>(Pawn->GetController());
	}

	return nullptr;
}

EStateTreeRunStatus FSTTask_LeaderPath::EnterState(FStateTreeExecutionContext& Context, const FStateTreeTransitionResult& Transition) const {
	auto& D = Context.GetInstanceData<FSTTask_LeaderPathData>(*this);
	D.MoveTask = nullptr;
	D.LastTargetLoc = FVector::ZeroVector;
	D.TimeSinceRepath = 0.5f;
	D.bCombatCoverRequested = false;
	D.bMovingToCombatCover = false;
	D.CombatCoverGoal = FVector::ZeroVector;
	D.LastCombatCoverRequestTime = -1000.f;
	D.LastStuckSampleLoc = FVector::ZeroVector;
	D.StuckSampleTime = -1000.f;
	D.DirectGoalUntil = -1000.f;
	D.NextRepathTime = -1000.f;
	D.ArrivedHoldUntil = -1000.f;

	if (ASoldierAIController* AI = GetLeaderPathController(Context))
	{
		if (!AI->HasCombatThreat(0.15f) && !AI->HasNearbyHostile(FMath::Min(AI->DirectCombatRange, 1500.f)))
		{
			if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(AI->GetPawn()))
			{
				Soldier->ClearCover();
			}
		}
	}

	return EStateTreeRunStatus::Running;
}

EStateTreeRunStatus FSTTask_LeaderPath::Tick(FStateTreeExecutionContext& Context, const float DeltaTime) const {
	auto& D = Context.GetInstanceData<FSTTask_LeaderPathData>(*this);
	ASoldierAIController* AI = GetLeaderPathController(Context);
	if (!AI || !AI->GetPawn()) return EStateTreeRunStatus::Failed;

	// S18-LEAD: claim movement ownership so RunDirectMissionPathing stands down.
	AI->NotifyLeaderPathTaskActive();

	// Level startup warmup veil check — hold position until player enters world
	if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(AI))
	{
		if (HUD->IsWarmupVeilActive())
		{
			return EStateTreeRunStatus::Running;
		}
	}

	// Direct close combat check (< 15m)
	// S14-LEAD: HasCombatThreat alone froze the leader — with waves continuously
	// marching toward the zone there is ALWAYS some distant perceived contact,
	// so he cover-danced (walk a bit, run to cover, back, stop) and never
	// reached the quest zone. A perception threat only stops the march if the
	// threat actor is actually within stop range; distant contacts are aimed at
	// while walking.
	const float StopForHostileRange = FMath::Min(AI->DirectCombatRange, 1500.f);
	bool bCloseThreat = AI->HasNearbyHostile(StopForHostileRange);
	if (!bCloseThreat && AI->HasCombatThreat(0.55f))
	{
		float DistantConfidence = 0.f;
		if (AActor* DistantThreat = AI->GetPrimaryThreat(DistantConfidence))
		{
			bCloseThreat = FVector::Dist(AI->GetPawn()->GetActorLocation(),
				DistantThreat->GetActorLocation()) <= StopForHostileRange;
		}
	}
	if (bCloseThreat)
	{
		if (D.MoveTask) { D.MoveTask->ExternalCancel(); D.MoveTask = nullptr; }

		float ThreatConfidence = 0.f;
		AActor* Threat = AI->GetPrimaryThreat(ThreatConfidence);
		const FVector ThreatLoc = Threat ? Threat->GetActorLocation() : AI->GetPawn()->GetActorLocation() + AI->GetPawn()->GetActorForwardVector() * 1000.f;
		if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(AI->GetPawn()))
		{
			FSquadAIAimCommand AimCommand;
			AimCommand.Mode = ESquadAIAimMode::CombatTarget;
			AimCommand.AimLocation = ThreatLoc + FVector(0.f, 0.f, 70.f);
			AimCommand.TargetActor = Threat;
			AI->SetAimCommand(AimCommand);
		}

		const float Now = AI->GetWorld()->GetTimeSeconds();
		if (!D.bCombatCoverRequested && !AI->HasActiveCoverMoveGoal())
		{
			AI->RequestCover(ThreatLoc, FMath::Max(2500.f, USquadAITuning::Get()->TacticalCoverSearchRadius));
			D.bCombatCoverRequested = true;
			D.LastCombatCoverRequestTime = Now;
			AI->StopMovement();
			return EStateTreeRunStatus::Running;
		}

		if (AI->bCoverQueryFinished && AI->bLastCoverQuerySucceeded && AI->bHasPendingCover && !D.bMovingToCombatCover)
		{
			D.CombatCoverGoal = AI->PendingCoverResult.Location;
			D.bMovingToCombatCover = true;
			AI->SetActiveCoverMoveGoal(D.CombatCoverGoal, true);
			AI->MoveToLocation(D.CombatCoverGoal, 300.f, true, true, true, false, nullptr, true);
			return EStateTreeRunStatus::Running;
		}

		if (D.bMovingToCombatCover || AI->HasActiveCoverMoveGoal())
		{
			const float Dist = FVector::Dist(AI->GetPawn()->GetActorLocation(), D.CombatCoverGoal);
			if (Dist <= 350.f)
			{
				AI->ClearActiveCoverMoveGoal(true);
				AI->bHasCover = false;
				if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(AI->GetPawn()))
				{
					Soldier->ClearCover();
				}
				return EStateTreeRunStatus::Succeeded;
			}
			return EStateTreeRunStatus::Running;
		}

		if ((Now - D.LastCombatCoverRequestTime) > 1.5f)
		{
			AI->StopMovement();
			return EStateTreeRunStatus::Succeeded;
		}

		AI->StopMovement();
		return EStateTreeRunStatus::Running;
	}

	// No immediate close threat: clear cover and advance along mission path
	if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(AI->GetPawn()))
	{
		if (Soldier->bIsInCover || Soldier->bIsCrouched)
		{
			Soldier->ClearCover();
		}
	}

	// Player pacing. S18-LEAD: this used a hardcoded 3500 while
	// ALeaderCharacter::UpdatePacing() zeroes MaxWalkSpeed at
	// WaitForPlayerRadius (1500 by default / tuning asset). Between 15 m and
	// 35 m the task therefore kept issuing move requests at a pawn whose walk
	// speed was ZERO — he stood there twitching against the path follower and
	// never advanced. Both now use the leader's own radius.
	if (APawn* PlayerPawn = UGameplayStatics::GetPlayerPawn(AI->GetWorld(), 0))
	{
		float WaitRadius = 3500.f;
		ALeaderCharacter* LeaderPawn = Cast<ALeaderCharacter>(AI->GetPawn());
		if (LeaderPawn)
		{
			WaitRadius = FMath::Max(400.f, LeaderPawn->WaitForPlayerRadius);
		}
		const float PlayerDist = FVector::Dist(AI->GetPawn()->GetActorLocation(), PlayerPawn->GetActorLocation());
		// S19-LEADWAIT: the halt is now decided by the leader itself, which knows
		// whether the player is BEHIND (wait for him) or AHEAD (catch up), and
		// which bounds the wait so a parked player cannot pin the squad forever.
		// Asking "is he far?" here was the standstill: 15 m+ away froze the leader
		// even when he was the one who still had to walk to the quest zone.
		const bool bHaltForPlayer = LeaderPawn ? LeaderPawn->ShouldHaltForPlayer(PlayerDist)
			: (PlayerDist > WaitRadius);
		if (bHaltForPlayer)
		{
			if (D.MoveTask) { D.MoveTask->ExternalCancel(); D.MoveTask = nullptr; }
			AI->StopMovement();
			// Waiting is not stalling — keep the watchdog from arming.
			D.StuckSampleTime = -1000.f;
			D.DirectGoalUntil = -1000.f;
			D.NextRepathTime = -1000.f;
			return EStateTreeRunStatus::Running;
		}
	}

	D.TimeSinceRepath += DeltaTime;

	// ===== S19-HUNT =========================================================
	// "After the leader reaches the quest area he does not try to track down the enemies."
	// The arrival hold below stopped him dead at the objective while the mission still
	// needed every enemy killed. The controller owns the decision (it is the only place
	// BOTH movement owners - this task and RunDirectMissionPathing - read), so here we only
	// need to know whether the leader has something to hunt, and to stop the two blocks
	// that would otherwise freeze him: the arrival hold and the stall watchdog.
	AActor* HuntTarget = AI->GetLeaderHuntTarget();

	FVector GoalLoc = AI->GetEffectiveMoveGoal();

	// S18-LEAD: stall watchdog. Sample the pawn every 1.5 s; if it travelled
	// less than 150 cm while free to march, bypass the spline corridor and head
	// straight for the mission zone for the next 6 s. This breaks the
	// pace-back-and-forth loop that kept him short of the quest zone.
	{
		const FVector Here = AI->GetPawn()->GetActorLocation();
		const float Now = AI->GetWorld()->GetTimeSeconds();
		if (D.StuckSampleTime < 0.f || (Now - D.StuckSampleTime) >= 1.5f)
		{
			if (D.StuckSampleTime > 0.f && FVector::Dist2D(Here, D.LastStuckSampleLoc) < 150.f)
			{
				D.DirectGoalUntil = Now + 6.f;
			}
			D.LastStuckSampleLoc = Here;
			D.StuckSampleTime = Now;
		}

		if (Now <= D.DirectGoalUntil && !HuntTarget)
		{
			FVector Direct = FVector::ZeroVector;
			if (AMissionZone* Mission = AI->FindActiveMissionZone())
			{
				Direct = Mission->GetActorLocation();
			}
			if (Direct.IsNearlyZero())
			{
				if (const UQuestRegistry* Reg = AI->GetWorld()->GetSubsystem<UQuestRegistry>())
				{
					Direct = Reg->CurrentActiveGoal;
				}
			}
			if (!Direct.IsNearlyZero())
			{
				GoalLoc = Direct;
			}
		}
	}

	if (GoalLoc.IsNearlyZero()) return EStateTreeRunStatus::Running;

	// S18-LEAD: a goal a few metres off the navmesh (zone pivot inside geometry,
	// above a trench floor, …) produces a partial path that dies short — the
	// leader then re-paths every single tick and jitters on the spot. Snap the
	// goal onto the navmesh first.
	GoalLoc = AI->ProjectToNav(GoalLoc);

	// S18-LEAD: arrival hold. Once he is on the goal, stop issuing new moves;
	// re-check every 2 s instead of fighting the path follower each tick.
	{
		const float NowA = AI->GetWorld()->GetTimeSeconds();
		// S18-LEAD: GoalLoc is usually a MOVING lookahead point on the corridor.
		// Holding position whenever we are near THAT would stutter the march, so
		// the arrival hold only applies when we are near the real mission goal.
		FVector FinalGoal = FVector::ZeroVector;
		if (AMissionZone* MZ = AI->FindActiveMissionZone())
		{
			FinalGoal = MZ->GetActorLocation();
		}
		if (FinalGoal.IsNearlyZero())
		{
			if (const UQuestRegistry* Reg2 = AI->GetWorld()->GetSubsystem<UQuestRegistry>())
			{
				FinalGoal = Reg2->CurrentActiveGoal;
			}
		}
		const bool bNearFinal = !FinalGoal.IsNearlyZero()
			&& FVector::Dist2D(AI->GetPawn()->GetActorLocation(), FinalGoal) <= 220.f;
		if (bNearFinal && !HuntTarget)
		{
			if (D.MoveTask) { D.MoveTask->ExternalCancel(); D.MoveTask = nullptr; }
			AI->StopMovement();
			D.ArrivedHoldUntil = NowA + 2.f;
			D.DirectGoalUntil = -1000.f;
			return EStateTreeRunStatus::Running;
		}
		if (HuntTarget)
		{
			// S19-HUNT: arrived, but the objective is not finished. Retarget onto the
			// enemy and let the move code below drive him there. The arrival hold is
			// cleared so it cannot re-freeze him on the next tick.
			D.ArrivedHoldUntil = -1000.f;
			D.DirectGoalUntil = -1000.f;
			GoalLoc = HuntTarget->GetActorLocation();
		}
		if (NowA <= D.ArrivedHoldUntil)
		{
			return EStateTreeRunStatus::Running;
		}
	}

	UPathFollowingComponent* PFC = AI->GetPathFollowingComponent();
	const bool bSameGoal = FVector::DistSquared(GoalLoc, D.LastTargetLoc) < 250000.f; // 500 units
	const bool bPathActuallyMoving = PFC && PFC->GetStatus() == EPathFollowingStatus::Moving;

	if (D.MoveTask && !D.MoveTask->IsFinished() && bSameGoal && bPathActuallyMoving)
	{
		return EStateTreeRunStatus::Running;
	}

	// S18-LEAD: never re-issue a move more than twice a second. Without this a
	// failing/partial path restarts every tick and reads as pacing in place.
	{
		const float NowR = AI->GetWorld()->GetTimeSeconds();
		if (NowR < D.NextRepathTime)
		{
			return EStateTreeRunStatus::Running;
		}
		D.NextRepathTime = NowR + 0.5f;
	}

	if (D.MoveTask) { D.MoveTask->ExternalCancel(); D.MoveTask = nullptr; }

	D.MoveTask = UAITask_MoveTo::AIMoveTo(AI, GoalLoc, nullptr, 250.f, EAIOptionFlag::Default, EAIOptionFlag::Enable);
	if (D.MoveTask) D.MoveTask->ReadyForActivation();
	
	D.LastTargetLoc = GoalLoc;
	D.TimeSinceRepath = 0.f;
	return EStateTreeRunStatus::Running;
}

void FSTTask_LeaderPath::ExitState(FStateTreeExecutionContext& Context, const FStateTreeTransitionResult& Transition) const {
	auto& D = Context.GetInstanceData<FSTTask_LeaderPathData>(*this);
	if (D.MoveTask) { D.MoveTask->ExternalCancel(); D.MoveTask = nullptr; }
}

// STTask_EnemyMission.cpp
#include "AI/StateTreeTasks/STTask_EnemyMission.h"
#include "AI/SoldierAIController.h"
#include "HUD/QuestNativeHUD.h"
#include "Quest/QuestZone.h"
#include "Quest/QuestChain.h"
#include "Quest/MissionZone.h"
#include "StateTreeExecutionContext.h"
#include "Navigation/PathFollowingComponent.h"
#include "NavigationSystem.h"
#include "Engine/Engine.h"
#include "HAL/IConsoleManager.h"

// S11-DIAG: `SquadAI.DebugEnemyGoals 1` prints, per enemy, where its goal came
// from, how far it is, and what MoveToLocation actually returned. The move
// result was previously swallowed into bMoveRequested and never surfaced, so a
// navmesh/pathing failure was indistinguishable from "no goal was resolved".
static TAutoConsoleVariable<int32> CVarSquadAIDebugEnemyGoals(
	TEXT("SquadAI.DebugEnemyGoals"),
	0,
	TEXT("1 = log/print enemy mission goal source and MoveToLocation results."),
	ECVF_Cheat);

static const TCHAR* SquadAIMoveResultToString(EPathFollowingRequestResult::Type R)
{
	switch (R)
	{
	case EPathFollowingRequestResult::Failed:            return TEXT("Failed");
	case EPathFollowingRequestResult::AlreadyAtGoal:     return TEXT("AlreadyAtGoal");
	case EPathFollowingRequestResult::RequestSuccessful: return TEXT("RequestSuccessful");
	default:                                             return TEXT("Unknown");
	}
}
#include "GameFramework/Pawn.h"
#include "Kismet/GameplayStatics.h"
#include "EngineUtils.h"

const UStruct* FSTTask_EnemyMission::GetInstanceDataType() const { return FSTTask_EnemyMissionData::StaticStruct(); }

static ASoldierAIController* GetEnemyMissionController(FStateTreeExecutionContext& Context)
{
	if (ASoldierAIController* AIC = Cast<ASoldierAIController>(Context.GetOwner()))
	{
		return AIC;
	}

	if (APawn* Pawn = Cast<APawn>(Context.GetOwner()))
	{
		return Cast<ASoldierAIController>(Pawn->GetController());
	}

	return nullptr;
}

EStateTreeRunStatus FSTTask_EnemyMission::EnterState(FStateTreeExecutionContext& Context, const FStateTreeTransitionResult& Transition) const {
	auto& D = Context.GetInstanceData<FSTTask_EnemyMissionData>(*this);
	D.LastGoalLoc = FVector::ZeroVector;
	D.TimeSinceRepath = 2.0f; // G-6: allow immediate first path under the 2s same-goal throttle
	D.bMoveRequested = false;
	D.bWasAtGoal = false;
	return EStateTreeRunStatus::Running;
}

EStateTreeRunStatus FSTTask_EnemyMission::Tick(FStateTreeExecutionContext& Context, const float DeltaTime) const {
	auto& D = Context.GetInstanceData<FSTTask_EnemyMissionData>(*this);
	ASoldierAIController* AI = GetEnemyMissionController(Context);
	if (!AI || !AI->GetPawn()) return EStateTreeRunStatus::Failed;

	// Level startup warmup veil check — hold position until player enters world
	if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(AI))
	{
		if (HUD->IsWarmupVeilActive())
		{
			return EStateTreeRunStatus::Running;
		}
	}
	
	D.TimeSinceRepath += DeltaTime;
	FVector GoalLoc = AI->GetEffectiveMoveGoal();
	const TCHAR* GoalSource = GoalLoc.IsNearlyZero() ? TEXT("none") : TEXT("EffectiveMoveGoal(CurrentGoal/Registry)");

	// Primary goal resolution: hunt known threats, but only within HunterMaxRange.
	// Beyond that the enemy advances on its mission zone instead of bee-lining across
	// the map to the player (this caused omniscient cross-map hunting and contact
	// from nowhere).
	if (!AI->GetPawn()) return EStateTreeRunStatus::Failed;
	const FVector SelfLoc = AI->GetPawn()->GetActorLocation();
	const float HunterMaxRangeSq = FMath::Square(12000.f);
	float ThreatConf = 0.f;
	float ThreatDistSq = TNumericLimits<float>::Max();
	// S14-FIX: was inferred later via (GoalSource == TEXT("Threat")) - a POINTER
	// comparison on two string literals (MSVC C4130, warning-as-error). Track it
	// as a bool at the single assignment site instead.
	bool bGoalIsThreat = false;
	if (AActor* Threat = AI->GetPrimaryThreat(ThreatConf))
	{
		const FVector ThreatLoc = Threat->GetActorLocation();
		ThreatDistSq = FVector::DistSquared(SelfLoc, ThreatLoc);
		if (ThreatDistSq <= HunterMaxRangeSq)
		{
			GoalLoc = ThreatLoc;
			GoalSource = TEXT("Threat");
			bGoalIsThreat = true;
		}
	}
	// S5-7a: REMOVED the unconditional player fallback branch. It hunted the player with
	// ZERO perception inside 12,000 cm (omniscient homing before mission movement).
	// Perceived threats (Memory) still drive hunting above; everyone else advances on
	// their active mission zone — the intended stand-and-advance behavior.
	if (GoalLoc.IsNearlyZero())
	{
		if (AMissionZone* ActiveMission = AI->FindActiveMissionZone())
		{
			GoalLoc = ActiveMission->GetActorLocation();
			GoalSource = TEXT("MissionZone");
		}
		else if (AQuestChain* Chain = AQuestChain::FindPreferred(AI->GetWorld(), false))
		{
			if (AMissionZone* Cur = Chain->GetCurrentMission())
			{
				GoalLoc = Cur->GetActorLocation();
				GoalSource = TEXT("QuestChain");
			}
		}
	}

	// S11-AI: QuestZone fallback.
	// Enemies only ever advanced on a MissionZone or an active QuestChain. On a
	// map whose objective is authored as a plain AQuestZone (no MissionZone and
	// no chain) GoalLoc stayed zero, this task returned Running every tick, and
	// the enemies simply stood where they spawned — the "enemies don't go to the
	// quest zone" bug. The leader controller already had this fallback
	// (RunDirectMissionPathing), but that function early-outs on
	// !IsLeaderController(), so nothing covered the enemy side.
	// Note QuestZone.h was already included here but never used.
	if (GoalLoc.IsNearlyZero())
	{
		if (AQuestZone* Zone = AI->GetFallbackQuestZone())
		{
			GoalLoc = Zone->GetActorLocation();
			GoalSource = TEXT("QuestZone(S11-AI fallback)");
		}
	}

	// S13-AI: ENGAGEMENT HOLD.
	// This task only knows how to walk somewhere. Once a threat is inside weapon
	// range the enemy must STOP and let the combat/aim states run - otherwise the
	// move request is re-issued every repath, the pawn is permanently in
	// "path following" and never settles into the aim pose, so it just sprints
	// into the player's face.
	//
	// This became visible when the QuestZone fallback (S11-AI) was added: before
	// it, enemies with no MissionZone simply had no goal and stood still, which
	// accidentally let the combat states run. Now that they always have somewhere
	// to be, the stop condition has to be explicit.
	static const float EngageHoldRange = 2200.f;   // start shooting, stop walking
	if (ThreatDistSq <= FMath::Square(EngageHoldRange))
	{
		if (UPathFollowingComponent* HoldPFC = AI->GetPathFollowingComponent())
		{
			if (HoldPFC->GetStatus() == EPathFollowingStatus::Moving)
			{
				AI->StopMovement();
			}
		}
		D.bMoveRequested = false;
		if (CVarSquadAIDebugEnemyGoals.GetValueOnGameThread() != 0)
		{
			UE_LOG(LogTemp, Warning, TEXT("[SquadAI][EnemyGoal] %s: ENGAGE HOLD at %.0fcm - stopping to fire."),
				*GetNameSafe(AI->GetPawn()), FMath::Sqrt(ThreatDistSq));
		}
		return EStateTreeRunStatus::Running;
	}

	if (GoalLoc.IsNearlyZero())
	{
		if (CVarSquadAIDebugEnemyGoals.GetValueOnGameThread() != 0)
		{
			UE_LOG(LogTemp, Warning, TEXT("[SquadAI][EnemyGoal] %s: NO GOAL RESOLVED (no threat, no MissionZone, no QuestChain, no QuestZone)."),
				*GetNameSafe(AI->GetPawn()));
		}
		return EStateTreeRunStatus::Running;
	}

	// S14-NAV: GROUND THE GOAL BEFORE MOVING.
	// Field log: every enemy resolved a valid MissionZone goal and then failed
	// with move=Failed goalOnNavmesh=NO while the user insists the navmesh
	// under the zone is built. Both can be true at once: this task fed
	// MissionZone->GetActorLocation() RAW into MoveToLocation, whose
	// destination projection uses a small extent - a zone MARKER hovering
	// above the terrain (or a goal cell World Partition hasn't streamed in)
	// fails projection and the request dies before pathfinding even runs.
	// Two stages:
	//   1. Re-project the goal with a huge VERTICAL extent (+-100 m) so a
	//      floating marker snaps to the navmesh beneath it.
	//   2. If that still fails (cell not streamed / genuine hole), walk the
	//      goal back toward the enemy in 10% steps and take the first point
	//      that lands on navmesh - march as far toward the zone as the world
	//      allows instead of standing still forever; re-extends automatically
	//      on later repaths as cells stream in.
	UNavigationSystemV1* NavSys = FNavigationSystem::GetCurrent<UNavigationSystemV1>(AI->GetWorld());
	bool bGoalGrounded = false;
	const FVector RawGoalLoc = GoalLoc;
	if (NavSys)
	{
		const FVector GroundExtent(500.f, 500.f, 10000.f);
		FNavLocation Grounded;
		if (NavSys->ProjectPointToNavigation(GoalLoc, Grounded, GroundExtent))
		{
			GoalLoc = Grounded.Location;
			bGoalGrounded = true;
		}
		else
		{
			const FVector SelfForGoal = AI->GetPawn()->GetActorLocation();
			for (float Frac = 0.9f; Frac >= 0.09f; Frac -= 0.1f)
			{
				const FVector Candidate = FMath::Lerp(SelfForGoal, GoalLoc, Frac);
				if (NavSys->ProjectPointToNavigation(Candidate, Grounded, GroundExtent))
				{
					GoalLoc = Grounded.Location;
					bGoalGrounded = true;
					GoalSource = TEXT("WalkedBack(S14-NAV partial)");
					break;
				}
			}
		}
	}

	UPathFollowingComponent* PFC = AI->GetPathFollowingComponent();
	// S13-AI: closing on a THREAT stops at firing distance; closing on an
	// objective still walks right onto it. (S14-FIX: bGoalIsThreat is set at
	// the threat-goal assignment above, not string-compared here.)
	const float AcceptanceRadius = bGoalIsThreat ? 1800.f : 300.f;
	const float DistToGoal = FVector::Dist(AI->GetPawn()->GetActorLocation(), GoalLoc);
	const bool bPathMoving = PFC && PFC->GetStatus() == EPathFollowingStatus::Moving;
	const bool bAtGoal = DistToGoal <= (D.bWasAtGoal ? 450.f : AcceptanceRadius); // G-6: arrival hysteresis
	const float Now = AI->GetWorld()->GetTimeSeconds();

	// If already at goal, remain alert
	D.bWasAtGoal = bAtGoal;
	if (bAtGoal)
	{
		return EStateTreeRunStatus::Running;
	}

	// G-6: throttle same-goal repaths whether moving OR idle-failed (failed requests used
	// to re-fire every tick = pathfinding spam + move jitter = "wandering"; idle backs off longer).
	const bool bSameGoal = FVector::DistSquared(GoalLoc, AI->LastMissionMoveGoal) < 40000.f; // 200 units
	if (bSameGoal && D.TimeSinceRepath < (bPathMoving ? 2.0f : 3.0f))
	{
		return EStateTreeRunStatus::Running;
	}

	const EPathFollowingRequestResult::Type Result = AI->MoveToLocation(
		GoalLoc,
		AcceptanceRadius,
		true,   // bStopOnOverlap
		true,   // bUsePathfinding
		true,   // bProjectDestinationToNavigation
		false,  // bCanStrafe
		nullptr,
		true    // bAllowPartialPath
	);

	if (CVarSquadAIDebugEnemyGoals.GetValueOnGameThread() != 0)
	{
		// S14-NAV: grounding already answered "is the goal on navmesh"; also
		// print the raw marker height above the grounded point - a large
		// goalDropZ with grounded=YES is the smoking gun for a floating
		// MissionZone marker (the pre-S14-NAV failure mode).
		const FString Msg = FString::Printf(
			TEXT("[SquadAI][EnemyGoal] %s src=%s dist=%.0fcm move=%s grounded=%s goalDropZ=%.0fcm"),
			*GetNameSafe(AI->GetPawn()), GoalSource, DistToGoal,
			SquadAIMoveResultToString(Result),
			bGoalGrounded ? TEXT("YES") : TEXT("NO"),
			RawGoalLoc.Z - GoalLoc.Z);
		UE_LOG(LogTemp, Warning, TEXT("%s"), *Msg);
		if (GEngine && Result != EPathFollowingRequestResult::RequestSuccessful)
		{
			GEngine->AddOnScreenDebugMessage(-1, 4.f, FColor::Orange, Msg);
		}
	}

	D.LastGoalLoc = GoalLoc;
	D.TimeSinceRepath = 0.f;
	D.bMoveRequested = (Result == EPathFollowingRequestResult::RequestSuccessful || Result == EPathFollowingRequestResult::AlreadyAtGoal);
	AI->LastMissionMoveGoal = GoalLoc;
	AI->LastMissionMoveRequestTime = Now;

	return EStateTreeRunStatus::Running;
}

void FSTTask_EnemyMission::ExitState(FStateTreeExecutionContext& Context, const FStateTreeTransitionResult& Transition) const {
	auto& D = Context.GetInstanceData<FSTTask_EnemyMissionData>(*this);
	D.bMoveRequested = false;
}

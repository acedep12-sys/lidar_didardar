// STTask_FollowLeader.cpp — V-formation follow with stable repath + opportunistic fire
#include "AI/StateTreeTasks/STTask_FollowLeader.h"
#include "StateTreeExecutionContext.h"
#include "AI/SoldierAIController.h"
#include "Characters/SoldierCharacter.h"
#include "Characters/AllySoldier.h"
#include "Characters/LeaderCharacter.h"
#include "Components/WeaponComponent.h"
#include "Components/AimComponent.h"
#include "Tasks/AITask_MoveTo.h"
#include "Navigation/PathFollowingComponent.h"
#include "Kismet/GameplayStatics.h"
#include "EngineUtils.h"
#include "Performance/SoldierRegistrySubsystem.h"

const UStruct* FSTTask_FollowLeader::GetInstanceDataType() const
{
	return FSTTask_FollowLeaderData::StaticStruct();
}

// Find the leader in the world
static APawn* FindLeader(UWorld* World, APawn* AllyPawn, TWeakObjectPtr<APawn>& Cache, float& CacheTime)
{
	if (AAllySoldier* Ally = Cast<AAllySoldier>(AllyPawn))
	{
		if (Ally->LeaderOverride.IsValid())
		{
			return Cast<APawn>(Ally->LeaderOverride.Get());
		}
	}

	const float Now = World ? World->GetTimeSeconds() : 0.f;
	if (APawn* Cached = Cache.Get())
	{
		if (!Cached->IsActorBeingDestroyed())
		{
			return Cached;
		}
	}
	// Miss cache: do not TActorIterator the world every StateTree tick.
	if (CacheTime > 0.f && (Now - CacheTime) < 0.5f)
	{
		return nullptr;
	}

	APawn* Found = nullptr;
	if (USoldierRegistrySubsystem* SR = World ? World->GetSubsystem<USoldierRegistrySubsystem>() : nullptr)
	{
		for (const TWeakObjectPtr<ASoldierCharacter>& W : SR->GetAllSoldiers())
		{
			if (ALeaderCharacter* L = Cast<ALeaderCharacter>(W.Get()))
			{
				Found = L;
				break;
			}
		}
	}
	if (!Found && World)
	{
		for (TActorIterator<ALeaderCharacter> It(World); It; ++It)
		{
			Found = *It;
			break;
		}
	}
	Cache = Found;
	CacheTime = Now;
	return Found;
}

static FVector ComputeSlotPosition(APawn* Leader, int32 Slot, float Spacing)
{
	const FVector LeaderLoc = Leader->GetActorLocation();
	const FVector LeaderFwd = Leader->GetActorForwardVector();
	const FVector LeaderRight = Leader->GetActorRightVector();

	const int32 Row = (Slot / 2) + 1;
	const float Side = (Slot % 2 == 0) ? 1.f : -1.f;
	const float SlackSpacing = Spacing * 1.75f;

	return LeaderLoc
		- LeaderFwd * (Row * SlackSpacing * 0.9f)
		+ LeaderRight * (Side * Row * SlackSpacing * 0.7f);
}

EStateTreeRunStatus FSTTask_FollowLeader::EnterState(
	FStateTreeExecutionContext& Context,
	const FStateTreeTransitionResult& Transition) const
{
	auto& D = Context.GetInstanceData<FSTTask_FollowLeaderData>(*this);
	D.MoveTask = nullptr;
	D.LastTargetSlot = FVector::ZeroVector;
	D.TimeSinceRepath = MinRepathInterval; // Trigger immediate first path
	D.ShootTimer = 0.f;
	D.bMoving = false;

	return EStateTreeRunStatus::Running; // Runs continuously
}

EStateTreeRunStatus FSTTask_FollowLeader::Tick(
	FStateTreeExecutionContext& Context,
	const float DeltaTime) const
{
	auto& D = Context.GetInstanceData<FSTTask_FollowLeaderData>(*this);

	ASoldierAIController* AI = Cast<ASoldierAIController>(Context.GetOwner());
	if (!AI || !AI->GetPawn()) return EStateTreeRunStatus::Failed;

	APawn* Pawn = AI->GetPawn();
	AAllySoldier* Ally = Cast<AAllySoldier>(Pawn);

	// If this follower is downed/injured, stay immobilized in crouching/sitting pose
	if (ASoldierCharacter* SelfChar = Cast<ASoldierCharacter>(Pawn))
	{
		if (SelfChar->IsDowned())
		{
			if (D.MoveTask) { D.MoveTask->ExternalCancel(); D.MoveTask = nullptr; }
			AI->StopMovement();
			AI->StopCombatPresentation();
			SelfChar->Crouch();
			return EStateTreeRunStatus::Running;
		}
	}

	// Stay in Follow. Succeeding on any threat lets another StateTree task
	// MoveTo the mission / enemy, then this task pulls back to the leader (zigzag).
	UWorld* World = AI->GetWorld();

	// ---- DOWNED SQUADMATE REVIVE PRIORITY ----
	if (USoldierRegistrySubsystem* SR = World ? World->GetSubsystem<USoldierRegistrySubsystem>() : nullptr)
	{
		for (const TWeakObjectPtr<ASoldierCharacter>& WeakS : SR->GetAllSoldiers())
		{
			ASoldierCharacter* DownedSoldier = WeakS.Get();
			if (!DownedSoldier || DownedSoldier == Pawn || !DownedSoldier->IsAlly() || !DownedSoldier->IsDowned())
			{
				continue;
			}

			const float DistToDowned = FVector::Dist(Pawn->GetActorLocation(), DownedSoldier->GetActorLocation());
			if (DistToDowned <= 2500.f)
			{
				if (DistToDowned > 180.f)
				{
					AI->MoveToActor(DownedSoldier, 120.f);
				}
				else
				{
					if (ASoldierCharacter* SelfChar = Cast<ASoldierCharacter>(Pawn))
					{
						SelfChar->Crouch();
					}
					DownedSoldier->ApplyReviveProgress(DeltaTime, Pawn);
					if (!DownedSoldier->IsDowned())
					{
						if (ASoldierCharacter* SelfChar = Cast<ASoldierCharacter>(Pawn))
						{
							SelfChar->UnCrouch();
						}
					}
				}
				return EStateTreeRunStatus::Running;
			}
		}
	}

	APawn* Leader = FindLeader(World, Pawn, D.CachedLeader, D.LeaderCacheTime);
	if (!Leader) return EStateTreeRunStatus::Running;

	D.TimeSinceRepath += DeltaTime;

	const int32 Slot = Ally ? Ally->FormationSlot : FormationSlot;
	FVector DesiredSlot = AI->GetAllyCorridorSlot(Leader, Slot, SlotSpacing);
	if (DesiredSlot.IsNearlyZero())
	{
		DesiredSlot = ComputeSlotPosition(Leader, Slot, SlotSpacing);
	}

	const float DistToSlot = FVector::Dist(Pawn->GetActorLocation(), DesiredSlot);
	const float SlotDrift = D.LastTargetSlot.IsNearlyZero()
		? TNumericLimits<float>::Max()
		: FVector::Dist(DesiredSlot, D.LastTargetSlot);

	const float StaggerWait = FMath::Max(MinRepathInterval, 1.15f) + static_cast<float>(FMath::Max(0, Slot)) * 0.2f;
	const bool bSlotMoved = SlotDrift > FMath::Max(RepathThreshold, 550.f);
	const bool bNeedCatchUp = DistToSlot > AcceptanceRadius * 1.35f;
	const bool bShouldRepath = (bSlotMoved || bNeedCatchUp || !D.bMoving)
		&& D.TimeSinceRepath >= StaggerWait
		&& DistToSlot > AcceptanceRadius;

	if (bShouldRepath)
	{
		if (D.MoveTask)
		{
			D.MoveTask->ExternalCancel();
			D.MoveTask = nullptr;
		}
		if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(Pawn))
		{
			Soldier->ClearCover();
		}

		const float Seed = static_cast<float>((Pawn->GetUniqueID() % 97) + Slot * 13);
		const FVector Jitter(FMath::Sin(Seed) * 55.f, FMath::Cos(Seed * 1.7f) * 55.f, 0.f);
		const FVector LooseSlot = AI->NudgeOutOfFire(Pawn->GetActorLocation(), DesiredSlot + Jitter);
		const float Accept = AcceptanceRadius + 80.f;
		const EPathFollowingRequestResult::Type Result = AI->MoveToLocation(
			LooseSlot, Accept, true, true, true, false, nullptr, true);
		D.bMoving = (Result == EPathFollowingRequestResult::RequestSuccessful
			|| Result == EPathFollowingRequestResult::AlreadyAtGoal);
		D.LastTargetSlot = DesiredSlot;
		D.TimeSinceRepath = 0.f;
	}

	// ---- SHOOTING ----
	if (bShootWhileFollowing)
	{
		float Confidence = 0.f;
		AActor* Threat = AI->GetPrimaryThreat(Confidence);

		if (Threat && Confidence > 0.3f)
		{
			D.ShootTimer += DeltaTime;
			if (D.ShootTimer >= ShootCooldown)
			{
				D.ShootTimer = 0.f;

				// Aim and fire (with terrible ally accuracy)
				AI->SetCombatAimTarget(Threat->GetActorLocation() + FVector(0.f, 0.f, 70.f), ESquadAIAimMode::CombatTarget, Threat);
				AI->TryStartBurstAtCurrentAim();
			}
		}
		else
		{
			AI->StopCombatPresentation();
			D.ShootTimer = 0.f;
		}
	}

	return EStateTreeRunStatus::Running; // Never completes — runs until state transition
}

void FSTTask_FollowLeader::ExitState(
	FStateTreeExecutionContext& Context,
	const FStateTreeTransitionResult& Transition) const
{
	auto& D = Context.GetInstanceData<FSTTask_FollowLeaderData>(*this);

	if (D.MoveTask)
	{
		D.MoveTask->ExternalCancel();
		D.MoveTask = nullptr;
	}

	ASoldierAIController* AI = Cast<ASoldierAIController>(Context.GetOwner());
	if (AI && AI->GetPawn())
	{
		if (ASoldierCharacter* S = Cast<ASoldierCharacter>(AI->GetPawn()))
		{
			AI->StopCombatPresentation();
		}
	}
}

// EnemyFireteamSubsystem.cpp — Wave enemies work as a squad
#include "AI/EnemyFireteamSubsystem.h"
#include "AI/SoldierAIController.h"
#include "Characters/SoldierCharacter.h"
#include "Kismet/GameplayStatics.h"
#include "GameFramework/Pawn.h"
#include "Engine/World.h"
#include "TimerManager.h"

void UEnemyFireteamSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
	UE_LOG(LogTemp, Warning, TEXT("[TEAMDBG] EnemyFireteamSubsystem active — wave enemies will squad up."));
}

void UEnemyFireteamSubsystem::Deinitialize()
{
	StopAssignTimer();
	Teams.Empty();
	Super::Deinitialize();
}

void UEnemyFireteamSubsystem::RegisterMember(APawn* Pawn, uint32 TeamKey)
{
	if (!Pawn || TeamKey == 0)
	{
		return;
	}

	const int32 Existing = FindTeamIndexForPawn(Pawn);
	if (Existing != INDEX_NONE)
	{
		return;
	}

	int32 Idx = FindTeamIndex(TeamKey);
	if (Idx == INDEX_NONE)
	{
		FEnemyFireteam NewTeam;
		NewTeam.TeamKey = TeamKey;
		Idx = Teams.Add(NewTeam);
	}

	FEnemyFireteamMember M;
	M.Pawn = Pawn;
	M.Slot = Teams[Idx].Members.Num();
	Teams[Idx].Members.Add(M);

	if (ASoldierAIController* AI = GetAI(Pawn))
	{
		AI->bInEnemyFireteam = true;
		AI->FireteamSlot = M.Slot;
	}

	UE_LOG(LogTemp, Warning, TEXT("[TEAMDBG] %s joined fireteam %u (size=%d)"),
		*GetNameSafe(Pawn), TeamKey, Teams[Idx].Members.Num());
	EnsureAssignTimer();
}

void UEnemyFireteamSubsystem::UnregisterMember(APawn* Pawn)
{
	if (!Pawn)
	{
		return;
	}
	for (int32 t = Teams.Num() - 1; t >= 0; --t)
	{
		FEnemyFireteam& Team = Teams[t];
		for (int32 i = Team.Members.Num() - 1; i >= 0; --i)
		{
			if (Team.Members[i].Pawn.Get() == Pawn)
			{
				Team.Members.RemoveAtSwap(i, EAllowShrinking::No);
			}
		}
		if (Team.Members.Num() == 0)
		{
			Teams.RemoveAtSwap(t, EAllowShrinking::No);
		}
	}
	if (ASoldierAIController* AI = GetAI(Pawn))
	{
		AI->bInEnemyFireteam = false;
		AI->FireteamRole = EEnemyFireteamRole::Unassigned;
		AI->FireteamMoveGoal = FVector::ZeroVector;
		AI->FireteamSharedThreat.Reset();
	}
	if (Teams.Num() == 0)
	{
		StopAssignTimer();
	}
}

bool UEnemyFireteamSubsystem::IsInFireteam(const APawn* Pawn) const
{
	return FindTeamIndexForPawn(Pawn) != INDEX_NONE;
}

bool UEnemyFireteamSubsystem::IsTickable() const
{
	return false;
}

void UEnemyFireteamSubsystem::EnsureAssignTimer()
{
	UWorld* World = GetWorld();
	if (!World || World->GetTimerManager().IsTimerActive(AssignTimer))
	{
		return;
	}
	World->GetTimerManager().SetTimer(AssignTimer, this, &UEnemyFireteamSubsystem::RunAssign, AssignInterval, true);
}

void UEnemyFireteamSubsystem::StopAssignTimer()
{
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(AssignTimer);
	}
}

void UEnemyFireteamSubsystem::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void UEnemyFireteamSubsystem::RunAssign()
{
	for (int32 t = Teams.Num() - 1; t >= 0; --t)
	{
		CompactTeam(Teams[t]);
		if (Teams[t].Members.Num() == 0)
		{
			Teams.RemoveAtSwap(t, EAllowShrinking::No);
			continue;
		}
		AssignTeam(Teams[t]);
	}
	if (Teams.Num() == 0)
	{
		StopAssignTimer();
	}
}

int32 UEnemyFireteamSubsystem::FindTeamIndex(uint32 TeamKey) const
{
	for (int32 i = 0; i < Teams.Num(); ++i)
	{
		if (Teams[i].TeamKey == TeamKey)
		{
			return i;
		}
	}
	return INDEX_NONE;
}

int32 UEnemyFireteamSubsystem::FindTeamIndexForPawn(const APawn* Pawn) const
{
	if (!Pawn)
	{
		return INDEX_NONE;
	}
	for (int32 t = 0; t < Teams.Num(); ++t)
	{
		for (const FEnemyFireteamMember& M : Teams[t].Members)
		{
			if (M.Pawn.Get() == Pawn)
			{
				return t;
			}
		}
	}
	return INDEX_NONE;
}

bool UEnemyFireteamSubsystem::IsMemberAlive(APawn* Pawn)
{
	if (!Pawn || Pawn->IsActorBeingDestroyed())
	{
		return false;
	}
	if (ASoldierCharacter* S = Cast<ASoldierCharacter>(Pawn))
	{
		return S->IsAlive();
	}
	return true;
}

ASoldierAIController* UEnemyFireteamSubsystem::GetAI(APawn* Pawn)
{
	return Pawn ? Cast<ASoldierAIController>(Pawn->GetController()) : nullptr;
}

void UEnemyFireteamSubsystem::CompactTeam(FEnemyFireteam& Team)
{
	for (int32 i = Team.Members.Num() - 1; i >= 0; --i)
	{
		APawn* P = Team.Members[i].Pawn.Get();
		if (!IsMemberAlive(P))
		{
			Team.Members.RemoveAtSwap(i, EAllowShrinking::No);
		}
	}
}

void UEnemyFireteamSubsystem::AssignTeam(FEnemyFireteam& Team)
{
	TArray<APawn*> Alive;
	Alive.Reserve(Team.Members.Num());
	FVector Centroid = FVector::ZeroVector;
	AActor* BestThreat = nullptr;
	FVector ThreatLoc = FVector::ZeroVector;
	float BestConf = 0.f;

	for (FEnemyFireteamMember& M : Team.Members)
	{
		APawn* P = M.Pawn.Get();
		if (!IsMemberAlive(P))
		{
			continue;
		}
		Alive.Add(P);
		Centroid += P->GetActorLocation();
		if (ASoldierAIController* AI = GetAI(P))
		{
			float Conf = 0.f;
			if (AActor* T = AI->GetPrimaryThreat(Conf))
			{
				if (Conf > BestConf)
				{
					BestConf = Conf;
					BestThreat = T;
					ThreatLoc = T->GetActorLocation();
				}
			}
		}
	}

	if (Alive.Num() == 0)
	{
		return;
	}
	Centroid /= static_cast<float>(Alive.Num());

	APawn* Leader = Alive[0];
	if (BestThreat)
	{
		float BestD = TNumericLimits<float>::Max();
		for (APawn* P : Alive)
		{
			const float D = FVector::DistSquared(P->GetActorLocation(), ThreatLoc);
			if (D < BestD)
			{
				BestD = D;
				Leader = P;
			}
		}
	}
	else
	{
		float BestD = TNumericLimits<float>::Max();
		for (APawn* P : Alive)
		{
			const float D = FVector::DistSquared(P->GetActorLocation(), Centroid);
			if (D < BestD)
			{
				BestD = D;
				Leader = P;
			}
		}
	}

	Team.Leader = Leader;
	Team.SharedThreat = BestThreat;
	Team.SharedThreatLoc = ThreatLoc;

	const FVector LeaderLoc = Leader->GetActorLocation();
	FVector Forward = Leader->GetActorForwardVector();
	Forward.Z = 0.f;
	if (BestThreat)
	{
		Forward = (ThreatLoc - LeaderLoc).GetSafeNormal2D();
	}
	if (Forward.IsNearlyZero())
	{
		Forward = FVector::ForwardVector;
	}
	const FVector Right = FVector::CrossProduct(Forward, FVector::UpVector).GetSafeNormal();

	int32 Follower = 0;
	int32 SuppressN = 0;
	int32 FlankLN = 0;
	int32 FlankRN = 0;
	int32 AssaultN = 0;

	for (FEnemyFireteamMember& M : Team.Members)
	{
		APawn* P = M.Pawn.Get();
		if (!IsMemberAlive(P))
		{
			continue;
		}

		ASoldierAIController* AI = GetAI(P);
		FVector Goal = LeaderLoc;
		EEnemyFireteamRole Role = EEnemyFireteamRole::Lead;

		if (P == Leader)
		{
			Role = EEnemyFireteamRole::Lead;
			M.Slot = 0;
			// Zero goal = keep using existing mission-zone movement when not in contact.
			Goal = BestThreat ? (ThreatLoc - Forward * 1400.f) : FVector::ZeroVector;
		}
		else
		{
			const int32 Cycle = Follower % 4;
			M.Slot = Follower + 1;
			++Follower;
			if (BestThreat)
			{
				switch (Cycle)
				{
				case 0:
					Role = EEnemyFireteamRole::Suppress;
					Goal = ThreatLoc - Forward * 2400.f + Right * ((SuppressN++ % 2 == 0) ? 450.f : -450.f);
					break;
				case 1:
					Role = EEnemyFireteamRole::FlankLeft;
					Goal = ThreatLoc - Forward * 500.f - Right * (1800.f + 250.f * FlankLN++);
					break;
				case 2:
					Role = EEnemyFireteamRole::FlankRight;
					Goal = ThreatLoc - Forward * 500.f + Right * (1800.f + 250.f * FlankRN++);
					break;
				default:
					Role = EEnemyFireteamRole::Assault;
					Goal = ThreatLoc - Forward * (800.f + 200.f * AssaultN++) + Right * ((AssaultN % 2 == 0) ? 280.f : -280.f);
					break;
				}
			}
			else
			{
				// Same idea as allied V-formation: hold a slot on the leader.
				const int32 Row = (M.Slot + 1) / 2;
				const float Side = (M.Slot % 2 == 0) ? 1.f : -1.f;
				Goal = LeaderLoc
					- Forward * (Row * 280.f)
					+ Right * (Side * Row * 220.f);
				Role = (Cycle == 3) ? EEnemyFireteamRole::Assault : EEnemyFireteamRole::Suppress;
			}
		}

		Goal.Z = P->GetActorLocation().Z;
		M.Role = Role;

		if (AI)
		{
			AI->bInEnemyFireteam = true;
			AI->FireteamRole = Role;
			AI->FireteamSlot = M.Slot;
			AI->FireteamMoveGoal = Goal;
			AI->FireteamSharedThreat = BestThreat;
			if (BestThreat)
			{
				AI->IngestSharedThreat(BestThreat, ThreatLoc, FMath::Max(0.55f, BestConf * 0.85f));
			}
		}
	}

	UWorld* World = GetWorld();
	const float Now = World ? World->GetTimeSeconds() : 0.f;
	if (World && (Now - Team.LastLogTime) >= 3.f)
	{
		Team.LastLogTime = Now;
		UE_LOG(LogTemp, Warning, TEXT("[TEAMDBG] fireteam %u n=%d leader=%s threat=%s conf=%.2f"),
			Team.TeamKey, Alive.Num(), *GetNameSafe(Leader), *GetNameSafe(BestThreat), BestConf);
	}
}

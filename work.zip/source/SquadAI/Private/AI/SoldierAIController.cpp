#include "AI/SoldierAIController.h"
#include "Performance/SquadAIRecovery.h"   // S19-CORPSE / S19-LEADWAIT
#include "Diagnostics/SquadAISituationLog.h"   // S19-LOGGER
#include "EngineUtils.h"
#include "Actors/SquadAIAutoSetupManager.h"
#include "Characters/SoldierCharacter.h"
#include "Characters/EnemyPatroller.h"   // S19-PATROL: calm patrollers keep their own beat
#include "Characters/LeaderCharacter.h"
#include "CoverSystem/CoverSystemSubsystem.h"
#include "Perception/AIPerceptionComponent.h"
#include "Perception/AISenseConfig_Sight.h"
#include "Perception/AISense_Sight.h"
#include "Perception/AISenseConfig_Hearing.h"
#include "Perception/AISenseConfig_Damage.h"
#include "Components/StateTreeAIComponent.h"
#include "Components/AimComponent.h"
#include "Components/WeaponComponent.h"
#include "Components/TacticalGrenadeComponent.h"
#include "Components/SquadAIAdapterComponent.h"
#include "BlueprintLibraries/SquadAIPackAssetResolverLibrary.h"
#include "Navigation/CrowdFollowingComponent.h"
#include "Navigation/PathFollowingComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "SquadAITuning.h"
#include "Performance/SharedThreatMemory.h"
#include "Performance/AISignificanceManager.h"
#include "Performance/SoldierRegistrySubsystem.h"
#include "HUD/QuestNativeHUD.h"
#include "Performance/SquadAIAudioSubsystem.h"
#include "Tactical/SquadAIPingSubsystem.h"
#include "Tactical/SquadAIAlarmSubsystem.h" // S19-ALARM
#include "AI/EnemyFireteamSubsystem.h"
#include "Quest/QuestRegistry.h"
#include "Quest/QuestZone.h"
#include "Quest/MissionZone.h"
#include "Quest/QuestChain.h"
#include "Quest/SplinePathActor.h"
#include "Components/SplineComponent.h" // S18-LEAD
#include "Quest/SceneDecorator.h"
#include "Components/SphereComponent.h"
#include "DrawDebugHelpers.h"
#include "Performance/SquadAIDevDebugSubsystem.h"
#include "Quest/SandstormWeatherDirector.h"
#include "NavigationSystem.h"
#include "GenericTeamAgentInterface.h"
#include "GameplayTasksComponent.h"
#include "GameFramework/Pawn.h"
#include "GameFramework/PlayerController.h"
#include "Kismet/GameplayStatics.h"
#include "Tutorial/SquadAITutorialSubsystem.h" // S18-TUT2
#include "Engine/World.h"
#include "TimerManager.h"

ASoldierAIController::ASoldierAIController(const FObjectInitializer& OI)
	: Super(OI.SetDefaultSubobjectClass<UCrowdFollowingComponent>(TEXT("PathFollowingComponent")))
{
	bWantsPlayerState = true; // Needed for GenericTeamId interface on the controller
	
	PerceptionComp = CreateDefaultSubobject<UAIPerceptionComponent>(TEXT("Perception"));
	SetPerceptionComponent(*PerceptionComp);
	StateTreeComp = CreateDefaultSubobject<UStateTreeAIComponent>(TEXT("StateTree"));
	TasksComp = CreateDefaultSubobject<UGameplayTasksComponent>(TEXT("GameplayTasks"));
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 0.1f; 
	TeamId = FGenericTeamId(255);
}

void ASoldierAIController::BeginPlay()
{
	Super::BeginPlay();
	const USquadAITuning* T = USquadAITuning::Get();
	MemoryDecayRate = T->MemoryDecayPerSecond;
	SuppressionDecayPerSec = T->SuppressionDecayPerSecond;
	DirectCombatRange = T->CombatDetectionRange;
	DirectCombatCloseRangeOverride = T->CombatCloseRangeOverride;
	DirectCombatFallbackFireRange = T->DirectFallbackFireRange;
	bAllowDirectCombatFallbackFire = T->bAllowDirectFallbackFire;

	// Hook into tactical 3D pings
	if (USquadAIPingSubsystem* PingSys = USquadAIPingSubsystem::Get(this))
	{
		PingSys->OnPingPlaced.AddDynamic(this, &ASoldierAIController::HandleTacticalPingPlaced);
	}

	// Always configure our perception. TPWCS BPC_AIDetection_Master should NOT be on the
	// controller — it's a competing AI brain, not just animation. SquadAI owns perception
	// and decision-making; TPWCS only provides weapon visuals.
	// S4-11: AI was deaf/blind for the first second (perception waited on this timer).
	// Configure immediately — the timer stays as a guarded fallback.
	SetupPerception();
	FTimerHandle PerceptionSetupHandle;
	GetWorldTimerManager().SetTimer(PerceptionSetupHandle, this, &ASoldierAIController::SetupPerception, 1.0f, false);
}

void ASoldierAIController::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (USquadAIPingSubsystem* PingSys = USquadAIPingSubsystem::Get(this))
	{
		PingSys->OnPingPlaced.RemoveDynamic(this, &ASoldierAIController::HandleTacticalPingPlaced);
	}
	Super::EndPlay(EndPlayReason);
}

void ASoldierAIController::HandleTacticalPingPlaced(FVector Location, ETacticalPingType Type)
{
	APawn* MyPawn = GetPawn();
	ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(MyPawn);
	if (!Soldier || !Soldier->IsAlive()) return;

	if (Soldier->IsAlly())
	{
		const float Dist = FVector::Dist(MyPawn->GetActorLocation(), Location);
		if (Dist < 12000.f)
		{
			SetCombatAimTarget(Location + FVector(0.f, 0.f, 60.f), ESquadAIAimMode::InvestigateLocation, nullptr);
		}
	}
}

void ASoldierAIController::OnPossess(APawn* InPawn)
{
	if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(InPawn))
	{
		SetGenericTeamId(Soldier->Faction == ESquadFaction::Enemy ? FGenericTeamId(1) : FGenericTeamId(0));
		Soldier->SetGenericTeamId(GetGenericTeamId());
	}
	else if (InPawn)
	{
		const FString CtrlName = GetName() + (GetClass() ? GetClass()->GetName() : FString());
		const FString PawnName = InPawn->GetName() + (InPawn->GetClass() ? InPawn->GetClass()->GetName() : FString());
		if (CtrlName.Contains(TEXT("Leader")) || CtrlName.Contains(TEXT("Ally")) || PawnName.Contains(TEXT("leader")) || PawnName.Contains(TEXT("ally")))
		{
			SetGenericTeamId(FGenericTeamId(0)); // Friendly team 0
		}
		else
		{
			SetGenericTeamId(FGenericTeamId(1)); // Enemy team 1
		}
	}

	if (InPawn)
	{
		// Ensure adapter component is present on the pawn
		if (!InPawn->FindComponentByClass<USquadAIAdapterComponent>())
		{
			USquadAIAdapterComponent* NewAdapter = NewObject<USquadAIAdapterComponent>(InPawn, TEXT("SquadAIAdapter_Runtime"));
			if (NewAdapter)
			{
				NewAdapter->RegisterComponent();
				InPawn->AddInstanceComponent(NewAdapter);
				NewAdapter->InitializeForOwner();
			}
		}
	}

	Super::OnPossess(InPawn);
	CacheRoleAndAdapter(InPawn);

	// Spread first ticks until significance LOD overwrites the interval.
	PrimaryActorTick.TickInterval = 0.1f + static_cast<float>(GetUniqueID() % 8) * 0.0125f;

	UE_LOG(LogTemp, Verbose, TEXT("[SquadAIPossess] Controller=%s Class=%s Pawn=%s PawnClass=%s StateTreeComp=%s PerceptionComp=%s"),
		*GetNameSafe(this),
		*GetNameSafe(GetClass()),
		*GetNameSafe(InPawn),
		InPawn ? *GetNameSafe(InPawn->GetClass()) : TEXT("null"),
		StateTreeComp ? TEXT("VALID") : TEXT("NULL"),
		PerceptionComp ? TEXT("VALID") : TEXT("NULL"));

	// CRITICAL FIX: RestartLogic() is silently ignored by UE5 when the StateTree has never
	// been started (i.e. on fresh possession of a newly spawned or pooled pawn). Without
	// StartLogic(), every StateTree task (LeaderPath, TakeCover, EngageTarget, FollowLeader)
	// remains dormant and the AI stands idle forever. Always check IsRunning() first.
	if (StateTreeComp)
	{
		const bool bWasRunning = StateTreeComp->IsRunning();
		UE_LOG(LogTemp, Verbose, TEXT("[SquadAIPossess] StateTree on %s: IsRunning=%d before start attempt"), *GetNameSafe(this), bWasRunning ? 1 : 0);

		if (!bWasRunning)
		{
			StateTreeComp->StartLogic();
			UE_LOG(LogTemp, Verbose, TEXT("[SquadAIPossess] StartLogic() called on %s — StateTree was dormant. Now IsRunning=%d"), *GetNameSafe(this), StateTreeComp->IsRunning() ? 1 : 0);
		}
		else
		{
			StateTreeComp->RestartLogic();
			UE_LOG(LogTemp, Verbose, TEXT("[SquadAIPossess] RestartLogic() called on %s — StateTree was already running."), *GetNameSafe(this));
		}
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("[SquadAIPossess] StateTreeComp is NULL on %s! StateTree tasks will not run."), *GetNameSafe(this));
	}

	if (PerceptionComp) PerceptionComp->OnTargetPerceptionUpdated.AddUniqueDynamic(this, &ASoldierAIController::OnPerceptionUpdated);

	// S19-ENEMYST: our own tree above is only half of it. The pack's pawns carry a state
	// tree component of their own, and one that failed to auto-start at spawn (no Pawn
	// context yet - see SquadAIRecovery.h) stays disabled forever. Possession is the
	// moment the context exists, so rescue the pawn's trees here too - whichever route
	// spawned it.
	SquadAIRecovery::EnsurePawnStateTreesRunning(InPawn, TEXT("possess"));

	// Safety net: some pack Blueprints may override or delay StateTree initialization.
	// Schedule a deferred re-check 2 seconds after possession. If StateTree is still
	// dormant by then, force-start it. This catches edge cases where OnPossess fires
	// before the Blueprint's own BeginPlay has finished setting up the StateTree asset.
	if (StateTreeComp && GetWorld())
	{
		FTimerHandle StateTreeSafetyHandle;
		TWeakObjectPtr<ASoldierAIController> WeakThis(this);
		GetWorldTimerManager().SetTimer(StateTreeSafetyHandle, [WeakThis]()
		{
			if (WeakThis.IsValid() && WeakThis->StateTreeComp && !WeakThis->StateTreeComp->IsRunning())
			{
				WeakThis->StateTreeComp->StartLogic();
				UE_LOG(LogTemp, Verbose, TEXT("[SoldierAIController] Safety net: StateTree was still dormant on %s after 2s, force-starting."), *GetNameSafe(WeakThis.Get()));
			}
		}, 2.0f, false);
	}
}

ETeamAttitude::Type ASoldierAIController::GetTeamAttitudeTowards(const AActor& Other) const
{
	const IGenericTeamAgentInterface* OtherTeamAgent = Cast<const IGenericTeamAgentInterface>(&Other);

	// If the perceived actor is a pawn, its controller may be the actual team agent.
	if (!OtherTeamAgent)
	{
		if (const APawn* OtherPawn = Cast<const APawn>(&Other))
		{
			OtherTeamAgent = Cast<const IGenericTeamAgentInterface>(OtherPawn->GetController());
		}
	}

	if (!OtherTeamAgent)
	{
		// Pack player characters usually do not implement SquadAI's team interface.
		// Treat the local/player-controlled pawn as team 0 (player/allied side) so enemies
		// can actually perceive and fight the player, while allies/leaders consider the
		// player friendly. Without this, pack player pawns become Neutral and enemies will
		// crouch/idle instead of shooting at the player.
		if (const APawn* OtherPawn = Cast<const APawn>(&Other))
		{
			if (OtherPawn->IsPlayerControlled())
			{
				// S18-TUT2: during the tutorial the player is Neutral to everyone.
				// Getting shot while a tutorial card has your legs locked is not a
				// lesson, it is a bug report.
				if (USquadAITutorialSubsystem::IsTutorialProtectingPlayer(this))
				{
					return ETeamAttitude::Neutral;
				}
				return TeamId == FGenericTeamId(1) ? ETeamAttitude::Hostile : ETeamAttitude::Friendly;
			}
		}

		return ETeamAttitude::Neutral;
	}

	const FGenericTeamId OtherTeamId = OtherTeamAgent->GetGenericTeamId();
	if (TeamId == FGenericTeamId::NoTeam || OtherTeamId == FGenericTeamId::NoTeam)
	{
		return ETeamAttitude::Neutral;
	}

	return TeamId == OtherTeamId ? ETeamAttitude::Friendly : ETeamAttitude::Hostile;
}

void ASoldierAIController::OnUnPossess()
{
	if (PerceptionComp) PerceptionComp->OnTargetPerceptionUpdated.RemoveDynamic(this, &ASoldierAIController::OnPerceptionUpdated);
	if (APawn* P = GetPawn())
	{
		if (UEnemyFireteamSubsystem* FT = GetWorld() ? GetWorld()->GetSubsystem<UEnemyFireteamSubsystem>() : nullptr)
		{
			FT->UnregisterMember(P);
		}
	}
	CachedAdapter.Reset();
	bLeaderRoleCached = false;
	bCachedIsLeader = false;
	bInEnemyFireteam = false;
	FireteamRole = EEnemyFireteamRole::Unassigned;
	Super::OnUnPossess();
}

void ASoldierAIController::CacheRoleAndAdapter(APawn* InPawn)
{
	bLeaderRoleCached = true;
	bCachedIsLeader = false;
	if (InPawn)
	{
		CachedAdapter = InPawn->FindComponentByClass<USquadAIAdapterComponent>();
		bCachedIsLeader = InPawn->IsA<ALeaderCharacter>()
			|| GetName().Contains(TEXT("Leader"))
			|| (GetClass() && GetClass()->GetName().Contains(TEXT("Leader")))
			|| InPawn->GetName().Contains(TEXT("leader"))
			|| (InPawn->GetClass() && InPawn->GetClass()->GetName().Contains(TEXT("leader")));
	}
}

bool ASoldierAIController::IsLeaderController() const
{
	if (!bLeaderRoleCached)
	{
		const_cast<ASoldierAIController*>(this)->CacheRoleAndAdapter(GetPawn());
	}
	return bCachedIsLeader;
}

USquadAIAdapterComponent* ASoldierAIController::GetCachedAdapter() const
{
	if (USquadAIAdapterComponent* A = CachedAdapter.Get())
	{
		return A;
	}
	if (APawn* P = GetPawn())
	{
		USquadAIAdapterComponent* Found = P->FindComponentByClass<USquadAIAdapterComponent>();
		CachedAdapter = Found;
		return Found;
	}
	return nullptr;
}

bool ASoldierAIController::PathDebugDue(float MinInterval) const
{
	UWorld* World = GetWorld();
	if (!bDebugLeaderPath || !World)
	{
		return false;
	}
	const float Now = World->GetTimeSeconds();
	if ((Now - LastPathDebugLogTime) < MinInterval)
	{
		return false;
	}
	LastPathDebugLogTime = Now;
	return true;
}

void ASoldierAIController::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	ASoldierCharacter* Soldier = GetSoldierCharacter();
	const float EffectiveDeltaTime = DeltaTime * FMath::Max(SignificanceUpdateMultiplier, 0.1f);
	const float CoverDecayMult = (Soldier && Soldier->bIsInCover) ? 0.5f : 1.f;
	Suppression = FMath::Max(0.f, Suppression - SuppressionDecayPerSec * EffectiveDeltaTime * CoverDecayMult);
	UpdateMemory(EffectiveDeltaTime);
	if (!bSkipExpensivePerceptionPolling)
	{
		PollPerceptionForHostiles();
		PollRegistryForHostiles();
	}
	RunDirectCombatFallback(EffectiveDeltaTime);
	// P7-AI1: movement must run in EVERY LOD bucket. Distant spawns are assigned bucket 5
	// (Dormant) — gating movement behind <5 froze exactly the far-away enemies that are
	// supposed to advance on the quest zone. The function already self-throttles (0.5 s
	// zone scan; 2.5–3 s move re-issue) and dormant controllers tick at a coarser
	// interval, so running it for all buckets is cheap.
	RunDirectEnemyMovement(EffectiveDeltaTime);
	if (IsLeaderController())
	{
		RunDirectMissionPathing(EffectiveDeltaTime);
		if (ALeaderCharacter* Leader = Cast<ALeaderCharacter>(GetPawn()))
		{
			Leader->bForceSprintThroughHazard = bLastLeaderFireSprint;
		}
	}

	// B7-6: the bDrawAIDebugVisuals cheat flag finally has a reader — per-AI threat,
	// cover and move-goal gizmos (F6 / ToggleAIDebugVisuals).
	if (USquadAIDevDebugSubsystem* DevDbg = USquadAIDevDebugSubsystem::Get(this))
	{
		if (DevDbg->bDrawAIDebugVisuals && GetPawn() && GetWorld())
		{
			UWorld* DbgWorld = GetWorld();
			const FVector ChestLoc = GetPawn()->GetActorLocation() + FVector(0.f, 0.f, 90.f);
			float ThreatConfidence = 0.f;
			if (AActor* Threat = GetPrimaryThreat(ThreatConfidence))
			{
				DrawDebugLine(DbgWorld, ChestLoc, Threat->GetActorLocation() + FVector(0.f, 0.f, 90.f),
					FColor::Red, false, 0.f, 0, 2.f);
				DrawDebugSphere(DbgWorld, Threat->GetActorLocation() + FVector(0.f, 0.f, 90.f),
					30.f, 8, FColor::Red, false, 0.f, 0, 1.f);
			}
			if (bHasCover)
			{
				DrawDebugSphere(DbgWorld, CurrentCover.Location + FVector(0.f, 0.f, 40.f),
					45.f, 10, FColor::Green, false, 0.f, 0, 2.f);
			}
			if (HasActiveCoverMoveGoal())
			{
				DrawDebugSphere(DbgWorld, GetActiveCoverMoveGoal() + FVector(0.f, 0.f, 40.f),
					35.f, 8, FColor::Cyan, false, 0.f, 0, 1.5f);
			}
		}
	}

	// S5-9: refresh sight radii for sandstorm visibility (0.5s poll, change-gated).
	WeatherPollTimer += DeltaTime;
	if (WeatherPollTimer >= 0.5f)
	{
		WeatherPollTimer = 0.f;
		RefreshSightForWeather();
	}
}

void ASoldierAIController::SetMoveCommand(const FSquadAIMoveCommand& NewCommand)
{
	ActiveMoveCommand = NewCommand;
	CurrentGoalLocation = NewCommand.GoalLocation;
	bHasActiveGoal = NewCommand.IsValid();
	if (USquadAIAdapterComponent* Adapter = GetCachedAdapter())
	{
		Adapter->SetMoveCommand(NewCommand);
	}
}

void ASoldierAIController::ClearMoveCommand()
{
	ActiveMoveCommand = FSquadAIMoveCommand();
	CurrentGoalLocation = FVector::ZeroVector;
	bHasActiveGoal = false;
	if (USquadAIAdapterComponent* Adapter = GetCachedAdapter())
	{
		Adapter->ClearMoveCommand();
	}
}

void ASoldierAIController::SetAimCommand(const FSquadAIAimCommand& NewCommand)
{
	ActiveAimCommand = NewCommand;
	if (USquadAIAdapterComponent* Adapter = GetCachedAdapter())
	{
		Adapter->SetAimCommand(NewCommand);
	}
}

void ASoldierAIController::ClearAimCommand()
{
	ActiveAimCommand = FSquadAIAimCommand();
	ClearFocus(EAIFocusPriority::Gameplay);
	if (UBlackboardComponent* BB = GetBlackboardComponent())
	{
		BB->ClearValue(TEXT("enemyActor"));
		BB->ClearValue(TEXT("targetActor"));
		BB->SetValueAsBool(TEXT("bIsInAttackRange?"), false);
	}
	if (APawn* P = GetPawn())
	{
		if (UCharacterMovementComponent* CMC = Cast<UCharacterMovementComponent>(P->GetComponentByClass(UCharacterMovementComponent::StaticClass())))
		{
			CMC->bOrientRotationToMovement = true;
		}
		if (USquadAIAdapterComponent* Adapter = GetCachedAdapter())
		{
			Adapter->ClearAimCommand();
		}
	}
}

namespace
{
struct FFireHaz
{
	FVector Loc;
	float Radius;
};

static void GatherFireHazards(UWorld* World, TArray<FFireHaz>& Out)
{
	if (!World)
	{
		return;
	}

	static TArray<FFireHaz> Cache;
	static float CacheTime = -1000.f;
	static uint32 CacheWorldId = 0;
	const float Now = World->GetTimeSeconds();
	const uint32 WorldId = World->GetUniqueID();
	if (CacheWorldId == WorldId && (Now - CacheTime) < 0.25f)
	{
		Out = Cache;
		return;
	}

	Cache.Reset();
	TArray<FVector> Locs;
	TArray<float> Radii;
	ASceneDecorator::CollectFireHazards(World, Locs, Radii);
	const int32 N = FMath::Min(Locs.Num(), Radii.Num());
	for (int32 i = 0; i < N; ++i)
	{
		FFireHaz H;
		H.Loc = Locs[i];
		H.Radius = Radii[i];
		Cache.Add(H);
	}
	CacheTime = Now;
	CacheWorldId = WorldId;
	Out = Cache;
}

static bool PointInFire(const FVector& P, const FFireHaz& H, float Pad)
{
	return FVector::Dist2D(P, H.Loc) <= (H.Radius + Pad) && FMath::Abs(P.Z - H.Loc.Z) <= 180.f;
}

static FVector PushOutOfFire(const FVector& P, const FFireHaz& H, float Pad)
{
	FVector D(P.X - H.Loc.X, P.Y - H.Loc.Y, 0.f);
	if (D.SizeSquared() < 1.f)
	{
		D = FVector(1.f, 0.f, 0.f);
	}
	D.Normalize();
	FVector Out = H.Loc + D * (H.Radius + Pad + 50.f);
	Out.Z = P.Z;
	return Out;
}

static float DistPointToSeg2D(const FVector& A, const FVector& B, const FVector& P, float& OutT)
{
	const float ABx = B.X - A.X;
	const float ABy = B.Y - A.Y;
	const float LenSq = ABx * ABx + ABy * ABy;
	if (LenSq < 1.f)
	{
		OutT = 0.f;
		return FVector::Dist2D(P, A);
	}
	OutT = FMath::Clamp(((P.X - A.X) * ABx + (P.Y - A.Y) * ABy) / LenSq, 0.f, 1.f);
	const FVector Closest(A.X + ABx * OutT, A.Y + ABy * OutT, A.Z);
	return FVector::Dist2D(P, Closest);
}
} // namespace

AMissionZone* ASoldierAIController::FindActiveMissionZone() const
{
	UWorld* World = GetWorld();
	if (!World)
	{
		return nullptr;
	}
	const float Now = World->GetTimeSeconds();
	if (AQuestChain* Cached = CachedActiveChain.Get())
	{
		if ((Now - CachedActiveChainTime) < 0.5f)
		{
			return Cached->bIsActive ? Cached->GetCurrentMission() : nullptr;
		}
	}

	AQuestChain* Found = AQuestChain::FindPreferred(World, true);
	CachedActiveChain = Found;
	CachedActiveChainTime = Now;
	return Found ? Found->GetCurrentMission() : nullptr;
}

FVector ASoldierAIController::AvoidFireHazards(const FVector& From, const FVector& To, bool& bOutSprint, FString& OutReason) const
{
	bOutSprint = false;
	OutReason = TEXT("none");
	UWorld* World = GetWorld();
	if (!World || !bAvoidFireOnPath)
	{
		OutReason = TEXT("disabled");
		return To;
	}

	TArray<FFireHaz> Fires;
	GatherFireHazards(World, Fires);
	if (Fires.Num() == 0)
	{
		OutReason = TEXT("noFires");
		return To;
	}

	const float Pad = FireAvoidPadding;
	FVector Goal = To;

	for (const FFireHaz& H : Fires)
	{
		if (PointInFire(From, H, 0.f))
		{
			bOutSprint = true;
			OutReason = FString::Printf(TEXT("insideFire-sprintOut r=%.0f xy=%.0f"), H.Radius, FVector::Dist2D(From, H.Loc));
			return PushOutOfFire(From, H, Pad);
		}
	}

	for (const FFireHaz& H : Fires)
	{
		if (PointInFire(Goal, H, Pad))
		{
			Goal = PushOutOfFire(Goal, H, Pad);
			OutReason = FString::Printf(TEXT("goalInFire-pushed r=%.0f"), H.Radius);
		}
	}

	for (int32 Iter = 0; Iter < 4; ++Iter)
	{
		bool bDetoured = false;
		for (const FFireHaz& H : Fires)
		{
			if (FMath::Abs(From.Z - H.Loc.Z) > 220.f && FMath::Abs(Goal.Z - H.Loc.Z) > 220.f)
			{
				continue;
			}
			float T = 0.f;
			const float D = DistPointToSeg2D(From, Goal, H.Loc, T);
			const float R = H.Radius + Pad;
			if (D > R)
			{
				continue;
			}
			const float Inner = FMath::Max(0.f, R * R - D * D);
			const float Chord = 2.f * FMath::Sqrt(Inner);
			if (Chord <= FireSprintThroughMaxWidth)
			{
				bOutSprint = true;
				if (OutReason == TEXT("none") || OutReason.StartsWith(TEXT("goalInFire")))
				{
					OutReason = FString::Printf(TEXT("sprintThrough chord=%.0f r=%.0f"), Chord, H.Radius);
				}
				continue;
			}

			const float ABx = Goal.X - From.X;
			const float ABy = Goal.Y - From.Y;
			FVector Perp(-ABy, ABx, 0.f);
			if (Perp.SizeSquared() < 1.f)
			{
				Perp = FVector(0.f, 1.f, 0.f);
			}
			Perp.Normalize();
			const float Offset = H.Radius + Pad + 80.f;
			FVector CandL = H.Loc + Perp * Offset;
			FVector CandR = H.Loc - Perp * Offset;
			CandL.Z = From.Z;
			CandR.Z = From.Z;

			auto ScoreCand = [&](const FVector& Cnd)
			{
				float S = FVector::Dist2D(From, Cnd) + FVector::Dist2D(Cnd, Goal);
				for (const FFireHaz& H2 : Fires)
				{
					if (PointInFire(Cnd, H2, Pad))
					{
						S += 100000.f;
					}
				}
				return S;
			};
			FVector Pick = (ScoreCand(CandL) <= ScoreCand(CandR)) ? CandL : CandR;
			Goal = ProjectToNav(Pick);
			bOutSprint = false;
			OutReason = FString::Printf(TEXT("detourFire r=%.0f chord=%.0f t=%.2f"), H.Radius, Chord, T);
			bDetoured = true;
			break;
		}
		if (!bDetoured)
		{
			break;
		}
	}
	return Goal;
}

FVector ASoldierAIController::ApplySplineAndFireToGoal(const FVector& RawGoal) const
{
	FVector Goal = RawGoal;
	AMissionZone* Mission = FindActiveMissionZone();
	if (Goal.IsNearlyZero() && Mission)
	{
		Goal = Mission->GetActorLocation();
	}

	APawn* P = GetPawn();
	if (!P)
	{
		return Goal;
	}
	const FVector From = P->GetActorLocation();
	UWorld* World = GetWorld();

	const bool bLog = bDebugLeaderPath && World && ((World->GetTimeSeconds() - LastPathDebugLogTime) >= 2.f);
	if (bLog)
	{
		LastPathDebugLogTime = World->GetTimeSeconds();
	}

	TArray<FFireHaz> Fires;
	GatherFireHazards(World, Fires);
	TArray<FVector> FireCenters;
	TArray<float> FireRadii;
	FireCenters.Reserve(Fires.Num());
	FireRadii.Reserve(Fires.Num());
	for (const FFireHaz& H : Fires)
	{
		FireCenters.Add(H.Loc);
		FireRadii.Add(H.Radius);
	}

	FString SplineWhy = TEXT("NO_GUIDE");
	FVector AfterSpline = Goal;
	ASplinePathActor* Guide = ASplinePathActor::FindGuide(World, Mission, From, bLog);
	if (Guide)
	{
		AfterSpline = Guide->GetFollowLocationSkipping(From, Goal, FireCenters, FireRadii, FireAvoidPadding);
		SplineWhy = FString::Printf(TEXT("%s/%s"), *Guide->GetName(), *Guide->PathName.ToString());

		// S18-LEAD: enforce monotonic progress along the guide + hand off to the
		// real goal early. Without this the follow point can snap backwards and
		// the leader ping-pongs forever short of the quest zone.
		if (USplineComponent* Spline = Guide->SplinePath)
		{
			const float Len = Spline->GetSplineLength();
			if (Len > 10.f)
			{
				const float Now2 = World ? World->GetTimeSeconds() : 0.f;
				// New guide, long gap, or a genuinely different objective goal
				// (next mission may lie back down the corridor) — start fresh.
				const bool bGoalChanged = !LeaderLastRawGoal.IsNearlyZero()
					&& FVector::DistSquared(LeaderLastRawGoal, Goal) > FMath::Square(1000.f);
				if (LeaderProgressGuide.Get() != Guide || (Now2 - LeaderProgressStamp) > 20.f || bGoalChanged)
				{
					LeaderProgressGuide = Guide;
					LeaderSplineProgress = -1.f; // new path (or long gap) — start fresh
				}
				LeaderLastRawGoal = Goal;
				LeaderProgressStamp = Now2;

				const float Key = Spline->FindInputKeyClosestToWorldLocation(From);
				float DistOn = Spline->GetDistanceAlongSplineAtSplineInputKey(Key);

				// Direction of travel along the spline toward the goal.
				float Sign = 1.f;
				if (!Goal.IsNearlyZero())
				{
					const FVector S0 = Spline->GetLocationAtDistanceAlongSpline(0.f, ESplineCoordinateSpace::World);
					const FVector S1 = Spline->GetLocationAtDistanceAlongSpline(Len, ESplineCoordinateSpace::World);
					Sign = (FVector::DistSquared(S1, Goal) <= FVector::DistSquared(S0, Goal)) ? 1.f : -1.f;
				}
				const float Signed = DistOn * Sign; // monotonically increasing along travel

				if (LeaderSplineProgress <= -1.f)
				{
					LeaderSplineProgress = Signed;
				}
				else if (Signed + 300.f < LeaderSplineProgress)
				{
					// Looks like a backwards snap. Only accept it if the pawn is
					// genuinely far from the remembered point (teleport, respawn,
					// pushed back) — otherwise keep the old progress.
					const FVector Remembered = Spline->GetLocationAtDistanceAlongSpline(
						FMath::Clamp(LeaderSplineProgress * Sign, 0.f, Len), ESplineCoordinateSpace::World);
					if (FVector::Dist2D(From, Remembered) > 2500.f)
					{
						LeaderSplineProgress = Signed;
					}
				}
				else
				{
					LeaderSplineProgress = FMath::Max(LeaderSplineProgress, Signed);
				}

				const float EffectiveLookahead = FMath::Max(Guide->LookAheadDistance, 650.f);
				float Ahead = FMath::Clamp((LeaderSplineProgress + EffectiveLookahead) * Sign, 0.f, Len);
				const float Remaining = (Sign > 0.f) ? (Len - Ahead) : Ahead;

				const FVector AheadLoc = Spline->GetLocationAtDistanceAlongSpline(Ahead, ESplineCoordinateSpace::World);
				const bool bNearSplineEnd = Remaining <= 200.f;
				// S18-LEAD: once the final goal is nearer than the lookahead point,
				// or the spline has run out, stop steering by the spline entirely —
				// that last stretch was where he used to stall and loop.
				const bool bGoalIsCloser = !Goal.IsNearlyZero()
					&& FVector::Dist2D(From, Goal) <= FVector::Dist2D(From, AheadLoc) + 150.f;
				if (!Goal.IsNearlyZero() && (bNearSplineEnd || bGoalIsCloser))
				{
					AfterSpline = Goal;
					SplineWhy += TEXT("/HANDOFF");
				}
				else
				{
					// Keep hazard skipping, but never behind the recorded progress.
					const float AfterKey = Spline->FindInputKeyClosestToWorldLocation(AfterSpline);
					const float AfterDist = Spline->GetDistanceAlongSplineAtSplineInputKey(AfterKey) * Sign;
					if (AfterDist < LeaderSplineProgress)
					{
						AfterSpline = AheadLoc;
						SplineWhy += TEXT("/MONO");
					}
				}
			}
		}
	}
	else
	{
		LeaderProgressGuide = nullptr;
		LeaderSplineProgress = -1.f;
	}

	bool bSprint = false;
	FString FireWhy;
	FVector Final = AfterSpline;
	if (bAvoidFireOnPath)
	{
		Final = AvoidFireHazards(From, AfterSpline, bSprint, FireWhy);
	}
	else
	{
		FireWhy = TEXT("disabled");
	}

	const float Now = World ? World->GetTimeSeconds() : 0.f;
	const bool bFireEvent = FireWhy.Contains(TEXT("detour")) || FireWhy.Contains(TEXT("sprint")) || FireWhy.Contains(TEXT("insideFire"));
	if (bFireEvent && !bFireHesitateArmed)
	{
		bFireHesitateArmed = true;
		FireHesitateUntil = Now + 0.45f;
	}
	else if (!bFireEvent)
	{
		bFireHesitateArmed = false;
	}
	if (bSprint)
	{
		FireSprintUntil = FMath::Max(FireSprintUntil, Now + 1.15f);
	}
	bLastLeaderFireSprint = bSprint && (Now <= FireSprintUntil);

	LastFireLookAt = FVector::ZeroVector;
	float BestFire = TNumericLimits<float>::Max();
	for (const FFireHaz& H : Fires)
	{
		const float XY = FVector::Dist2D(From, H.Loc);
		if (XY < BestFire)
		{
			BestFire = XY;
			LastFireLookAt = H.Loc + FVector(0, 0, 60);
		}
	}

	bLastInTrench = false;
	if (Guide && Guide->SplinePath)
	{
		const float Key = Guide->SplinePath->FindInputKeyClosestToWorldLocation(From);
		const FVector Closest = Guide->SplinePath->GetLocationAtSplineInputKey(Key, ESplineCoordinateSpace::World);
		bLastInTrench = FVector::Dist2D(From, Closest) <= Guide->CorridorHalfWidth * 1.15f;
	}

	FVector NewHeading = (Final - From).GetSafeNormal2D();
	if (NewHeading.IsNearlyZero())
	{
		NewHeading = LastPathHeading;
	}
	const float HeadingDot = FVector::DotProduct(LastPathHeading, NewHeading);
	LastPathHeading = NewHeading;
	PathSpeedScale = (HeadingDot < 0.35f) ? 0.62f : ((HeadingDot < 0.7f) ? 0.82f : 1.f);
	if (bLastInTrench)
	{
		PathSpeedScale *= TrenchWalkSpeedScale;
	}
	if (Now < FireHesitateUntil)
	{
		PathSpeedScale = 0.f;
	}

	LastPathDebugReason = FString::Printf(TEXT("spline=%s fire=%s sprint=%d hesitate=%.2f turn=%.2f"),
		*SplineWhy, *FireWhy, bLastLeaderFireSprint ? 1 : 0, FMath::Max(0.f, FireHesitateUntil - Now), PathSpeedScale);

	if (bLog)
	{
		int32 Inside = 0;
		int32 OnPath = 0;
		float Nearest = TNumericLimits<float>::Max();
		for (const FFireHaz& H : Fires)
		{
			const float XY = FVector::Dist2D(From, H.Loc);
			Nearest = FMath::Min(Nearest, XY);
			if (PointInFire(From, H, 0.f))
			{
				Inside++;
			}
			float T = 0.f;
			if (DistPointToSeg2D(From, AfterSpline, H.Loc, T) <= H.Radius + FireAvoidPadding)
			{
				OnPath++;
			}
		}
		UE_LOG(LogTemp, Warning,
			TEXT("[PATHDBG] build=PATHDBG_3 leader=%s mission=%s loc=%s raw=%s splineGoal=%s final=%s | %s fires=%d inside=%d onPath=%d nearestXY=%.0f"),
			*GetNameSafe(P),
			*GetNameSafe(Mission),
			*From.ToString(),
			*RawGoal.ToString(),
			*AfterSpline.ToString(),
			*Final.ToString(),
			*LastPathDebugReason,
			Fires.Num(), Inside, OnPath,
			Nearest < TNumericLimits<float>::Max() ? Nearest : -1.f);
	}

	if (bDrawLeaderPath && World)
	{
		DrawDebugLine(World, From + FVector(0, 0, 50), Goal + FVector(0, 0, 50), FColor::Red, false, 0.2f, 0, 2.f);
		DrawDebugLine(World, From + FVector(0, 0, 55), AfterSpline + FVector(0, 0, 55), FColor::Cyan, false, 0.2f, 0, 4.f);
		DrawDebugLine(World, From + FVector(0, 0, 60), Final + FVector(0, 0, 60), bSprint ? FColor::Yellow : FColor::Green, false, 0.2f, 0, 6.f);
		DrawDebugSphere(World, Final + FVector(0, 0, 40), 40.f, 8, bSprint ? FColor::Yellow : FColor::Green, false, 0.2f, 0, 2.f);
	}

	// S19-STEERLATCH: never let the steering goal walk backwards on the leader.
	// Measured against the goal he is already walking to: a candidate more than 1.5 m
	// BEHIND that goal (relative to his direction of travel) is a projection / fire-skip
	// flip-flop, not progress - hold the old goal instead of turning him around.
	FVector Out = Final;
	if (World)
	{
		const bool bNoGoal  = LeaderSteerGoal.IsNearlyZero();
		const bool bReached = !bNoGoal && FVector::Dist2D(From, LeaderSteerGoal) < 250.f;
		const bool bMoved   = !bNoGoal && FVector::Dist2D(From, LeaderSteerPawnAt) > 600.f;   // respawn / regroup
		const bool bStale   = (World->GetTimeSeconds() - LeaderSteerGoalTime) > 2.5f;
		if (bNoGoal || bReached || bMoved || bStale)
		{
			LeaderSteerGoal = Out;
			LeaderSteerPawnAt = From;
			LeaderSteerGoalTime = World->GetTimeSeconds();
		}
		else
		{
			const FVector TravelDir = (LeaderSteerGoal - From).GetSafeNormal2D();
			const float Along = TravelDir.IsNearlyZero() ? 0.f : FVector::DotProduct(Out - LeaderSteerGoal, TravelDir);
			if (Along < -150.f)
			{
				SquadAISituation::NoteOnce(
					FString::Printf(TEXT("steerlatch:%s"), *GetName()),
					FString::Printf(TEXT("STEERLATCH %s: candidate goal %.2f m BEHIND the one being walked to - holding (%.0f,%.0f) instead of turning around"),
						*GetNameSafe(GetPawn()), -Along / 100.f, LeaderSteerGoal.X, LeaderSteerGoal.Y));
				Out = LeaderSteerGoal;
			}
			else
			{
				LeaderSteerGoal = Out;
				LeaderSteerPawnAt = From;
				LeaderSteerGoalTime = World->GetTimeSeconds();
			}
		}
	}
	return Out;
}

// S19-STORM: see the header. Called from the Engage task on every entry.
bool ASoldierAIController::NoteEngageEntry()
{
	const UWorld* W = GetWorld();
	if (!W) return false;
	const float Now = W->GetTimeSeconds();

	if (EngageStormWindowStart < 0.f || (Now - EngageStormWindowStart) > 2.f)
	{
		EngageStormWindowStart = Now;
		EngageStormEntries = 0;
	}
	++EngageStormEntries;
	if (EngageStormEntries >= 10)
	{
		EngageStormEntries = 0;
		EngageStormWindowStart = Now;
		return true;
	}
	return false;
}

void ASoldierAIController::SuppressPrimaryThreat(float Seconds, const TCHAR* Why)
{
	const UWorld* W = GetWorld();
	const float Now = W ? W->GetTimeSeconds() : 0.f;
	ThreatSuppressUntil = FMath::Max(ThreatSuppressUntil, Now + FMath::Max(0.5f, Seconds));

	// Drop the belief itself, not just our own reads of it: the pack's StateTree
	// transitions judge the same list, so this is what actually stops the transition that
	// re-enters combat every frame.
	int32 Dropped = 0;
	for (FPerceivedTarget& T : Memory)
	{
		if (T.Confidence <= 0.f) continue;
		T.bCurrentlyVisible = false;
		T.Confidence = 0.05f;   // below every gate (0.15 / 0.2); decays to nothing
		++Dropped;
	}
	UE_LOG(LogTemp, Warning, TEXT("[SquadAI] %s: combat suppressed for %.1fs (%s) - belief dropped on %d tracked hostile(s)"),
		*GetName(), Seconds, Why ? Why : TEXT("?"), Dropped);
}

// S19-HUNT: one decision point for "the objective is reached but not finished".
// See the header for why this is on the controller rather than in the state-tree task.
AActor* ASoldierAIController::GetLeaderHuntTarget() const
{
	if (!IsLeaderController() || !GetPawn()) return nullptr;

	UWorld* World = GetWorld();
	if (!World) return nullptr;

	// Rescan twice a second at most: the query walks every spawner's pawn list, and a
	// half-second-old enemy position is irrelevant at walking speed.
	const float Now = World->GetTimeSeconds();
	if ((Now - LeaderHuntScanTime) < 0.5f)
	{
		AActor* Cached = LeaderHuntTarget.Get();
		return (Cached && SquadAIRecovery::IsActorDead(Cached)) ? nullptr : Cached;
	}
	LeaderHuntScanTime = Now;
	LeaderHuntTarget = nullptr;
	LeaderHuntRemaining = 0;

	AMissionZone* Zone = FindActiveMissionZone();
	if (!Zone || !Zone->bHuntRemainingEnemiesOnArrival) return nullptr;

	const FVector PawnLoc = GetPawn()->GetActorLocation();
	const FVector ZoneLoc = Zone->GetActorLocation();
	const float HuntRadius = (Zone->HuntActivationRadius > 0.f) ? Zone->HuntActivationRadius : 3000.f;
	if (FVector::Dist2D(PawnLoc, ZoneLoc) > HuntRadius) return nullptr;   // still marching - do not abandon the approach

	if (!Zone->HasAliveEnemies()) return nullptr;

	// S19-HUNT2 first tried to keep the hunt inside the objective area - and the next live
	// log showed what that costs: "HUNT none inside the objective area (5-10 alive
	// elsewhere, nearest 256-311 m away, area radius 30 m) - leader holds at the objective"
	// ten times in a row, while the mission can only finish when every enemy is dead.
	// S19-HUNT3 therefore treats "inside" as a PREFERENCE, not a gate:
	//   * an enemy inside the area (HuntActivationRadius around the zone centre) wins;
	//   * otherwise the nearest enemy within HuntPursuitRadius of the objective is hunted,
	//     so the squad walks over and clears the survivors as the mission requires;
	//   * only when survivors exist beyond even that radius does the leader hold - and he
	//     says so with the distance, so a hold is never silent again.
	// The old "walks between the objective and the enemy side" bug came from the combat
	// re-entry storm plus goal churn re-issuing his movement every frame (S19-BELIEF /
	// S19-STORM / S19-STEERLATCH), not from the pursuit itself.
	const FVector AreaOrigin = ZoneLoc;
	const float AreaRadius = HuntRadius;
	const float PursuitRadius = Zone->GetHuntPursuitRadius();

	// Hysteresis: keep the enemy already being hunted while he is alive and within the
	// PURSUIT radius (+25%). Bounding this by the area radius instead would drop a target
	// the moment the leader starts walking to it, and re-pick every half second.
	if (AActor* Cached = LeaderHuntTarget.Get())
	{
		if (!SquadAIRecovery::IsActorDead(Cached) &&
			FVector::Dist2D(Cached->GetActorLocation(), AreaOrigin) <= PursuitRadius * 1.25f)
		{
			LeaderHuntRemaining = Zone->GetAliveEnemyCount();
			return Cached;
		}
	}

	AActor* Target = Zone->GetNearestAliveEnemy(AreaOrigin, AreaRadius);
	const bool bInsideArea = (Target != nullptr);
	if (!Target)
	{
		Target = Zone->GetNearestAliveEnemy(AreaOrigin, PursuitRadius);
	}
	if (!Target)
	{
		// Survivors exist but all of them are beyond the pursuit radius: HOLD, and say so
		// once per count change. Silence here is what made this look like "the leader
		// simply refuses to move".
		AActor* Elsewhere = Zone->GetNearestAliveEnemy(AreaOrigin);
		const float ElsewhereDist = Elsewhere ? FVector::Dist2D(PawnLoc, Elsewhere->GetActorLocation()) : -1.f;
		LeaderHuntRemaining = Zone->GetAliveEnemyCount();
		SquadAISituation::NoteOnce(
			FString::Printf(TEXT("hunthold:%s:%d"), *GetName(), LeaderHuntRemaining),
			FString::Printf(TEXT("HUNT none within %.0f m of the objective (%d alive, nearest %.0f m away) - leader holds at the objective"),
				PursuitRadius / 100.f, LeaderHuntRemaining, ElsewhereDist / 100.f));
		return nullptr;
	}

	LeaderHuntTarget = Target;
	LeaderHuntRemaining = Zone->GetAliveEnemyCount();

	// One line per target: this is the "he is going after them" proof in the log.
	SquadAISituation::NoteOnce(
		FString::Printf(TEXT("hunt:%s:%s"), *GetName(), *GetNameSafe(Target)),
		FString::Printf(TEXT("HUNT leader going after %s (%d enemy/enemies left at %s, %.0f m away, %s)"),
			*GetNameSafe(Target), LeaderHuntRemaining, *Zone->GetName(),
			FVector::Dist(PawnLoc, Target->GetActorLocation()) / 100.f,
			bInsideArea
				? *FString::Printf(TEXT("inside the objective area (%.0f m from the centre)"), FVector::Dist2D(Target->GetActorLocation(), AreaOrigin) / 100.f)
				: *FString::Printf(TEXT("OUTSIDE the objective area: %.0f m from the centre, pursuit radius %.0f m"), FVector::Dist2D(Target->GetActorLocation(), AreaOrigin) / 100.f, PursuitRadius / 100.f)));

	return Target;
}

FVector ASoldierAIController::GetEffectiveMoveGoal() const
{
	if (ActiveMoveCommand.IsValid())
	{
		const FVector Raw = ActiveMoveCommand.GoalLocation;
		APawn* P = GetPawn();
		// S18-LEAD: QuestObjective_AutoZone pushes a QuestGoal move command to
		// every ally, and this branch returned the raw zone centre with NO
		// spline guidance — the leader beelined, the partial path died short of
		// the zone and he paced there forever. Leaders now always go through the
		// corridor + monotonic progress + handoff logic.
		if (P && IsLeaderController())
		{
			// S19-HUNT: QuestObjective_AutoZone keeps a QuestGoal move command active for
			// this whole branch - which is exactly the state the leader is in when he
			// arrives. Hunting therefore has to be checked HERE as well, or the arrival
			// case (the only case that matters) would never reach the hunt code below.
			if (AActor* HuntEarly = GetLeaderHuntTarget())
			{
				return HuntEarly->GetActorLocation();
			}
			return ApplySplineAndFireToGoal(Raw);
		}
		if (!P || !bAvoidFireOnPath)
		{
			return Raw;
		}
		bool bSprint = false;
		FString Why;
		const FVector Out = AvoidFireHazards(P->GetActorLocation(), Raw, bSprint, Why);
		bLastLeaderFireSprint = bSprint;
		return Out;
	}
	FVector Raw = FVector::ZeroVector;
	if (!CurrentGoalLocation.IsNearlyZero())
	{
		Raw = CurrentGoalLocation;
	}
	else if (const UQuestRegistry* GPS = GetWorld() ? GetWorld()->GetSubsystem<UQuestRegistry>() : nullptr)
	{
		Raw = GPS->CurrentActiveGoal;
	}
	if (!IsLeaderController())
	{
		APawn* P = GetPawn();
		if (!P || !bAvoidFireOnPath || Raw.IsNearlyZero())
		{
			return Raw;
		}
		bool bSprint = false;
		FString Why;
		return AvoidFireHazards(P->GetActorLocation(), Raw, bSprint, Why);
	}

	// S19-HUNT: arrived at the objective with enemies still up -> the nearest enemy IS the
	// goal. Straight line on purpose: this happens inside the zone, where the spline
	// corridor is irrelevant and would only pull him off the enemy.
	if (AActor* Hunt = GetLeaderHuntTarget())
	{
		return Hunt->GetActorLocation();
	}

	return ApplySplineAndFireToGoal(Raw);
}

void ASoldierAIController::DumpLeaderPathDebug()
{
	LastPathDebugLogTime = -1000.f;
	const FVector Goal = GetEffectiveMoveGoal();
	UE_LOG(LogTemp, Warning, TEXT("[PATHDBG] DumpLeaderPathDebug pawn=%s goal=%s %s"),
		*GetNameSafe(GetPawn()), *Goal.ToString(), *LastPathDebugReason);
	ASplinePathActor::LogAllGuides(GetWorld(), FindActiveMissionZone(),
		GetPawn() ? GetPawn()->GetActorLocation() : FVector::ZeroVector);
}

FVector ASoldierAIController::NudgeOutOfFire(const FVector& From, const FVector& To) const
{
	if (!bAvoidFireOnPath)
	{
		return To;
	}
	bool bSprint = false;
	FString Why;
	return AvoidFireHazards(From, To, bSprint, Why);
}

FVector ASoldierAIController::ProjectToNav(const FVector& P) const
{
	UWorld* World = GetWorld();
	if (!World)
	{
		return P;
	}
	UNavigationSystemV1* Nav = FNavigationSystem::GetCurrent<UNavigationSystemV1>(World);
	if (!Nav)
	{
		return P;
	}
	FNavLocation Out;
	if (Nav->ProjectPointToNavigation(P, Out, FVector(280.f, 280.f, 400.f)))
	{
		return Out.Location;
	}
	return P;
}

FVector ASoldierAIController::GetAllyCorridorSlot(APawn* Leader, int32 Slot, float Spacing) const
{
	if (!Leader)
	{
		return FVector::ZeroVector;
	}
	AMissionZone* Mission = FindActiveMissionZone();
	const FVector MissionLoc = Mission ? Mission->GetActorLocation() : FVector::ZeroVector;
	ASplinePathActor* Guide = ASplinePathActor::FindGuide(GetWorld(), Mission, Leader->GetActorLocation(), false);
	FVector SlotLoc;
	if (Guide)
	{
		SlotLoc = Guide->GetCorridorSlotLocation(Leader->GetActorLocation(), MissionLoc, Slot, Spacing);
	}
	else
	{
		const int32 Row = (FMath::Max(0, Slot) / 2) + 1;
		const float Side = (Slot % 2 == 0) ? 1.f : -1.f;
		const float Slack = Spacing * 1.75f;
		SlotLoc = Leader->GetActorLocation()
			- Leader->GetActorForwardVector() * (Row * Slack * 0.9f)
			+ Leader->GetActorRightVector() * (Side * Row * Slack * 0.7f);
	}
	const FVector From = GetPawn() ? GetPawn()->GetActorLocation() : SlotLoc;
	return NudgeOutOfFire(From, SlotLoc);
}

void ASoldierAIController::RedirectIfPathHitsFire()
{
	if (!bAvoidFireOnPath || !GetPawn() || !GetWorld())
	{
		return;
	}
	UPathFollowingComponent* PFC = GetPathFollowingComponent();
	if (!PFC)
	{
		return;
	}
	const FNavPathSharedPtr NavPath = PFC->GetPath();
	if (!NavPath.IsValid())
	{
		return;
	}
	const TArray<FNavPathPoint>& Pts = NavPath->GetPathPoints();
	if (Pts.Num() < 2)
	{
		return;
	}

	TArray<FFireHaz> Fires;
	GatherFireHazards(GetWorld(), Fires);
	if (Fires.Num() == 0)
	{
		return;
	}

	const FVector From = GetPawn()->GetActorLocation();
	const float Pad = FireAvoidPadding * 0.45f;
	for (int32 i = 1; i < Pts.Num(); ++i)
	{
		const FVector A = Pts[i - 1].Location;
		const FVector B = Pts[i].Location;
		for (const FFireHaz& H : Fires)
		{
			float T = 0.f;
			const float D = DistPointToSeg2D(A, B, H.Loc, T);
			if (D > H.Radius + Pad)
			{
				continue;
			}
			const float Inner = FMath::Max(0.f, FMath::Square(H.Radius + Pad) - D * D);
			const float Chord = 2.f * FMath::Sqrt(Inner);
			if (Chord <= FireSprintThroughMaxWidth)
			{
				continue;
			}
			bool bSprint = false;
			FString Why;
			FVector Safe = AvoidFireHazards(From, B, bSprint, Why);
			Safe = ProjectToNav(Safe);
			if (FVector::Dist2D(Safe, LastDirectMissionGoal) > 90.f)
			{
				MoveToLocation(Safe, 120.f, true, true, true, false, nullptr, true);
				LastDirectMissionGoal = Safe;
				LastDirectMissionPathTime = GetWorld()->GetTimeSeconds();
				if (PathDebugDue())
				{
					UE_LOG(LogTemp, Warning, TEXT("[PATHDBG] pathHitFire via=%s r=%.0f chord=%.0f %s"),
						*Safe.ToString(), H.Radius, Chord, *Why);
				}
			}
			return;
		}
	}
}

void ASoldierAIController::SetCombatAimTarget(FVector AimLocation, ESquadAIAimMode AimMode, AActor* TargetActor)
{
	FSquadAIAimCommand AimCommand;
	AimCommand.Mode = AimMode;
	AimCommand.AimLocation = AimLocation;
	AimCommand.TargetActor = TargetActor;
	SetAimCommand(AimCommand);

	if (UBlackboardComponent* BB = GetBlackboardComponent())
	{
		BB->SetValueAsObject(TEXT("enemyActor"), TargetActor);
		BB->SetValueAsObject(TEXT("targetActor"), TargetActor);
		BB->SetValueAsBool(TEXT("bIsInAttackRange?"), TargetActor != nullptr);
		BB->SetValueAsVector(TEXT("lastKnownLoc"), AimLocation);
	}

	if (APawn* P = GetPawn())
	{
		if (UCharacterMovementComponent* CMC = Cast<UCharacterMovementComponent>(P->GetComponentByClass(UCharacterMovementComponent::StaticClass())))
		{
			CMC->bOrientRotationToMovement = false;
			CMC->bUseControllerDesiredRotation = true;
		}
	}

	if (TargetActor)
	{
		SetFocus(TargetActor, EAIFocusPriority::Gameplay);
	}
	else
	{
		SetFocalPoint(AimLocation, EAIFocusPriority::Gameplay);
	}
}

bool ASoldierAIController::TryStartBurstAtCurrentAim()
{
	if (USquadAIAdapterComponent* Adapter = GetCachedAdapter())
	{
		return Adapter->TryStartBurstAtAimCommand();
	}
	return false;
}

bool ASoldierAIController::IsBurstFiring() const
{
	if (const USquadAIAdapterComponent* Adapter = GetCachedAdapter())
	{
		return Adapter->IsBurstFiring();
	}
	return false;
}

bool ASoldierAIController::HasCombatAimCommand() const
{
	if (const USquadAIAdapterComponent* Adapter = GetCachedAdapter())
	{
		return Adapter->HasAimCommand();
	}
	return false;
}

bool ASoldierAIController::CanUseAdapterPresentation() const
{
	return GetCachedAdapter() != nullptr;
}

void ASoldierAIController::StopCombatPresentation()
{
	ClearAimCommand();
	if (USquadAIAdapterComponent* Adapter = GetCachedAdapter())
	{
		Adapter->StopBurstAndClearAim();
	}
}

void ASoldierAIController::SetupPerception()
{
	if (!PerceptionComp || bPerceptionInitialized) return;
	bPerceptionInitialized = true;
	const USquadAITuning* T = USquadAITuning::Get();
	SightConfig = NewObject<UAISenseConfig_Sight>(this);
	SightConfig->SightRadius = T->SightRadius;
	SightConfig->LoseSightRadius = T->LoseSightRadius;
	// S5-9: keep the clean-weather baseline so storm scaling never compounds.
	BaseSightRadius = T->SightRadius;
	BaseLoseSightRadius = T->LoseSightRadius;
	SightConfig->PeripheralVisionAngleDegrees = T->PeripheralVisionDegrees;
	SightConfig->DetectionByAffiliation.bDetectEnemies = SightConfig->DetectionByAffiliation.bDetectNeutrals = SightConfig->DetectionByAffiliation.bDetectFriendlies = true;
	PerceptionComp->ConfigureSense(*SightConfig);
	HearingConfig = NewObject<UAISenseConfig_Hearing>(this);
	HearingConfig->HearingRange = T->HearingRange;
	HearingConfig->DetectionByAffiliation.bDetectEnemies = HearingConfig->DetectionByAffiliation.bDetectNeutrals = HearingConfig->DetectionByAffiliation.bDetectFriendlies = true;
	PerceptionComp->ConfigureSense(*HearingConfig);
	DamageConfig = NewObject<UAISenseConfig_Damage>(this);
	PerceptionComp->ConfigureSense(*DamageConfig);
}

void ASoldierAIController::RefreshSightForWeather()
{
	// S5-9: GetCurrentAIVisibilityMultiplier had zero readers — weather was cosmetic.
	// Rescale engine sight radii when the storm multiplier shifts (hysteresis 0.02).
	ASandstormWeatherDirector* Director = Cast<ASandstormWeatherDirector>(CachedStormDirector.Get());
	if (!Director && GetWorld())
	{
		for (TActorIterator<ASandstormWeatherDirector> It(GetWorld()); It; ++It)
		{
			Director = *It;
			break;
		}
		CachedStormDirector = Director;
	}
	const float Mult = Director ? Director->GetCurrentAIVisibilityMultiplier() : 1.f;
	if (FMath::Abs(Mult - LastAppliedWeatherMult) < 0.02f) return;
	LastAppliedWeatherMult = Mult;
	if (SightConfig && PerceptionComp && BaseSightRadius > 0.f)
	{
		SightConfig->SightRadius = BaseSightRadius * Mult;
		SightConfig->LoseSightRadius = FMath::Max(BaseLoseSightRadius * Mult, SightConfig->SightRadius + 50.f);
		PerceptionComp->ConfigureSense(*SightConfig);
	}
}

void ASoldierAIController::OnPerceptionUpdated(AActor* Actor, FAIStimulus Stimulus)
{
	if (!Actor || !Cast<APawn>(Actor)) return;
	bool bIsAlive = true;
	if (ASoldierCharacter* S = Cast<ASoldierCharacter>(Actor)) bIsAlive = S->IsAlive();
	if (!bIsAlive) return;

	// Use this controller's team attitude check.
	const ETeamAttitude::Type Attitude = GetTeamAttitudeTowards(*Actor);
	const TCHAR* AttitudeText = TEXT("Neutral");
	if (Attitude == ETeamAttitude::Hostile)
	{
		AttitudeText = TEXT("Hostile");
	}
	else if (Attitude == ETeamAttitude::Friendly)
	{
		AttitudeText = TEXT("Friendly");
	}

	// S19-ALARM: a hostile seeing the player raises the world alarm. The subsystem's
	// own per-event cooldown keeps one sustained glance from spamming the value up.
	// Deep-review fix B3: the SENSER has to be alive too - a dying man's controller
	// must not keep testifying (same guard the ping handler has always had).
	const APawn* SensingPawn = GetPawn();
	const ASoldierCharacter* SensingSoldier = Cast<ASoldierCharacter>(SensingPawn);
	const bool bSenserAlive = !SensingSoldier || SensingSoldier->IsAlive();
	if (bSenserAlive && Attitude == ETeamAttitude::Hostile && Stimulus.WasSuccessfullySensed())
	{
		if (USquadAIAlarmSubsystem* AlarmSys = USquadAIAlarmSubsystem::Get(this))
		{
			AlarmSys->RaiseEvent(EMissionAlarmEvent::EnemySensed, Actor->GetActorLocation());
		}
	}

	if (ASquadAIAutoSetupManager::AreVerboseDebugLogsEnabled())
	{
		UE_LOG(LogTemp, Warning, TEXT("[SquadAIPerceptionDebug] Pawn=%s ControllerTeam=%d Perceived=%s Class=%s Sensed=%d Attitude=%s StimulusAge=%.2f Strength=%.2f"),
			*GetNameSafe(GetPawn()),
			GetGenericTeamId().GetId(),
			*GetNameSafe(Actor),
			*GetNameSafe(Actor->GetClass()),
			Stimulus.WasSuccessfullySensed() ? 1 : 0,
			AttitudeText,
			Stimulus.GetAge(),
			Stimulus.Strength);
	}

	if (Attitude != ETeamAttitude::Hostile) return;

	if (Stimulus.WasSuccessfullySensed())
	{
		if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(GetPawn()))
		{
			if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
			{
				if (Soldier->IsAlly())
				{
					AudioSys->PlayTacticalVoiceline(ETacticalVoicelineType::Ally_EnemySpotted, Soldier);
				}
				else if (Soldier->IsEnemy())
				{
					AudioSys->PlayTacticalVoiceline(ETacticalVoicelineType::Enemy_Alerted, Soldier);
				}
			}
		}
	}

	UpsertPerceivedHostile(Actor, Stimulus.WasSuccessfullySensed());
}

void ASoldierAIController::UpdateMemory(float DeltaTime)
{
	for (int32 i = Memory.Num() - 1; i >= 0; --i) {
		FPerceivedTarget& T = Memory[i];
		// S19-CORPSE: only ASoldierCharacter used to be checked for death. The pack's
		// enemies are BP_Enemy_* pawns, so a killed one stayed a valid, permanently
		// visible memory entry - which made it the "primary threat" forever and kept
		// the leader stopping to take cover from a body. IsActorDead() covers both.
		if (!T.Actor.IsValid() || SquadAIRecovery::IsActorDead(T.Actor.Get())) {
			// S19-LOGGER + S19-CORPSE: a body leaves threat memory here. NoteOnce keeps it
			// to one line per corpse even though this runs every tick.
			if (AActor* Dead = T.Actor.Get())
			{
				SquadAISituation::NoteOnce(
					FString::Printf(TEXT("corpse-drop:%s:%s"), *GetName(), *GetNameSafe(Dead)),
					FString::Printf(TEXT("CORPSE-DROP %s dropped %s from threat memory (dead, was Conf=%.2f)"),
						*GetName(), *GetNameSafe(Dead), T.Confidence));
			}
			Memory.RemoveAtSwap(i); continue;
		}
		if (!T.bCurrentlyVisible) {
			T.Confidence -= MemoryDecayRate * DeltaTime;
			if (T.Confidence <= 0.f) Memory.RemoveAtSwap(i);
		} else T.LastKnownLocation = T.Actor->GetActorLocation();
	}
}

void ASoldierAIController::UpsertPerceivedHostile(AActor* Actor, bool bCurrentlyVisible)
{
	if (!Actor || !GetPawn()) return;

	FPerceivedTarget* Existing = Memory.FindByPredicate([Actor](const FPerceivedTarget& T) { return T.Actor.Get() == Actor; });
	if (Existing)
	{
		Existing->LastKnownLocation = Actor->GetActorLocation();
		Existing->Confidence = bCurrentlyVisible ? 1.f : Existing->Confidence;
		Existing->bCurrentlyVisible = bCurrentlyVisible;
		if (ASquadAIAutoSetupManager::AreVerboseDebugLogsEnabled())
		{
			UE_LOG(LogTemp, Warning, TEXT("[SquadAIMemoryDebug] Update Pawn=%s Hostile=%s Visible=%d Conf=%.2f MemoryNum=%d"), *GetNameSafe(GetPawn()), *GetNameSafe(Actor), bCurrentlyVisible ? 1 : 0, Existing->Confidence, Memory.Num());
		}
	}
	else if (bCurrentlyVisible)
	{
		FPerceivedTarget NewTarget;
		NewTarget.Actor = Actor;
		NewTarget.LastKnownLocation = Actor->GetActorLocation();
		NewTarget.Confidence = 1.f;
		NewTarget.bCurrentlyVisible = true;
		Memory.Add(NewTarget);
		if (USharedThreatMemorySubsystem* Shared = GetWorld() ? GetWorld()->GetSubsystem<USharedThreatMemorySubsystem>() : nullptr)
		{
			Shared->ReportThreat(Actor, Actor->GetActorLocation(), FVector::ZeroVector, 1.f, GetGenericTeamId().GetId());
		}
		if (ASquadAIAutoSetupManager::AreVerboseDebugLogsEnabled())
		{
			UE_LOG(LogTemp, Warning, TEXT("[SquadAIMemoryDebug] Add Pawn=%s Hostile=%s Visible=1 Conf=1.00 MemoryNum=%d"), *GetNameSafe(GetPawn()), *GetNameSafe(Actor), Memory.Num());
		}
	}
	else
	{
		if (ASquadAIAutoSetupManager::AreVerboseDebugLogsEnabled())
		{
			UE_LOG(LogTemp, Warning, TEXT("[SquadAIMemoryDebug] IgnoreNonVisibleNew Pawn=%s Actor=%s"), *GetNameSafe(GetPawn()), *GetNameSafe(Actor));
		}
	}
}

void ASoldierAIController::PollPerceptionForHostiles()
{
	if (!PerceptionComp || !GetPawn()) return;

	TArray<AActor*> VisibleActors;
	PerceptionComp->GetCurrentlyPerceivedActors(UAISense_Sight::StaticClass(), VisibleActors);

	for (AActor* Actor : VisibleActors)
	{
		if (!Actor || Actor == GetPawn() || !Cast<APawn>(Actor)) continue;

		if (ASoldierCharacter* S = Cast<ASoldierCharacter>(Actor))
		{
			if (!S->IsAlive()) continue;
		}

		if (GetTeamAttitudeTowards(*Actor) == ETeamAttitude::Hostile)
		{
			// S19-BELIEF: seeing is not the same as being able to fight. AI Perception's
			// sight radius is a pack/Blueprint setting and was reporting enemies 300 m away
			// as "currently visible" with confidence 1.00, which kept a combat state alive
			// that the squad could not act on (see S19-STORM). A hostile only counts as
			// visible inside fighting range (engage range x 1.5 = 120 m at current tuning);
			// past that it is *lost* and the normal confidence decay removes it in ~2 s.
			const float EngageRange = FMath::Max(4500.f, USquadAITuning::Get()->MaxEngageRange);
			const float BelievableRange = EngageRange * 1.5f;
			const float Dist = FVector::Dist(GetPawn()->GetActorLocation(), Actor->GetActorLocation());
			const bool bBelievable = (Dist <= BelievableRange);
			const bool bTracked = Memory.ContainsByPredicate(
				[Actor](const FPerceivedTarget& T) { return T.Actor.Get() == Actor; });

			if (!bBelievable && !bTracked)
			{
				continue;   // never seen it: a sight cone is not a reason to believe in it
			}
			if (!bBelievable)
			{
				SquadAISituation::NoteOnce(
					FString::Printf(TEXT("belief:%s:%s"), *GetName(), *GetNameSafe(Actor)),
					FString::Printf(TEXT("BELIEF %s: dropping %s - %.0f m away, past the %.0f m fighting range (the sight cone still reports it)"),
						*GetNameSafe(GetPawn()), *GetNameSafe(Actor), Dist / 100.f, BelievableRange / 100.f));
			}
			UpsertPerceivedHostile(Actor, bBelievable);
		}
	}
}

void ASoldierAIController::PollRegistryForHostiles()
{
	APawn* Self = GetPawn();
	UWorld* World = GetWorld();
	if (!Self || !World) return;

	const float Now = World->GetTimeSeconds();
	const float PollInterval = (CurrentLODBucket >= 3) ? 0.75f : 0.25f;
	if ((Now - LastRegistryPollTime) < PollInterval)
	{
		return;
	}
	LastRegistryPollTime = Now;

	USoldierRegistrySubsystem* Registry = World->GetSubsystem<USoldierRegistrySubsystem>();
	if (!Registry) return;

	const FVector SelfLoc = Self->GetActorLocation();
	float PollRange = DirectCombatRange;
	if (CurrentLODBucket >= 3)
	{
		PollRange = FMath::Min(PollRange, 4500.f);
	}
	const float PollRangeSq = PollRange * PollRange;
	int32 LosBudget = (CurrentLODBucket >= 3) ? 1 : 3;

	auto Consider = [&](AActor* Other)
	{
		if (!Other || Other == Self) return;
		if (ASoldierCharacter* S = Cast<ASoldierCharacter>(Other))
		{
			if (!S->IsAlive()) return;
		}
		if (GetTeamAttitudeTowards(*Other) != ETeamAttitude::Hostile) return;

		const float DistSq = FVector::DistSquared(SelfLoc, Other->GetActorLocation());
		if (DistSq > PollRangeSq) return;

		const bool bAlreadyVisible = Memory.FindByPredicate([Other](const FPerceivedTarget& T)
		{
			return T.Actor.Get() == Other && T.bCurrentlyVisible;
		}) != nullptr;
		if (bAlreadyVisible)
		{
			UpsertPerceivedHostile(Other, true);
			return;
		}

		const float Dist = FMath::Sqrt(DistSq);
		if (Dist <= DirectCombatCloseRangeOverride)
		{
			UpsertPerceivedHostile(Other, true);
			return;
		}
		if (LosBudget > 0 && HasLineOfSightTo(Other))
		{
			--LosBudget;
			UpsertPerceivedHostile(Other, true);
		}
	};

	TArray<ASoldierCharacter*> Nearby = Registry->QueryRadius(SelfLoc, PollRange);
	for (ASoldierCharacter* Other : Nearby)
	{
		Consider(Other);
	}

	if (APawn* Player = UGameplayStatics::GetPlayerPawn(World, 0))
	{
		Consider(Player);
	}

	const TArray<TWeakObjectPtr<APawn>>& Broad = Registry->GetBroadPawns();
	for (const TWeakObjectPtr<APawn>& WeakP : Broad)
	{
		APawn* OtherPawn = WeakP.Get();
		if (!OtherPawn || OtherPawn->IsA<ASoldierCharacter>()) continue;
		Consider(OtherPawn);
		if (LosBudget <= 0) break;
	}
}

void ASoldierAIController::RunDirectCombatFallback(float DeltaTime)
{
	if (!bEnableDirectCombatFallback || !GetPawn()) return;

	const float Now = GetWorld() ? GetWorld()->GetTimeSeconds() : 0.f;

	// Periodic diagnostic log — tells us exactly what's happening every 3 seconds
	const bool bShouldLogDiagnostic = (Now - LastCombatDiagnosticLogTime) >= 3.0f;
	if (bShouldLogDiagnostic)
	{
		LastCombatDiagnosticLogTime = Now;
	}

	// --- Find the best threat ---
	float Confidence = 0.f;
	AActor* Threat = GetPrimaryThreat(Confidence);
	if (!Threat || Confidence < 0.15f)
	{
		if (bWasFiringLastTick)
		{
			StopCombatPresentation();
			bWasFiringLastTick = false;
			bHasInitiatedFiringThisEngagement = false;
		}
		if (bShouldLogDiagnostic && ASquadAIAutoSetupManager::AreVerboseDebugLogsEnabled())
		{
			UE_LOG(LogTemp, Warning, TEXT("[SquadAIDiag] %s — NoThreat Memory=%d"), *GetNameSafe(GetPawn()), Memory.Num());
		}
		return;
	}

	// Skip dead threats
	if (const APawn* ThreatPawn = Cast<APawn>(Threat))
	{
		// Check if alive via SoldierCharacter or just check pawn is still valid
		if (const ASoldierCharacter* ThreatSoldier = Cast<ASoldierCharacter>(Threat))
		{
			if (!ThreatSoldier->IsAlive())
			{
				StopCombatPresentation();
				bWasFiringLastTick = false;
				bHasInitiatedFiringThisEngagement = false;
				return;
			}
		}
	}

	const float Dist = FVector::Dist(GetPawn()->GetActorLocation(), Threat->GetActorLocation());
	if (Dist > DirectCombatRange)
	{
		return;
	}

	// S4-3: the tuning safety switch + range finally gate the fallback (was: always
	// fires). Defaults (true / 8000cm) preserve current behavior; designers can now
	// actually turn the fallback off or shorten its reach.
	if (!bAllowDirectCombatFallbackFire || Dist > DirectCombatFallbackFireRange)
	{
		if (bWasFiringLastTick)
		{
			StopCombatPresentation();
			bWasFiringLastTick = false;
		}
		return;
	}

	// --- Line of sight check ---
	const bool bHasCombatLOS = HasLineOfSightTo(Threat) || Dist <= DirectCombatCloseRangeOverride;
	if (!bHasCombatLOS)
	{
		if (bWasFiringLastTick)
		{
			StopCombatPresentation();
			bWasFiringLastTick = false;
		}
		if (bShouldLogDiagnostic && ASquadAIAutoSetupManager::AreVerboseDebugLogsEnabled())
		{
			UE_LOG(LogTemp, Warning, TEXT("[SquadAIDiag] %s — NoLOS to %s dist=%.0f"), *GetNameSafe(GetPawn()), *GetNameSafe(Threat), Dist);
		}
		return;
	}

	// --- We have a visible hostile threat within range. AIM AND FIRE. ---
	const FVector AimLoc = Threat->GetActorLocation() + FVector(0.f, 0.f, 70.f);
	SetCombatAimTarget(AimLoc, ESquadAIAimMode::CombatTarget, Threat);

	// Log the first time we engage a target
	if (!bWasFiringLastTick)
	{
		if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
		{
			AudioSys->PlayTacticalVoiceline(ETacticalVoicelineType::Ally_EnemySpotted, GetPawn());
		}

		UE_LOG(LogTemp, Warning, TEXT("[SquadAICombat] %s (team %d) engaging %s at dist %.0f conf %.2f LOS=1"),
			*GetNameSafe(GetPawn()), GetGenericTeamId().GetId(), *GetNameSafe(Threat), Dist, Confidence);
	}

	// MOVEMENT: fireteam members keep their assigned job. Suppress/flank hold
	// their slots and shoot.
	const bool bFireteamHold = bInEnemyFireteam
		&& (FireteamRole == EEnemyFireteamRole::Suppress
			|| FireteamRole == EEnemyFireteamRole::FlankLeft
			|| FireteamRole == EEnemyFireteamRole::FlankRight);
	// S14-AI: HOLD AND FIGHT. Assault/loner PreferredFireRange was 1500 -
	// INSIDE the S13-AI engagement hold (2200). STTask_EnemyMission stopped
	// them at 2200 and this block immediately re-issued MoveToActor with a
	// 1200 acceptance every second, so the two owners fought and the MoveTo
	// won: enemies sprinted into the player's face. This block now enforces
	// the SAME hold line: inside 2200 stop and fight (about half of them in a
	// crouched firing pose), and only close distance when beyond 2400 - the
	// suppress/flank fireteam behavior the user saw working ("a few crouch")
	// is effectively extended to everyone.
	static const float DirectEngageHoldRange = 2200.f; // keep == STTask_EnemyMission EngageHoldRange
	const float PreferredFireRange = bFireteamHold ? 2800.f : 2400.f;
	const float MaxEngageRange = 4000.f;
	// S18-LEAD: the LEADER used to fall into this hold-and-fight block, which
	// calls StopMovement() every tick while any visible hostile sits inside
	// 2200. Near the quest zone there is always one, so he halted, the path
	// task re-issued a move, this halted him again — the stop/start pacing that
	// never reached the zone. Movement for every team-0 pawn (leader included)
	// is owned by its StateTree task; this block only aims and fires for them.
	// STTask_LeaderPath still stops the leader for hostiles inside 15 m.
	const bool bAllyFollower = (GetGenericTeamId() == FGenericTeamId(0));
	if (!bFireteamHold && !bAllyFollower)
	{
		ASoldierCharacter* HoldSoldier = GetSoldierCharacter();
		if (Dist <= DirectEngageHoldRange)
		{
			if (UPathFollowingComponent* HoldPFC = GetPathFollowingComponent())
			{
				if (HoldPFC->GetStatus() == EPathFollowingStatus::Moving)
				{
					StopMovement();
				}
			}
			// Roughly half the soldiers fight crouched at the hold line
			// (deterministic per pawn so the pose never flickers). Never touch
			// anyone the cover system has placed - TakeCover owns their pose.
			if (HoldSoldier && !HoldSoldier->bIsInCover)
			{
				const bool bCroucher = (HoldSoldier->GetUniqueID() & 1u) == 0u;
				if (bCroucher && !HoldSoldier->bIsCrouched)
				{
					HoldSoldier->Crouch();
				}
			}
		}
		else if (Dist > PreferredFireRange)
		{
			// Stand back up before repositioning (only our own hold-crouch:
			// cover-system poses have bIsInCover set and are left alone).
			if (HoldSoldier && !HoldSoldier->bIsInCover && HoldSoldier->bIsCrouched)
			{
				HoldSoldier->UnCrouch();
			}
			const float Now2 = GetWorld() ? GetWorld()->GetTimeSeconds() : 0.f;
			if (Now2 - LastDirectCombatBurstTime >= 1.0f || Dist > MaxEngageRange)
			{
				MoveToActor(Threat, PreferredFireRange * 0.8f);
			}
		}
	}

	// Fire repeatedly every 1 second
	if (Now - LastDirectCombatBurstTime >= 1.0f)
	{
		// Tactical AI Grenade Usage:
		// S14-AI: GRENADE DISCIPLINE. The old frag gate was distance + a 35%/s
		// roll + only the component's 3 s cooldown - every closing enemy dumped
		// both frags at the player within seconds of contact ("they run to me
		// and throw grenades at me"). The comment always said "entrenched" but
		// nothing measured it. A frag now needs ALL of: the threat actually
		// entrenched (moved < 4 m across a 4 s sample - a camping/dug-in
		// target), 800-2200 cm, a 10%/s roll, and >= 15 s since this soldier's
		// previous AI throw of any type. Smoke keeps its suppression trigger
		// but shares the 15 s interval.
		if (ASoldierCharacter* SelfSoldier = GetSoldierCharacter())
		{
			if (SelfSoldier->GrenadeComp)
			{
				if (GrenadeThreatSample.Get() != Threat)
				{
					GrenadeThreatSample = Threat;
					GrenadeThreatSampleLoc = Threat->GetActorLocation();
					GrenadeThreatSampleTime = Now;
					bGrenadeThreatEntrenched = false;
				}
				else if (Now - GrenadeThreatSampleTime >= 4.0f)
				{
					bGrenadeThreatEntrenched = FVector::DistSquared(Threat->GetActorLocation(), GrenadeThreatSampleLoc) <= FMath::Square(400.f);
					GrenadeThreatSampleLoc = Threat->GetActorLocation();
					GrenadeThreatSampleTime = Now;
				}
				const bool bGrenadeIntervalOK = (Now - LastAIGrenadeThrowTime) >= 15.0f;

				// 1. If heavily suppressed, throw defensive Smoke Screen toward threat
				if (Suppression >= 0.70f && bGrenadeIntervalOK && SelfSoldier->GrenadeComp->CanThrowGrenade(EGrenadeType::SmokeScreen))
				{
					const FVector ThreatDir = (Threat->GetActorLocation() - SelfSoldier->GetActorLocation()).GetSafeNormal();
					if (SelfSoldier->GrenadeComp->ThrowGrenadeInDirection(EGrenadeType::SmokeScreen, ThreatDir))
					{
						LastAIGrenadeThrowTime = Now;
					}
				}
				// 2. Frag only flushes an ENTRENCHED threat at medium distance
				else if (bGrenadeThreatEntrenched && bGrenadeIntervalOK
					&& Dist >= 800.f && Dist <= 2200.f && FMath::FRand() < 0.10f
					&& SelfSoldier->GrenadeComp->CanThrowGrenade(EGrenadeType::Fragmentation))
				{
					if (SelfSoldier->GrenadeComp->ThrowGrenadeAtLocation(EGrenadeType::Fragmentation, Threat->GetActorLocation()))
					{
						LastAIGrenadeThrowTime = Now;
					}
				}
			}
		}

		// Check adapter
		USquadAIAdapterComponent* Adapter = GetCachedAdapter();
		const bool bStarted = TryStartBurstAtCurrentAim();
		LastDirectCombatBurstTime = Now;
		bWasFiringLastTick = true;

		if (ASquadAIAutoSetupManager::AreVerboseDebugLogsEnabled())
		{
			UE_LOG(LogTemp, Warning, TEXT("[SquadAIDiag] %s — Fire attempt: Adapter=%d Started=%d Threat=%s Dist=%.0f"),
				*GetNameSafe(GetPawn()), Adapter ? 1 : 0, bStarted ? 1 : 0, *GetNameSafe(Threat), Dist);
		}
	}
	else
	{
		bWasFiringLastTick = true;
	}
}

// ===== ENEMY MOVEMENT TO MISSION ZONE =====

void ASoldierAIController::RunDirectEnemyMovement(float DeltaTime)
{
	if (!GetPawn()) return;
	if (IsLeaderController()) return;
	// Allies follow the leader. This path is enemy-zone hunting only.
	// Running it on followers fights FollowLeader and zigzags them toward the mission.
	if (const ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(GetPawn()))
	{
		if (!Soldier->IsEnemy())
		{
			return;
		}
	}
	else if (GetGenericTeamId() != FGenericTeamId(1))
	{
		return;
	}

	float ThreatConf = 0.f;
	AActor* Threat = GetPrimaryThreat(ThreatConf);
	const float ThreatDist = (Threat && ThreatConf >= 0.15f)
		? FVector::Dist(GetPawn()->GetActorLocation(), Threat->GetActorLocation())
		: TNumericLimits<float>::Max();

	const float Now = GetWorld() ? GetWorld()->GetTimeSeconds() : 0.f;

	// 1. If we have a perceived threat (player or squad ally), advance directly toward them!
	if (Threat && ThreatConf >= 0.15f)
	{
		if (ThreatDist > 550.f || !HasLineOfSightTo(Threat))
		{
			if (Now - LastDirectMissionPathTime < 1.0f)
			{
				UPathFollowingComponent* PFC = GetPathFollowingComponent();
				if (PFC && PFC->GetStatus() == EPathFollowingStatus::Moving) return;
			}

			// Direct forward assault with slight lateral offset to avoid stacking
			const float LateralOffset = ((GetUniqueID() % 3) - 1) * 120.f;
			const FVector AdvanceDir = (Threat->GetActorLocation() - GetPawn()->GetActorLocation()).GetSafeNormal2D();
			const FVector RightDir = FVector(-AdvanceDir.Y, AdvanceDir.X, 0.f);
			const FVector AdvanceTarget = Threat->GetActorLocation() + RightDir * LateralOffset;

			MoveToLocation(AdvanceTarget, 300.f, true, true, true, false, nullptr, true);
			LastDirectMissionPathTime = Now;
		}
		else
		{
			// Within combat range and has line of sight: halt to fire accurately
			UPathFollowingComponent* PFC = GetPathFollowingComponent();
			if (PFC && PFC->GetStatus() == EPathFollowingStatus::Moving)
			{
				StopMovement();
			}
		}
		return;
	}

	// S19-PATROL: with no threat inside his (short) engagement envelope, a patroller's movement
	// belongs to his route. Without this the advance-on-the-player fallback below would drag
	// him off his beat, which is exactly what a patrol must not do. Threats are handled above;
	// once he is ENGAGED the patrol pawn hands movement over and this function drives him.
	if (const AEnemyPatroller* Patroller = Cast<AEnemyPatroller>(GetPawn()))
	{
		// Movement belongs to the route unless he is ENGAGED - alert with a hostile of his
		// own to deal with. "Alerted but nothing to shoot" (a neighbour's shout, a scripted
		// alert) is still his beat; handing him to the advance-on-the-player fallback in
		// that state would march him off his route for the whole linger window.
		if (!Patroller->IsEngaged())
		{
			return;
		}
	}

	// 2. If in fireteam formation, follow fireteam slot
	if (bInEnemyFireteam && !FireteamMoveGoal.IsNearlyZero())
	{
		const float NowFt = GetWorld() ? GetWorld()->GetTimeSeconds() : 0.f;
		if (NowFt - LastDirectMissionPathTime < 1.25f)
		{
			UPathFollowingComponent* PFC = GetPathFollowingComponent();
			if (PFC && PFC->GetStatus() == EPathFollowingStatus::Moving) return;
		}
		const float DistToSlot = FVector::Dist(GetPawn()->GetActorLocation(), FireteamMoveGoal);
		if (DistToSlot > 220.f)
		{
			MoveToLocation(FireteamMoveGoal, 180.f, true, true, true, false, nullptr, true);
			LastDirectMissionPathTime = NowFt;
			LastDirectMissionGoal = FireteamMoveGoal;
		}
		return;
	}

	// 3. Fallback: Search for player pawn and advance toward frontlines
	APawn* PlayerPawn = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	if (PlayerPawn)
	{
		const float DistToPlayer = FVector::Dist(GetPawn()->GetActorLocation(), PlayerPawn->GetActorLocation());
		if (DistToPlayer > 500.f && DistToPlayer < 12000.f)
		{
			if (Now - LastDirectMissionPathTime < 2.5f)
			{
				UPathFollowingComponent* PFC = GetPathFollowingComponent();
				if (PFC && PFC->GetStatus() == EPathFollowingStatus::Moving) return;
			}
			const float SpreadAngle = (GetUniqueID() % 8) * (PI / 4.0f);
			const FVector AttackLoc = PlayerPawn->GetActorLocation() + FVector(FMath::Cos(SpreadAngle) * 450.f, FMath::Sin(SpreadAngle) * 450.f, 0.f);
			StopMovement();
			MoveToLocation(AttackLoc, 350.f, true, true, true, false, nullptr, true);
			LastDirectMissionPathTime = Now;
			return;
		}
	}

	// 4. Mission Zone Defense
	const float NowScan = GetWorld() ? GetWorld()->GetTimeSeconds() : 0.f;
	if ((NowScan - LastEnemyZoneScanTime) >= 0.5f || CachedEnemyZoneCenter.IsNearlyZero())
	{
		LastEnemyZoneScanTime = NowScan;
		CachedEnemyZoneCenter = FVector::ZeroVector;
		auto IsAssaultMission = [](const AMissionZone* Z) -> bool
		{
			return Z && (Z->MissionType == EMissionType::Clear || Z->MissionType == EMissionType::Defend);
		};
		AMissionZone* CurrentMission = FindActiveMissionZone();
		if (!IsAssaultMission(CurrentMission))
		{
			// P7-AI1 FALLBACK: keep enemies advancing toward the quest zone even when the
			// chain is not active yet (auto-start delay / save restore / re-setup) or the
			// active mission is not Clear/Defend — previously this returned a zero goal
			// and wave-spawned enemies simply stood at their spawn points.
			CurrentMission = nullptr;
			if (AQuestChain* C = AQuestChain::FindPreferred(GetWorld(), true))
			{
				if (IsAssaultMission(C->GetCurrentMission())) CurrentMission = C->GetCurrentMission();
			}
			if (!CurrentMission)
			{
				if (AQuestChain* C = AQuestChain::FindPreferred(GetWorld(), false))
				{
					if (IsAssaultMission(C->GetCurrentMission())) CurrentMission = C->GetCurrentMission();
				}
			}
			if (!CurrentMission)
			{
				AMissionZone* FirstAny = nullptr;
				for (TActorIterator<AMissionZone> It(GetWorld()); It; ++It)
				{
					AMissionZone* Z = *It;
					if (!Z) continue;
					if (IsAssaultMission(Z)) { CurrentMission = Z; break; }
					if (!FirstAny) FirstAny = Z;
				}
				if (!CurrentMission) CurrentMission = FirstAny; // last resort: always advance
			}
		}
		if (CurrentMission)
		{
			CachedEnemyZoneCenter = CurrentMission->GetActorLocation();
		}
	}
	const FVector ZoneCenter = CachedEnemyZoneCenter;

	if (ZoneCenter.IsNearlyZero()) return;

	if (Now - LastDirectMissionPathTime < 3.0f)
	{
		UPathFollowingComponent* PFC = GetPathFollowingComponent();
		if (PFC && PFC->GetStatus() == EPathFollowingStatus::Moving) return;
	}
	StopMovement();
	MoveToLocation(ZoneCenter, 600.f, true, true, true, false, nullptr, true);
	LastDirectMissionPathTime = Now;
}

AActor* ASoldierAIController::GetPrimaryThreat(float& OutConfidence) const
{
	OutConfidence = 0.f;
	if (!GetPawn()) return nullptr;

	// S19-STORM: a re-entry storm proved this controller's threat cannot be acted on right
	// now. Reporting "no threat" for a few seconds is what lets the StateTree settle back
	// into following / pathing instead of cycling through combat forever.
	if (const UWorld* W = GetWorld())
	{
		if (W->GetTimeSeconds() < ThreatSuppressUntil)
		{
			return nullptr;
		}
	}

	AActor* Best = nullptr;
	float BestScore = -FLT_MAX;
	for (const FPerceivedTarget& T : Memory)
	{
		AActor* Candidate = T.Actor.Get();
		if (!Candidate) continue;
		// G-6: never hunt friendlies — stale/shared entries must not turn hunters onto teammates.
		if (GetTeamAttitudeTowards(*Candidate) != ETeamAttitude::Hostile) continue;
		// S19-CORPSE: pack enemies are not ASoldierCharacter, so the IsAlive() test
		// below never ran for them and a corpse could be picked as the primary
		// threat indefinitely. IsActorDead() handles native and pack pawns alike.
		if (SquadAIRecovery::IsActorDead(Candidate)) continue;
		if (const ASoldierCharacter* S = Cast<ASoldierCharacter>(Candidate))
		{
			if (!S->IsAlive()) continue;
			if (S->HasSpawnGracePeriod()) continue;
		}

		float Score = T.Confidence * 1000.f - FVector::DistSquared(T.LastKnownLocation, GetPawn()->GetActorLocation()) * 0.001f;
		if (Score > BestScore)
		{
			BestScore = Score;
			Best = Candidate;
			OutConfidence = T.Confidence;
		}
	}
	return Best;
}

TArray<AActor*> ASoldierAIController::GetCurrentlyVisibleHostiles() const
{
	TArray<AActor*> Result;
	for (const FPerceivedTarget& T : Memory) if (T.bCurrentlyVisible && T.Actor.IsValid()) Result.Add(T.Actor.Get());
	return Result;
}

void ASoldierAIController::AddSuppression(float Amount)
{
	const float PrevSupp = Suppression;
	Suppression = FMath::Clamp(Suppression + Amount, 0.f, 1.f);
	if (Suppression >= 0.55f && PrevSupp < 0.55f)
	{
		if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(GetPawn()))
		{
			if (Soldier->IsAlly())
			{
				if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
				{
					AudioSys->PlayTacticalVoiceline(ETacticalVoicelineType::Ally_UnderFire, Soldier);
				}
			}
		}
	}
}

void ASoldierAIController::SetActiveCoverMoveGoal(FVector GoalLocation, bool bUsesRealCover)
{
	ActiveCoverMoveGoal = GoalLocation;
	bHasActiveCoverMoveGoal = !GoalLocation.IsNearlyZero();
	bActiveCoverMoveUsesRealCover = bUsesRealCover;
	ActiveCoverMoveStartedTime = GetWorld() ? GetWorld()->GetTimeSeconds() : 0.f;
}

void ASoldierAIController::ClearActiveCoverMoveGoal(bool bMarkTakeCoverCompleted)
{
	ActiveCoverMoveGoal = FVector::ZeroVector;
	bHasActiveCoverMoveGoal = false;
	bActiveCoverMoveUsesRealCover = false;
	ActiveCoverMoveStartedTime = -1000.f;
	if (bMarkTakeCoverCompleted)
	{
		LastTakeCoverCompletedTime = GetWorld() ? GetWorld()->GetTimeSeconds() : LastTakeCoverCompletedTime;
	}
}

void ASoldierAIController::HoldCoverReservation(const FIntPoint& ChunkKey, int32 LocalID)
{
	// Replace any previous hold (the caller secures the new point first).
	ReleaseHeldCoverReservation();
	HeldCoverChunk = ChunkKey;
	HeldCoverLocalID = LocalID;
	bHasHeldCover = true;
}

void ASoldierAIController::ReleaseHeldCoverReservation()
{
	if (!bHasHeldCover) return;
	const FIntPoint ChunkKey = HeldCoverChunk;
	const int32 LocalID = HeldCoverLocalID;
	bHasHeldCover = false;
	HeldCoverLocalID = -1;
	HeldCoverChunk = FIntPoint::ZeroValue;
	if (UWorld* World = GetWorld())
	{
		if (UCoverSystemSubsystem* CoverSys = World->GetSubsystem<UCoverSystemSubsystem>())
		{
			CoverSys->ReleaseCover(ChunkKey, LocalID);
		}
	}
}

void ASoldierAIController::RequestCover(FVector TL, float R) {
	bHasPendingCover = false;
	bCoverQueryFinished = false;
	bLastCoverQuerySucceeded = false;
	LastCoverRequestTime = GetWorld() ? GetWorld()->GetTimeSeconds() : LastCoverRequestTime;
	UCoverSystemSubsystem* CS = GetWorld()->GetSubsystem<UCoverSystemSubsystem>();
	if (!CS || !GetPawn()) {
		bCoverQueryFinished = true;
		bLastCoverQuerySucceeded = false;
		return;
	}
	TWeakObjectPtr<ASoldierAIController> WeakSelf(this);
	CS->RequestCoverAsync(GetPawn(), GetPawn()->GetActorLocation(), TL, R, [WeakSelf](bool bFound, const FCoverPoint& Res) {
		if (WeakSelf.IsValid()) {
			WeakSelf->PendingCoverResult = Res;
			WeakSelf->bHasPendingCover = bFound;
			WeakSelf->bCoverQueryFinished = true;
			WeakSelf->bLastCoverQuerySucceeded = bFound;
		}
	});
}

void ASoldierAIController::IngestSharedThreat(AActor* Threat, const FVector& Loc, float Confidence)
{
	if (!Threat || !GetPawn() || Confidence < 0.15f)
	{
		return;
	}
	// G-6: shared intel is only valid for hostiles — refuse friendly entries outright.
	if (GetTeamAttitudeTowards(*Threat) != ETeamAttitude::Hostile)
	{
		return;
	}
	FPerceivedTarget* Existing = Memory.FindByPredicate([Threat](const FPerceivedTarget& T) { return T.Actor.Get() == Threat; });
	if (Existing)
	{
		Existing->LastKnownLocation = Loc;
		Existing->Confidence = FMath::Max(Existing->Confidence, Confidence);
		return;
	}
	FPerceivedTarget NewTarget;
	NewTarget.Actor = Threat;
	NewTarget.LastKnownLocation = Loc;
	NewTarget.Confidence = Confidence;
	NewTarget.bCurrentlyVisible = false;
	Memory.Add(NewTarget);
}

ASoldierCharacter* ASoldierAIController::GetSoldierCharacter() const { return Cast<ASoldierCharacter>(GetPawn()); }

bool ASoldierAIController::HasNearbyHostile(float Range) const
{
	if (!GetPawn() || !GetWorld()) return false;

	const float RangeSq = Range * Range;
	const FVector SelfLoc = GetPawn()->GetActorLocation();
	for (const FPerceivedTarget& T : Memory)
	{
		AActor* A = T.Actor.Get();
		// S19-CORPSE: a body in the memory list is not a threat. Treating one as a
		// close hostile is exactly what made the leader stop on the mission path
		// (he cover-dances around a corpse that can never stop being "hostile").
		if (A && !SquadAIRecovery::IsActorDead(A)
			&& FVector::DistSquared(SelfLoc, A->GetActorLocation()) <= RangeSq)
		{
			return true;
		}
	}

	if (USoldierRegistrySubsystem* Registry = GetWorld()->GetSubsystem<USoldierRegistrySubsystem>())
	{
		TArray<ASoldierCharacter*> Nearby = Registry->QueryRadius(SelfLoc, Range);
		for (ASoldierCharacter* S : Nearby)
		{
			if (!S || S == GetPawn() || !S->IsAlive()) continue;
			if (S->GetGenericTeamId().GetId() != GetGenericTeamId().GetId())
			{
				return true;
			}
		}
	}
	return false;
}

bool ASoldierAIController::HasCombatThreat(float MinConfidence) const
{
	if (!GetPawn()) return false;

	float Confidence = 0.f;
	AActor* Threat = GetPrimaryThreat(Confidence);
	return Threat && Confidence >= MinConfidence;
}

bool ASoldierAIController::HasLineOfSightTo(AActor* Target) const {
	if (!Target || !GetPawn() || !GetWorld()) return false;

	const float Now = GetWorld()->GetTimeSeconds();
	if (CachedLosTarget.Get() == Target && (Now - CachedLosTime) < 0.12f)
	{
		return CachedLosResult;
	}

	const FVector Start = GetPawn()->GetActorLocation() + FVector(0,0,60);
	const FVector End = Target->GetActorLocation() + FVector(0,0,60);

	// Check if smoke screen intersects the sightline
	if (USoldierRegistrySubsystem* Reg = GetWorld()->GetSubsystem<USoldierRegistrySubsystem>())
	{
		if (Reg->IsLineOfSightBlockedBySmoke(Start, End))
		{
			CachedLosTarget = Target;
			CachedLosTime = Now;
			CachedLosResult = false;
			return false;
		}
	}

	FHitResult Hit; FCollisionQueryParams P; P.AddIgnoredActor(GetPawn());
	bool bSee = true;
	if (GetWorld()->LineTraceSingleByChannel(Hit, Start, End, ECC_Visibility, P))
	{
		AActor* HitActor = Hit.GetActor();
		bSee = (HitActor == Target);
		if (!bSee)
		{
			for (AActor* Cursor = HitActor; Cursor; Cursor = Cursor->GetAttachParentActor())
			{
				if (Cursor == Target)
				{
					bSee = true;
					break;
				}
			}
		}
	}

	CachedLosTarget = Target;
	CachedLosTime = Now;
	CachedLosResult = bSee;
	return bSee;
}

AQuestZone* ASoldierAIController::GetFallbackQuestZone()
{
	// S5-7b: per-controller, world-checked cache (a function-static here used to
	// leak goals across PIE worlds).
	AQuestZone* Z = CachedFallbackQuestZone.Get();
	if (Z && Z->GetWorld() != GetWorld())
	{
		Z = nullptr;
		CachedFallbackQuestZone.Reset();
	}
	if (Z)
	{
		return Z;
	}

	if (UWorld* World = GetWorld())
	{
		for (TActorIterator<AQuestZone> It(World); It; ++It)
		{
			CachedFallbackQuestZone = *It;
			return *It;
		}
	}
	return nullptr;
}

void ASoldierAIController::NotifyLeaderPathTaskActive()
{
	LeaderPathTaskHeartbeat = GetWorld() ? GetWorld()->GetTimeSeconds() : 0.f;
}

bool ASoldierAIController::IsLeaderPathTaskDriving() const
{
	const float Now = GetWorld() ? GetWorld()->GetTimeSeconds() : 0.f;
	return (Now - LeaderPathTaskHeartbeat) <= 0.5f;
}

void ASoldierAIController::RunDirectMissionPathing(float DeltaTime)
{
	if (!GetPawn() || !IsLeaderController()) return;

	// S18-LEAD: the StateTree task and this function were BOTH issuing moves for
	// the leader every tick (UAITask_MoveTo accept 250 here vs MoveToLocation
	// accept 180 there, with different combat/player gates). Each new request
	// aborts the other's path — that is the walk-stop-drift-back loop. While the
	// task is ticking it owns movement and this function stands down; if the
	// StateTree asset has no LeaderPath task, the heartbeat goes stale in 0.5 s
	// and this takes over again exactly as before.
	if (IsLeaderPathTaskDriving())
	{
		return;
	}

	// Gate AI movement during initial level startup / deployment warmup screen
	if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this))
	{
		if (HUD->IsWarmupVeilActive())
		{
			return;
		}
	}

	// Do not path to mission while actively fighting
	float ThreatConf = 0.f;
	AActor* Threat = GetPrimaryThreat(ThreatConf);
	if (Threat && ThreatConf >= 0.15f)
	{
		const float ThreatDist = FVector::Dist(GetPawn()->GetActorLocation(), Threat->GetActorLocation());
		if (ThreatDist <= DirectCombatRange && (HasLineOfSightTo(Threat) || ThreatDist <= DirectCombatCloseRangeOverride))
		{
			if (PathDebugDue())
			{
				UE_LOG(LogTemp, Warning, TEXT("[PATHDBG] Leader %s BLOCKED by combat — Threat=%s Dist=%.0f Conf=%.2f"),
					*GetNameSafe(GetPawn()), *GetNameSafe(Threat), ThreatDist, ThreatConf);
			}
			return;
		}
	}

	// Universal pacing — ensure squad stays reasonably coherent without freezing leader prematurely
	if (APawn* PlayerPawn = UGameplayStatics::GetPlayerPawn(GetWorld(), 0))
	{
		const float PlayerDist = FVector::Dist(GetPawn()->GetActorLocation(), PlayerPawn->GetActorLocation());
		// S18-LEAD: match ALeaderCharacter::WaitForPlayerRadius (the radius that
		// actually zeroes his walk speed) instead of a second hardcoded 3500.
		float WaitRadius = 3500.f;
		ALeaderCharacter* LeaderPawn = Cast<ALeaderCharacter>(GetPawn());
		if (LeaderPawn)
		{
			WaitRadius = FMath::Max(400.f, LeaderPawn->WaitForPlayerRadius);
		}
		// S19-LEADWAIT: same shared decision as the StateTree task - a far player is
		// only a reason to stop when he is BEHIND, and never for longer than the
		// leader's MaxWaitForPlayerSeconds.
		const bool bHaltForPlayer = LeaderPawn ? LeaderPawn->ShouldHaltForPlayer(PlayerDist)
			: (PlayerDist > WaitRadius);
		if (bHaltForPlayer)
		{
			if (PathDebugDue())
			{
				UE_LOG(LogTemp, Warning, TEXT("[PATHDBG] Leader %s WAITING for player — dist=%.0f"),
					*GetNameSafe(GetPawn()), PlayerDist);
			}
			return;
		}
	}

	FVector GoalLoc = GetEffectiveMoveGoal();

	if (GoalLoc.IsNearlyZero())
	{
		if (AMissionZone* CurrentMission = FindActiveMissionZone())
		{
			GoalLoc = ApplySplineAndFireToGoal(CurrentMission->GetActorLocation());
		}
	}

	if (GoalLoc.IsNearlyZero())
	{
		// S11-AI: shared with the enemy mission task (was duplicated here).
		if (AQuestZone* Z = GetFallbackQuestZone())
		{
			GoalLoc = ApplySplineAndFireToGoal(Z->GetActorLocation());
		}
	}

	if (GoalLoc.IsNearlyZero())
	{
		if (PathDebugDue())
		{
			UE_LOG(LogTemp, Warning, TEXT("[PATHDBG] Leader %s NO GOAL — no active QuestChain or MissionZone found"),
				*GetNameSafe(GetPawn()));
		}
		return;
	}

	const float Now = GetWorld() ? GetWorld()->GetTimeSeconds() : 0.f;
	const float DistToGoal = FVector::Dist(GetPawn()->GetActorLocation(), GoalLoc);

	if (Now < FireHesitateUntil)
	{
		StopMovement();
		if (!LastFireLookAt.IsNearlyZero())
		{
			SetFocalPoint(LastFireLookAt, EAIFocusPriority::Gameplay);
		}
		if (PathDebugDue(0.5f))
		{
			UE_LOG(LogTemp, Warning, TEXT("[PATHDBG] Leader %s hesitate at fire %.2fs %s"),
				*GetNameSafe(GetPawn()), FireHesitateUntil - Now, *LastPathDebugReason);
		}
		return;
	}

	RedirectIfPathHitsFire();

	if (DistToGoal <= 180.f) return;

	const bool bSameGoal = FVector::DistSquared(GoalLoc, LastDirectMissionGoal) < 22500.f;
	if (bSameGoal && (Now - LastDirectMissionPathTime) < 1.5f)
	{
		UPathFollowingComponent* PFC = GetPathFollowingComponent();
		if (PFC && PFC->GetStatus() == EPathFollowingStatus::Moving)
		{
			return;
		}
	}

	if (!HasCombatThreat(0.12f))
	{
		SetFocalPoint(GoalLoc, EAIFocusPriority::Gameplay);
	}

	const float Accept = bLastLeaderFireSprint ? 80.f : 180.f;
	const EPathFollowingRequestResult::Type Result = MoveToLocation(GoalLoc, Accept, true, true, true, false, nullptr, true);
	LastDirectMissionGoal = GoalLoc;
	LastDirectMissionPathTime = Now;

	if (PathDebugDue())
	{
		UE_LOG(LogTemp, Warning, TEXT("[PATHDBG] Leader %s MoveTo %s dist=%.0f result=%d sprint=%d %s"),
			*GetNameSafe(GetPawn()), *GoalLoc.ToString(), DistToGoal, static_cast<int32>(Result),
			bLastLeaderFireSprint ? 1 : 0, *LastPathDebugReason);
	}
}

void ASoldierAIController::RestartStateTree()
{
	if (StateTreeComp)
	{
		if (!StateTreeComp->IsRunning())
		{
			StateTreeComp->StartLogic();
		}
		else
		{
			StateTreeComp->RestartLogic();
		}
	}
}

void ASoldierAIController::ResetCombatState()
{
	Memory.Empty();
	CachedEnemyZoneCenter = FVector::ZeroVector;
	CachedFallbackQuestZone.Reset();
	CachedActiveChain.Reset();
	CachedActiveChainTime = -1000.f;
	CachedLosResult = false;
	CachedLosTime = -1000.f;
	LastDirectMissionPathTime = -1000.f;
	FireHesitateUntil = -1000.f;
	bLastLeaderFireSprint = false;
	FireteamSharedThreat.Reset();
	// S6-A1: mirror OnUnPossess' fireteam reset — a pooled body wakes role-clean
	// (re-registration on its next wave spawn re-arms everything).
	bInEnemyFireteam = false;
	FireteamRole = EEnemyFireteamRole::Unassigned;
	FireteamMoveGoal = FVector::ZeroVector;
	CachedLosTarget.Reset();
	StopMovement();
	ClearFocus(EAIFocusPriority::Gameplay);
}

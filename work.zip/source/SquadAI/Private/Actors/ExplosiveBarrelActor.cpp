#include "Actors/ExplosiveBarrelActor.h"
#include "Components/StaticMeshComponent.h"
#include "Characters/SoldierCharacter.h"
#include "Performance/SoldierRegistrySubsystem.h"
#include "Performance/SquadAIAudioSubsystem.h"
#include "Actors/SquadAIAudioManager.h"
#include "HUD/QuestNativeHUD.h"
#include "Kismet/GameplayStatics.h"
#include "Tactical/SquadAIExplosiveDamage.h" // S18-BOOM
#include "Engine/World.h"
#include "TimerManager.h"
#include "Perception/AISense_Hearing.h" // F-G13: explosion hearing stimuli.
#include "UObject/ConstructorHelpers.h"

AExplosiveBarrelActor::AExplosiveBarrelActor()
{
	PrimaryActorTick.bCanEverTick = false;

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SetRootComponent(SceneRoot);

	BarrelMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("BarrelMesh"));
	BarrelMesh->SetupAttachment(SceneRoot);
	BarrelMesh->SetCollisionProfileName(TEXT("BlockAllDynamic"));
	BarrelMesh->SetGenerateOverlapEvents(true);

	static ConstructorHelpers::FObjectFinder<UStaticMesh> CylMesh(TEXT("/Engine/BasicShapes/Cylinder.Cylinder"));
	if (CylMesh.Succeeded())
	{
		BarrelMesh->SetStaticMesh(CylMesh.Object);
		// Red explosive fuel drum proportions (60cm diam x 90cm height)
		BarrelMesh->SetRelativeScale3D(FVector(0.6f, 0.6f, 0.9f));
	}
}

void AExplosiveBarrelActor::BeginPlay()
{
	Super::BeginPlay();
	ApplyCustomVisuals();
	OnTakeAnyDamage.AddDynamic(this, &AExplosiveBarrelActor::HandleTakeAnyDamage);
}

void AExplosiveBarrelActor::ApplyCustomVisuals()
{
	if (BarrelMesh)
	{
		if (CustomBarrelMesh)
		{
			BarrelMesh->SetStaticMesh(CustomBarrelMesh);
		}
		if (BarrelMaterialOverride)
		{
			BarrelMesh->SetMaterial(0, BarrelMaterialOverride);
		}
	}
}

void AExplosiveBarrelActor::HandleTakeAnyDamage(AActor* DamagedActor, float Damage, const UDamageType* DamageType,
	AController* InstigatedBy, AActor* DamageCauser)
{
	if (bHasExploded || bIsIgnited || Damage <= 0.0f) return;

	Health -= Damage;
	if (Health <= 0.0f)
	{
		bIsIgnited = true;
		// 0.35s ignition fuse delay
		if (GetWorld())
		{
			GetWorld()->GetTimerManager().SetTimer(FuseTimerHandle, this, &AExplosiveBarrelActor::Detonate, 0.35f, false);
		}
		else
		{
			Detonate();
		}
	}
}

void AExplosiveBarrelActor::Detonate()
{
	if (bHasExploded) return;
	bHasExploded = true;

	UWorld* World = GetWorld();
	if (!World) return;

	const FVector BlastLoc = GetActorLocation();

	// 1. Radial Blast Damage with Falloff
	TArray<AActor*> IgnoreActors;
	IgnoreActors.Add(this);
	// S18-BOOM: the player needs the dedicated damage path.
	if (APawn* BoomPlayer = UGameplayStatics::GetPlayerPawn(World, 0))
	{
		IgnoreActors.AddUnique(BoomPlayer);
	}

	UAISense_Hearing::ReportNoiseEvent(World, BlastLoc, 1.0f, nullptr, 5500.0, FName(TEXT("Explosion"))); // F-G13: blasts stimulate AI hearing (was: silent to AI).
	UGameplayStatics::ApplyRadialDamageWithFalloff(
		World,
		ExplosionDamage,
		ExplosionDamage * 0.25f,
		BlastLoc,
		ExplosionRadius * 0.4f,
		ExplosionRadius,
		1.0f,
		UDamageType::StaticClass(),
		IgnoreActors,
		this,
		nullptr,
		ECC_Visibility
	);

	// S18-BOOM: barrels hurt the player too.
	const float PlayerHit = USquadAIExplosiveDamageLibrary::ApplyExplosiveDamageToPlayer(
		this, BlastLoc, ExplosionDamage, ExplosionRadius * 0.4f, ExplosionRadius,
		0.25f, PlayerDamageMultiplier, this, true);
	if (PlayerHit > 0.f)
	{
		UE_LOG(LogTemp, Warning, TEXT("[S18-BOOM] Exploding barrel hit the player for %.1f."), PlayerHit);
	}

	// 2. Heavy Suppression & Camera Impact on Nearby Soldiers
	if (USoldierRegistrySubsystem* Reg = World->GetSubsystem<USoldierRegistrySubsystem>())
	{
		TArray<ASoldierCharacter*> Nearby = Reg->QueryRadius(BlastLoc, SuppressionRadius);
		for (ASoldierCharacter* S : Nearby)
		{
			if (S && S->IsAlive())
			{
				const float Dist = FVector::Dist(BlastLoc, S->GetActorLocation());
				const float SuppressAmount = FMath::Clamp(1.0f - (Dist / SuppressionRadius), 0.3f, 1.0f);
				// Push suppression to player HUD if player is nearby
				if (APlayerController* PC = Cast<APlayerController>(S->GetController()))
				{
					if (AQuestNativeHUD* HUD = Cast<AQuestNativeHUD>(PC->GetHUD()))
					{
						HUD->AddPlayerSuppression(SuppressAmount);
					}
				}
			}
		}
	}

	// 3. Audio Feedback
	USoundBase* Snd = ExplosionSound;
	if (!Snd)
	{
		if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
		{
			if (ASquadAIAudioManager* Mgr = AudioSys->GetActiveAudioManager())
			{
				Snd = Mgr->MediumExplosionCloseSound.Get();
			}
		}
	}

	if (Snd)
	{
		UGameplayStatics::PlaySoundAtLocation(World, Snd, BlastLoc, 1.25f);
	}

	OnBarrelExploded.Broadcast(this);
	Destroy();

	UE_LOG(LogTemp, Warning, TEXT("[ExplosiveBarrel] %s DETONATED with %.0f radius at %s"), *GetName(), ExplosionRadius, *BlastLoc.ToString());
}

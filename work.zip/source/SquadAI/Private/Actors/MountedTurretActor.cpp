#include "Actors/MountedTurretActor.h"
#include "HUD/QuestNativeHUD.h"
#include "Components/StaticMeshComponent.h"
#include "Components/SphereComponent.h"
#include "Components/HealthComponent.h"
#include "Characters/SoldierCharacter.h"
#include "Performance/SquadAIAssetCacheSubsystem.h"   // S26-TEX4: default textured materials
#include "Performance/SquadAIAudioSubsystem.h"
#include "Performance/SoldierRegistrySubsystem.h"
#include "Actors/SquadAIAudioManager.h"
#include "Kismet/GameplayStatics.h"
#include "GameFramework/Pawn.h"
#include "GameFramework/PlayerController.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Engine/World.h"
#include "DrawDebugHelpers.h"
#include "UObject/ConstructorHelpers.h"

AMountedTurretActor::AMountedTurretActor()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 0.033f; // ~30 Hz tick for responsive aiming

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SetRootComponent(SceneRoot);

	BaseMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("BaseMesh"));
	BaseMesh->SetupAttachment(SceneRoot);
	BaseMesh->SetCollisionProfileName(TEXT("BlockAllDynamic"));

	GunMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("GunMesh"));
	GunMesh->SetupAttachment(BaseMesh);
	GunMesh->SetRelativeLocation(FVector(0.f, 0.f, 75.f));
	GunMesh->SetCollisionProfileName(TEXT("NoCollision"));

	static ConstructorHelpers::FObjectFinder<UStaticMesh> CubeMesh(TEXT("/Engine/BasicShapes/Cube.Cube"));
	static ConstructorHelpers::FObjectFinder<UStaticMesh> CylinderMesh(TEXT("/Engine/BasicShapes/Cylinder.Cylinder"));

	if (CubeMesh.Succeeded())
	{
		BaseMesh->SetStaticMesh(CubeMesh.Object);
		BaseMesh->SetRelativeScale3D(FVector(1.2f, 1.2f, 0.7f)); // Sandbag mount base
	}

	if (CylinderMesh.Succeeded())
	{
		GunMesh->SetStaticMesh(CylinderMesh.Object);
		GunMesh->SetRelativeScale3D(FVector(0.15f, 0.15f, 1.2f));
		GunMesh->SetRelativeRotation(FRotator(90.f, 0.f, 0.f)); // Barrel points forward
	}

	// S26-TEX4: the missing anatomy - a pintle post under the gun, a gun shield,
	// and a belted ammo box beside the mount. Names only, no header change:
	// ApplyCustomVisuals finds them again by name.
	if (CylinderMesh.Succeeded())
	{
		UStaticMeshComponent* PintlePost = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("PintlePost"));
		PintlePost->SetupAttachment(BaseMesh);
		PintlePost->SetStaticMesh(CylinderMesh.Object);
		PintlePost->SetRelativeLocation(FVector(0.f, 0.f, 45.f));
		PintlePost->SetRelativeScale3D(FVector(0.09f, 0.09f, 0.45f));
		PintlePost->SetCollisionProfileName(TEXT("NoCollision"));
	}
	if (CubeMesh.Succeeded())
	{
		UStaticMeshComponent* GunShield = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("GunShield"));
		GunShield->SetupAttachment(BaseMesh);
		GunShield->SetStaticMesh(CubeMesh.Object);
		GunShield->SetRelativeLocation(FVector(26.f, 0.f, 80.f));
		GunShield->SetRelativeRotation(FRotator(-8.f, 0.f, 0.f));
		GunShield->SetRelativeScale3D(FVector(0.06f, 1.05f, 0.8f));
		GunShield->SetCollisionProfileName(TEXT("NoCollision"));

		UStaticMeshComponent* AmmoBeltBox = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("AmmoBeltBox"));
		AmmoBeltBox->SetupAttachment(SceneRoot);
		AmmoBeltBox->SetStaticMesh(CubeMesh.Object);
		AmmoBeltBox->SetRelativeLocation(FVector(38.f, 42.f, 12.f));
		AmmoBeltBox->SetRelativeRotation(FRotator(0.f, 18.f, 0.f));
		AmmoBeltBox->SetRelativeScale3D(FVector(0.42f, 0.3f, 0.24f));
		AmmoBeltBox->SetCollisionProfileName(TEXT("NoCollision"));
	}

	InteractionSphere = CreateDefaultSubobject<USphereComponent>(TEXT("InteractionSphere"));
	InteractionSphere->SetupAttachment(SceneRoot);
	InteractionSphere->SetSphereRadius(220.f);
	InteractionSphere->SetCollisionProfileName(TEXT("OverlapAllDynamic"));
	InteractionSphere->SetGenerateOverlapEvents(true);
}

void AMountedTurretActor::BeginPlay()
{
	Super::BeginPlay();

	ApplyCustomVisuals();
	InteractionSphere->OnComponentBeginOverlap.AddDynamic(this, &AMountedTurretActor::OnOverlapBegin);
	InteractionSphere->OnComponentEndOverlap.AddDynamic(this, &AMountedTurretActor::OnOverlapEnd);
}

void AMountedTurretActor::ApplyCustomVisuals()
{
	if (BaseMesh)
	{
		if (CustomBaseMesh) BaseMesh->SetStaticMesh(CustomBaseMesh);
		if (BaseMaterialOverride) BaseMesh->SetMaterial(0, BaseMaterialOverride);
	}
	if (GunMesh)
	{
		if (CustomGunMesh) GunMesh->SetStaticMesh(CustomGunMesh);
		if (GunMaterialOverride) GunMesh->SetMaterial(0, GunMaterialOverride);
	}
	// S26-TEX4: default dress for an uncustomized gun - the mount reads as
	// sandbags, the steel reads as oiled steel, the belt box as ammunition.
	// A designer's overrides above always win.
	if (USquadAIAssetCacheSubsystem* Cache = USquadAIAssetCacheSubsystem::Get(this))
	{
		auto PieceMat = [&Cache](const TCHAR* Key, const FLinearColor& Tint) -> UMaterialInterface*
		{
			UMaterialInterface* M = Cache->GetPropMaterial(Key, Tint);
			return M ? M : nullptr;
		};
		TInlineComponentArray<UStaticMeshComponent*> Meshes(this);
		for (UStaticMeshComponent* MC : Meshes)
		{
			if (!MC || !MC->GetStaticMesh()) { continue; }
			const FName N = MC->GetFName();
			UMaterialInterface* M = nullptr;
			if (N == TEXT("BaseMesh"))          { M = PieceMat(TEXT("Sandbags"), FLinearColor::White); }
			else if (N == TEXT("GunMesh"))      { M = PieceMat(TEXT("ScorchedMetal"), FLinearColor(0.3f, 0.3f, 0.3f, 1.f)); }
			else if (N == TEXT("PintlePost"))   { M = PieceMat(TEXT("ScorchedMetal"), FLinearColor(0.25f, 0.25f, 0.25f, 1.f)); }
			else if (N == TEXT("GunShield"))    { M = PieceMat(TEXT("OliveArmor"), FLinearColor(0.55f, 0.58f, 0.45f, 1.f)); }
			else if (N == TEXT("AmmoBeltBox"))  { M = PieceMat(TEXT("AmmoBox"), FLinearColor::White); }
			if (M) { MC->SetMaterial(0, M); }
		}
	}
}

void AMountedTurretActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	APawn* Player = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	if (!Player) return;

	APlayerController* PC = Cast<APlayerController>(Player->GetController());
	if (!PC) return;

	// Mount interaction check (dismount below is intentionally ungated — always allow exit).
	if (bPlayerInRange && !bIsMounted)
	{
		if (PC->WasInputKeyJustPressed(EKeys::E))
		{
			// E-arbitration: revive always wins; otherwise first claimant per press frame wins.
			AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this);
			const bool bYieldToRevive = HUD && HUD->IsReviveAvailable();
			const bool bClaimed = HUD ? HUD->TryConsumeWorldEPress() : true;
			if (!bYieldToRevive && bClaimed)
			{
				MountTurret(Player);
				return;
			}
		}
	}

	// Active mounted control
	if (bIsMounted)
	{
		// Validate mounted pawn is still alive and not downed
		if (!MountedPawn.IsValid() || MountedPawn->IsActorBeingDestroyed())
		{
			DismountTurret();
			return;
		}

		if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(MountedPawn.Get()))
		{
			if (!Soldier->IsAlive() || Soldier->IsDowned())
			{
				DismountTurret();
				return;
			}
		}

		// Dismount check
		if (PC->WasInputKeyJustPressed(EKeys::E) || PC->WasInputKeyJustPressed(EKeys::SpaceBar))
		{
			DismountTurret();
			return;
		}

		// Align gun mesh with player aim
		const FRotator ControlRot = PC->GetControlRotation();
		GunMesh->SetWorldRotation(ControlRot);

		// Fire input
		if (PC->IsInputKeyDown(EKeys::LeftMouseButton))
		{
			const float Now = GetWorld()->GetTimeSeconds();
			if (Now - LastFireTime >= (1.0f / FMath::Max(1.0f, FireRate)))
			{
				LastFireTime = Now;
				FireHeavyRound();
			}
		}
	}
}

void AMountedTurretActor::OnOverlapBegin(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
	UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	if (OtherActor == UGameplayStatics::GetPlayerPawn(GetWorld(), 0))
	{
		bPlayerInRange = true;
	}
}

void AMountedTurretActor::OnOverlapEnd(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
	UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
	if (OtherActor == UGameplayStatics::GetPlayerPawn(GetWorld(), 0))
	{
		bPlayerInRange = false;
		if (bIsMounted)
		{
			DismountTurret();
		}
	}
}

void AMountedTurretActor::MountTurret(APawn* PlayerPawn)
{
	if (!PlayerPawn) return;
	bIsMounted = true;
	MountedPawn = PlayerPawn;
	// B7-20: lock the gunner's feet while mounted (was: walking away silently
	// dismounted via overlap-end). Aim (control rotation) still drives the gun.
	if (ACharacter* Char = Cast<ACharacter>(PlayerPawn))
	{
		if (UCharacterMovementComponent* Move = Char->GetCharacterMovement())
		{
			CachedMountMovementMode = static_cast<uint8>(Move->MovementMode);
			Move->DisableMovement();
			Move->StopMovementImmediately();
		}
	}
	UE_LOG(LogTemp, Warning, TEXT("[MountedTurret] %s mounted by %s"), *GetName(), *GetNameSafe(PlayerPawn));
}

void AMountedTurretActor::DismountTurret()
{
	// B7-20: restore pre-mount locomotion.
	if (APawn* Pawn = MountedPawn.Get())
	{
		if (ACharacter* Char = Cast<ACharacter>(Pawn))
		{
			if (UCharacterMovementComponent* Move = Char->GetCharacterMovement())
			{
				Move->SetMovementMode(static_cast<EMovementMode>(CachedMountMovementMode));
			}
		}
	}
	bIsMounted = false;
	MountedPawn = nullptr;
	UE_LOG(LogTemp, Warning, TEXT("[MountedTurret] %s dismounted."), *GetName());
}

void AMountedTurretActor::FireHeavyRound()
{
	UWorld* World = GetWorld();
	if (!World) return;

	const FVector MuzzleLoc = GunMesh->GetComponentLocation() + GunMesh->GetForwardVector() * 80.f;
	const FVector AimDir = GunMesh->GetForwardVector();
	const FVector TraceEnd = MuzzleLoc + AimDir * MaxRange;

	FHitResult Hit;
	FCollisionQueryParams Params(SCENE_QUERY_STAT(MountedTurretFire), false);
	Params.AddIgnoredActor(this);
	if (MountedPawn.IsValid()) Params.AddIgnoredActor(MountedPawn.Get());

	if (World->LineTraceSingleByChannel(Hit, MuzzleLoc, TraceEnd, ECC_Visibility, Params))
	{
		if (AActor* HitActor = Hit.GetActor())
		{
				AActor* EffectiveCauser = MountedPawn.IsValid() ? Cast<AActor>(MountedPawn.Get()) : Cast<AActor>(this);
				AController* EffectiveController = MountedPawn.IsValid() ? MountedPawn->GetController() : nullptr;
				if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(HitActor))
				{
					const ASoldierCharacter* ShooterSoldier = MountedPawn.IsValid() ? Cast<ASoldierCharacter>(MountedPawn.Get()) : nullptr;
					const bool bSameTeamSoldiers = ShooterSoldier && Soldier &&
						((ShooterSoldier->IsEnemy() && Soldier->IsEnemy()) || (!ShooterSoldier->IsEnemy() && !Soldier->IsEnemy()));
					const bool bPlayerShooterHitsFriendly = MountedPawn.IsValid() && MountedPawn->IsPlayerControlled() && Soldier && !Soldier->IsEnemy();
					const bool bFriendlyShooterHitsPlayer = ShooterSoldier && !ShooterSoldier->IsEnemy() && Soldier && Soldier->IsPlayerControlled();
					if (bSameTeamSoldiers || bPlayerShooterHitsFriendly || bFriendlyShooterHitsPlayer)
					{
						return;
					}
					if (Soldier->HealthComp)
					{
						Soldier->HealthComp->ApplyDamage(DamagePerShot, EffectiveCauser);
						if (!Soldier->IsAlive())
						{
							Soldier->ApplyDeathImpulse(AimDir, 850.f, Hit.BoneName);
						}
					}
				}
				else
				{
					UGameplayStatics::ApplyDamage(HitActor, DamagePerShot, EffectiveController, EffectiveCauser, nullptr);
				}
			}
		}

	// Suppression on nearby enemies
	if (USoldierRegistrySubsystem* Reg = World->GetSubsystem<USoldierRegistrySubsystem>())
	{
		Reg->ApplySuppressionAlongPath(MuzzleLoc, TraceEnd, 350.f, 0.65f, MountedPawn.Get());
	}

	// Roaring Gunshot Sound & Camera Shake
	USoundBase* Snd = FireSound;
	if (!Snd)
	{
		if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
		{
			if (ASquadAIAudioManager* Mgr = AudioSys->GetActiveAudioManager())
			{
				Snd = Mgr->LargeExplosionCloseSound ? Mgr->LargeExplosionCloseSound.Get() : Mgr->DefaultGunshotCloseSound.Get();
			}
		}
	}

	if (Snd)
	{
		UGameplayStatics::PlaySoundAtLocation(World, Snd, MuzzleLoc, 1.25f, 0.95f);
	}

	if (FireCameraShake && MountedPawn.IsValid())
	{
		if (APlayerController* PC = Cast<APlayerController>(MountedPawn->GetController()))
		{
			PC->ClientStartCameraShake(FireCameraShake, 1.0f);
		}
	}
}

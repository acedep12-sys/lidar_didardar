#include "Actors/FirstAidKitActor.h"
#include "HUD/QuestNativeHUD.h"
#include "Components/StaticMeshComponent.h"
#include "Components/SphereComponent.h"
#include "Components/HealthComponent.h"
#include "Characters/SoldierCharacter.h"
#include "Performance/SquadAIAudioSubsystem.h"
#include "Actors/SquadAIAudioManager.h"
#include "GameFramework/SquadAIInventorySubsystem.h"
#include "Kismet/GameplayStatics.h"
#include "GameFramework/Pawn.h"
#include "GameFramework/PlayerController.h"
#include "Engine/World.h"
#include "TimerManager.h"
#include "UObject/ConstructorHelpers.h"
#include "UObject/UnrealType.h"

AFirstAidKitActor::AFirstAidKitActor()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 0.05f;

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SetRootComponent(SceneRoot);

	KitMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("KitMesh"));
	KitMesh->SetupAttachment(SceneRoot);
	KitMesh->SetCollisionProfileName(TEXT("BlockAllDynamic"));

	static ConstructorHelpers::FObjectFinder<UStaticMesh> BoxMesh(TEXT("/Engine/BasicShapes/Cube.Cube"));
	if (BoxMesh.Succeeded())
	{
		KitMesh->SetStaticMesh(BoxMesh.Object);
		// Compact tactical first aid pouch / box dimensions (35cm x 25cm x 15cm)
		KitMesh->SetRelativeScale3D(FVector(0.35f, 0.25f, 0.15f));
	}

	InteractionSphere = CreateDefaultSubobject<USphereComponent>(TEXT("InteractionSphere"));
	InteractionSphere->SetupAttachment(SceneRoot);
	InteractionSphere->SetSphereRadius(InteractionRadius);
	InteractionSphere->SetCollisionProfileName(TEXT("OverlapAllDynamic"));
	InteractionSphere->SetGenerateOverlapEvents(true);
}

void AFirstAidKitActor::BeginPlay()
{
	Super::BeginPlay();

	ApplyCustomVisuals();
	InteractionSphere->SetSphereRadius(InteractionRadius);
	InteractionSphere->OnComponentBeginOverlap.AddDynamic(this, &AFirstAidKitActor::OnOverlapBegin);
	InteractionSphere->OnComponentEndOverlap.AddDynamic(this, &AFirstAidKitActor::OnOverlapEnd);
}

void AFirstAidKitActor::ApplyCustomVisuals()
{
	if (KitMesh)
	{
		if (CustomKitMesh)
		{
			KitMesh->SetStaticMesh(CustomKitMesh);
		}
		if (KitMaterialOverride)
		{
			KitMesh->SetMaterial(0, KitMaterialOverride);
		}
	}
}

void AFirstAidKitActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (!bIsAvailable) return;

	// Player 'E' key interaction check while in proximity
	if (bPlayerInRange && CachedPlayerPawn.IsValid())
	{
		APawn* Player = CachedPlayerPawn.Get();
		if (APlayerController* PC = Cast<APlayerController>(Player->GetController()))
		{
			if (PC->WasInputKeyJustPressed(EKeys::E))
			{
				// E-arbitration: revive always wins; otherwise first claimant per press frame wins.
				AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this);
				const bool bYieldToRevive = HUD && HUD->IsReviveAvailable();
				const bool bClaimed = HUD ? HUD->TryConsumeWorldEPress() : true;
				if (!bYieldToRevive && bClaimed)
				{
					ConsumeKit(Player);
				}
			}
		}
	}
}

void AFirstAidKitActor::OnOverlapBegin(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
	UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	if (!OtherActor || !bIsAvailable) return;

	APawn* Player = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	if (OtherActor == Player)
	{
		bPlayerInRange = true;
		CachedPlayerPawn = Player;

		if (bAutoPickupOnOverlap)
		{
			ConsumeKit(Player);
		}
		else
		{
			UE_LOG(LogTemp, Warning, TEXT("[FirstAidKit] Player near First Aid Kit at %s"), *GetName());
		}
	}
}

void AFirstAidKitActor::OnOverlapEnd(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
	UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
	APawn* Player = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	if (OtherActor == Player)
	{
		bPlayerInRange = false;
		CachedPlayerPawn = nullptr;
	}
}

bool AFirstAidKitActor::ConsumeKit(APawn* PlayerPawn)
{
	if (!PlayerPawn || !bIsAvailable) return false;

	bool bHealed = false;
	// F-G8: a ground kit must not be consumed when it would do nothing (full HP + full stock).
	bool bNeededHeal = false;
	if (ASoldierCharacter* PreSoldier = Cast<ASoldierCharacter>(PlayerPawn))
	{
		bNeededHeal = PreSoldier->IsDowned() || (PreSoldier->HealthComp && PreSoldier->HealthComp->CurrentHealth < PreSoldier->HealthComp->MaxHealth);
	}
	USquadAIInventorySubsystem* InvPre = USquadAIInventorySubsystem::Get(this);
	const bool bWouldBank = (InvPre && InvPre->FirstAidKits < 5);

	// 1. SquadAI Health Component
	if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(PlayerPawn))
	{
		if (Soldier->IsDowned())
		{
			Soldier->CompleteRevive(this);
			bHealed = true;
		}
		else if (Soldier->HealthComp)
		{
			if (HealAmount <= 0.0f)
			{
				Soldier->HealthComp->CurrentHealth = Soldier->HealthComp->MaxHealth;
			}
			else
			{
				Soldier->HealthComp->Heal(HealAmount);
			}
			bHealed = true;
		}
	}

	// 2. TPWCS Pack Health Component
	TArray<UActorComponent*> Comps;
	PlayerPawn->GetComponents(Comps);
	for (UActorComponent* C : Comps)
	{
		if (!C || !C->GetName().Contains(TEXT("BPC_Health"))) continue;

		double MaxHP = 100.0;
		for (const FName& MaxPropName : { FName(TEXT("maxHealth")), FName(TEXT("MaxHealth")), FName(TEXT("Max Health")) })
		{
			if (FDoubleProperty* DP = FindFProperty<FDoubleProperty>(C->GetClass(), MaxPropName))
			{
				MaxHP = DP->GetPropertyValue_InContainer(C);
				break;
			}
			if (FFloatProperty* FP = FindFProperty<FFloatProperty>(C->GetClass(), MaxPropName))
			{
				MaxHP = static_cast<double>(FP->GetPropertyValue_InContainer(C));
				break;
			}
		}

		if (MaxHP <= 0.0) MaxHP = 100.0;

		double TargetHP = MaxHP;
		bNeededHeal = true; // F-G8: full-restore kit — pack HP unread here, assume useful (preserves old behavior).
		if (HealAmount > 0.0f)
		{
			double CurHP = 0.0;
			for (const FName& CurPropName : { FName(TEXT("currentHealth")), FName(TEXT("CurrentHealth")), FName(TEXT("Health")) })
			{
				if (FDoubleProperty* DP = FindFProperty<FDoubleProperty>(C->GetClass(), CurPropName))
				{
					CurHP = DP->GetPropertyValue_InContainer(C);
					break;
				}
				if (FFloatProperty* FP = FindFProperty<FFloatProperty>(C->GetClass(), CurPropName))
				{
					CurHP = static_cast<double>(FP->GetPropertyValue_InContainer(C));
					break;
				}
			}
			TargetHP = FMath::Min(CurHP + static_cast<double>(HealAmount), MaxHP);
		if (CurHP < MaxHP) bNeededHeal = true; // F-G8: pack was actually hurt.
		}

		for (const FName& CurPropName : { FName(TEXT("currentHealth")), FName(TEXT("CurrentHealth")), FName(TEXT("Health")) })
		{
			if (FDoubleProperty* DP = FindFProperty<FDoubleProperty>(C->GetClass(), CurPropName))
			{
				DP->SetPropertyValue_InContainer(C, TargetHP);
				bHealed = true;
				break;
			}
			if (FFloatProperty* FP = FindFProperty<FFloatProperty>(C->GetClass(), CurPropName))
			{
				FP->SetPropertyValue_InContainer(C, static_cast<float>(TargetHP));
				bHealed = true;
				break;
			}
		}
	}

	if (!bNeededHeal && !bWouldBank) return false; // F-G8: nothing gained — leave the ground kit for later.

	// 3. Audio feedback
	USoundBase* Snd = HealSound;
	if (!Snd)
	{
		if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
		{
			if (ASquadAIAudioManager* Mgr = AudioSys->GetActiveAudioManager())
			{
				Snd = Mgr->TacticalRadioClick.Get();
			}
		}
	}

	if (Snd && GetWorld())
	{
		UGameplayStatics::PlaySoundAtLocation(GetWorld(), Snd, GetActorLocation(), 1.0f);
	}

	if (bWouldBank)
	{
		if (USquadAIInventorySubsystem* Inv = USquadAIInventorySubsystem::Get(this))
		{
			Inv->FirstAidKits = FMath::Min(Inv->FirstAidKits + 1, 5);
		}
	}

	OnFirstAidCollected.Broadcast(PlayerPawn);
	bPlayerInRange = false;

	if (bRespawnable)
	{
		bIsAvailable = false;
		if (KitMesh) KitMesh->SetVisibility(false);
		if (InteractionSphere) InteractionSphere->SetCollisionEnabled(ECollisionEnabled::NoCollision);

		if (GetWorld())
		{
			GetWorld()->GetTimerManager().SetTimer(RespawnTimerHandle, this, &AFirstAidKitActor::RespawnKit, RespawnDelaySeconds, false);
		}
	}
	else
	{
		bIsAvailable = false;
		Destroy();
	}

	UE_LOG(LogTemp, Warning, TEXT("[FirstAidKit] %s used by player %s (Healed to max)!"), *GetName(), *GetNameSafe(PlayerPawn));
	return bHealed;
}

void AFirstAidKitActor::RespawnKit()
{
	bIsAvailable = true;
	if (KitMesh) KitMesh->SetVisibility(true);
	if (InteractionSphere) InteractionSphere->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
	UE_LOG(LogTemp, Log, TEXT("[FirstAidKit] %s respawned and ready for pickup"), *GetName());
}

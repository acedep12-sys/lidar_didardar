#include "Actors/MedicalStationActor.h"
#include "HUD/QuestNativeHUD.h"
#include "Components/StaticMeshComponent.h"
#include "Components/SphereComponent.h"
#include "Components/HealthComponent.h"
#include "Characters/SoldierCharacter.h"
#include "Performance/SquadAIAudioSubsystem.h"
#include "Actors/SquadAIAudioManager.h"
#include "Kismet/GameplayStatics.h"
#include "GameFramework/Pawn.h"
#include "GameFramework/PlayerController.h"
#include "Engine/World.h"
#include "UObject/ConstructorHelpers.h"
#include "UObject/UnrealType.h"

AMedicalStationActor::AMedicalStationActor()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 0.05f;

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SetRootComponent(SceneRoot);

	StationMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("StationMesh"));
	StationMesh->SetupAttachment(SceneRoot);
	StationMesh->SetCollisionProfileName(TEXT("BlockAllDynamic"));

	static ConstructorHelpers::FObjectFinder<UStaticMesh> BoxMesh(TEXT("/Engine/BasicShapes/Cube.Cube"));
	if (BoxMesh.Succeeded())
	{
		StationMesh->SetStaticMesh(BoxMesh.Object);
		StationMesh->SetRelativeScale3D(FVector(0.8f, 0.8f, 1.1f)); // Medical cabinet dimensions
	}

	InteractionSphere = CreateDefaultSubobject<USphereComponent>(TEXT("InteractionSphere"));
	InteractionSphere->SetupAttachment(SceneRoot);
	InteractionSphere->SetSphereRadius(InteractionRadius);
	InteractionSphere->SetCollisionProfileName(TEXT("OverlapAllDynamic"));
	InteractionSphere->SetGenerateOverlapEvents(true);
}

void AMedicalStationActor::BeginPlay()
{
	Super::BeginPlay();

	InteractionSphere->SetSphereRadius(InteractionRadius);
	InteractionSphere->OnComponentBeginOverlap.AddDynamic(this, &AMedicalStationActor::OnOverlapBegin);
	InteractionSphere->OnComponentEndOverlap.AddDynamic(this, &AMedicalStationActor::OnOverlapEnd);
}

void AMedicalStationActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (CooldownTimer > 0.0f)
	{
		CooldownTimer -= DeltaTime;
	}

	// Player 'E' key interaction check while in proximity
	if (bPlayerInRange && CachedPlayerPawn.IsValid() && IsReady())
	{
		APawn* Player = CachedPlayerPawn.Get();
		if (APlayerController* PC = Cast<APlayerController>(Player->GetController()))
		{
			if (PC->WasInputKeyJustPressed(EKeys::E))
			{
				// E-arbitration: revive always wins; otherwise first claimant per press frame wins.
				AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this);
				const bool bYieldToRevive = HUD && HUD->IsReviveAvailable();
				const bool bClaimed = HUD ? HUD->TryConsumeWorldEPress() : true;
				if (!bYieldToRevive && bClaimed)
				{
					HealPlayer(Player);
				}
			}
		}
	}
}

void AMedicalStationActor::OnOverlapBegin(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
	UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	if (!OtherActor) return;

	APawn* Player = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	if (OtherActor == Player)
	{
		bPlayerInRange = true;
		CachedPlayerPawn = Player;
		UE_LOG(LogTemp, Warning, TEXT("[MedicalStation] Player entered first aid range at %s"), *GetName());
	}
}

void AMedicalStationActor::OnOverlapEnd(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
	UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
	APawn* Player = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	if (OtherActor == Player)
	{
		bPlayerInRange = false;
		CachedPlayerPawn = nullptr;
	}
}

bool AMedicalStationActor::HealPlayer(APawn* PlayerPawn)
{
	if (!PlayerPawn || !IsReady()) return false;

	bool bHealed = false;

	// 1. SquadAI Health Component
	if (ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(PlayerPawn))
	{
		if (Soldier->HealthComp)
		{
			Soldier->HealthComp->CurrentHealth = Soldier->HealthComp->MaxHealth;
			bHealed = true;
		}
	}

	// 2. TPWCS Pack Health Component
	TArray<UActorComponent*> Comps;
	PlayerPawn->GetComponents(Comps);
	for (UActorComponent* C : Comps)
	{
		if (!C || !C->GetName().Contains(TEXT("BPC_Health"))) continue;

		double MaxHP = 100.0;
		for (const FName& MaxPropName : { FName(TEXT("maxHealth")), FName(TEXT("MaxHealth")), FName(TEXT("Max Health")) })
		{
			if (FDoubleProperty* DP = FindFProperty<FDoubleProperty>(C->GetClass(), MaxPropName))
			{
				MaxHP = DP->GetPropertyValue_InContainer(C);
				break;
			}
			if (FFloatProperty* FP = FindFProperty<FFloatProperty>(C->GetClass(), MaxPropName))
			{
				MaxHP = static_cast<double>(FP->GetPropertyValue_InContainer(C));
				break;
			}
		}

		if (MaxHP <= 0.0) MaxHP = 100.0;

		for (const FName& CurPropName : { FName(TEXT("currentHealth")), FName(TEXT("CurrentHealth")), FName(TEXT("Health")) })
		{
			if (FDoubleProperty* DP = FindFProperty<FDoubleProperty>(C->GetClass(), CurPropName))
			{
				DP->SetPropertyValue_InContainer(C, MaxHP);
				bHealed = true;
				break;
			}
			if (FFloatProperty* FP = FindFProperty<FFloatProperty>(C->GetClass(), CurPropName))
			{
				FP->SetPropertyValue_InContainer(C, static_cast<float>(MaxHP));
				bHealed = true;
				break;
			}
		}
	}

	// 3. Audio feedback
	USoundBase* Snd = HealSound;
	if (!Snd)
	{
		if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
		{
			if (ASquadAIAudioManager* Mgr = AudioSys->GetActiveAudioManager())
			{
				Snd = Mgr->TacticalRadioClick.Get();
			}
		}
	}

	if (Snd && GetWorld())
	{
		UGameplayStatics::PlaySoundAtLocation(GetWorld(), Snd, GetActorLocation(), 1.0f);
	}

	CooldownTimer = CooldownSeconds;
	OnHealthRestored.Broadcast(PlayerPawn);

	UE_LOG(LogTemp, Warning, TEXT("[MedicalStation] %s healed player %s back to full health!"), *GetName(), *GetNameSafe(PlayerPawn));
	return bHealed;
}

#include "Actors/CombatEncounterVolume.h"
#include "Components/BoxComponent.h"
#include "Characters/SoldierCharacter.h"
#include "Characters/EnemySoldier.h"
#include "Characters/EnemyCommander.h"           // S19-ELITE
#include "Characters/EnemyCommanderAssistant.h"  // S19-ELITE
#include "Components/HealthComponent.h"          // S19-ELITE: OnDeath on the commander
#include "HUD/QuestNativeHUD.h"                  // S19-ELITE: alert banner
#include "Actors/FirstAidKitActor.h"
#include "Actors/AmmoCrateActor.h"
#include "Actors/MountedTurretActor.h"
#include "Performance/SquadAIAudioSubsystem.h"
#include "Actors/SquadAIAudioManager.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/World.h"
#include "Engine/Engine.h"

ACombatEncounterVolume::ACombatEncounterVolume()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 0.25f;

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SetRootComponent(SceneRoot);

	TriggerBounds = CreateDefaultSubobject<UBoxComponent>(TEXT("TriggerBounds"));
	TriggerBounds->SetupAttachment(SceneRoot);
	TriggerBounds->SetBoxExtent(FVector(1500.f, 1500.f, 400.f));
	TriggerBounds->SetCollisionProfileName(TEXT("OverlapAllDynamic"));
	TriggerBounds->SetGenerateOverlapEvents(true);
}

void ACombatEncounterVolume::BeginPlay()
{
	Super::BeginPlay();

	TriggerBounds->OnComponentBeginOverlap.AddDynamic(this, &ACombatEncounterVolume::OnTriggerOverlapBegin);

	if (bAutoScatterSupplyKits)
	{
		SetupFieldLogistics();
	}
}

void ACombatEncounterVolume::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (!bIsActive || bIsCompleted) return;

	// Check alive enemies in current wave
	const int32 AliveCount = GetAliveEnemiesCount();

	if (bPendingNextWave)
	{
		NextWaveTimer -= DeltaTime;
		if (NextWaveTimer <= 0.0f)
		{
			bPendingNextWave = false;
			CurrentWaveIndex++;
			if (CurrentWaveIndex < TotalWaves)
			{
				SpawnCurrentWave();
			}
			else
			{
				CompleteEncounter();
			}
		}
		return;
	}

	if (AliveCount == 0 && ActiveEnemies.Num() > 0)
	{
		OnEncounterWaveCleared.Broadcast(CurrentWaveIndex);
		UE_LOG(LogTemp, Log, TEXT("[CombatEncounter] %s: Wave %d cleared!"), *GetName(), CurrentWaveIndex + 1);

		if (CurrentWaveIndex + 1 < TotalWaves)
		{
			bPendingNextWave = true;
			NextWaveTimer = WaveIntervalSeconds;
		}
		else
		{
			CompleteEncounter();
		}
	}
}

void ACombatEncounterVolume::OnTriggerOverlapBegin(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
	UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	if (!bTriggerOnPlayerEntry || bIsActive || bIsCompleted || !OtherActor) return;

	APawn* Player = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	if (OtherActor == Player)
	{
		StartEncounter();
	}
}

void ACombatEncounterVolume::StartEncounter()
{
	if (bIsActive || bIsCompleted || !GetWorld()) return;

	bIsActive = true;
	CurrentWaveIndex = 0;
	bPendingNextWave = false;

	UE_LOG(LogTemp, Warning, TEXT("[CombatEncounter] Starting encounter: %s with %d waves"), *EncounterName.ToString(), TotalWaves);
	OnEncounterStarted.Broadcast(this);

	SpawnCurrentWave();
}

void ACombatEncounterVolume::SpawnCurrentWave()
{
	UWorld* World = GetWorld();
	if (!World) return;

	ActiveEnemies.Empty();

	const FVector Origin = GetActorLocation();
	const FVector Extents = TriggerBounds->GetUnscaledBoxExtent();

	for (int32 i = 0; i < EnemiesPerWave; ++i)
	{
		const float Angle = (2.0f * PI * i) / FMath::Max(1, EnemiesPerWave);
		const float Dist = FMath::FRandRange(300.f, FMath::Min(Extents.X, Extents.Y) * 0.75f);
		FVector SpawnLoc = Origin + FVector(FMath::Cos(Angle) * Dist, FMath::Sin(Angle) * Dist, 20.f);

		// Trace to ground
		FHitResult Hit;
		FCollisionQueryParams Params;
		Params.AddIgnoredActor(this);
		if (World->LineTraceSingleByChannel(Hit, SpawnLoc + FVector(0.f, 0.f, 300.f), SpawnLoc - FVector(0.f, 0.f, 1000.f), ECC_Visibility, Params))
		{
			SpawnLoc = Hit.ImpactPoint + FVector(0.f, 0.f, 50.f);
		}

		FActorSpawnParameters SpawnParams;
		// S5-14c: WP/lifetime ownership for all spawned children.
		SpawnParams.Owner = this;
		SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;

		// S19-ELITE: honour EnemyClass. This used to hardcode AEnemySoldier, so an
		// encounter could never use the pack's Blueprint enemies - or anything else.
		const TSubclassOf<AEnemySoldier> ClassToSpawn = EnemyClass ? EnemyClass : TSubclassOf<AEnemySoldier>(AEnemySoldier::StaticClass());
		AEnemySoldier* Enemy = World->SpawnActor<AEnemySoldier>(ClassToSpawn, SpawnLoc, FRotator(0.f, FMath::FRandRange(0.f, 360.f), 0.f), SpawnParams);
		if (Enemy)
		{
			ActiveEnemies.Add(Enemy);
		}
	}

	// S19-ELITE: the commander, with his escort. CommanderHunt always fields one; the
	// other types get one when bSpawnCommander is ticked.
	if (ShouldSpawnCommander() && !SpawnedCommander)
	{
		SpawnCommanderAndEscorts(Origin);
	}

	UE_LOG(LogTemp, Log, TEXT("[CombatEncounter] %s spawned wave %d (%d enemies%s)"), *GetName(), CurrentWaveIndex + 1,
		ActiveEnemies.Num(), SpawnedCommander ? TEXT(" + commander") : TEXT(""));
}

// =========================================================================
//  S19-ELITE
// =========================================================================
bool ACombatEncounterVolume::ShouldSpawnCommander() const
{
	// The "Eliminate Commander" type has no other purpose: it always fields one.
	return bSpawnCommander || EncounterType == ECombatEncounterType::CommanderHunt;
}

void ACombatEncounterVolume::SpawnCommanderAndEscorts(const FVector& Origin)
{
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}

	const TSubclassOf<AEnemyCommander> CmdClass = CommanderClass
		? CommanderClass : TSubclassOf<AEnemyCommander>(AEnemyCommander::StaticClass());
	const TSubclassOf<AEnemyCommanderAssistant> AsstClass = AssistantClass
		? AssistantClass : TSubclassOf<AEnemyCommanderAssistant>(AEnemyCommanderAssistant::StaticClass());

	FActorSpawnParameters SpawnParams;
	SpawnParams.Owner = this;   // S5-14c: WP/lifetime ownership
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;

	FVector CmdLoc = Origin + FVector(0.f, 0.f, 80.f);
	FHitResult Hit;
	FCollisionQueryParams Params;
	Params.AddIgnoredActor(this);
	if (World->LineTraceSingleByChannel(Hit, CmdLoc + FVector(0.f, 0.f, 300.f), CmdLoc - FVector(0.f, 0.f, 1000.f), ECC_Visibility, Params))
	{
		CmdLoc = Hit.ImpactPoint + FVector(0.f, 0.f, 60.f);
	}

	AEnemyCommander* Commander = World->SpawnActor<AEnemyCommander>(CmdClass, CmdLoc, FRotator(0.f, FMath::FRandRange(0.f, 360.f), 0.f), SpawnParams);
	SpawnedCommander = Commander;
	if (!Commander)
	{
		UE_LOG(LogTemp, Error, TEXT("[CombatEncounter] %s: commander spawn failed (class %s)"), *GetName(), *GetNameSafe(CmdClass.Get()));
		return;
	}

	// He is part of the encounter like anybody else... 
	ActiveEnemies.Add(Commander);

	// ...and the decapitation objective listens to him specifically.
	if (Commander->HealthComp)
	{
		Commander->HealthComp->OnDeath.AddDynamic(this, &ACombatEncounterVolume::OnCommanderDied);
	}

	int32 Escorts = 0;
	for (int32 i = 0; i < AssistantsPerCommander; ++i)
	{
		const float Ang = (2.f * PI * i) / FMath::Max(1, AssistantsPerCommander);
		const FVector Offset(FMath::Cos(Ang) * 300.f, FMath::Sin(Ang) * 300.f, 0.f);
		if (AEnemyCommanderAssistant* Assistant = World->SpawnActor<AEnemyCommanderAssistant>(AsstClass, CmdLoc + Offset, FRotator(0.f, FMath::FRandRange(0.f, 360.f), 0.f), SpawnParams))
		{
			Assistant->SetCommander(Commander);
			ActiveEnemies.Add(Assistant);
			++Escorts;
		}
	}

	UE_LOG(LogTemp, Log, TEXT("[CombatEncounter] %s: commander %s + %d/%d assistant(s) - objective %s"),
		*GetName(), *Commander->GetName(), Escorts, AssistantsPerCommander,
		(EncounterType == ECombatEncounterType::CommanderHunt) ? TEXT("Eliminate Commander") : TEXT("support"));

	if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this))
	{
		HUD->ShowAlertBanner(
			AQuestNativeHUD::LocalizeHUDText(this, TEXT("HUD"), TEXT("CommanderOnField"),
				TEXT("فرمانده در میدان است — او را از پای درآورید"),
				TEXT("COMMANDER ON THE FIELD")),
			FLinearColor(0.95f, 0.35f, 0.12f), 5.f);
	}
}

void ACombatEncounterVolume::OnCommanderDied(AActor* OwnerActor)
{
	if (!bCompleteOnCommanderDeath)
	{
		return;
	}
	if (EncounterType != ECombatEncounterType::CommanderHunt && !bSpawnCommander)
	{
		return;   // a support commander dying does not end a Defend/Ambush encounter
	}

	UE_LOG(LogTemp, Warning, TEXT("[CombatEncounter] %s: COMMANDER ELIMINATED - objective complete"), *GetName());

	if (AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this))
	{
		HUD->ShowAlertBanner(
			AQuestNativeHUD::LocalizeHUDText(this, TEXT("HUD"), TEXT("CommanderKilled"),
				TEXT("فرمانده از پای درآمد — ماموریت انجام شد"),
				TEXT("COMMANDER ELIMINATED - OBJECTIVE COMPLETE")),
			FLinearColor(0.30f, 0.85f, 0.35f), 5.f);
	}

	// Decapitation: the objective is the man, not the mopping-up.
	if (!bIsCompleted)
	{
		OnEncounterWaveCleared.Broadcast(CurrentWaveIndex);
		CompleteEncounter();
	}
}

void ACombatEncounterVolume::SetupFieldLogistics()
{
	UWorld* World = GetWorld();
	if (!World) return;

	const FVector Origin = GetActorLocation();
	FActorSpawnParameters SpawnParams;
	// S5-14c: WP/lifetime ownership for all spawned children.
	SpawnParams.Owner = this;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;

	// Spawn First Aid Kit
	FVector MedLoc = Origin + FVector(FMath::FRandRange(-200.f, 200.f), FMath::FRandRange(-200.f, 200.f), 10.f);
	FHitResult Hit;
	FCollisionQueryParams Params;
	Params.AddIgnoredActor(this);
	if (World->LineTraceSingleByChannel(Hit, MedLoc + FVector(0.f, 0.f, 300.f), MedLoc - FVector(0.f, 0.f, 1000.f), ECC_Visibility, Params))
	{
		MedLoc = Hit.ImpactPoint + FVector(0.f, 0.f, 10.f);
	}
	AFirstAidKitActor* Kit = World->SpawnActor<AFirstAidKitActor>(AFirstAidKitActor::StaticClass(), MedLoc, FRotator::ZeroRotator, SpawnParams);
	if (Kit) SpawnedSupplies.Add(Kit);

	// Spawn Ammo Crate
	FVector AmmoLoc = Origin + FVector(FMath::FRandRange(-350.f, 350.f), FMath::FRandRange(-350.f, 350.f), 10.f);
	if (World->LineTraceSingleByChannel(Hit, AmmoLoc + FVector(0.f, 0.f, 300.f), AmmoLoc - FVector(0.f, 0.f, 1000.f), ECC_Visibility, Params))
	{
		AmmoLoc = Hit.ImpactPoint + FVector(0.f, 0.f, 10.f);
	}
	AAmmoCrateActor* Ammo = World->SpawnActor<AAmmoCrateActor>(AAmmoCrateActor::StaticClass(), AmmoLoc, FRotator::ZeroRotator, SpawnParams);
	if (Ammo) SpawnedSupplies.Add(Ammo);

	// Spawn Mounted Turret if requested
	if (bSpawnMountedTurret)
	{
		FVector TurretLoc = Origin + FVector(0.f, 400.f, 10.f);
		if (World->LineTraceSingleByChannel(Hit, TurretLoc + FVector(0.f, 0.f, 300.f), TurretLoc - FVector(0.f, 0.f, 1000.f), ECC_Visibility, Params))
		{
			TurretLoc = Hit.ImpactPoint + FVector(0.f, 0.f, 10.f);
		}
		AMountedTurretActor* Turret = World->SpawnActor<AMountedTurretActor>(AMountedTurretActor::StaticClass(), TurretLoc, FRotator::ZeroRotator, SpawnParams);
		if (Turret) SpawnedSupplies.Add(Turret);
	}
}

int32 ACombatEncounterVolume::GetAliveEnemiesCount() const
{
	int32 Count = 0;
	for (const TWeakObjectPtr<ASoldierCharacter>& WeakEnemy : ActiveEnemies)
	{
		if (ASoldierCharacter* Enemy = WeakEnemy.Get())
		{
			if (Enemy->IsAlive())
			{
				Count++;
			}
		}
	}
	return Count;
}

void ACombatEncounterVolume::CompleteEncounter()
{
	bIsActive = false;
	bIsCompleted = true;

	UE_LOG(LogTemp, Warning, TEXT("[CombatEncounter] %s ALL WAVES CLEARED! Encounter Completed!"), *EncounterName.ToString());
	OnEncounterCompleted.Broadcast(this);

	if (bCinematicSlowMoOnClear && GetWorld())
	{
		// 0.35x cinematic slow-motion effect for 1.25 seconds
		UGameplayStatics::SetGlobalTimeDilation(GetWorld(), 0.35f);
		FTimerHandle TimerHandle;
		TWeakObjectPtr<UWorld> WeakWorld(GetWorld());
		GetWorld()->GetTimerManager().SetTimer(TimerHandle, [WeakWorld]()
		{
			if (WeakWorld.IsValid())
			{
				UGameplayStatics::SetGlobalTimeDilation(WeakWorld.Get(), 1.0f);
			}
		}, 0.5f, false); // 0.5 unscaled seconds = ~1.42 real seconds
	}
}

void ACombatEncounterVolume::ResetEncounter()
{
	bIsActive = false;
	bIsCompleted = false;
	CurrentWaveIndex = 0;
	bPendingNextWave = false;
	ActiveEnemies.Empty();
}

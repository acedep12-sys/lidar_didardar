#include "Actors/SquadAIMainMenuSetupActor.h"
#include "HUD/SquadAIMainMenuHUD.h"
#include "Utilities/SquadAIAssetHelper.h"
#include "BlueprintLibraries/SquadAIAutoSetupEditorLibrary.h"   // S26-VIDEO: shared video installer
#include "Localization/SquadAILocalizationSubsystem.h"
#include "SaveSystem/SquadAISaveLoadSubsystem.h"
#include "Camera/CameraComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/World.h"
#include "GameFramework/PlayerController.h"
#include "GameFramework/GameModeBase.h"
#include "GameFramework/SquadAIMainMenuGameMode.h"
#include "Performance/SquadAILoadingScreenSubsystem.h"
#include "Quest/AtmosphericDustScatterer.h"
#include "Engine/Texture2D.h"
#include "Sound/SoundBase.h"
#include "Components/AudioComponent.h" // S17-MVOL
#include "NiagaraSystem.h"

// S19-PIEASSETINIT: keep LoadObject/asset resolution out of actor construction/CDO.
ASquadAIMainMenuSetupActor::ASquadAIMainMenuSetupActor()
{
	PrimaryActorTick.bCanEverTick = true;

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	RootComponent = SceneRoot;

	MenuCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("MenuCamera"));
	MenuCamera->SetupAttachment(RootComponent);
	MenuCamera->SetRelativeLocation(FVector(-OrbitRadius, 0.0f, CameraHeight));
	MenuCamera->SetRelativeRotation(FRotator(-10.0f, 0.0f, 0.0f));

	ApplyPersianFarsiPreset();
}

// S19-PIEASSETINIT: resolve texture/Niagara soft paths after engine registries are ready.
void ASquadAIMainMenuSetupActor::BeginPlay()
{
	Super::BeginPlay();

	AutoResolveAllTextureSlots();

	// P1-L2: honor the saved language (ctor default is Persian) + subscribe for live re-skin.
	if (USquadAISaveLoadSubsystem* SaveSys = USquadAISaveLoadSubsystem::Get(this))
	{
		if (SaveSys->LoadSettings().LanguageCode.Equals(TEXT("en"), ESearchCase::IgnoreCase))
		{
			ApplyEnglishMilitaryPreset();
		}
	}
	if (USquadAILocalizationSubsystem* Loc = USquadAILocalizationSubsystem::Get(this))
	{
		LanguageChangedHandle = Loc->OnLanguageChangedNative.AddUObject(this, &ASquadAIMainMenuSetupActor::OnLanguageChanged);
	}

	if (APlayerController* PC = UGameplayStatics::GetPlayerController(GetWorld(), 0))
	{
		if (BackgroundType == EMenuBackgroundType::Cinematic3DCameraOrbit)
		{
			PC->SetViewTargetWithBlend(this, 0.0f);
		}

		ASquadAIMainMenuHUD* HUD = Cast<ASquadAIMainMenuHUD>(PC->GetHUD());
		if (!HUD)
		{
			PC->ClientSetHUD(ASquadAIMainMenuHUD::StaticClass());
			HUD = Cast<ASquadAIMainMenuHUD>(PC->GetHUD());
		}

		if (HUD)
		{
			PushSettingsToHUD(HUD);
		}
	}

	if (MenuThemeMusic)
	{
		// S17-MVOL: spawn (not fire-and-forget) so the Settings screen can adjust
		// the volume live; initial volume honors the saved MusicVolume setting.
		float MusicVol = 0.8f;
		if (USquadAISaveLoadSubsystem* SaveSys = USquadAISaveLoadSubsystem::Get(this))
		{
			MusicVol = FMath::Clamp(SaveSys->LoadSettings().MusicVolume, 0.f, 1.f);
		}
		MenuMusicAudioComp = UGameplayStatics::SpawnSound2D(this, MenuThemeMusic, MusicVol);
	}
	if (DesertWindAmbience)
	{
		UGameplayStatics::PlaySound2D(this, DesertWindAmbience);
	}

	if (bSpawnAtmosphericDust && GetWorld())
	{
		FActorSpawnParameters SpawnParams;
		SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
		GetWorld()->SpawnActor<AAtmosphericDustScatterer>(GetActorLocation(), GetActorRotation(), SpawnParams);
	}
}

void ASquadAIMainMenuSetupActor::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (USquadAILocalizationSubsystem* Loc = USquadAILocalizationSubsystem::Get(this))
	{
		Loc->OnLanguageChangedNative.Remove(LanguageChangedHandle);
	}
	Super::EndPlay(EndPlayReason);
}

void ASquadAIMainMenuSetupActor::OnLanguageChanged(const FString& NewLang)
{
	if (NewLang.Equals(TEXT("en"), ESearchCase::IgnoreCase)) { ApplyEnglishMilitaryPreset(); }
	else { ApplyPersianFarsiPreset(); }
	if (APlayerController* PC = UGameplayStatics::GetPlayerController(GetWorld(), 0))
	{
		PushSettingsToHUD(Cast<ASquadAIMainMenuHUD>(PC->GetHUD()));
	}
}

void ASquadAIMainMenuSetupActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (BackgroundType == EMenuBackgroundType::Cinematic3DCameraOrbit && bEnableCinematicCameraPan && MenuCamera)
	{
		CurrentPanAngle += CameraPanSpeed * DeltaTime;
		if (CurrentPanAngle >= 360.0f) CurrentPanAngle -= 360.0f;

		const float Rad = FMath::DegreesToRadians(CurrentPanAngle);
		const float CamX = FMath::Cos(Rad) * OrbitRadius;
		const float CamY = FMath::Sin(Rad) * OrbitRadius;

		MenuCamera->SetRelativeLocation(FVector(CamX, CamY, CameraHeight));

		const FVector TargetLookLoc = FVector::ZeroVector + FVector(0.0f, 0.0f, CameraHeight * 0.5f);
		const FRotator LookRot = (TargetLookLoc - MenuCamera->GetComponentLocation()).Rotation();
		MenuCamera->SetWorldRotation(LookRot);
	}
}

void ASquadAIMainMenuSetupActor::AutoSetupMasterMainMenu()
{
	AutoResolveAllTextureSlots();

	int32 ResolvedCount = 0;
	if (MenuBackgroundTexture) ResolvedCount++;
	if (LoadingScreenTexture) ResolvedCount++;
	if (WatermarkEmblemTexture) ResolvedCount++;
	if (PlayerProgressionArtTexture) ResolvedCount++;
	if (FrameTacticalGoldTexture) ResolvedCount++;
	if (FrameTacticalCrimsonTexture) ResolvedCount++;
	if (FrameBadgeHexagonTexture) ResolvedCount++;
	if (FrameAvatarPortraitTexture) ResolvedCount++;
	if (AvatarShahidRostamiTexture) ResolvedCount++;
	if (AvatarYoungBasijiTexture) ResolvedCount++;
	if (AvatarArteshParatrooperTexture) ResolvedCount++;
	if (AvatarGuerrillaHunterTexture) ResolvedCount++;
	if (TraitTankDestroyerTexture) ResolvedCount++;
	if (TraitHeavyCaliberTexture) ResolvedCount++;
	if (TraitDesertReliabilityTexture) ResolvedCount++;
	if (TraitAreaSuppressionTexture) ResolvedCount++;
	if (TraitSilentMarksmanTexture) ResolvedCount++;
	if (MapPreviewDehlaviehTexture) ResolvedCount++;
	if (MapPreviewBostanTexture) ResolvedCount++;
	if (MapPreviewKhorramshahrTexture) ResolvedCount++;
	if (WeaponPreviewG3A3Texture) ResolvedCount++;
	if (WeaponPreviewAK47Texture) ResolvedCount++;
	if (WeaponPreviewRPG7Texture) ResolvedCount++;
	if (WeaponPreviewMG3Texture) ResolvedCount++;
	if (WeaponPreviewSVDTexture) ResolvedCount++;

	SetupStatusMessage = FString::Printf(TEXT("SUCCESS: Master Main Menu Setup Complete! [%d/25 Asset Slots Resolved]. Level: %s"),
		ResolvedCount, *TargetGameplayLevelName.ToString());

	UE_LOG(LogTemp, Warning, TEXT("[MainMenuMaster] %s"), *SetupStatusMessage);
}

void ASquadAIMainMenuSetupActor::AutoResolveAllTextureSlots()
{
	// 1. Key Art Backgrounds
	// AAA-MW-27: force the clean loose PNG first so old imported map assets with
	// baked square/grid overlays cannot override the Canvas main menu background.
	if (UTexture2D* CleanMenuBackground = FSquadAIAssetHelper::LoadTextureSafe(nullptr, TEXT("Textures/Menu_Background_KhuzestanDesertWar.png")))
	{
		MenuBackgroundTexture = CleanMenuBackground;
	}
	else if (!MenuBackgroundTexture)
	{
		MenuBackgroundTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Menu_Background_KhuzestanDesertWar.Menu_Background_KhuzestanDesertWar"), TEXT("Textures/Menu_Background_KhuzestanDesertWar.png"));
	}
	if (!LoadingScreenTexture) LoadingScreenTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Loading_Background_TrenchAssault.Loading_Background_TrenchAssault"), TEXT("Textures/Loading_Background_TrenchAssault.png"));
	if (!NightOperationsTexture) NightOperationsTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Menu_Background_NightOperations.Menu_Background_NightOperations"), TEXT("Textures/Menu_Background_NightOperations.png"));
	if (!WatermarkEmblemTexture) WatermarkEmblemTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Military_Watermark_Emblem.UI_Military_Watermark_Emblem"), TEXT("Textures/UI_Military_Watermark_Emblem.png"));
	if (!PlayerProgressionArtTexture) PlayerProgressionArtTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Player_Progression_Art.UI_Player_Progression_Art"), TEXT("Textures/UI_Player_Progression_Art.png"));

	// AAA-MW-6: optional exact Niagara dust explosion for the Canvas main menu lower window.
	if (!MenuDustNiagaraSystem)
	{
		const TCHAR* MenuDustPaths[] =
		{
			TEXT("/Game/NiagaraExamples/FX_Explosions/NS_Dirt_Explosion.NS_Dirt_Explosion"),
			TEXT("/Game/NiagaraExamples/FX_Explosions/NS_Dirt_Explosion"),
			TEXT("/Game/NiagaraExamples/FX_Explosions/NS_Dirt_Explosion_Medium.NS_Dirt_Explosion_Medium"),
			TEXT("/Game/FX/Niagara/NS_DustExplosion.NS_DustExplosion"),
			TEXT("/Game/FX/Niagara/NS_Dust_Explosion.NS_Dust_Explosion"),
			TEXT("/Game/VFX/NS_DustExplosion.NS_DustExplosion"),
			TEXT("/Game/VFX/DustExplosion.DustExplosion"),
			TEXT("/Game/Effects/NS_DustExplosion.NS_DustExplosion"),
			TEXT("/Game/Niagara/NS_DustExplosion.NS_DustExplosion")
		};
		for (const TCHAR* Path : MenuDustPaths)
		{
			if (UNiagaraSystem* NS = LoadObject<UNiagaraSystem>(nullptr, Path))
			{
				MenuDustNiagaraSystem = NS;
				break;
			}
		}
	}

	if (!BackgroundMedalsTexture) BackgroundMedalsTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Background_Medals.UI_Background_Medals"), TEXT("Textures/UI_Background_Medals.png"));
	if (!BackgroundProgressionTexture) BackgroundProgressionTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Background_Progression.UI_Background_Progression"), TEXT("Textures/UI_Background_Progression.png"));
	if (!BackgroundArmoryTexture) BackgroundArmoryTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Background_Armory.UI_Background_Armory"), TEXT("Textures/UI_Background_Armory.png"));

	if (!DiffRecruitTexture) DiffRecruitTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Diff_Recruit.UI_Diff_Recruit"), TEXT("Textures/UI_Diff_Recruit.png"));
	if (!DiffRegularTexture) DiffRegularTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Diff_Regular.UI_Diff_Regular"), TEXT("Textures/UI_Diff_Regular.png"));
	if (!DiffHardenedTexture) DiffHardenedTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Diff_Hardened.UI_Diff_Hardened"), TEXT("Textures/UI_Diff_Hardened.png"));
	if (!DiffLethalTexture) DiffLethalTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Diff_Lethal.UI_Diff_Lethal"), TEXT("Textures/UI_Diff_Lethal.png"));

	if (!FrameMapTheaterTexture) FrameMapTheaterTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Frame_MapTheater.UI_Frame_MapTheater"), TEXT("Textures/UI_Frame_MapTheater.png"));
	if (!ProgressionUpgradeBarTexture) ProgressionUpgradeBarTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Progression_UpgradeBar.UI_Progression_UpgradeBar"), TEXT("Textures/UI_Progression_UpgradeBar.png"));

	// 2. AAA Modular Frames
	if (!FrameTacticalGoldTexture) FrameTacticalGoldTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Frame_TacticalBorder_Gold.UI_Frame_TacticalBorder_Gold"), TEXT("Textures/UI_Frame_TacticalBorder_Gold.png"));
	if (!FrameTacticalCrimsonTexture) FrameTacticalCrimsonTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Frame_TacticalBorder_Crimson.UI_Frame_TacticalBorder_Crimson"), TEXT("Textures/UI_Frame_TacticalBorder_Crimson.png"));
	if (!FrameBadgeHexagonTexture) FrameBadgeHexagonTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Frame_Badge_Hexagon.UI_Frame_Badge_Hexagon"), TEXT("Textures/UI_Frame_Badge_Hexagon.png"));
	if (!FrameAvatarPortraitTexture) FrameAvatarPortraitTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Frame_Avatar_Portrait.UI_Frame_Avatar_Portrait"), TEXT("Textures/UI_Frame_Avatar_Portrait.png"));

	// 3. Soldier Profile Avatars
	if (!AvatarShahidRostamiTexture) AvatarShahidRostamiTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Avatar_ShahidRostami.UI_Avatar_ShahidRostami"), TEXT("Textures/UI_Avatar_ShahidRostami.png"));
	if (!AvatarYoungBasijiTexture) AvatarYoungBasijiTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Avatar_YoungBasiji.UI_Avatar_YoungBasiji"), TEXT("Textures/UI_Avatar_YoungBasiji.png"));
	if (!AvatarArteshParatrooperTexture) AvatarArteshParatrooperTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Avatar_ArteshParatrooper.UI_Avatar_ArteshParatrooper"), TEXT("Textures/UI_Avatar_ArteshParatrooper.png"));
	if (!AvatarGuerrillaHunterTexture) AvatarGuerrillaHunterTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Avatar_GuerrillaHunter.UI_Avatar_GuerrillaHunter"), TEXT("Textures/UI_Avatar_GuerrillaHunter.png"));

	// 4. Speciality Trait Badges
	if (!TraitTankDestroyerTexture) TraitTankDestroyerTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Trait_TankDestroyer.UI_Trait_TankDestroyer"), TEXT("Textures/UI_Trait_TankDestroyer.png"));
	if (!TraitHeavyCaliberTexture) TraitHeavyCaliberTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Trait_HeavyCaliber.UI_Trait_HeavyCaliber"), TEXT("Textures/UI_Trait_HeavyCaliber.png"));
	if (!TraitDesertReliabilityTexture) TraitDesertReliabilityTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Trait_DesertReliability.UI_Trait_DesertReliability"), TEXT("Textures/UI_Trait_DesertReliability.png"));
	if (!TraitAreaSuppressionTexture) TraitAreaSuppressionTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Trait_AreaSuppression.UI_Trait_AreaSuppression"), TEXT("Textures/UI_Trait_AreaSuppression.png"));
	if (!TraitSilentMarksmanTexture) TraitSilentMarksmanTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Trait_SilentMarksman.UI_Trait_SilentMarksman"), TEXT("Textures/UI_Trait_SilentMarksman.png"));

	// 5. Map Previews
	if (!MapPreviewDehlaviehTexture) MapPreviewDehlaviehTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Map_Preview_Dehlavieh_Karkheh.Map_Preview_Dehlavieh_Karkheh"), TEXT("Textures/Map_Preview_Dehlavieh_Karkheh.png"));
	if (!MapPreviewBostanTexture) MapPreviewBostanTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Map_Preview_Bostan_Chazzabeh.Map_Preview_Bostan_Chazzabeh"), TEXT("Textures/Map_Preview_Bostan_Chazzabeh.png"));
	if (!MapPreviewKhorramshahrTexture) MapPreviewKhorramshahrTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Map_Preview_Khorramshahr_Arvand.Map_Preview_Khorramshahr_Arvand"), TEXT("Textures/Map_Preview_Khorramshahr_Arvand.png"));

	// 6. Period Weapon Previews
	if (!WeaponPreviewG3A3Texture) WeaponPreviewG3A3Texture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Weapon_Preview_G3A3.Weapon_Preview_G3A3"), TEXT("Textures/Weapon_Preview_G3A3.png"));
	if (!WeaponPreviewAK47Texture) WeaponPreviewAK47Texture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Weapon_Preview_AK47.Weapon_Preview_AK47"), TEXT("Textures/Weapon_Preview_AK47.png"));
	if (!WeaponPreviewRPG7Texture) WeaponPreviewRPG7Texture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Weapon_Preview_RPG7.Weapon_Preview_RPG7"), TEXT("Textures/Weapon_Preview_RPG7.png"));
	if (!WeaponPreviewMG3Texture) WeaponPreviewMG3Texture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Weapon_Preview_MG3.Weapon_Preview_MG3"), TEXT("Textures/Weapon_Preview_MG3.png"));
	if (!WeaponPreviewSVDTexture) WeaponPreviewSVDTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/Weapon_Preview_SVD.Weapon_Preview_SVD"), TEXT("Textures/Weapon_Preview_SVD.png"));

	// 7. Inventory & Relics
	if (!PocketQuranTexture) PocketQuranTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Item_PocketQuran.UI_Item_PocketQuran"), TEXT("Textures/UI_Item_PocketQuran.png"));
	if (!PocketRadioTexture) PocketRadioTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Item_PocketRadio.UI_Item_PocketRadio"), TEXT("Textures/UI_Item_PocketRadio.png"));
	if (!CombatWalletTexture) CombatWalletTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Item_CombatWallet.UI_Item_CombatWallet"), TEXT("Textures/UI_Item_CombatWallet.png"));
	if (!FirstAidPouchTexture) FirstAidPouchTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Item_FirstAidPouch.UI_Item_FirstAidPouch"), TEXT("Textures/UI_Item_FirstAidPouch.png"));
	if (!CanteenTexture) CanteenTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Item_Canteen.UI_Item_Canteen"), TEXT("Textures/UI_Item_Canteen.png"));
	if (!DogTagTexture) DogTagTexture = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_Item_DogTag.UI_Item_DogTag"), TEXT("Textures/UI_Item_DogTag.png"));
	if (!FallenNotesPlaceholderArtwork) FallenNotesPlaceholderArtwork = FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_FallenNotes_Background.UI_FallenNotes_Background"), TEXT("Textures/UI_FallenNotes_Background.png"));

	SetupStatusMessage = TEXT("Auto-Resolved all asset slots from /Game/Textures/ and Content/Textures/.");
}

void ASquadAIMainMenuSetupActor::ApplyPersianFarsiPreset()
{
	MenuTextConfig.GameTitle = FText::FromString(TEXT("عملیات خوزستان | سرگرد شهید ایرج رستمی"));
	MenuTextConfig.GameSubtitle = FText::FromString(TEXT("شوتر تاکتیکی جهان‌باز فرماندهی جوخه — دفاع مقدس (۱۳۵۹)"));
	MenuTextConfig.ButtonNewGame = FText::FromString(TEXT("شروع بازی جدید"));
	MenuTextConfig.ButtonMapSelect = FText::FromString(TEXT("انتخاب منطقه و نقشه عملیات"));
	MenuTextConfig.ButtonArmory = FText::FromString(TEXT("زرادخانه و آزادسازی سلاح‌ها"));
	MenuTextConfig.ButtonProgression = FText::FromString(TEXT("ارتقای توانمندی‌ها و سطح رزمنده"));
	MenuTextConfig.ButtonPlayerProfile = FText::FromString(TEXT("پرونده و آمار نبردهای رزمنده"));
	MenuTextConfig.ButtonAchievements = FText::FromString(TEXT("مدال‌ها و دستاوردهای جنگی"));
	MenuTextConfig.ButtonContinue = FText::FromString(TEXT("ادامه عملیات"));
	MenuTextConfig.ButtonLoadGame = FText::FromString(TEXT("بارگذاری ذخیره"));
	MenuTextConfig.ButtonSettings = FText::FromString(TEXT("تنظیمات و گرافیک"));
	MenuTextConfig.ButtonBriefing = FText::FromString(TEXT("پرونده اطلاعات عملیاتی"));
	MenuTextConfig.ButtonQuit = FText::FromString(TEXT("خروج از بازی"));
	MenuTextConfig.ButtonBack = FText::FromString(TEXT("← بازگشت"));
	MenuTextConfig.DifficultyTitle = FText::FromString(TEXT("انتخاب سطح دشواری نبرد"));
	MenuTextConfig.DiffRecruit = FText::FromString(TEXT("سرباز تازه‌کار (آسان)"));
	MenuTextConfig.DiffRegular = FText::FromString(TEXT("سرباز رزمنده (متوسط)"));
	MenuTextConfig.DiffHardened = FText::FromString(TEXT("کهنه‌سرباز (دشوار)"));
	MenuTextConfig.DiffVeteran = FText::FromString(TEXT("فرمانده افسانه‌ای (بسیار سنگین)"));
}

void ASquadAIMainMenuSetupActor::ApplyEnglishMilitaryPreset()
{
	MenuTextConfig.GameTitle = FText::FromString(TEXT("OPERATION KHUZESTAN | MAJOR SHAHID ROSTAMI"));
	MenuTextConfig.GameSubtitle = FText::FromString(TEXT("TACTICAL OPEN-WORLD SQUAD SHOOTER — UNREAL ENGINE 5.7"));
	MenuTextConfig.ButtonNewGame = FText::FromString(TEXT("NEW GAME"));
	MenuTextConfig.ButtonMapSelect = FText::FromString(TEXT("MAP & THEATER SELECT"));
	MenuTextConfig.ButtonArmory = FText::FromString(TEXT("ARMORY & WEAPONS"));
	MenuTextConfig.ButtonProgression = FText::FromString(TEXT("PLAYER UPGRADES & SKILLS"));
	MenuTextConfig.ButtonPlayerProfile = FText::FromString(TEXT("PLAYER PROFILE & STATS"));
	MenuTextConfig.ButtonAchievements = FText::FromString(TEXT("MEDALS & ACHIEVEMENTS"));
	MenuTextConfig.ButtonContinue = FText::FromString(TEXT("CONTINUE"));
	MenuTextConfig.ButtonLoadGame = FText::FromString(TEXT("LOAD GAME"));
	MenuTextConfig.ButtonSettings = FText::FromString(TEXT("SETTINGS & CONTROLS"));
	MenuTextConfig.ButtonBriefing = FText::FromString(TEXT("TACTICAL BRIEFING"));
	MenuTextConfig.ButtonQuit = FText::FromString(TEXT("QUIT GAME"));
	MenuTextConfig.ButtonBack = FText::FromString(TEXT("← BACK"));
	MenuTextConfig.DifficultyTitle = FText::FromString(TEXT("SELECT COMBAT DIFFICULTY"));
	MenuTextConfig.DiffRecruit = FText::FromString(TEXT("RECRUIT"));
	MenuTextConfig.DiffRegular = FText::FromString(TEXT("REGULAR"));
	MenuTextConfig.DiffHardened = FText::FromString(TEXT("HARDENED"));
	MenuTextConfig.DiffVeteran = FText::FromString(TEXT("VETERAN"));
}

void ASquadAIMainMenuSetupActor::TestLaunchMissionWithLoadingScreen()
{
	if (USquadAILoadingScreenSubsystem* Loading = USquadAILoadingScreenSubsystem::Get(GetWorld()))
	{
		const bool bEnglish = USquadAILocalizationSubsystem::Get(this)
			&& USquadAILocalizationSubsystem::Get(this)->GetCurrentLanguage().StartsWith(TEXT("en"), ESearchCase::IgnoreCase);
		Loading->LoadLevelWithScreen(
			TargetGameplayLevelName,
			FText::FromString(bEnglish ? TEXT("Dehlavieh and Karkheh River Axis - Front Line") : TEXT("محور دهلاویه و رودخانه کرخه - خط مقدم")),
			FText::FromString(bEnglish
				? TEXT("Advance through the forward trenches, destroy enemy heavy machine-gun positions with RPG-7 support, and stabilize the defensive line beside Major Shahid Rostami and the squad.")
				: TEXT("پیشروی در سنگرهای خط مقدم، انهدام مواضع تیربار سنگین دشمن با آرپی‌جی-۷ و تثبیت خط پدافندی با سرگرد شهید رستمی و همرزمان جوخه."))
		);
	}
	else
	{
		UGameplayStatics::OpenLevel(GetWorld(), TargetGameplayLevelName);
	}
}

void ASquadAIMainMenuSetupActor::PushSettingsToHUD(ASquadAIMainMenuHUD* HUD)
{
	if (!HUD) return;

	HUD->TargetGameplayLevelName = TargetGameplayLevelName;
	HUD->MenuTextConfig = MenuTextConfig;
	// AAA-MW-27: do not push the old material/animated background path to the main
	// Canvas HUD; it was the likely source of the rejected square-line overlay.
	HUD->BackgroundType = EMenuBackgroundType::StaticImageKenBurns;
	HUD->BackgroundMaterial = nullptr;
	if (UTexture2D* CleanMenuBackground = FSquadAIAssetHelper::LoadTextureSafe(nullptr, TEXT("Textures/Menu_Background_KhuzestanDesertWar.png")))
	{
		HUD->BackgroundTexture = CleanMenuBackground;
	}
	else
	{
		HUD->BackgroundTexture = MenuBackgroundTexture;
	}
	HUD->ColorTheme = ColorTheme;
	HUD->MenuDustNiagaraSystem = MenuDustNiagaraSystem;
	HUD->bUseNiagaraMenuDustExplosion = bUseNiagaraMenuDustExplosion;
	HUD->MenuNiagaraDustBurstInterval = FMath::Clamp(MenuNiagaraDustBurstInterval, 0.42f, 1.15f);

	// Frames
	HUD->FrameTacticalGoldTexture = FrameTacticalGoldTexture;
	HUD->FrameTacticalCrimsonTexture = FrameTacticalCrimsonTexture;
	HUD->FrameBadgeHexagonTexture = FrameBadgeHexagonTexture;
	HUD->FrameAvatarPortraitTexture = FrameAvatarPortraitTexture;

	// Avatars
	HUD->AvatarRostamiTexture = AvatarShahidRostamiTexture;
	HUD->AvatarYoungBasijiTexture = AvatarYoungBasijiTexture;
	HUD->AvatarArteshParatrooperTexture = AvatarArteshParatrooperTexture;
	HUD->AvatarGuerrillaHunterTexture = AvatarGuerrillaHunterTexture;

	// Traits
	HUD->TraitTankDestroyerTexture = TraitTankDestroyerTexture;
	HUD->TraitHeavyCaliberTexture = TraitHeavyCaliberTexture;
	HUD->TraitDesertReliabilityTexture = TraitDesertReliabilityTexture;
	HUD->TraitAreaSuppressionTexture = TraitAreaSuppressionTexture;
	HUD->TraitSilentMarksmanTexture = TraitSilentMarksmanTexture;

	// Watermark & Relics
	HUD->WatermarkEmblemTexture = WatermarkEmblemTexture;
	HUD->ProgressionArtTexture = PlayerProgressionArtTexture;

	// Section Backgrounds & Difficulty Cards
	HUD->BackgroundMedalsTexture = BackgroundMedalsTexture;
	HUD->BackgroundProgressionTexture = BackgroundProgressionTexture;
	HUD->BackgroundArmoryTexture = BackgroundArmoryTexture;
	HUD->DiffRecruitTexture = DiffRecruitTexture;
	HUD->DiffRegularTexture = DiffRegularTexture;
	HUD->DiffHardenedTexture = DiffHardenedTexture;
	HUD->DiffLethalTexture = DiffLethalTexture;
	HUD->FrameMapTheaterTexture = FrameMapTheaterTexture;
	HUD->ProgressionUpgradeBarTexture = ProgressionUpgradeBarTexture;

	// Map Previews
	HUD->MapPreviewDehlaviehTexture = MapPreviewDehlaviehTexture;
	HUD->MapPreviewBostanTexture = MapPreviewBostanTexture;
	HUD->MapPreviewKhorramshahrTexture = MapPreviewKhorramshahrTexture;

	// Weapon Previews
	HUD->WeaponPreviewG3A3Texture = WeaponPreviewG3A3Texture;
	HUD->WeaponPreviewAK47Texture = WeaponPreviewAK47Texture;
	HUD->WeaponPreviewRPG7Texture = WeaponPreviewRPG7Texture;
	HUD->WeaponPreviewMG3Texture = WeaponPreviewMG3Texture;
	HUD->WeaponPreviewSVDTexture = WeaponPreviewSVDTexture;

	// Sounds
	HUD->ButtonHoverSound = ButtonHoverSound;
	HUD->ButtonClickSound = ButtonClickSound;
	HUD->ButtonBackSound = ButtonBackSound;
	HUD->UpgradePurchasedSound = UpgradePurchasedSound;

	// Typography & Custom Fonts
	HUD->TitleFont = CustomTitleFont;
	HUD->MenuFont = CustomMenuFont;
	HUD->BodyFont = CustomBodyFont;

	HUD->ApplyThemeColors();
}

// S17-MVOL
void ASquadAIMainMenuSetupActor::SetMenuMusicVolume(float Volume)
{
	if (MenuMusicAudioComp)
	{
		MenuMusicAudioComp->SetVolumeMultiplier(FMath::Clamp(Volume, 0.f, 1.f));
	}
}

// ============================ S26-VIDEO2 ====================================
// One picker + one button per video; the shared installer in the editor library
// does the copy and the menu HUD auto-plays the result on the next open.
FString ASquadAIMainMenuSetupActor::InstallMenuBackgroundVideo()
{
	return USquadAIAutoSetupEditorLibrary::InstallMenuVideoFile(
		MenuBackgroundVideoFile, TEXT("MenuBackground.mp4"), TEXT("looping menu background video"));
}

FString ASquadAIMainMenuSetupActor::WhatWillTheMenuVideosPlay()
{
	// S26-VIDEOFIX: one button that answers "why am I still seeing the old video"
	return USquadAIAutoSetupEditorLibrary::WhatWillTheMenuVideosPlay();
}

#if WITH_EDITOR
void ASquadAIMainMenuSetupActor::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);
	// S26-VIDEOFIX: setting the path IS the button - pick a file, it installs
	// on the spot with an on-screen notification.
	const FName PropertyName = PropertyChangedEvent.GetPropertyName();
	if (PropertyName == GET_MEMBER_NAME_CHECKED(ASquadAIMainMenuSetupActor, IntroMovieVideoFile))
	{
		InstallIntroMovieVideo();
	}
	else if (PropertyName == GET_MEMBER_NAME_CHECKED(ASquadAIMainMenuSetupActor, MenuBackgroundVideoFile))
	{
		InstallMenuBackgroundVideo();
	}
}
#endif

FString ASquadAIMainMenuSetupActor::InstallIntroMovieVideo()
{
	return USquadAIAutoSetupEditorLibrary::InstallMenuVideoFile(
		IntroMovieVideoFile, TEXT("MenuIntro.mp4"), TEXT("fullscreen intro movie before the menu"));
}

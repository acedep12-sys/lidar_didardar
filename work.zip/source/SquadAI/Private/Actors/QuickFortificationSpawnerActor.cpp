#include "Actors/QuickFortificationSpawnerActor.h"
#include "Actors/MountedTurretActor.h"
#include "Actors/AmmoCrateActor.h"
#include "Actors/FirstAidKitActor.h"
#include "Performance/SquadAIAssetCacheSubsystem.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/World.h"
#include "Engine/StaticMeshActor.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Math/RotationMatrix.h"   // S26-SURF: barbed-wire strands stretch between posts

namespace
{
	// S6-Q: per-build sandbag batch tone (runtime DMI; silent on plain materials)
	UMaterialInterface* TintFortMaterial(UMaterialInterface* Base, float Offset, UObject* Outer)
	{
		if (!Base || Offset == 0.f) return Base;
		if (UMaterialInstanceDynamic* Dyn = UMaterialInstanceDynamic::Create(Base, Outer))
		{
			const FLinearColor Tone(1.f + Offset, 1.f + Offset * 0.7f, 1.f + Offset * 0.45f, 1.f);
			static const FName Candidates[] = { TEXT("Color"), TEXT("BaseColor"), TEXT("Tint"), TEXT("BaseColorTint"), TEXT("Albedo"), TEXT("Colour") };
			for (const FName& Param : Candidates)
			{
				Dyn->SetVectorParameterValue(Param, Tone);
			}
			return Dyn;
		}
		return Base;
	}
}

bool AQuickFortificationSpawnerActor::FortGroundSnap(UWorld* World, FVector& InOutLoc) const
{
	if (!World) return false;
	FHitResult Hit;
	FCollisionQueryParams Params;
	Params.AddIgnoredActor(this);
	if (World->LineTraceSingleByChannel(Hit, InOutLoc + FVector(0.f, 0.f, 400.f), InOutLoc - FVector(0.f, 0.f, 2000.f), ECC_Visibility, Params))
	{
		InOutLoc = Hit.ImpactPoint;
		return true;
	}
	return false;
}

AQuickFortificationSpawnerActor::AQuickFortificationSpawnerActor()
{
	PrimaryActorTick.bCanEverTick = false;

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SetRootComponent(SceneRoot);

	HISM_Sandbags = CreateDefaultSubobject<UHierarchicalInstancedStaticMeshComponent>(TEXT("HISM_Sandbags"));
	HISM_Sandbags->SetupAttachment(SceneRoot);
	HISM_Sandbags->SetCollisionProfileName(TEXT("BlockAllDynamic"));
}

void AQuickFortificationSpawnerActor::BeginPlay()
{
	Super::BeginPlay();
	BuildFortification();
}

void AQuickFortificationSpawnerActor::BuildFortification()
{
	ClearFortification();

	UWorld* World = GetWorld();
	if (!World) return;

	// S26-LIFE: the preset enum finally MEANS something - each preset stamps its
	// signature shape. bSpawnHeavyMG / bSpawnAmmoCrate / bSpawnFirstAidKit are
	// left alone: the factory and the designer own those.
	const bool bBunkerPreset = (FortificationPreset == EFortificationPreset::SandbagBunker);
	const bool bCheckpointPreset = (FortificationPreset == EFortificationPreset::RoadblockCheckpoint);
	const bool bTrenchPreset = (FortificationPreset == EFortificationPreset::TrenchLine);
	const bool bSniperPreset = (FortificationPreset == EFortificationPreset::SniperNest);
	if (bBunkerPreset)   { bArcFormation = true;  bDoubleTier = true;  bFlankReturns = true;  SandbagCount = FMath::Max(SandbagCount, 5); }
	if (bTrenchPreset)   { bArcFormation = false; bDoubleTier = true;  bFlankReturns = false; SandbagCount = FMath::Max(SandbagCount, 6); }
	if (bSniperPreset)   { bArcFormation = true;  bDoubleTier = false; bFlankReturns = false; SandbagCount = FMath::Max(SandbagCount, 4); }
	if (bCheckpointPreset){ bArcFormation = false; bDoubleTier = false; bFlankReturns = false; SandbagCount = FMath::Min(SandbagCount, 4); }

	// S6-Q: reseed variation + tone per build
	FortStream = FRandomStream(FortSeed);
	CurrentToneOffset = (bSeededVariation && ToneJitter > 0.f) ? FortStream.FRandRange(-ToneJitter, ToneJitter) : 0.f;

	USquadAIAssetCacheSubsystem* Cache = USquadAIAssetCacheSubsystem::Get(this);
	UStaticMesh* MeshToUse = CustomSandbagMesh;
	if (!MeshToUse)
	{
		// S26-MESH2: a SANDBAG is rounded. The engine sphere at the same per-bag
		// scales the wall code already uses reads as a real bag; the cube reads
		// as a brick. Custom mesh always wins when set.
		MeshToUse = Cache ? Cache->GetSphereMesh() : nullptr;
		if (!MeshToUse)
		{
			MeshToUse = LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cube.Cube"));
		}
	}

	UMaterialInterface* MatToApply = SandbagMaterialOverride;
	if (!MatToApply && Cache)
	{
		// S26-MAT: the real thing - sandbag texture x tone on the shared prop
		// material - with the tinted basic material as the fallback.
		UMaterialInterface* Textured = Cache->GetPropMaterial(TEXT("Sandbags"),
			FLinearColor(1.f + CurrentToneOffset * 0.5f, 1.f + CurrentToneOffset * 0.5f, 1.f + CurrentToneOffset * 0.5f, 1.f));
		MatToApply = Textured ? Textured : Cache->GetDefaultBasicMaterial();
	}
	MatToApply = TintFortMaterial(MatToApply, CurrentToneOffset, this); // S6-Q

	if (bUseHISMInstancing && HISM_Sandbags)
	{
		HISM_Sandbags->ClearInstances();
		if (MeshToUse) HISM_Sandbags->SetStaticMesh(MeshToUse);
		if (MatToApply) HISM_Sandbags->SetMaterial(0, MatToApply);
	}

	const FVector Origin = GetActorLocation();
	const FRotator Rotation = GetActorRotation();
	const FVector Forward = Rotation.Vector();
	const FVector Right = FRotationMatrix(Rotation).GetScaledAxis(EAxis::Y);

	FActorSpawnParameters SpawnParams;
	// S5-14c: WP/lifetime ownership for all spawned children.
	SpawnParams.Owner = this;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;

	// 1. Spawn Mounted Heavy MG if requested
	if (bSpawnHeavyMG)
	{
		FVector MGLoc = Origin + Forward * 50.f;
		FortGroundSnap(World, MGLoc); // S6-Q: was unsnapped — floated on slopes
		AMountedTurretActor* Turret = World->SpawnActor<AMountedTurretActor>(AMountedTurretActor::StaticClass(), MGLoc, Rotation, SpawnParams);
		if (Turret)
		{
			Turret->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
			SpawnedElements.Add(Turret);
		}
	}

	// 2. Spawn Ammo Crate
	if (bSpawnAmmoCrate)
	{
		FVector AmmoLoc = Origin - Forward * 80.f - Right * 120.f;
		FortGroundSnap(World, AmmoLoc); // S6-Q
		AAmmoCrateActor* Ammo = World->SpawnActor<AAmmoCrateActor>(AAmmoCrateActor::StaticClass(), AmmoLoc,
			Rotation + FRotator(0.f, FortStream.FRandRange(-12.f, 12.f), 0.f), SpawnParams);   // S26-TEX4: no parade-ground alignment
		if (Ammo)
		{
			Ammo->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
			SpawnedElements.Add(Ammo);
			// S26-TEX4: the crate wears the ammunition texture like every other prop
			if (Cache)
			{
				if (UMaterialInterface* AmmoMat = Cache->GetPropMaterial(TEXT("AmmoBox"), FLinearColor::White))
				{
					TInlineComponentArray<UStaticMeshComponent*> AmmoMeshes(Ammo);
					for (UStaticMeshComponent* AMC : AmmoMeshes)
					{
						if (AMC && AMC->GetStaticMesh()) { AMC->SetMaterial(0, AmmoMat); }
					}
				}
			}
		}
	}

	// 3. Spawn First Aid Kit
	if (bSpawnFirstAidKit)
	{
		FVector MedLoc = Origin - Forward * 80.f + Right * 120.f;
		FortGroundSnap(World, MedLoc); // S6-Q
		AFirstAidKitActor* Med = World->SpawnActor<AFirstAidKitActor>(AFirstAidKitActor::StaticClass(), MedLoc, Rotation, SpawnParams);
		if (Med)
		{
			Med->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
			SpawnedElements.Add(Med);
		}
	}

	// 4. Spawn Sandbag barricades — S6-Q: crescent arc, per-bag snap, jitter, tiers
	auto PlaceBag = [&](const FVector& Loc, const FRotator& Rot, const FVector& Scl, const float LiftCm = 0.f)
	{
		FVector Snapped = Loc;
		FortGroundSnap(World, Snapped); // S6-Q: every bag sits on terrain now
		// S26-DETAIL: the snap rewrites Z with the GROUND height - stacked tiers
		// pass their height as LiftCm so it survives the snap instead of collapsing
		Snapped.Z += LiftCm;
		if (bUseHISMInstancing && HISM_Sandbags)
		{
			HISM_Sandbags->AddInstance(FTransform(Rot, Snapped, Scl), true);
			return;
		}
		AStaticMeshActor* B = World->SpawnActor<AStaticMeshActor>(AStaticMeshActor::StaticClass(), Snapped, Rot, SpawnParams);
		if (B && B->GetStaticMeshComponent())
		{
			B->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
			if (MeshToUse)
			{
				B->GetStaticMeshComponent()->SetStaticMesh(MeshToUse);
				B->GetStaticMeshComponent()->SetRelativeScale3D(Scl);
				B->GetStaticMeshComponent()->SetCollisionProfileName(TEXT("BlockAllDynamic"));
			}
			if (MatToApply)
			{
				B->GetStaticMeshComponent()->SetMaterial(0, MatToApply);
			}
			SpawnedElements.Add(B);
		}
	};

	const int32 Nb = FMath::Max(1, SandbagCount);
	float Leftmost = 0.f; // track for flank returns
	for (int32 i = 0; i < Nb; ++i)
	{
		const float T = (Nb == 1) ? 0.5f : (float)i / (Nb - 1); // 0..1 across the line
		FVector BagLoc;
		FRotator BagRot = Rotation;
		if (bArcFormation)
		{
			// defensive crescent: middle bags protrude ~1.3m ahead of the flanks,
			// each bag angled tangent to the arc
			const float ArcYawRad = (T - 0.5f) * FMath::DegreesToRadians(130.f);
			const float ArcRadius = 220.f;
			BagLoc = Origin
				+ Forward * (120.f + ArcRadius * (FMath::Cos(ArcYawRad) - 1.f))
				+ Right * (FMath::Sin(ArcYawRad) * ArcRadius * 1.55f);
			BagRot = Rotation + FRotator(0.f, FMath::RadiansToDegrees(ArcYawRad), 0.f);
		}
		else
		{
			BagLoc = Origin + Forward * 120.f + Right * ((i - (Nb - 1) * 0.5f) * 160.f);
		}
		Leftmost = FMath::Max(Leftmost, FVector::DotProduct(BagLoc - Origin, Right));

		FVector Scale(0.5f, 1.4f, 0.75f);
		if (bSeededVariation)
		{
			BagLoc += Forward * FortStream.FRandRange(-7.f, 7.f) + Right * FortStream.FRandRange(-5.f, 5.f);
			BagRot += FRotator(FortStream.FRandRange(-1.5f, 1.5f), FortStream.FRandRange(-3.5f, 3.5f), FortStream.FRandRange(-1.5f, 1.5f));
			Scale.Y *= FortStream.FRandRange(0.85f, 1.15f);
			Scale.Z *= FortStream.FRandRange(0.90f, 1.10f);
		}
		PlaceBag(BagLoc, BagRot, Scale);

		// S26-DETAIL: a real sandbag wall is STACKED (three tiers), STAGGERED
		// (odd tiers shift half a bag along the row - running bond), and LEANED
		// back a touch. The old code sprinkled a few random extra bags on the
		// ground beside the row; this builds the wall the eye expects.
		if (bDoubleTier)
		{
			for (int32 Tier = 1; Tier <= 2; ++Tier)
			{
				const bool bOddTier = (Tier % 2) == 1;
				FVector TLoc = BagLoc - Forward * (12.f * Tier) + Right * (bOddTier ? 80.f : 0.f);
				FRotator TRot = BagRot + FRotator(0.f, FortStream.FRandRange(-2.f, 2.f), 0.f);
				FVector TScl(Scale.X, Scale.Y * (Tier == 2 ? 0.85f : 0.95f), Scale.Z);
				if (bSeededVariation)
				{
					TLoc += Forward * FortStream.FRandRange(-5.f, 5.f) + Right * FortStream.FRandRange(-4.f, 4.f);
					if (Tier == 2 && FortStream.FRand() < 0.25f)
					{
						continue;   // a worn crown: the top row is missing a bag here and there
					}
				}
				PlaceBag(TLoc, TRot, TScl, 55.f * Tier);
			}
		}
	}

	// Flank-return bags bending backward at both ends of the crescent
	if (bFlankReturns && Nb >= 2)
	{
		for (int32 FS = -1; FS <= 1; FS += 2)
		{
			PlaceBag(Origin + Forward * 105.f + Right * (FS * (Leftmost + 95.f)),
				Rotation + FRotator(0.f, FS * 72.f, 0.f), FVector(0.5f, 1.2f, 0.75f));
		}
	}

	// 5. S26-LIFE: scene pieces - wire, roofs, hedgehogs, fires, crates. All
	// built from the cache primitives so no content is needed.
	UStaticMesh* PieceCyl = Cache ? Cache->GetCylinderMesh() : nullptr;
	UStaticMesh* PieceCube = Cache ? Cache->GetCubeMesh() : nullptr;
	int32 FortPieceSerial = 0;   // S26-FOLDER: a fort's pieces are named, not "StaticMeshActor_214"
	auto PlacePiece = [&](const FVector& Loc, const FRotator& Rot, UStaticMesh* Mesh, const FVector& Scl,
		const bool bSolid, UMaterialInterface* Mat = nullptr, const FString& Label = FString())
	{
		if (!Mesh) { return; }
		AStaticMeshActor* Piece = World->SpawnActor<AStaticMeshActor>(AStaticMeshActor::StaticClass(), Loc, Rot, SpawnParams);
		if (Piece && Piece->GetStaticMeshComponent())
		{
			Piece->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
			Piece->GetStaticMeshComponent()->SetStaticMesh(Mesh);
			Piece->GetStaticMeshComponent()->SetRelativeScale3D(Scl);
			Piece->GetStaticMeshComponent()->SetCollisionEnabled(bSolid
				? ECollisionEnabled::QueryAndPhysics : ECollisionEnabled::NoCollision);
			if (Mat) { Piece->GetStaticMeshComponent()->SetMaterial(0, Mat); }
			else if (MatToApply) { Piece->GetStaticMeshComponent()->SetMaterial(0, MatToApply); }
#if WITH_EDITOR
			Piece->SetActorLabel(Label.IsEmpty()
				? FString::Printf(TEXT("Fort Piece %d"), ++FortPieceSerial)
				: Label);
			Piece->SetFolderPath(FName(TEXT("SquadAI/Fortifications")));   // S26-FOLDER
#endif
			SpawnedElements.Add(Piece);
		}
	};
	auto PieceMat = [&](const TCHAR* TexKey, const FLinearColor& Tint, float UVScale = 1.f) -> UMaterialInterface*
	{
		if (!Cache) { return nullptr; }
		UMaterialInterface* M = Cache->GetPropMaterial(TexKey, Tint, UVScale);   // S26-PATINA: big surfaces tile instead of stretching
		return M ? M : MatToApply;
	};

	// 5a. S26-SURF: barbed wire behind the crest - posts and two twisted strands.
	// Posts are solid; the strands are decoration-only so they never block a
	// player vaulting the wall.
	if ((bBunkerPreset || bTrenchPreset) && Nb >= 3)
	{
		const float WireT[4] = { 0.125f, 0.375f, 0.625f, 0.875f };
		FVector PostTops[4];
		bool bAllPosts = true;
		for (int32 Wi = 0; Wi < 4; ++Wi)
		{
			const float T = WireT[Wi];
			const float ArcYawRad = (T - 0.5f) * FMath::DegreesToRadians(130.f);
			const float ArcRadius = 220.f;
			// S26-LIFE: the wire follows the wall it guards - arc behind an arc,
			// straight line behind a trench wall
			FVector PLoc = bArcFormation
				? Origin
					+ Forward * (95.f + ArcRadius * (FMath::Cos(ArcYawRad) - 1.f))
					+ Right * (FMath::Sin(ArcYawRad) * ArcRadius * 1.55f)
				: Origin - Forward * 45.f
					+ Right * ((T - 0.5f) * (Nb - 1) * 160.f);
			if (!FortGroundSnap(World, PLoc)) { bAllPosts = false; break; }
			PostTops[Wi] = PLoc + FVector(0.f, 0.f, 140.f);
			PlacePiece(PLoc + FVector(0.f, 0.f, 70.f),
				Rotation + FRotator(-6.f, bArcFormation ? FMath::RadiansToDegrees(ArcYawRad) : 0.f, 0.f),
				PieceCyl, FVector(0.14f, 0.14f, 1.4f), true);
		}
		if (bAllPosts)
		{
			auto PlaceWire = [&](const FVector& A, const FVector& B)
			{
				const FVector Dir = B - A;
				const float Len = Dir.Size();
				if (Len < 60.f) { return; }
				PlacePiece((A + B) * 0.5f, FRotationMatrix::MakeFromZ(Dir).Rotator(),
					PieceCyl, FVector(0.05f, 0.05f, Len / 100.f), false);
			};
			for (int32 Wi = 0; Wi < 3; ++Wi)
			{
				PlaceWire(PostTops[Wi], PostTops[Wi + 1]);
				PlaceWire(PostTops[Wi] - FVector(0.f, 0.f, 25.f), PostTops[Wi + 1] - FVector(0.f, 0.f, 25.f));
			}
		}
	}

	// 5b. S26-LIFE: BUNKER - a corrugated roof over the nest and a campfire
	// ring behind it. A position someone LIVES in, not just fights from.
	if (bBunkerPreset)
	{
		UMaterialInterface* RoofMat = PieceMat(TEXT("CorrugatedRust"), FLinearColor(0.85f, 0.8f, 0.7f, 1.f));
		for (float PX = -1.f; PX <= 1.f; PX += 2.f)
		{
			for (float PY = -1.f; PY <= 1.f; PY += 2.f)
			{
				PlacePiece(Origin + Forward * 120.f + Right * (PY * 150.f) + FVector(PX * 160.f, 0.f, 85.f),
					FRotator::ZeroRotator, PieceCyl, FVector(0.16f, 0.16f, 1.7f), true, RoofMat);
			}
		}
		PlacePiece(Origin + Forward * 120.f + FVector(-85.f, 0.f, 176.f), FRotator(0.f, 90.f, 9.f),
			PieceCube, FVector(3.6f, 0.9f, 0.1f), false, RoofMat);
		PlacePiece(Origin + Forward * 120.f + FVector(85.f, 0.f, 176.f), FRotator(0.f, 90.f, -9.f),
			PieceCube, FVector(3.6f, 0.9f, 0.1f), false, RoofMat);
		// the fire: stone ring, crossed charred logs, ash plate
		UMaterialInterface* StoneMat = PieceMat(TEXT("Concrete"), FLinearColor(0.55f, 0.53f, 0.5f, 1.f));
		UMaterialInterface* CharMat = PieceMat(TEXT("ScorchedMetal"), FLinearColor(0.06f, 0.05f, 0.04f, 1.f));
		const FVector FireAt = Origin - Forward * 150.f + Right * 190.f;
		for (int32 Si = 0; Si < 7; ++Si)
		{
			const float Sa = Si * (360.f / 7.f);
			PlacePiece(FireAt + FRotator(0.f, Sa, 0.f).Vector() * 42.f + FVector(0.f, 0.f, 8.f),
				FRotator(0.f, Sa, 12.f), PieceCube, FVector(0.34f, 0.26f, 0.16f), true, StoneMat);
		}
		PlacePiece(FireAt + FVector(0.f, 0.f, 8.f), FRotator(0.f, 25.f, 90.f), PieceCyl, FVector(0.11f, 0.11f, 0.55f), false, CharMat);
		PlacePiece(FireAt + FVector(0.f, 0.f, 8.f), FRotator(0.f, -40.f, 90.f), PieceCyl, FVector(0.11f, 0.11f, 0.55f), false, CharMat);
		PlacePiece(FireAt + FVector(0.f, 0.f, 2.f), FRotator::ZeroRotator, PieceCyl, FVector(0.6f, 0.6f, 0.04f), false, CharMat);
	}

	// 5c. S26-LIFE: CHECKPOINT - Czech hedgehogs, a striped boom, a stop sign.
	// The road stops HERE.
	if (bCheckpointPreset)
	{
		UMaterialInterface* SteelMat = PieceMat(TEXT("ScorchedMetal"), FLinearColor(0.35f, 0.32f, 0.28f, 1.f));
		UMaterialInterface* HazardMat = PieceMat(TEXT("HazardPad"), FLinearColor::White);
		for (float HG = -1.f; HG <= 1.f; HG += 2.f)
		{
			const FVector HGAt = Origin + Forward * 240.f + Right * (HG * 210.f);
			FVector HGGround = HGAt;
			FortGroundSnap(World, HGGround);
			const FRotator HedgeRots[3] = { FRotator(45.f, 0.f, 0.f), FRotator(-45.f, 60.f, 0.f), FRotator(0.f, 120.f, 45.f) };
			for (const FRotator& HR : HedgeRots)
			{
				PlacePiece(HGGround + FVector(0.f, 0.f, 60.f), Rotation + HR, PieceCube, FVector(0.16f, 0.16f, 3.1f), true, SteelMat, TEXT("Czech Hedgehog"));
			}
		}
		const FVector BoomPost = Origin + Forward * 210.f - Right * 200.f;
		FVector BoomGround = BoomPost;
		FortGroundSnap(World, BoomGround);
		PlacePiece(BoomGround + FVector(0.f, 0.f, 75.f), Rotation, PieceCube, FVector(0.15f, 0.15f, 1.5f), true, SteelMat);
		PlacePiece(BoomGround + Right * 110.f + FVector(0.f, 0.f, 130.f), Rotation,
			PieceCube, FVector(4.4f, 0.12f, 0.12f), false,
			PieceMat(TEXT("HazardPad"), FLinearColor::White, 4.4f), TEXT("Checkpoint Boom Arm"));   // S26-PATINA: stripes tile the full 4.4 m
		PlacePiece(BoomGround + Right * 340.f + FVector(0.f, 0.f, 130.f), Rotation,
			PieceCube, FVector(0.12f, 0.12f, 0.3f), true, SteelMat);
		const FVector SignAt = Origin + Forward * 290.f + Right * 130.f;
		FVector SignGround = SignAt;
		FortGroundSnap(World, SignGround);
		PlacePiece(SignGround + FVector(0.f, 0.f, 110.f), Rotation + FRotator(0.f, 25.f, 0.f), PieceCyl, FVector(0.05f, 0.05f, 2.2f), true, SteelMat);
		PlacePiece(SignGround + FVector(0.f, 0.f, 210.f), Rotation + FRotator(0.f, 25.f, 0.f), PieceCube, FVector(0.55f, 0.06f, 0.55f), false,
			PieceMat(TEXT("ScorchedMetal"), FLinearColor(0.9f, 0.15f, 0.1f, 1.f)), TEXT("Checkpoint Halt Sign"));

		// S26-PATINA: the wreck that EXPLAINS the roadblock - a burned-out
		// truck angled off past the barrier, rolled onto its side, front wheel
		// flung free. Solid pieces: the hulk is cover now.
		{
			const FVector WreckAt = Origin + Forward * 560.f + Right * 300.f;
			FVector WreckGround = WreckAt;
			FortGroundSnap(World, WreckGround);
			const FRotator WreckRot = Rotation + FRotator(0.f, 38.f, 7.f);
			const FVector FDir = FRotator(0.f, WreckRot.Yaw, 0.f).Vector();
			const FVector RDir = FRotator(0.f, WreckRot.Yaw + 90.f, 0.f).Vector();
			UMaterialInterface* CharMat = PieceMat(TEXT("ScorchedMetal"), FLinearColor(0.05f, 0.045f, 0.04f, 1.f), 2.4f);
			UMaterialInterface* BurnMat = PieceMat(TEXT("OliveArmor"), FLinearColor(0.16f, 0.15f, 0.12f, 1.f), 1.5f);
			// the scorch pool under it
			PlacePiece(WreckGround + FVector(0.f, 0.f, 3.f), WreckRot, PieceCyl, FVector(3.4f, 3.4f, 0.06f), false, CharMat, TEXT("Wreck Scorch"));
			// chassis, rolled 7 degrees off its wheels
			PlacePiece(WreckGround + FVector(0.f, 0.f, 58.f), WreckRot, PieceCube, FVector(1.24f, 3.1f, 0.34f), true, CharMat, TEXT("Burned-Out Truck Chassis"));
			// the cab shell at the front, stove in
			PlacePiece(WreckGround + FDir * 135.f + FVector(0.f, 0.f, 105.f), WreckRot + FRotator(0.f, 0.f, -6.f),
				PieceCube, FVector(1.15f, 0.95f, 0.85f), true, BurnMat, TEXT("Wrecked Cab"));
			// the collapsed cargo bed
			PlacePiece(WreckGround - FDir * 55.f + FVector(0.f, 0.f, 85.f), WreckRot + FRotator(0.f, 0.f, 5.f),
				PieceCube, FVector(1.2f, 1.6f, 0.55f), true, BurnMat, TEXT("Collapsed Cargo Bed"));
			// two wheels still on the rear axle
			for (float WX = -1.f; WX <= 1.f; WX += 2.f)
			{
				PlacePiece(WreckGround - FDir * 115.f + RDir * (WX * 68.f) + FVector(0.f, 0.f, 30.f),
					WreckRot + FRotator(0.f, 0.f, 90.f), PieceCyl, FVector(0.52f, 0.52f, 0.18f), true, CharMat);
			}
			// the front wheel that came off - flung 3 m clear, lying flat
			PlacePiece(WreckGround + FDir * 250.f + RDir * 120.f + FVector(0.f, 0.f, 9.f),
				FRotator(0.f, FortStream.FRandRange(0.f, 360.f), 0.f), PieceCyl, FVector(0.52f, 0.52f, 0.18f), true, CharMat);
		}
	}

	// 5d. S26-LIFE: TRENCH - a supply cache stacked beside the line.
	if (bTrenchPreset)
	{
		UMaterialInterface* CrateMat = PieceMat(TEXT("SupplyCrate"), FLinearColor::White);
		const FVector CacheAt = Origin - Forward * 120.f - Right * 140.f;
		FVector CacheGround = CacheAt;
		FortGroundSnap(World, CacheGround);
		PlacePiece(CacheGround + FVector(0.f, 0.f, 30.f), Rotation + FRotator(0.f, 12.f, 0.f), PieceCube, FVector(0.6f, 0.6f, 0.55f), true, CrateMat, TEXT("Trench Supply Cache"));
		PlacePiece(CacheGround + FVector(35.f, 15.f, 80.f), Rotation + FRotator(0.f, -18.f, 0.f), PieceCube, FVector(0.5f, 0.5f, 0.45f), true, CrateMat, TEXT("Trench Cache Crate"));
		PlacePiece(CacheGround + FVector(-30.f, 40.f, 26.f), Rotation + FRotator(0.f, 40.f, 0.f), PieceCube, FVector(0.42f, 0.42f, 0.35f), true, CrateMat, TEXT("Trench Cache Crate"));
	}

	// 5e. S26-STAIR/LIFE: SNIPER - an ELEVATED observation post: four posts, a
	// 3 m deck with rails (front open for the shot), a ladder up the back, the
	// scrim netting overhead, and a rest crate on the deck. The sandbag arc at
	// ground level stays as the base position.
	if (bSniperPreset)
	{
		UMaterialInterface* NetMat = PieceMat(TEXT("CamoTarp"), FLinearColor(0.7f, 0.75f, 0.6f, 1.f));
		UMaterialInterface* WoodMat = PieceMat(TEXT("WoodPlanks"), FLinearColor(0.8f, 0.75f, 0.62f, 1.f));
		UMaterialInterface* DeckMat = PieceMat(TEXT("WoodPlanks"), FLinearColor(0.8f, 0.75f, 0.62f, 1.f), 2.6f);   // S26-PATINA: 2.6 m deck tiles, no stretched grain
		UMaterialInterface* LadderMat = PieceMat(TEXT("WoodPlanks"), FLinearColor(0.8f, 0.75f, 0.62f, 1.f), 3.0f);
		const FVector PC = Origin + Forward * 120.f;
		const float DeckZ = 300.f;
		for (float LX = -1.f; LX <= 1.f; LX += 2.f)
		{
			for (float LY = -1.f; LY <= 1.f; LY += 2.f)
			{
				FVector LegBase = PC + Forward * (LX * 95.f) + Right * (LY * 95.f);
				FortGroundSnap(World, LegBase);
				// S26-LOGIC: each leg is as tall as ITS ground demands - fixed 3 m
				// legs poked through the deck on high corners and hung in the air
				// on low ones. Sniper posts sit on hills; hills have slope.
				const float ThisLegH = FMath::Max((Origin.Z + DeckZ + 8.f) - LegBase.Z, 60.f);
				PlacePiece(FVector(LegBase.X, LegBase.Y, LegBase.Z + ThisLegH * 0.5f), Rotation,
					PieceCyl, FVector(0.2f, 0.2f, ThisLegH / 100.f), true, WoodMat);
			}
		}
		PlacePiece(PC + FVector(0.f, 0.f, DeckZ + 8.f), Rotation, PieceCube, FVector(2.6f, 2.6f, 0.16f), true, DeckMat, TEXT("Sniper Nest Deck"));
		// deck rails, front open
		for (float RX = -1.f; RX <= 1.f; RX += 2.f)
		{
			// side rails (run along Forward)
			PlacePiece(PC + Right * (RX * 127.f) + FVector(0.f, 0.f, DeckZ + 66.f), Rotation,
				PieceCube, FVector(2.6f, 0.07f, 0.07f), false, DeckMat);
			// four corner posts
			PlacePiece(PC + Forward * (RX * 127.f) + Right * (RX * 127.f) + FVector(0.f, 0.f, DeckZ + 24.f), Rotation,
				PieceCyl, FVector(0.06f, 0.06f, 1.0f), false, WoodMat);
		}
		// the back edge rail only - the FRONT stays open for the shot
		PlacePiece(PC - Forward * 127.f + FVector(0.f, 0.f, DeckZ + 66.f), Rotation + FRotator(0.f, 90.f, 0.f),
			PieceCube, FVector(2.6f, 0.07f, 0.07f), false, WoodMat);
		// the ladder up the back
		for (float LX = -1.f; LX <= 1.f; LX += 2.f)
		{
			PlacePiece(PC - Forward * 138.f + Right * (LX * 22.f) + FVector(0.f, 0.f, DeckZ * 0.5f),
				Rotation, PieceCube, FVector(0.06f, 0.06f, 3.0f), true, LadderMat);
		}
		for (float RungZ = 55.f; RungZ < DeckZ - 20.f; RungZ += 55.f)
		{
			PlacePiece(PC - Forward * 138.f + FVector(0.f, 0.f, RungZ), Rotation,
				PieceCube, FVector(0.06f, 0.52f, 0.06f), false, WoodMat);
		}
		// scrim netting overhead + a rest crate on the deck
		for (float NX = -1.f; NX <= 1.f; NX += 2.f)
		{
			PlacePiece(PC + Right * (NX * 90.f) + FVector(0.f, 0.f, DeckZ + 16.f + 95.f),
				Rotation + FRotator(0.f, NX * 12.f, NX * 18.f), PieceCube, FVector(1.5f, 1.1f, 0.04f), false, NetMat, TEXT("Sniper Scrim Netting"));
		}
		PlacePiece(PC + Forward * 70.f + Right * 75.f + FVector(0.f, 0.f, DeckZ + 16.f + 25.f),
			Rotation + FRotator(0.f, 20.f, 0.f), PieceCube, FVector(0.5f, 0.5f, 0.42f), true,
			PieceMat(TEXT("SupplyCrate"), FLinearColor::White));
	}

	// 6. S26-WEAR3: the post has BEEN under fire - spent brass by the gun,
	// pocks stitched into the dirt out front, a scorch where a bag burned,
	// a fallen helmet, a bag knocked off the wall. The small stuff is
	// instanced (one HISM per material, never one actor per casing), and
	// the randomness is seeded from the post's OWN location, so no two
	// posts wear the same.
	{
		uint32 WState = (uint32)(FMath::Abs(Origin.X * 0.31f) + FMath::Abs(Origin.Y * 0.53f)) | 1u;
		auto WRand = [&WState]() -> float
		{
			WState = WState * 1103515245u + 12345u;
			return (float)((WState >> 16) & 0xFFFFu) / 65535.f;
		};
		auto MakeWearHISM = [&](const TCHAR* CompName) -> UHierarchicalInstancedStaticMeshComponent*
		{
			// reuse the one from a previous build (same name, same tag) - a
			// destroyed-then-recreated component would fight over the name
			UHierarchicalInstancedStaticMeshComponent* H = nullptr;
			TInlineComponentArray<UHierarchicalInstancedStaticMeshComponent*> WearComps(this);
			for (UHierarchicalInstancedStaticMeshComponent* C : WearComps)
			{
				if (C && C->ComponentTags.Contains(FName(TEXT("FortBattleWear"))) && C->GetFName() == CompName)
				{
					H = C;
					break;
				}
			}
			if (!H)
			{
				H = NewObject<UHierarchicalInstancedStaticMeshComponent>(this, CompName);
				H->ComponentTags.Add(FName(TEXT("FortBattleWear")));
				H->RegisterComponent();
				H->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
			}
			H->SetStaticMesh(PieceCyl);
			H->SetCollisionProfileName(TEXT("NoCollision"));
			H->SetCastShadow(false);
			H->SetCanEverAffectNavigation(false);
			H->ClearInstances();
			return H;
		};
		// spent brass: a tight pile beside the gun, then singles thrown wide
		UMaterialInterface* BrassMat = Cache ? Cache->GetPropMaterial(TEXT("MetalPlate"), FLinearColor(0.72f, 0.55f, 0.22f, 1.f), 1.5f) : nullptr;
		if (PieceCyl && BrassMat)
		{
			UHierarchicalInstancedStaticMeshComponent* BrassHISM = MakeWearHISM(TEXT("HISM_FortBrass"));
			BrassHISM->SetMaterial(0, BrassMat);
			const FVector PileAt = Origin + Forward * 55.f + Right * 35.f;
			for (int32 Ci = 0; Ci < 5; ++Ci)
			{
				FVector CLoc = PileAt + FVector(WRand() * 76.f - 38.f, WRand() * 76.f - 38.f, 0.f);
				FortGroundSnap(World, CLoc);
				BrassHISM->AddInstance(FTransform(FRotator(90.f, WRand() * 360.f, 0.f),
					CLoc + FVector(0.f, 0.f, 2.f), FVector(0.024f, 0.024f, 0.055f)), true);
			}
			const int32 StrayCount = 4 + (int32)(WRand() * 5.f);
			for (int32 Si = 0; Si < StrayCount; ++Si)
			{
				FVector CLoc = Origin + Forward * (WRand() * 320.f - 160.f) + Right * (WRand() * 440.f - 220.f);
				FortGroundSnap(World, CLoc);
				BrassHISM->AddInstance(FTransform(FRotator(90.f, WRand() * 360.f, 0.f),
					CLoc + FVector(0.f, 0.f, 2.f), FVector(0.024f, 0.024f, 0.055f)), true);
			}
		}
		// missed shots stitched into the dirt in front of the line
		UMaterialInterface* PockMat = Cache ? Cache->GetPropMaterial(TEXT("ScorchedMetal"), FLinearColor(0.09f, 0.08f, 0.07f, 1.f), 1.f) : nullptr;
		if (PieceCyl && PockMat)
		{
			UHierarchicalInstancedStaticMeshComponent* PockHISM = MakeWearHISM(TEXT("HISM_FortPocks"));
			PockHISM->SetMaterial(0, PockMat);
			const float StrafeY = WRand() * 160.f - 80.f;
			const int32 PockCount = 4 + (int32)(WRand() * 3.f);
			for (int32 Pi = 0; Pi < PockCount; ++Pi)
			{
				FVector PLoc = Origin + Forward * (250.f + WRand() * 60.f)
					+ Right * (StrafeY + Pi * 42.f - PockCount * 21.f + WRand() * 14.f);
				FortGroundSnap(World, PLoc);
				PockHISM->AddInstance(FTransform(FRotator::ZeroRotator,
					PLoc + FVector(0.f, 0.f, 1.5f), FVector(0.10f, 0.10f, 0.016f)), true);
			}
			// the scorch where a bag burned - off one flank of the wall
			if (WRand() > 0.4f)
			{
				const float FlankSide = (WRand() > 0.5f) ? 1.f : -1.f;
				FVector SLoc = Origin + Forward * 100.f + Right * (FlankSide * (180.f + WRand() * 90.f));
				FortGroundSnap(World, SLoc);
				PockHISM->AddInstance(FTransform(FRotator::ZeroRotator,
					SLoc + FVector(0.f, 0.f, 2.f), FVector(1.2f, 1.2f, 0.03f)), true);
			}
		}
		// a fallen helmet behind the line - someone did not duck in time
		if (WRand() > 0.35f && Cache)
		{
			FVector HLoc = Origin - Forward * (70.f + WRand() * 80.f) + Right * (WRand() * 300.f - 150.f);
			FortGroundSnap(World, HLoc);
			PlacePiece(HLoc + FVector(0.f, 0.f, 7.f),
				FRotator(WRand() * 80.f - 40.f, WRand() * 360.f, 12.f),
				Cache->GetSphereMesh(), FVector(0.26f, 0.26f, 0.15f), false,
				PieceMat(TEXT("OliveArmor"), FLinearColor(0.42f, 0.45f, 0.34f, 1.f)), TEXT("Fallen Helmet"));
		}
		// a bag knocked clean off the wall - one more instance in the sandbag HISM
		if (WRand() > 0.45f)
		{
			PlaceBag(Origin + Forward * (215.f + WRand() * 55.f) + Right * (WRand() * 300.f - 150.f),
				Rotation + FRotator(30.f, WRand() * 40.f - 20.f, 18.f), FVector(0.5f, 1.4f, 0.75f));
		}
	}
	
	UE_LOG(LogTemp, Log, TEXT("[QuickFortification] %s built fortification (HISM: %s)"), *GetName(), bUseHISMInstancing ? TEXT("TRUE") : TEXT("FALSE"));
}

void AQuickFortificationSpawnerActor::ClearFortification()
{
	if (HISM_Sandbags)
	{
		HISM_Sandbags->ClearInstances();
	}

	// S26-WEAR3: wear components are not destroyed - the next build finds
	// them by name and reuses them; here only their instances go
	for (UActorComponent* WearComp : GetComponentsByTag(UHierarchicalInstancedStaticMeshComponent::StaticClass(), FName(TEXT("FortBattleWear"))))
	{
		if (UHierarchicalInstancedStaticMeshComponent* WearH = Cast<UHierarchicalInstancedStaticMeshComponent>(WearComp))
		{
			WearH->ClearInstances();
		}
	}

	for (AActor* Act : SpawnedElements)
	{
		if (IsValid(Act))
		{
			Act->Destroy();
		}
	}
	SpawnedElements.Empty();
}

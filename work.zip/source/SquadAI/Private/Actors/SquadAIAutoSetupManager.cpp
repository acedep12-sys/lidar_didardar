#include "Actors/SquadAIAutoSetupManager.h"

#include "Misc/Paths.h"        // S26-VIDEO: Content/Movies install targets
#include "HAL/FileManager.h"   // S26-VIDEO: MakeDirectory / Copy / FileSize

#include "Actors/SquadAIMainMenuSetupActor.h"
#include "Actors/SquadAIAudioManager.h"
#include "Actors/AmmoCrateActor.h"
#include "Actors/FirstAidKitActor.h"
#include "Actors/MedicalStationActor.h"
#include "Actors/MountedTurretActor.h"
#include "Actors/ExplosiveBarrelActor.h"
#include "Actors/QuickFortificationSpawnerActor.h"
#include "Actors/TacticalTrenchSplineActor.h"
#include "Quest/AtmosphericDustScatterer.h"
#include "Quest/SandstormWeatherDirector.h"
#include "Quest/SceneDecorator.h"
#include "Quest/MissionZone.h"
#include "Quest/EnemyWaveSpawner.h"
#include "Quest/QuestChain.h"
#include "BlueprintLibraries/SquadAIAutoSetupEditorLibrary.h"
#include "Quest/MissionTemplateAsset.h"   // S19-TEMPLATE
#include "Quest/GeneratorModel.h"          // S19-GEN
#include "BlueprintLibraries/SquadAIBlueprintAssetFactoryLibrary.h"
#include "SquadAIWeaponVisualPreset.h"
#include "Components/SquadAITPWCSVisualsComponent.h"
#include "Environment/DestroyedVillageCompoundActor.h"
#include "Environment/DestroyedBuildingActor.h"
#include "Characters/AllySoldier.h"
#include "Characters/EnemySoldier.h"
#include "Characters/LeaderCharacter.h"
#include "Engine/Blueprint.h"
#include "EngineUtils.h"
// F-C3: FXManager + Niagara are runtime-safe — BeginPlay wires FX defaults at game start,
// so these must NOT be editor-guarded (packaged builds failed: undeclared identifier).
#include "Performance/SquadAIFXManagerSubsystem.h"
#include "NiagaraSystem.h"
#if WITH_EDITOR
#include "UObject/UnrealType.h"
#include "Engine/SimpleConstructionScript.h"
#include "Engine/SCS_Node.h"
#include "Kismet2/KismetEditorUtilities.h"
#endif // F-C3: removed duplicate include (already included at top level).

namespace
{
    static bool GSquadAIVerboseDebugLogsEnabled = false;
    static bool GSquadAILogAI = false;
    static bool GSquadAILogCombat = false;
    static bool GSquadAILogBridge = false;
    static bool GSquadAILogAudio = false;
    static bool GSquadAILogQuest = false;
    static bool GSquadAILogCover = false;
}

ASquadAIAutoSetupManager::ASquadAIAutoSetupManager()
{
	// S19-MAP: the landscape checker's default grammar - crates are trenches, trees
	// are biomes, and anything water-named is the river. Edit these if your actors
	// are named differently.
	CrateTokens = USquadAIAutoSetupEditorLibrary::DefaultCrateTokens();
	TreeTokens = USquadAIAutoSetupEditorLibrary::DefaultTreeTokens();
	RiverTokens = USquadAIAutoSetupEditorLibrary::DefaultRiverTokens();
    PrimaryActorTick.bCanEverTick = false;
    bIsEditorOnlyActor = false;

    AlliesSpawnLocations.Add(FVector(-300.f, -250.f, 0.f));
    AlliesSpawnLocations.Add(FVector(-300.f, 250.f, 0.f));

    EncounterSpawnLocations.Add(FVector(1500.f, 0.f, 0.f));
    EncounterSpawnLocations.Add(FVector(3500.f, 1000.f, 0.f));
    EncounterSpawnLocations.Add(FVector(5500.f, -500.f, 0.f));
}

bool ASquadAIAutoSetupManager::AreVerboseDebugLogsEnabled()
{
    return GSquadAIVerboseDebugLogsEnabled;
}

void ASquadAIAutoSetupManager::SetVerboseDebugLogsEnabled(bool bEnabled)
{
    // B7-8: lets the ToggleDebugLogs cheat drive the real ShouldLog* gates.
    GSquadAIVerboseDebugLogsEnabled = bEnabled;
}

bool ASquadAIAutoSetupManager::ShouldLogAI()
{
    return GSquadAIVerboseDebugLogsEnabled || GSquadAILogAI;
}

bool ASquadAIAutoSetupManager::ShouldLogCombat()
{
    return GSquadAIVerboseDebugLogsEnabled || GSquadAILogCombat;
}

bool ASquadAIAutoSetupManager::ShouldLogBridge()
{
    return GSquadAIVerboseDebugLogsEnabled || GSquadAILogBridge;
}

bool ASquadAIAutoSetupManager::ShouldLogAudio()
{
    return GSquadAIVerboseDebugLogsEnabled || GSquadAILogAudio;
}

bool ASquadAIAutoSetupManager::ShouldLogQuest()
{
    return GSquadAIVerboseDebugLogsEnabled || GSquadAILogQuest;
}

bool ASquadAIAutoSetupManager::ShouldLogCover()
{
    return GSquadAIVerboseDebugLogsEnabled || GSquadAILogCover;
}

void ASquadAIAutoSetupManager::BeginPlay()
{
    Super::BeginPlay();
    GSquadAIVerboseDebugLogsEnabled = bEnableVerboseDebugLogs;
    GSquadAILogAI = bLogAIEvents;
    GSquadAILogCombat = bLogCombatEvents;
    GSquadAILogBridge = bLogBridgeEvents;
    GSquadAILogAudio = bLogAudioEvents;
    GSquadAILogQuest = bLogQuestEvents;
    GSquadAILogCover = bLogCoverEvents;

    if (USquadAIFXManagerSubsystem* FXSys = USquadAIFXManagerSubsystem::Get(this))
    {
        if (DefaultDirtExplosion) FXSys->NS_Dirt_Explosion = DefaultDirtExplosion;
        if (DefaultDirtExplosionMedium) FXSys->NS_Dirt_Explosion_Medium = DefaultDirtExplosionMedium;
        if (DefaultDirtExplosionSmall) FXSys->NS_Dirt_Explosion_Small = DefaultDirtExplosionSmall;
        if (DefaultExplosion) FXSys->NS_Explosion = DefaultExplosion;
        if (DefaultExplosionMedium) FXSys->NS_Explosion_Medium = DefaultExplosionMedium;
        if (DefaultExplosionSmall) FXSys->NS_Explosion_Small = DefaultExplosionSmall;
    }

    if (!bRunOnBeginPlay || bRunInEditorOnly || bSetupAlreadyCompleted)
    {
        return;
    }

#if WITH_EDITOR
    if (RunEditorAutoSetup())
    {
        bSetupAlreadyCompleted = true;
        if (bValidateAfterSetup)
        {
            RunEditorValidation();
        }
        DisableManagerIfNeeded();
    }
#else
    // S5-16: AutoSetup mutates levels/assets and is an editor-maintenance tool.
    // A level that flips bRunOnBeginPlay+bRunInEditorOnly must NOT run it in a
    // packaged game (FX wiring above stays runtime — only this block is gated).
    UE_LOG(LogTemp, Warning, TEXT("[AutoSetup] RunEditorAutoSetup requested at runtime — editor-only, skipped."));
#endif
}

// F-C4: whole definition is editor-only (matches the guarded declaration in the header).
#if WITH_EDITOR
void ASquadAIAutoSetupManager::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
    Super::PostEditChangeProperty(PropertyChangedEvent);

    const FName PropertyName = PropertyChangedEvent.GetPropertyName();

    GSquadAIVerboseDebugLogsEnabled = bEnableVerboseDebugLogs;
    GSquadAILogAI = bLogAIEvents;
    GSquadAILogCombat = bLogCombatEvents;
    GSquadAILogBridge = bLogBridgeEvents;
    GSquadAILogAudio = bLogAudioEvents;
    GSquadAILogQuest = bLogQuestEvents;
    GSquadAILogCover = bLogCoverEvents;

    if (PropertyName == GET_MEMBER_NAME_CHECKED(ASquadAIAutoSetupManager, bExecuteCreateLeaderBlueprint) && bExecuteCreateLeaderBlueprint)
    {
        CreateLeaderBlueprintAsset();
        bExecuteCreateLeaderBlueprint = false;
        LastSetupSummary = BuildSetupSummary();
    }
    else if (PropertyName == GET_MEMBER_NAME_CHECKED(ASquadAIAutoSetupManager, bExecuteCreateAllyBlueprint) && bExecuteCreateAllyBlueprint)
    {
        CreateAllyBlueprintAsset();
        bExecuteCreateAllyBlueprint = false;
        LastSetupSummary = BuildSetupSummary();
    }
    else if (PropertyName == GET_MEMBER_NAME_CHECKED(ASquadAIAutoSetupManager, bExecuteCreateEnemyBlueprint) && bExecuteCreateEnemyBlueprint)
    {
        CreateEnemyBlueprintAsset();
        bExecuteCreateEnemyBlueprint = false;
        LastSetupSummary = BuildSetupSummary();
    }
    else if (PropertyName == GET_MEMBER_NAME_CHECKED(ASquadAIAutoSetupManager, bExecuteRunEditorAutoSetup) && bExecuteRunEditorAutoSetup)
    {
        RunEditorAutoSetup();
        bExecuteRunEditorAutoSetup = false;
    }
    else if (PropertyName == GET_MEMBER_NAME_CHECKED(ASquadAIAutoSetupManager, bExecuteRunEditorValidation) && bExecuteRunEditorValidation)
    {
        RunEditorValidation();
        bExecuteRunEditorValidation = false;
    }
    else if (PropertyName == GET_MEMBER_NAME_CHECKED(ASquadAIAutoSetupManager, bExecuteAutoFixLevelAndMissions) && bExecuteAutoFixLevelAndMissions)
    {
        AutoFixLevelAndMissions();
        bExecuteAutoFixLevelAndMissions = false;
    }
    else if (PropertyName == GET_MEMBER_NAME_CHECKED(ASquadAIAutoSetupManager, bExecuteEnsureAtmosphereAndAudio) && bExecuteEnsureAtmosphereAndAudio)
    {
        EnsureAtmosphereAndAudio();
        bExecuteEnsureAtmosphereAndAudio = false;
    }
    else if (PropertyName == GET_MEMBER_NAME_CHECKED(ASquadAIAutoSetupManager, bExecuteAutoPopulateEncounters) && bExecuteAutoPopulateEncounters)
    {
        AutoPopulateEncounters();
        bExecuteAutoPopulateEncounters = false;
    }
    else if (PropertyName == GET_MEMBER_NAME_CHECKED(ASquadAIAutoSetupManager, bExecuteAutoBakeCoverNodes) && bExecuteAutoBakeCoverNodes)
    {
        AutoBakeCoverNodes();
        bExecuteAutoBakeCoverNodes = false;
    }
    else if (PropertyName == GET_MEMBER_NAME_CHECKED(ASquadAIAutoSetupManager, bExecuteSpawnDestroyedVillage) && bExecuteSpawnDestroyedVillage)
    {
        SpawnDestroyedVillage();
        bExecuteSpawnDestroyedVillage = false;
    }
    else if (PropertyName == GET_MEMBER_NAME_CHECKED(ASquadAIAutoSetupManager, bExecuteApplyGlobalPalette) && bExecuteApplyGlobalPalette)
    {
        ApplyGlobalPaletteToAllLevelAssets();
        bExecuteApplyGlobalPalette = false;
    }
    else if (PropertyName == GET_MEMBER_NAME_CHECKED(ASquadAIAutoSetupManager, bExecuteBuildSetupSummary) && bExecuteBuildSetupSummary)
    {
        BuildSetupSummary();
        bExecuteBuildSetupSummary = false;
    }
    // S19-TEMPLATE: the Details-panel build button (see BuildMissionFromTemplate below).
    else if (PropertyName == GET_MEMBER_NAME_CHECKED(ASquadAIAutoSetupManager, bExecuteBuildMissionFromTemplate) && bExecuteBuildMissionFromTemplate)
    {
        BuildMissionFromTemplate();
        bExecuteBuildMissionFromTemplate = false;
    }
    // S19-GEN: the seeded-generator button (see GenerateMissionFromSeed below).
    else if (PropertyName == GET_MEMBER_NAME_CHECKED(ASquadAIAutoSetupManager, bExecuteGenerateMissionFromSeed) && bExecuteGenerateMissionFromSeed)
    {
        GenerateMissionFromSeed();
        bExecuteGenerateMissionFromSeed = false;
    }
    // S19-MAP: the landscape checker and the automatic mission putter.
    else if (PropertyName == GET_MEMBER_NAME_CHECKED(ASquadAIAutoSetupManager, bExecuteAnalyzeMapLayout) && bExecuteAnalyzeMapLayout)
    {
        AnalyzeMapLayout();
        bExecuteAnalyzeMapLayout = false;
    }
    else if (PropertyName == GET_MEMBER_NAME_CHECKED(ASquadAIAutoSetupManager, bExecuteAutoScatterMissions) && bExecuteAutoScatterMissions)
    {
        AutoScatterMissions();
        bExecuteAutoScatterMissions = false;
    }
}
#endif // WITH_EDITOR // F-C4: dropped #else branch (PostEditChangeProperty does not exist in game builds).

bool ASquadAIAutoSetupManager::RunEditorAutoSetup()
{
    FString FullLog;
    FullLog += TEXT("====================================================\n");
    FullLog += TEXT("🎯 SQUADAI 1-CLICK LEVEL AUTO-SETUP INITIATED\n");
    FullLog += TEXT("====================================================\n\n");

    UE_LOG(LogTemp, Warning, TEXT("[SquadAIAutoSetupManager] Running 1-Click Level Auto Setup..."));

    // 1. Ensure Essential Environment & Audio Actors
    const FString AudioLog = EnsureAtmosphereAndAudio();
    FullLog += AudioLog + TEXT("\n");

    // 2. Auto-Fix & Connect Mission Zones, Quest Chains & Spawners
    const FString MissionLog = AutoFixLevelAndMissions();
    FullLog += MissionLog + TEXT("\n");

    // 3. Propagate Global Material & Mesh Palette to All Assets
    const FString PaletteLog = ApplyGlobalPaletteToAllLevelAssets();
    FullLog += PaletteLog + TEXT("\n");

    // 4. Auto-Bake Tactical Cover Nodes Across Level
    const FString CoverLog = AutoBakeCoverNodes();
    FullLog += CoverLog + TEXT("\n");

    // 4. Configure Squad Leader & Allies if present
    AActor* Leader = ResolveLeader();
    const TArray<AActor*> Allies = ResolveAllies();

    if (Leader)
    {
        const bool bSuccess = USquadAIAutoSetupEditorLibrary::AutoSetupLeaderTeamInEditor(Leader, Allies);
        if (bSuccess)
        {
            FullLog += FString::Printf(TEXT("✅ SQUAD CONFIGURED: Leader '%s' wired with %d Ally soldier(s).\n"), *Leader->GetName(), Allies.Num());
            UE_LOG(LogTemp, Warning, TEXT("[SquadAIAutoSetupManager] Successfully configured Leader '%s' and %d Allies."), *Leader->GetName(), Allies.Num());
        }
        else
        {
            FullLog += FString::Printf(TEXT("⚠️ SQUAD PARTIAL: Leader '%s' found but ally setup returned warnings.\n"), *Leader->GetName());
        }
    }
    else
    {
        FullLog += TEXT("ℹ️ SQUAD NOTICE: No Leader placed in level yet.\n(Level atmosphere, audio, missions, and cover are 100% configured! To add your squad, place BP_Leader into the level or click 'Create Leader Blueprint').\n");
        UE_LOG(LogTemp, Warning, TEXT("[SquadAIAutoSetupManager] Level systems ready. To add squad: place BP_Leader or click 'Create Leader Blueprint'."));
    }

    // 5. Build Summary & Run Validation
    bSetupAlreadyCompleted = true;
    RunEditorValidation();

    FullLog += TEXT("\n") + LastSetupSummary;
    LastSetupSummary = FullLog;

    UE_LOG(LogTemp, Warning, TEXT("%s"), *FullLog);

    return true;
}

bool ASquadAIAutoSetupManager::RunEditorValidation()
{
    const FString Prefix = TEXT("[SquadAIAutoSetupManager]");
    bool bAllPassed = true;
    FString ValidationSummary = Prefix + TEXT(" Validation Results\n");

    if (AActor* Leader = ResolveLeader())
    {
        const bool bLeaderPassed = USquadAIAutoSetupEditorLibrary::ValidateActorForPackSetup(Leader);
        bAllPassed &= bLeaderPassed;
        ValidationSummary += FString::Printf(TEXT("Leader %s: %s\n"), *Leader->GetName(), bLeaderPassed ? TEXT("PASS") : TEXT("FAIL"));
    }
    else
    {
        ValidationSummary += TEXT("Leader: NOT IN LEVEL (Optional: click Create Leader Blueprint)\n");
    }

    const TArray<AActor*> Allies = ResolveAllies();
    for (AActor* Ally : Allies)
    {
        const bool bAllyPassed = USquadAIAutoSetupEditorLibrary::ValidateActorForPackSetup(Ally);
        bAllPassed &= bAllyPassed;
        ValidationSummary += FString::Printf(TEXT("Ally %s: %s\n"), *GetNameSafe(Ally), bAllyPassed ? TEXT("PASS") : TEXT("FAIL"));
    }

    const TArray<AActor*> Enemies = ResolveEnemies();
    for (AActor* Enemy : Enemies)
    {
        const bool bEnemyPassed = USquadAIAutoSetupEditorLibrary::ValidateActorForPackSetup(Enemy);
        bAllPassed &= bEnemyPassed;
        ValidationSummary += FString::Printf(TEXT("Enemy %s: %s\n"), *GetNameSafe(Enemy), bEnemyPassed ? TEXT("PASS") : TEXT("FAIL"));
    }

    ValidationSummary += FString::Printf(TEXT("Overall Status: %s\n"), bAllPassed ? TEXT("READY") : TEXT("NEEDS_SETUP"));
    LastSetupSummary = ValidationSummary + BuildSetupSummary();

    UE_LOG(LogTemp, Warning, TEXT("%s %s"), *Prefix, bAllPassed ? TEXT("Validation passed.") : TEXT("Validation ready with notices."));

    return bAllPassed;
}

FString ASquadAIAutoSetupManager::AutoFixLevelAndMissions()
{
    if (!GetWorld()) return TEXT("ERROR: World is NULL");
    const FString Result = USquadAIAutoSetupEditorLibrary::AutoFixAndWireLevelMissions(GetWorld());
    LastSetupSummary = Result;
    UE_LOG(LogTemp, Warning, TEXT("%s"), *Result);
    return Result;
}

FString ASquadAIAutoSetupManager::EnsureAtmosphereAndAudio()
{
    if (!GetWorld()) return TEXT("ERROR: World is NULL");
    const FString Result = USquadAIAutoSetupEditorLibrary::EnsureEssentialEnvironmentActors(GetWorld());
    LastSetupSummary = Result;
    UE_LOG(LogTemp, Warning, TEXT("%s"), *Result);
    return Result;
}

// S19-GEN: write the generator's brief into a template asset. Field-by-field on
// purpose - no reflection, no hidden coupling; the generator guarantees the factory's
// validator will pass (escort legs >= 3, par < limit, Defend never escorts).
static void ApplyGeneratedFacts(UMissionTemplateAsset* T, const FMissionTemplateFacts& F,
    uint32 Seed, int32 Tier)
{
    const FString Title = FString::Printf(TEXT("Generated mission (seed %u, tier %d)"), Seed, Tier);
    T->MissionName = FText::FromString(Title);
    T->MissionDescription = FText::FromString(FString::Printf(TEXT("%s operation, difficulty %d"),
        FMissionGeneratorModel::TypeName(F.TypeReachClearDefend), Tier));
    T->CustomBadgeText = FText::FromString(FMissionGeneratorModel::TypeName(F.TypeReachClearDefend));

    switch (F.TypeReachClearDefend)
    {
    case 1:  T->MissionType = EMissionType::Reach;  break;
    case 3:  T->MissionType = EMissionType::Defend; break;
    default: T->MissionType = EMissionType::Clear;  break;
    }
    T->bLoopWaves = (T->MissionType == EMissionType::Defend);

    T->TotalWaves = F.TotalWaves;
    T->EnemiesPerWave = F.EnemiesPerWave;
    T->bEliteCommander = F.bCommander;
    T->AssistantsPerCommander = 2;

    T->bEscort = F.bEscort;
    T->EscortRouteLegs = F.EscortRouteLegs;
    T->EscortRouteLegLengthCm = F.EscortRouteLegLengthCm;
    T->bRequireEscortArrival = true;
    T->bFailIfEscortDies = true;

    T->IntelSiteCount = F.IntelSiteCount;
    T->SupplyCrateCount = F.SupplyCrateCount;
    T->SabotageTargetCount = F.SabotageTargetCount;
    T->POWCaptiveCount = 0;                    // captives need a class only the project knows
    T->bExtraction = F.bExtraction;
    T->bRequireExtraction = F.bRequireExtraction;

    T->TimeLimitSeconds = F.TimeLimitSeconds;
    T->ParTimeSeconds = F.ParTimeSeconds;

    T->PropRingRadiusCm = F.PropRingRadiusCm;
    T->bSpawnFortification = F.bFortify;
    T->ExplosiveBarrels = F.ExplosiveBarrels;

    T->CapturePointCount = F.CapturePointCount;         // S19-CAP
    T->CaptureHoldSeconds = F.CaptureHoldSeconds;
    T->bDefendedAsset = F.bDefendedAsset;               // S19-ASSET
    T->bInterdiction = F.bInterdiction;                 // S19-INTERDICT
    T->InterdictionCourierCount = F.InterdictionCourierCount;
    T->InterdictionStopQuota = F.InterdictionStopQuota;
}

// S19-MAP: read the map (crates = trenches, trees = biomes, the river line).
FString ASquadAIAutoSetupManager::AnalyzeMapLayout()
{
    if (!GetWorld()) return TEXT("ERROR: World is NULL");
    const FString Result = USquadAIAutoSetupEditorLibrary::AnalyzeLandscapeLayout(
        GetWorld(), CrateTokens, TreeTokens, RiverTokens);
    LastSetupSummary = Result;
    return Result;
}

// S19-MAP: the automatic mission putter - read, plan, draw the map, stamp.
FString ASquadAIAutoSetupManager::AutoScatterMissions()
{
    if (!GetWorld()) return TEXT("ERROR: World is NULL");
    const FString Result = USquadAIAutoSetupEditorLibrary::AutoScatterMissionsFromLandscape(
        GetWorld(), ScatterMissionCount, ScatterMinSeparationCm, bScatterDryRun,
        CrateTokens, TreeTokens, RiverTokens, /*bAppendToQuestChain=*/true,
        ScatterCampaignSpreadKm);
    LastSetupSummary = Result;
    return Result;
}

// S19-GEN: one seed + one tier = one mission, reproducibly.
FString ASquadAIAutoSetupManager::GenerateMissionFromSeed()
{
    if (!GetWorld()) return TEXT("ERROR: World is NULL");

    const uint32 Seed = static_cast<uint32>(GeneratorSeed);
    const FMissionTemplateFacts Facts = FMissionGeneratorModel::BuildTemplateFacts(Seed, GeneratorDifficultyTier);

    UMissionTemplateAsset* Generated = NewObject<UMissionTemplateAsset>(
        GetTransientPackage(), NAME_None, RF_Transient);
    if (!Generated)
    {
        return TEXT("ERROR: could not create the generated template object.");
    }
    ApplyGeneratedFacts(Generated, Facts, Seed, GeneratorDifficultyTier);

    const FVector Origin = bBuildMissionInFrontOfActor
        ? (GetActorLocation() + GetActorForwardVector() * FMath::Max(0.f, MissionBuildDistanceCm))
        : MissionBuildLocation;

    UE_LOG(LogTemp, Warning, TEXT("[SquadAIGenerator] Seed %u, tier %d -> %s, %d wave(s) x %d%s."),
        Seed, GeneratorDifficultyTier, FMissionGeneratorModel::TypeName(Facts.TypeReachClearDefend),
        Facts.TotalWaves, Facts.EnemiesPerWave, Facts.bCommander ? TEXT(", commander") : TEXT(""));

    return USquadAIAutoSetupEditorLibrary::BuildMissionFromTemplate(
        GetWorld(), Generated, Origin, GetActorRotation(), /*bAppendToQuestChain=*/true);
}

// S19-TEMPLATE: stamp the chosen template into the level - one asset, one complete mission.
FString ASquadAIAutoSetupManager::BuildMissionFromTemplate()
{
    if (!GetWorld()) return TEXT("ERROR: World is NULL");
    if (!MissionTemplateToBuild)
    {
        return TEXT("ERROR: no Mission Template selected (SquadAI|Mission Factory -> Mission Template To Build).");
    }

    const FVector Origin = bBuildMissionInFrontOfActor
        ? (GetActorLocation() + GetActorForwardVector() * FMath::Max(0.f, MissionBuildDistanceCm))
        : MissionBuildLocation;

    // The template's own settings decide the rest; the factory validates first and
    // refuses to build a template that cannot work (see its report for the reasons).
    const FString Result = USquadAIAutoSetupEditorLibrary::BuildMissionFromTemplate(
        GetWorld(), MissionTemplateToBuild, Origin, GetActorRotation(), /*bAppendToQuestChain=*/true);
    LastSetupSummary = Result;
    UE_LOG(LogTemp, Warning, TEXT("%s"), *Result);
    return Result;
}

FString ASquadAIAutoSetupManager::AutoPopulateEncounters()
{
    if (!GetWorld()) return TEXT("ERROR: World is NULL");
    const FString Result = USquadAIAutoSetupEditorLibrary::AutoPopulateLevelWithEncounterZones(GetWorld());
    LastSetupSummary = Result;
    UE_LOG(LogTemp, Warning, TEXT("%s"), *Result);
    return Result;
}

FString ASquadAIAutoSetupManager::AutoBakeCoverNodes()
{
    if (!GetWorld()) return TEXT("ERROR: World is NULL");
    const FString Result = USquadAIAutoSetupEditorLibrary::AutoBakeCoverNodesAcrossMap(GetWorld());
    LastSetupSummary = Result;
    UE_LOG(LogTemp, Warning, TEXT("%s"), *Result);
    return Result;
}

FString ASquadAIAutoSetupManager::DeleteScatteredContent()
{
    // S26-DELBTN: the manager's own delete button. Runs the library teardown
    // a re-press performs, so the two can never disagree about what belongs
    // to the scatter. Tag-based: hand-placed towers, forts and missions stay.
    UWorld* World = GetWorld();
    if (!World)
    {
        return TEXT("no world");
    }
    const FString Report = USquadAIAutoSetupEditorLibrary::DeleteScatteredContent(
        World, bDeleteAlsoStampedMissions, /*bRepressWording=*/false);
    UE_LOG(LogTemp, Log, TEXT("[SquadAI] Manager delete: %s"), *Report);
    return Report;
}

FString ASquadAIAutoSetupManager::SpawnDestroyedVillage()
{
    if (!GetWorld()) return TEXT("ERROR: World is NULL");
    const FVector SpawnLoc = GetActorLocation() + GetActorForwardVector() * 1500.f;
    const FString Result = USquadAIAutoSetupEditorLibrary::AutoSpawnDestroyedVillageInLevel(GetWorld(), SpawnLoc, 5);
    LastSetupSummary = Result;
    UE_LOG(LogTemp, Warning, TEXT("%s"), *Result);
    return Result;
}

FString ASquadAIAutoSetupManager::ApplyGlobalPaletteToAllLevelAssets()
{
    UWorld* World = GetWorld();
    if (!World) return TEXT("ERROR: World is NULL");

    int32 VillageCount = 0;
    int32 BuildingCount = 0;
    int32 FortCount = 0;
    int32 AmmoCount = 0;
    int32 KitCount = 0;
    int32 BarrelCount = 0;
    int32 TurretCount = 0;

    // 1. Village Compounds
    for (TActorIterator<ADestroyedVillageCompoundActor> It(World); It; ++It)
    {
        ADestroyedVillageCompoundActor* V = *It;
        if (!V) continue;

        if (GlobalWallMaterial) V->VillageWallMaterial = GlobalWallMaterial;
        if (GlobalFloorMaterial) V->VillageFloorMaterial = GlobalFloorMaterial;
        if (GlobalWoodMaterial) V->VillageWoodMaterial = GlobalWoodMaterial;
        if (GlobalSandbagMaterial) V->VillageSandbagMaterial = GlobalSandbagMaterial;
        if (GlobalRubbleMaterial) V->VillageRubbleMaterial = GlobalRubbleMaterial;

        if (GlobalWallMesh) V->CustomVillageWallMesh = GlobalWallMesh;
        if (GlobalSandbagMesh) V->CustomVillageSandbagMesh = GlobalSandbagMesh;
        if (GlobalWoodBeamMesh) V->CustomVillageWoodMesh = GlobalWoodBeamMesh;
        if (GlobalRubbleMesh) V->CustomVillageRubbleMesh = GlobalRubbleMesh;

        V->BuildVillage();
        VillageCount++;
    }

    // 2. Standalone Destroyed Buildings
    for (TActorIterator<ADestroyedBuildingActor> It(World); It; ++It)
    {
        ADestroyedBuildingActor* B = *It;
        if (!B) continue;

        if (GlobalWallMaterial) B->WallMaterialOverride = GlobalWallMaterial;
        if (GlobalFloorMaterial) B->FloorMaterialOverride = GlobalFloorMaterial;
        if (GlobalWoodMaterial) B->WoodMaterialOverride = GlobalWoodMaterial;
        if (GlobalSandbagMaterial) B->SandbagMaterialOverride = GlobalSandbagMaterial;
        if (GlobalMetalMaterial) B->MetalMaterialOverride = GlobalMetalMaterial;
        if (GlobalRubbleMaterial) B->RubbleMaterialOverride = GlobalRubbleMaterial;

        if (GlobalWallMesh) B->CustomWallMesh = GlobalWallMesh;
        if (GlobalSandbagMesh) B->CustomSandbagMesh = GlobalSandbagMesh;
        if (GlobalWoodBeamMesh) B->CustomWoodBeamMesh = GlobalWoodBeamMesh;
        if (GlobalRubbleMesh) B->CustomRubbleMesh = GlobalRubbleMesh;

        B->BuildBuilding();
        BuildingCount++;
    }

    // 3. Quick Fortification Spawners
    for (TActorIterator<AQuickFortificationSpawnerActor> It(World); It; ++It)
    {
        AQuickFortificationSpawnerActor* F = *It;
        if (!F) continue;

        if (GlobalSandbagMaterial) F->SandbagMaterialOverride = GlobalSandbagMaterial;
        if (GlobalSandbagMesh) F->CustomSandbagMesh = GlobalSandbagMesh;

        F->BuildFortification();
        FortCount++;
    }

    // 3b. Tactical Trench Splines
    for (TActorIterator<ATacticalTrenchSplineActor> It(World); It; ++It)
    {
        ATacticalTrenchSplineActor* Trench = *It;
        if (!Trench) continue;

        if (GlobalSandbagMaterial) Trench->SandbagMaterialOverride = GlobalSandbagMaterial;
        if (GlobalSandbagMesh) Trench->CustomSandbagMesh = GlobalSandbagMesh;

        Trench->BuildTrench();
    }

    // 4. Ammo Crates
    for (TActorIterator<AAmmoCrateActor> It(World); It; ++It)
    {
        AAmmoCrateActor* C = *It;
        if (!C) continue;

        if (GlobalAmmoCrateMesh) C->CustomCrateMesh = GlobalAmmoCrateMesh;
        if (GlobalAmmoCrateMaterial) C->CrateMaterialOverride = GlobalAmmoCrateMaterial;

        C->ApplyCustomVisuals();
        AmmoCount++;
    }

    // 5. First Aid Kits
    for (TActorIterator<AFirstAidKitActor> It(World); It; ++It)
    {
        AFirstAidKitActor* K = *It;
        if (!K) continue;

        if (GlobalFirstAidMesh) K->CustomKitMesh = GlobalFirstAidMesh;
        if (GlobalFirstAidMaterial) K->KitMaterialOverride = GlobalFirstAidMaterial;

        K->ApplyCustomVisuals();
        KitCount++;
    }

    // 6. Explosive Barrels
    for (TActorIterator<AExplosiveBarrelActor> It(World); It; ++It)
    {
        AExplosiveBarrelActor* B = *It;
        if (!B) continue;

        if (GlobalBarrelMesh) B->CustomBarrelMesh = GlobalBarrelMesh;
        if (GlobalBarrelMaterial) B->BarrelMaterialOverride = GlobalBarrelMaterial;

        B->ApplyCustomVisuals();
        BarrelCount++;
    }

    // 7. Mounted Turrets
    for (TActorIterator<AMountedTurretActor> It(World); It; ++It)
    {
        AMountedTurretActor* T = *It;
        if (!T) continue;

        if (GlobalTurretBaseMesh) T->CustomBaseMesh = GlobalTurretBaseMesh;
        if (GlobalTurretGunMesh) T->CustomGunMesh = GlobalTurretGunMesh;
        if (GlobalSandbagMaterial) T->BaseMaterialOverride = GlobalSandbagMaterial;
        if (GlobalMetalMaterial) T->GunMaterialOverride = GlobalMetalMaterial;

        T->ApplyCustomVisuals();
        TurretCount++;
    }

    const FString Summary = FString::Printf(
        TEXT("🎨 Global Palette Applied: %d Villages, %d Buildings, %d Forts, %d Ammo Crates, %d Med Kits, %d Barrels, %d Turrets reskinned!"),
        VillageCount, BuildingCount, FortCount, AmmoCount, KitCount, BarrelCount, TurretCount);

    LastSetupSummary = Summary;
    UE_LOG(LogTemp, Warning, TEXT("%s"), *Summary);
    return Summary;
}

FString ASquadAIAutoSetupManager::MoveVillageToTargetLocation()
{
    UWorld* World = GetWorld();
    if (!World) return TEXT("ERROR: World is NULL");

    FVector TargetLoc = GetActorLocation() + GetActorRotation().RotateVector(VillageSpawnLocation);

    // High-altitude terrain raycast
    FHitResult Hit;
    FCollisionQueryParams TraceParams;
    TraceParams.AddIgnoredActor(this);
    if (World->LineTraceSingleByChannel(Hit, TargetLoc + FVector(0.f, 0.f, 20000.f), TargetLoc - FVector(0.f, 0.f, 50000.f), ECC_Visibility, TraceParams))
    {
        TargetLoc = Hit.ImpactPoint + FVector(0.f, 0.f, 10.f);
    }

    ADestroyedVillageCompoundActor* ExistingVillage = nullptr;
    for (TActorIterator<ADestroyedVillageCompoundActor> It(World); It; ++It)
    {
        ExistingVillage = *It;
        break;
    }

    if (ExistingVillage)
    {
        ExistingVillage->SetActorLocation(TargetLoc);
        ExistingVillage->BuildVillage();
        const FString Log = FString::Printf(TEXT("✅ Successfully moved Destroyed Village to %s and rebuilt compound!"), *TargetLoc.ToString());
        LastSetupSummary = Log;
        UE_LOG(LogTemp, Warning, TEXT("%s"), *Log);
        return Log;
    }
    else
    {
        const FString Result = USquadAIAutoSetupEditorLibrary::AutoSpawnDestroyedVillageInLevel(World, TargetLoc, 5);
        LastSetupSummary = Result;
        UE_LOG(LogTemp, Warning, TEXT("%s"), *Result);
        return Result;
    }
}

FString ASquadAIAutoSetupManager::MoveSquadToTargetLocations()
{
    UWorld* World = GetWorld();
    if (!World) return TEXT("ERROR: World is NULL");

    FString Log;
    Log += TEXT("=== RELOCATING SQUAD TO TARGET LOCATIONS ===\n");

    AActor* Leader = ResolveLeader();
    if (Leader)
    {
        FVector LeaderTarget = GetActorLocation() + GetActorRotation().RotateVector(LeaderSpawnLocation);
        FHitResult Hit;
        FCollisionQueryParams Params;
        if (World->LineTraceSingleByChannel(Hit, LeaderTarget + FVector(0.f, 0.f, 10000.f), LeaderTarget - FVector(0.f, 0.f, 50000.f), ECC_Visibility, Params))
        {
            LeaderTarget = Hit.ImpactPoint + FVector(0.f, 0.f, 60.f);
        }
        Leader->SetActorLocation(LeaderTarget);
        Log += FString::Printf(TEXT(" • Moved Leader '%s' to %s\n"), *Leader->GetName(), *LeaderTarget.ToString());
    }

    const TArray<AActor*> Allies = ResolveAllies();
    for (int32 i = 0; i < Allies.Num(); ++i)
    {
        AActor* Ally = Allies[i];
        if (!Ally) continue;

        const FVector Offset = (i < AlliesSpawnLocations.Num()) ? AlliesSpawnLocations[i] : FVector(-300.f, (i % 2 == 0 ? 1 : -1) * 250.f * ((i / 2) + 1), 0.f);
        FVector AllyTarget = GetActorLocation() + GetActorRotation().RotateVector(Offset);
        FHitResult Hit;
        FCollisionQueryParams Params;
        if (World->LineTraceSingleByChannel(Hit, AllyTarget + FVector(0.f, 0.f, 10000.f), AllyTarget - FVector(0.f, 0.f, 50000.f), ECC_Visibility, Params))
        {
            AllyTarget = Hit.ImpactPoint + FVector(0.f, 0.f, 60.f);
        }
        Ally->SetActorLocation(AllyTarget);
        Log += FString::Printf(TEXT(" • Moved Ally [%d] '%s' to %s\n"), i, *Ally->GetName(), *AllyTarget.ToString());
    }

    if (Leader)
    {
        USquadAIAutoSetupEditorLibrary::AutoSetupLeaderTeamInEditor(Leader, Allies);
    }

    Log += TEXT("=== SQUAD RELOCATION COMPLETED ===\n");
    LastSetupSummary = Log;
    UE_LOG(LogTemp, Warning, TEXT("%s"), *Log);
    return Log;
}

FString ASquadAIAutoSetupManager::MoveEncountersToTargetLocations()
{
    UWorld* World = GetWorld();
    if (!World) return TEXT("ERROR: World is NULL");

    FString Log;
    Log += TEXT("=== RELOCATING MISSION ENCOUNTERS ===\n");

    TArray<AMissionZone*> Missions;
    for (TActorIterator<AMissionZone> It(World); It; ++It)
    {
        Missions.Add(*It);
    }
    Missions.Sort([](const AMissionZone& A, const AMissionZone& B) { return A.MissionIndex < B.MissionIndex; });

    for (int32 i = 0; i < Missions.Num(); ++i)
    {
        AMissionZone* MZ = Missions[i];
        if (!MZ) continue;

        const FVector Offset = (i < EncounterSpawnLocations.Num()) ? EncounterSpawnLocations[i] : FVector(1500.f * (i + 1), 0.f, 0.f);
        FVector TargetLoc = GetActorLocation() + GetActorRotation().RotateVector(Offset);

        FHitResult Hit;
        FCollisionQueryParams Params;
        if (World->LineTraceSingleByChannel(Hit, TargetLoc + FVector(0.f, 0.f, 15000.f), TargetLoc - FVector(0.f, 0.f, 50000.f), ECC_Visibility, Params))
        {
            TargetLoc = Hit.ImpactPoint + FVector(0.f, 0.f, 10.f);
        }

        MZ->SetActorLocation(TargetLoc);
        Log += FString::Printf(TEXT(" • Moved MissionZone [%d] '%s' to %s\n"), i, *MZ->GetName(), *TargetLoc.ToString());

        // Move linked spawners nearby
        for (AEnemyWaveSpawner* Spawner : MZ->LinkedSpawners)
        {
            if (Spawner)
            {
                Spawner->SetActorLocation(TargetLoc + FVector(FMath::FRandRange(200.f, 500.f), FMath::FRandRange(-300.f, 300.f), 10.f));
            }
        }
    }

    Log += TEXT("=== ENCOUNTER RELOCATION COMPLETED ===\n");
    LastSetupSummary = Log;
    UE_LOG(LogTemp, Warning, TEXT("%s"), *Log);
    return Log;
}

FString ASquadAIAutoSetupManager::MoveLogisticsToTargetLocation()
{
    UWorld* World = GetWorld();
    if (!World) return TEXT("ERROR: World is NULL");

    FVector BaseLoc = GetActorLocation() + GetActorRotation().RotateVector(LogisticsSpawnLocation);
    FHitResult Hit;
    FCollisionQueryParams Params;
    if (World->LineTraceSingleByChannel(Hit, BaseLoc + FVector(0.f, 0.f, 10000.f), BaseLoc - FVector(0.f, 0.f, 50000.f), ECC_Visibility, Params))
    {
        BaseLoc = Hit.ImpactPoint + FVector(0.f, 0.f, 10.f);
    }

    FString Log;
    Log += TEXT("=== RELOCATING LOGISTICS CACHES ===\n");

    for (TActorIterator<AAmmoCrateActor> It(World); It; ++It)
    {
        It->SetActorLocation(BaseLoc + FVector(100.f, 120.f, 0.f));
        Log += FString::Printf(TEXT(" • Moved Ammo Crate to %s\n"), *It->GetActorLocation().ToString());
        break;
    }

    for (TActorIterator<AFirstAidKitActor> It(World); It; ++It)
    {
        It->SetActorLocation(BaseLoc + FVector(100.f, -120.f, 0.f));
        Log += FString::Printf(TEXT(" • Moved First Aid Kit to %s\n"), *It->GetActorLocation().ToString());
        break;
    }

    for (TActorIterator<AMountedTurretActor> It(World); It; ++It)
    {
        It->SetActorLocation(BaseLoc + FVector(300.f, 0.f, 0.f));
        Log += FString::Printf(TEXT(" • Moved Mounted Turret to %s\n"), *It->GetActorLocation().ToString());
        break;
    }

    LastSetupSummary = Log;
    UE_LOG(LogTemp, Warning, TEXT("%s"), *Log);
    return Log;
}

FString ASquadAIAutoSetupManager::SnapAllSpawnedAssetsToGround()
{
    UWorld* World = GetWorld();
    if (!World) return TEXT("ERROR: World is NULL");

    int32 SnappedCount = 0;
    FString Log;
    Log += TEXT("=== SNAPPING ALL SPAWNED ASSETS TO GROUND ===\n");

    auto SnapActor = [&](AActor* Act, float ZOffset = 10.f)
    {
        if (!Act) return;
        FHitResult Hit;
        FCollisionQueryParams Params;
        Params.AddIgnoredActor(Act);
        const FVector Loc = Act->GetActorLocation();
        if (World->LineTraceSingleByChannel(Hit, Loc + FVector(0.f, 0.f, 15000.f), Loc - FVector(0.f, 0.f, 50000.f), ECC_Visibility, Params))
        {
            Act->SetActorLocation(Hit.ImpactPoint + FVector(0.f, 0.f, ZOffset));
            SnappedCount++;
        }
    };

    for (TActorIterator<ADestroyedVillageCompoundActor> It(World); It; ++It)
    {
        It->SnapVillageToGround();
        SnappedCount++;
    }

    for (TActorIterator<AAmmoCrateActor> It(World); It; ++It) SnapActor(*It, 10.f);
    for (TActorIterator<AFirstAidKitActor> It(World); It; ++It) SnapActor(*It, 10.f);
    for (TActorIterator<AMountedTurretActor> It(World); It; ++It) SnapActor(*It, 10.f);
    for (TActorIterator<AExplosiveBarrelActor> It(World); It; ++It) SnapActor(*It, 10.f);
    for (TActorIterator<AMissionZone> It(World); It; ++It) SnapActor(*It, 10.f);

    Log += FString::Printf(TEXT("Successfully snapped %d level actors to terrain surface!\n"), SnappedCount);
    LastSetupSummary = Log;
    UE_LOG(LogTemp, Warning, TEXT("%s"), *Log);
    return Log;
}

#if WITH_EDITOR
static void AssignWeaponPresetToBlueprint(UBlueprint* Blueprint, FName WeaponID, const FString& PackagePath)
{
    if (!Blueprint || !Blueprint->GeneratedClass || WeaponID.IsNone()) return;

    USquadAIWeaponVisualPreset* Preset = USquadAIBlueprintAssetFactoryLibrary::CreateOrFindWeaponVisualPreset(WeaponID, PackagePath);
    if (!Preset)
    {
        UE_LOG(LogTemp, Warning, TEXT("[SquadAIFactory] Could not create weapon preset for '%s'"), *WeaponID.ToString());
        return;
    }

    AActor* CDO = Cast<AActor>(Blueprint->GeneratedClass->GetDefaultObject());
    if (CDO)
    {
        USquadAITPWCSVisualsComponent* VisualsComp = CDO->FindComponentByClass<USquadAITPWCSVisualsComponent>();
        if (VisualsComp)
        {
            VisualsComp->Modify();
            VisualsComp->WeaponPreset = Preset;
            VisualsComp->WeaponID = WeaponID;
            Blueprint->MarkPackageDirty();
            UE_LOG(LogTemp, Warning, TEXT("[SquadAIFactory] Assigned weapon preset '%s' to %s (via CDO)"), *Preset->GetName(), *Blueprint->GetName());
            return;
        }
    }

#if WITH_EDITOR
    if (Blueprint->SimpleConstructionScript)
    {
        for (USCS_Node* Node : Blueprint->SimpleConstructionScript->GetAllNodes())
        {
            if (Node && Node->ComponentTemplate && Node->ComponentTemplate->IsA<USquadAITPWCSVisualsComponent>())
            {
                USquadAITPWCSVisualsComponent* Template = Cast<USquadAITPWCSVisualsComponent>(Node->ComponentTemplate);
                Template->Modify();
                Template->WeaponPreset = Preset;
                Template->WeaponID = WeaponID;
                Blueprint->MarkPackageDirty();
                UE_LOG(LogTemp, Warning, TEXT("[SquadAIFactory] Assigned weapon preset '%s' to %s (via SCS template)"), *Preset->GetName(), *Blueprint->GetName());

                FKismetEditorUtilities::CompileBlueprint(Blueprint);
                return;
            }
        }
    }
#endif

    UE_LOG(LogTemp, Warning, TEXT("[SquadAIFactory] No SquadAITPWCSVisuals component found on %s — neither on CDO nor SCS. Open the BP and add it manually."), *Blueprint->GetName());
}

UBlueprint* ASquadAIAutoSetupManager::CreateLeaderBlueprintAsset()
{
    UBlueprint* Result = nullptr;
    if (bCreateBlueprintsFromPackTemplates)
    {
        Result = USquadAIBlueprintAssetFactoryLibrary::DuplicatePackTemplateAsLeaderBlueprintAsset(LeaderPackTemplateAssetName, AssetPackagePath, LeaderAssetName);
    }
    if (!Result)
    {
        Result = USquadAIBlueprintAssetFactoryLibrary::CreateLeaderPackBlueprintAsset(AssetPackagePath, LeaderAssetName);
    }
    if (Result) AssignWeaponPresetToBlueprint(Result, LeaderWeaponID, AssetPackagePath);
    return Result;
}

UBlueprint* ASquadAIAutoSetupManager::CreateAllyBlueprintAsset()
{
    UBlueprint* Result = nullptr;
    if (bCreateBlueprintsFromPackTemplates)
    {
        Result = USquadAIBlueprintAssetFactoryLibrary::DuplicatePackTemplateAsAllyBlueprintAsset(AllyPackTemplateAssetName, AssetPackagePath, AllyAssetName);
    }
    if (!Result)
    {
        Result = USquadAIBlueprintAssetFactoryLibrary::CreateAllyPackBlueprintAsset(AssetPackagePath, AllyAssetName);
    }
    if (Result) AssignWeaponPresetToBlueprint(Result, AllyWeaponID, AssetPackagePath);
    return Result;
}

UBlueprint* ASquadAIAutoSetupManager::CreateEnemyBlueprintAsset()
{
    UBlueprint* Result = nullptr;
    if (bCreateBlueprintsFromPackTemplates)
    {
        Result = USquadAIBlueprintAssetFactoryLibrary::DuplicatePackTemplateAsEnemyBlueprintAsset(EnemyPackTemplateAssetName, AssetPackagePath, EnemyAssetName);
    }
    if (!Result)
    {
        Result = USquadAIBlueprintAssetFactoryLibrary::CreateEnemyPackBlueprintAsset(AssetPackagePath, EnemyAssetName);
    }
    if (Result) AssignWeaponPresetToBlueprint(Result, EnemyWeaponID, AssetPackagePath);
    return Result;
}
#endif // WITH_EDITOR  // Blueprint asset creation helpers

FString ASquadAIAutoSetupManager::BuildSetupSummary()
{
    FString Summary;
    Summary += FString::Printf(TEXT("Manager: %s\n"), *GetName());
    Summary += FString::Printf(TEXT("Setup Completed: %s\n"), bSetupAlreadyCompleted ? TEXT("Yes") : TEXT("No"));

    if (AActor* Leader = ResolveLeader())
    {
        Summary += FString::Printf(TEXT("Leader: %s\n"), *Leader->GetName());
    }
    else
    {
        Summary += TEXT("Leader: MISSING\n");
    }

    const TArray<AActor*> Allies = ResolveAllies();
    Summary += FString::Printf(TEXT("Allies/Followers Found: %d\n"), Allies.Num());
    for (AActor* Ally : Allies)
    {
        if (Ally)
        {
            Summary += FString::Printf(TEXT(" - %s\n"), *Ally->GetName());
        }
    }

    const TArray<AActor*> Enemies = ResolveEnemies();
    Summary += FString::Printf(TEXT("Enemies Found: %d\n"), Enemies.Num());
    for (AActor* Enemy : Enemies)
    {
        if (Enemy)
        {
            Summary += FString::Printf(TEXT(" - %s\n"), *Enemy->GetName());
        }
    }

    // Check Missions and Quest Chain
    int32 MissionCount = 0;
    AQuestChain* Chain = nullptr;
    ASquadAIAudioManager* AudioMgr = nullptr;
    AAtmosphericDustScatterer* DustScatterer = nullptr;
    ASceneDecorator* SceneDec = nullptr;
    ASandstormWeatherDirector* WeatherDirector = nullptr;
    AAmmoCrateActor* AmmoCrate = nullptr;
    AFirstAidKitActor* FirstAidKit = nullptr;
    AMedicalStationActor* MedicalStation = nullptr;
    AMountedTurretActor* MountedTurret = nullptr;

    if (UWorld* World = GetWorld())
    {
        for (TActorIterator<AMissionZone> It(World); It; ++It) { MissionCount++; }
        for (TActorIterator<AQuestChain> It(World); It; ++It) { Chain = *It; break; }
        for (TActorIterator<ASquadAIAudioManager> It(World); It; ++It) { AudioMgr = *It; break; }
        for (TActorIterator<AAtmosphericDustScatterer> It(World); It; ++It) { DustScatterer = *It; break; }
        for (TActorIterator<ASceneDecorator> It(World); It; ++It) { SceneDec = *It; break; }
        for (TActorIterator<ASandstormWeatherDirector> It(World); It; ++It) { WeatherDirector = *It; break; }
        for (TActorIterator<AAmmoCrateActor> It(World); It; ++It) { AmmoCrate = *It; break; }
        for (TActorIterator<AFirstAidKitActor> It(World); It; ++It) { FirstAidKit = *It; break; }
        for (TActorIterator<AMedicalStationActor> It(World); It; ++It) { MedicalStation = *It; break; }
        for (TActorIterator<AMountedTurretActor> It(World); It; ++It) { MountedTurret = *It; break; }
    }

    Summary += FString::Printf(TEXT("Quest Chain: %s\n"), Chain ? *Chain->GetName() : TEXT("MISSING (Use Auto-Fix to create)"));
    Summary += FString::Printf(TEXT("Mission Zones: %d found\n"), MissionCount);
    Summary += FString::Printf(TEXT("Audio Manager: %s\n"), AudioMgr ? *AudioMgr->GetName() : TEXT("MISSING (Use EnsureAtmosphereAndAudio)"));
    Summary += FString::Printf(TEXT("Dust Scatterer: %s\n"), DustScatterer ? *DustScatterer->GetName() : TEXT("MISSING (Use EnsureAtmosphereAndAudio)"));
    Summary += FString::Printf(TEXT("Scene Decorator: %s\n"), SceneDec ? *SceneDec->GetName() : TEXT("MISSING (Use EnsureAtmosphereAndAudio)"));
    Summary += FString::Printf(TEXT("Weather Director: %s\n"), WeatherDirector ? *WeatherDirector->GetName() : TEXT("MISSING (Use EnsureAtmosphereAndAudio)"));
    Summary += FString::Printf(TEXT("Ammo Crate: %s\n"), AmmoCrate ? *AmmoCrate->GetName() : TEXT("MISSING (Use EnsureAtmosphereAndAudio)"));
    Summary += FString::Printf(TEXT("First Aid Kit: %s\n"), FirstAidKit ? *FirstAidKit->GetName() : TEXT("MISSING (Use EnsureAtmosphereAndAudio)"));
    Summary += FString::Printf(TEXT("Mounted Turret: %s\n"), MountedTurret ? *MountedTurret->GetName() : TEXT("MISSING (Use EnsureAtmosphereAndAudio)"));

    LastSetupSummary = Summary;
    return Summary;
}

AActor* ASquadAIAutoSetupManager::ResolveLeader() const
{
    if (IsValid(ExplicitLeader))
    {
        return ExplicitLeader;
    }

    if (!bAutoFindLeaderIfMissing || !GetWorld())
    {
        return nullptr;
    }

    // 1. Search for ALeaderCharacter
    for (TActorIterator<ALeaderCharacter> It(GetWorld()); It; ++It)
    {
        if (!RequiredActorTag.IsNone() && !It->ActorHasTag(RequiredActorTag))
        {
            continue;
        }

        return *It;
    }

    // 2. Search for ASoldierCharacter with Leader tag or name
    for (TActorIterator<ASoldierCharacter> It(GetWorld()); It; ++It)
    {
        if (It->ActorHasTag(TEXT("Leader")) || It->GetName().Contains(TEXT("Leader"), ESearchCase::IgnoreCase))
        {
            return *It;
        }
    }

    // 3. Search for any ACharacter / APawn with Leader / Player / Hero / Commander in name or tag
    for (TActorIterator<ACharacter> It(GetWorld()); It; ++It)
    {
        const FString Name = It->GetName();
        if (It->ActorHasTag(TEXT("Leader")) || It->ActorHasTag(TEXT("Player")) ||
            Name.Contains(TEXT("Leader"), ESearchCase::IgnoreCase) ||
            Name.Contains(TEXT("Commander"), ESearchCase::IgnoreCase) ||
            Name.Contains(TEXT("Hero"), ESearchCase::IgnoreCase) ||
            Name.Contains(TEXT("Player"), ESearchCase::IgnoreCase))
        {
            return *It;
        }
    }

    return nullptr;
}

TArray<AActor*> ASquadAIAutoSetupManager::ResolveAllies() const
{
    TArray<AActor*> Result;
    AActor* ResolvedLeaderActor = ResolveLeader();

    for (AActor* Ally : ExplicitAllies)
    {
        if (IsValid(Ally) && Ally != ResolvedLeaderActor)
        {
            Result.AddUnique(Ally);
        }
    }

    if (Result.Num() > 0 || !bAutoFindAlliesIfArrayEmpty || !GetWorld())
    {
        return Result;
    }

    // 1. Search for AAllySoldier
    for (TActorIterator<AAllySoldier> It(GetWorld()); It; ++It)
    {
        if (!RequiredActorTag.IsNone() && !It->ActorHasTag(RequiredActorTag))
        {
            continue;
        }

        if (*It != ResolvedLeaderActor)
        {
            Result.AddUnique(*It);
        }
    }

    // 2. Search for ASoldierCharacter with Ally/Follower tags or name
    for (TActorIterator<ASoldierCharacter> It(GetWorld()); It; ++It)
    {
        if (*It == ResolvedLeaderActor) continue;
        const FString Name = It->GetName();
        if (It->ActorHasTag(TEXT("Ally")) || It->ActorHasTag(TEXT("Follower")) || It->ActorHasTag(TEXT("Squad")) ||
            Name.Contains(TEXT("Ally"), ESearchCase::IgnoreCase) ||
            Name.Contains(TEXT("Follower"), ESearchCase::IgnoreCase) ||
            Name.Contains(TEXT("Teammate"), ESearchCase::IgnoreCase) ||
            Name.Contains(TEXT("Friendly"), ESearchCase::IgnoreCase))
        {
            Result.AddUnique(*It);
        }
    }

    // 3. Search for any ACharacter / APawn with Follower / Ally / Squad in tag or name
    for (TActorIterator<ACharacter> It(GetWorld()); It; ++It)
    {
        if (*It == ResolvedLeaderActor) continue;
        const FString Name = It->GetName();
        if (It->ActorHasTag(TEXT("Ally")) || It->ActorHasTag(TEXT("Follower")) || It->ActorHasTag(TEXT("Squad")) ||
            Name.Contains(TEXT("Follower"), ESearchCase::IgnoreCase) ||
            Name.Contains(TEXT("Ally"), ESearchCase::IgnoreCase) ||
            Name.Contains(TEXT("Teammate"), ESearchCase::IgnoreCase) ||
            Name.Contains(TEXT("Friendly"), ESearchCase::IgnoreCase))
        {
            Result.AddUnique(*It);
        }
    }

    return Result;
}

TArray<AActor*> ASquadAIAutoSetupManager::ResolveEnemies() const
{
    TArray<AActor*> Result;
    AActor* ResolvedLeaderActor = ResolveLeader();

    for (AActor* Enemy : ExplicitEnemies)
    {
        if (IsValid(Enemy) && Enemy != ResolvedLeaderActor)
        {
            Result.AddUnique(Enemy);
        }
    }

    if (Result.Num() > 0 || !bAutoFindEnemiesIfArrayEmpty || !GetWorld())
    {
        return Result;
    }

    // 1. Search for AEnemySoldier
    for (TActorIterator<AEnemySoldier> It(GetWorld()); It; ++It)
    {
        if (!RequiredActorTag.IsNone() && !It->ActorHasTag(RequiredActorTag))
        {
            continue;
        }

        Result.AddUnique(*It);
    }

    // 2. Search for ASoldierCharacter / ACharacter with Enemy/Hostile tags or name
    for (TActorIterator<ACharacter> It(GetWorld()); It; ++It)
    {
        if (*It == ResolvedLeaderActor) continue;
        const FString Name = It->GetName();
        if (It->ActorHasTag(TEXT("Enemy")) || It->ActorHasTag(TEXT("Hostile")) ||
            Name.Contains(TEXT("Enemy"), ESearchCase::IgnoreCase) ||
            Name.Contains(TEXT("Hostile"), ESearchCase::IgnoreCase) ||
            Name.Contains(TEXT("BadGuy"), ESearchCase::IgnoreCase) ||
            Name.Contains(TEXT("Opponent"), ESearchCase::IgnoreCase))
        {
            Result.AddUnique(*It);
        }
    }

    return Result;
}

FString ASquadAIAutoSetupManager::SpawnMainMenuDirectorActor()
{
    UWorld* World = GetWorld();
    if (!World) return TEXT("Failed: No active World");

    // Check if one already exists
    for (TActorIterator<ASquadAIMainMenuSetupActor> It(World); It; ++It)
    {
        (*It)->AutoSetupMasterMainMenu();
        return FString::Printf(TEXT("Found existing Main Menu Director '%s' and executed AutoSetup!"), *(*It)->GetName());
    }

    FActorSpawnParameters SpawnParams;
    SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
    ASquadAIMainMenuSetupActor* MenuDir = World->SpawnActor<ASquadAIMainMenuSetupActor>(GetActorLocation(), GetActorRotation(), SpawnParams);
    if (MenuDir)
    {
        MenuDir->AutoSetupMasterMainMenu();
        return FString::Printf(TEXT("Successfully spawned and auto-wired Main Menu Director '%s'"), *MenuDir->GetName());
    }

    return TEXT("Failed to spawn Main Menu Director");
}

// S26-MENUSPLIT: the menu video pickers + install buttons moved to the Main
// Menu Director (SquadAIMainMenuSetupActor) - menu things live in the menu map.

void ASquadAIAutoSetupManager::DisableManagerIfNeeded()
{
    if (!bDisableAfterSuccessfulSetup)
    {
        return;
    }

    SetActorTickEnabled(false);
    SetActorHiddenInGame(true);
    SetActorEnableCollision(false);
}

#include "Actors/SquadAIAudioManager.h"
#include "Performance/SquadAIAudioSubsystem.h"
#include "Kismet/GameplayStatics.h"
#include "Components/AudioComponent.h"
#include "Sound/SoundBase.h"
#include "Engine/World.h"
#include "TimerManager.h"

ASquadAIAudioManager::ASquadAIAudioManager()
{
	PrimaryActorTick.bCanEverTick = false;

	USceneComponent* Root = CreateDefaultSubobject<USceneComponent>(TEXT("AudioRoot"));
	SetRootComponent(Root);
}

void ASquadAIAudioManager::BeginPlay()
{
	Super::BeginPlay();
	SyncSettingsToSubsystem();
}

void ASquadAIAudioManager::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	StopAllPreviewAudio();
	Super::EndPlay(EndPlayReason);
}

#if WITH_EDITOR
void ASquadAIAudioManager::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);
	SyncSettingsToSubsystem();
}
#endif

void ASquadAIAudioManager::SyncSettingsToSubsystem()
{
	if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
	{
		AudioSys->RegisterAudioManager(this);
	}
}

void ASquadAIAudioManager::PlayEditorPreview(USoundBase* Sound, float Volume)
{
	if (!Sound || !GetWorld()) return;

	StopAllPreviewAudio();

	EditorPreviewAudioComp = UGameplayStatics::SpawnSound2D(GetWorld(), Sound, Volume * MusicMasterVolume, 1.0f, 0.0f, nullptr, true, false);
	if (EditorPreviewAudioComp)
	{
		EditorPreviewAudioComp->bIsUISound = true;
		EditorPreviewAudioComp->Play();
	}
}

void ASquadAIAudioManager::TestPlayAmbientMusic()
{
	if (AmbientMusic)
	{
		UE_LOG(LogTemp, Warning, TEXT("[AudioManager GUI] Previewing Ambient Music: %s"), *AmbientMusic->GetName());
		PlayEditorPreview(AmbientMusic, 0.8f);
	}
	else if (AmbientMusicPlaylist.Num() > 0 && AmbientMusicPlaylist[0])
	{
		UE_LOG(LogTemp, Warning, TEXT("[AudioManager GUI] Previewing Ambient Playlist Track 0: %s"), *AmbientMusicPlaylist[0]->GetName());
		PlayEditorPreview(AmbientMusicPlaylist[0], 0.8f);
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("[AudioManager GUI] AmbientMusic slot is empty!"));
	}
}

void ASquadAIAudioManager::TestPlayCombatMusic()
{
	if (CombatMusic)
	{
		UE_LOG(LogTemp, Warning, TEXT("[AudioManager GUI] Previewing Combat Music: %s"), *CombatMusic->GetName());
		PlayEditorPreview(CombatMusic, 1.0f);
	}
	else if (CombatMusicPlaylist.Num() > 0 && CombatMusicPlaylist[0])
	{
		UE_LOG(LogTemp, Warning, TEXT("[AudioManager GUI] Previewing Combat Playlist Track 0: %s"), *CombatMusicPlaylist[0]->GetName());
		PlayEditorPreview(CombatMusicPlaylist[0], 1.0f);
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("[AudioManager GUI] CombatMusic slot is empty!"));
	}
}

void ASquadAIAudioManager::TestPlayDefendIntroMusic()
{
	if (DefendIntroMusic)
	{
		UE_LOG(LogTemp, Warning, TEXT("[AudioManager GUI] Previewing Defend Music X (Intro/Early Stage): %s"), *DefendIntroMusic->GetName());
		PlayEditorPreview(DefendIntroMusic, 0.9f);
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("[AudioManager GUI] DefendIntroMusic slot is empty! Falling back to CombatMusic."));
		TestPlayCombatMusic();
	}
}

void ASquadAIAudioManager::TestPlayDefendClimaxMusic()
{
	if (DefendClimaxMusic)
	{
		UE_LOG(LogTemp, Warning, TEXT("[AudioManager GUI] Previewing Defend Music Y (Climax/Final Countdown): %s"), *DefendClimaxMusic->GetName());
		PlayEditorPreview(DefendClimaxMusic, 1.0f);
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("[AudioManager GUI] DefendClimaxMusic slot is empty!"));
	}
}

void ASquadAIAudioManager::TestPlayHordeStem()
{
	if (HordeCombatStem)
	{
		UE_LOG(LogTemp, Warning, TEXT("[AudioManager GUI] Previewing Horde War Drums Stem Layer: %s"), *HordeCombatStem->GetName());
		if (EditorPreviewStemComp)
		{
			EditorPreviewStemComp->Stop();
		}
		EditorPreviewStemComp = UGameplayStatics::SpawnSound2D(GetWorld(), HordeCombatStem, 1.0f, 1.0f, 0.0f, nullptr, true, false);
		if (EditorPreviewStemComp)
		{
			EditorPreviewStemComp->bIsUISound = true;
			EditorPreviewStemComp->Play();
		}
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("[AudioManager GUI] HordeCombatStem slot is empty!"));
	}
}

void ASquadAIAudioManager::TestPlayDesertWindAmbience()
{
	if (DesertWindAmbience)
	{
		UE_LOG(LogTemp, Warning, TEXT("[AudioManager GUI] Previewing Khuzestan Desert Wind Ambience: %s"), *DesertWindAmbience->GetName());
		PlayEditorPreview(DesertWindAmbience, 0.7f);
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("[AudioManager GUI] DesertWindAmbience slot is empty!"));
	}
}

void ASquadAIAudioManager::TestPlayDistantArtilleryRumble()
{
	if (DistantArtilleryRumble)
	{
		UE_LOG(LogTemp, Warning, TEXT("[AudioManager GUI] Previewing Distant Artillery Horizon Rumble: %s"), *DistantArtilleryRumble->GetName());
		PlayEditorPreview(DistantArtilleryRumble, 0.85f);
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("[AudioManager GUI] DistantArtilleryRumble slot is empty!"));
	}
}

void ASquadAIAudioManager::TestPlayVictoryStinger()
{
	if (VictoryStingerSound)
	{
		UE_LOG(LogTemp, Warning, TEXT("[AudioManager GUI] Previewing Victory Stinger: %s"), *VictoryStingerSound->GetName());
		PlayEditorPreview(VictoryStingerSound, 1.0f);
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("[AudioManager GUI] VictoryStingerSound slot is empty!"));
	}
}

void ASquadAIAudioManager::TestPlayCloseExplosion()
{
	USoundBase* Snd = LargeExplosionCloseSound ? LargeExplosionCloseSound.Get() : (MediumExplosionCloseSound ? MediumExplosionCloseSound.Get() : SmallExplosionCloseSound.Get());
	if (Snd)
	{
		UE_LOG(LogTemp, Warning, TEXT("[AudioManager GUI] Previewing Close Explosion Sound: %s"), *Snd->GetName());
		PlayEditorPreview(Snd, 1.0f);
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("[AudioManager GUI] No Explosion Close Sound assigned!"));
	}
}

void ASquadAIAudioManager::TestPlayDistantExplosion()
{
	USoundBase* Snd = LargeExplosionDistantSound ? LargeExplosionDistantSound.Get() : (MediumExplosionDistantSound ? MediumExplosionDistantSound.Get() : SmallExplosionDistantSound.Get());
	if (Snd)
	{
		UE_LOG(LogTemp, Warning, TEXT("[AudioManager GUI] Simulating Distant Explosion with 1.5s Speed-of-Sound Delay: %s"), *Snd->GetName());
		FTimerHandle DelayHandle;
		TWeakObjectPtr<ASquadAIAudioManager> WeakThis(this);
		GetWorld()->GetTimerManager().SetTimer(DelayHandle, [WeakThis, Snd]()
		{
			if (WeakThis.IsValid())
			{
				WeakThis->PlayEditorPreview(Snd, 0.85f);
			}
		}, 1.5f, false);
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("[AudioManager GUI] No Explosion Distant Sound assigned!"));
	}
}

void ASquadAIAudioManager::TestPlayBulletWhizBy()
{
	if (BulletWhizBySound)
	{
		UE_LOG(LogTemp, Warning, TEXT("[AudioManager GUI] Previewing Bullet Whiz-By Sound: %s"), *BulletWhizBySound->GetName());
		PlayEditorPreview(BulletWhizBySound, 1.0f);
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("[AudioManager GUI] BulletWhizBySound slot is empty!"));
	}
}

void ASquadAIAudioManager::StopAllPreviewAudio()
{
	if (EditorPreviewAudioComp)
	{
		EditorPreviewAudioComp->Stop();
		EditorPreviewAudioComp = nullptr;
	}
	if (EditorPreviewStemComp)
	{
		EditorPreviewStemComp->Stop();
		EditorPreviewStemComp = nullptr;
	}
	UE_LOG(LogTemp, Warning, TEXT("[AudioManager GUI] Stopped all audio preview playback."));
}

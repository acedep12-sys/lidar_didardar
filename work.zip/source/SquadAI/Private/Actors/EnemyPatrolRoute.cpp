// EnemyPatrolRoute.cpp - S19-PATROL
#include "Actors/EnemyPatrolRoute.h"
#include "Components/SceneComponent.h"
#include "Diagnostics/SquadAISituationLog.h"
#include "Engine/World.h"

#if WITH_EDITORONLY_DATA
#include "Components/BillboardComponent.h"
#include "Components/SplineComponent.h"
#include "Engine/Texture2D.h"              // FObjectFinder<UTexture2D> needs the complete type
#include "UObject/ConstructorHelpers.h"
#endif

AEnemyPatrolRoute::AEnemyPatrolRoute()
{
	PrimaryActorTick.bCanEverTick = false;   // authoring data only; the patrollers do the thinking

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SetRootComponent(SceneRoot);

#if WITH_EDITORONLY_DATA
	EditorPathSpline = CreateDefaultSubobject<USplineComponent>(TEXT("EditorPathSpline"));
	if (EditorPathSpline)
	{
		EditorPathSpline->SetupAttachment(SceneRoot);
		EditorPathSpline->SetClosedLoop(true);
		EditorPathSpline->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		EditorPathSpline->SetGenerateOverlapEvents(false);
	}

	EditorIcon = CreateDefaultSubobject<UBillboardComponent>(TEXT("EditorIcon"));
	if (EditorIcon)
	{
		EditorIcon->SetupAttachment(SceneRoot);
		EditorIcon->bIsScreenSizeScaled = true;
		EditorIcon->SetHiddenInGame(true);
		// Engine editor sprite; guarded so a packaged build never references it. If the asset
		// is ever missing the component simply draws nothing - no crash, no gameplay effect.
		static ConstructorHelpers::FObjectFinder<UTexture2D> RouteIconTex(TEXT("/Engine/EditorResources/S_Note"));
		if (RouteIconTex.Succeeded())
		{
			EditorIcon->Sprite = RouteIconTex.Object;
		}
	}
#endif

	if (RouteName.IsEmpty())
	{
		RouteName = GetName();
	}
}

void AEnemyPatrolRoute::OnConstruction(const FTransform& Transform)
{
	Super::OnConstruction(Transform);
	RebuildEditorPathVisual();
}

// =========================================================================
//  Editing
// =========================================================================
void AEnemyPatrolRoute::MarkRouteDirty()
{
#if WITH_EDITOR
	// Recorded for undo and marks the containing level package dirty, without which points
	// added here would be lost on save. A no-op outside the editor.
	Modify();
#endif
}

void AEnemyPatrolRoute::AddPoint()
{
	MarkRouteDirty();
	FEnemyPatrolPoint NewPoint;

	if (Points.Num() > 0)
	{
		// 4 m along from the previous point, so repeated presses lay a line you can then drag
		// into shape. A first point lands in front of the route actor.
		const FVector Last = Points.Last().Location;
		FVector Dir = FVector::ForwardVector;
		if (Points.Num() >= 2)
		{
			Dir = (Points.Last().Location - Points[Points.Num() - 2].Location).GetSafeNormal();
			if (Dir.IsNearlyZero())
			{
				Dir = FVector::ForwardVector;
			}
		}
		NewPoint.Location = Last + Dir * 400.f;
	}
	else
	{
		NewPoint.Location = GetActorTransform().TransformVector(FVector(400.f, 0.f, 0.f));
	}

	Points.Add(NewPoint);
	RebuildEditorPathVisual();

	SquadAISituation::Note(FString::Printf(
		TEXT("S19-PATROL route %s: point %d added (%s). Drag its handle in the viewport to place it."),
		*RouteName, Points.Num(), *GetPointLocation(Points.Num() - 1).ToString()));
}

void AEnemyPatrolRoute::AddPointAt(const FVector& WorldLocation)
{
	MarkRouteDirty();
	FEnemyPatrolPoint NewPoint;
	// Stored relative: moving the route actor later moves the whole beat with it.
	NewPoint.Location = GetActorTransform().InverseTransformPosition(WorldLocation);
	Points.Add(NewPoint);
	RebuildEditorPathVisual();

	SquadAISituation::Note(FString::Printf(TEXT("S19-PATROL route %s: point %d added at %s"),
		*RouteName, Points.Num(), *WorldLocation.ToString()));
}

void AEnemyPatrolRoute::DuplicateLastPoint()
{
	MarkRouteDirty();
	if (Points.Num() == 0)
	{
		AddPoint();
		return;
	}
	Points.Add(Points.Last());
	RebuildEditorPathVisual();
}

void AEnemyPatrolRoute::RemoveLastPoint()
{
	if (Points.Num() == 0)
	{
		return;
	}
	MarkRouteDirty();
	Points.Pop();
	RebuildEditorPathVisual();
	SquadAISituation::Note(FString::Printf(TEXT("S19-PATROL route %s: last point removed, %d left"),
		*RouteName, Points.Num()));
}

void AEnemyPatrolRoute::RemovePoint(int32 Index)
{
	if (!Points.IsValidIndex(Index))
	{
		return;
	}
	MarkRouteDirty();
	Points.RemoveAt(Index);
	RebuildEditorPathVisual();
	SquadAISituation::Note(FString::Printf(TEXT("S19-PATROL route %s: point %d removed, %d left"),
		*RouteName, Index + 1, Points.Num()));
}

void AEnemyPatrolRoute::ClearPoints()
{
	MarkRouteDirty();
	const int32 Was = Points.Num();
	Points.Reset();
	RebuildEditorPathVisual();
	if (Was > 0)
	{
		SquadAISituation::Note(FString::Printf(TEXT("S19-PATROL route %s: cleared (%d point(s) removed)"),
			*RouteName, Was));
	}
}

// =========================================================================
//  Queries
// =========================================================================
FVector AEnemyPatrolRoute::GetPointLocation(int32 Index) const
{
	if (!Points.IsValidIndex(Index))
	{
		return GetActorLocation();
	}
	return GetActorTransform().TransformPosition(Points[Index].Location);
}

int32 AEnemyPatrolRoute::FindNearestPointIndex(const FVector& WorldLocation) const
{
	int32 Best = 0;
	float BestDistSq = TNumericLimits<float>::Max();
	for (int32 i = 0; i < Points.Num(); ++i)
	{
		const float D = FVector::DistSquared2D(GetPointLocation(i), WorldLocation);
		if (D < BestDistSq)
		{
			BestDistSq = D;
			Best = i;
		}
	}
	return Best;
}

float AEnemyPatrolRoute::DistanceToRoute2D(const FVector& WorldLocation) const
{
	const int32 Count = Points.Num();
	if (Count == 0)
	{
		return TNumericLimits<float>::Max();
	}
	if (Count == 1)
	{
		return FVector::Dist2D(WorldLocation, GetPointLocation(0));
	}

	// Distance to the nearest leg. A closed route also has the last -> first leg; when the
	// route is left open, standing beyond either end still measures to the line ends, which
	// is what the leash wants.
	const int32 Legs = bClosedLoop ? Count : (Count - 1);
	float Best = TNumericLimits<float>::Max();
	for (int32 i = 0; i < Legs; ++i)
	{
		const FVector A = GetPointLocation(i);
		const FVector B = GetPointLocation((i + 1) % Count);

		// 2D projection onto the segment.
		const FVector2D P(WorldLocation.X, WorldLocation.Y);
		const FVector2D S(A.X, A.Y);
		const FVector2D E(B.X, B.Y);
		const FVector2D SE = E - S;
		const float LenSq = SE.SizeSquared();
		FVector2D Closest = S;
		if (LenSq > KINDA_SMALL_NUMBER)
		{
			const float T = FMath::Clamp(((P - S) | SE) / LenSq, 0.f, 1.f);
			Closest = S + SE * T;
		}
		Best = FMath::Min(Best, FVector2D::Distance(P, Closest));
	}
	return Best;
}

float AEnemyPatrolRoute::DistanceToRoute3D(const FVector& WorldLocation) const
{
	const int32 Count = Points.Num();
	if (Count == 0)
	{
		return TNumericLimits<float>::Max();
	}
	if (Count == 1)
	{
		return FVector::Dist(WorldLocation, GetPointLocation(0));
	}

	const int32 Legs = bClosedLoop ? Count : (Count - 1);
	float Best = TNumericLimits<float>::Max();
	for (int32 i = 0; i < Legs; ++i)
	{
		const FVector A = GetPointLocation(i);
		const FVector B = GetPointLocation((i + 1) % Count);
		const FVector AB = B - A;
		const float LenSq = AB.SizeSquared();
		FVector Closest = A;
		if (LenSq > KINDA_SMALL_NUMBER)
		{
			const float T = FMath::Clamp(FVector::DotProduct(WorldLocation - A, AB) / LenSq, 0.f, 1.f);
			Closest = A + AB * T;
		}
		Best = FMath::Min(Best, FVector::Dist(WorldLocation, Closest));
	}
	return Best;
}

float AEnemyPatrolRoute::GetRouteLength2D() const
{
	const int32 Count = Points.Num();
	if (Count < 2)
	{
		return 0.f;
	}
	const int32 Legs = bClosedLoop ? Count : (Count - 1);
	float Total = 0.f;
	for (int32 i = 0; i < Legs; ++i)
	{
		Total += FVector::Dist2D(GetPointLocation(i), GetPointLocation((i + 1) % Count));
	}
	return Total;
}

#if WITH_EDITOR
void AEnemyPatrolRoute::LogRouteDescription()
{
	SquadAISituation::Note(FString::Printf(
		TEXT("S19-PATROL route %s: %d point(s), %s, %.0f m of beat, %.1f s pause at each point%s"),
		*RouteName, Points.Num(), bClosedLoop ? TEXT("closed loop") : TEXT("open"),
		GetRouteLength2D() / 100.f, DefaultPointWaitSeconds,
		Points.ContainsByPredicate([](const FEnemyPatrolPoint& P) { return P.WaitSeconds >= 0.f; })
			? TEXT(" (some points override the pause)") : TEXT("")));
}
#endif

// =========================================================================
//  Editor visual
// =========================================================================
void AEnemyPatrolRoute::RebuildEditorPathVisual()
{
#if WITH_EDITORONLY_DATA
	if (!EditorPathSpline)
	{
		return;
	}

	EditorPathSpline->ClearSplinePoints(false);
	for (int32 i = 0; i < Points.Num(); ++i)
	{
		// Local space: the spline rides the actor, exactly like the stored points.
		EditorPathSpline->AddSplinePoint(Points[i].Location, ESplineCoordinateSpace::Local, false);
	}
	EditorPathSpline->SetClosedLoop(bClosedLoop, false);
	EditorPathSpline->UpdateSpline();
#endif
}

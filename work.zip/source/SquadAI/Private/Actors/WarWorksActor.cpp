#include "Actors/WarWorksActor.h"

#include "Components/StaticMeshComponent.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h"   // S26-WEAR2: instanced shells
#include "Engine/World.h"
#include "Engine/StaticMesh.h"
#include "Materials/MaterialInstanceDynamic.h"

#include "Performance/SquadAIAssetCacheSubsystem.h"

namespace
{
	// The manager said "create the materials yourself" - so we do.
	// S26-MAT: the real thing first - the shared textured prop material
	// (Tex x Tint on M_SquadAIProp) - and the plain tint material as the
	// fallback when the textures are not in the project yet.
	UMaterialInterface* WarMat(UObject* Ctx, const FString& TexKey, const FLinearColor& Tint, const float UVScale = 1.f)
	{
		if (USquadAIAssetCacheSubsystem* Cache = USquadAIAssetCacheSubsystem::Get(Ctx))
		{
			if (UMaterialInterface* Textured = Cache->GetPropMaterial(TexKey, Tint, UVScale))
			{
				return Textured;
			}
			return Cache->GetSharedDynamicMaterial(Cache->GetDefaultBasicMaterial(), TEXT("Color"), Tint);
		}
		return nullptr;
	}

	// Cube and cylinder meshes are 100 cm on a side.
	constexpr float MeshUnit = 100.f;

	// every piece carries this tag so a rebuild can find and clear ALL of them
	const FName WarWorksPieceTag(TEXT("WarWorksPiece"));
}

AWarWorksActor::AWarWorksActor()
{
	PrimaryActorTick.bCanEverTick = false;

	USceneComponent* Root = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	Root->SetMobility(EComponentMobility::Static);
	SetRootComponent(Root);
}

void AWarWorksActor::OnConstruction(const FTransform& Transform)
{
	Super::OnConstruction(Transform);
	BuildWarWork();
}

void AWarWorksActor::BuildWarWork()
{
	// clear the previous build. By TAG, not the (transient) array: after a
	// save/reload cycle - or an editor move that reran construction - loaded
	// pieces can exist that the array does not know about, and clearing only
	// the array would stack a second bridge on the first.
	{
		TArray<UStaticMeshComponent*> Existing;
		GetComponents<UStaticMeshComponent>(Existing);
		for (UStaticMeshComponent* C : Existing)
		{
			// S26-WEAR4: the shell HISM is REUSED, never destroyed - tearing down
		// a HISM while its async cluster-tree build is still pending corrupts
		// the instance table (InstanceReorderTable assert). See AddShell.
		if (C && C->ComponentHasTag(WarWorksPieceTag) && C->GetFName() != TEXT("HISM_Shells"))
			{
				C->DestroyComponent();
			}
		}
	}
	Pieces.Reset();

	UWorld* World = GetWorld();
	if (!World || HasAnyFlags(RF_ClassDefaultObject)) return;

	USquadAIAssetCacheSubsystem* Cache = USquadAIAssetCacheSubsystem::Get(this);

	// S26-SHELLFALLBACK: never leave a war work as an empty shell - if the cache is unreachable
	// (or came up unprimed), load the engine basic shapes directly, like the fort posts do.
	UStaticMesh* Cube = Cache ? Cache->GetCubeMesh() : nullptr;
	UStaticMesh* Cyl  = Cache ? Cache->GetCylinderMesh() : nullptr;
	if (!Cube) { Cube = LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cube.Cube")); }
	if (!Cyl)  { Cyl  = LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cylinder.Cylinder")); }
	if (!Cube || !Cyl) return;   // a world without basic shapes has no war to build

	const FRotator BaseRot = GetActorRotation();
	const FVector BaseLoc = GetActorLocation();

	// one piece = one primitive, world-placed (like the fortifications)
	auto AddBox = [&](const FVector& LocalCenter, const FRotator& LocalRot, const FVector& SizeCm, UMaterialInterface* Mat)
	{
		UStaticMeshComponent* C = NewObject<UStaticMeshComponent>(this);
		C->CreationMethod = EComponentCreationMethod::UserConstructionScript;   // never saved with the level
		C->ComponentTags.Add(WarWorksPieceTag);
		C->SetStaticMesh(Cube);
		C->SetCollisionProfileName(TEXT("BlockAll"));
		C->SetWorldLocationAndRotation(BaseLoc + LocalCenter.RotateAngleAxis(BaseRot.Yaw, FVector::UpVector), LocalRot + BaseRot);
		C->SetWorldScale3D(SizeCm / MeshUnit);
		if (Mat) { C->SetMaterial(0, Mat); }
		C->RegisterComponent();
		C->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
		Pieces.Add(C);
		return C;
	};
	auto AddCyl = [&](const FVector& LocalCenter, const FRotator& LocalRot, float RadiusCm, float HeightCm, UMaterialInterface* Mat)
	{
		UStaticMeshComponent* C = NewObject<UStaticMeshComponent>(this);
		C->CreationMethod = EComponentCreationMethod::UserConstructionScript;   // never saved with the level
		C->ComponentTags.Add(WarWorksPieceTag);
		C->SetStaticMesh(Cyl);
		C->SetCollisionProfileName(TEXT("BlockAll"));
		C->SetWorldLocationAndRotation(BaseLoc + LocalCenter.RotateAngleAxis(BaseRot.Yaw, FVector::UpVector), LocalRot + BaseRot);
		// cylinder mesh: 100 cm tall, 50 cm radius -> scale X/Y by radius/50, Z by height/100
		C->SetWorldScale3D(FVector(RadiusCm / 50.f, RadiusCm / 50.f, HeightCm / MeshUnit));
		if (Mat) { C->SetMaterial(0, Mat); }
		C->RegisterComponent();
		C->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
		Pieces.Add(C);
		return C;
	};

	// a cheap ground probe: trace down from +500 cm, land where the land is
	auto GroundZ = [&](const FVector& LocalXY) -> float
	{
		const FVector WorldXY = BaseLoc + LocalXY.RotateAngleAxis(BaseRot.Yaw, FVector::UpVector);
		if (!bGroundSnap || !World) return BaseLoc.Z;
		FHitResult Hit;
		FCollisionQueryParams Params;
		Params.AddIgnoredActor(this);   // also ignores our own deck while we build under it
		// S26-GROUND2: sky-to-depth, not a +-30 m window around the actor - the
		// riverbed can be far below the banks, and the old window put decks underwater
		if (World->LineTraceSingleByChannel(Hit, WorldXY + FVector(0.f, 0.f, 50000.f),
			WorldXY - FVector(0.f, 0.f, 100000.f), ECC_Visibility, Params))
		{
			return Hit.ImpactPoint.Z;
		}
		return BaseLoc.Z;
	};

	// S26-WEAR2: spent brass on the ground - ONE hierarchical instanced mesh
	// carries every casing this work leaves, not a component each. A tower or
	// a crossing that was fought over means dozens of shells; HISM means one
	// instanced draw instead of dozens.
	// S26-WEAR4 (crash fix): the component is found and REUSED across
	// rebuilds - never destroyed and recreated. It used to carry the
	// UserConstructionScript creation method, which made the ENGINE rip
	// it down on every construction rerun (the setup moves this actor
	// while placing it), then this code recreated it under the same name
	// - all while the old component's async cluster-tree build was still
	// pending, corrupting the instance table (InstanceReorderTable
	// assert in HierarchicalInstancedStaticMesh.cpp). Like the village
	// batches, the component is Native: it survives construction reruns,
	// gets ClearInstances(), and the fixed seed replays the same brass.
	UHierarchicalInstancedStaticMeshComponent* ShellHISM = nullptr;
	uint32 ShellState = ((uint32)(FMath::Abs(BaseLoc.X * 0.29f) + FMath::Abs(BaseLoc.Y * 0.17f)) | 1u);
	{
		TArray<UHierarchicalInstancedStaticMeshComponent*> ShellComps;
		GetComponents(ShellComps);
		for (UHierarchicalInstancedStaticMeshComponent* C : ShellComps)
		{
			if (C && C->ComponentHasTag(WarWorksPieceTag) && C->GetFName() == TEXT("HISM_Shells"))
			{
				ShellHISM = C;
				break;
			}
		}
	}
	if (ShellHISM)
	{
		ShellHISM->ClearInstances();   // same seed, same brass - the scatter replays identically
	}
	auto AddShell = [&](const FVector& WorldLoc, float Yaw)
	{
		if (!ShellHISM)
		{
			UMaterialInterface* Brass = WarMat(this, TEXT("MetalPlate"), FLinearColor(0.72f, 0.55f, 0.22f, 1.f), 1.5f);
			if (!Brass) Brass = Cache ? Cache->GetDefaultBasicMaterial() : nullptr;
			if (!Brass) return;
			ShellHISM = NewObject<UHierarchicalInstancedStaticMeshComponent>(this, TEXT("HISM_Shells"));
			// S26-WEAR4: deliberately NOT UserConstructionScript - that made the
			// engine destroy this component on every construction rerun (see
			// above). Native + reuse, like the village batch components.
			ShellHISM->ComponentTags.Add(WarWorksPieceTag);
			ShellHISM->SetStaticMesh(Cyl);
			ShellHISM->SetCollisionProfileName(TEXT("NoCollision"));
			ShellHISM->SetCastShadow(false);
			ShellHISM->SetCanEverAffectNavigation(false);
			ShellHISM->SetMobility(EComponentMobility::Static);   // the root is static
			ShellHISM->SetMaterial(0, Brass);
			ShellHISM->RegisterComponent();
			ShellHISM->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
		}
		// casing: 2.4 cm across, 5.5 cm long, axis flat on the ground
		ShellHISM->AddInstance(FTransform(FRotator(90.f, Yaw, 0.f), WorldLoc, FVector(0.024f, 0.024f, 0.055f)), true);
	};
	// a scatter ring around a local point, ground-snapped, deterministic
	auto ShellRing = [&](const FVector& LocalCenter, float RMinCm, float RMaxCm, int32 Count)
	{
		for (int32 I = 0; I < Count; ++I)
		{
			ShellState = ShellState * 1103515245u + 12345u;
			const float Ang = (float)((ShellState >> 8) & 0xFFu) * (2.f * PI / 255.f);
			ShellState = ShellState * 1103515245u + 12345u;
			const float Rad = RMinCm + (float)((ShellState >> 8) & 0xFFu) * ((RMaxCm - RMinCm) / 255.f);
			ShellState = ShellState * 1103515245u + 12345u;
			const float Yaw = (float)((ShellState >> 8) & 0xFFu) * (360.f / 255.f);
			const FVector Local(LocalCenter.X + FMath::Cos(Ang) * Rad, LocalCenter.Y + FMath::Sin(Ang) * Rad, 0.f);
			FVector WorldLoc = BaseLoc + Local.RotateAngleAxis(BaseRot.Yaw, FVector::UpVector);
			WorldLoc.Z = GroundZ(Local) + 2.f;
			AddShell(WorldLoc, Yaw);
		}
	};

	const FLinearColor OldWood(0.28f, 0.20f, 0.13f);   // their weathered bridge
	const FLinearColor FreshWood(0.46f, 0.34f, 0.20f); // our engineers' cut timber
	const FLinearColor OliveDrab(0.24f, 0.28f, 0.17f); // the tower
	const FLinearColor EnemyArmor(0.36f, 0.17f, 0.12f);// their armor, the red on the map
	const FLinearColor BurntOut(0.05f, 0.05f, 0.05f);  // what a hulk becomes

	switch (Preset)
	{
		case EWarWorkPreset::EnemyBridge:
		case EWarWorkPreset::FriendlyBridge:
		{
			// A real bridge: deck planks across the channel, two pylon pairs
			// down to the water, a ramp at each bank. Local +X = across the
			// water (the model's bridge facing).
			UMaterialInterface* Wood = (Preset == EWarWorkPreset::FriendlyBridge)
				? WarMat(this, TEXT("WoodPlanks"), FreshWood, 2.2f)   // S26-TEX3: tile the planks, don't stretch one across 4.6 m
				: WarMat(this, TEXT("WoodPlanks"), OldWood, 2.2f);
			if (!Wood) Wood = Cache->GetDefaultBasicMaterial();

			float Span = FMath::Max(SpanCm, 400.f);
			const float DeckW = 460.f;                    // two trucks wide
			// S26-BRIDGE-MATH: MEASURE the channel from the real landscape. The
			// model chose this crossing from a ~70 m grid - honest for WHERE,
			// far too coarse for HOW LONG. Walk out along the crossing axis
			// until the ground rises clear of the bed, and build THAT span.
			{
				float BedMin = FLT_MAX;   // the lowest ground under the centre line
				// S26-SWEEP2: the bed used to be sampled under the INITIAL span - a
				// coarse estimate that can be a fraction of the real channel, so
				// every sample could land on one dry bank. The "bank level" then sat
				// ABOVE the real bank, the walk-out overshot or gave up, and the span
				// collapsed small again. Sample a FIXED 80 m window: the bridge was
				// stamped on a river crossing, the channel is in here somewhere.
				for (float D = 0.f; D <= 4000.f; D += 500.f)
				{
					BedMin = FMath::Min(BedMin, GroundZ(FVector(D, 0.f, 0.f)));
					BedMin = FMath::Min(BedMin, GroundZ(FVector(-D, 0.f, 0.f)));
				}
				const float BankLevel = BedMin + 260.f;   // 2.6 m above the bed = out of the water
				float HalfR = 0.f, HalfL = 0.f;
				// S26-FIXALL: walk out to 80 m at 1 m steps. The old 40 m / 0.5 m
				// probes gave up inside wide riverbeds and the span collapsed to
				// the fallback - "bridges are small" is exactly that.
				for (float D = 50.f; D <= 8000.f; D += 100.f)
				{
					if (GroundZ(FVector(D, 0.f, 0.f)) >= BankLevel) { HalfR = D; break; }
				}
				for (float D = 50.f; D <= 8000.f; D += 100.f)
				{
					if (GroundZ(FVector(-D, 0.f, 0.f)) >= BankLevel) { HalfL = D; break; }
				}
				if (HalfR > 0.f && HalfL > 0.f)
				{
					Span = FMath::Clamp(HalfL + HalfR + 120.f, 400.f, 8000.f);   // measured, with abutments
				}
				else
				{
					Span = FMath::Clamp(Span, 400.f, 8000.f);   // probes failed: sane cap, never multi-km
				}
			}
			// S26-GROUND2: probe each bank NEAR and FAR - the far probe climbs the
			// bank slope, so the deck is sized to the water's edges, never its bed
			// S26-DRY: probe a LADDER of distances on each bank and take the MAX.
			// A single near probe can land on the UNDERWATER bank slope, the
			// deck comes out below the waterline, and "bridges are under water"
			// is exactly what that looks like.
			const auto BankZ = [&](const float SideSign) -> float
			{
				float Best = -1e6f;
				// S26-FIXALL: x1.9 steps out to ~9.4 km, past the far top of any
				// bank - the old 2.8 km ladder could stop on the underwater slope
				// and the deck ended up below the waterline.
				for (float D = 200.f; D <= 9500.f; D *= 1.9f)   // 200, 380, 722, 1372, 2606, 4951, 9407
				{
					Best = FMath::Max(Best, GroundZ(FVector(SideSign * (Span * 0.5f + D), 0.f, 0.f)));
				}
				return Best;
			};
			const float EndZ[2] = { BankZ(1.f), BankZ(-1.f) };
			// the bed under the span: the deck clears even a flooded channel
			float BedZ = -1e6f;
			for (float FX = -0.4f; FX <= 0.41f; FX += 0.2f)
			{
				BedZ = FMath::Max(BedZ, GroundZ(FVector(FX * Span, 0.f, 0.f)));
			}
			const float DeckZ = FMath::Max(FMath::Max(EndZ[0], EndZ[1]) + 130.f, BedZ + 400.f) - BaseLoc.Z;   // local Z of the deck

			// deck planks: 130 cm planks with a finger gap, laid across the span.
			// S26-WEAR: the deck has history - a plank GONE (a gap you can see
			// the river through), one charred black. S26-WEAR3: HOW MUCH is
			// rolled per bridge from its own location - this crossing lost two
			// planks and burned, the next is only scorched, a third weathered on.
			uint32 BWear = ((uint32)(FMath::Abs(BaseLoc.X * 0.41f) + FMath::Abs(BaseLoc.Y * 0.23f)) | 1u);
			auto BRand = [&BWear]() -> float
			{
				BWear = BWear * 1103515245u + 12345u;
				return (float)((BWear >> 16) & 0xFFFFu) / 65535.f;
			};
			const int32 PlankTotal = FMath::Max(2, (int32)(Span / 150.f));
			const float GRoll = BRand();
			int32 GonePlankA = -1, GonePlankB = -1, CharPlank = -1;
			if (GRoll > 0.75f && PlankTotal >= 10) { GonePlankB = (int32)(BRand() * (PlankTotal - 2.f)) + 1; }
			if (GRoll > 0.25f) { GonePlankA = (int32)(BRand() * (PlankTotal - 2.f)) + 1; }   // never the end planks
			if (GonePlankA == GonePlankB) { GonePlankB = -1; }
			if (BRand() > 0.3f)
			{
				CharPlank = (int32)(BRand() * (float)PlankTotal);
				while (CharPlank == GonePlankA || CharPlank == GonePlankB)
				{
					CharPlank = (CharPlank + 1) % PlankTotal;   // char lands on a plank that is still there
				}
			}
			UMaterialInterface* CharWood = WarMat(this, TEXT("ScorchedMetal"), FLinearColor(0.05f, 0.045f, 0.04f, 1.f), 1.5f);
			if (!CharWood) CharWood = Wood;
			int32 PlankIdx = 0;
			for (float X = -Span * 0.5f; X < Span * 0.5f + 1.f; X += 150.f, ++PlankIdx)
			{
				if (PlankIdx == GonePlankA || PlankIdx == GonePlankB) { continue; }   // the gap(s)
				AddBox(FVector(X + 65.f, 0.f, DeckZ), FRotator::ZeroRotator, FVector(120.f, DeckW, 32.f),
					PlankIdx == CharPlank ? CharWood : Wood);
			}
			// stringers under the deck, one per edge
			AddBox(FVector(0.f, DeckW * 0.42f, DeckZ - 42.f), FRotator::ZeroRotator, FVector(Span, 44.f, 40.f), Wood);
			AddBox(FVector(0.f, -DeckW * 0.42f, DeckZ - 42.f), FRotator::ZeroRotator, FVector(Span, 44.f, 40.f), Wood);
			// pylons: two pairs at +-1/4 span, cylinders to the ground
			UMaterialInterface* RustBandMat = WarMat(this, TEXT("CorrugatedRust"), FLinearColor(0.42f, 0.27f, 0.16f, 1.f), 1.2f);
			if (!RustBandMat) RustBandMat = Wood;
			for (float Side = -1.f; Side <= 1.f; Side += 2.f)
			{
				for (float Edge = -1.f; Edge <= 1.f; Edge += 2.f)
				{
					const FVector At(Side * Span * 0.25f, Edge * DeckW * 0.38f, 0.f);
					const float Ground = GroundZ(At);
					const float Top = BaseLoc.Z + DeckZ;
					const float Height = FMath::Max(Top - Ground + 80.f, 120.f);
					AddCyl(FVector(At.X, At.Y, Ground + Height * 0.5f - BaseLoc.Z), FRotator::ZeroRotator, 58.f, Height, Wood);
					// S26-WEAR3: rust sleeve where the water laps the pylon - the
					// splash zone rots first. BedZ is the MEASURED bed; the band
					// sits just above it, where wet meets dry
					const float BandC = BedZ + 150.f;
					if (BandC + 35.f < Top - 60.f)
					{
						AddCyl(FVector(At.X, At.Y, BandC - BaseLoc.Z), FRotator::ZeroRotator, 60.f, 70.f, RustBandMat);
					}
				}
			}
			// S26-SURF: side trusses - alternating diagonals between the stringers,
			// the mark of a BUILT bridge rather than planks on poles
			for (float Edge = -1.f; Edge <= 1.f; Edge += 2.f)
			{
				int32 DiagIdx = 0;
				for (float X0 = -Span * 0.5f + 120.f; X0 < Span * 0.5f - 260.f; X0 += 520.f, ++DiagIdx)
				{
					const float DiagPitch = (DiagIdx % 2 == 0) ? 33.f : -33.f;
					AddBox(FVector(X0 + 200.f, Edge * DeckW * 0.42f, DeckZ - 95.f),
						FRotator(DiagPitch, 0.f, 0.f), FVector(30.f, 20.f, 560.f), Wood);
				}
			}
			// S26-SURF: low rails along the deck edges - the crossing reads walkable
			for (float Edge = -1.f; Edge <= 1.f; Edge += 2.f)
			{
				AddBox(FVector(0.f, Edge * (DeckW * 0.5f - 12.f), DeckZ + 92.f),
					FRotator::ZeroRotator, FVector(Span, 10.f, 12.f), Wood);
				// S26-WEAR3: WHICH post leans is rolled per bridge, and a side may
				// have kept its footing entirely
				const int32 LeanIdx = 1 + (int32)(BRand() * 3.f);
				const bool bThisSideLeans = BRand() > 0.25f;
				int32 PostIdx = 0;
				for (float RX = -Span * 0.5f + 150.f; RX < Span * 0.5f; RX += 300.f, ++PostIdx)
				{
					const bool bLeaning = bThisSideLeans && (PostIdx == LeanIdx);
					AddCyl(FVector(RX, Edge * (DeckW * 0.5f - 12.f), DeckZ + 52.f),
						bLeaning ? FRotator(0.f, 0.f, 14.f) : FRotator::ZeroRotator, 5.f, 80.f, Wood);
				}
			}
			// ramps at each bank: a 5 m slab pitched down to the land
			for (int32 End = 0; End < 2; ++End)
			{
				const float Dir = (End == 0) ? 1.f : -1.f;
				const float BankX = Dir * (Span * 0.5f + 240.f);
				const float BankEndZ = EndZ[End];   // S26-FIX: was BankZ - shadowed the probe lambda (C4456, error)
				const float DeckTop = BaseLoc.Z + DeckZ;
				const float Pitch = FMath::RadiansToDegrees(FMath::Atan2(DeckTop - BankEndZ, 480.f));
				AddBox(FVector(BankX + Dir * 180.f, 0.f, (DeckTop + BankEndZ) * 0.5f - BaseLoc.Z),
					FRotator(Dir * Pitch, 0.f, 0.f), FVector(520.f, DeckW, 26.f), Wood);
			}

			// S26-WEAR5: a supply crate came off a truck at one ramp - body
			// tipped on its corner, the lid flung against it, three planks
			// sprung out across the dirt
			if (BRand() > 0.4f)
			{
				UMaterialInterface* CrateMat = WarMat(this, TEXT("SupplyCrate"), FLinearColor::White, 1.f);
				if (!CrateMat) CrateMat = Wood;
				const float CargoSide = (BRand() > 0.5f) ? 1.f : -1.f;
				const float CargoX = CargoSide * (Span * 0.5f + 330.f);
				const float CargoY = (BRand() > 0.5f ? 1.f : -1.f) * (DeckW * 0.5f + 70.f);
				const float CargoZ = GroundZ(FVector(CargoX, CargoY, 0.f)) - BaseLoc.Z;
				AddBox(FVector(CargoX, CargoY, CargoZ + 28.f), FRotator(11.f, BRand() * 360.f, 0.f),
					FVector(86.f, 62.f, 55.f), CrateMat);
				AddBox(FVector(CargoX + 45.f, CargoY + (CargoY > 0.f ? 65.f : -65.f), CargoZ + 4.f),
					FRotator(0.f, BRand() * 90.f, 76.f), FVector(90.f, 64.f, 4.f), CrateMat);
				for (int32 Pi = 0; Pi < 3; ++Pi)
				{
					AddBox(FVector(CargoX + BRand() * 160.f - 80.f, CargoY + BRand() * 200.f - 100.f, CargoZ + 3.f),
						FRotator(0.f, BRand() * 360.f, BRand() * 8.f - 4.f), FVector(60.f, 12.f, 4.f), Wood);
				}
			}

			// S26-WEAR2: the crossing was fought over - brass on both banks
			// and stitched down the deck itself, all in the one HISM
			ShellRing(FVector(Span * 0.5f + 560.f, 0.f, 0.f), 60.f, 300.f, 8);
			ShellRing(FVector(-Span * 0.5f - 560.f, 0.f, 0.f), 60.f, 300.f, 8);
			{
				// on-deck casings sit at a COMPUTED deck height - GroundZ
				// traces past our own deck (the actor ignores itself), so the
				// plank top comes from the geometry, not a probe
				for (int32 I = 0; I < 10; ++I)
				{
				ShellState = ShellState * 1103515245u + 12345u;
				const float SX = -Span * 0.45f + (float)((ShellState >> 8) & 0xFFu) * ((Span * 0.9f) / 255.f);
				ShellState = ShellState * 1103515245u + 12345u;
				const float SY = (float)((ShellState >> 8) & 0xFFu) * ((DeckW - 90.f) / 255.f) - (DeckW - 90.f) * 0.5f;
				ShellState = ShellState * 1103515245u + 12345u;
				const float Yaw = (float)((ShellState >> 8) & 0xFFu) * (360.f / 255.f);
				const FVector Local(SX, SY, DeckZ + 18.f);   // plank top (16) + casing radius
				AddShell(BaseLoc + Local.RotateAngleAxis(BaseRot.Yaw, FVector::UpVector), Yaw);
				}
			}
			break;
		}

		case EWarWorkPreset::WatchTower:
		{
			// four legs, a platform, an open-front cab (the model's facing is
			// the watch cone), and a roof. Local +X = the watched direction.
			// S26-MESH2: X cross-braces on every wall and a steel-plate cab -
			// the tower reads as built structure, not stacked boxes.
			UMaterialInterface* Mat = WarMat(this, TEXT("CorrugatedRust"), OliveDrab, 2.f);        // S26-TEX3
			UMaterialInterface* PlateMat = WarMat(this, TEXT("MetalPlate"), FLinearColor(0.85f, 0.87f, 0.80f, 1.f), 2.f);   // S26-TEX3
			if (!Mat) Mat = Cache->GetDefaultBasicMaterial();
			if (!PlateMat) PlateMat = Mat;

			const float LegH = 640.f;
			for (float X = -1.f; X <= 1.f; X += 2.f)
			{
				for (float Y = -1.f; Y <= 1.f; Y += 2.f)
				{
					AddCyl(FVector(X * 135.f, Y * 135.f, LegH * 0.5f), FRotator::ZeroRotator, 24.f, LegH, Mat);
				}
			}
			// S26-MESH2: X cross-braces - two diagonals per wall, all four walls
			const float BraceAng = FMath::RadiansToDegrees(FMath::Atan2(270.f, 560.f));
			for (float Side = -1.f; Side <= 1.f; Side += 2.f)
			{
				for (float Diag = -1.f; Diag <= 1.f; Diag += 2.f)
				{
					AddBox(FVector(Side * 135.f, 0.f, LegH * 0.5f), FRotator(0.f, 0.f, Diag * BraceAng), FVector(16.f, 16.f, 660.f), Mat);
					AddBox(FVector(0.f, Side * 135.f, LegH * 0.5f), FRotator(Diag * BraceAng, 0.f, 0.f), FVector(16.f, 16.f, 660.f), Mat);
				}
			}
			// cross-brace ring at knee height
			AddBox(FVector(0.f, 0.f, LegH * 0.45f), FRotator::ZeroRotator, FVector(300.f, 300.f, 18.f), Mat);
			// platform
			AddBox(FVector(0.f, 0.f, LegH + 16.f), FRotator::ZeroRotator, FVector(370.f, 370.f, 30.f), PlateMat);
			// S26-STAIR: a real staircase - two flights, a landing, stringers and
			// rails, switchbacking up the back. Nobody climbs a ladder to a watch
			// post carrying a rifle; they walk up.
			// S26-LOGIC: the rise is MEASURED - the ground at the stair foot is
			// traced, the step height is the actual rise over 24 steps, and the
			// stringer pitch follows it. On a slope the stairs still land exactly
			// on the platform top instead of floating or burying.
			{
				const float StepRun = 28.f;
				const int32 StepsPerFlight = 12;
				const float FlightRun = StepsPerFlight * StepRun;      // 336 cm of run per flight
				const float StartX = -195.f;                           // just off the platform edge
				const float YA = 62.f, YB = -62.f;                     // the two flight lanes
				const float FootWorldZ = GroundZ(FVector(StartX - 60.f, YA, 0.f));   // the stair's own ground
				const float FootZ = FootWorldZ - BaseLoc.Z;            // ...in tower-local Z
				const float TotalRise = (LegH + 31.f) - FootZ;         // platform top, from the foot
				const float RisePerStep = FMath::Clamp(TotalRise / (StepsPerFlight * 2.f), 16.f, 34.f);
				const float FlightRise = RisePerStep * StepsPerFlight;
				const float PitchDeg = FMath::RadiansToDegrees(FMath::Atan2(FlightRise, FlightRun));
				const float FlightDiag = FMath::Sqrt(FlightRun * FlightRun + FlightRise * FlightRise);
				// flight A: away from the tower, climbing
				for (int32 i = 0; i < StepsPerFlight; ++i)
				{
					// S26-WEAR: tread six is kicked loose and sags - a staircase
					// people actually climb, not a stair machine
					const bool bLooseTread = (i == 5);
					AddBox(FVector(StartX - (i + 0.5f) * StepRun, YA, FootZ + (i + 0.5f) * RisePerStep - (bLooseTread ? 3.f : 0.f)),
						bLooseTread ? FRotator(-6.f, 3.f, 5.f) : FRotator::ZeroRotator,
						FVector(StepRun, 112.f, 8.f), PlateMat);
				}
				// flight B: the return, climbing to the platform top
				for (int32 i = 0; i < StepsPerFlight; ++i)
				{
					AddBox(FVector(StartX - FlightRun + (i + 1.5f) * StepRun, YB,
						FootZ + FlightRise + (i + 0.5f) * RisePerStep),
						FRotator::ZeroRotator, FVector(StepRun, 112.f, 8.f), PlateMat);
				}
				// stringers under both flights, pitched to the MEASURED rise
				for (float SY = -48.f; SY <= 48.f; SY += 96.f)
				{
					AddBox(FVector(StartX - FlightRun * 0.5f, YA + SY, FootZ + FlightRise * 0.5f),
						FRotator(-PitchDeg, 0.f, 0.f), FVector(FlightDiag, 10.f, 18.f), Mat);
					AddBox(FVector(StartX - FlightRun * 0.5f, YB + SY, FootZ + FlightRise * 1.5f),
						FRotator(PitchDeg, 0.f, 0.f), FVector(FlightDiag, 10.f, 18.f), Mat);
				}
				// the landing at the far turn, on legs that reach ITS ground
				AddBox(FVector(StartX - FlightRun - 62.f, 0.f, FootZ + FlightRise + 6.f),
					FRotator::ZeroRotator, FVector(124.f, 236.f, 12.f), PlateMat);
				for (float LY = -1.f; LY <= 1.f; LY += 2.f)
				{
					const FVector LegAt(StartX - FlightRun - 105.f, LY * 95.f, 0.f);
					const float LegGround = GroundZ(LegAt);
					const float LegTop = FootWorldZ + FlightRise;
					const float LegH2 = FMath::Max(LegTop - LegGround + 20.f, 60.f);
					AddCyl(FVector(LegAt.X, LegAt.Y, LegGround + LegH2 * 0.5f - BaseLoc.Z),
						FRotator::ZeroRotator, 7.f, LegH2, Mat);
				}
				AddBox(FVector(StartX - FlightRun - 122.f, 0.f, FootZ + FlightRise + 96.f),
					FRotator::ZeroRotator, FVector(6.f, 236.f, 6.f), PlateMat);
				// stair rails: sloped boxes parallel to the flights, outer side
				AddBox(FVector(StartX - FlightRun * 0.5f, YA + 62.f, FootZ + FlightRise * 0.5f + 92.f),
					FRotator(-PitchDeg, 0.f, 0.f), FVector(FlightDiag, 6.f, 6.f), PlateMat);
				AddBox(FVector(StartX - FlightRun * 0.5f, YB - 62.f, FootZ + FlightRise * 1.5f + 92.f),
					FRotator(PitchDeg, 0.f, 0.f), FVector(FlightDiag, 6.f, 6.f), PlateMat);
				for (float RP = 0.f; RP <= 1.f; RP += 1.f)
				{
					AddCyl(FVector(StartX - RP * FlightRun, YA + 62.f, FootZ + RP * FlightRise + 45.f),
						FRotator::ZeroRotator, 4.f, 90.f, PlateMat);
					AddCyl(FVector(StartX - RP * FlightRun, YB - 62.f, FootZ + FlightRise + RP * FlightRise + 45.f),
						FRotator::ZeroRotator, 4.f, 90.f, PlateMat);
				}
			}
			// S26-STAIR: the cab interior - a bench along the back wall and a map
			// table in the corner. A post someone LIVES in, not just stands on.
			AddBox(FVector(-152.f, 94.f, LegH + 31.f + 20.f), FRotator::ZeroRotator, FVector(24.f, 150.f, 40.f), PlateMat);   // S26-FIXALL: on the RIGHT wall segment, clear of the door
			AddBox(FVector(-152.f, 94.f, LegH + 31.f + 78.f), FRotator::ZeroRotator, FVector(10.f, 150.f, 76.f), PlateMat);
			AddCyl(FVector(60.f, 110.f, LegH + 31.f + 45.f), FRotator::ZeroRotator, 5.f, 90.f, Mat);
			AddBox(FVector(60.f, 110.f, LegH + 31.f + 94.f), FRotator::ZeroRotator, FVector(70.f, 70.f, 8.f), PlateMat);
			// S26-SURF: handrails on the platform - back and sides; the front stays
			// open so the watch cone reads. A work deck, not a diving board.
			for (float Side = -1.f; Side <= 1.f; Side += 2.f)
			{
				AddBox(FVector(0.f, Side * 178.f, LegH + 121.f), FRotator::ZeroRotator, FVector(370.f, 8.f, 8.f), PlateMat);
				AddBox(FVector(-178.f, Side * 178.f, LegH + 76.f), FRotator::ZeroRotator, FVector(8.f, 8.f, 90.f), PlateMat);
				AddBox(FVector(178.f, Side * 178.f, LegH + 76.f), FRotator::ZeroRotator, FVector(8.f, 8.f, 90.f), PlateMat);
			}
			// S26-FIXALL SWEEP: the back handrail and its centre post used to sit
			// INSIDE the solid back wall (invisible). The doorway would leave them
			// floating across the opening - the wall segments are the guard now.
			AddCyl(FVector(178.f, 0.f, LegH + 76.f), FRotator::ZeroRotator, 4.f, 90.f, PlateMat);
			// cab: back wall + two side walls, open toward the watched land.
			// S26-FIXALL: the wall is SPLIT around a doorway where stair flight B
			// arrives. SWEEP CORRECTION: flight B climbs in lane YB = -62 (treads
			// span Y -118..-6), NOT on the cab centre - a centre-cut door left
			// half the stair lane buried in wall. Door Y -132..8 (140 wide,
			// centred on the lane), lintel bottom at LegH+212 = 181 cm of
			// headroom above the LegH+31 walkway. Left segment 48 wide, right 172.
			AddBox(FVector(-170.f, -156.f, LegH + 132.f), FRotator::ZeroRotator, FVector(28.f, 48.f, 220.f), PlateMat);
			AddBox(FVector(-170.f, 94.f, LegH + 132.f), FRotator::ZeroRotator, FVector(28.f, 172.f, 220.f), PlateMat);
			AddBox(FVector(-170.f, -62.f, LegH + 227.f), FRotator::ZeroRotator, FVector(28.f, 140.f, 30.f), PlateMat);   // lintel: door top .. wall top
			// S26-WEAR: a tower that has BEEN shot at. Rust bleeding down the
			// legs, a darker welded patch over an old hit, bullet pocks across
			// the cab and rail. The jitter is derived from the tower's own
			// location, so no two towers wear identically.
			{
				uint32 WearState = (uint32)(FMath::Abs(BaseLoc.X * 0.37f) + FMath::Abs(BaseLoc.Y * 0.11f)) | 1u;
				auto WearRand = [&WearState]() -> float
				{
					WearState = WearState * 1103515245u + 12345u;   // tiny deterministic LCG (unsigned wrap is defined)
					return (float)((WearState >> 16) & 0xFFFFu) / 65535.f;
				};
				UMaterialInterface* RustPatchMat = WarMat(this, TEXT("CorrugatedRust"), FLinearColor(0.45f, 0.30f, 0.20f, 1.f), 1.f);
				UMaterialInterface* PockMat = WarMat(this, TEXT("ScorchedMetal"), FLinearColor(0.06f, 0.055f, 0.045f, 1.f), 1.f);
				UMaterialInterface* WeldMat = WarMat(this, TEXT("MetalPlate"), FLinearColor(0.58f, 0.60f, 0.56f, 1.f), 1.f);
				if (!RustPatchMat) RustPatchMat = Mat;
				if (!PockMat) PockMat = Mat;
				if (!WeldMat) WeldMat = PlateMat;
				// S26-WEAR3: every mark is ROLLED - towers differ in WHAT they
				// survived, not just where the marks sit. One bleeds and is
				// patched; the next took it across the rail and buckled.
				// rust bleeding down the legs (corner legs face outward at 45 deg)
				AddBox(FVector(117.f, 117.f, 220.f + WearRand() * 160.f), FRotator(0.f, 45.f, 0.f), FVector(2.f, 46.f, 90.f), RustPatchMat);
				if (WearRand() > 0.35f)
				{
					AddBox(FVector(-117.f, 117.f, 300.f + WearRand() * 140.f), FRotator(0.f, -45.f, 0.f), FVector(2.f, 40.f, 76.f), RustPatchMat);
				}
				// the welded patch over an old hit
				if (WearRand() > 0.30f)
				{
					AddBox(FVector(-152.f, 40.f + WearRand() * 110.f, LegH + 170.f), FRotator(0.f, 0.f, 1.5f), FVector(4.f, 58.f, 66.f), WeldMat);   // S26-FIXALL: on the RIGHT wall segment, clear of the door
				}
				// pocks across the cab's inner back wall - how many depends on the fight
				const int32 WallPocks = 2 + (int32)(WearRand() * 3.f);
				for (int32 Pi = 0; Pi < WallPocks; ++Pi)
				{
					AddCyl(FVector(-155.f, (Pi == 2 ? -158.f : 45.f + Pi * 55.f) + WearRand() * 20.f, LegH + 165.f + WearRand() * 60.f),   // S26-FIXALL: on the segments, not the door
						FRotator(0.f, 90.f, 0.f), 3.5f, 1.2f, PockMat);
				}
				// S26-WEAR5: soot runs down the wall from the hits - what the
				// bullets started, the smoke finished
				if (WearRand() > 0.5f)
				{
					for (int32 Si = 0; Si < 2; ++Si)
					{
						AddBox(FVector(-153.f, (Si == 0 ? -156.f : 95.f) + WearRand() * 22.f, LegH + 108.f),   // S26-FIXALL: on the segments, not the door
							FRotator::ZeroRotator, FVector(1.5f, 14.f, 90.f), PockMat);
					}
				}
				// pocks on the side rail
				if (WearRand() > 0.45f)
				{
					for (int32 Pi = 0; Pi < 2; ++Pi)
					{
						AddCyl(FVector(-60.f + Pi * 120.f, 179.f, LegH + 119.f),
							FRotator(90.f, 0.f, 0.f), 3.5f, 1.2f, PockMat);
					}
				}
				// rust streaks hanging off the platform edge
				if (WearRand() > 0.40f)
				{
					AddBox(FVector(150.f, 150.f, LegH - 40.f), FRotator::ZeroRotator, FVector(4.f, 4.f, 70.f), PockMat);
				}
				if (WearRand() > 0.60f)
				{
					AddBox(FVector(-150.f, 150.f, LegH - 55.f), FRotator::ZeroRotator, FVector(4.f, 4.f, 55.f), PockMat);
				}
				// S26-WEAR3: a RECENT hit - the rail itself buckled down and the
				// platform edge took the burst. Roughly one tower in four.
				if (WearRand() > 0.72f)
				{
					AddBox(FVector(80.f, 178.f, LegH + 112.f), FRotator(0.f, 0.f, 34.f), FVector(150.f, 8.f, 8.f), PlateMat);
					for (int32 Pi = 0; Pi < 3; ++Pi)
					{
						AddCyl(FVector(30.f + Pi * 60.f, 178.f, LegH + 119.f),
							FRotator(90.f, 0.f, 0.f), 3.5f, 1.2f, PockMat);
					}
				}
			}
			AddBox(FVector(0.f, 170.f, LegH + 132.f), FRotator::ZeroRotator, FVector(340.f, 28.f, 220.f), PlateMat);
			AddBox(FVector(0.f, -170.f, LegH + 132.f), FRotator::ZeroRotator, FVector(340.f, 28.f, 220.f), PlateMat);
			// roof + mast
			AddBox(FVector(0.f, 0.f, LegH + 254.f), FRotator::ZeroRotator, FVector(390.f, 390.f, 24.f), PlateMat);
			AddCyl(FVector(-120.f, 0.f, LegH + 320.f), FRotator::ZeroRotator, 7.f, 130.f, Mat);
			// S26-LIFE: one guy wire from the masthead to a ground anchor - a mast
			// that size is stayed in real life, and the diagonal reads instantly
			{
				const float MastTop = LegH + 385.f;
				const float Run = 400.f;
				const float GuyLen = FMath::Sqrt(Run * Run + MastTop * MastTop);
				const float GuyAng = FMath::RadiansToDegrees(FMath::Atan2(MastTop, Run));
				AddBox(FVector(-120.f + Run * 0.5f, 0.f, MastTop * 0.5f), FRotator(-GuyAng, 0.f, 0.f),
					FVector(5.f, 5.f, GuyLen), Mat);
				AddBox(FVector(-120.f + Run, 0.f, 10.f), FRotator::ZeroRotator, FVector(22.f, 22.f, 20.f), Mat);
			}
			// S26-WEAR2: the tower was shot at and held - brass spilled around
			// its legs where the reply came from
			ShellRing(FVector::ZeroVector, 200.f, 480.f, 14);
			break;
		}

		case EWarWorkPreset::TankHull:
		case EWarWorkPreset::DeadHull:
		{
			// their armor, hull-down at the rim: tracks, hull, turret, barrel.
			// Local +X = gun direction. A DeadHull is the same tank after the
			// war finished with it: burnt black, turret thrown 25 degrees off,
			// barrel drooped.
			const bool bDead = (Preset == EWarWorkPreset::DeadHull);
			UMaterialInterface* Mat = WarMat(this, bDead ? TEXT("ScorchedMetal") : TEXT("OliveArmor"), bDead ? BurntOut : EnemyArmor, 1.5f);   // S26-TEX3
			if (!Mat) Mat = Cache->GetDefaultBasicMaterial();

			const float Sink = bGroundSnap ? 18.f : 0.f;   // tracks settle into the dirt
			AddBox(FVector(0.f, 150.f, 50.f - Sink), FRotator::ZeroRotator, FVector(560.f, 95.f, 100.f), Mat);
			AddBox(FVector(0.f, -150.f, 50.f - Sink), FRotator::ZeroRotator, FVector(560.f, 95.f, 100.f), Mat);
			AddBox(FVector(-20.f, 0.f, 140.f - Sink * 0.5f), FRotator::ZeroRotator, FVector(510.f, 300.f, 120.f), Mat);
			const float TurretYaw = bDead ? 25.f : 0.f;
			const FRotator TurretRot(0.f, TurretYaw, 0.f);
			// S26-MESH2: a round turret reads TANK; a box reads crate
			AddCyl(FVector(40.f, 0.f, 268.f - Sink * 0.5f), TurretRot, 118.f, 86.f, Mat);
			// S26-MESH2: sloped glacis off the hull front
			AddBox(FVector(255.f, 0.f, 95.f - Sink * 0.5f), FRotator(-32.f, 0.f, 0.f), FVector(150.f, 300.f, 22.f), Mat);
			// barrel: cylinder along +X (rotated off Z), drooped if dead
			const float BarrelPitch = 90.f + (bDead ? 14.f : 0.f);   // +Z -> +X at 90; droop tips past level
			const FVector BarrelBase = FVector(40.f, 0.f, 262.f - Sink * 0.5f)
				+ TurretRot.RotateVector(FVector(120.f, 0.f, 0.f));
			const float Rad = FMath::DegreesToRadians(TurretYaw);
			AddCyl(FVector(BarrelBase.X + 165.f * FMath::Cos(Rad),
				BarrelBase.Y + 165.f * FMath::Sin(Rad), BarrelBase.Z),
				FRotator(BarrelPitch, TurretYaw, 0.f), 13.f, 330.f, Mat);
			// a dead hull settles nose-down and its stowage burns off, leaving
			// a scorch skirt
			if (bDead)
			{
				AddBox(FVector(0.f, 0.f, 8.f), FRotator::ZeroRotator, FVector(640.f, 420.f, 14.f), Mat);
			}
			// S26-WEAR2: a hull that fired leaves brass around it; a dead one
			// is a firefight's centre of gravity
			ShellRing(FVector::ZeroVector, 150.f, 420.f, bDead ? 18 : 8);
			break;
		}
	}
}

#include "Actors/TacticalTrenchSplineActor.h"
#include "Actors/MountedTurretActor.h"
#include "Actors/AmmoCrateActor.h"
#include "Actors/FirstAidKitActor.h"
#include "Performance/SquadAIAssetCacheSubsystem.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/World.h"
#include "Engine/StaticMeshActor.h"
#include "Materials/MaterialInstanceDynamic.h"

namespace
{
	// S6-T: one runtime DMI tint per build — sandbags read as one sun-bleached
	// batch, slightly different trench to trench. Silent on param-less materials.
	UMaterialInterface* TintTrenchMaterial(UMaterialInterface* Base, float Offset, UObject* Outer)
	{
		if (!Base || Offset == 0.f) return Base;
		if (UMaterialInstanceDynamic* Dyn = UMaterialInstanceDynamic::Create(Base, Outer))
		{
			const FLinearColor Tone(1.f + Offset, 1.f + Offset * 0.7f, 1.f + Offset * 0.45f, 1.f);
			static const FName Candidates[] = { TEXT("Color"), TEXT("BaseColor"), TEXT("Tint"), TEXT("BaseColorTint"), TEXT("Albedo"), TEXT("Colour") };
			for (const FName& Param : Candidates)
			{
				Dyn->SetVectorParameterValue(Param, Tone);
			}
			return Dyn;
		}
		return Base;
	}
}

ATacticalTrenchSplineActor::ATacticalTrenchSplineActor()
{
	PrimaryActorTick.bCanEverTick = false;

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SetRootComponent(SceneRoot);

	TrenchSpline = CreateDefaultSubobject<USplineComponent>(TEXT("TrenchSpline"));
	TrenchSpline->SetupAttachment(SceneRoot);
	TrenchSpline->SetClosedLoop(false);

	HISM_Sandbags = CreateDefaultSubobject<UHierarchicalInstancedStaticMeshComponent>(TEXT("HISM_Sandbags"));
	HISM_Sandbags->SetupAttachment(SceneRoot);
	HISM_Sandbags->SetCollisionProfileName(TEXT("BlockAllDynamic"));
}

void ATacticalTrenchSplineActor::BeginPlay()
{
	Super::BeginPlay();
	BuildTrench();
}

void ATacticalTrenchSplineActor::BuildTrench()
{
	ClearTrench();

	UWorld* World = GetWorld();
	if (!World || !TrenchSpline) return;

	const float TotalLength = TrenchSpline->GetSplineLength();
	if (TotalLength <= 50.0f) return;

	// S6-T: reseed variation + tone per build
	TrenchStream = FRandomStream(TrenchSeed);
	CurrentToneOffset = (bSeededVariation && ToneJitter > 0.f) ? TrenchStream.FRandRange(-ToneJitter, ToneJitter) : 0.f;

	USquadAIAssetCacheSubsystem* Cache = USquadAIAssetCacheSubsystem::Get(this);
	UStaticMesh* MeshToUse = CustomSandbagMesh;
	if (!MeshToUse)
	{
		MeshToUse = Cache ? Cache->GetCubeMesh() : LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cube.Cube"));
	}

	UMaterialInterface* MatToApply = SandbagMaterialOverride;
	if (!MatToApply && Cache)
	{
		MatToApply = Cache->GetDefaultBasicMaterial();
	}
	MatToApply = TintTrenchMaterial(MatToApply, CurrentToneOffset, this); // S6-T

	if (bUseHISMInstancing && HISM_Sandbags)
	{
		HISM_Sandbags->ClearInstances();
		if (MeshToUse) HISM_Sandbags->SetStaticMesh(MeshToUse);
		if (MatToApply) HISM_Sandbags->SetMaterial(0, MatToApply);
	}

	const float Spacing = FMath::Clamp(SegmentSpacing, 100.f, 1000.f);
	const int32 NumSegments = FMath::Max(1, FMath::FloorToInt(TotalLength / Spacing));

	FActorSpawnParameters SpawnParams;
	// S5-14c: WP/lifetime ownership for all spawned children.
	SpawnParams.Owner = this;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;

	float NextSupplyDist = SupplyCacheInterval;

	// S6-T: unified placement — HISM instance or spawned actor, same call site
	auto PlaceBag = [&](const FVector& Loc, const FRotator& Rot, const FVector& Scl)
	{
		if (bUseHISMInstancing && HISM_Sandbags)
		{
			HISM_Sandbags->AddInstance(FTransform(Rot, Loc, Scl), true);
			return;
		}
		AStaticMeshActor* B = World->SpawnActor<AStaticMeshActor>(AStaticMeshActor::StaticClass(), Loc, Rot, SpawnParams);
		if (B && B->GetStaticMeshComponent())
		{
			B->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
			if (MeshToUse)
			{
				B->GetStaticMeshComponent()->SetStaticMesh(MeshToUse);
				B->GetStaticMeshComponent()->SetRelativeScale3D(Scl);
				B->GetStaticMeshComponent()->SetCollisionProfileName(TEXT("BlockAllDynamic"));
			}
			if (MatToApply)
			{
				B->GetStaticMeshComponent()->SetMaterial(0, MatToApply);
			}
			SpawnedElements.Add(B);
		}
	};

	for (int32 i = 0; i <= NumSegments; ++i)
	{
		const float Distance = FMath::Min(i * Spacing, TotalLength);
		const FVector SplinePoint = TrenchSpline->GetLocationAtDistanceAlongSpline(Distance, ESplineCoordinateSpace::World);
		const FRotator SplineRot = TrenchSpline->GetRotationAtDistanceAlongSpline(Distance, ESplineCoordinateSpace::World);
		const FVector Tangent = TrenchSpline->GetTangentAtDistanceAlongSpline(Distance, ESplineCoordinateSpace::World).GetSafeNormal();
		const FVector RightVec = FVector::CrossProduct(Tangent, FVector::UpVector).GetSafeNormal();

		// Snap to terrain surface
		FVector GroundLoc = SplinePoint;
		FHitResult Hit;
		FCollisionQueryParams Params;
		Params.AddIgnoredActor(this);
		if (World->LineTraceSingleByChannel(Hit, SplinePoint + FVector(0.f, 0.f, 300.f), SplinePoint - FVector(0.f, 0.f, 1000.f), ECC_Visibility, Params))
		{
			GroundLoc = Hit.ImpactPoint;
		}

		// 1. Sandbag barricade segment — S6-T: jitter, double tiers, gaps, debris
		const bool bBreached = bBattleGaps && bSeededVariation && i > 0 && i < NumSegments && TrenchStream.FRand() < 0.08f;
		if (bBreached)
		{
			// Battle breach: sunken partial bag leaving a ragged firing gap
			const FVector GapScl(0.45f, TrenchStream.FRandRange(0.7f, 1.0f), TrenchStream.FRandRange(0.35f, 0.5f));
			PlaceBag(GroundLoc + FVector(0.f, 0.f, 4.f),
				SplineRot + FRotator(TrenchStream.FRandRange(-7.f, 7.f), TrenchStream.FRandRange(-5.f, 5.f), 0.f), GapScl);
		}
		else
		{
			FVector SegLoc = GroundLoc;
			FRotator SegRot = SplineRot;
			FVector Scale(0.45f, 2.0f, 0.85f);
			if (bSeededVariation)
			{
				SegLoc += Tangent * TrenchStream.FRandRange(-8.f, 8.f) + RightVec * TrenchStream.FRandRange(-6.f, 6.f);
				SegRot += FRotator(TrenchStream.FRandRange(-1.5f, 1.5f), TrenchStream.FRandRange(-4.f, 4.f), TrenchStream.FRandRange(-1.5f, 1.5f));
				Scale.Y *= TrenchStream.FRandRange(0.88f, 1.12f);
				Scale.Z *= TrenchStream.FRandRange(0.92f, 1.10f);
			}
			PlaceBag(SegLoc, SegRot, Scale);

			// Second firing-tier, staggered backward — classic parapet build-up
			if (bDoubleLayerBags && bSeededVariation && TrenchStream.FRand() < 0.40f)
			{
				PlaceBag(SegLoc + FVector(0.f, 0.f, 62.f) - RightVec * TrenchStream.FRandRange(6.f, 14.f) + Tangent * TrenchStream.FRandRange(-10.f, 10.f),
					SegRot + FRotator(0.f, TrenchStream.FRandRange(-3.f, 3.f), 0.f),
					FVector(0.45f, Scale.Y * TrenchStream.FRandRange(0.65f, 0.85f), 0.85f));
			}

			// Half-buried debris bag at the wall base
			if (bBrokenBags && bSeededVariation && TrenchStream.FRand() < 0.15f)
			{
				PlaceBag(SegLoc + RightVec * TrenchStream.FRandRange(40.f, 70.f) + Tangent * TrenchStream.FRandRange(-60.f, 60.f) + FVector(0.f, 0.f, -12.f),
					SegRot + FRotator(TrenchStream.FRandRange(-8.f, 8.f), TrenchStream.FRandRange(0.f, 360.f), 0.f),
					FVector(0.45f, TrenchStream.FRandRange(0.9f, 1.3f), 0.55f));
			}
		}

		// S6-T: end caps — short perpendicular closure bags at both trench mouths
		if (bEndCaps && (i == 0 || i == NumSegments))
		{
			const float EndSign = (i == 0) ? -1.f : 1.f;
			PlaceBag(GroundLoc + Tangent * (EndSign * 90.f) + RightVec * 90.f,
				SplineRot + FRotator(0.f, 90.f, 0.f), FVector(0.45f, 1.8f, 0.85f));
		}

		// 2. Spawn Supply Caches (Ammo & First Aid) at configured intervals
		if (bSpawnSupplyCaches && Distance >= NextSupplyDist)
		{
			NextSupplyDist += SupplyCacheInterval;
			const FVector CacheLoc = GroundLoc - RightVec * 120.f + FVector(0.f, 0.f, 10.f);

			if (i % 2 == 0)
			{
				AAmmoCrateActor* Ammo = World->SpawnActor<AAmmoCrateActor>(AAmmoCrateActor::StaticClass(), CacheLoc, SplineRot, SpawnParams);
				if (Ammo)
				{
					Ammo->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
					SpawnedElements.Add(Ammo);
				}
			}
			else
			{
				AFirstAidKitActor* Kit = World->SpawnActor<AFirstAidKitActor>(AFirstAidKitActor::StaticClass(), CacheLoc, SplineRot, SpawnParams);
				if (Kit)
				{
					Kit->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
					SpawnedElements.Add(Kit);
				}
			}
		}

		// 3. Spawn Heavy Turrets at start and end of trench if requested
		if (bSpawnMountedTurretsAtEnds && (i == 0 || i == NumSegments) && TotalLength >= 1000.0f)
		{
			const FVector TurretLoc = GroundLoc + RightVec * 60.f + FVector(0.f, 0.f, 10.f);
			AMountedTurretActor* Turret = World->SpawnActor<AMountedTurretActor>(AMountedTurretActor::StaticClass(), TurretLoc, SplineRot, SpawnParams);
			if (Turret)
			{
				Turret->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
				SpawnedElements.Add(Turret);
			}
		}
	}

	UE_LOG(LogTemp, Log, TEXT("[TacticalTrenchSpline] %s generated %d trench barricade elements (HISM: %s) along %.0fm spline"),
		*GetName(), SpawnedElements.Num() + (HISM_Sandbags ? HISM_Sandbags->GetInstanceCount() : 0), bUseHISMInstancing ? TEXT("TRUE") : TEXT("FALSE"), TotalLength / 100.f);
}

void ATacticalTrenchSplineActor::ClearTrench()
{
	if (HISM_Sandbags)
	{
		HISM_Sandbags->ClearInstances();
	}

	for (AActor* Act : SpawnedElements)
	{
		if (IsValid(Act))
		{
			Act->Destroy();
		}
	}
	SpawnedElements.Empty();
}

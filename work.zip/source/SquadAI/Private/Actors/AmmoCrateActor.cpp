#include "Actors/AmmoCrateActor.h"
#include "GameFramework/SquadAIInventorySubsystem.h"
#include "HUD/QuestNativeHUD.h"
#include "Components/StaticMeshComponent.h"
#include "Components/SphereComponent.h"
#include "Components/TacticalGrenadeComponent.h"
#include "Performance/SquadAIAudioSubsystem.h"
#include "Actors/SquadAIAudioManager.h"
#include "Kismet/GameplayStatics.h"
#include "GameFramework/Pawn.h"
#include "GameFramework/PlayerController.h"
#include "Engine/World.h"
#include "UObject/ConstructorHelpers.h"
#include "UObject/UnrealType.h"

AAmmoCrateActor::AAmmoCrateActor()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 0.05f;

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SetRootComponent(SceneRoot);

	CrateMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("CrateMesh"));
	CrateMesh->SetupAttachment(SceneRoot);
	CrateMesh->SetCollisionProfileName(TEXT("BlockAllDynamic"));

	static ConstructorHelpers::FObjectFinder<UStaticMesh> CubeMesh(TEXT("/Engine/BasicShapes/Cube.Cube"));
	if (CubeMesh.Succeeded())
	{
		CrateMesh->SetStaticMesh(CubeMesh.Object);
		CrateMesh->SetRelativeScale3D(FVector(1.0f, 0.7f, 0.5f)); // Ammo crate dimensions
	}

	InteractionSphere = CreateDefaultSubobject<USphereComponent>(TEXT("InteractionSphere"));
	InteractionSphere->SetupAttachment(SceneRoot);
	InteractionSphere->SetSphereRadius(InteractionRadius);
	InteractionSphere->SetCollisionProfileName(TEXT("OverlapAllDynamic"));
	InteractionSphere->SetGenerateOverlapEvents(true);
}

void AAmmoCrateActor::BeginPlay()
{
	Super::BeginPlay();

	ApplyCustomVisuals();
	InteractionSphere->SetSphereRadius(InteractionRadius);
	InteractionSphere->OnComponentBeginOverlap.AddDynamic(this, &AAmmoCrateActor::OnOverlapBegin);
	InteractionSphere->OnComponentEndOverlap.AddDynamic(this, &AAmmoCrateActor::OnOverlapEnd);
}

void AAmmoCrateActor::ApplyCustomVisuals()
{
	if (CrateMesh)
	{
		if (CustomCrateMesh)
		{
			CrateMesh->SetStaticMesh(CustomCrateMesh);
		}
		if (CrateMaterialOverride)
		{
			CrateMesh->SetMaterial(0, CrateMaterialOverride);
		}
	}
}

void AAmmoCrateActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (CooldownTimer > 0.0f)
	{
		CooldownTimer -= DeltaTime;
	}

	// Player 'E' key interaction check while in proximity
	if (bPlayerInRange && CachedPlayerPawn.IsValid() && IsReady())
	{
		APawn* Player = CachedPlayerPawn.Get();
		if (APlayerController* PC = Cast<APlayerController>(Player->GetController()))
		{
			if (PC->WasInputKeyJustPressed(EKeys::E))
			{
				// E-arbitration: revive always wins; otherwise first claimant per press frame wins.
				AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this);
				const bool bYieldToRevive = HUD && HUD->IsReviveAvailable();
				const bool bClaimed = HUD ? HUD->TryConsumeWorldEPress() : true;
				if (!bYieldToRevive && bClaimed)
				{
					ResupplyPlayer(Player);
				}
			}
		}
	}
}

void AAmmoCrateActor::OnOverlapBegin(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
	UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	if (!OtherActor) return;

	APawn* Player = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	if (OtherActor == Player)
	{
		bPlayerInRange = true;
		CachedPlayerPawn = Player;
		UE_LOG(LogTemp, Warning, TEXT("[AmmoCrate] Player entered ammo resupply range at %s"), *GetName());
	}
}

void AAmmoCrateActor::OnOverlapEnd(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
	UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
	APawn* Player = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	if (OtherActor == Player)
	{
		bPlayerInRange = false;
		CachedPlayerPawn = nullptr;
	}
}

bool AAmmoCrateActor::ResupplyPlayer(APawn* PlayerPawn)
{
	if (!PlayerPawn || !IsReady()) return false;

	bool bResupplied = false;
	TArray<UActorComponent*> Comps;
	PlayerPawn->GetComponents(Comps);

	// 1. Refill TPWCS Pack Weapon Components
	for (UActorComponent* C : Comps)
	{
		if (!C) continue;
		const FString N = C->GetName();
		const FString CN = C->GetClass() ? C->GetClass()->GetName() : TEXT("");

		if (N.Contains(TEXT("BPC_Weapon")) || CN.Contains(TEXT("WeaponCharacter")))
		{
			for (const FName& ClipName : { FName(TEXT("Ammo Clip Current")), FName(TEXT("AmmoClipCurrent")), FName(TEXT("ClipAmmo")) })
			{
				if (FIntProperty* P = FindFProperty<FIntProperty>(C->GetClass(), ClipName))
				{
					P->SetPropertyValue_InContainer(C, MaxClipAmmo);
					bResupplied = true;
					break;
				}
			}

			for (const FName& AmmoName : { FName(TEXT("Ammo Current")), FName(TEXT("AmmoCurrent")), FName(TEXT("ReserveAmmo")), FName(TEXT("Ammo")) })
			{
				if (FIntProperty* P = FindFProperty<FIntProperty>(C->GetClass(), AmmoName))
				{
					P->SetPropertyValue_InContainer(C, MaxReserveAmmo);
					bResupplied = true;
					break;
				}
			}
		}
	}

	// 2. Refill Tactical Grenades & Inventory Arsenal
	if (UTacticalGrenadeComponent* GrenadeComp = PlayerPawn->FindComponentByClass<UTacticalGrenadeComponent>())
	{
		GrenadeComp->RefillGrenades(2, 2);
		bResupplied = true;
	}
	if (USquadAIInventorySubsystem* Inv = USquadAIInventorySubsystem::Get(this))
	{
		for (FSquadInventoryWeaponItem& W : Inv->Weapons)
		{
			W.ClipAmmo = W.MaxClipAmmo;
			W.ReserveAmmo = FMath::Max(W.ReserveAmmo, W.MaxClipAmmo * 6);
		}
		Inv->FragGrenades = FMath::Max(2, Inv->FragGrenades);
		Inv->SmokeGrenades = FMath::Max(2, Inv->SmokeGrenades);
		bResupplied = true;
	}

	// 3. Play satisfying metallic ammo reload sound
	USoundBase* Snd = ResupplySound;
	if (!Snd)
	{
		if (USquadAIAudioSubsystem* AudioSys = USquadAIAudioSubsystem::Get(this))
		{
			if (ASquadAIAudioManager* Mgr = AudioSys->GetActiveAudioManager())
			{
				Snd = Mgr->TacticalRadioClick.Get();
			}
		}
	}

	if (Snd && GetWorld())
	{
		UGameplayStatics::PlaySoundAtLocation(GetWorld(), Snd, GetActorLocation(), 1.0f);
	}

	CooldownTimer = CooldownSeconds;
	OnAmmoResupplied.Broadcast(PlayerPawn);

	UE_LOG(LogTemp, Warning, TEXT("[AmmoCrate] %s successfully resupplied ammo for %s (Clip: %d, Reserve: %d)"),
		*GetName(), *GetNameSafe(PlayerPawn), MaxClipAmmo, MaxReserveAmmo);

	return bResupplied;
}

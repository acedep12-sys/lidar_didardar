// TutorialRangeActor.cpp — S18-TUT
#include "Tutorial/TutorialRangeActor.h"
#include "Tutorial/SquadAITutorialSubsystem.h"
#include "Tactical/TacticalGrenadeActor.h"
#include "Components/StaticMeshComponent.h"
#include "Components/SphereComponent.h"
#include "GameFramework/ProjectileMovementComponent.h" // S19-BARREL: grenade velocity in the mouth test
#include "Engine/StaticMesh.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "CollisionQueryParams.h"
#include "Engine/OverlapResult.h" // S18-PERF: FOverlapResult lives here in UE5
#include "UObject/ConstructorHelpers.h"
#include "Kismet/GameplayStatics.h"
#include "Misc/PackageName.h"        // S19-MAT: FPackageName::DoesPackageExist
#include "Materials/MaterialInterface.h"

// ===========================================================================
//  S19-MAT: give the range props real materials
//  The cans and the barrel were engine cylinders with no material at all, so
//  they rendered with the default engine grey — no texture, no response to
//  light, and almost invisible against sand. Look for the trench material
//  pack that scripts/SquadAI_ImportTrenchMaterials.py creates; if it has not
//  been imported yet, say so once instead of spamming.
// ===========================================================================
namespace
{
	/** Load /Game/SquadAI/TrenchMaterials/<AssetName> if the pack is present. */
	UMaterialInterface* LoadTrenchMaterial(const TCHAR* AssetName)
	{
		const FString Asset(AssetName);
		if (Asset.IsEmpty())
		{
			return nullptr;
		}
		const FString PackagePath = FString::Printf(TEXT("/Game/SquadAI/TrenchMaterials/%s"), *Asset);
		if (!FPackageName::DoesPackageExist(PackagePath))
		{
			return nullptr;
		}
		const FString ObjectPath = FString::Printf(TEXT("%s.%s"), *PackagePath, *Asset);
		return Cast<UMaterialInterface>(
			StaticLoadObject(UMaterialInterface::StaticClass(), nullptr, *ObjectPath));
	}

	/** Cache the misses too: DoesPackageExist() is not free, and this runs on
	 *  every prop spawn. */
	UMaterialInterface* CachedTrenchMaterial(const TCHAR* AssetName)
	{
		static TMap<FString, TWeakObjectPtr<UMaterialInterface>> Cache;
		static TSet<FString> KnownMissing;

		const FString Key(AssetName);
		if (KnownMissing.Contains(Key))
		{
			return nullptr;
		}
		if (const TWeakObjectPtr<UMaterialInterface>* Found = Cache.Find(Key))
		{
			return Found->Get();
		}
		UMaterialInterface* M = LoadTrenchMaterial(AssetName);
		if (M)
		{
			Cache.Add(Key, TWeakObjectPtr<UMaterialInterface>(M));
		}
		else
		{
			KnownMissing.Add(Key);
		}
		return M;
	}
}

UMaterialInterface* ATutorialRangeActor::ResolveTrenchMaterial(const FString& AssetName)
{
	return CachedTrenchMaterial(*AssetName);
}

// ===========================================================================
//  Can
// ===========================================================================
ATutorialTargetCan::ATutorialTargetCan()
{
	PrimaryActorTick.bCanEverTick = false;

	CanMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("CanMesh"));
	RootComponent = CanMesh;
	CanMesh->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
	CanMesh->SetCollisionObjectType(ECC_PhysicsBody);
	CanMesh->SetCollisionResponseToAllChannels(ECR_Block);
	CanMesh->SetSimulatePhysics(false);
	CanMesh->SetNotifyRigidBodyCollision(true);

	// Engine cylinder at can scale; the range actor can override the mesh.
	static ConstructorHelpers::FObjectFinder<UStaticMesh> CylinderMesh(TEXT("/Engine/BasicShapes/Cylinder.Cylinder"));
	if (CylinderMesh.Succeeded())
	{
		CanMesh->SetStaticMesh(CylinderMesh.Object);
		CanMesh->SetRelativeScale3D(FVector(0.12f, 0.12f, 0.17f));
	}

	SetCanBeDamaged(true);
}

void ATutorialTargetCan::BeginPlay()
{
	Super::BeginPlay();

	// S19-MAT: the can shipped as a bare engine cylinder with no material, so
	// it rendered default grey — flat, untextured and hard to pick out against
	// sand. Use the trench ammo-can material when the pack is present.
	if (CanMesh && CanMesh->GetNumOverrideMaterials() == 0)
	{
		if (UMaterialInterface* M = CachedTrenchMaterial(TEXT("M_TrenchAmmoCan")))
		{
			CanMesh->SetMaterial(0, M);
		}
		else
		{
			UE_LOG(LogTemp, Log, TEXT("[S19-MAT] M_TrenchAmmoCan not found — tutorial cans keep the default material. Run scripts/SquadAI_ImportTrenchMaterials.py, or set CanMaterialOverride on the range actor."));
		}
	}

	OnTakeAnyDamage.AddDynamic(this, &ATutorialTargetCan::HandleAnyDamage);
	OnTakePointDamage.AddDynamic(this, &ATutorialTargetCan::HandlePointDamage);
}

void ATutorialTargetCan::HandleAnyDamage(AActor*, float Damage, const UDamageType*, AController*, AActor*)
{
	if (Damage > 0.f)
	{
		RegisterHit(GetActorForwardVector() * -1.f);
	}
}

void ATutorialTargetCan::HandlePointDamage(AActor*, float Damage, AController*, FVector,
	UPrimitiveComponent*, FName, FVector ShotDirection, const UDamageType*, AActor*)
{
	if (Damage > 0.f)
	{
		RegisterHit(ShotDirection);
	}
}

void ATutorialTargetCan::RegisterHit(const FVector& ImpactDirection)
{
	if (bKnockedDown)
	{
		return;
	}
	bKnockedDown = true;

	// Knock it off the berm so the hit reads instantly.
	if (CanMesh)
	{
		CanMesh->SetCollisionEnabled(ECollisionEnabled::PhysicsOnly);
		CanMesh->SetSimulatePhysics(true);
		const FVector Dir = ImpactDirection.IsNearlyZero() ? FVector(1.f, 0.f, 0.3f) : ImpactDirection.GetSafeNormal();
		// S19-FIX: was 18000 — that is 180 m/s, which fired the cans into orbit
		// and off the map before the player could see them fall. 800 cm/s = 8 m/s,
		// a believable knock-off-the-berm tumble.
		CanMesh->AddImpulse((Dir + FVector(0.f, 0.f, 0.45f)) * 800.f, NAME_None, true);
	}

	if (USquadAITutorialSubsystem* Tut = USquadAITutorialSubsystem::Get(this))
	{
		Tut->NotifyCanDestroyed();
	}
	UE_LOG(LogTemp, Warning, TEXT("[S18-TUT] Tutorial can knocked down: %s"), *GetName());
	SetLifeSpan(12.f);
}

// ===========================================================================
//  Grenade barrel
// ===========================================================================
ATutorialGrenadeBarrel::ATutorialGrenadeBarrel()
{
	PrimaryActorTick.bCanEverTick = true;

	// ---- the visual barrel: a shell, and it does NOT collide ----------------
	// S19-BARREL: it used to be the collider too (BlockAllDynamic on a solid
	// cylinder), which is why no grenade could ever go inside it. The body keeps
	// the look; the cup below provides every centimetre of collision.
	BarrelBody = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("BarrelBody"));
	RootComponent = BarrelBody;
	BarrelBody->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	BarrelBody->SetCollisionResponseToAllChannels(ECR_Ignore);
	BarrelBody->SetGenerateOverlapEvents(false);

	static ConstructorHelpers::FObjectFinder<UStaticMesh> CylinderMesh(TEXT("/Engine/BasicShapes/Cylinder.Cylinder"));
	if (CylinderMesh.Succeeded())
	{
		BarrelBody->SetStaticMesh(CylinderMesh.Object);
		BarrelBody->SetRelativeScale3D(FVector(0.6f, 0.6f, 0.9f));
	}

	// No cup here: collision parts are created in BeginPlay, where there is a
	// world to register them with (see BuildCup).
}

void ATutorialGrenadeBarrel::BuildCup()
{
	// The cup is built from the Mouth rule, so the collision the player feels and
	// the volume the lesson accepts are the same shape.
	//
	// Called from BeginPlay, and ONLY from BeginPlay: component creation needs a
	// world to register into, and a constructor-time build would be serialised
	// onto placed barrels - a second shell beside this one, built before a
	// designer's Details-panel edits to Mouth were applied.
	//
	// Each part uses the engine Cube (100 cm cube) scaled to the size we want;
	// the parts are invisible in practice because they sit inside the visual
	// barrel - the walls stop at the inner face, the floor below the rim.
	if (!GetWorld())
	{
		UE_LOG(LogTemp, Warning, TEXT("[S19-BARREL] %s: BuildCup called with no world — skipped."), *GetName());
		return;
	}
	const float WallW   = Mouth.WallWidthCm;
	const float WallT   = Mouth.WallThicknessCm;
	const float WallH   = Mouth.WallHeightCm();
	const int32 Segs    = Mouth.WallSegmentCount();
	const float FloorZ  = Mouth.FloorTopZCm - Mouth.FloorThicknessCm * 0.5f;

	// A rebuild, not a second cup: the parts from a previous call go first, so
	// calling this twice can never leave two overlapping shells behind.
	if (CupParts.Num() > 0)
	{
		for (UStaticMeshComponent* Old : CupParts)
		{
			if (IsValid(Old))
			{
				Old->DestroyComponent();
			}
		}
		CupParts.Reset();
	}

	// Engine cube is 100 cm on every axis, so scale = centimetres / 100.
	//
	// The whole transform is set BEFORE RegisterComponent: these parts are built
	// at runtime, and a relative transform pushed onto an already-registered
	// component is at best a warning ("...is Static, transform ignored") and at
	// worst silently dropped. Mobility is set explicitly for the same reason -
	// a cup part is a runtime object, not level geometry.
	auto MakePart = [&](const FVector& Offset, const FVector& SizeCm, float YawDeg) -> UStaticMeshComponent*
	{
		UStaticMeshComponent* Part = NewObject<UStaticMeshComponent>(this);
		if (!Part)
		{
			return nullptr;
		}
		Part->SetupAttachment(RootComponent);
		Part->SetMobility(EComponentMobility::Movable);
		Part->SetStaticMesh(LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cube.Cube")));
		Part->SetRelativeLocation(Offset);
		Part->SetRelativeRotation(FRotator(0.f, YawDeg, 0.f));
		Part->SetRelativeScale3D(SizeCm / 100.f);
		Part->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
		Part->SetCollisionProfileName(TEXT("BlockAllDynamic"));
		Part->SetGenerateOverlapEvents(false);
		Part->SetHiddenInGame(true);
		Part->RegisterComponent();
		CupParts.Add(Part);
		return Part;
	};

	// floor: a square whose inscribed circle is the mouth, so it covers the
	// whole disc the rule accepts
	MakePart(FVector(0.f, 0.f, FloorZ),
		FVector(Mouth.InnerRadiusCm * 2.f, Mouth.InnerRadiusCm * 2.f, Mouth.FloorThicknessCm), 0.f);

	// ring of walls: offsets and yaws come from the model, so the rectangles
	// that stop the grenade are the same rectangles WallSegmentCoversPoint
	// tests (and the harness proves they leave no gap). The yaw keeps the
	// segment's width tangent to the ring, so its face points at the axis.
	for (int32 i = 0; i < Segs; ++i)
	{
		MakePart(Mouth.WallSegmentOffsetCm(i), FVector(WallW, WallT, WallH), Mouth.WallSegmentYawDeg(i));
	}
}

void ATutorialGrenadeBarrel::BeginPlay()
{
	Super::BeginPlay();

	// S19-BARREL: build the cup here, from whatever Mouth says now. This is the
	// only build: the constructor runs before a designer's Details-panel edits
	// are applied (and before there is a world to register parts with), so it
	// must not be the one that makes the collision.
	BuildCup();

	// S19-MAT: same story as the cans — the drum had no material at all.
	if (BarrelBody && BarrelBody->GetNumOverrideMaterials() == 0)
	{
		if (UMaterialInterface* M = CachedTrenchMaterial(TEXT("M_TrenchDrum")))
		{
			BarrelBody->SetMaterial(0, M);
		}
		else
		{
			UE_LOG(LogTemp, Log, TEXT("[S19-MAT] M_TrenchDrum not found — tutorial barrel keeps the default material. Run scripts/SquadAI_ImportTrenchMaterials.py, or set BarrelMaterialOverride on the range actor."));
		}
	}

	if (USquadAITutorialSubsystem* Tut = USquadAITutorialSubsystem::Get(this))
	{
		// S19-BARREL: the marker points at the open top, because that is what the
		// lesson is about. It used to point at the barrel's origin - its middle.
		Tut->CurrentTaskWorldFocus = GetActorLocation() + Mouth.MouthCentre();
	}
}

void ATutorialGrenadeBarrel::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);
	if (bSatisfied)
	{
		return;
	}

	// Poll 20x a second for a live grenade in the barrel mouth. Polling beats an
	// overlap event here because the grenade may be spawned with collision
	// disabled for its first frames. The rate is set against the grenade's fuse
	// (2.5 s by default): a throw arcs for about a second, so at 0.05 s there are
	// ~25 samples between it coming to rest in the drum and it going off, while
	// 0.2 s left as few as one. One small sphere overlap per scan is nothing.
	ScanTimer += DeltaSeconds;
	if (ScanTimer < 0.05f)
	{
		return;
	}
	ScanTimer = 0.f;

	// S19-BARREL: the sphere is a BROADPHASE only. It used to be the acceptance
	// test itself - a 140 cm sphere 60 cm above the barrel's origin, scaled by the
	// actor, i.e. a ~2.5 m ball around a 60 cm drum that counted a grenade landing
	// a metre away on the grass. Now the shape it finds candidates with is generous
	// and the test it applies to them is the barrel: FTutorialBarrelMouth.
	const float Radius = Mouth.BroadphaseRadiusCm();
	const FVector Centre = GetActorLocation();

	// Cleared before the query, not after it: an overlap query that finds
	// nothing at all reports false, and returning from that path used to leave
	// IsOccupied() stuck at whatever the last frame said.
	bOccupied = false;

	TArray<FOverlapResult> Overlaps;
	FCollisionQueryParams QP(SCENE_QUERY_STAT(TutorialGrenadeScan), false, this);
	FCollisionObjectQueryParams ObjQP;
	ObjQP.AddObjectTypesToQuery(ECC_PhysicsBody);
	ObjQP.AddObjectTypesToQuery(ECC_WorldDynamic);
	if (!GetWorld()->OverlapMultiByObjectType(Overlaps, Centre, FQuat::Identity, ObjQP,
		FCollisionShape::MakeSphere(Radius), QP))
	{
		return;
	}

	bool bSawGrenadeNearby = false;
	for (const FOverlapResult& O : Overlaps)
	{
		AActor* A = O.GetActor();
		if (!A || A == this)
		{
			continue;
		}
		const bool bIsGrenade = A->IsA(ATacticalGrenadeActor::StaticClass())
			|| A->GetClass()->GetName().Contains(TEXT("Grenade"));
		if (!bIsGrenade)
		{
			continue;
		}
		bSawGrenadeNearby = true;

		// Inverse transform, not a subtraction: a barrel rotated or scaled in the
		// level tests against the mouth it actually has. (The cup's parts are
		// relative offsets, so they scale and rotate with the actor too.)
		const FVector Local = GetActorTransform().InverseTransformPosition(A->GetActorLocation());
		// S19-BARREL: inside AND no longer travelling fast - the rule lives in the model
		// (FTutorialBarrelMouth::CountsAsLanded) so the harness tests it. It used to be
		// "not climbing fast", which let a grenade on its way back OUT of the mouth (a hard
		// bounce off the cup floor, a throw that clips the rim) complete the lesson and then
		// sail away. It also means the lesson fires the moment the grenade settles, which is
		// what the player sees.
		FVector GrenadeVelocity = FVector::ZeroVector;
		if (const UProjectileMovementComponent* Mover = A->FindComponentByClass<UProjectileMovementComponent>())
		{
			GrenadeVelocity = Mover->Velocity;
		}
		if (!FTutorialBarrelMouth::CountsAsLanded(Local, GrenadeVelocity, Mouth))
		{
			continue;
		}

		bOccupied = true;
		RegisterGrenadeHit();
		return;
	}

	// Nothing in the mouth. If a grenade is sitting close to the barrel - or has
	// just come to rest nearby - say so once, so "it did not count" is a message
	// the player can act on instead of a silent non-event. Throttled per throw.
	if (bSawGrenadeNearby && GetWorld())
	{
		const double Now = GetWorld()->GetTimeSeconds();
		if (Now - LastMissTime > 1.5)
		{
			LastMissTime = Now;
			UE_LOG(LogTemp, Warning, TEXT("[S19-BARREL] Grenade came to rest beside the barrel, not in it - "
				"it has to go through the open top (%s are %.0f cm across)."), *GetName(), Mouth.InnerRadiusCm * 2.f);
		}
	}
}

void ATutorialGrenadeBarrel::RegisterGrenadeHit()
{
	if (bSatisfied)
	{
		return;
	}
	bSatisfied = true;
	if (USquadAITutorialSubsystem* Tut = USquadAITutorialSubsystem::Get(this))
	{
		Tut->NotifyBarrelGrenaded();
	}
	UE_LOG(LogTemp, Warning, TEXT("[S18-TUT] Grenade landed in the tutorial barrel."));
}

// ===========================================================================
//  Range
// ===========================================================================
ATutorialRangeActor::ATutorialRangeActor()
{
	PrimaryActorTick.bCanEverTick = false;
	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
}

void ATutorialRangeActor::BeginPlay()
{
	Super::BeginPlay();

	if (USquadAITutorialSubsystem* Tut = USquadAITutorialSubsystem::Get(this))
	{
		// Keep the can count honest on both sides.
		Tut->CansToShoot = FMath::Max(1, CanCount);
		if (bClearWhenTutorialEnds)
		{
			Tut->OnTutorialFinished.AddDynamic(this, &ATutorialRangeActor::HandleTutorialFinished);
		}
	}
	BuildRange();
}

FVector ATutorialRangeActor::GroundedLocation(const FVector& In) const
{
	if (!bSnapToGround || !GetWorld())
	{
		return In;
	}
	FHitResult Hit;
	FCollisionQueryParams Params(SCENE_QUERY_STAT(TutorialRangeGround), false, this);
	if (GetWorld()->LineTraceSingleByChannel(Hit, In + FVector(0.f, 0.f, 500.f), In - FVector(0.f, 0.f, 2000.f), ECC_Visibility, Params))
	{
		return Hit.ImpactPoint;
	}
	return In;
}

void ATutorialRangeActor::BuildRange()
{
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}
	ClearRange();

	const FTransform Base = GetActorTransform();
	FActorSpawnParameters P;
	P.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	P.Owner = this;

	// --- cans in a row ----------------------------------------------------
	const FVector RowStart = Base.TransformPosition(CanRowOffset);
	const FVector RowDir = GetActorRightVector();
	for (int32 i = 0; i < FMath::Max(1, CanCount); ++i)
	{
		const FVector Raw = RowStart + RowDir * (i * CanSpacingCm);
		const FVector Loc = GroundedLocation(Raw) + FVector(0.f, 0.f, 12.f);
		if (ATutorialTargetCan* Can = World->SpawnActor<ATutorialTargetCan>(ATutorialTargetCan::StaticClass(), Loc, FRotator::ZeroRotator, P))
		{
			if (CanMeshOverride && Can->CanMesh)
			{
				Can->CanMesh->SetStaticMesh(CanMeshOverride);
			}
			// S19-MAT: a designer override always wins over the auto-resolved one.
			if (CanMaterialOverride && Can->CanMesh)
			{
				Can->CanMesh->SetMaterial(0, CanMaterialOverride);
			}
			SpawnedProps.Add(Can);
		}
	}

	// --- the grenade barrel ----------------------------------------------
	const FVector BarrelLoc = GroundedLocation(Base.TransformPosition(BarrelOffset)) + FVector(0.f, 0.f, 45.f);
	if (ATutorialGrenadeBarrel* Barrel = World->SpawnActor<ATutorialGrenadeBarrel>(ATutorialGrenadeBarrel::StaticClass(), BarrelLoc, FRotator::ZeroRotator, P))
	{
		if (BarrelMeshOverride && Barrel->BarrelBody)
		{
			Barrel->BarrelBody->SetStaticMesh(BarrelMeshOverride);
		}
		// S19-MAT: designer override wins here too.
		if (BarrelMaterialOverride && Barrel->BarrelBody)
		{
			Barrel->BarrelBody->SetMaterial(0, BarrelMaterialOverride);
		}
		SpawnedProps.Add(Barrel);
	}

	UE_LOG(LogTemp, Warning, TEXT("[S18-TUT] Tutorial range built: %d cans + 1 barrel."), FMath::Max(1, CanCount));
}

void ATutorialRangeActor::ClearRange()
{
	for (AActor* A : SpawnedProps)
	{
		if (IsValid(A))
		{
			A->Destroy();
		}
	}
	SpawnedProps.Reset();
}

void ATutorialRangeActor::HandleTutorialFinished()
{
	UE_LOG(LogTemp, Warning, TEXT("[S18-TUT] Tutorial finished — clearing the practice range."));
	ClearRange();
}

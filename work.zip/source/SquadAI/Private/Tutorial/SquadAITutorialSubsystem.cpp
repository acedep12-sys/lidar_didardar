// SquadAITutorialSubsystem.cpp — S18-TUT
#include "Tutorial/SquadAITutorialSubsystem.h"
#include "Tutorial/TutorialRangeActor.h"   // S18-TUT2
#include "Components/TacticalGrenadeComponent.h" // S19-TUT: grenade lesson perks
#include "EngineUtils.h"                   // S18-TUT2
#include "HAL/IConsoleManager.h"           // S18-TUT3
#include "SaveSystem/SquadAISaveLoadSubsystem.h"
#include "HUD/QuestNativeHUD.h"
#include "Engine/World.h"
#include "Engine/Engine.h"
#include "GameFramework/Pawn.h"
#include "GameFramework/PlayerController.h"
#include "Kismet/GameplayStatics.h"
#include "Sound/SoundBase.h"               // S18-TUTAUDIO
#include "TimerManager.h"

USquadAITutorialSubsystem* USquadAITutorialSubsystem::Get(const UObject* WorldContextObject)
{
	if (!WorldContextObject || !GEngine) return nullptr;
	UWorld* World = GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::ReturnNull);
	return World ? World->GetSubsystem<USquadAITutorialSubsystem>() : nullptr;
}

void USquadAITutorialSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
	BuildBeats();
}

void USquadAITutorialSubsystem::Deinitialize()
{
	// S19-INPUT / S19-TUT: never leave the player detached from the input stack
	// or holding free grenades if the world goes away mid-lesson.
	SetPawnInputBlocked(false);
	ApplyGrenadeLessonPerks(false);
	SetMovementLocked(false);
	Super::Deinitialize();
}

// S19-PIEMENUGATE: PIE world type alone does not distinguish M_MainMenu from a mission.
void USquadAITutorialSubsystem::OnWorldBeginPlay(UWorld& InWorld)
{
	Super::OnWorldBeginPlay(InWorld);

	const FString MapName = InWorld.GetMapName();
	if (MapName.Contains(TEXT("MainMenu"), ESearchCase::IgnoreCase))
	{
		UE_LOG(LogTemp, Log, TEXT("[S18-TUT] Skipping tutorial in menu world '%s'."), *MapName);
		return;
	}

	// Editor utility/preview worlds have no player pawn worth tutoring.
	if (InWorld.WorldType != EWorldType::Game && InWorld.WorldType != EWorldType::PIE)
	{
		return;
	}

	InWorld.GetTimerManager().SetTimer(StartDelayTimer, FTimerDelegate::CreateWeakLambda(this, [this]()
	{
		BeginTutorialFlow();
	}), FMath::Max(0.1f, StartDelaySeconds), false);
}

void USquadAITutorialSubsystem::BuildBeats()
{
	Beats.Reset();

	auto Add = [this](ESquadAITutorialStep Step, FName Highlight, const TCHAR* TFa, const TCHAR* BFa,
		const TCHAR* TEn, const TCHAR* BEn, bool bFullPause, int32 Required)
	{
		FSquadAITutorialBeat B;
		B.Step = Step;
		B.HighlightElement = Highlight;
		B.TitleFa = TFa; B.BodyFa = BFa;
		B.TitleEn = TEn; B.BodyEn = BEn;
		B.bFullPause = bFullPause;
		B.RequiredCount = Required;
		Beats.Add(B);
	};

	// ---- UI walkthrough: game fully frozen, one element highlighted at a time
	Add(ESquadAITutorialStep::UI_Objective, TEXT("Objective"),
		TEXT("حرکت در سنگر خط مقدم"),
		TEXT("پشت سر سرگرد رستمی روی تخته‌های سنگر حرکت کنید و به موضع میدان تیر برسید."),
		TEXT("ADVANCE IN FORWARD TRENCH"),
		TEXT("Follow Major Rostami along the trench boards to reach the firing range position."),
		true, 1);

	Add(ESquadAITutorialStep::UI_Squad, TEXT("Squad"),
		TEXT("پناه‌گیری و وضعیت جوخه"),
		TEXT("پشت خاکریز و کیسه‌های شن موضع بگیرید و سلامت سرگرد رستمی، مهدی و علی را بررسی کنید."),
		TEXT("TAKE COVER & SQUAD STATUS"),
		TEXT("Take cover behind the sandbags and monitor the health of Major Rostami, Mehdi, and Ali."),
		true, 1);

	Add(ESquadAITutorialStep::UI_Compass, TEXT("Compass"),
		TEXT("قطب‌نما و جهت‌یابی میدان"),
		TEXT("جهت حرکت در محور دهلاویه، زاویه دید و نشانه‌های هدف روی نوار قطب‌نمای بالا دیده می‌شود."),
		TEXT("COMPASS & SECTOR BEARING"),
		TEXT("Your heading along the Dehlavieh axis and objective markers ride on the top compass rail."),
		true, 1);

	Add(ESquadAITutorialStep::UI_Weapon, TEXT("Weapon"),
		TEXT("تفنگ سازمانی ژ-۳ و مهمات"),
		TEXT("وضعیت تفنگ ژ-۳ (G3A3)، خشاب ۲۰ فشنگی و ذخیره مهمات ۷.۶۲ ناتو را بررسی کنید. با [R] خشاب عوض کنید."),
		TEXT("G3A3 SERVICE RIFLE & AMMO"),
		TEXT("Check your G3A3 battle rifle mode, 20-round magazine, and 7.62 NATO reserve. Press [R] to reload."),
		true, 1);

	Add(ESquadAITutorialStep::UI_Artillery, TEXT("Artillery"),
		TEXT("نشانگر پشتیبانی آتش خمپاره"),
		TEXT("وضعیت آمادگی آتشبار خمپاره ۱۲۰ میلی‌متری را می‌بینید. هشدار: از محدوده انفجار فاصله بگیرید."),
		TEXT("120MM MORTAR FIRE SUPPORT"),
		TEXT("This indicator shows 120mm mortar readiness. Warning: stay clear of the impact zone."),
		true, 1);

	// ---- hands-on tasks: prompt pauses, then movement is locked until done
	Add(ESquadAITutorialStep::Task_Move, NAME_None,
		TEXT("حرکت در سنگر خط مقدم"),
		TEXT("پشت سر سرگرد رستمی روی تخته‌های سنگر حرکت کنید و به موضع میدان تیر برسید."),
		TEXT("ADVANCE IN FORWARD TRENCH"),
		TEXT("Follow Major Rostami along the trench boards to reach the firing range position."),
		false, 1);

	Add(ESquadAITutorialStep::Task_ShootCans, NAME_None,
		TEXT("تیراندازی با تفنگ ژ-۳"),
		TEXT("به حالت نشسته بروید، با کلیک راست از مگسک آهنی نشانه بگیرید و ۳ قوطی روی خاکریز را بزنید."),
		TEXT("G3A3 MARKSMANSHIP"),
		TEXT("Crouch behind cover, aim down the G3A3 iron sights with RMB, and shoot the 3 cans on the berm."),
		false, 3);

	Add(ESquadAITutorialStep::Task_Grenade, NAME_None,
		TEXT("پرتاب نارنجک در بشکه"),
		TEXT("از پشت جان‌پناه با کلید [G] ضامن را بکشید و نارنجک را از دهانه باز داخل بشکه بیندازید."),
		TEXT("GRENADE ACCURACY"),
		TEXT("From behind cover, hold [G] and arc the grenade through the open top of the drum."),
		false, 1);

	Add(ESquadAITutorialStep::Task_Artillery, NAME_None,
		TEXT("درخواست آتش توپخانه"),
		TEXT("موضع هدف در دشت دهلاویه را نشانه بگیرید و با کلیک وسط ماوس [MMB] آتش خمپاره درخواست کنید."),
		TEXT("CALL FOR MORTAR FIRE"),
		TEXT("Aim at the target position across the Dehlavieh plain and press [MMB] to call mortar fire."),
		false, 1);
	// S18-TUT3: key chips so the player is never left guessing which button.
	for (FSquadAITutorialBeat& B : Beats)
	{
		switch (B.Step)
		{
		case ESquadAITutorialStep::Task_Move:
			B.KeyHintFa = TEXT("[W] نگه‌داشتن برای حرکت به جلو  •  [SHIFT] دویدن"); B.KeyHintEn = TEXT("Hold [W] to move forward  •  [SHIFT] Sprint"); break;
		case ESquadAITutorialStep::Task_ShootCans:
			B.KeyHintFa = TEXT("کلیک راست = نشانه‌روی   |   کلیک چپ = شلیک");
			B.KeyHintEn = TEXT("Right mouse = aim   |   Left mouse = fire"); break;
		case ESquadAITutorialStep::Task_Grenade:
			B.KeyHintFa = TEXT("[G] = پرتاب نارنجک"); B.KeyHintEn = TEXT("[G] = throw grenade"); break;
		case ESquadAITutorialStep::UI_Artillery:
		case ESquadAITutorialStep::Task_Artillery:
			B.KeyHintFa = TEXT("[MMB] = درخواست آتش توپخانه"); B.KeyHintEn = TEXT("[MMB] = call for fire"); break;
		default:
			B.KeyHintFa = TEXT("[F] ادامه"); B.KeyHintEn = TEXT("[F] Continue"); break;
		}
	}

	// S18-TUT batch 4: hand-drawn manual art per beat (see assets/TutorialImages).
	for (FSquadAITutorialBeat& B : Beats)
	{
		switch (B.Step)
		{
		case ESquadAITutorialStep::UI_Objective:  B.IllustrationKey = TEXT("Welcome");   break;
		case ESquadAITutorialStep::UI_Squad:      B.IllustrationKey = TEXT("Squad");     break;
		case ESquadAITutorialStep::Task_Move:     B.IllustrationKey = TEXT("Move");      break;
		case ESquadAITutorialStep::Task_ShootCans:B.IllustrationKey = TEXT("Shoot");     break;
		case ESquadAITutorialStep::Task_Grenade:  B.IllustrationKey = TEXT("Grenade");   break;
		case ESquadAITutorialStep::UI_Artillery:
		case ESquadAITutorialStep::Task_Artillery:B.IllustrationKey = TEXT("Artillery"); break;
		default: break;
		}
	}

}

bool USquadAITutorialSubsystem::GetCurrentBeat(FSquadAITutorialBeat& OutBeat) const
{
	if (Beats.IsValidIndex(CurrentBeatIndex))
	{
		OutBeat = Beats[CurrentBeatIndex];
		return true;
	}
	return false;
}

namespace
{
	// S18-TUTAUDIO: tiny 2D cue helper — null sound is simply ignored.
	void PlayTutorialCue(const UObject* Ctx, USoundBase* Sound, float Volume = 1.f)
	{
		if (!Sound || !Ctx) return;
		UGameplayStatics::PlaySound2D(Ctx, Sound, Volume);
	}
}

void USquadAITutorialSubsystem::BeginTutorialFlow()
{
	// S18-TUT2: never open on a dead frame. Wait for a possessed pawn and a HUD
	// before showing anything, retrying twice a second for ~15 s.
	UWorld* World = GetWorld();
	APlayerController* PC = World ? UGameplayStatics::GetPlayerController(World, 0) : nullptr;
	if (!World || !PC || !PC->GetPawn() || !PC->GetHUD())
	{
		if (++StartAttempts < 30 && World)
		{
			World->GetTimerManager().SetTimer(StartDelayTimer, FTimerDelegate::CreateWeakLambda(this, [this]()
			{
				BeginTutorialFlow();
			}), 0.5f, false);
			return;
		}
		UE_LOG(LogTemp, Warning, TEXT("[S18-TUT] Gave up waiting for pawn/HUD — tutorial not started."));
		return;
	}

	USquadAISaveLoadSubsystem* SaveSys = USquadAISaveLoadSubsystem::Get(this);
	FSquadGameSettingsSaveData Settings = SaveSys ? SaveSys->GetCachedSettings() : FSquadGameSettingsSaveData();

	if (Settings.bTutorialCompleted || Settings.bTutorialSkipped)
	{
		UE_LOG(LogTemp, Log, TEXT("[S18-TUT] Tutorial already handled (completed=%d skipped=%d) — not shown."),
			Settings.bTutorialCompleted ? 1 : 0, Settings.bTutorialSkipped ? 1 : 0);
		return;
	}

	bActive = true;
	if (!Settings.bTutorialPromptAnswered)
	{
		// First ever play: ask once, with the game frozen.
		CurrentStep = ESquadAITutorialStep::SkipPrompt;
		CurrentBeatIndex = INDEX_NONE;
		SetGamePausedForTutorial(true);
		OnTutorialStepChanged.Broadcast(CurrentStep);
		UE_LOG(LogTemp, Warning, TEXT("[S18-TUT] First run — asking whether to skip the tutorial."));
		return;
	}

	StartTutorial();
}

void USquadAITutorialSubsystem::AnswerSkipPrompt(bool bSkip)
{
	if (CurrentStep != ESquadAITutorialStep::SkipPrompt)
	{
		return;
	}

	if (USquadAISaveLoadSubsystem* SaveSys = USquadAISaveLoadSubsystem::Get(this))
	{
		FSquadGameSettingsSaveData Settings = SaveSys->GetCachedSettings();
		Settings.bTutorialPromptAnswered = true;   // never ask again
		SaveSys->SaveSettings(Settings);
	}

	if (bSkip)
	{
		SkipTutorial();
	}
	else
	{
		StartTutorial();
	}
}

void USquadAITutorialSubsystem::StartTutorial()
{
	bActive = true;
	CompletedSteps.Reset();
	CurrentBeatIndex = INDEX_NONE;
	UE_LOG(LogTemp, Warning, TEXT("[S18-TUT] Tutorial started (%d beats)."), Beats.Num());
	AdvanceToNextStep();
}

void USquadAITutorialSubsystem::AdvanceToNextStep()
{
	const int32 Next = CurrentBeatIndex + 1;
	if (!Beats.IsValidIndex(Next))
	{
		FinishTutorial();
		return;
	}
	CurrentBeatIndex = Next;
	EnterStep(Beats[Next].Step);
}

void USquadAITutorialSubsystem::EnterStep(ESquadAITutorialStep NewStep)
{
	CurrentStep = NewStep;
	StepProgress = 0;

	if (NewStep == ESquadAITutorialStep::Task_Move)
	{
		if (const APawn* P = UGameplayStatics::GetPlayerPawn(GetWorld(), 0))
		{
			MoveTaskStartLocation = P->GetActorLocation();
		}
		if (UWorld* W = GetWorld())
		{
			W->GetTimerManager().SetTimer(MoveTaskTimer, FTimerDelegate::CreateWeakLambda(this, [this]()
			{
				TickMoveTask();
			}), 0.25f, true);
		}
	}

	// S18-TUT2: make sure there is something to shoot before we ask for it.
	if (NewStep == ESquadAITutorialStep::Task_ShootCans || NewStep == ESquadAITutorialStep::Task_Grenade)
	{
		EnsurePracticeRange();
	}

	if (UWorld* W = GetWorld()) { StepStartTime = W->GetTimeSeconds(); } // S18-TUT4

	// S19-TUT: free grenades and the landing arc, but only for this one lesson.
	ApplyGrenadeLessonPerks(NewStep == ESquadAITutorialStep::Task_Grenade);

	ApplyStepGating();
	OnTutorialStepChanged.Broadcast(NewStep);
	UE_LOG(LogTemp, Warning, TEXT("[S18-TUT] Step -> %s"), *UEnum::GetValueAsString(NewStep));
}

void USquadAITutorialSubsystem::ApplyStepGating()
{
	FSquadAITutorialBeat Beat;
	if (!GetCurrentBeat(Beat))
	{
		SetGamePausedForTutorial(false);
		SetMovementLocked(false);
		return;
	}

	if (Beat.bFullPause)
	{
		// UI lesson: the whole game stops until the player acknowledges.
		SetGamePausedForTutorial(true);
		SetMovementLocked(false);
	}
	else if (bCinematicPromptMode)
	{
		// S18-TUT4: the AAA way — the game never stops for a hands-on step. The
		// player keeps full control, reads a one-line banner, and simply does it.
		// Nothing is locked: locking the legs while telling someone to shoot is
		// exactly the frustration we were asked to remove.
		SetGamePausedForTutorial(false);
		SetMovementLocked(false);
	}
	else
	{
		// Legacy: show the card paused, then unpause and lock movement.
		SetGamePausedForTutorial(true);
	}
}

void USquadAITutorialSubsystem::AcknowledgeCurrentBeat()
{
	FSquadAITutorialBeat Beat;
	if (!bActive || !GetCurrentBeat(Beat))
	{
		return;
	}

	if (Beat.bFullPause)
	{
		// UI lessons complete on acknowledge.
		CompletedSteps.AddUnique(Beat.Step);
		SetGamePausedForTutorial(false);
		AdvanceToNextStep();
		return;
	}

	// Task card dismissed: resume the world.
	SetGamePausedForTutorial(false);
	// S18-TUT4: movement is only locked in legacy mode.
	SetMovementLocked(!bCinematicPromptMode && Beat.Step != ESquadAITutorialStep::Task_Move);
}

void USquadAITutorialSubsystem::ReportProgress(ESquadAITutorialStep ForStep, int32 Amount)
{
	if (!bActive || CurrentStep != ForStep)
	{
		return;
	}
	FSquadAITutorialBeat Beat;
	if (!GetCurrentBeat(Beat))
	{
		return;
	}

	StepProgress = FMath::Max(0, StepProgress + Amount);
	if (UWorld* W = GetWorld()) { LastProgressTime = W->GetTimeSeconds(); } // S18-TUT3
	PlayTutorialCue(this, ProgressSound); // S18-TUTAUDIO
	const int32 Required = (ForStep == ESquadAITutorialStep::Task_ShootCans)
		? FMath::Max(1, CansToShoot) : FMath::Max(1, Beat.RequiredCount);

	UE_LOG(LogTemp, Warning, TEXT("[S18-TUT] Progress %s: %d/%d"), *UEnum::GetValueAsString(ForStep), StepProgress, Required);

	if (StepProgress >= Required)
	{
		PlayTutorialCue(this, StepCompleteSound); // S18-TUTAUDIO
		CompletedSteps.AddUnique(ForStep);
		SetMovementLocked(false);
		if (UWorld* W = GetWorld())
		{
			W->GetTimerManager().ClearTimer(MoveTaskTimer);
		}
		AdvanceToNextStep();
	}
}

void USquadAITutorialSubsystem::NotifyCanDestroyed()    { ReportProgress(ESquadAITutorialStep::Task_ShootCans, 1); }
void USquadAITutorialSubsystem::NotifyBarrelGrenaded()  { ReportProgress(ESquadAITutorialStep::Task_Grenade, 1); }
void USquadAITutorialSubsystem::NotifyArtilleryCalled() { ReportProgress(ESquadAITutorialStep::Task_Artillery, 1); }

void USquadAITutorialSubsystem::TickMoveTask()
{
	if (CurrentStep != ESquadAITutorialStep::Task_Move)
	{
		return;
	}
	if (const APawn* P = UGameplayStatics::GetPlayerPawn(GetWorld(), 0))
	{
		if (FVector::Dist2D(P->GetActorLocation(), MoveTaskStartLocation) >= MoveTaskDistanceCm)
		{
			ReportProgress(ESquadAITutorialStep::Task_Move, 1);
		}
	}
}

void USquadAITutorialSubsystem::SkipTutorial()
{
	UE_LOG(LogTemp, Warning, TEXT("[S18-TUT] Tutorial skipped by the player."));
	SetGamePausedForTutorial(false);
	SetMovementLocked(false);
	SetPawnInputBlocked(false);      // S19-INPUT
	ApplyGrenadeLessonPerks(false);  // S19-TUT
	if (UWorld* W = GetWorld())
	{
		W->GetTimerManager().ClearTimer(MoveTaskTimer);
	}
	bActive = false;
	CurrentStep = ESquadAITutorialStep::Inactive;
	CurrentBeatIndex = INDEX_NONE;
	MarkTutorialDoneInSettings(true);
	OnTutorialFinished.Broadcast();
}

void USquadAITutorialSubsystem::FinishTutorial()
{
	PlayTutorialCue(this, TutorialCompleteSound); // S18-TUTAUDIO
	UE_LOG(LogTemp, Warning, TEXT("[S18-TUT] Tutorial complete."));
	SetGamePausedForTutorial(false);
	SetMovementLocked(false);
	SetPawnInputBlocked(false);      // S19-INPUT
	ApplyGrenadeLessonPerks(false);  // S19-TUT
	if (UWorld* W = GetWorld())
	{
		W->GetTimerManager().ClearTimer(MoveTaskTimer);
	}
	bActive = false;
	CurrentStep = ESquadAITutorialStep::Finished;
	MarkTutorialDoneInSettings(false);
	OnTutorialFinished.Broadcast();
}

void USquadAITutorialSubsystem::MarkTutorialDoneInSettings(bool bSkipped)
{
	if (USquadAISaveLoadSubsystem* SaveSys = USquadAISaveLoadSubsystem::Get(this))
	{
		FSquadGameSettingsSaveData Settings = SaveSys->GetCachedSettings();
		Settings.bTutorialPromptAnswered = true;
		Settings.bTutorialSkipped = bSkipped;
		Settings.bTutorialCompleted = !bSkipped;
		SaveSys->SaveSettings(Settings);
	}
}

void USquadAITutorialSubsystem::RestartTutorial()
{
	// S18-TUT3: clear the three saved flags and run the flow from the top.
	if (USquadAISaveLoadSubsystem* SaveSys = USquadAISaveLoadSubsystem::Get(this))
	{
		FSquadGameSettingsSaveData Settings = SaveSys->GetCachedSettings();
		Settings.bTutorialCompleted = false;
		Settings.bTutorialSkipped = false;
		Settings.bTutorialPromptAnswered = true; // don't re-ask; he chose it deliberately
		SaveSys->SaveSettings(Settings);
	}

	SetGamePausedForTutorial(false);
	SetMovementLocked(false);
	CompletedSteps.Reset();
	StepProgress = 0;
	CurrentBeatIndex = INDEX_NONE;
	CurrentStep = ESquadAITutorialStep::Inactive;
	StartAttempts = 0;
	bActive = false;
	BuildBeats();

	UE_LOG(LogTemp, Warning, TEXT("[S18-TUT] S18-TUT3: tutorial restarted by request."));
	StartTutorial();
}

float USquadAITutorialSubsystem::GetTimeOnCurrentStep() const
{
	const UWorld* W = GetWorld();
	return (W && StepStartTime >= 0.f) ? (W->GetTimeSeconds() - StepStartTime) : 0.f;
}

bool USquadAITutorialSubsystem::ShouldEscalateHint() const
{
	// S18-TUT4: nothing has been achieved on this beat for a while — the player
	// is lost, so the HUD may show the longer "how" line and re-flag the target.
	const UWorld* W = GetWorld();
	if (!W || StepStartTime < 0.f) return false;
	const float Since = W->GetTimeSeconds() - FMath::Max(StepStartTime, LastProgressTime);
	return Since > FMath::Max(3.f, HintEscalationSeconds);
}

float USquadAITutorialSubsystem::GetProgressPopAlpha() const
{
	// S18-TUT3: 1 -> 0 over 1.2 s after each counted success.
	const UWorld* W = GetWorld();
	if (!W || LastProgressTime < 0.f) return 0.f;
	const float Age = W->GetTimeSeconds() - LastProgressTime;
	return (Age < 0.f || Age > 1.2f) ? 0.f : (1.f - Age / 1.2f);
}

void USquadAITutorialSubsystem::SetGamePausedForTutorial(bool bPause)
{
	UWorld* World = GetWorld();
	if (!World) return;

	if (bPause == bPausedByTutorial)
	{
		return;
	}
	bPausedByTutorial = bPause;

	// S18-TUT2: UGameplayStatics::SetGamePaused() is what produced the empty
	// blue screen — a paused world stops ticking the HUD panels and most of the
	// scene, so the player stared at a card floating over nothing and could not
	// see the very UI element being explained. We now slow time instead: the
	// level, the squad and every HUD panel keep rendering, the player just
	// cannot run off mid-lesson.
	UGameplayStatics::SetGlobalTimeDilation(World, bPause ? FMath::Clamp(CardTimeDilation, 0.02f, 1.0f) : 1.0f);
	PlayTutorialCue(this, bPause ? CardOpenSound : CardConfirmSound); // S18-TUTAUDIO

	// S19-INPUT: a card you dismiss with Space used to also make the character
	// jump, because SetIgnoreMoveInput() only blocks the movement axes — the
	// Jump / Fire *action* bindings were still live. Detach the pawn from the
	// input stack instead: then Space can never reach them.
	SetPawnInputBlocked(bPause && bBlockPawnInputDuringCards);

	if (APlayerController* PC = UGameplayStatics::GetPlayerController(World, 0))
	{
		// Legs and weapon off while a card is up, aim stays free so the player
		// can look at whatever the card is pointing at.
		PC->SetIgnoreMoveInput(bPause);
		PC->bShowMouseCursor = bPause;
		if (bPause)
		{
			FInputModeGameAndUI Mode;
			Mode.SetHideCursorDuringCapture(false);
			Mode.SetLockMouseToViewportBehavior(EMouseLockMode::DoNotLock);
			PC->SetInputMode(Mode);
		}
		else
		{
			PC->SetInputMode(FInputModeGameOnly());
		}
	}
	UE_LOG(LogTemp, Log, TEXT("[S18-TUT] Card %s (time dilation %.2f) — no hard pause."),
		bPause ? TEXT("shown") : TEXT("dismissed"), bPause ? CardTimeDilation : 1.0f);
}

bool USquadAITutorialSubsystem::IsTutorialProtectingPlayer(const UObject* WorldContextObject)
{
	// S18-TUT2: enemies must not shoot a player whose legs we locked.
	const USquadAITutorialSubsystem* Tut = USquadAITutorialSubsystem::Get(WorldContextObject);
	return Tut && Tut->bActive && Tut->bCombatSafeDuringTutorial
		&& Tut->CurrentStep != ESquadAITutorialStep::Finished;
}

void USquadAITutorialSubsystem::EnsurePracticeRange()
{
	UWorld* World = GetWorld();
	if (!World || !bAutoSpawnPracticeRange)
	{
		return;
	}
	// Already placed by hand? Leave the level alone.
	for (TActorIterator<ATutorialRangeActor> It(World); It; ++It)
	{
		UE_LOG(LogTemp, Log, TEXT("[S18-TUT] Practice range already in the level (%s)."), *It->GetName());
		return;
	}

	APawn* Pawn = UGameplayStatics::GetPlayerPawn(World, 0);
	if (!Pawn)
	{
		return;
	}

	// Put it on the ground a short walk ahead, facing the player.
	const FVector Fwd = Pawn->GetActorForwardVector().GetSafeNormal2D();
	FVector Loc = Pawn->GetActorLocation() + Fwd * FMath::Max(300.f, PracticeRangeDistanceCm);
	FHitResult Hit;
	FCollisionQueryParams Params(SCENE_QUERY_STAT(TutorialRangeSpawn), false, Pawn);
	if (World->LineTraceSingleByChannel(Hit, Loc + FVector(0.f, 0.f, 600.f), Loc - FVector(0.f, 0.f, 3000.f), ECC_Visibility, Params))
	{
		Loc = Hit.ImpactPoint;
	}

	FActorSpawnParameters SP;
	SP.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	// The range actor lays its cans out along +X from its own transform, so face
	// it back at the player: the row ends up square-on to the shooter.
	const FRotator Rot = (-Fwd).Rotation();
	if (ATutorialRangeActor* Range = World->SpawnActor<ATutorialRangeActor>(ATutorialRangeActor::StaticClass(), Loc, Rot, SP))
	{
		Range->CanCount = FMath::Max(1, CansToShoot);
		Range->CanRowOffset = FVector(-180.f, -90.f, 0.f);  // just behind its own origin, in front of the player
		Range->BarrelOffset = FVector(-420.f, 280.f, 0.f);
		Range->BuildRange();
		CurrentTaskWorldFocus = Loc;
		UE_LOG(LogTemp, Warning, TEXT("[S18-TUT] S18-TUT2: auto-spawned the practice range at %s (%d cans)."),
			*Loc.ToCompactString(), Range->CanCount);
	}
}

void USquadAITutorialSubsystem::SetMovementLocked(bool bLocked)
{
	if (bMovementLocked == bLocked)
	{
		return;
	}
	bMovementLocked = bLocked;

	if (APlayerController* PC = UGameplayStatics::GetPlayerController(GetWorld(), 0))
	{
		// Look and shoot stay available — only the legs are frozen.
		PC->SetIgnoreMoveInput(bLocked);
	}
	UE_LOG(LogTemp, Warning, TEXT("[S18-TUT] Movement %s"), bLocked ? TEXT("LOCKED") : TEXT("released"));
}

// =====================================================================
//  S18-TUT3: console helpers.
//    SquadAI.Tutorial.Reset  — wipe the flags and play the tutorial again
//    SquadAI.Tutorial.Skip   — end it immediately
// =====================================================================
static void SquadAITutorialResetCmd(UWorld* World)
{
	if (USquadAITutorialSubsystem* Tut = World ? World->GetSubsystem<USquadAITutorialSubsystem>() : nullptr)
	{
		Tut->RestartTutorial();
	}
}

static void SquadAITutorialSkipCmd(UWorld* World)
{
	if (USquadAITutorialSubsystem* Tut = World ? World->GetSubsystem<USquadAITutorialSubsystem>() : nullptr)
	{
		Tut->SkipTutorial();
	}
}

static FAutoConsoleCommandWithWorld GSquadAITutorialReset(
	TEXT("SquadAI.Tutorial.Reset"),
	TEXT("Clear the saved tutorial flags and run the training again."),
	FConsoleCommandWithWorldDelegate::CreateStatic(&SquadAITutorialResetCmd));

static FAutoConsoleCommandWithWorld GSquadAITutorialSkip(
	TEXT("SquadAI.Tutorial.Skip"),
	TEXT("End the running tutorial immediately."),
	FConsoleCommandWithWorldDelegate::CreateStatic(&SquadAITutorialSkipCmd));

// ==========================================================================
//  S19-INPUT: keep Space out of the character's Jump binding
// ==========================================================================

void USquadAITutorialSubsystem::SetPawnInputBlocked(bool bBlocked)
{
	if (bPawnInputBlocked == bBlocked)
	{
		return;
	}

	UWorld* World = GetWorld();
	APlayerController* PC = World ? UGameplayStatics::GetPlayerController(World, 0) : nullptr;
	APawn* Pawn = PC ? PC->GetPawn() : nullptr;

	if (bBlocked)
	{
		// Only claim the flag once we really have something to detach, so the
		// matching EnableInput() below can never be skipped.
		if (!Pawn)
		{
			UE_LOG(LogTemp, Warning, TEXT("[S19-INPUT] No pawn to detach — Space may still reach Jump."));
			return;
		}
		bPawnInputBlocked = true;
		Pawn->DisableInput(PC);
		UE_LOG(LogTemp, Verbose, TEXT("[S19-INPUT] Pawn input detached for the lesson card."));
		return;
	}

	bPawnInputBlocked = false;
	if (Pawn)
	{
		Pawn->EnableInput(PC);
	}
	UE_LOG(LogTemp, Verbose, TEXT("[S19-INPUT] Pawn input restored."));
}

// ==========================================================================
//  S19-TUT: the grenade lesson should not run out of grenades
// ==========================================================================

void USquadAITutorialSubsystem::ApplyGrenadeLessonPerks(bool bOn)
{
	if (bGrenadePerksApplied == bOn)
	{
		return;
	}

	APawn* Pawn = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
	UTacticalGrenadeComponent* Gren = Pawn
		? Pawn->FindComponentByClass<UTacticalGrenadeComponent>()
		: nullptr;

	if (bOn && !Gren)
	{
		// Nothing to grant. Do not latch the flag, or we would "revoke" a perk
		// we never applied and silently skip it if the component appears later.
		UE_LOG(LogTemp, Warning, TEXT("[S19-TUT] Grenade lesson started but the player pawn has no UTacticalGrenadeComponent — ammo will not be free."));
		return;
	}

	bGrenadePerksApplied = bOn;

	if (Gren)
	{
		Gren->bUnlimitedGrenades = bOn && bUnlimitedGrenadesDuringLesson;
		// The arc is drawn by the HUD whenever IsGrenadePreviewWanted() says so;
		// this flag only matters for players who leave it on permanently.
		if (bOn && (bShowGrenadeArcDuringLesson || bShowGrenadeArcForWholeTutorial))
		{
			Gren->bShowThrowPreview = bShowGrenadeArcForWholeTutorial;
		}
		else if (!bOn)
		{
			Gren->bShowThrowPreview = false;
		}
	}

	UE_LOG(LogTemp, Warning, TEXT("[S19-TUT] Grenade lesson perks %s (free ammo=%d)."),
		bOn ? TEXT("GRANTED") : TEXT("revoked"),
		(Gren && Gren->bUnlimitedGrenades) ? 1 : 0);
}

bool USquadAITutorialSubsystem::IsGrenadePreviewWanted() const
{
	if (!bActive)
	{
		return false;
	}
	if (bShowGrenadeArcForWholeTutorial)
	{
		return true;
	}
	return bShowGrenadeArcDuringLesson
		&& CurrentStep == ESquadAITutorialStep::Task_Grenade;
}

// TutorialGuideActor.cpp — S18-TUTGUIDE
#include "Tutorial/TutorialGuideActor.h"
#include "Tutorial/TutorialRangeActor.h"
#include "Characters/SoldierCharacter.h"
#include "Kismet/GameplayStatics.h"
#include "Sound/SoundMix.h"   // S18-VOX
#include "Sound/SoundClass.h" // S18-VOX
#include "EngineUtils.h"
#include "Engine/World.h"
#include "GameFramework/Pawn.h"
#include "DrawDebugHelpers.h"
#include "Components/StaticMeshComponent.h"

ATutorialGuideActor::ATutorialGuideActor()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 0.05f;
	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
}

void ATutorialGuideActor::BeginPlay()
{
	Super::BeginPlay();

	if (USquadAITutorialSubsystem* Tut = USquadAITutorialSubsystem::Get(this))
	{
		Tut->OnTutorialStepChanged.AddDynamic(this, &ATutorialGuideActor::HandleStepChanged);
		// Catch the step that is already running when we spawn.
		if (Tut->IsTutorialActive())
		{
			HandleStepChanged(Tut->GetCurrentStep());
		}
	}
	ResolveGuidePawn();
}

AActor* ATutorialGuideActor::ResolveGuidePawn()
{
	if (IsValid(ResolvedGuide))
	{
		return ResolvedGuide;
	}
	if (IsValid(GuidePawn))
	{
		ResolvedGuide = GuidePawn;
		return ResolvedGuide;
	}

	// Adopt the closest friendly soldier to the player — usually the leader.
	UWorld* World = GetWorld();
	APawn* Player = World ? UGameplayStatics::GetPlayerPawn(World, 0) : nullptr;
	if (!World || !Player)
	{
		return nullptr;
	}
	float BestDistSq = TNumericLimits<float>::Max();
	for (TActorIterator<ASoldierCharacter> It(World); It; ++It)
	{
		ASoldierCharacter* S = *It;
		if (!IsValid(S) || S == Player) continue;
		const float DSq = FVector::DistSquared(S->GetActorLocation(), Player->GetActorLocation());
		if (DSq < BestDistSq)
		{
			BestDistSq = DSq;
			ResolvedGuide = S;
		}
	}
	if (ResolvedGuide)
	{
		UE_LOG(LogTemp, Log, TEXT("[S18-TUTGUIDE] Adopted %s as the tutorial guide."), *ResolvedGuide->GetName());
	}
	return ResolvedGuide;
}

FVector ATutorialGuideActor::GetGuideLocation() const
{
	return IsValid(ResolvedGuide) ? ResolvedGuide->GetActorLocation() : GetActorLocation();
}

// ---------------------------------------------------------------------------
//  Speech
// ---------------------------------------------------------------------------
bool ATutorialGuideActor::IsSpeaking() const
{
	const UWorld* World = GetWorld();
	if (!World) return false;
	return LineQueue.Num() > 0 || (SubtitleEndTime > 0.f && World->GetTimeSeconds() < SubtitleEndTime);
}

void ATutorialGuideActor::SetDucking(bool bEnable)
{
	// S18-VOX: optional — silently does nothing unless both assets are set.
	UWorld* World = GetWorld();
	if (!World || !DuckingMix || !DuckingClass) return;
	if (bEnable == bDuckingActive) return;

	bDuckingActive = bEnable;
	if (bEnable)
	{
		UGameplayStatics::PushSoundMixModifier(World, DuckingMix);
		UGameplayStatics::SetSoundMixClassOverride(World, DuckingMix, DuckingClass,
			FMath::Clamp(DuckedVolume, 0.f, 1.f), 1.f, FMath::Max(0.f, DuckFadeSeconds), true);
	}
	else
	{
		UGameplayStatics::SetSoundMixClassOverride(World, DuckingMix, DuckingClass,
			1.f, 1.f, FMath::Max(0.f, DuckFadeSeconds), true);
		UGameplayStatics::PopSoundMixModifier(World, DuckingMix);
	}
}

void ATutorialGuideActor::Speak(const FString& TextFa, const FString& TextEn, USoundBase* Voice, float Seconds)
{
	SetActorTickEnabled(true); // S18-PERF
	UWorld* World = GetWorld();
	if (!World) return;

	// S18-VOX: if he is mid-sentence, queue instead of cutting himself off.
	if (SubtitleEndTime > 0.f && World->GetTimeSeconds() < SubtitleEndTime)
	{
		if (LineQueue.Num() < 6)
		{
			FGuidePendingLine Q;
			Q.Fa = TextFa;
			Q.En = TextEn;
			Q.Voice = Voice;
			Q.Seconds = Seconds;
			LineQueue.Add(MoveTemp(Q));
		}
		return;
	}

	SubtitleFa = TextFa;
	SubtitleEn = TextEn;
	SubtitleStartTime = World->GetTimeSeconds();
	SubtitleEndTime = SubtitleStartTime + FMath::Max(1.f, Seconds);

	if (Voice)
	{
		// At the guide so it pans correctly; falls back to 2D if he is nowhere.
		if (IsValid(ResolvedGuide))
		{
			UGameplayStatics::PlaySoundAtLocation(World, Voice, GetGuideLocation());
		}
		else
		{
			UGameplayStatics::PlaySound2D(World, Voice);
		}
	}
	SetDucking(true);
	UE_LOG(LogTemp, Log, TEXT("[S18-TUTGUIDE] \"%s\""), *TextEn);
}

FString ATutorialGuideActor::GetActiveSubtitleFor(bool bEnglish) const
{
	UWorld* World = GetWorld();
	if (!World || SubtitleEndTime < 0.f || World->GetTimeSeconds() > SubtitleEndTime)
	{
		return FString();
	}
	return bEnglish ? SubtitleEn : SubtitleFa;
}

float ATutorialGuideActor::GetSubtitleAlpha() const
{
	UWorld* World = GetWorld();
	if (!World || SubtitleEndTime < 0.f) return 0.f;
	const float Now = World->GetTimeSeconds();
	if (Now > SubtitleEndTime) return 0.f;
	const float FadeIn = FMath::Clamp((Now - SubtitleStartTime) / 0.25f, 0.f, 1.f);
	const float FadeOut = FMath::Clamp((SubtitleEndTime - Now) / 0.4f, 0.f, 1.f);
	return FMath::Min(FadeIn, FadeOut);
}

// ---------------------------------------------------------------------------
//  Step reactions
// ---------------------------------------------------------------------------
void ATutorialGuideActor::HandleStepChanged(ESquadAITutorialStep NewStep)
{
	SetActorTickEnabled(true); // S18-PERF: wake the guide for this beat
	// Authored line first, built-in fallback second — the tutorial must never be
	// silent just because the designer has not filled the map in yet.
	FSquadAIGuideLine Line;
	if (const FSquadAIGuideLine* Found = Lines.Find(NewStep))
	{
		Line = *Found;
	}

	if (Line.TextFa.IsEmpty() && Line.TextEn.IsEmpty())
	{
		switch (NewStep)
		{
		case ESquadAITutorialStep::UI_Objective:
			Line.TextFa = TEXT("خوش آمدی. اول صفحه را بشناس، بعد میدان را.");
			Line.TextEn = TEXT("Welcome. Learn your screen first, then the ground."); break;
		case ESquadAITutorialStep::UI_Squad:
			Line.TextFa = TEXT("حال بچه‌ها را همیشه زیر نظر داشته باش.");
			Line.TextEn = TEXT("Keep an eye on the lads at all times."); break;
		case ESquadAITutorialStep::UI_Compass:
			Line.TextFa = TEXT("بدون جهت، شجاعت به درد نمی‌خورد.");
			Line.TextEn = TEXT("Courage without a bearing is worth nothing."); break;
		case ESquadAITutorialStep::UI_Weapon:
			Line.TextFa = TEXT("مهماتت را بشمار. اینجا کسی برایت نمی‌آورد.");
			Line.TextEn = TEXT("Count your rounds. Nobody is bringing you more out here."); break;
		case ESquadAITutorialStep::UI_Artillery:
			Line.TextFa = TEXT("توپخانه رفیق توست — تا وقتی فاصله‌ات را حفظ کنی.");
			Line.TextEn = TEXT("The guns are your friend — as long as you keep your distance."); break;
		case ESquadAITutorialStep::Task_Move:
			Line.TextFa = TEXT("دنبال من. سرت را پایین نگه دار.");
			Line.TextEn = TEXT("With me. Keep your head down."); break;
		case ESquadAITutorialStep::Task_ShootCans:
			Line.TextFa = TEXT("نگاه کن، اینطوری. حالا تو بزن.");
			Line.TextEn = TEXT("Watch — like this. Now you do it."); break;
		case ESquadAITutorialStep::Task_Grenade:
			Line.TextFa = TEXT("ضامن را بکش، بشمار، بعد پرتاب کن. داخل بشکه.");
			Line.TextEn = TEXT("Pull, count, then throw. Into the barrel."); break;
		case ESquadAITutorialStep::Task_Artillery:
			Line.TextFa = TEXT("مختصات را بده و پناه بگیر.");
			Line.TextEn = TEXT("Send the coordinates and take cover."); break;
		case ESquadAITutorialStep::Finished:
			Line.TextFa = TEXT("آماده‌ای. خدا پشت و پناهت.");
			Line.TextEn = TEXT("You are ready. God keep you."); break;
		default:
			return; // SkipPrompt / Inactive: say nothing
		}
	}

	Speak(Line.TextFa, Line.TextEn, Line.Voice, Line.Seconds);

	if (bPhysicalDemonstration)
	{
		BeginDemonstration(NewStep);
	}
}

void ATutorialGuideActor::BeginDemonstration(ESquadAITutorialStep Step)
{
	SetActorTickEnabled(true); // S18-PERF
	UWorld* World = GetWorld();
	if (!World || !ResolveGuidePawn())
	{
		return;
	}

	DemoTarget = FVector::ZeroVector;

	if (Step == ESquadAITutorialStep::Task_ShootCans)
	{
		// Aim at the first can still standing.
		for (TActorIterator<ATutorialTargetCan> It(World); It; ++It)
		{
			if (!It->IsKnockedDown())
			{
				DemoTarget = It->GetActorLocation();
				break;
			}
		}
	}
	else if (Step == ESquadAITutorialStep::Task_Grenade)
	{
		for (TActorIterator<ATutorialGrenadeBarrel> It(World); It; ++It)
		{
			// S19-BARREL: aim the demonstration at the barrel's open mouth. Aiming
			// at the actor's origin (the middle of the drum) taught the player to
			// throw at the drum's side - the one place a grenade cannot go in.
			DemoTarget = It->GetActorLocation() + It->Mouth.MouthCentre();
			break;
		}
	}

	if (DemoTarget.IsNearlyZero())
	{
		PendingDemoStep = ESquadAITutorialStep::Inactive;
		return;
	}

	PendingDemoStep = Step;
	DemoFireTime = World->GetTimeSeconds() + FMath::Max(0.5f, DemoWindUpSeconds);
	FaceTowards(DemoTarget);
}

void ATutorialGuideActor::FaceTowards(const FVector& Target) const
{
	if (!IsValid(ResolvedGuide)) return;
	FVector Dir = Target - ResolvedGuide->GetActorLocation();
	Dir.Z = 0.f;
	if (Dir.Normalize())
	{
		ResolvedGuide->SetActorRotation(Dir.Rotation());
	}
}

void ATutorialGuideActor::FireDemonstration()
{
	UWorld* World = GetWorld();
	if (!World) return;

	const FVector From = GetGuideLocation() + FVector(0.f, 0.f, 60.f);

	if (DemoShotSound)
	{
		UGameplayStatics::PlaySoundAtLocation(World, DemoShotSound, From);
	}

	if (PendingDemoStep == ESquadAITutorialStep::Task_ShootCans)
	{
		// He drops ONE can so the player sees what "done" looks like, and the
		// tutorial deliberately does NOT count it — the player still shoots his
		// own three. (RegisterHit reports progress, so we bypass it and knock
		// the mesh over by hand.)
		for (TActorIterator<ATutorialTargetCan> It(World); It; ++It)
		{
			ATutorialTargetCan* Can = *It;
			if (!Can || Can->IsKnockedDown()) continue;
			if (!FVector::PointsAreNear(Can->GetActorLocation(), DemoTarget, 60.f)) continue;
			// S18-FIX: simulating a static-mobility component throws a warning
			// and silently does nothing — check first.
			if (Can->CanMesh && Can->CanMesh->Mobility == EComponentMobility::Movable)
			{
				Can->CanMesh->SetCollisionEnabled(ECollisionEnabled::PhysicsOnly);
				Can->CanMesh->SetSimulatePhysics(true);
				const FVector Dir = (Can->GetActorLocation() - From).GetSafeNormal();
				Can->CanMesh->AddImpulse((Dir + FVector(0.f, 0.f, 0.4f)) * 16000.f, NAME_None, true);
			}
			Can->SetLifeSpan(6.f);
			UE_LOG(LogTemp, Log, TEXT("[S18-TUTGUIDE] Demonstration shot — one can knocked down (not counted)."));
			break;
		}
	}
	else if (PendingDemoStep == ESquadAITutorialStep::Task_Grenade)
	{
		// No live grenade: a visible arc is enough to teach the shape of the
		// throw, and it cannot satisfy the player's own objective by accident.
		const FVector Apex = (From + DemoTarget) * 0.5f + FVector(0.f, 0.f, 260.f);
		constexpr int32 Steps = 14;
		FVector Prev = From;
		for (int32 i = 1; i <= Steps; ++i)
		{
			const float T = static_cast<float>(i) / Steps;
			const FVector Pt = FMath::Lerp(FMath::Lerp(From, Apex, T), FMath::Lerp(Apex, DemoTarget, T), T);
			DrawDebugLine(World, Prev, Pt, FColor(255, 200, 70), false, 3.0f, 0, 2.5f);
			Prev = Pt;
		}
		DrawDebugSphere(World, DemoTarget, 60.f, 12, FColor(255, 160, 50), false, 3.0f, 0, 2.f);
	}

	PendingDemoStep = ESquadAITutorialStep::Inactive;
	DemoFireTime = -1.f;
}

void ATutorialGuideActor::EndPlay(const EEndPlayReason::Type Reason)
{
	SetDucking(false); // S18-VOX: never leave the world ducked
	LineQueue.Reset();
	Super::EndPlay(Reason);
}

void ATutorialGuideActor::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	UWorld* World = GetWorld();
	if (!World) return;

	// S18-VOX: when the current line ends, start the next one, or lift the duck.
	if (SubtitleEndTime > 0.f && World->GetTimeSeconds() >= SubtitleEndTime)
	{
		if (LineQueue.Num() > 0)
		{
			const FGuidePendingLine Next = LineQueue[0];
			LineQueue.RemoveAt(0);
			SubtitleEndTime = -1.f; // let Speak take the direct path
			Speak(Next.Fa, Next.En, Next.Voice, Next.Seconds);
		}
		else if (bDuckingActive)
		{
			SetDucking(false);
		}
	}

	if (DemoFireTime > 0.f && World->GetTimeSeconds() >= DemoFireTime)
	{
		FireDemonstration();
	}

	// Keep him looking at whatever he is talking about.
	if (PendingDemoStep != ESquadAITutorialStep::Inactive && !DemoTarget.IsNearlyZero())
	{
		FaceTowards(DemoTarget);
	}
	else if (DemoFireTime <= 0.f && !IsSpeaking() && !bDuckingActive)
	{
		// S18-PERF: nothing pending — stop ticking entirely. OnTutorialStepChanged
		// turns the tick back on when there is something to do.
		SetActorTickEnabled(false);
	}
}

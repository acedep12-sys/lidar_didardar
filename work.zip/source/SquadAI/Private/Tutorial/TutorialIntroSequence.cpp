// TutorialIntroSequence.cpp — S18-INTRO
#include "Tutorial/TutorialIntroSequence.h"
#include "Tutorial/TutorialGuideActor.h"
#include "Tutorial/SquadAITutorialSubsystem.h"
#include "Quest/MissionZone.h"
#include "HUD/QuestNativeHUD.h"
#include "SaveSystem/SquadAISaveLoadSubsystem.h"
#include "SaveSystem/SquadAISaveGame.h" // FSquadGameSettingsSaveData
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/Pawn.h"
#include "Components/SceneComponent.h"
#include "AIController.h"
#include "Blueprint/AIBlueprintHelperLibrary.h"
#include "Kismet/GameplayStatics.h"
#include "EngineUtils.h"
#include "Engine/World.h"

ATutorialIntroSequence::ATutorialIntroSequence()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 0.05f;
	PrimaryActorTick.bStartWithTickEnabled = false; // S18-PERF: only ticks while running
	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
}

void ATutorialIntroSequence::BeginPlay()
{
	Super::BeginPlay();
	if (Beats.Num() == 0)
	{
		BuildDefaultBeats();
	}
	// S18-INTRO2: a later mission can own its own walk — bind to that zone's
	// state change instead of starting at level open.
	if (TriggerMission)
	{
		TriggerMission->OnMissionStateChanged.AddUniqueDynamic(this, &ATutorialIntroSequence::HandleMissionStateChanged);
		UE_LOG(LogTemp, Log, TEXT("[S18-INTRO] Waiting for mission '%s' to activate."), *TriggerMission->GetName());
	}

	if (bAutoStart && !TriggerMission && GetWorld())
	{
		GetWorld()->GetTimerManager().SetTimer(StartTimer, FTimerDelegate::CreateWeakLambda(this, [this]()
		{
			StartIntro();
		}), FMath::Max(0.05f, StartDelaySeconds), false);
	}
}

// ---------------------------------------------------------------------------
//  Default script — works with zero authoring: the guide walks a short way
//  along the trench from his own start, speaking as he goes, then hands over.
// ---------------------------------------------------------------------------
void ATutorialIntroSequence::BuildDefaultBeats()
{
	auto Add = [this](ESquadAIIntroAction A, const TCHAR* Fa, const TCHAR* En, float Radius, float Dwell)
	{
		FSquadAIIntroBeat B;
		B.Action = A;
		B.LineFa = Fa;
		B.LineEn = En;
		B.Radius = Radius;
		B.DwellSeconds = Dwell;
		Beats.Add(B);
	};

	Add(ESquadAIIntroAction::SayOnly,
		TEXT("رسیدی. اسلحه‌ات را بگیر و پشت سرم بیا — اینجا سر بلند کردن یعنی تمام."),
		TEXT("You made it. Take your rifle and stay behind me — raising your head here is the end of you."),
		350.f, 2.2f);

	Add(ESquadAIIntroAction::WalkAndSay,
		TEXT("این سنگر خط اول است. پایش را روی تخته‌ها بگذار، نه روی گِل."),
		TEXT("This is the forward trench. Walk the boards, not the mud."),
		350.f, 1.4f);

	Add(ESquadAIIntroAction::WaitForPlayer,
		TEXT("عقب نمان. جدا شدن از جوخه یعنی اسیر شدن."),
		TEXT("Don't fall behind. Separated from the squad means captured."),
		500.f, 1.0f);

	Add(ESquadAIIntroAction::WalkAndSay,
		TEXT("از اینجا به بعد سیم خاردار است. مسیر فقط همین دهانه است."),
		TEXT("Wire starts from here. This gap is the only way through."),
		350.f, 1.4f);

	Add(ESquadAIIntroAction::HandOffToTutorial,
		TEXT("خوب. حالا ببینیم چه بلدی. چند قوطی برایت گذاشته‌ام."),
		TEXT("Good. Now let's see what you know. I've set a few cans out for you."),
		350.f, 0.8f);
}

ATutorialGuideActor* ATutorialIntroSequence::ResolveGuide()
{
	if (IsValid(Guide)) return Guide;
	for (TActorIterator<ATutorialGuideActor> It(GetWorld()); It; ++It)
	{
		Guide = *It;
		break;
	}
	return Guide;
}

AActor* ATutorialIntroSequence::GuidePawnActor() const
{
	return IsValid(Guide) ? Guide->GetGuideActor() : nullptr;
}

// ---------------------------------------------------------------------------
void ATutorialIntroSequence::StartIntro()
{
	UWorld* World = GetWorld();
	if (!World || bRunning || Beats.Num() == 0) return;

	// S18-FIX: a veteran must never be walked down the trench again. Read the
	// same saved flags the tutorial itself gates on.
	if (USquadAISaveLoadSubsystem* SaveSys = USquadAISaveLoadSubsystem::Get(this))
	{
		const FSquadGameSettingsSaveData Settings = SaveSys->GetCachedSettings();
		if (bOnlyBeforeTutorial && (Settings.bTutorialCompleted || Settings.bTutorialSkipped))
		{
			UE_LOG(LogTemp, Log, TEXT("[S18-INTRO] Training already handled — intro skipped."));
			return;
		}
		// S18-INTRO2: once-per-level, so reloading a mid-mission save does not
		// replay the opening walk.
		if (bPlayOncePerLevel && Settings.PlayedIntroLevels.Contains(GetLevelKey()))
		{
			UE_LOG(LogTemp, Log, TEXT("[S18-INTRO] '%s' already played its intro — skipped."), *GetLevelKey());
			return;
		}
	}
	if (USquadAITutorialSubsystem* Tut = USquadAITutorialSubsystem::Get(this))
	{
		if (Tut->GetCurrentStep() == ESquadAITutorialStep::Finished)
		{
			return;
		}
	}

	ResolveGuide();
	if (LeadWalkSpeed > 0.f)
	{
		if (ACharacter* GC = Cast<ACharacter>(GuidePawnActor()))
		{
			if (UCharacterMovementComponent* M = GC->GetCharacterMovement())
			{
				M->MaxWalkSpeed = LeadWalkSpeed;
			}
		}
	}

	// S18-INTRO3: if a mission briefing card is still on screen, hold off —
	// two voices at once is amateur hour. Re-check twice a second.
	if (bWaitForBriefingCard)
	{
		if (const AQuestNativeHUD* HUD = AQuestNativeHUD::Get(this))
		{
			if (HUD->IsReaderCardOpen())
			{
				UE_LOG(LogTemp, Log, TEXT("[S18-INTRO] Briefing card open — waiting."));
				if (UWorld* W = GetWorld())
				{
					W->GetTimerManager().SetTimer(StartTimer, FTimerDelegate::CreateWeakLambda(this, [this]()
					{
						StartIntro();
					}), 0.5f, false);
				}
				return;
			}
		}
	}

	bRunning = true;
	SetActorTickEnabled(true);
	UE_LOG(LogTemp, Warning, TEXT("[S18-INTRO] Intro walk started (%d beats)."), Beats.Num());
	EnterBeat(0);
}

FString ATutorialIntroSequence::GetLevelKey() const
{
	// S18-INTRO2: level name + this actor's name, so two intro actors in one
	// level (a mission-triggered second walk, say) are tracked separately.
	const UWorld* World = GetWorld();
	const FString LevelName = World ? World->GetMapName() : TEXT("UnknownLevel");
	return LevelName + TEXT("::") + GetName();
}

void ATutorialIntroSequence::MarkIntroPlayed()
{
	USquadAISaveLoadSubsystem* SaveSys = USquadAISaveLoadSubsystem::Get(this);
	if (!SaveSys || !bPlayOncePerLevel) return;

	FSquadGameSettingsSaveData Settings = SaveSys->GetCachedSettings();
	const FString Key = GetLevelKey();
	if (!Settings.PlayedIntroLevels.Contains(Key))
	{
		Settings.PlayedIntroLevels.Add(Key);
		SaveSys->SaveSettings(Settings);
		UE_LOG(LogTemp, Log, TEXT("[S18-INTRO] Marked '%s' as played."), *Key);
	}
}

void ATutorialIntroSequence::SkipIntro()
{
	if (!bRunning) return;
	MarkIntroPlayed();
	bRunning = false;
	SetActorTickEnabled(false);
	CurrentBeat = INDEX_NONE;
	UE_LOG(LogTemp, Warning, TEXT("[S18-INTRO] Intro skipped — handing over to the tutorial."));
	if (USquadAITutorialSubsystem* Tut = USquadAITutorialSubsystem::Get(this))
	{
		if (!Tut->IsTutorialActive())
		{
			Tut->StartTutorial();
		}
	}
}

void ATutorialIntroSequence::HandleMissionStateChanged(AMissionZone* Mission, EMissionZoneState NewState)
{
	// S18-INTRO2: start the walk the moment the bound mission goes active.
	if (!Mission || Mission != TriggerMission || bRunning) return;
	if (NewState != EMissionZoneState::Active) return;

	UE_LOG(LogTemp, Warning, TEXT("[S18-INTRO] Mission '%s' activated — starting its walk."), *Mission->GetName());
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().SetTimer(StartTimer, FTimerDelegate::CreateWeakLambda(this, [this]()
		{
			StartIntro();
		}), FMath::Max(0.05f, StartDelaySeconds), false);
	}
}

void ATutorialIntroSequence::EnterBeat(int32 Index)
{
	UWorld* World = GetWorld();
	if (!World) return;

	if (!Beats.IsValidIndex(Index))
	{
		SkipIntro(); // end of script = hand off
		return;
	}

	CurrentBeat = Index;
	LastMoveTarget = FVector(FLT_MAX); // S18-FIX: force a fresh path on the new beat
	NextMoveRefresh = -1.f;
	BeatStartTime = World->GetTimeSeconds();
	DwellUntil = -1.f;
	bBeatSpoken = false;

	const FSquadAIIntroBeat& B = Beats[Index];
	UE_LOG(LogTemp, Log, TEXT("[S18-INTRO] Beat %d/%d (action %d)."), Index + 1, Beats.Num(),
		static_cast<int32>(B.Action));

	// "Just speak" and the hand-off say their line immediately.
	if (B.Action == ESquadAIIntroAction::SayOnly || B.Action == ESquadAIIntroAction::HandOffToTutorial)
	{
		if (ResolveGuide())
		{
			Guide->Speak(B.LineFa, B.LineEn, B.Voice, FMath::Max(2.5f, B.DwellSeconds + 2.5f));
		}
		bBeatSpoken = true;
		DwellUntil = World->GetTimeSeconds() + FMath::Max(0.1f, B.DwellSeconds + 2.0f);
	}
}

void ATutorialIntroSequence::AdvanceBeat()
{
	const int32 Next = CurrentBeat + 1;
	if (Beats.IsValidIndex(CurrentBeat) && Beats[CurrentBeat].Action == ESquadAIIntroAction::HandOffToTutorial)
	{
		SkipIntro();
		return;
	}
	EnterBeat(Next);
}

bool ATutorialIntroSequence::MoveGuideTo(const FVector& Target, float Accept, float DeltaSeconds)
{
	AActor* GuideActor = GuidePawnActor();
	if (!GuideActor)
	{
		return true; // nobody to move — treat as arrived so the script continues
	}

	const float DistSq = FVector::DistSquared2D(GuideActor->GetActorLocation(), Target);
	if (DistSq <= FMath::Square(FMath::Max(80.f, Accept)))
	{
		return true;
	}

	// Prefer real navigation; fall back to a straight interp if the pawn has no
	// controller (so a plain StaticMeshActor stand-in still works).
	if (APawn* GuidePawnPtr = Cast<APawn>(GuideActor))
	{
		if (AAIController* AIC = Cast<AAIController>(GuidePawnPtr->GetController()))
		{
			// S18-FIX: re-issuing MoveToLocation every tick cancels and rebuilds
			// the path each time, which both costs CPU and makes the guide stutter.
			// Issue once per destination, then only refresh every 2 s.
			const float Now = GetWorld() ? GetWorld()->GetTimeSeconds() : 0.f;
			if (!LastMoveTarget.Equals(Target, 50.f) || Now >= NextMoveRefresh)
			{
				AIC->MoveToLocation(Target, Accept, true, true, false, true);
				LastMoveTarget = Target;
				NextMoveRefresh = Now + 2.0f;
			}
			return false;
		}
		UAIBlueprintHelperLibrary::SimpleMoveToLocation(GuidePawnPtr->GetController(), Target);
		return false;
	}

	const FVector Dir = (Target - GuideActor->GetActorLocation()).GetSafeNormal2D();
	GuideActor->SetActorLocation(GuideActor->GetActorLocation() + Dir * FMath::Max(50.f, LeadWalkSpeed) * DeltaSeconds, true);
	GuideActor->SetActorRotation(Dir.Rotation());
	return false;
}

void ATutorialIntroSequence::EndPlay(const EEndPlayReason::Type Reason)
{
	// S18-FIX2: tidy teardown — the weak lambda was already safe, but leaving a
	// live handle around during seamless travel is asking for trouble.
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(StartTimer);
	}
	bRunning = false;
	Super::EndPlay(Reason);
}

void ATutorialIntroSequence::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	UWorld* World = GetWorld();
	if (!bRunning || !World || !Beats.IsValidIndex(CurrentBeat)) return;

	const FSquadAIIntroBeat& B = Beats[CurrentBeat];
	const float Now = World->GetTimeSeconds();
	APawn* Player = UGameplayStatics::GetPlayerPawn(World, 0);

	// Dwell: the beat is resolved, we are just letting the line land.
	if (DwellUntil > 0.f)
	{
		if (Now >= DwellUntil)
		{
			AdvanceBeat();
		}
		return;
	}

	// Safety valve so a blocked navmesh can never strand the player.
	if (B.TimeoutSeconds > 0.f && (Now - BeatStartTime) > B.TimeoutSeconds)
	{
		UE_LOG(LogTemp, Warning, TEXT("[S18-INTRO] Beat %d timed out — moving on."), CurrentBeat + 1);
		AdvanceBeat();
		return;
	}

	switch (B.Action)
	{
	case ESquadAIIntroAction::WalkAndSay:
	{
		const FVector Target = B.Point ? B.Point->GetActorLocation()
			: (Player ? Player->GetActorLocation() + Player->GetActorForwardVector() * 900.f : GetActorLocation());

		// Hold position if the player is lagging — the guide never abandons him.
		const AActor* GuideA = GuidePawnActor();
		const bool bPlayerLagging = Player && GuideA
			&& FVector::Dist2D(Player->GetActorLocation(), GuideA->GetActorLocation()) > PlayerLagDistance;

		if (!bPlayerLagging && MoveGuideTo(Target, B.Radius, DeltaSeconds))
		{
			if (!bBeatSpoken && ResolveGuide())
			{
				Guide->Speak(B.LineFa, B.LineEn, B.Voice, FMath::Max(2.5f, B.DwellSeconds + 2.5f));
				bBeatSpoken = true;
			}
			DwellUntil = Now + FMath::Max(0.1f, B.DwellSeconds + 1.5f);
		}
		break;
	}

	case ESquadAIIntroAction::WaitForPlayer:
	{
		const AActor* GuideA = GuidePawnActor();
		const FVector Here = GuideA ? GuideA->GetActorLocation()
			: (B.Point ? B.Point->GetActorLocation() : GetActorLocation());
		if (Player && FVector::Dist2D(Player->GetActorLocation(), Here) <= B.Radius)
		{
			if (!bBeatSpoken && ResolveGuide())
			{
				Guide->Speak(B.LineFa, B.LineEn, B.Voice, FMath::Max(2.5f, B.DwellSeconds + 2.5f));
				bBeatSpoken = true;
			}
			DwellUntil = Now + FMath::Max(0.1f, B.DwellSeconds);
		}
		break;
	}

	case ESquadAIIntroAction::SayOnly:
	case ESquadAIIntroAction::HandOffToTutorial:
	default:
		// Handled on entry; the dwell timer carries them.
		break;
	}
}

FString ATutorialIntroSequence::GetIntroObjective(bool bEnglish) const
{
	if (!bRunning || !Beats.IsValidIndex(CurrentBeat))
	{
		return FString();
	}
	const FSquadAIIntroBeat& B = Beats[CurrentBeat];
	switch (B.Action)
	{
	case ESquadAIIntroAction::WaitForPlayer:
	case ESquadAIIntroAction::WalkAndSay:
		return bEnglish ? ObjectiveFollowEn : ObjectiveFollowFa;
	default:
		return bEnglish ? ObjectiveListenEn : ObjectiveListenFa;
	}
}

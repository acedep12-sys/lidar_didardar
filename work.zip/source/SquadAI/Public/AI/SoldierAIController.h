// SoldierAIController.h — Base AI controller
#pragma once

#include "CoreMinimal.h"
#include "AIController.h"
#include "AI/SquadAICommandTypes.h"
#include "SquadTypes.h"
#include "Navigation/CrowdFollowingComponent.h"
#include "GameplayTasksComponent.h"
#include "SoldierAIController.generated.h"

class UAIPerceptionComponent;
class UAISenseConfig_Sight;
class UAISenseConfig_Hearing;
class UAISenseConfig_Damage;
class UStateTreeAIComponent;
class ASoldierCharacter;
class AMissionZone;
class AQuestChain;
class AQuestZone;   // S9-FIX: was used at CachedFallbackQuestZone without a declaration
class USquadAIAdapterComponent;

UCLASS(BlueprintType, Blueprintable)
class SQUADAI_API ASoldierAIController : public AAIController
{
	GENERATED_BODY()

public:
	ASoldierAIController(const FObjectInitializer& OI = FObjectInitializer::Get());

	// ---- Mission Data (Direct Drive) ----
	UPROPERTY(BlueprintReadWrite, Category = "AI|Mission")
	FVector CurrentGoalLocation = FVector::ZeroVector;

	UPROPERTY(BlueprintReadWrite, Category = "AI|Mission")
	bool bHasActiveGoal = false;

	UPROPERTY(BlueprintReadOnly, Category = "AI|Commands")
	FSquadAIMoveCommand ActiveMoveCommand;

	UPROPERTY(BlueprintReadOnly, Category = "AI|Commands")
	FSquadAIAimCommand ActiveAimCommand;

	UFUNCTION(BlueprintCallable, Category = "AI|Commands")
	void SetMoveCommand(const FSquadAIMoveCommand& NewCommand);

	UFUNCTION(BlueprintCallable, Category = "AI|Commands")
	void ClearMoveCommand();

	UFUNCTION(BlueprintCallable, Category = "AI|Commands")
	void SetAimCommand(const FSquadAIAimCommand& NewCommand);

	UFUNCTION(BlueprintCallable, Category = "AI|Commands")
	void ClearAimCommand();

	/** S19-PATROL: virtual so a controller subclass can answer with something other than the
	 *  mission goal - AEnemyPatrolAIController returns the patrol point while its patrol is
	 *  calm. Everything that asks a controller where it is going goes through here, which is
	 *  what makes that one override enough. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "AI|Commands")
	virtual FVector GetEffectiveMoveGoal() const;

	// Filter Output Log with: PATHDBG
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AI|PathDebug")
	bool bDebugLeaderPath = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AI|PathDebug")
	bool bDrawLeaderPath = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AI|FireAvoid")
	bool bAvoidFireOnPath = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AI|FireAvoid", meta = (ClampMin = "0"))
	float FireAvoidPadding = 120.f;

	// Crossings thinner than this (cm) are sprinted through. Wider fires are walked around.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AI|FireAvoid", meta = (ClampMin = "0"))
	float FireSprintThroughMaxWidth = 280.f;

	UFUNCTION(CallInEditor, BlueprintCallable, Category = "AI|PathDebug")
	void DumpLeaderPathDebug();

	UFUNCTION(BlueprintCallable, Category = "AI|FireAvoid")
	FVector NudgeOutOfFire(const FVector& From, const FVector& To) const;

	FVector ProjectToNav(const FVector& P) const;

	/** S19-HUNT: the enemy a leader who has ARRIVED at an active zone should go after, or
	 *  nullptr when there is nothing left to hunt.
	 *
	 *  This lives on the controller, not in the state-tree task, because TWO movement
	 *  owners drive the leader: STTask_LeaderPath while it owns movement, and
	 *  RunDirectMissionPathing whenever it does not. Both ask GetEffectiveMoveGoal(), so
	 *  putting the decision here means "the leader hunts the rest of the objective" cannot
	 *  be lost by a state transition. Scans at most every 0.5 s.
	 *
	 *  Returns nullptr unless: the controller is the leader's, the active mission zone has
	 *  bHuntRemainingEnemiesOnArrival set, the leader is within HuntActivationRadius of the
	 *  zone, and at least one enemy the zone spawned is still alive. */
	AActor* GetLeaderHuntTarget() const;

	/** How many enemies were left at the objective when the current target was picked
	 *  (log/diagnostic only). */
	int32 GetLeaderHuntRemaining() const { return LeaderHuntRemaining; }

	/** S18-LEAD: STTask_LeaderPath calls this every tick while it owns the
	 *  leader's movement. RunDirectMissionPathing then stands down, so the two
	 *  movement owners stop cancelling each other's path requests. */
	void NotifyLeaderPathTaskActive();
	bool IsLeaderPathTaskDriving() const;
	void RedirectIfPathHitsFire();

	// Ally slot on the leader's trench, or V-formation if no spline.
	UFUNCTION(BlueprintCallable, Category = "AI|PathDebug")
	FVector GetAllyCorridorSlot(APawn* Leader, int32 Slot, float Spacing) const;

	UPROPERTY(BlueprintReadOnly, Category = "AI|PathDebug")
	mutable float PathSpeedScale = 1.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AI|PathDebug", meta = (ClampMin = "0.3", ClampMax = "1.0"))
	float TrenchWalkSpeedScale = 0.68f;

	UFUNCTION(BlueprintCallable, Category = "AI|Commands")
	void SetCombatAimTarget(FVector AimLocation, ESquadAIAimMode AimMode = ESquadAIAimMode::CombatTarget, AActor* TargetActor = nullptr);

	UFUNCTION(BlueprintCallable, Category = "AI|Commands")
	bool TryStartBurstAtCurrentAim();

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "AI|Commands")
	bool IsBurstFiring() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "AI|Commands")
	bool HasCombatAimCommand() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "AI|Commands")
	bool CanUseAdapterPresentation() const;

	UFUNCTION(BlueprintCallable, Category = "AI|Commands")
	void StopCombatPresentation();

	UFUNCTION(BlueprintCallable, Category = "AI|Mission")
	AMissionZone* FindActiveMissionZone() const;

	/** S11-AI: first AQuestZone in this world, cached per controller.
	 *  Shared by the leader pathing and the enemy mission StateTree task so both
	 *  sides fall back to the same objective when there is no MissionZone/chain. */
	AQuestZone* GetFallbackQuestZone();

	UFUNCTION(BlueprintCallable, Category = "AI|StateTree")
	void RestartStateTree();

	// Persistent movement bookkeeping for StateTree tasks. Do not keep this only in
	// StateTree instance data, because some StateTree setups can re-enter/recreate
	// task instance data and spam MoveTo every tick.
	UPROPERTY(BlueprintReadOnly, Category = "AI|Mission")
	FVector LastMissionMoveGoal = FVector::ZeroVector;

	UPROPERTY(BlueprintReadOnly, Category = "AI|Mission")
	float LastMissionMoveRequestTime = -1000.f;

	// ---- Team Logic ----
	virtual FGenericTeamId GetGenericTeamId() const override { return TeamId; }
	virtual void SetGenericTeamId(const FGenericTeamId& InID) override { TeamId = InID; }
	virtual ETeamAttitude::Type GetTeamAttitudeTowards(const AActor& Other) const override;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AI")
	FGenericTeamId TeamId;

	// ---- Components ----
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "AI")
	TObjectPtr<UAIPerceptionComponent> PerceptionComp;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "AI")
	TObjectPtr<UStateTreeAIComponent> StateTreeComp;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "AI")
	TObjectPtr<UGameplayTasksComponent> TasksComp;

	// ---- Suppression ----
	UPROPERTY(BlueprintReadOnly, Category = "AI|Suppression")
	float Suppression = 0.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AI|Suppression")
	float SuppressionDecayPerSec = 0.4f;

	UFUNCTION(BlueprintCallable, Category = "AI|Suppression")
	void AddSuppression(float Amount);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "AI|Suppression")
	float GetSuppression() const { return Suppression; }

	// ---- Threat Memory ----
	UPROPERTY(BlueprintReadOnly, Category = "AI|Memory")
	TArray<FPerceivedTarget> Memory;

	// Safety net: keeps combat responsive even if a StateTree asset is missing the
	// threat transitions/evaluators or initial perception events were missed.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AI|Combat")
	bool bEnableDirectCombatFallback = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AI|Combat")
	float DirectCombatRange = 9000.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AI|Combat")
	float DirectCombatBurstCooldown = 1.25f;

	// Now that StateTree threat transitions work, direct fallback should mainly feed memory/aim.
	// Keep this false for production so AI does not shoot while it is supposed to be moving to cover.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AI|Combat")
	bool bAllowDirectCombatFallbackFire = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AI|Combat")
	float DirectCombatFallbackFireRange = 4500.f;

	// At very close range, force recognition even if the Visibility trace is blocked by
	// character attachments/capsules/terrain seams. Prevents soldiers standing idle face-to-face.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AI|Combat")
	float DirectCombatCloseRangeOverride = 1600.f;

	UFUNCTION(BlueprintCallable, Category = "AI|Memory")
	AActor* GetPrimaryThreat(float& OutConfidence) const;

	// ---- S19-STORM -------------------------------------------------------
	// The live log (`grip_fixed.txt`) shows BOTH the ally and the leader entering the
	// Engage task ~20 times per second for 25 s straight ("[SquadAIEngageDebug] Enter
	// BP_Ally... StartPhase=Waiting" x496, x495 for the leader). Engage exits immediately
	// because the only "threat" in memory is a pack enemy 300 m away while the task's
	// fighting range is 80 m - and the pack's state-tree transition re-enters it because
	// the threat exists at all. While that loop runs, no follow / path task keeps control:
	// the ally stands crouched in cover ("the fighter won't follow after healing") and the
	// leader's movement is re-issued every frame ("walks back and forth").
	//
	// NoteEngageEntry() counts entries and reports a storm; SuppressPrimaryThreat() then
	// drops the belief that feeds the transition, for a few seconds.
	bool NoteEngageEntry();
	void SuppressPrimaryThreat(float Seconds, const TCHAR* Why);

	// S5-12: clean AI slate for pool sleep/wake — old runs left perceived-hostile memory,
	// zone/goal caches and focus artifacts attached to pooled enemies ("instant aggression
	// from nowhere" / walking to the previous run's objective).
	void ResetCombatState();

	UFUNCTION(BlueprintCallable, Category = "AI|Memory")
	TArray<AActor*> GetCurrentlyVisibleHostiles() const;

	// ---- Cover ----
	UPROPERTY(BlueprintReadOnly, Category = "AI|Cover")
	FCoverPoint PendingCoverResult;

	UPROPERTY(BlueprintReadOnly, Category = "AI|Cover")
	bool bHasPendingCover = false;

	UPROPERTY(BlueprintReadOnly, Category = "AI|Cover")
	bool bCoverQueryFinished = false;

	UPROPERTY(BlueprintReadOnly, Category = "AI|Cover")
	bool bLastCoverQuerySucceeded = false;

	UPROPERTY(BlueprintReadOnly, Category = "AI|Cover")
	FCoverPoint CurrentCover;

	UPROPERTY(BlueprintReadOnly, Category = "AI|Cover")
	bool bHasCover = false;

	// Controller-held cover reservation. TakeCover transfers its reservation here on exit
	// while the AI still engages from the point, so teammates cannot steal it mid-fight
	// (released when a new point is secured, cover is cleared, or the AI dies).
	UPROPERTY(BlueprintReadOnly, Category = "AI|Cover")
	FIntPoint HeldCoverChunk = FIntPoint::ZeroValue;

	UPROPERTY(BlueprintReadOnly, Category = "AI|Cover")
	int32 HeldCoverLocalID = -1;

	UPROPERTY(BlueprintReadOnly, Category = "AI|Cover")
	bool bHasHeldCover = false;

	// Controller-level cover movement state. StateTree tasks may be re-entered by
	// global transitions while a threat is visible; keeping the goal here prevents
	// TakeCover from restarting the query every frame and never issuing movement.
	UPROPERTY(BlueprintReadOnly, Category = "AI|Cover")
	FVector ActiveCoverMoveGoal = FVector::ZeroVector;

	UPROPERTY(BlueprintReadOnly, Category = "AI|Cover")
	bool bHasActiveCoverMoveGoal = false;

	UPROPERTY(BlueprintReadOnly, Category = "AI|Cover")
	bool bActiveCoverMoveUsesRealCover = false;

	UPROPERTY(BlueprintReadOnly, Category = "AI|Cover")
	float ActiveCoverMoveStartedTime = -1000.f;

	UPROPERTY(BlueprintReadOnly, Category = "AI|Cover")
	float LastCoverRequestTime = -1000.f;

	UPROPERTY(BlueprintReadOnly, Category = "AI|Cover")
	float LastTakeCoverCompletedTime = -1000.f;

	// If a StateTree has a broad/global "HasVision -> TakeCover" transition, this cooldown
	// prevents it from re-entering TakeCover every frame and starving Engage.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AI|Cover")
	float TakeCoverReentryCooldown = 8.0f;

	UFUNCTION(BlueprintCallable, Category = "AI|Cover")
	void RequestCover(FVector ThreatLocation, float SearchRadius = 2000.f);

	UFUNCTION(BlueprintCallable, Category = "AI|Cover")
	void SetActiveCoverMoveGoal(FVector GoalLocation, bool bUsesRealCover);

	UFUNCTION(BlueprintCallable, Category = "AI|Cover")
	void ClearActiveCoverMoveGoal(bool bMarkTakeCoverCompleted = false);

	UFUNCTION(BlueprintCallable, Category = "AI|Cover")
	void HoldCoverReservation(const FIntPoint& ChunkKey, int32 LocalID);

	UFUNCTION(BlueprintCallable, Category = "AI|Cover")
	void ReleaseHeldCoverReservation();

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "AI|Cover")
	bool HasActiveCoverMoveGoal() const { return bHasActiveCoverMoveGoal; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "AI|Cover")
	FVector GetActiveCoverMoveGoal() const { return ActiveCoverMoveGoal; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "AI|Cover")
	bool IsActiveCoverMoveUsingRealCover() const { return bActiveCoverMoveUsesRealCover; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "AI|Cover")
	float GetActiveCoverMoveStartedTime() const { return ActiveCoverMoveStartedTime; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "AI|Cover")
	float GetLastCoverRequestTime() const { return LastCoverRequestTime; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "AI|Cover")
	float GetLastTakeCoverCompletedTime() const { return LastTakeCoverCompletedTime; }

	// ---- LOD & Performance ----
	UPROPERTY(BlueprintReadOnly, Category = "AI|LOD")
	int32 CurrentLODBucket = 0;

	UPROPERTY(BlueprintReadOnly, Category = "AI|LOD")
	float SignificanceUpdateMultiplier = 1.f;

	UPROPERTY(BlueprintReadOnly, Category = "AI|LOD")
	bool bSkipExpensivePerceptionPolling = false;

	UPROPERTY(BlueprintReadWrite, Category = "AI|LOD")
	bool bForceFullTick = false;

	float ForceFullTickUntil = 0.f;

	// ---- Helpers ----
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "AI")
	ASoldierCharacter* GetSoldierCharacter() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "AI")
	bool HasLineOfSightTo(AActor* Target) const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "AI|Combat")
	bool HasCombatThreat(float MinConfidence = 0.25f) const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "AI|Combat")
	bool HasNearbyHostile(float Range) const;

	// Wave fireteam (set by UEnemyFireteamSubsystem). Unassigned = not in a wave squad.
	UPROPERTY(BlueprintReadOnly, Category = "AI|Fireteam")
	EEnemyFireteamRole FireteamRole = EEnemyFireteamRole::Unassigned;

	UPROPERTY(BlueprintReadOnly, Category = "AI|Fireteam")
	FVector FireteamMoveGoal = FVector::ZeroVector;

	UPROPERTY(BlueprintReadOnly, Category = "AI|Fireteam")
	TWeakObjectPtr<AActor> FireteamSharedThreat;

	UPROPERTY(BlueprintReadOnly, Category = "AI|Fireteam")
	int32 FireteamSlot = -1;

	UPROPERTY(BlueprintReadOnly, Category = "AI|Fireteam")
	bool bInEnemyFireteam = false;

	void IngestSharedThreat(AActor* Threat, const FVector& Loc, float Confidence);

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void OnPossess(APawn* InPawn) override;
	virtual void OnUnPossess() override;
	virtual void Tick(float DeltaTime) override;

	UFUNCTION()
	void OnPerceptionUpdated(AActor* Actor, FAIStimulus Stimulus);

	UFUNCTION()
	void HandleTacticalPingPlaced(FVector Location, ETacticalPingType Type);

	void SetupPerception();
	void UpdateMemory(float DeltaTime);
	void PollPerceptionForHostiles();
	void PollRegistryForHostiles();
	void UpsertPerceivedHostile(AActor* Actor, bool bCurrentlyVisible);
	void RunDirectCombatFallback(float DeltaTime);
	void RunDirectEnemyMovement(float DeltaTime);

	// ---- Direct Mission Pathing (StateTree-independent) ----
	void RunDirectMissionPathing(float DeltaTime);

	UPROPERTY(BlueprintReadOnly, Category = "AI|Mission")
	float LastDirectMissionPathTime = -1000.f;

	UPROPERTY(BlueprintReadOnly, Category = "AI|Mission")
	FVector LastDirectMissionGoal = FVector::ZeroVector;

private:

	// S19-HUNT state (see GetLeaderHuntTarget). mutable because GetEffectiveMoveGoal() is
	// const (it is BlueprintPure) and must be able to refresh this cache on the fly.
	// The target is weak: a dead enemy must not be kept alive by the cache, and must not
	// be read as still valid after it dies.
	mutable TWeakObjectPtr<AActor> LeaderHuntTarget;
	mutable float LeaderHuntScanTime = -1000.f;
	mutable int32 LeaderHuntRemaining = 0;
	UPROPERTY() TObjectPtr<UAISenseConfig_Sight>   SightConfig;
	UPROPERTY() TObjectPtr<UAISenseConfig_Hearing>  HearingConfig;
	UPROPERTY() TObjectPtr<UAISenseConfig_Damage>   DamageConfig;

	// S5-9: sandstorm visibility scaling (see RefreshSightForWeather). Director cached
	// as AActor so this header needs no Quest include (cast at use in the .cpp).
	float BaseSightRadius = 0.f;
	float BaseLoseSightRadius = 0.f;
	float WeatherPollTimer = 0.f;
	float LastAppliedWeatherMult = 1.f;
	TWeakObjectPtr<AActor> CachedStormDirector;

	void RefreshSightForWeather();

	// S4-11: SetupPerception now runs immediately at BeginPlay (the 1s timer stays as
	// fallback); this guard keeps the fallback from double-configuring the senses.
	bool bPerceptionInitialized = false;

	float MemoryDecayRate = 0.2f;
	float LastDirectCombatBurstTime = -1000.f;
	float LastCombatDiagnosticLogTime = -1000.f;
	bool bWasFiringLastTick = false;
	bool bHasInitiatedFiringThisEngagement = false;

	// S14-AI: grenade discipline for the direct-combat fallback. The frag
	// branch's "entrenched" condition is now actually measured (threat barely
	// moved between two samples), and every AI throw (frag or smoke) is gated
	// by a per-soldier minimum interval on top of the component's 3 s cooldown.
	TWeakObjectPtr<AActor> GrenadeThreatSample;
	FVector GrenadeThreatSampleLoc = FVector::ZeroVector;
	float GrenadeThreatSampleTime = -1000.f;
	bool bGrenadeThreatEntrenched = false;
	float LastAIGrenadeThrowTime = -1000.f;

	mutable bool bLastLeaderFireSprint = false;
	mutable float LastPathDebugLogTime = -1000.f;
	mutable FString LastPathDebugReason;
	mutable float FireHesitateUntil = -1000.f;
	mutable float FireSprintUntil = -1000.f;
	mutable bool bFireHesitateArmed = false;
	mutable FVector LastPathHeading = FVector::ForwardVector;
	mutable FVector LastFireLookAt = FVector::ZeroVector;
	mutable bool bLastInTrench = false;

	// S18-LEAD: monotonic spline progress. FindInputKeyClosestToWorldLocation
	// snaps to whatever spline point is nearest, so on bends / corridor drift
	// it can jump BACKWARDS — the lookahead goal then points behind the leader
	// and he walks back, re-acquires, walks forward: the back-and-forth dance.
	// We remember the furthest distance reached and never regress unless the
	// pawn genuinely left that part of the path.
	mutable TWeakObjectPtr<class ASplinePathActor> LeaderProgressGuide;
	mutable float LeaderSplineProgress = -1.f;

	// S19-STEERLATCH: the steering goal the leader is currently walking to. The spline /
	// fire-skip / closest-point math can hand back a goal that jumps a couple of metres
	// back and forth on the same segment; the leader then turns around every 2-3 s in the
	// same spot. A goal that moves BACKWARDS more than 1.5 m is held instead of followed,
	// for up to 2.5 s, unless the pawn reached it or was teleported (squad regroup/respawn).
	mutable FVector LeaderSteerGoal = FVector::ZeroVector;
	mutable FVector LeaderSteerPawnAt = FVector::ZeroVector;
	mutable float   LeaderSteerGoalTime = -1000.f;

	// S19-STORM: engage re-entry counter + threat suppression window.
	mutable float   EngageStormWindowStart = -1000.f;
	mutable int32   EngageStormEntries = 0;
	mutable float   ThreatSuppressUntil = -1000.f;
	mutable float LeaderProgressStamp = -1000.f;
	mutable FVector LeaderLastRawGoal = FVector::ZeroVector;
	float LeaderPathTaskHeartbeat = -1000.f; // S18-LEAD

	mutable TWeakObjectPtr<USquadAIAdapterComponent> CachedAdapter;
	mutable TWeakObjectPtr<AQuestChain> CachedActiveChain;
	// S5-7b: mission-pathing fallback zone — PER-CONTROLLER (was a function-static shared
	// across all controllers and all world contexts, which leaked goals cross-world in PIE).
	TWeakObjectPtr<AQuestZone> CachedFallbackQuestZone;
	mutable float CachedActiveChainTime = -1000.f;
	mutable bool bCachedIsLeader = false;
	mutable bool bLeaderRoleCached = false;
	float LastRegistryPollTime = -1000.f;
	float LastEnemyZoneScanTime = -1000.f;
	FVector CachedEnemyZoneCenter = FVector::ZeroVector;

	mutable TWeakObjectPtr<AActor> CachedLosTarget;
	mutable bool CachedLosResult = false;
	mutable float CachedLosTime = -1000.f;

	USquadAIAdapterComponent* GetCachedAdapter() const;
	bool IsLeaderController() const;
	void CacheRoleAndAdapter(APawn* InPawn);
	bool PathDebugDue(float MinInterval = 2.f) const;

	FVector ApplySplineAndFireToGoal(const FVector& RawGoal) const;
	FVector AvoidFireHazards(const FVector& From, const FVector& To, bool& bOutSprint, FString& OutReason) const;
};

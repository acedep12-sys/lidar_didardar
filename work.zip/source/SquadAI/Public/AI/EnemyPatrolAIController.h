// EnemyPatrolAIController.h - S19-PATROL
//
// The patroller needs one thing from the controller layer that no other enemy wants: while
// his patrol is calm, "where am I going" must answer with the patrol point he is walking to -
// not the mission zone, not the player. Everything in this codebase that asks a controller
// where it is going (the state-tree mission task included) asks GetEffectiveMoveGoal(), so
// overriding that one function is what makes the patrol authoritative while it walks its beat.
//
// Once he is ENGAGED (alerted with a hostile of his own to deal with) he hands movement back
// to the normal enemy behaviour and fights like any other soldier.
#pragma once

#include "CoreMinimal.h"
#include "AI/SoldierAIController.h"
#include "EnemyPatrolAIController.generated.h"

class AEnemyPatroller;

UCLASS(BlueprintType, Blueprintable)
class SQUADAI_API AEnemyPatrolAIController : public ASoldierAIController
{
	GENERATED_BODY()

public:
	AEnemyPatrolAIController(const FObjectInitializer& OI = FObjectInitializer::Get());

	/** S19-PATROL: the patrol point while calm, the base answer while alerted. */
	virtual FVector GetEffectiveMoveGoal() const override;

	/** Clamp a soldier controller's engagement envelopes to a patrol's own attention range.
	 *  Static and idempotent on purpose: the pawn applies it as soon as it has a controller, and
	 *  this controller re-applies it EVERY TICK - because ASoldierAIController::BeginPlay assigns
	 *  DirectCombatRange / DirectCombatFallbackFireRange / DirectCombatCloseRangeOverride from the
	 *  GLOBAL tuning, and for a level-placed pawn the controller's BeginPlay is dispatched after
	 *  the pawn's (the controller is spawned during the pawn's PostInitializeComponents, before
	 *  the world has begun play, so its BeginPlay is deferred). One shot at the pawn's BeginPlay
	 *  was therefore silently reverted and a placed patroller kept a normal enemy's 90 m reach.
	 *  Static so it also works if a project swaps AIControllerClass for its own controller. */
	static void ApplyPatrolEnvelope(ASoldierAIController* Controller, float SpotRange, float SpotHearRange);

protected:
	/** Re-applies the envelope clamp every tick (see ApplyPatrolEnvelope). Tick is protected on
	 *  the base controller, so it is protected here too. */
	virtual void Tick(float DeltaSeconds) override;
};

// EnemyFireteamSubsystem.h — Auto fireteam for wave-spawned enemies
// One squad per spawner. Shares contact, assigns Lead / Suppress / Flank / Assault.
#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "Tickable.h"
#include "Engine/EngineTypes.h"
#include "SquadTypes.h"
#include "EnemyFireteamSubsystem.generated.h"

class APawn;
class ASoldierAIController;
class AActor;

USTRUCT()
struct FEnemyFireteamMember
{
	GENERATED_BODY()

	UPROPERTY() TWeakObjectPtr<APawn> Pawn;
	EEnemyFireteamRole Role = EEnemyFireteamRole::Unassigned;
	int32 Slot = 0;
};

USTRUCT()
struct FEnemyFireteam
{
	GENERATED_BODY()

	uint32 TeamKey = 0;
	UPROPERTY() TArray<FEnemyFireteamMember> Members;
	UPROPERTY() TWeakObjectPtr<APawn> Leader;
	UPROPERTY() TWeakObjectPtr<AActor> SharedThreat;
	FVector SharedThreatLoc = FVector::ZeroVector;
	float LastLogTime = -1000.f;
};

UCLASS()
class SQUADAI_API UEnemyFireteamSubsystem : public UTickableWorldSubsystem
{
	GENERATED_BODY()

public:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;
	virtual void Tick(float DeltaTime) override;
	virtual bool IsTickable() const override;
	virtual TStatId GetStatId() const override
	{
		RETURN_QUICK_DECLARE_CYCLE_STAT(UEnemyFireteamSubsystem, STATGROUP_Tickables);
	}

	// TeamKey is typically the spawner's UniqueID — one fireteam per wave spawner.
	void RegisterMember(APawn* Pawn, uint32 TeamKey);
	void UnregisterMember(APawn* Pawn);

	bool IsInFireteam(const APawn* Pawn) const;

private:
	UPROPERTY() TArray<FEnemyFireteam> Teams;
	float TimeSinceAssign = 0.f;
	float AssignInterval = 0.5f;
	FTimerHandle AssignTimer;

	void EnsureAssignTimer();
	void StopAssignTimer();
	void RunAssign();
	int32 FindTeamIndex(uint32 TeamKey) const;
	int32 FindTeamIndexForPawn(const APawn* Pawn) const;
	void CompactTeam(FEnemyFireteam& Team);
	void AssignTeam(FEnemyFireteam& Team);
	static bool IsMemberAlive(APawn* Pawn);
	static ASoldierAIController* GetAI(APawn* Pawn);
};

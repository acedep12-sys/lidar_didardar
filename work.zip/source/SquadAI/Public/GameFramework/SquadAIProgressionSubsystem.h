#pragma once

#include "CoreMinimal.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "GameFramework/SquadAIMapData.h"
#include "GameFramework/SquadAIWeaponData.h"
#include "SquadAIProgressionSubsystem.generated.h"

UENUM(BlueprintType)
enum class EPlayerAttributeType : uint8
{
	MovementSpeed      UMETA(DisplayName = "سرعت تحرک و دویدن (Movement Speed)"),
	MaxHealth          UMETA(DisplayName = "ظرفیت سلامت و پایداری (Max Health)"),
	Stamina            UMETA(DisplayName = "استقامت و نفس نبرد (Stamina)"),
	RecoilControl      UMETA(DisplayName = "کنترل لگد و ثبات سلاح (Recoil Control)"),
	ReloadSpeed        UMETA(DisplayName = "سرعت تعویض خشاب تاکتیکی (Reload Speed)"),
	FieldReviveSpeed   UMETA(DisplayName = "سرعت احیا و پانسمان همرزمان (Field Revive Speed)"),
	OrdnanceCapacity   UMETA(DisplayName = "ظرفیت حمل نارنجک و مهمات (Ordnance Capacity)")
};

USTRUCT(BlueprintType)
struct SQUADAI_API FSquadPlayerProfile
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Player Profile")
	FString ProfileID = TEXT("Profile_1");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Player Profile")
	FString PlayerName = TEXT("رزمنده دلیر");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Player Profile")
	FName SelectedAvatarID = FName("Avatar_Rostami");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Player Profile")
	FString BloodType = TEXT("O+ (مثبت)");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Player Profile")
	FString DogTagNumber = TEXT("۹۵۸ / ۱۳۵۹ - خ");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Player Profile|Stats")
	int32 EnemiesHunted = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Player Profile|Stats")
	int32 EnemiesEliminated = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Player Profile|Stats")
	int32 TanksDemolished = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Player Profile|Stats")
	float TotalPlaytimeSeconds = 0.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Player Profile|Stats")
	int32 MissionsCompleted = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Player Profile|Stats")
	int32 TriageRevives = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Player Profile|Stats")
	int32 AlliesRevived = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Player Profile|Stats")
	float OverallAccuracyPercentage = 78.5f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Player Profile|Stats")
	int32 HeadshotCount = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Player Profile|Stats")
	FString FormattedPlaytime = TEXT("۰ دقیقه");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Player Profile|Progression")
	int32 PlayerLevel = 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Player Profile|Progression")
	int32 CurrentLevel = 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Player Profile|Progression")
	int32 TotalXP = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Player Profile|Progression")
	int32 CurrentLevelXP = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Player Profile|Progression")
	int32 AvailableSkillPoints = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Player Profile|Progression")
	TMap<uint8, int32> AttributeRanks;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Player Profile|Progression")
	TArray<FName> UnlockedWeaponIDs;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Player Profile|Progression")
	FName EquippedWeaponID = FName("G3A3");
};

/**
 * FSquadProgressionNode
 * Tactical doctrine, leadership trait, or squad attribute branch.
 */
USTRUCT(BlueprintType)
struct SQUADAI_API FSquadProgressionNode
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Progression")
	FName NodeID = FName("LeadershipTactics");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Progression")
	FText DisplayNameFarsi = FText::FromString(TEXT("فرماندهی و رهبری میدان"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Progression")
	FText DisplayNameEnglish = FText::FromString(TEXT("Field Leadership"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Progression", meta = (MultiLine = true))
	FText DescriptionFarsi = FText::FromString(TEXT("افزایش استقامت و سرعت عکس‌العمل تمام افراد جوخه در زیر آتش سنگین دشمن."));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Progression", meta = (MultiLine = true))
	FText DescriptionEnglish = FText::FromString(TEXT("Boosts squad stamina and tactical reaction speed under fire."));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Progression")
	int32 Cost = 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Progression")
	bool bUnlocked = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Progression")
	TObjectPtr<UTexture2D> IconTexture;
};

USTRUCT(BlueprintType)
struct SQUADAI_API FSquadAchievement
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Achievement")
	FName AchievementID = FName("FirstBlood");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Achievement")
	FText TitleFarsi = FText::FromString(TEXT("اولین پیروزی خط‌شکن"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Achievement")
	FText TitleEnglish = FText::FromString(TEXT("First Blood"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Achievement")
	FText DisplayNameFarsi = FText::FromString(TEXT("اولین پیروزی خط‌شکن"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Achievement")
	FText DisplayNameEnglish = FText::FromString(TEXT("First Blood"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Achievement")
	FText DescriptionFarsi = FText::FromString(TEXT("اولین موج دشمن متخاصم را در سنگرهای دهلاویه خنثی کنید."));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Achievement")
	FText DescriptionEnglish = FText::FromString(TEXT("Neutralize the first enemy combat wave in Dehlavieh trenches."));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Achievement")
	int32 XPReward = 350;

	UPROPERTY(BlueprintReadOnly, Category = "Achievement")
	float CurrentProgress = 0.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Achievement")
	float TargetProgress = 1.0f;

	UPROPERTY(BlueprintReadOnly, Category = "Achievement")
	bool bIsUnlocked = false;

	UPROPERTY(BlueprintReadOnly, Category = "Achievement")
	bool bUnlocked = false;

	UPROPERTY(BlueprintReadOnly, Category = "Achievement")
	FDateTime UnlockTimestamp;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Achievement")
	TObjectPtr<UTexture2D> IconTexture;
};

using FSquadAchievementDefinition = FSquadAchievement;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FOnXPGained, int32, AddedXP, int32, NewTotalXP, const FString&, Reason);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnPlayerLevelUp, int32, NewLevel, int32, AvailableSkillPoints);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnAttributeUpgraded, EPlayerAttributeType, Attribute, int32, NewRank);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnWeaponUnlocked, FName, WeaponID);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnAchievementUnlocked, const FSquadAchievement&, Achievement);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnProfileChanged, const FSquadPlayerProfile&, ActiveProfile);

/**
 * USquadAIProgressionSubsystem
 * Global Progression, Player Profiles, Combat Stats, Leveling, Skill Upgrades, Armory Unlocks & Medals.
 */
UCLASS(BlueprintType)
class SQUADAI_API USquadAIProgressionSubsystem : public UGameInstanceSubsystem
{
	GENERATED_BODY()

public:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression", meta = (WorldContext = "WorldContextObject"))
	static USquadAIProgressionSubsystem* Get(const UObject* WorldContextObject);

	// =========================================================================
	//  PLAYER PROFILE MANAGEMENT
	// =========================================================================

	UFUNCTION(BlueprintCallable, Category = "Progression|Profile")
	void CreateNewProfile(const FString& ProfileName, FName AvatarID);

	UFUNCTION(BlueprintCallable, Category = "Progression|Profile")
	bool SwitchProfile(int32 ProfileIndex);

	UFUNCTION(BlueprintCallable, Category = "Progression|Profile")
	void DeleteProfile(int32 ProfileIndex);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|Profile")
	const FSquadPlayerProfile& GetActiveProfile() const { return ActiveProfile; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|Profile")
	const TArray<FSquadPlayerProfile>& GetAllProfiles() const { return SavedProfiles; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|Profile")
	int32 GetActiveProfileIndex() const { return ActiveProfileIndex; }

	UFUNCTION(BlueprintCallable, Category = "Progression|Profile")
	void SetActiveAvatar(FName AvatarID);

	UFUNCTION(BlueprintCallable, Category = "Progression|Profile")
	void SetActivePlayerName(const FString& NewName);

	UFUNCTION(BlueprintCallable, Category = "Progression|Profile")
	FString CyclePresetCallsign();

	// =========================================================================
	//  COMBAT STATS TRACKING
	// =========================================================================

	UFUNCTION(BlueprintCallable, Category = "Progression|Stats")
	void RecordEnemyEliminated();

	UFUNCTION(BlueprintCallable, Category = "Progression|Stats")
	void RegisterHeadshot();

	UFUNCTION(BlueprintCallable, Category = "Progression|Stats")
	void RecordTankDemolished();

	UFUNCTION(BlueprintCallable, Category = "Progression|Stats")
	void RecordTriageRevive();

	UFUNCTION(BlueprintCallable, Category = "Progression|Stats")
	void AddPlaytime(float DeltaSeconds);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|Stats")
	int32 GetEnemiesHunted() const { return ActiveProfile.EnemiesHunted; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|Stats")
	int32 GetTanksDemolished() const { return ActiveProfile.TanksDemolished; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|Stats")
	FString GetFormattedPlaytime() const;

	// =========================================================================
	//  LEVEL & XP API
	// =========================================================================

	UFUNCTION(BlueprintCallable, Category = "Progression|XP")
	void AwardXP(int32 Amount, const FString& Reason = TEXT("Quest Complete"));

	UFUNCTION(BlueprintCallable, Category = "Progression|XP")
	void AwardQuestCompletionXP(FName QuestID, int32 Amount = 800);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|XP")
	int32 GetPlayerLevel() const { return ActiveProfile.PlayerLevel; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|XP")
	int32 GetTotalXP() const { return ActiveProfile.TotalXP; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|XP")
	int32 GetCurrentLevelXP() const { return ActiveProfile.CurrentLevelXP; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|XP")
	int32 GetXPRequiredForNextLevel() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|XP")
	float GetLevelProgressFraction() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|Skills")
	int32 GetAvailableSkillPoints() const { return ActiveProfile.AvailableSkillPoints; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|Skills")
	int32 GetAvailableUpgradePoints() const { return ActiveProfile.AvailableSkillPoints; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|Skills")
	TArray<FSquadProgressionNode> GetProgressionNodes() const;

	UFUNCTION(BlueprintCallable, Category = "Progression|Skills")
	bool UnlockProgressionNode(FName NodeID);

	// =========================================================================
	//  ATTRIBUTE UPGRADES
	// =========================================================================

	UFUNCTION(BlueprintCallable, Category = "Progression|Attributes")
	bool UpgradeAttribute(EPlayerAttributeType Attribute);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|Attributes")
	int32 GetAttributeRank(EPlayerAttributeType Attribute) const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|Attributes")
	float GetSpeedMultiplier() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|Attributes")
	float GetMaxHealthBonus() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|Attributes")
	float GetStaminaMultiplier() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|Attributes")
	float GetRecoilMultiplier() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|Attributes")
	float GetReloadSpeedMultiplier() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|Attributes")
	float GetReviveSpeedMultiplier() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|Attributes")
	int32 GetExtraOrdnanceCapacity() const;

	// =========================================================================
	//  WEAPON ARMORY & UNLOCKS
	// =========================================================================

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|Armory")
	TArray<FSquadWeaponDefinition> GetArmoryCatalog() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|Armory")
	TArray<FSquadWeaponDefinition> GetAvailableWeapons() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|Armory")
	bool IsWeaponUnlocked(FName WeaponID) const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|Armory")
	bool CanUnlockWeapon(FName WeaponID, FText& OutFailReason) const;

	UFUNCTION(BlueprintCallable, Category = "Progression|Armory")
	bool UnlockWeapon(FName WeaponID);

	UFUNCTION(BlueprintCallable, Category = "Progression|Armory")
	bool EquipWeapon(FName WeaponID);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|Armory")
	FName GetEquippedWeaponID() const { return ActiveProfile.EquippedWeaponID; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|Armory")
	bool FindWeaponDefinition(FName WeaponID, FSquadWeaponDefinition& OutWeapon) const;

	// =========================================================================
	//  ACHIEVEMENTS
	// =========================================================================

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|Achievements")
	const TArray<FSquadAchievement>& GetAchievementsCatalog() const { return AchievementsCatalog; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|Achievements")
	const TArray<FSquadAchievement>& GetAchievements() const { return AchievementsCatalog; }

	UFUNCTION(BlueprintCallable, Category = "Progression|Achievements")
	void UpdateAchievementProgress(FName AchievementID, float ProgressDelta);

	UFUNCTION(BlueprintCallable, Category = "Progression|Achievements")
	void UnlockAchievement(FName AchievementID);

	// =========================================================================
	//  MAP SELECTION CATALOG
	// =========================================================================

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Progression|Maps")
	const TArray<FSquadMapDefinition>& GetAvailableMaps() const { return AvailableMaps; }

	// =========================================================================
	//  EVENTS
	// =========================================================================

	UPROPERTY(BlueprintAssignable, Category = "Progression|Events")
	FOnXPGained OnXPGained;

	UPROPERTY(BlueprintAssignable, Category = "Progression|Events")
	FOnPlayerLevelUp OnPlayerLevelUp;

	UPROPERTY(BlueprintAssignable, Category = "Progression|Events")
	FOnAttributeUpgraded OnAttributeUpgraded;

	UPROPERTY(BlueprintAssignable, Category = "Progression|Events")
	FOnWeaponUnlocked OnWeaponUnlocked;

	UPROPERTY(BlueprintAssignable, Category = "Progression|Events")
	FOnAchievementUnlocked OnAchievementUnlocked;

	UPROPERTY(BlueprintAssignable, Category = "Progression|Events")
	FOnProfileChanged OnProfileChanged;

	// =========================================================================
	//  SAVE / LOAD PERSISTENCE
	// =========================================================================

	UFUNCTION(BlueprintCallable, Category = "Progression|SaveLoad")
	void SaveProgressionToDisk();

	UFUNCTION(BlueprintCallable, Category = "Progression|SaveLoad")
	void LoadProgressionFromDisk();

private:
	FSquadPlayerProfile ActiveProfile;
	TArray<FSquadPlayerProfile> SavedProfiles;
	int32 ActiveProfileIndex = 0;

	UPROPERTY()
	TArray<FSquadWeaponDefinition> ArmoryCatalog;

	UPROPERTY()
	TArray<FSquadAchievement> AchievementsCatalog;

	UPROPERTY()
	TArray<FSquadMapDefinition> AvailableMaps;

	void InitializeCatalogs();
	void InitializeDefaultProfile();
	int32 CalculateXPRequirement(int32 Level) const;
	void CheckLevelUp();
};

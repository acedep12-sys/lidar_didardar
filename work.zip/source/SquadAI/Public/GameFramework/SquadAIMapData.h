#pragma once

#include "CoreMinimal.h"
#include "Engine/Texture2D.h"
#include "SquadAIMapData.generated.h"

/**
 * FSquadMapDefinition
 * Data-driven tactical theater and map configuration.
 * Fully editable in Details panel or Blueprint data assets.
 */
USTRUCT(BlueprintType)
struct SQUADAI_API FSquadMapDefinition
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Map Configuration")
	FName MapID = FName("Dehlavieh_Karkheh");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Map Configuration")
	FName LevelPackageName = FName("L_Khuzestan");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Map Configuration")
	FText DisplayNameFarsi = FText::FromString(TEXT("محور دهلاویه و رودخانه کرخه"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Map Configuration")
	FText DisplayNameEnglish = FText::FromString(TEXT("Dehlavieh & Karkheh River Frontline"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Map Configuration")
	FText Subtitle = FText::FromString(TEXT("خط مقدم نبرد خوزستان — دفاع در برابر ادوات زرهی دشمن"));

	/** Rich tactical situation description displayed on hover in the map selection sidebar */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Map Configuration", meta = (MultiLine = true))
	FText SituationBriefingFarsi = FText::FromString(TEXT(
		"موقعیت تاکتیکی: نبرد سنگین در حاشیه رودخانه کرخه و دشت‌های تفتیده دهلاویه.\n"
		"نیروهای متخاصم با ستون‌های زرهی و تانک‌های پیشرفته در حال پیشروی به سمت روستای خشتی عقبه هستند.\n"
		"ماموریت جوخه به فرماندهی سرگرد شهید ایرج رستمی: استقرار در سنگرهای شنی، هدایت آتشبار خمپاره، شکار تانک‌ها با آرپی‌جی-۷ و تثبیت خط پدافندی."
	));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Map Configuration", meta = (MultiLine = true))
	FText SituationBriefingEnglish = FText::FromString(TEXT(
		"Tactical Situation: Heavy frontline engagement along the Karkheh riverbanks and Dehlavieh desert.\n"
		"Hostile armored columns are attempting to breach toward the rear mudbrick village compound.\n"
		"Mission: Under Major Shahid Rostami's command, hold the sandbag trenches, direct 81mm mortar fire, hunt hostile armor with RPG-7s, and fortify the defensive perimeter."
	));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Map Configuration")
	TObjectPtr<UTexture2D> PreviewTexture;

	/** If true, player can deploy to this map; if false, shown as 'Undergoing Preparation' */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Map Configuration")
	bool bIsSelectable = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Map Configuration")
	FText LockReasonFarsi = FText::FromString(TEXT("در دست آماده‌سازی و بازسازی عملیاتی (Undergoing)"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Map Configuration")
	int32 RequiredPlayerLevel = 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Map Configuration")
	int32 CompletionXPReward = 1200;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Map Configuration")
	FString EstimatedPlaytime = TEXT("۲۰ الی ۳۰ دقیقه");
};

// SquadAIInventorySubsystem.h — Tactical Military Backpack & Inventory Manager
#pragma once

#include "CoreMinimal.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "SquadAIInventorySubsystem.generated.h"

class APawn;
class UTexture2D;
class USoundBase;

USTRUCT(BlueprintType)
struct FSquadInventoryWeaponItem
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Inventory")
	FName WeaponID = NAME_None;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Inventory")
	FString DisplayName = TEXT("سلاح");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Inventory")
	FString Description = TEXT("");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Inventory")
	FString Caliber = TEXT("7.62mm");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Inventory")
	int32 ClipAmmo = 30;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Inventory")
	int32 MaxClipAmmo = 30;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Inventory")
	int32 ReserveAmmo = 120;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Inventory")
	float DamageRating = 0.85f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Inventory")
	float AccuracyRating = 0.80f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Inventory")
	float FireRateRating = 0.70f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Inventory")
	float RangeRating = 0.75f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Inventory")
	bool bIsUnlocked = true;
};

USTRUCT(BlueprintType)
struct FSquadFallenTroopNote
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Notes")
	FString Title = TEXT("دست‌نوشته همرزم شهید");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Notes")
	FString Content = TEXT("");

	// G-13: data-driven art slots — stable ID + designer-wired scan + loose-file stem
	// (drop user PNGs in Textures/Notes/<ImageFile>.png; falls back to the placeholder).
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Notes")
	FName NoteID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Notes")
	TObjectPtr<UTexture2D> NoteImage;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Notes")
	FString ImageFile;
};

USTRUCT(BlueprintType)
struct FSquadRadioStation
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Radio")
	float Frequency = 88.5f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Radio")
	FString StationName = TEXT("نوای حماسی دفاع مقدس");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Radio")
	TObjectPtr<USoundBase> BroadcastAudioTrack;
};

/**
 * USquadAIInventorySubsystem
 * Manages player's tactical military backpack, weapons, ammo,
 * fallen soldiers' handwritten notes, pocket radio frequencies,
 * holy Quran verses, and identification wallet.
 */
UCLASS(BlueprintType)
class SQUADAI_API USquadAIInventorySubsystem : public UGameInstanceSubsystem
{
	GENERATED_BODY()

public:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Inventory", meta = (WorldContext = "WorldContextObject"))
	static USquadAIInventorySubsystem* Get(const UObject* WorldContextObject);

	// ===== WEAPON ARSENAL =====
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Inventory")
	void NextWeapon();

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Inventory")
	void PreviousWeapon();

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Inventory")
	void SelectWeaponByIndex(int32 Index);

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Inventory")
	void SelectWeaponByID(FName WeaponID);

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Inventory")
	bool EquipSelectedWeapon(APawn* PlayerPawn);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Inventory")
	FSquadInventoryWeaponItem GetSelectedWeapon() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Inventory")
	int32 GetSelectedWeaponIndex() const { return SelectedWeaponIndex; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Inventory")
	int32 GetTotalWeaponCount() const { return Weapons.Num(); }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Inventory")
	TArray<FSquadInventoryWeaponItem> GetAllWeapons() const { return Weapons; }

	// ===== FALLEN SOLDIERS' NOTES =====
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Inventory")
	void NextFallenNote();

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Inventory")
	void PreviousFallenNote();

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Inventory")
	FSquadFallenTroopNote GetCurrentFallenNote() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Inventory")
	FSquadFallenTroopNote GetFallenNoteByIndex(int32 Index) const;

	// G-13: wired NoteImage → Textures/Notes/<ImageFile|NoteID>.png (cached) → null.
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Inventory")
	UTexture2D* GetNoteImage(const FSquadFallenTroopNote& Note);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Inventory")
	int32 GetCurrentNoteIndex() const { return CurrentNoteIndex; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Inventory")
	int32 GetTotalNotesCount() const { return FallenNotes.Num(); }

	// ===== POCKET FRONTLINE RADIO =====
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Inventory")
	void NextRadioStation();

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Inventory")
	void PreviousRadioStation();

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Inventory")
	void ToggleRadioPower();

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Inventory")
	FSquadRadioStation GetCurrentRadioStation() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Inventory")
	bool IsRadioPlaying() const { return bRadioIsPlaying; }

	// ===== POCKET QURAN & DUAS =====
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Inventory")
	void NextQuranVerse();

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Inventory")
	void GetCurrentQuranVerse(FString& OutArabic, FString& OutTranslation) const;

	// ===== SUPPLIES =====
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Inventory|Supplies")
	int32 FirstAidKits = 3;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Inventory|Supplies")
	int32 FragGrenades = 2;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Inventory|Supplies")
	int32 SmokeGrenades = 2;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Inventory|Supplies")
	float CanteenWaterPercent = 0.85f;

	/** Called when inventory is opened to refresh data from localization and game state */
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Inventory")
	void OnInventoryOpened();

private:
	UPROPERTY()
	TArray<FSquadInventoryWeaponItem> Weapons;

	UPROPERTY()
	TArray<FSquadFallenTroopNote> FallenNotes;

	UPROPERTY()
	TArray<FSquadRadioStation> RadioStations;

	struct FQuranEntry
	{
		FString Arabic;
		FString Translation;
	};
	TArray<FQuranEntry> QuranVerses;

	int32 SelectedWeaponIndex = 0;
	int32 CurrentNoteIndex = 0;
	TMap<FString, TWeakObjectPtr<UTexture2D>> NoteImageCache; // G-13: loose-file cache
	int32 CurrentStationIndex = 0;
	int32 CurrentQuranIndex = 0;
	bool bRadioIsPlaying = true;

	void PopulateDefaultArsenal();
	void ReloadNotesFromLocalization();
	void ReloadRadioStations();
	void ReloadQuranVerses();
};

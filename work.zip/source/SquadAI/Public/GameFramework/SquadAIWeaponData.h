#pragma once

#include "CoreMinimal.h"
#include "Engine/Texture2D.h"
#include "SquadAIWeaponData.generated.h"

UENUM(BlueprintType)
enum class ESquadWeaponCategory : uint8
{
	BattleRifle      UMETA(DisplayName = "تفنگ جنگی (Battle Rifle)"),
	AssaultRifle     UMETA(DisplayName = "تفنگ هجومی (Assault Rifle)"),
	AntiTankRocket   UMETA(DisplayName = "شکارچی تانک و راکت‌انداز (Anti-Tank Launcher)"),
	MachineGun       UMETA(DisplayName = "تیربار سنگین و متوسط (Machine Gun)"),
	SniperRifle      UMETA(DisplayName = "تفنگ تک‌تیرانداز دقیق (Sniper Rifle)")
};

/**
 * FSquadWeaponSpecialityTrait
 * Weapon unique combat perk and tactical trait.
 * Displayed as interactive speciality badge in the Armory.
 */
USTRUCT(BlueprintType)
struct SQUADAI_API FSquadWeaponSpecialityTrait
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Speciality")
	FName TraitID = FName("DefaultTrait");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Speciality")
	FText TitleFarsi = FText::FromString(TEXT("مهارت ویژه"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Speciality")
	FText TitleEnglish = FText::FromString(TEXT("Speciality"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Speciality")
	FText DisplayNameFarsi = FText::FromString(TEXT("مهارت ویژه"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Speciality")
	FText DisplayNameEnglish = FText::FromString(TEXT("Speciality"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Speciality", meta = (MultiLine = true))
	FText DescriptionFarsi = FText::FromString(TEXT("توضیحات تاکتیکی مهارت ویژه سلاح."));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Speciality", meta = (MultiLine = true))
	FText DescriptionEnglish = FText::FromString(TEXT("Tactical description of weapon capability."));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Speciality")
	FString BadgeTag = TEXT("★ ویژگی برتر");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Speciality")
	TObjectPtr<UTexture2D> IconTexture;
};

/**
 * FSquadWeaponDefinition
 * Tactical armory configuration and unlock metadata.
 * Fully editable in Details panel or Blueprints.
 */
USTRUCT(BlueprintType)
struct SQUADAI_API FSquadWeaponDefinition
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon Armory")
	FName WeaponID = FName("G3A3");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon Armory")
	FText DisplayNameFarsi = FText::FromString(TEXT("تفنگ جنگی ژ-۳ (G3A3)"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon Armory")
	FText DisplayNameEnglish = FText::FromString(TEXT("H&K G3A3 Battle Rifle"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon Armory")
	FText Caliber = FText::FromString(TEXT("۷.۶۲×۵۱ میلی‌متر ناتو"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon Armory")
	FText HistoricalRoleFarsi = FText::FromString(TEXT("سلاح سازمانی و استاندارد ارتش"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon Armory")
	FText HistoricalRoleEnglish = FText::FromString(TEXT("Standard Service Rifle"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon Armory")
	ESquadWeaponCategory Category = ESquadWeaponCategory::BattleRifle;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon Armory", meta = (MultiLine = true))
	FText DescriptionFarsi = FText::FromString(TEXT("سلاح سازمانی و استاندارد ارتش، کالیبر قدرتمند ۷.۶۲ میلی‌متری با برد و دقت آتش بسیار بالا در دشت‌های باز."));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon Armory", meta = (MultiLine = true))
	FText DescriptionEnglish = FText::FromString(TEXT("Standard-issue 7.62x51mm battle rifle. High kinetic stopping power and extreme effective range in open desert terrain."));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon Armory")
	TObjectPtr<UTexture2D> PreviewTexture;

	/** Combat Performance Attribute Scores (0.0 to 1.0 / Normalized 100-Point Bars) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon Stats", meta = (ClampMin = "0.0", ClampMax = "1.0"))
	float DamageRating = 0.88f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon Stats", meta = (ClampMin = "0.0", ClampMax = "1.0"))
	float FireRateRating = 0.55f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon Stats", meta = (ClampMin = "0.0", ClampMax = "1.0"))
	float AccuracyRating = 0.86f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon Stats", meta = (ClampMin = "0.0", ClampMax = "1.0"))
	float RangeRating = 0.90f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon Stats", meta = (ClampMin = "0.0", ClampMax = "1.0"))
	float RecoilControlRating = 0.65f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon Stats", meta = (ClampMin = "0.0", ClampMax = "1.0"))
	float MobilityRating = 0.70f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon Stats", meta = (ClampMin = "0.0", ClampMax = "1.0"))
	float ArmorPenetrationRating = 0.75f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon Stats", meta = (ClampMin = "0.0", ClampMax = "1.0"))
	float EffectiveRangeRating = 0.90f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon Stats", meta = (ClampMin = "0.0", ClampMax = "1.0"))
	float HandlingRating = 0.70f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon Stats")
	int32 MagazineCapacity = 20;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon Stats")
	int32 MaxReserveAmmo = 140;

	/** Speciality Traits Line (multiple interactive trait tags) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon Speciality")
	TArray<FSquadWeaponSpecialityTrait> SpecialityTraits;

	/** Unlock Requirements */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon Unlock")
	int32 RequiredPlayerLevel = 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon Unlock")
	int32 XPCostToUnlock = 0; // 0 = Unlocked by default

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon Unlock")
	bool bDefaultUnlocked = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon Unlock")
	bool bIsUnlocked = true;
};

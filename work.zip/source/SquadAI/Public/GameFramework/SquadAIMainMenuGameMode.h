#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "SquadAIMainMenuGameMode.generated.h"

/**
 * ASquadAIMainMenuGameMode
 * Dedicated GameMode for the Main Menu Level.
 * Sets up menu HUD, cursor visibility, audio ambience, and UI input mode.
 */
UCLASS(BlueprintType, Blueprintable)
class SQUADAI_API ASquadAIMainMenuGameMode : public AGameModeBase
{
	GENERATED_BODY()

public:
	ASquadAIMainMenuGameMode();

	virtual void BeginPlay() override;
};

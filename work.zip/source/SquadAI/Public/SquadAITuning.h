// SquadAITuning.h — Every gameplay number in ONE place
// Accessible via: Project Settings → Plugins → Squad AI Tuning
// Or via: GetDefault<USquadAITuning>() (zero-cost CDO read)
// Or via: USquadAITuning::Get()
#pragma once

#include "CoreMinimal.h"
#include "Engine/DeveloperSettings.h"
#include "SquadTypes.h"
#include "SquadAITuning.generated.h"

class UTexture2D;
class UMaterialInterface;
class UFont;
class USoundBase;

UCLASS(Config = Game, DefaultConfig, meta = (DisplayName = "Squad AI Tuning"))
class SQUADAI_API USquadAITuning : public UDeveloperSettings
{
	GENERATED_BODY()

public:
	USquadAITuning();

	static const USquadAITuning* Get()
	{
		return GetDefault<USquadAITuning>();
	}

	virtual FName GetCategoryName() const override { return FName("Plugins"); }

	// =====================================================================
	//  AUDIO & DYNAMIC MUSIC (Global defaults for open world)
	// =====================================================================

	/** Default exploration / peaceful desert background music */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Audio|Music")
	TObjectPtr<USoundBase> DefaultAmbientMusic;

	/** Default high-intensity combat / firefight music */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Audio|Music")
	TObjectPtr<USoundBase> DefaultCombatMusic;

	/** Default defend mission climax music (final moments) */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Audio|Music")
	TObjectPtr<USoundBase> DefaultDefendClimaxMusic;

	/** Mission victory completion stinger / fanfare */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Audio|Music")
	TObjectPtr<USoundBase> VictoryStingerSound;

	/** Mission defeat / failure stinger */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Audio|Music")
	TObjectPtr<USoundBase> DefeatStingerSound;

	/** Music crossfade transition time (seconds) */
	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Audio|Music", meta = (ClampMin = "0.5", ClampMax = "10.0"))
	float GlobalMusicCrossfadeDuration = 2.5f;

	/** Global fallback for close explosion sound */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Audio|SFX")
	TObjectPtr<USoundBase> DefaultExplosionCloseSound;

	/** Global fallback for distant booming explosion echo */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Audio|SFX")
	TObjectPtr<USoundBase> DefaultExplosionDistantSound;

	/** Enable realistic speed-of-sound physical delay (343 m/s) across the 8 km map */
	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Audio|SFX")
	bool bSimulateSpeedOfSound = true;

	// =====================================================================
	//  COVER SCANNER
	// =====================================================================

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Cover Scanner")
	float ChunkSizeXY = 1000.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Cover Scanner")
	float ChunkSizeZ = 500.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Cover Scanner")
	int32 SamplesPerChunkAxis = 6;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Cover Scanner")
	float ChunkRevalidationSeconds = 30.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Cover Scanner")
	int32 MaxChunkScansPerFrame = 1; // S4-8: was 2 (2880-trace first-contact spike); full-chunk scans now serialize

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Cover Scanner")
	int32 MaxQueriesPerFrame = 16;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Cover Scanner")
	int32 AsyncTraceBudgetPerFrame = 96;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Cover Scanner")
	float CrouchHeight = 95.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Cover Scanner")
	float StandHeight = 180.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Cover Scanner")
	float MinCoverThickness = 25.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Cover Scanner")
	float NavmeshProjectExtent = 150.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Cover Scanner")
	float TacticalCoverSearchRadius = 3500.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Cover Scanner")
	float CoverQueryPartialResolveSeconds = 0.6f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Cover Scanner")
	float CoverQueryTimeoutSeconds = 3.0f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Cover Scanner")
	float CoverGroundTraceHalfHeight = 2500.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Cover Scanner")
	bool bCoverUseLargeHeightFallbackTrace = true;

	// =====================================================================
	//  COMBAT — Weapon
	// =====================================================================

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Combat|Weapon")
	float DefaultDamage = 8.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Combat|Weapon")
	float DefaultFireRate = 12.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Combat|Weapon")
	float DefaultBaseSpread = 1.5f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Combat|Weapon")
	float DefaultSpreadPerShot = 0.3f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Combat|Weapon")
	float DefaultSpreadDecay = 5.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Combat|Weapon")
	float DefaultMaxRange = 10000.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Combat|Weapon")
	float DefaultFalloffStart = 2500.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Combat|Weapon")
	float DefaultMinDamageMultiplier = 0.35f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Combat|Weapon")
	float SuppressionRadius = 250.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Combat|Weapon")
	float SuppressionAmountPerBullet = 0.35f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Combat|Weapon")
	float DamageMultiplier = 1.f;

	// =====================================================================
	//  COMBAT — Health
	// =====================================================================

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Combat|Health")
	float DefaultMaxHealth = 100.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Combat|Health")
	float InvincibleMinHealth = 1.f;

	// =====================================================================
	//  COMBAT — Aim
	// =====================================================================

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Combat|Aim")
	float AimBodyYawRate = 360.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Combat|Aim")
	float AimSpringStiffness = 14.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Combat|Aim")
	float AimSpringDampingRatio = 1.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Combat|Aim")
	float AimSpineConeDegrees = 75.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Combat|Aim")
	float AimMaxErrorDegrees = 2.5f;

	// =====================================================================
	//  PERCEPTION
	// =====================================================================

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Perception")
	float SightRadius = 3500.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Perception")
	float LoseSightRadius = 4200.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Perception")
	float PeripheralVisionDegrees = 70.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Perception")
	float HearingRange = 2500.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Perception")
	float MemoryDecayPerSecond = 0.2f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Perception")
	float SuppressionDecayPerSecond = 0.4f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Combat|Detection")
	float CombatDetectionRange = 15000.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Combat|Detection")
	float CombatCloseRangeOverride = 1800.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Combat|Detection")
	float MaxEngageRange = 8000.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Combat|Detection")
	float DirectFallbackFireRange = 8000.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Combat|Detection")
	bool bAllowDirectFallbackFire = true;

	// =====================================================================
	//  FACTION — Allies
	// =====================================================================

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Faction|Allies")
	float AllyAccuracyMultiplier = 0.25f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Faction|Allies")
	float AllyDefaultPowerLevel = 0.25f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Faction|Allies")
	int32 AllyCount = 4;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Faction|Allies")
	bool bAlliesInvincible = false;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Faction|Allies")
	float AllyFormationSpacing = 200.f;

	// =====================================================================
	//  FACTION — Enemies
	// =====================================================================

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Faction|Enemies")
	float EnemyAccuracyMultiplier = 0.65f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Faction|Enemies")
	float EnemyDefaultAggression = 0.4f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Faction|Enemies")
	float EnemySuppressionThreshold = 0.6f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Faction|Enemies")
	int32 MaxVisibleEnemies = 50;

	// =====================================================================
	//  LEADER
	// =====================================================================

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Leader")
	float LeaderWaitForPlayerRadius = 1500.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Leader")
	float LeaderFullSpeedRadius = 800.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Leader")
	float LeaderNormalSpeed = 400.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Leader")
	float LeaderWaitingSpeed = 120.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Leader")
	bool bLeaderInvincible = false;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Leader")
	float LeaderChipDamageFraction = 0.0f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Leader")
	float LeaderMinChipHealth = 35.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Leader")
	float NavInvokerRadius = 5000.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Leader")
	float NavInvokerRemovalRadius = 10000.f;

	// =====================================================================
	//  LOD / PERFORMANCE
	// =====================================================================

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Performance")
	float SignificanceUpdateInterval = 0.25f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Performance")
	int32 MaxHighFidelityAgents = 16;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Performance")
	float SignificanceDormantDistance = 8000.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Performance")
	float RegistryCellSize = 4000.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Performance")
	float RegistryRebucketInterval = 0.2f;

	// =====================================================================
	//  DIFFICULTY
	// =====================================================================

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Difficulty")
	float AllyPower_Easy = 0.45f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Difficulty")
	float AllyPower_Normal = 0.25f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Difficulty")
	float AllyPower_Hard = 0.15f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Difficulty")
	float AllyPower_Lethal = 0.05f;

	// S14-STAB: 0.70 was brutal once all three waves actually converge (pool
	// fixes made every spawned enemy real). Easy should be forgiving.
	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Difficulty")
	float EnemyDamage_Easy = 0.45f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Difficulty")
	float EnemyDamage_Normal = 1.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Difficulty")
	float EnemyDamage_Hard = 1.30f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Difficulty")
	float EnemyDamage_Lethal = 1.60f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Difficulty")
	float EnemyAccuracy_Easy = 0.28f; // S14-STAB: was 0.40 — see EnemyDamage_Easy

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Difficulty")
	float EnemyAccuracy_Normal = 0.65f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Difficulty")
	float EnemyAccuracy_Hard = 0.80f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Difficulty")
	float EnemyAccuracy_Lethal = 0.92f;

	// =====================================================================
	//  MINIMAP ICONS
	// =====================================================================

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Minimap Icons")
	TObjectPtr<UTexture2D> PlayerIcon;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Minimap Icons")
	TObjectPtr<UTexture2D> LeaderIcon;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Minimap Icons")
	TObjectPtr<UTexture2D> AllyIcon;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Minimap Icons")
	TObjectPtr<UTexture2D> EnemyIcon;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Minimap Icons")
	TObjectPtr<UTexture2D> MissionZoneIcon;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Minimap Icons")
	TObjectPtr<UTexture2D> LeaderBorderIcon;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Minimap Icons")
	TObjectPtr<UTexture2D> MissionBorderIcon;

	// =====================================================================
	//  MINIMAP
	// =====================================================================

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Minimap")
	FLinearColor MinimapBorderColor = FLinearColor(0.5f, 0.5f, 0.5f, 1.f);

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Minimap")
	float MinimapBorderThickness = 3.f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Minimap")
	FString MinimapMaterialPath;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Minimap")
	TObjectPtr<UMaterialInterface> MinimapMaterial;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "HUD Font")
	FString HUDFontPath = TEXT("/Game/Fonts/SquadAI_HUD.SquadAI_HUD");

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "HUD Font")
	TObjectPtr<UFont> HUDFont;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "HUD Font")
	int32 ChecklistFontSize = 18;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "HUD Font")
	int32 MissionDescFontSize = 20;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "HUD Font")
	int32 BadgeFontSize = 16;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "HUD Font")
	int32 TimerFontSize = 24;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "HUD Font")
	int32 EnemyCounterFontSize = 18;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Minimap")
	FString EnemyCounterText = TEXT("دشمنان"); // F-D1: was U+0006 control chars + literal hex digits.

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Minimap")
	FString DistanceSuffix = TEXT("m");

	// =====================================================================
	//  MISSION COMPLETION POPUP
	// =====================================================================

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Mission Completion")
	float MissionCompletionDisplaySeconds = 3.0f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Mission Completion")
	TObjectPtr<UTexture2D> MissionCompletionBackground;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Mission Completion")
	FString MissionCompletionMessage = TEXT("\u0645\u0627\u0645\u0648\u0631\u06CC\u062A \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0628\u0647 \u067E\u0627\u06CC\u0627\u0646 \u0631\u0633\u06CC\u062F.");

	// =====================================================================
	//  QUEST
	// =====================================================================

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Quest")
	float QuestTickRate = 0.25f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Quest")
	float CorpseLingerSeconds = 8.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Quest")
	int32 EnemyPoolPrewarmCount = 30;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Quest")
	float SpawnPointNavProjectExtent = 120.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Combat|Heroes")
	float LeaderPackHealthFloor = 35.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Combat|Heroes")
	float LeaderVetoHealth = 50.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Combat|Heroes")
	float LeaderDamageScale = 0.0f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Combat|Heroes")
	float AllyPackHealthFloor = 1.f;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Progression")
	int32 KillXP = 50;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Progression")
	int32 HeadshotBonusXP = 25;
};

#pragma once

#include "CoreMinimal.h"
#include "Containers/Ticker.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "SaveSystem/SquadAISaveGame.h"
#include "SquadAISaveLoadSubsystem.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnSaveGameCompleted, bool, bSuccess);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnLoadGameCompleted, bool, bSuccess);

/**
 * FSquadSaveSlotInfo
 * Descriptive metadata for UI save slot rendering.
 */
USTRUCT(BlueprintType)
struct SQUADAI_API FSquadSaveSlotInfo
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SaveLoad")
	FString SlotName = TEXT("SquadAISave_0");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SaveLoad")
	FString DisplayName = TEXT("موقعیت ذخیره ۱");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SaveLoad")
	FDateTime Timestamp = FDateTime::Now();

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SaveLoad")
	bool bExists = false;
};

/**
 * USquadAISaveLoadSubsystem
 * GameInstance Subsystem managing persistent saving, loading, auto-saves,
 * settings profiles, and world reconstruction across level transitions.
 */
UCLASS(BlueprintType)
class SQUADAI_API USquadAISaveLoadSubsystem : public UGameInstanceSubsystem
{
	GENERATED_BODY()

public:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|SaveLoad", meta = (WorldContext = "WorldContextObject"))
	static USquadAISaveLoadSubsystem* Get(const UObject* WorldContextObject);

	// =========================================================================
	//  SAVE / LOAD ACTIONS
	// =========================================================================

	UFUNCTION(BlueprintCallable, Category = "SquadAI|SaveLoad")
	bool SaveGame(const FString& SlotName = TEXT("SquadAISave_Manual"));

	// B6-1: the slot constants below are private consts — expose the autosave one so
	// the pause menu saves where GetAllSaveSlotNames()/Continue actually look.
	FString GetAutoSaveSlotName() const { return AutoSaveSlotName; }

	UFUNCTION(BlueprintCallable, Category = "SquadAI|SaveLoad")
	bool LoadGame(const FString& SlotName = TEXT("SquadAISave_Manual"), bool bTransitionToMap = true);

	UFUNCTION(BlueprintCallable, Category = "SquadAI|SaveLoad")
	bool QuickSave();

	UFUNCTION(BlueprintCallable, Category = "SquadAI|SaveLoad")
	bool QuickLoad();

	UFUNCTION(BlueprintCallable, Category = "SquadAI|SaveLoad")
	bool AutoSave(const FText& SectorName = FText());

	UFUNCTION(BlueprintCallable, Category = "SquadAI|SaveLoad")
	bool DeleteSaveSlot(const FString& SlotName);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|SaveLoad")
	bool DoesSaveExist(const FString& SlotName) const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|SaveLoad")
	TArray<FString> GetAllSaveSlotNames() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|SaveLoad")
	TArray<FSquadSaveSlotInfo> GetAllSaveSlots() const;

	UFUNCTION(BlueprintCallable, Category = "SquadAI|SaveLoad")
	bool LoadGameFromSlot(int32 SlotIndex);

	UFUNCTION(BlueprintCallable, Category = "SquadAI|SaveLoad")
	bool LoadLatestSave();

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|SaveLoad")
	USquadAISaveGame* GetLoadedSaveData() const { return CurrentLoadedSave; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|SaveLoad")
	USquadAISaveGame* ReadSaveMetadata(const FString& SlotName) const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|SaveLoad")
	FString GetMostRecentSaveSlot() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|SaveLoad")
	bool HasAnySaves() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|SaveLoad")
	bool HasAnySaveGames() const { return HasAnySaves(); }

	// =========================================================================
	//  WORLD RESTORATION (Called after level load)
	// =========================================================================

	UFUNCTION(BlueprintCallable, Category = "SquadAI|SaveLoad")
	void ApplySaveDataToWorld(UWorld* World);

	// =========================================================================
	//  SETTINGS MANAGEMENT
	// =========================================================================

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Settings")
	void SaveSettings(const FSquadGameSettingsSaveData& Settings);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Settings")
	FSquadGameSettingsSaveData LoadSettings();

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Settings")
	void ApplySettingsToEngine(const FSquadGameSettingsSaveData& Settings);

	// B6-9: last-applied settings (HUD/consumers read without disk I/O; also exposes
	// MouseSensitivity/bInvertYAxis to the out-of-module look-input owner).
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Settings")
	FSquadGameSettingsSaveData GetCachedSettings() const { return CachedSettings; }

	/**
	 * S18-INTRO2: true when the current level was entered by loading a save
	 * rather than starting fresh. Transient (this subsystem lives on the game
	 * instance, so it survives the travel) and consumed once by the HUD, which
	 * uses it to suppress the opening title card on a reload.
	 */
	UFUNCTION(BlueprintCallable, Category = "SquadAI|SaveLoad")
	bool ConsumeEnteredLevelFromLoad()
	{
		const bool bWas = bEnteredLevelFromLoad;
		bEnteredLevelFromLoad = false;
		return bWas;
	}

private:
	bool bEnteredLevelFromLoad = false;

public:

	// =========================================================================
	//  EVENTS
	// =========================================================================

	UPROPERTY(BlueprintAssignable, Category = "SquadAI|SaveLoad")
	FOnSaveGameCompleted OnSaveCompleted;

	UPROPERTY(BlueprintAssignable, Category = "SquadAI|SaveLoad")
	FOnLoadGameCompleted OnLoadCompleted;

private:
	UPROPERTY()
	TObjectPtr<USquadAISaveGame> CurrentLoadedSave;

	// B6-9: last-applied settings cache (defaults = struct defaults until first apply).
	FSquadGameSettingsSaveData CachedSettings;

	// B6-15: GetMostRecentSaveSlot deserializes every slot — cache until a save/delete lands.
	mutable FString CachedMostRecentSlot;
	mutable bool bMostRecentCacheValid = false;

	// Post-travel apply state (B6-12 fix): polls until the destination world is live.
	FTSTicker::FDelegateHandle PostTravelApplyHandle;
	FString PendingApplyMapName;
	float PendingApplyElapsed = 0.f;

	void SchedulePostTravelApply(const FString& TargetMapName);

	const FString SettingsSlotName = TEXT("SquadAISettings_Profile");
	const FString QuickSaveSlotName = TEXT("SquadAISave_QuickSave");
	const FString AutoSaveSlotName = TEXT("SquadAISave_AutoSave");

	void GatherWorldDataIntoSave(USquadAISaveGame* SaveObj, UWorld* World);
};

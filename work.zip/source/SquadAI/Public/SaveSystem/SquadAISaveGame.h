#pragma once

#include "CoreMinimal.h"
#include "GameFramework/SaveGame.h"
#include "SquadAISaveGame.generated.h"

USTRUCT(BlueprintType)
struct FSquadAllySaveData
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SaveData")
	FString AllyID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SaveData")
	FTransform Transform;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SaveData")
	float Health = 100.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SaveData")
	float MaxHealth = 100.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SaveData")
	bool bIsDowned = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SaveData")
	bool bIsDead = false;
};

USTRUCT(BlueprintType)
struct FSquadGameSettingsSaveData
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Audio Settings")
	float MasterVolume = 1.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Audio Settings")
	float MusicVolume = 0.8f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Audio Settings")
	float SFXVolume = 1.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Audio Settings")
	float VoiceVolume = 1.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Gameplay Settings")
	float MouseSensitivity = 1.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Gameplay Settings")
	bool bInvertYAxis = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Gameplay Settings")
	bool bEnableSubtitles = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Video Settings")
	int32 OverallQualityPreset = 3; // 0=Low, 1=Med, 2=High, 3=Epic

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Video Settings")
	float FieldOfView = 90.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Video Settings")
	bool bMotionBlurEnabled = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Video Settings")
	bool bVSyncEnabled = false;

	// B6-9: persisted language (fa/en). Was claimed "persisted" but no field existed.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Gameplay Settings")
	FString LanguageCode = TEXT("fa");

	// S18-TUT: the "skip the tutorial?" question is asked only on the very first
	// play. Both flags live in the settings profile, not a game slot, so they
	// survive new games and slot deletion.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tutorial")
	bool bTutorialPromptAnswered = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tutorial")
	bool bTutorialCompleted = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tutorial")
	bool bTutorialSkipped = false;

	// S18-INTRO2: levels whose scripted opening walk has already been played.
	// Stored by level name in the settings profile (not a game slot), so the
	// major never walks you down the same trench twice, and reloading a
	// mid-mission save does not replay the opening.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tutorial")
	TArray<FString> PlayedIntroLevels;
};

/**
 * USquadAISaveGame
 * Complete Tactical Game State & Player Progress Save Container.
 * Serializes squad state, player health & ammo, active quest/mission chain,
 * level, XP, attribute upgrades, armory unlocks, and player customization settings.
 */
UCLASS(BlueprintType)
class SQUADAI_API USquadAISaveGame : public USaveGame
{
	GENERATED_BODY()

public:
	USquadAISaveGame();

	// =========================================================================
	//  SAVE METADATA
	// =========================================================================

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Save Metadata")
	FString SlotName = TEXT("SquadAISave_Slot0");

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Save Metadata")
	FDateTime Timestamp;

	// S5-15: save format versioning. Legacy saves written before this field existed
	// deserialize with the class-default 1 and are restored via the legacy fallback.
	static constexpr int32 CurrentSaveFormatVersion = 2;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Save Metadata")
	int32 SaveFormatVersion = 1;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Save Metadata")
	float PlaytimeSeconds = 0.0f;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Save Metadata")
	FString MapName = TEXT("L_Khuzestan");

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Save Metadata")
	FText SectorDisplayName = FText::FromString(TEXT("محور دهلاویه و کرخه - خط مقدم"));

	// =========================================================================
	//  PLAYER LEVELING & ATTRIBUTES PROGRESSION
	// =========================================================================

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Progression")
	int32 PlayerLevel = 1;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Progression")
	int32 PlayerTotalXP = 0;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Progression")
	int32 PlayerCurrentLevelXP = 0;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Progression")
	int32 AvailableSkillPoints = 0;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Progression")
	TMap<uint8, int32> AttributeUpgradeRanks;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Progression")
	TArray<FName> UnlockedWeaponIDs;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Progression")
	TArray<FName> UnlockedAchievementIDs;

	// B6-22: identity dossier persistence (profile name/avatar were editable but never saved).
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Progression")
	FString SavedPlayerName;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Progression")
	FName SavedAvatarID;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Progression")
	FString SavedBloodType;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Progression")
	FString SavedDogTagNumber;

	// =========================================================================
	//  TACTICAL MISSION & CAMPAIGN PROGRESS
	// =========================================================================

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Campaign Progress")
	int32 ActiveMissionIndex = 0;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Campaign Progress")
	FText ActiveMissionTitle = FText::FromString(TEXT("پیشروی در سنگرهای دهلاویه"));

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Campaign Progress")
	int32 CompletedMissionCount = 0;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Campaign Progress")
	int32 TotalWavesCleared = 0;

	// S5-15: stable identity of the quest chain ActiveMissionIndex refers to.
	// v2+ saves restore by GUID match (name as secondary), not iterator order.
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Campaign Progress")
	FGuid SavedChainId;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Campaign Progress")
	FName SavedChainName;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Campaign Progress")
	int32 DifficultyRating = 1; // 0=Recruit, 1=Regular, 2=Hardened, 3=Veteran

	// =========================================================================
	//  PLAYER STATE & LOADOUT
	// =========================================================================

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Player State")
	FTransform PlayerTransform;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Player State")
	float PlayerHealth = 100.0f;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Player State")
	float PlayerMaxHealth = 100.0f;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Player State")
	FName EquippedWeaponID = FName("G3A3");

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Player State")
	int32 AmmoInClip = 20;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Player State")
	int32 ReserveAmmo = 140;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Player State")
	int32 FragGrenades = 3;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Player State")
	int32 SmokeGrenades = 2;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Player State")
	int32 FirstAidKits = 2;

	// =========================================================================
	//  SQUAD STATUS
	// =========================================================================

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Squad State")
	TArray<FSquadAllySaveData> SavedAllies;

	// =========================================================================
	//  SETTINGS & CONFIGURATION
	// =========================================================================

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Settings")
	FSquadGameSettingsSaveData SavedSettings;
};

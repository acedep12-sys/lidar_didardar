#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "MountedTurretActor.generated.h"

class UStaticMeshComponent;
class USphereComponent;
class USoundBase;
class UNiagaraSystem;
class UCameraShakeBase;

/**
 * AMountedTurretActor
 * Heavy Sandbag-Mounted Machine Gun Emplacement (DShK / .50 Cal).
 * Allows the player or squad leader to mount and lay down devastating heavy machine gun fire.
 */
UCLASS(BlueprintType, Blueprintable, meta = (DisplayName = "Mounted Heavy Machine Gun"))
class SQUADAI_API AMountedTurretActor : public AActor
{
	GENERATED_BODY()

public:
	AMountedTurretActor();

	// =========================================================================
	//  COMPONENTS & VISUALS
	// =========================================================================

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<USceneComponent> SceneRoot;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UStaticMeshComponent> BaseMesh;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UStaticMeshComponent> GunMesh;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<USphereComponent> InteractionSphere;

	// =========================================================================
	//  TURRET CONFIGURATION
	// =========================================================================

	/** Damage per heavy caliber bullet */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Turret|Combat")
	float DamagePerShot = 40.f;

	/** Rounds fired per second (e.g. 10 rounds/sec = 600 RPM) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Turret|Combat")
	float FireRate = 10.f;

	/** Maximum range of heavy machine gun in cm (150m) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Turret|Combat")
	float MaxRange = 15000.f;

	/** Heavy gunshot firing sound */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Turret|Audio")
	TObjectPtr<USoundBase> FireSound;

	/** Camera shake during heavy continuous firing */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Turret|FX")
	TSubclassOf<UCameraShakeBase> FireCameraShake;

	/** Prompt text displayed when in proximity */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Turret|UI")
	FString MountPromptText = TEXT("[E] استقرار پشت تیربار سنگین");

	/** Custom mesh for turret base / sandbag nest */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Turret|Visuals")
	TObjectPtr<UStaticMesh> CustomBaseMesh;

	/** Custom mesh for turret machine gun */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Turret|Visuals")
	TObjectPtr<UStaticMesh> CustomGunMesh;

	/** Custom material for turret base */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Turret|Visuals")
	TObjectPtr<UMaterialInterface> BaseMaterialOverride;

	/** Custom material for turret gun */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Turret|Visuals")
	TObjectPtr<UMaterialInterface> GunMaterialOverride;

	UPROPERTY(BlueprintReadOnly, Category = "Turret|State")
	bool bIsMounted = false;

	UFUNCTION(BlueprintCallable, Category = "Turret")
	void ApplyCustomVisuals();

	UFUNCTION(BlueprintCallable, Category = "Turret")
	void MountTurret(APawn* PlayerPawn);

	UFUNCTION(BlueprintCallable, Category = "Turret")
	void DismountTurret();

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Turret")
	bool IsPlayerInRange() const { return bPlayerInRange; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Turret")
	APawn* GetMountedPawn() const { return MountedPawn.Get(); }

protected:
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;

	UFUNCTION()
	void OnOverlapBegin(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
		UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

	UFUNCTION()
	void OnOverlapEnd(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
		UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);

private:
	bool bPlayerInRange = false;
	float LastFireTime = 0.f;
	TWeakObjectPtr<APawn> MountedPawn;
	uint8 CachedMountMovementMode = 1; // B7-20: EMovementMode across mount (uint8 keeps CharacterMovement out of the header; 1 = MOVE_Walking).

	void FireHeavyRound();
};

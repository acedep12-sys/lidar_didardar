#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "MedicalStationActor.generated.h"

class UStaticMeshComponent;
class USphereComponent;
class USoundBase;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnHealthRestored, APawn*, PlayerPawn);

/**
 * AMedicalStationActor
 * Battlefield First Aid & Medical Supply Station for Open World Trench Warfare.
 * 
 * Features:
 * 1. Proximity detection: Displays floating 3D prompt [E] First Aid Station when player is near.
 * 2. Interaction: Pressing 'E' heals the player back to 100% max health.
 * 3. First-aid bandage audio & on-screen HUD feedback.
 * 4. Configurable cooldown or unlimited uses.
 */
UCLASS(BlueprintType, Blueprintable, meta = (DisplayName = "Military Medical Station"))
class SQUADAI_API AMedicalStationActor : public AActor
{
	GENERATED_BODY()

public:
	AMedicalStationActor();

	// =========================================================================
	//  COMPONENTS & VISUALS
	// =========================================================================

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<USceneComponent> SceneRoot;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UStaticMeshComponent> StationMesh;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<USphereComponent> InteractionSphere;

	// =========================================================================
	//  CONFIG
	// =========================================================================

	/** Amount of health restored (<= 0 means full 100% heal) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Medical Station")
	float HealAmount = -1.0f;

	/** Interaction radius in cm (default 220cm = 2.2m) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Medical Station", meta = (ClampMin = "50"))
	float InteractionRadius = 220.f;

	/** Cooldown in seconds between uses (0 = instant reuse) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Medical Station", meta = (ClampMin = "0"))
	float CooldownSeconds = 0.0f;

	/** First aid / bandage audio sound */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Medical Station|Audio")
	TObjectPtr<USoundBase> HealSound;

	/** Floating prompt text */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Medical Station|UI")
	FString PromptText = TEXT("[E] ایستگاه امداد و درمان");

	UPROPERTY(BlueprintAssignable, Category = "Medical Station|Events")
	FOnHealthRestored OnHealthRestored;

	// =========================================================================
	//  API
	// =========================================================================

	UFUNCTION(BlueprintCallable, Category = "Medical Station")
	bool HealPlayer(APawn* PlayerPawn);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Medical Station")
	bool IsPlayerInRange() const { return bPlayerInRange; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Medical Station")
	bool IsReady() const { return CooldownTimer <= 0.0f; }

protected:
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;

	UFUNCTION()
	void OnOverlapBegin(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
		UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

	UFUNCTION()
	void OnOverlapEnd(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
		UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);

private:
	bool bPlayerInRange = false;
	float CooldownTimer = 0.0f;
	TWeakObjectPtr<APawn> CachedPlayerPawn;
};

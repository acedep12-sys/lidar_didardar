#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "CombatEncounterVolume.generated.h"

class UBoxComponent;
class ASoldierCharacter;
class AEnemySoldier;
class AEnemyCommander;           // S19-ELITE
class AEnemyCommanderAssistant;  // S19-ELITE
class AFirstAidKitActor;
class AAmmoCrateActor;
class AMountedTurretActor;

UENUM(BlueprintType)
enum class ECombatEncounterType : uint8
{
	Ambush			UMETA(DisplayName = "Ambush / Skirmish"),
	DefendPosition	UMETA(DisplayName = "Bunker / Stronghold Defense"),
	PatrolCamp		UMETA(DisplayName = "Patrol Camp / Outpost"),
	WaveAssault		UMETA(DisplayName = "Multi-Wave Assault"),
	CommanderHunt	UMETA(DisplayName = "Eliminate Commander")
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnEncounterStarted, ACombatEncounterVolume*, EncounterVolume);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnEncounterWaveCleared, int32, WaveIndex);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnEncounterCompleted, ACombatEncounterVolume*, EncounterVolume);

/**
 * ACombatEncounterVolume
 * Drag-and-drop Combat Encounter Arena & Wave Spawner.
 * 
 * Drop this volume into any trench, canyon, bunker, or outpost to instantly turn it into
 * an active tactical combat zone with zero manual blueprint coding required.
 */
UCLASS(BlueprintType, Blueprintable, meta = (DisplayName = "Tactical Combat Encounter Arena"))
class SQUADAI_API ACombatEncounterVolume : public AActor
{
	GENERATED_BODY()

public:
	ACombatEncounterVolume();

	// =========================================================================
	//  COMPONENTS
	// =========================================================================

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<USceneComponent> SceneRoot;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UBoxComponent> TriggerBounds;

	// =========================================================================
	//  ENCOUNTER CONFIGURATION
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat Encounter")
	FText EncounterName = FText::FromString(TEXT("Tactical Combat Zone"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat Encounter")
	ECombatEncounterType EncounterType = ECombatEncounterType::Ambush;

	/** Number of waves to fight (1 for single skirmish) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat Encounter", meta = (ClampMin = "1", ClampMax = "10"))
	int32 TotalWaves = 1;

	/** Number of enemy soldiers per wave */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat Encounter", meta = (ClampMin = "1", ClampMax = "16"))
	int32 EnemiesPerWave = 4;

	/** Delay between clearing a wave and spawning the next reinforcement wave */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat Encounter", meta = (ClampMin = "1.0"))
	float WaveIntervalSeconds = 4.0f;

	/** If true, automatically activates when player walks inside the volume */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat Encounter")
	bool bTriggerOnPlayerEntry = true;

	/** If true, automatically spawns tactical First Aid Kits and Ammo Crates inside the combat zone */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat Encounter|Logistics")
	bool bAutoScatterSupplyKits = true;

	/** If true, automatically spawns a mounted heavy machine gun defense turret */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat Encounter|Logistics")
	bool bSpawnMountedTurret = false;

	/** If true, triggers a brief cinematic slow-motion effect when the final enemy of the encounter is eliminated */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat Encounter|Cinematics")
	bool bCinematicSlowMoOnClear = true;

	// ===== S19-ELITE: the commander =====

	/** Enemy class this volume spawns. Empty = the native AEnemySoldier; set it to your
	 *  BP_Enemy if your waves use the pack factory instead. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat Encounter|Enemy")
	TSubclassOf<AEnemySoldier> EnemyClass;

	/** A commander joins the fight. Forced ON for the "Eliminate Commander" encounter
	 *  type, whatever this says - that type's whole objective is him. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat Encounter|Elite")
	bool bSpawnCommander = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat Encounter|Elite")
	TSubclassOf<AEnemyCommander> CommanderClass;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat Encounter|Elite")
	TSubclassOf<AEnemyCommanderAssistant> AssistantClass;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat Encounter|Elite", meta = (ClampMin = "0", ClampMax = "6"))
	int32 AssistantsPerCommander = 2;

	/** For CommanderHunt: the encounter is complete the moment HE dies (his men may still
	 *  be up - that is the point of a decapitation strike). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat Encounter|Elite")
	bool bCompleteOnCommanderDeath = true;

	/** The commander this encounter spawned (read-only). */
	UPROPERTY(BlueprintReadOnly, Category = "Combat Encounter|State")
	TObjectPtr<AEnemyCommander> SpawnedCommander;

	// =========================================================================
	//  EVENTS
	// =========================================================================

	UPROPERTY(BlueprintAssignable, Category = "Combat Encounter|Events")
	FOnEncounterStarted OnEncounterStarted;

	UPROPERTY(BlueprintAssignable, Category = "Combat Encounter|Events")
	FOnEncounterWaveCleared OnEncounterWaveCleared;

	UPROPERTY(BlueprintAssignable, Category = "Combat Encounter|Events")
	FOnEncounterCompleted OnEncounterCompleted;

	// =========================================================================
	//  API
	// =========================================================================

	UFUNCTION(BlueprintCallable, Category = "Combat Encounter")
	void StartEncounter();

	UFUNCTION(BlueprintCallable, Category = "Combat Encounter")
	void ResetEncounter();

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Combat Encounter")
	bool IsEncounterActive() const { return bIsActive; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Combat Encounter")
	bool IsEncounterCompleted() const { return bIsCompleted; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Combat Encounter")
	int32 GetCurrentWave() const { return CurrentWaveIndex; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Combat Encounter")
	int32 GetAliveEnemiesCount() const;

protected:
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;

	// S19-ELITE
	/** True when this encounter should field a commander. */
	bool ShouldSpawnCommander() const;
	void SpawnCommanderAndEscorts(const FVector& Origin);
	/** Death hook on the commander (the decapitation objective). */
	UFUNCTION()
	void OnCommanderDied(AActor* OwnerActor);

	UFUNCTION()
	void OnTriggerOverlapBegin(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
		UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

	void SpawnCurrentWave();
	void OnEnemyKilled(ASoldierCharacter* DeadSoldier);
	void SetupFieldLogistics();
	void CompleteEncounter();

private:
	bool bIsActive = false;
	bool bIsCompleted = false;
	int32 CurrentWaveIndex = 0;
	float NextWaveTimer = 0.0f;
	bool bPendingNextWave = false;

	UPROPERTY()
	TArray<TWeakObjectPtr<ASoldierCharacter>> ActiveEnemies;

	UPROPERTY()
	TArray<TWeakObjectPtr<AActor>> SpawnedSupplies;
};

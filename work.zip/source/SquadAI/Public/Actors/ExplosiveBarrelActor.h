#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "ExplosiveBarrelActor.generated.h"

class UStaticMeshComponent;
class USoundBase;
class UParticleSystem;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnBarrelExploded, AExplosiveBarrelActor*, Barrel);

/**
 * AExplosiveBarrelActor
 * Tactical Red Explosive Fuel Drum / Ammunition Cache.
 * 
 * Shooters can ignite these barrels in combat to trigger devastating chain explosions,
 * blast enemies out of trenches, and suppress surrounding hostile squads.
 */
UCLASS(BlueprintType, Blueprintable, meta = (DisplayName = "Tactical Explosive Barrel"))
class SQUADAI_API AExplosiveBarrelActor : public AActor
{
	GENERATED_BODY()

public:
	AExplosiveBarrelActor();

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<USceneComponent> SceneRoot;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UStaticMeshComponent> BarrelMesh;

	// =========================================================================
	//  CONFIG
	// =========================================================================

	/** Barrel durability before detonating */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Explosive Barrel", meta = (ClampMin = "1.0"))
	float Health = 25.0f;

	/** Maximum explosion damage at center */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Explosive Barrel", meta = (ClampMin = "10.0"))
	float ExplosionDamage = 180.0f;

	/** S18-BOOM: friendly-fire scale applied to the local player (0 = immune,
	 *  1 = full). The player is damaged through a dedicated path because pack
	 *  Blueprint health does not respond to engine radial damage. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Explosion", meta = (ClampMin = "0.0", ClampMax = "2.0"))
	float PlayerDamageMultiplier = 0.5f;

	/** Radius in cm of lethal blast damage */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Explosive Barrel", meta = (ClampMin = "100.0"))
	float ExplosionRadius = 650.0f;

	/** Radial physics impulse applied to physics objects & ragdolls */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Explosive Barrel")
	float ExplosionImpulse = 120000.0f;

	/** Radius in cm in which surviving enemies become heavily suppressed */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Explosive Barrel")
	float SuppressionRadius = 1200.0f;

	/** Audio sound played upon detonation */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Explosive Barrel|Audio")
	TObjectPtr<USoundBase> ExplosionSound;

	/** Custom mesh override for explosive barrel */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Explosive Barrel|Visuals")
	TObjectPtr<UStaticMesh> CustomBarrelMesh;

	/** Custom material override for explosive barrel */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Explosive Barrel|Visuals")
	TObjectPtr<UMaterialInterface> BarrelMaterialOverride;

	UPROPERTY(BlueprintAssignable, Category = "Explosive Barrel|Events")
	FOnBarrelExploded OnBarrelExploded;

	// =========================================================================
	//  API
	// =========================================================================

	UFUNCTION(BlueprintCallable, Category = "Explosive Barrel")
	void ApplyCustomVisuals();

	UFUNCTION(BlueprintCallable, Category = "Explosive Barrel")
	void Detonate();

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Explosive Barrel")
	bool IsDetonated() const { return bHasExploded; }

protected:
	virtual void BeginPlay() override;

	UFUNCTION()
	void HandleTakeAnyDamage(AActor* DamagedActor, float Damage, const UDamageType* DamageType,
		AController* InstigatedBy, AActor* DamageCauser);

private:
	bool bHasExploded = false;
	bool bIsIgnited = false;
	FTimerHandle FuseTimerHandle;
};

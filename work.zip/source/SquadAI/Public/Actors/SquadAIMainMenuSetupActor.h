#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "UObject/SoftObjectPath.h"   // S26-VIDEO: FFilePath (the details-panel file picker)
#include "HUD/SquadAIMainMenuHUD.h"
#include "SquadAIMainMenuSetupActor.generated.h"

class USoundBase;
class UTexture2D;
class UMaterialInterface;
class UCameraComponent;
class AAtmosphericDustScatterer;
class UNiagaraSystem;

/**
 * ASquadAIMainMenuSetupActor
 * Complete Master Manager for Main Menu, Theater Selection, Armory, Player Profiles, and Loading Screen.
 * 
 * Features:
 * 1. [1-Click Master Setup & Auto-Wire] button in Details panel.
 * 2. Dedicated drag-and-drop asset slots for all required textures, frames, avatars, weapon previews, and sounds.
 * 3. 1-Click Persian Farsi (Holy Defense) and English (AAA Military) presets.
 * 4. Auto-resolution of asset paths from Content/Textures/.
 * 5. Automatic runtime HUD, camera orbit, atmospheric dust, and loading screen coordination.
 */
UCLASS(BlueprintType, Blueprintable, meta = (DisplayName = "SquadAI Main Menu Master Director"))
class SQUADAI_API ASquadAIMainMenuSetupActor : public AActor
{
	GENERATED_BODY()

public:
	ASquadAIMainMenuSetupActor();

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<USceneComponent> SceneRoot;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UCameraComponent> MenuCamera;

	// =========================================================================
	//  1-CLICK MASTER ACTIONS (BUTTONS IN UNREAL DETAILS PANEL)
	// =========================================================================

	/** 1-Click Master Setup: Auto-wires HUD, GameMode, Camera Orbit, Atmosphere, and Assets */
	UFUNCTION(BlueprintCallable, CallInEditor, Category = "1-Click Master Setup")
	void AutoSetupMasterMainMenu();

	/** 1-Click Auto-Resolve: Automatically loads all textures from /Game/Textures/ into the required slots */
	UFUNCTION(BlueprintCallable, CallInEditor, Category = "1-Click Master Setup")
	void AutoResolveAllTextureSlots();

	/** Apply authentic 1980s Holy Defense Persian Farsi presets to all menus and briefings */
	UFUNCTION(BlueprintCallable, CallInEditor, Category = "1-Click Presets")
	void ApplyPersianFarsiPreset();

	/** Apply modern AAA tactical shooter English presets to all menus and briefings */
	UFUNCTION(BlueprintCallable, CallInEditor, Category = "1-Click Presets")
	void ApplyEnglishMilitaryPreset();

	/** Test Launch Mission & Preview Loading Screen with custom briefing */
	UFUNCTION(BlueprintCallable, CallInEditor, Category = "1-Click Testing")
	void TestLaunchMissionWithLoadingScreen();

	// =========================================================================
	//  SETUP STATUS & DIAGNOSTICS
	// =========================================================================

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Setup Status")
	FString SetupStatusMessage = TEXT("Ready. Click [AutoSetupMasterMainMenu] to configure.");

	// =========================================================================
	//  LEVEL & NAVIGATION CONFIG
	// =========================================================================

	/** Name of the main open-world gameplay map to load when starting a game */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Target Level")
	FName TargetGameplayLevelName = FName("L_Khuzestan");

	// =========================================================================
	//  CUSTOM TEXT & LOCALIZATION
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Custom Text & Localization")
	FSquadMenuTextConfig MenuTextConfig;

	// =========================================================================
	//  BACKGROUND CONFIGURATION (3D Orbit, Video Material, Texture)
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Background")
	EMenuBackgroundType BackgroundType = EMenuBackgroundType::StaticImageKenBurns;

	/** Optional looping video texture material or animated background material */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Background")
	TObjectPtr<UMaterialInterface> BackgroundMaterial;

	/** If true, slowly orbits the 3D camera in a circle for a cinematic live backdrop */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Cinematic Camera", meta = (EditCondition = "BackgroundType == EMenuBackgroundType::Cinematic3DCameraOrbit"))
	bool bEnableCinematicCameraPan = true;

	/** Camera orbit speed in degrees per second */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Cinematic Camera")
	float CameraPanSpeed = 1.5f;

	/** Optional exact Niagara dust/dirt explosion used by the Canvas main menu bottom window. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu FX|Niagara")
	TObjectPtr<UNiagaraSystem> MenuDustNiagaraSystem;

	/** Enables the real Niagara dust bursts behind the lower transparent background window. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu FX|Niagara")
	bool bUseNiagaraMenuDustExplosion = true;

	/** How often the menu spawns visible dust bursts; lower = denser/longer-looking. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu FX|Niagara", meta = (ClampMin = "0.25", ClampMax = "6.00"))
	float MenuNiagaraDustBurstInterval = 1.15f;

	/** Distance of camera orbit around the scene origin */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Cinematic Camera")
	float OrbitRadius = 800.0f;

	/** Height offset of camera */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Cinematic Camera")
	float CameraHeight = 250.0f;

	// =========================================================================
	//  VISUAL THEME & PALETTE
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Visual Theme")
	EMenuColorTheme ColorTheme = EMenuColorTheme::DesertKhakiGold;

	// =========================================================================
	//  REQUIRED ASSET SLOTS: 1. KEY ART & BACKGROUNDS
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|1. Backgrounds & Loading")
	TObjectPtr<UTexture2D> MenuBackgroundTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|1. Backgrounds & Loading")
	TObjectPtr<UTexture2D> LoadingScreenTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|1. Backgrounds & Loading")
	TObjectPtr<UTexture2D> NightOperationsTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|1. Backgrounds & Loading")
	TObjectPtr<UTexture2D> WatermarkEmblemTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|1. Backgrounds & Loading")
	TObjectPtr<UTexture2D> PlayerProgressionArtTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|1. Backgrounds & Loading")
	TObjectPtr<UTexture2D> BackgroundMedalsTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|1. Backgrounds & Loading")
	TObjectPtr<UTexture2D> BackgroundProgressionTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|1. Backgrounds & Loading")
	TObjectPtr<UTexture2D> BackgroundArmoryTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|1. Backgrounds & Loading")
	TObjectPtr<UTexture2D> DiffRecruitTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|1. Backgrounds & Loading")
	TObjectPtr<UTexture2D> DiffRegularTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|1. Backgrounds & Loading")
	TObjectPtr<UTexture2D> DiffHardenedTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|1. Backgrounds & Loading")
	TObjectPtr<UTexture2D> DiffLethalTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|1. Backgrounds & Loading")
	TObjectPtr<UTexture2D> ProgressionUpgradeBarTexture;

	// =========================================================================
	//  REQUIRED ASSET SLOTS: 2. MODULAR UI FRAMES & BORDERS
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|2. UI Frames & Borders")
	TObjectPtr<UTexture2D> FrameTacticalGoldTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|2. UI Frames & Borders")
	TObjectPtr<UTexture2D> FrameTacticalCrimsonTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|2. UI Frames & Borders")
	TObjectPtr<UTexture2D> FrameBadgeHexagonTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|2. UI Frames & Borders")
	TObjectPtr<UTexture2D> FrameAvatarPortraitTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|2. UI Frames & Borders")
	TObjectPtr<UTexture2D> FrameMapTheaterTexture;

	// =========================================================================
	//  REQUIRED ASSET SLOTS: 3. SOLDIER PROFILE AVATARS
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|3. Profile Avatars")
	TObjectPtr<UTexture2D> AvatarShahidRostamiTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|3. Profile Avatars")
	TObjectPtr<UTexture2D> AvatarYoungBasijiTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|3. Profile Avatars")
	TObjectPtr<UTexture2D> AvatarArteshParatrooperTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|3. Profile Avatars")
	TObjectPtr<UTexture2D> AvatarGuerrillaHunterTexture;

	// =========================================================================
	//  REQUIRED ASSET SLOTS: 4. WEAPON SPECIALITY TRAIT BADGES
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|4. Trait Badges")
	TObjectPtr<UTexture2D> TraitTankDestroyerTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|4. Trait Badges")
	TObjectPtr<UTexture2D> TraitHeavyCaliberTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|4. Trait Badges")
	TObjectPtr<UTexture2D> TraitDesertReliabilityTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|4. Trait Badges")
	TObjectPtr<UTexture2D> TraitAreaSuppressionTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|4. Trait Badges")
	TObjectPtr<UTexture2D> TraitSilentMarksmanTexture;

	// =========================================================================
	//  REQUIRED ASSET SLOTS: 5. MAP & THEATER PREVIEWS
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|5. Map Previews")
	TObjectPtr<UTexture2D> MapPreviewDehlaviehTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|5. Map Previews")
	TObjectPtr<UTexture2D> MapPreviewBostanTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|5. Map Previews")
	TObjectPtr<UTexture2D> MapPreviewKhorramshahrTexture;

	// =========================================================================
	//  REQUIRED ASSET SLOTS: 6. PERIOD WEAPON PREVIEWS
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|6. Weapon Previews")
	TObjectPtr<UTexture2D> WeaponPreviewG3A3Texture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|6. Weapon Previews")
	TObjectPtr<UTexture2D> WeaponPreviewAK47Texture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|6. Weapon Previews")
	TObjectPtr<UTexture2D> WeaponPreviewRPG7Texture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|6. Weapon Previews")
	TObjectPtr<UTexture2D> WeaponPreviewMG3Texture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|6. Weapon Previews")
	TObjectPtr<UTexture2D> WeaponPreviewSVDTexture;

	// =========================================================================
	//  AUDIO & SFX SLOTS
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|7. Audio SFX")
	TObjectPtr<USoundBase> MenuThemeMusic;

	// S17-MVOL: live handle to the playing theme so the Settings screen can
	// adjust its volume without restarting the track.
	UPROPERTY(Transient)
	TObjectPtr<class UAudioComponent> MenuMusicAudioComp;

	UFUNCTION(BlueprintCallable, Category = "Menu|Audio")
	void SetMenuMusicVolume(float Volume);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|7. Audio SFX")
	TObjectPtr<USoundBase> DesertWindAmbience;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|7. Audio SFX")
	TObjectPtr<USoundBase> ButtonHoverSound;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|7. Audio SFX")
	TObjectPtr<USoundBase> ButtonClickSound;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|7. Audio SFX")
	TObjectPtr<USoundBase> ButtonBackSound;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|7. Audio SFX")
	TObjectPtr<USoundBase> UpgradePurchasedSound;

	// =========================================================================
	//  8. TYPOGRAPHY & CUSTOM FONTS
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|8. Typography & Fonts")
	TObjectPtr<UFont> CustomTitleFont;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|8. Typography & Fonts")
	TObjectPtr<UFont> CustomMenuFont;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|8. Typography & Fonts")
	TObjectPtr<UFont> CustomBodyFont;

	// =========================================================================
	//  9. INVENTORY, RADIO, QURAN & FALLEN NOTES
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|9. Inventory & Notes")
	TObjectPtr<UTexture2D> PocketQuranTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|9. Inventory & Notes")
	TObjectPtr<UTexture2D> PocketRadioTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|9. Inventory & Notes")
	TObjectPtr<UTexture2D> CombatWalletTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|9. Inventory & Notes")
	TObjectPtr<UTexture2D> FirstAidPouchTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|9. Inventory & Notes")
	TObjectPtr<UTexture2D> CanteenTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|9. Inventory & Notes")
	TObjectPtr<UTexture2D> DogTagTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|9. Inventory & Notes")
	TObjectPtr<UTexture2D> FallenNotesPlaceholderArtwork;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Required Assets|9. Inventory & Notes")
	TArray<TObjectPtr<UTexture2D>> FallenNotesImageList;

	/** If true, spawns atmospheric dust scatterer for authentic Khuzestan desert look */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Atmosphere")
	bool bSpawnAtmosphericDust = true;

	// =========================================================================
	//  S26-VIDEO2: one picker + one button PER video. Pick the file, press the
	//  button right under it - the file is copied to Content/Movies and
	//  auto-plays on the next menu open (PIE or packaged). MP4 (H.264 video +
	//  AAC audio) is the safe format. Delete the file in Content/Movies to
	//  fall back to the built-in art.
	// =========================================================================
	/** The LOOPING VIDEO behind the main menu. Pick an MP4 - it INSTALLS IMMEDIATELY with a notification (also: the button below, or console command SquadAI.InstallMenuVideos). */
	UPROPERTY(EditAnywhere, Category = "SquadAI|Main Menu Video", meta = (DisplayName = "Menu Background Video File (MP4)"))
	FFilePath MenuBackgroundVideoFile;

	/** Copies the background file above to Content/Movies/MenuBackground.mp4 */
	UFUNCTION(BlueprintCallable, CallInEditor, Category = "SquadAI|Main Menu Video")
	FString InstallMenuBackgroundVideo();

	/** The FULLSCREEN MOVIE that plays before the menu. Pick an MP4 - it INSTALLS IMMEDIATELY with a notification (also: the button below, or console command SquadAI.InstallMenuVideos). */
	UPROPERTY(EditAnywhere, Category = "SquadAI|Main Menu Video", meta = (DisplayName = "Intro Movie Video File (MP4)"))
	FFilePath IntroMovieVideoFile;

	/** Copies the intro file above to Content/Movies/MenuIntro.mp4 */
	UFUNCTION(BlueprintCallable, CallInEditor, Category = "SquadAI|Main Menu Video")
	FString InstallIntroMovieVideo();

	/** S26-VIDEOFIX: diagnoses EXACTLY what the menu will play next time it opens - file dates, image-sequence overrides, cvar states - and why. */
	UFUNCTION(BlueprintCallable, CallInEditor, Category = "SquadAI|Main Menu Video")
	FString WhatWillTheMenuVideosPlay();

#if WITH_EDITOR
	// S26-VIDEOFIX: setting either video path above installs it IMMEDIATELY -
	// the path picker is the button now. No button to find, no silent no-op.
	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;
#endif

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	// P1-L2: re-apply preset + re-push on central language change.
	void OnLanguageChanged(const FString& NewLang);
	FDelegateHandle LanguageChangedHandle;
	virtual void Tick(float DeltaTime) override;

private:
	float CurrentPanAngle = 0.0f;

	void PushSettingsToHUD(ASquadAIMainMenuHUD* HUD);
};

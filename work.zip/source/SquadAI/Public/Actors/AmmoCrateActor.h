#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "AmmoCrateActor.generated.h"

class UStaticMeshComponent;
class USphereComponent;
class USoundBase;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnAmmoResupplied, APawn*, PlayerPawn);

/**
 * AAmmoCrateActor
 * Tactical Military Ammo & Supply Crate for Open World Trench Warfare.
 * 
 * Features:
 * 1. Proximity detection: When player is near, displays floating 3D prompt [E] Resupply Ammo.
 * 2. Interaction: Pressing 'E' refills player's weapon clip and reserve ammo to maximum.
 * 3. Metallic ammo resupply audio & visual HUD feedback.
 * 4. Configurable cooldown or unlimited uses.
 */
UCLASS(BlueprintType, Blueprintable, meta = (DisplayName = "Military Ammo Crate"))
class SQUADAI_API AAmmoCrateActor : public AActor
{
	GENERATED_BODY()

public:
	AAmmoCrateActor();

	// =========================================================================
	//  COMPONENTS & VISUALS
	// =========================================================================

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<USceneComponent> SceneRoot;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UStaticMeshComponent> CrateMesh;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<USphereComponent> InteractionSphere;

	// =========================================================================
	//  CONFIG
	// =========================================================================

	/** Maximum reserve ammo given on resupply */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ammo Crate")
	int32 MaxReserveAmmo = 180;

	/** Clip ammo refilled on resupply */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ammo Crate")
	int32 MaxClipAmmo = 30;

	/** Interaction radius in cm (default 220cm = 2.2m) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ammo Crate", meta = (ClampMin = "50"))
	float InteractionRadius = 220.f;

	/** Optional cooldown in seconds between uses (0 = infinite / instant reuse) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ammo Crate", meta = (ClampMin = "0"))
	float CooldownSeconds = 0.0f;

	/** Satisfying metallic ammo reload / latch opening sound */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ammo Crate|Audio")
	TObjectPtr<USoundBase> ResupplySound;

	/** Floating prompt text */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ammo Crate|UI")
	FString PromptText = TEXT("[E] دریافت مهمات");

	/** Custom mesh override for ammo crate */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ammo Crate|Visuals")
	TObjectPtr<UStaticMesh> CustomCrateMesh;

	/** Custom material override for ammo crate */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ammo Crate|Visuals")
	TObjectPtr<UMaterialInterface> CrateMaterialOverride;

	UPROPERTY(BlueprintAssignable, Category = "Ammo Crate|Events")
	FOnAmmoResupplied OnAmmoResupplied;

	// =========================================================================
	//  API
	// =========================================================================

	UFUNCTION(BlueprintCallable, Category = "Ammo Crate")
	void ApplyCustomVisuals();

	UFUNCTION(BlueprintCallable, Category = "Ammo Crate")
	bool ResupplyPlayer(APawn* PlayerPawn);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Ammo Crate")
	bool IsPlayerInRange() const { return bPlayerInRange; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Ammo Crate")
	bool IsReady() const { return CooldownTimer <= 0.0f; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Ammo Crate")
	bool IsAvailable() const { return IsReady(); }

protected:
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;

	UFUNCTION()
	void OnOverlapBegin(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
		UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

	UFUNCTION()
	void OnOverlapEnd(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
		UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);

private:
	bool bPlayerInRange = false;
	float CooldownTimer = 0.0f;
	TWeakObjectPtr<APawn> CachedPlayerPawn;
};

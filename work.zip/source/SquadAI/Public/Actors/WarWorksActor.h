#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "WarWorksActor.generated.h"

UENUM(BlueprintType)
enum class EWarWorkPreset : uint8
{
	EnemyBridge   UMETA(DisplayName = "Enemy Bridge"),
	FriendlyBridge UMETA(DisplayName = "Friendly Bridge"),
	WatchTower    UMETA(DisplayName = "Watch Tower"),
	TankHull      UMETA(DisplayName = "Tank Hull"),
	DeadHull      UMETA(DisplayName = "Dead Hull")
};

/**
 * AWarWorksActor - S25-WARWORKS
 *
 * One actor, five kinds of war geography: the enemy's bridge over the water
 * and ours, their watchtower on a net hill, an armor hull at the tank
 * country's rim, and the burnt-out hulk of the last push. Everything is built
 * from the ASSET CACHE's basic meshes (cube / cylinder) with shared dynamic
 * materials the module creates itself - no content dependencies, a blank
 * project still gets a real bridge: pylons, deck planks, ramps; a real tower:
 * legs, platform, open-front cab; a real tank: tracks, hull, turret, barrel.
 *
 * The auto-setup manager places these at terrain-derived points (see
 * Quest/WarWorksModel.h - the rules, pinned offline by tools/map_test).
 */
UCLASS(BlueprintType)
class AWarWorksActor : public AActor
{
	GENERATED_BODY()

public:
	AWarWorksActor();

	/** What to build. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "War Works")
	EWarWorkPreset Preset = EWarWorkPreset::WatchTower;

	/** Bridges: the channel width the deck must span (cm). */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "War Works", meta = (ClampMin = "400"))
	float SpanCm = 4000.f;

	/** Snap pieces to the ground with traces (safe on any slope). */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "War Works")
	bool bGroundSnap = true;

	virtual void OnConstruction(const FTransform& Transform) override;

	/** Builds the pieces. Clears anything built before. */
	void BuildWarWork();

private:
	UPROPERTY(Transient)
	TArray<TObjectPtr<UStaticMeshComponent>> Pieces;
};

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "FirstAidKitActor.generated.h"

class UStaticMeshComponent;
class USphereComponent;
class USoundBase;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnFirstAidCollected, APawn*, CollectorPawn);

/**
 * AFirstAidKitActor
 * Tactical Field First Aid Kit found on the battlefield (in trenches, bunkers, camps, or dropped by fallen units).
 * 
 * Features:
 * 1. Proximity detection: Displays floating 3D prompt [E] First Aid Kit when player is near.
 * 2. Interaction: Pressing 'E' (or walking over if configured) applies first aid and restores health back to 100%.
 * 3. Bandaging/treatment audio feedback.
 * 4. Can be single-use (consumed on pickup) or respawnable after a configurable timer.
 */
UCLASS(BlueprintType, Blueprintable, meta = (DisplayName = "Tactical First Aid Kit"))
class SQUADAI_API AFirstAidKitActor : public AActor
{
	GENERATED_BODY()

public:
	AFirstAidKitActor();

	// =========================================================================
	//  COMPONENTS & VISUALS
	// =========================================================================

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<USceneComponent> SceneRoot;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UStaticMeshComponent> KitMesh;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<USphereComponent> InteractionSphere;

	// =========================================================================
	//  CONFIG
	// =========================================================================

	/** Amount of health restored (<= 0 means full 100% heal) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "First Aid Kit")
	float HealAmount = -1.0f;

	/** Interaction radius in cm (default 180cm = 1.8m) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "First Aid Kit", meta = (ClampMin = "50"))
	float InteractionRadius = 180.f;

	/** If true, walking over the kit picks it up automatically without needing 'E' key press */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "First Aid Kit")
	bool bAutoPickupOnOverlap = false;

	/** If true, the kit respawns after RespawnDelaySeconds instead of being destroyed */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "First Aid Kit")
	bool bRespawnable = false;

	/** Delay in seconds before respawning (if bRespawnable is true) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "First Aid Kit", meta = (EditCondition = "bRespawnable", ClampMin = "1.0"))
	float RespawnDelaySeconds = 30.0f;

	/** First aid / bandage audio sound */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "First Aid Kit|Audio")
	TObjectPtr<USoundBase> HealSound;

	/** Floating prompt text */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "First Aid Kit|UI")
	FString PromptText = TEXT("[E] بسته امدادی");

	/** Custom mesh override for first aid kit */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "First Aid Kit|Visuals")
	TObjectPtr<UStaticMesh> CustomKitMesh;

	/** Custom material override for first aid kit */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "First Aid Kit|Visuals")
	TObjectPtr<UMaterialInterface> KitMaterialOverride;

	UPROPERTY(BlueprintAssignable, Category = "First Aid Kit|Events")
	FOnFirstAidCollected OnFirstAidCollected;

	// =========================================================================
	//  API
	// =========================================================================

	UFUNCTION(BlueprintCallable, Category = "First Aid Kit")
	void ApplyCustomVisuals();

	UFUNCTION(BlueprintCallable, Category = "First Aid Kit")
	bool ConsumeKit(APawn* PlayerPawn);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "First Aid Kit")
	bool IsPlayerInRange() const { return bPlayerInRange; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "First Aid Kit")
	bool IsAvailable() const { return bIsAvailable; }

protected:
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;

	UFUNCTION()
	void OnOverlapBegin(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
		UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

	UFUNCTION()
	void OnOverlapEnd(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
		UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);

	void RespawnKit();

private:
	bool bPlayerInRange = false;
	bool bIsAvailable = true;
	FTimerHandle RespawnTimerHandle;
	TWeakObjectPtr<APawn> CachedPlayerPawn;
};

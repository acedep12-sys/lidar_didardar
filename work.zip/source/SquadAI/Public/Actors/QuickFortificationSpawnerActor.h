#pragma once

#include "CoreMinimal.h"
#include "Math/RandomStream.h"
#include "GameFramework/Actor.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h"
#include "QuickFortificationSpawnerActor.generated.h"

class UMaterialInterface;
class UStaticMesh;
class AMountedTurretActor;
class AAmmoCrateActor;
class AFirstAidKitActor;
class ASoldierCharacter;

UENUM(BlueprintType)
enum class EFortificationPreset : uint8
{
	SandbagBunker		UMETA(DisplayName = "Sandbag Bunker with Heavy MG"),
	TrenchLine			UMETA(DisplayName = "Trench Barricade & Supply Cache"),
	SniperNest			UMETA(DisplayName = "Elevated Sniper Observation Post"),
	RoadblockCheckpoint	UMETA(DisplayName = "Military Roadblock Checkpoint")
};

/**
 * AQuickFortificationSpawnerActor
 * One-Click Tactical Outpost & Defensive Fortification Builder.
 * 
 * Drop into any level to instantly construct fortified sandbag emplacements,
 * complete with mounted heavy machine guns, ammo crates, first aid kits, and optional guards.
 * Supports HISM instanced rendering.
 */
UCLASS(BlueprintType, Blueprintable, meta = (DisplayName = "Quick Fortification Builder"))
class SQUADAI_API AQuickFortificationSpawnerActor : public AActor
{
	GENERATED_BODY()

public:
	AQuickFortificationSpawnerActor();

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<USceneComponent> SceneRoot;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "HISM Components")
	TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_Sandbags;

	// =========================================================================
	//  FORTIFICATION CONFIG
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fortification")
	EFortificationPreset FortificationPreset = EFortificationPreset::SandbagBunker;

	/** If true, uses Hierarchical Instanced Static Meshes (HISM) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Performance")
	bool bUseHISMInstancing = true;

	/** If true, automatically spawns a heavy caliber sandbag-mounted machine gun */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fortification")
	bool bSpawnHeavyMG = true;

	/** If true, automatically spawns a resupply ammo crate */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fortification")
	bool bSpawnAmmoCrate = true;

	/** If true, automatically spawns a tactical first aid kit */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fortification")
	bool bSpawnFirstAidKit = true;

	/** Number of static sandbag barricade walls to arrange */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fortification", meta = (ClampMin = "1", ClampMax = "8"))
	int32 SandbagCount = 3;

	/** Optional custom static mesh for sandbags */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fortification")
	TObjectPtr<UStaticMesh> CustomSandbagMesh;

	/** Optional material override for sandbags */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fortification")
	TObjectPtr<UMaterialInterface> SandbagMaterialOverride;

	// =========================================================================
	//  S6-Q VARIATION (seeded; OFF reproduces the original straight line)
	// =========================================================================

	/** Seed driving all fortification variation */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fortification Variation")
	int32 FortSeed = 909;

	/** Master toggle for seeded variation */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fortification Variation")
	bool bSeededVariation = true;

	/** If true, the bag line bows into a defensive crescent (middle ahead of the flanks, each bag angled to the arc) instead of a straight rank */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fortification Variation")
	bool bArcFormation = true;

	/** If true, ~40% of centre bags gain a staggered second firing-tier above them */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fortification Variation")
	bool bDoubleTier = true;

	/** If true, adds short flank-return bags bending backward at both ends (real MG nests protect their sides) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fortification Variation")
	bool bFlankReturns = true;

	/** Sandbag material tone jitter via one runtime DMI (silent on colour-param-less materials) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fortification Variation", meta = (ClampMin = "0.0", ClampMax = "0.15"))
	float ToneJitter = 0.05f;

	// =========================================================================
	//  API
	// =========================================================================

	UFUNCTION(BlueprintCallable, Category = "Fortification")
	void BuildFortification();

	UFUNCTION(BlueprintCallable, Category = "Fortification")
	void ClearFortification();

protected:
	virtual void BeginPlay() override;

private:
	UPROPERTY()
	TArray<TObjectPtr<AActor>> SpawnedElements;

	// S6-Q: variation state (re-seeded every BuildFortification)
	FRandomStream FortStream;
	float CurrentToneOffset = 0.f;

	// S6-Q: shared per-piece ground trace
	bool FortGroundSnap(UWorld* World, FVector& InOutLoc) const;
};

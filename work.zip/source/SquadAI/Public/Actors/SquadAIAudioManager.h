#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "SquadAIAudioManager.generated.h"

class USoundBase;
class USoundAttenuation;
class UAudioComponent;
class UCameraShakeBase;

/**
 * ASquadAIAudioManager
 * Visual In-Editor GUI & Centralized Audio Manager for the Open World FPS.
 * Tailored for Khuzestan Tactical War Theater (Southern Iran desert/trenches/berms).
 * 
 * Features:
 * - Zero-Asset Fallbacks: If SoundAttenuation or CameraShake are left empty, C++ creates realistic procedural defaults automatically!
 * - Khuzestan Battlefield Ambience: Dynamic desert wind, distant horizon artillery rumbles, low-health heartbeat & tinnitus.
 * - Dynamic Music Stages: Configure Music X (early defend) and Music Y (final countdown climax).
 * - Dynamic Horde Scaling: Heavy war drums stem layer fades in dynamically as enemy horde size grows.
 * - Ambient & Combat Playlists: Multi-track rotation to prevent audio repetition in massive 8 km open world.
 * - Contextual Squad Voicelines & Combat Banter: Dynamic tactical barks inspired by FEAR, Battlefield 1, and Insurgency.
 */
UCLASS(BlueprintType, Blueprintable, meta = (DisplayName = "Squad AI Audio & Music Manager"))
class SQUADAI_API ASquadAIAudioManager : public AActor
{
	GENERATED_BODY()

public:
	ASquadAIAudioManager();

	// =========================================================================
	//  1. 🎵 BACKGROUND MUSIC & PLAYLISTS (Drag & Drop)
	// =========================================================================

	/** Primary exploration / peaceful desert background music */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "1. Background Music & Playlists")
	TObjectPtr<USoundBase> AmbientMusic;

	/** Optional playlist of ambient tracks rotated during long exploration */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "1. Background Music & Playlists")
	TArray<TObjectPtr<USoundBase>> AmbientMusicPlaylist;

	/** Primary combat / firefight music */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "1. Background Music & Playlists")
	TObjectPtr<USoundBase> CombatMusic;

	/** Optional playlist of battle tracks rotated across encounters */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "1. Background Music & Playlists")
	TArray<TObjectPtr<USoundBase>> CombatMusicPlaylist;

	/** Victory / mission completed stinger cue */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "1. Background Music & Playlists")
	TObjectPtr<USoundBase> VictoryStingerSound;

	/** Defeat / mission failed stinger cue */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "1. Background Music & Playlists")
	TObjectPtr<USoundBase> DefeatStingerSound;

	/** Time in seconds to smoothly crossfade between music tracks */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "1. Background Music & Playlists", meta = (ClampMin = "0.5", ClampMax = "10.0"))
	float MusicCrossfadeDuration = 2.5f;

	/** Master music volume multiplier (0.0 to 1.0) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "1. Background Music & Playlists", meta = (ClampMin = "0.0", ClampMax = "1.0"))
	float MusicMasterVolume = 0.85f;


	// =========================================================================
	//  2. 🛡️ DEFEND MISSION STAGES (Music X vs Music Y) & HORDE STEM
	// =========================================================================

	/** Music X: Played during the first half / early waves of a Defend mission */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "2. Defend Stages & Horde Scaling")
	TObjectPtr<USoundBase> DefendIntroMusic;

	/** Music Y: Played in the final countdown / intense climax of a Defend mission */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "2. Defend Stages & Horde Scaling")
	TObjectPtr<USoundBase> DefendClimaxMusic;

	/** Time remaining (in seconds) in a Defend mission to trigger Music Y (Climax) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "2. Defend Stages & Horde Scaling", meta = (ClampMin = "5.0", ClampMax = "60.0"))
	float DefendClimaxThresholdSeconds = 20.f;

	/** Dynamic Horde Combat Stem (heavy war drums / percussion) that fades in as horde size grows */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "2. Defend Stages & Horde Scaling")
	TObjectPtr<USoundBase> HordeCombatStem;

	/** Number of active nearby enemies required to trigger full horde music intensity and war drums */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "2. Defend Stages & Horde Scaling", meta = (ClampMin = "3", ClampMax = "30"))
	int32 HordeEnemyThreshold = 7;


	// =========================================================================
	//  3. 🏜️ KHUZESTAN WAR THEATER ATMOSPHERE & IMMERSION
	// =========================================================================

	/** Enable realistic battlefield ambience (desert wind, distant artillery rumbles, low-health heartbeat) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "3. Khuzestan War Atmosphere")
	bool bEnableKhuzestanAtmosphere = true;

	/** Looping arid desert wind sound (whistling softly through trenches and berms) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "3. Khuzestan War Atmosphere")
	TObjectPtr<USoundBase> DesertWindAmbience;

	/** Distant artillery rumble (plays occasionally on the distant horizon to make the 8km world feel alive) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "3. Khuzestan War Atmosphere")
	TObjectPtr<USoundBase> DistantArtilleryRumble;

	/** Tactical military radio squelch / click when missions start or update */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "3. Khuzestan War Atmosphere")
	TObjectPtr<USoundBase> TacticalRadioClick;

	/** Tense heartbeat loop played when player health is critically low (< 30%) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "3. Khuzestan War Atmosphere")
	TObjectPtr<USoundBase> LowHealthHeartbeat;

	/** High-pitched ear ringing (tinnitus) played after taking massive explosive concussion */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "3. Khuzestan War Atmosphere")
	TObjectPtr<USoundBase> ConcussionTinnitusSound;


	// =========================================================================
	//  4. 💥 EXPLOSIONS & ARTILLERY SFX (Drag & Drop)
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "4. Explosions & Artillery SFX")
	TObjectPtr<USoundBase> SmallExplosionCloseSound;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "4. Explosions & Artillery SFX")
	TObjectPtr<USoundBase> SmallExplosionDistantSound;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "4. Explosions & Artillery SFX")
	TObjectPtr<USoundBase> MediumExplosionCloseSound;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "4. Explosions & Artillery SFX")
	TObjectPtr<USoundBase> MediumExplosionDistantSound;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "4. Explosions & Artillery SFX")
	TObjectPtr<USoundBase> LargeExplosionCloseSound;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "4. Explosions & Artillery SFX")
	TObjectPtr<USoundBase> LargeExplosionDistantSound;

	/** Camera shake triggered near explosions (Leave empty for automatic built-in procedural camera shake!) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "4. Explosions & Artillery SFX")
	TSubclassOf<UCameraShakeBase> ExplosionCameraShake;

	/** Optional Unreal SoundAttenuation asset (Leave empty for automatic built-in 3D spatial attenuation!) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "4. Explosions & Artillery SFX")
	TObjectPtr<USoundAttenuation> ExplosionAttenuationSettings;


	// =========================================================================
	//  5. 🔫 GUNSHOTS, TAILS & WHIZ-BYS (Drag & Drop)
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "5. Gunshots & Weapon SFX")
	TObjectPtr<USoundBase> DefaultGunshotCloseSound;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "5. Gunshots & Weapon SFX")
	TObjectPtr<USoundBase> DefaultGunshotDistantSound;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "5. Gunshots & Weapon SFX")
	TObjectPtr<USoundBase> DefaultGunshotTailSound;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "5. Gunshots & Weapon SFX")
	TObjectPtr<USoundBase> BulletWhizBySound;

	/** Optional Unreal SoundAttenuation asset for weapons (Leave empty for automatic built-in attenuation!) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "5. Gunshots & Weapon SFX")
	TObjectPtr<USoundAttenuation> GunshotAttenuationSettings;


	// =========================================================================
	//  6. 🎙️ HEROIC SQUAD VOICELINES & TACTICAL CALLOUTS (War Hero Demeanor)
	// =========================================================================

	/** Ally spotting enemy callouts ("Enemy sighted!", "Hostiles at 12 o'clock, engage!") */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "6. Heroic Voicelines & Callouts")
	TArray<TObjectPtr<USoundBase>> AllyEnemySpottedVoicelines;

	/** Ally resolute combat callouts under fire ("Stay firm, return fire!", "Hold the line!") */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "6. Heroic Voicelines & Callouts")
	TArray<TObjectPtr<USoundBase>> AllyUnderFireVoicelines;

	/** Ally reloading cover coordination ("Cover me, changing mag!", "Reloading, keep pressure!") */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "6. Heroic Voicelines & Callouts")
	TArray<TObjectPtr<USoundBase>> AllyReloadingVoicelines;

	/** Ally explosive warning callouts ("Incoming mortar, take cover!", "Grenade, clear out!") */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "6. Heroic Voicelines & Callouts")
	TArray<TObjectPtr<USoundBase>> AllyIncomingGrenadeVoicelines;

	/** Resolute casualty report ("Soldier down! Cover the position!") */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "6. Heroic Voicelines & Callouts")
	TArray<TObjectPtr<USoundBase>> AllyManDownVoicelines;

	/** Field dressing / medic callout ("Medic! Patch him up!") — MEGA-5 (G-11). Falls back silently when empty. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "6. Heroic Voicelines & Callouts")
	TArray<TObjectPtr<USoundBase>> AllyHealingVoicelines;

	/** Heroic kill confirmation callouts ("Target neutralized!", "Threat eliminated!") */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "6. Heroic Voicelines & Callouts")
	TArray<TObjectPtr<USoundBase>> AllyKillConfirmedVoicelines;

	/** Ally tactical maneuvering ("Flanking right to pinch them!", "Moving into firing position!") */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "6. Heroic Voicelines & Callouts")
	TArray<TObjectPtr<USoundBase>> AllyFlankingVoicelines;

	/** Supreme Heroic Leader advance command ("Squad, advance!", "For the motherland, forward!") */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "6. Heroic Voicelines & Callouts")
	TArray<TObjectPtr<USoundBase>> LeaderOrderMoveVoicelines;

	/** Hold-position command bark ("Hold this line!", "Nobody moves!") — empty = falls back to LeaderOrderMove (F-C1) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "6. Heroic Voicelines & Callouts")
	TArray<TObjectPtr<USoundBase>> CommandHoldVoicelines;

	/** Supreme Heroic Leader fire command ("Open fire!", "Unleash hell on their line!") */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "6. Heroic Voicelines & Callouts")
	TArray<TObjectPtr<USoundBase>> LeaderOrderEngageVoicelines;

	/** Enemy alerted shouting in 3D space */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "6. Heroic Voicelines & Callouts")
	TArray<TObjectPtr<USoundBase>> EnemyAlertedVoicelines;

	/** Enemy combat taunts heard nearby */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "6. Heroic Voicelines & Callouts")
	TArray<TObjectPtr<USoundBase>> EnemyCombatBarks;

	/** Spent brass shell casing drop sound */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "6. Heroic Voicelines & Callouts")
	TObjectPtr<USoundBase> SpentShellCasingSound;


	// =========================================================================
	//  7. 🎛️ REALISM & PERFORMANCE TUNING (Open World 8km)
	// =========================================================================

	/** Enable realistic speed-of-sound air delay (343 m/s) across distant landmarks */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "7. Realism & Performance")
	bool bSimulateSpeedOfSound = true;

	/** Speed of sound in air (cm/s, default 34300 cm/s = 343 m/s) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "7. Realism & Performance", meta = (ClampMin = "10000.0"))
	float SpeedOfSoundVelocity = 34300.f;

	/** Distance threshold (cm) where sound transitions from close punch to distant echo (2500 cm = 25m) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "7. Realism & Performance", meta = (ClampMin = "500.0", ClampMax = "10000.0"))
	float CloseDistanceThreshold = 2500.f;

	/** Maximum audible distance (cm). Sounds beyond this are instantly culled to save CPU voices */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "7. Realism & Performance", meta = (ClampMin = "5000.0", ClampMax = "100000.0"))
	float MaxAudibleDistance = 40000.f;

	/** Max concurrent gunshot sounds per frame window (prevents hardware audio voice starvation in 50-AI battles) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "7. Realism & Performance", meta = (ClampMin = "2", ClampMax = "16"))
	int32 MaxConcurrentGunshots = 6;

	/** Max concurrent explosion sounds allowed at once */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "7. Realism & Performance", meta = (ClampMin = "1", ClampMax = "8"))
	int32 MaxConcurrentExplosions = 3;


	// =========================================================================
	//  8. 🎮 EDITOR PREVIEW & TEST ACTIONS (Clickable in Details Panel)
	// =========================================================================

	UFUNCTION(CallInEditor, BlueprintCallable, Category = "8. Editor Audio Preview")
	void TestPlayAmbientMusic();

	UFUNCTION(CallInEditor, BlueprintCallable, Category = "8. Editor Audio Preview")
	void TestPlayCombatMusic();

	UFUNCTION(CallInEditor, BlueprintCallable, Category = "8. Editor Audio Preview")
	void TestPlayDefendIntroMusic();

	UFUNCTION(CallInEditor, BlueprintCallable, Category = "8. Editor Audio Preview")
	void TestPlayDefendClimaxMusic();

	UFUNCTION(CallInEditor, BlueprintCallable, Category = "8. Editor Audio Preview")
	void TestPlayHordeStem();

	UFUNCTION(CallInEditor, BlueprintCallable, Category = "8. Editor Audio Preview")
	void TestPlayDesertWindAmbience();

	UFUNCTION(CallInEditor, BlueprintCallable, Category = "8. Editor Audio Preview")
	void TestPlayDistantArtilleryRumble();

	UFUNCTION(CallInEditor, BlueprintCallable, Category = "8. Editor Audio Preview")
	void TestPlayVictoryStinger();

	UFUNCTION(CallInEditor, BlueprintCallable, Category = "8. Editor Audio Preview")
	void TestPlayCloseExplosion();

	UFUNCTION(CallInEditor, BlueprintCallable, Category = "8. Editor Audio Preview")
	void TestPlayDistantExplosion();

	UFUNCTION(CallInEditor, BlueprintCallable, Category = "8. Editor Audio Preview")
	void TestPlayBulletWhizBy();

	UFUNCTION(CallInEditor, BlueprintCallable, Category = "8. Editor Audio Preview")
	void StopAllPreviewAudio();

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

#if WITH_EDITOR
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
#endif

private:
	UPROPERTY()
	TObjectPtr<UAudioComponent> EditorPreviewAudioComp;

	UPROPERTY()
	TObjectPtr<UAudioComponent> EditorPreviewStemComp;

	void SyncSettingsToSubsystem();
	void PlayEditorPreview(USoundBase* Sound, float Volume = 1.0f);
};

// EnemyPatrolRoute.h - S19-PATROL: the authored patrol route (point 1 -> 2 -> 3 -> ...).
//
// This actor is the AUTHORING surface: drop it in the level, press **Add Point** in the
// Details panel as many times as you want, and drag each point's handle to where the enemy
// should walk. The patrolling enemies hold a reference to a route and walk its points; the
// rules for that walk (the loop, the pauses, the short-range detection) live in
// Tactical/PatrolRouteModel.h, which is unit-tested offline.
//
// Points are stored RELATIVE to this actor (the array uses MakeEditWidget, which is what
// draws the draggable handles). Moving the route actor therefore moves the whole patrol,
// exactly like a spline. GetPointLocation() returns the world location.
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "EnemyPatrolRoute.generated.h"

class USceneComponent;
class USplineComponent;
class UBillboardComponent;

/** One stop on the route. */
USTRUCT(BlueprintType)
struct FEnemyPatrolPoint
{
	GENERATED_BODY()

	/** Where to walk, relative to the route actor. Drag the handle in the viewport. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Patrol",
		meta = (MakeEditWidget = "true"))
	FVector Location = FVector::ZeroVector;

	/** How long to pause here. -1 (default) means "use the route's default pause". */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Patrol", meta = (ClampMin = "-1.0"))
	float WaitSeconds = -1.f;

	/** Free text for the level designer - appears in the route's log line. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Patrol")
	FString Label;
};

/**
 * S19-PATROL: a patrol route. AEnemyPatroller walks these points.
 *
 * Editor flow:
 *   1. Place one of these where the patrol should start.
 *   2. Details panel -> Patrol -> press **"+ Add Patrol Point"**.
 *   3. Drag the new point's handle where you want it (it appears 4 m along from the last one,
 *      so you can also just press Add three times and drag all three).
 *   4. Repeat. The loop is drawn between the points as you go.
 *   5. Place / spawn a patrolling enemy within 60 m and it binds to this route automatically,
 *      or point its Patrol Route field at this actor explicitly.
 */
UCLASS(BlueprintType, Blueprintable, ClassGroup = (SquadAI))
class SQUADAI_API AEnemyPatrolRoute : public AActor
{
	GENERATED_BODY()

public:
	AEnemyPatrolRoute();

	/** The points, in the order they are walked. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Patrol")
	TArray<FEnemyPatrolPoint> Points;

	// ===== S19-PATROL: the editing buttons =====

	/** Adds a new point. It appears 4 m along from the last one (or 4 m in front of the route
	 *  actor when the route is empty) - press it, then drag the handle into place. */
	UFUNCTION(CallInEditor, BlueprintCallable, Category = "Patrol|Editing")
	void AddPoint();

	/** Adds a point exactly at a world location (for Blueprint or scripted route building). */
	UFUNCTION(BlueprintCallable, Category = "Patrol|Editing")
	void AddPointAt(const FVector& WorldLocation);

	/** Duplicates the last point, so a route can be extended by dragging rather than adding. */
	UFUNCTION(CallInEditor, BlueprintCallable, Category = "Patrol|Editing")
	void DuplicateLastPoint();

	/** Removes the last point (the undo-friendly way to fix a misclick). */
	UFUNCTION(CallInEditor, BlueprintCallable, Category = "Patrol|Editing")
	void RemoveLastPoint();

	UFUNCTION(BlueprintCallable, Category = "Patrol|Editing")
	void RemovePoint(int32 Index);

	/** Wipes the route. The patrollers walking it will stop and report having no route. */
	UFUNCTION(CallInEditor, BlueprintCallable, Category = "Patrol|Editing")
	void ClearPoints();

	// ===== queries (used by the patrollers and the editor visual) =====

	UFUNCTION(BlueprintPure, Category = "Patrol")
	int32 GetPointCount() const { return Points.Num(); }

	/** World location of a point (the array stores them relative to this actor). */
	UFUNCTION(BlueprintPure, Category = "Patrol")
	FVector GetPointLocation(int32 Index) const;

	/** Index of the point closest to a world location - how a placed patroller picks which
	 *  point of the route to walk to first. */
	UFUNCTION(BlueprintPure, Category = "Patrol")
	int32 FindNearestPointIndex(const FVector& WorldLocation) const;

	/** Distance (2D) from a world location to the route line, for the patroller's leash. */
	float DistanceToRoute2D(const FVector& WorldLocation) const;

	/** Distance (3D) from a world location to the route line. Used to decide whether a route may
	 *  be auto-bound: the enemy pool parks pawns 100 m below the world, and a 2D test would let
	 *  such a pawn bind to whatever route passes over the parking spot. */
	float DistanceToRoute3D(const FVector& WorldLocation) const;

	/** Does the route loop back to point 1 after the last point? (PingPong and Once modes
	 *  override this per-pawn; the flag is what the editor visual and the default use.) */
	UFUNCTION(BlueprintPure, Category = "Patrol")
	bool IsClosedLoop() const { return bClosedLoop; }

	/** Sum of the leg lengths, 2D. Handy for sizing a patrol beat. */
	UFUNCTION(BlueprintPure, Category = "Patrol")
	float GetRouteLength2D() const;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Patrol")
	bool bClosedLoop = true;

	/** Pause at each point unless the point overrides it. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Patrol", meta = (ClampMin = "0.0"))
	float DefaultPointWaitSeconds = 2.f;

	/** Optional name for logs and HUD lines. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Patrol")
	FString RouteName;

	/** Keeps the editor visual (the curve between the points) in step with the array.
	 *  Also runs on level load, where it is a no-op for gameplay. */
	virtual void OnConstruction(const FTransform& Transform) override;

#if WITH_EDITOR
	/** Live readout in the Details panel's log: how many points, how long the beat is. */
	UFUNCTION(CallInEditor, BlueprintCallable, Category = "Patrol|Editing")
	void LogRouteDescription();
#endif

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Patrol|Components")
	TObjectPtr<USceneComponent> SceneRoot;

#if WITH_EDITORONLY_DATA
	/** Editor-only: shows the route curve in the viewport. The Points array is the authority;
	 *  this is drawn from it and never read back. */
	UPROPERTY(VisibleAnywhere, Category = "Patrol|Components")
	TObjectPtr<USplineComponent> EditorPathSpline;

	/** Editor-only: makes the route clickable in the viewport. */
	UPROPERTY(VisibleAnywhere, Category = "Patrol|Components")
	TObjectPtr<UBillboardComponent> EditorIcon;
#endif

private:
	void RebuildEditorPathVisual();

	/** Marks the actor (and therefore the level) modified so a route built with the buttons is
	 *  saved, and the Details panel rebuilds after the array changed. `Modify()` is
	 *  editor-only, so it compiles out of game builds - this helper is then a no-op. */
	void MarkRouteDirty();
};

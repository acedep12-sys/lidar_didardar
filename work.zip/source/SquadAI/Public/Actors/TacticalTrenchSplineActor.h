#pragma once

#include "CoreMinimal.h"
#include "Math/RandomStream.h"
#include "GameFramework/Actor.h"
#include "Components/SplineComponent.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h"
#include "TacticalTrenchSplineActor.generated.h"

class UMaterialInterface;
class UStaticMesh;
class AAmmoCrateActor;
class AFirstAidKitActor;
class AMountedTurretActor;

/**
 * ATacticalTrenchSplineActor
 * Procedural Spline-Based Trench & Sandbag Barricade Builder.
 * 
 * Simply draw a spline curve across the terrain in the editor. This actor automatically constructs:
 * 1. Sandbag bunker walls and barricades curved along the spline (batched via HISM for high performance).
 * 2. Automated low/high cover points along the trench line.
 * 3. Tactical supply caches (Ammo Crates & First Aid Kits) placed at regular intervals.
 * 4. Optional sandbag-mounted heavy machine guns at apex defensive positions.
 */
UCLASS(BlueprintType, Blueprintable, meta = (DisplayName = "Tactical Trench Spline Builder"))
class SQUADAI_API ATacticalTrenchSplineActor : public AActor
{
	GENERATED_BODY()

public:
	ATacticalTrenchSplineActor();

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<USceneComponent> SceneRoot;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<USplineComponent> TrenchSpline;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "HISM Components")
	TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_Sandbags;

	// =========================================================================
	//  CONFIG
	// =========================================================================

	/** If true, batches sandbag barricades into HISM instances for max performance */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Performance")
	bool bUseHISMInstancing = true;

	/** Distance in cm between sandbag barricade segments along the spline */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Builder", meta = (ClampMin = "100.0", ClampMax = "1000.0"))
	float SegmentSpacing = 200.0f;

	/** If true, places Ammo Crates and First Aid Kits along the trench */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Builder")
	bool bSpawnSupplyCaches = true;

	/** Interval in cm along spline for placing supply caches (e.g. every 15m = 1500cm) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Builder", meta = (EditCondition = "bSpawnSupplyCaches", ClampMin = "500.0"))
	float SupplyCacheInterval = 1500.0f;

	/** If true, spawns mounted heavy machine gun turrets at key apex points */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Builder")
	bool bSpawnMountedTurretsAtEnds = true;

	/** Optional custom static mesh for sandbags */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Visuals")
	TObjectPtr<UStaticMesh> CustomSandbagMesh;

	/** Optional material override for sandbags */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Visuals")
	TObjectPtr<UMaterialInterface> SandbagMaterialOverride;

	// =========================================================================
	//  S6-T TRENCH VARIATION (seeded; OFF reproduces the original uniform wall)
	// =========================================================================

	/** Seed driving all trench variation below */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Variation")
	int32 TrenchSeed = 404;

	/** Master toggle for seeded variation (position/angle/scale jitter per segment) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Variation")
	bool bSeededVariation = true;

	/** If true, ~40% of segments gain a staggered second firing-tier of sandbags (classic parapet build-up) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Variation")
	bool bDoubleLayerBags = true;

	/** If true, ~8% of mid-trench segments become sunken battle-breached partials (firing gaps) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Variation")
	bool bBattleGaps = true;

	/** If true, closes both trench mouths with short perpendicular closure bags */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Variation")
	bool bEndCaps = true;

	/** If true, ~15% of segments drop a half-buried debris bag beside the wall */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Variation")
	bool bBrokenBags = true;

	/** Sandbag material tone jitter (fractional, applied via one runtime DMI; silent on colour-param-less materials) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Variation", meta = (ClampMin = "0.0", ClampMax = "0.15"))
	float ToneJitter = 0.05f;

	// =========================================================================
	//  API
	// =========================================================================

	UFUNCTION(BlueprintCallable, CallInEditor, Category = "Trench Builder")
	void BuildTrench();

	UFUNCTION(BlueprintCallable, CallInEditor, Category = "Trench Builder")
	void ClearTrench();

protected:
	virtual void BeginPlay() override;

private:
	UPROPERTY()
	TArray<TObjectPtr<AActor>> SpawnedElements;

	// S6-T: variation state (re-seeded every BuildTrench)
	FRandomStream TrenchStream;
	float CurrentToneOffset = 0.f;
};

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "UObject/SoftObjectPath.h"   // S26-VIDEO: FFilePath picker for the menu/intro video (a CoreUObject USTRUCT in UE5 - the old UE4 Misc/FilePath.h is gone by 5.7)
#include "SquadAIAutoSetupManager.generated.h"

class ALeaderCharacter;
class AAllySoldier;
class AEnemySoldier;
class USquadAIPackValidationComponent;
class UBlueprint;

UCLASS(BlueprintType, Blueprintable)
class SQUADAI_API ASquadAIAutoSetupManager : public AActor
{
    GENERATED_BODY()

public:
    ASquadAIAutoSetupManager();

    virtual void BeginPlay() override;

#if WITH_EDITOR
    virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;
#endif

    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Auto Setup")
    bool RunEditorAutoSetup();

    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Auto Setup")
    bool RunEditorValidation();

    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Level Tools")
    FString AutoFixLevelAndMissions();

    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Level Tools")
    FString EnsureAtmosphereAndAudio();

    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Level Tools")
    FString AutoPopulateEncounters();

    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Level Tools")
    FString AutoBakeCoverNodes();

    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Level Tools")
    FString SpawnDestroyedVillage();

    /**
     * S26-DELBTN: delete every mesh the auto-scatter stamped on this map -
     * towers, bridges, outposts, guard posts and (optionally) the stamped
     * missions with all their props. Hand-placed content is never touched:
     * the teardown is tag-based, exactly what a re-press replaces.
     */
    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Level Tools")
    FString DeleteScatteredContent();

    /** S26-DELBTN: also remove the stamped mission zones and their props (the full re-scatter clean). */
    UPROPERTY(EditAnywhere, Category="SquadAI|Level Tools")
    bool bDeleteAlsoStampedMissions = true;

    // =========================================================================
    //  GLOBAL MATERIAL & MESH PALETTE (Centralized level skinner)
    // =========================================================================

    /** Global Wall Material applied to all village buildings, ruins, and stone barricades */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Global Palette|Materials")
    TObjectPtr<UMaterialInterface> GlobalWallMaterial;

    /** Global Floor & Roof Material applied to foundation slabs, floors, and ramps */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Global Palette|Materials")
    TObjectPtr<UMaterialInterface> GlobalFloorMaterial;

    /** Global Wood Material applied to roof beams, rafters, doors, and crate stacks */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Global Palette|Materials")
    TObjectPtr<UMaterialInterface> GlobalWoodMaterial;

    /** Global Sandbag Material applied to sandbag walls, parapets, and embrasures */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Global Palette|Materials")
    TObjectPtr<UMaterialInterface> GlobalSandbagMaterial;

    /** Global Metal Material applied to corrugated tin roofs, awnings, and turrets */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Global Palette|Materials")
    TObjectPtr<UMaterialInterface> GlobalMetalMaterial;

    /** Global Rubble Material applied to debris fields, broken bricks, and plaster */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Global Palette|Materials")
    TObjectPtr<UMaterialInterface> GlobalRubbleMaterial;

    /** Global Ammo Crate Material */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Global Palette|Materials")
    TObjectPtr<UMaterialInterface> GlobalAmmoCrateMaterial;

    /** Global First Aid Kit Material */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Global Palette|Materials")
    TObjectPtr<UMaterialInterface> GlobalFirstAidMaterial;

    /** Global Red Explosive Barrel Material */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Global Palette|Materials")
    TObjectPtr<UMaterialInterface> GlobalBarrelMaterial;

    // Custom Meshes
    /** Custom static mesh for walls */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Global Palette|Meshes")
    TObjectPtr<UStaticMesh> GlobalWallMesh;

    /** Custom static mesh for sandbag fortifications */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Global Palette|Meshes")
    TObjectPtr<UStaticMesh> GlobalSandbagMesh;

    /** Custom static mesh for wooden roof beams */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Global Palette|Meshes")
    TObjectPtr<UStaticMesh> GlobalWoodBeamMesh;

    /** Custom static mesh for rubble heaps */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Global Palette|Meshes")
    TObjectPtr<UStaticMesh> GlobalRubbleMesh;

    /** Custom static mesh for ammo crates */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Global Palette|Meshes")
    TObjectPtr<UStaticMesh> GlobalAmmoCrateMesh;

    /** Custom static mesh for first aid kits */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Global Palette|Meshes")
    TObjectPtr<UStaticMesh> GlobalFirstAidMesh;

    /** Custom static mesh for red fuel drums */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Global Palette|Meshes")
    TObjectPtr<UStaticMesh> GlobalBarrelMesh;

    /** Custom static mesh for mounted turret base */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Global Palette|Meshes")
    TObjectPtr<UStaticMesh> GlobalTurretBaseMesh;

    /** Custom static mesh for mounted turret machine gun */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Global Palette|Meshes")
    TObjectPtr<UStaticMesh> GlobalTurretGunMesh;

    // =========================================================================
    //  NIAGARA EXPLOSION FX CONFIGURATION (Defaults to /Game/NiagaraExamples/FX_Explosions)
    // =========================================================================

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Niagara Explosions")
    TObjectPtr<class UNiagaraSystem> DefaultDirtExplosion;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Niagara Explosions")
    TObjectPtr<class UNiagaraSystem> DefaultDirtExplosionMedium;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Niagara Explosions")
    TObjectPtr<class UNiagaraSystem> DefaultDirtExplosionSmall;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Niagara Explosions")
    TObjectPtr<class UNiagaraSystem> DefaultExplosion;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Niagara Explosions")
    TObjectPtr<class UNiagaraSystem> DefaultExplosionMedium;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Niagara Explosions")
    TObjectPtr<class UNiagaraSystem> DefaultExplosionSmall;

    /** 1-Click Action: Instantly propagates all configured materials and meshes to all buildings, props, and fortifications in the level */
    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Global Palette")
    FString ApplyGlobalPaletteToAllLevelAssets();

    // =========================================================================
    //  ASSET & GROUP SPAWN LOCATION MANAGER (3D Viewport Widgets)
    // =========================================================================

    /** Target spawn location offset for Destroyed Village (Drag 3D diamond widget in viewport!) */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Asset Manager|Locations", meta=(MakeEditWidget=true))
    FVector VillageSpawnLocation = FVector(2000.f, 0.f, 0.f);

    /** Target spawn location offset for Squad Leader (Drag 3D diamond widget in viewport!) */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Asset Manager|Locations", meta=(MakeEditWidget=true))
    FVector LeaderSpawnLocation = FVector(0.f, 0.f, 0.f);

    /** Target spawn location offsets for Allies / Followers (Drag 3D diamond widgets in viewport!) */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Asset Manager|Locations", meta=(MakeEditWidget=true))
    TArray<FVector> AlliesSpawnLocations;

    /** Target spawn location offsets for Mission Encounter Zones (Drag 3D diamond widgets in viewport!) */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Asset Manager|Locations", meta=(MakeEditWidget=true))
    TArray<FVector> EncounterSpawnLocations;

    /** Target spawn location offset for Logistics Cache (Ammo & First Aid) */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Asset Manager|Locations", meta=(MakeEditWidget=true))
    FVector LogisticsSpawnLocation = FVector(250.f, 0.f, 0.f);

    // =========================================================================
    //  ASSET MANAGER ACTIONS (Clickable in Details Panel)
    // =========================================================================

    /** Spawns or moves the Destroyed Village to the configured VillageSpawnLocation widget */
    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Asset Manager")
    FString MoveVillageToTargetLocation();

    /** Moves Squad Leader and Allies to their configured spawn locations */
    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Asset Manager")
    FString MoveSquadToTargetLocations();

    /** Moves Mission Zones and Combat Encounter Volumes to configured encounter locations */
    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Asset Manager")
    FString MoveEncountersToTargetLocations();

    /** Moves Logistics props (Ammo Crate, First Aid Kit, Mounted MG) to LogisticsSpawnLocation */
    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Asset Manager")
    FString MoveLogisticsToTargetLocation();

    /** 1-Click Action: Spawns and configures the Master Main Menu Setup Director actor in the level */
    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Main Menu")
    FString SpawnMainMenuDirectorActor();

    // S26-MENUSPLIT: the menu and its intro/background videos belong to the
    // MENU MAP - they live on the Main Menu Director actor only now. The
    // manager works the GAME map; it no longer carries video pickers.

    /** Snaps all spawned buildings, fortifications, and props firmly to the landscape */
    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Asset Manager")
    FString SnapAllSpawnedAssetsToGround();

#if WITH_EDITOR
    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Asset Factory")
    UBlueprint* CreateLeaderBlueprintAsset();

    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Asset Factory")
    UBlueprint* CreateAllyBlueprintAsset();

    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Asset Factory")
    UBlueprint* CreateEnemyBlueprintAsset();
#endif

    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Auto Setup")
    FString BuildSetupSummary();

    // =========================================================================
    //  S19-TEMPLATE: the mission factory (one asset = one mission)
    // =========================================================================
    /** Stamp the template below into the level: the zone, its wave spawner, the
     *  fortification and barrels, and every prop group the template asks for. */
    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Mission Factory")
    FString BuildMissionFromTemplate();

    /** S19-GEN: build a mission from (Generator Seed x Difficulty Tier) - the same
     *  seed and tier always build the SAME mission (share the seed, share the fight). */
    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Mission Factory")
    FString GenerateMissionFromSeed();

    // =========================================================================
    //  S19-MAP: the landscape checker and the automatic mission putter
    // =========================================================================
    /** Read the map's layout (crates = trenches, trees = biomes, the river line)
     *  and log + save SquadAIReports/LandscapeReport.md. */
    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Landscape")
    FString AnalyzeMapLayout();

    /** Read the map, pick the spots, and stamp a full mission on each one (or with
     *  Dry Run on: only report and draw the map). Writes MissionScatterReport.md and
     *  MissionScatterMap.svg - the map of the target scattering - into SquadAIReports. */
    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Landscape")
    FString AutoScatterMissions();

    UFUNCTION(BlueprintCallable, BlueprintPure, Category="SquadAI|Diagnostics")
    static bool AreVerboseDebugLogsEnabled();
    static void SetVerboseDebugLogsEnabled(bool bEnabled);

    UFUNCTION(BlueprintCallable, BlueprintPure, Category="SquadAI|Diagnostics")
    static bool ShouldLogAI();

    UFUNCTION(BlueprintCallable, BlueprintPure, Category="SquadAI|Diagnostics")
    static bool ShouldLogCombat();

    UFUNCTION(BlueprintCallable, BlueprintPure, Category="SquadAI|Diagnostics")
    static bool ShouldLogBridge();

    UFUNCTION(BlueprintCallable, BlueprintPure, Category="SquadAI|Diagnostics")
    static bool ShouldLogAudio();

    UFUNCTION(BlueprintCallable, BlueprintPure, Category="SquadAI|Diagnostics")
    static bool ShouldLogQuest();

    UFUNCTION(BlueprintCallable, BlueprintPure, Category="SquadAI|Diagnostics")
    static bool ShouldLogCover();

protected:
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Auto Setup")
    bool bRunInEditorOnly = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Auto Setup")
    bool bRunOnBeginPlay = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Auto Setup")
    bool bDisableAfterSuccessfulSetup = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Auto Setup")
    bool bValidateAfterSetup = true;

    // Master switch for diagnostic logs across SquadAI
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Diagnostics")
    bool bEnableVerboseDebugLogs = false;

    // Detailed Category Toggles
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Diagnostics")
    bool bLogAIEvents = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Diagnostics")
    bool bLogCombatEvents = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Diagnostics")
    bool bLogBridgeEvents = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Diagnostics")
    bool bLogAudioEvents = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Diagnostics")
    bool bLogQuestEvents = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Diagnostics")
    bool bLogCoverEvents = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Discovery")
    TObjectPtr<AActor> ExplicitLeader = nullptr;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Discovery")
    TArray<TObjectPtr<AActor>> ExplicitAllies;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Discovery")
    TArray<TObjectPtr<AActor>> ExplicitEnemies;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Discovery")
    bool bAutoFindLeaderIfMissing = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Discovery")
    bool bAutoFindAlliesIfArrayEmpty = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Discovery")
    bool bAutoFindEnemiesIfArrayEmpty = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Discovery")
    FName RequiredActorTag;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Asset Factory")
    FString AssetPackagePath = TEXT("/Game/_AutoGeneratedSquadAI");

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Asset Factory|Pack Template")
    bool bCreateBlueprintsFromPackTemplates = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Asset Factory|Pack Template")
    FString LeaderPackTemplateAssetName = TEXT("BP_AICharacter");

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Asset Factory|Pack Template")
    FString AllyPackTemplateAssetName = TEXT("BP_AICharacter");

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Asset Factory|Pack Template")
    FString EnemyPackTemplateAssetName = TEXT("BP_AICharacter");

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Asset Factory")
    FString LeaderAssetName = TEXT("BP_Leader_PackClean_Auto");

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Asset Factory")
    FString AllyAssetName = TEXT("BP_Ally_PackClean_Auto");

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Asset Factory")
    FString EnemyAssetName = TEXT("BP_Enemy_PackClean_Auto");

    // === WEAPON SELECTION ===
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Asset Factory|Weapons")
    FName LeaderWeaponID = TEXT("ak");

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Asset Factory|Weapons")
    FName AllyWeaponID = TEXT("ak");

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Asset Factory|Weapons")
    FName EnemyWeaponID = TEXT("ak");

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Editor Actions")
    bool bExecuteCreateLeaderBlueprint = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Editor Actions")
    bool bExecuteCreateAllyBlueprint = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Editor Actions")
    bool bExecuteCreateEnemyBlueprint = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Editor Actions")
    bool bExecuteRunEditorAutoSetup = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Editor Actions")
    bool bExecuteRunEditorValidation = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Editor Actions")
    bool bExecuteAutoFixLevelAndMissions = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Editor Actions")
    bool bExecuteEnsureAtmosphereAndAudio = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Editor Actions")
    bool bExecuteAutoPopulateEncounters = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Editor Actions")
    bool bExecuteAutoBakeCoverNodes = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Editor Actions")
    bool bExecuteSpawnDestroyedVillage = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Editor Actions")
    bool bExecuteApplyGlobalPalette = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Editor Actions")
    bool bExecuteBuildSetupSummary = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Editor Actions")
    bool bExecuteBuildMissionFromTemplate = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Editor Actions")
    bool bExecuteGenerateMissionFromSeed = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Editor Actions")
    bool bExecuteAnalyzeMapLayout = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Editor Actions")
    bool bExecuteAutoScatterMissions = false;

    // =========================================================================
    //  S19-TEMPLATE: mission factory settings
    // =========================================================================
    /** The mission template the build button stamps into the level. */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Mission Factory")
    TObjectPtr<class UMissionTemplateAsset> MissionTemplateToBuild;

    /** Build it in front of this actor (2 km along its forward axis) or at the exact
     *  location below. */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Mission Factory")
    bool bBuildMissionInFrontOfActor = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Mission Factory",
        meta=(EditCondition="!bBuildMissionInFrontOfActor"))
    FVector MissionBuildLocation = FVector::ZeroVector;

    /** How far in front of this actor a new mission is built (cm). */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Mission Factory",
        meta=(EditCondition="bBuildMissionInFrontOfActor", ClampMin="0.0"))
    float MissionBuildDistanceCm = 2000.f;

    /** S19-GEN: the seed for the generator. The same seed + tier = the same mission. */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Mission Factory")
    int32 GeneratorSeed = 1337;

    /** S19-GEN: how hard the generated mission is (1 = patrol-sized, 5 = siege). */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Mission Factory",
        meta=(ClampMin="1", ClampMax="5"))
    int32 GeneratorDifficultyTier = 3;

    // =========================================================================
    //  S19-MAP: landscape checker / mission scatterer settings
    // =========================================================================
    /** 0 = AUTO: the HQ, every trench, every biome and the river crossing, capped at
     *  16 - the whole open world becomes ONE campaign. 1..16 = exactly that many acts. */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Landscape",
        meta=(ClampMin="0", ClampMax="16"))
    int32 ScatterMissionCount = 0;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Landscape", meta=(ClampMin="5000.0"))
    float ScatterMinSeparationCm = 15000.f;

    /** S26-SPREAD: how wide the campaign front reaches from the HQ, in km.
     *  3 = a tight, readable front (acts a short march apart). 0 = the whole map. */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Landscape", meta=(ClampMin="0.0"))
    double ScatterCampaignSpreadKm = 3.0;

    /** On = analyse and draw the map WITHOUT stamping anything (start here). */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Landscape")
    bool bScatterDryRun = true;

    /** Actor-name tokens read as TRENCH markers (crates, trench splines). */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Landscape")
    TArray<FString> CrateTokens;

    /** Actor-name tokens read as TREE/BIOME markers (painted foliage IS read). */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Landscape")
    TArray<FString> TreeTokens;

    /** Actor-name tokens read as the RIVER (splines are followed when present). */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="SquadAI|Landscape")
    TArray<FString> RiverTokens;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="SquadAI|Editor Actions")
    FString LastSetupSummary;

    UPROPERTY(VisibleInstanceOnly, BlueprintReadOnly, Category="SquadAI|Auto Setup")
    bool bSetupAlreadyCompleted = false;

private:
    AActor* ResolveLeader() const;
    TArray<AActor*> ResolveAllies() const;
    TArray<AActor*> ResolveEnemies() const;
    void DisableManagerIfNeeded();
};

// FarsiTextHelper.h — Persian digit conversion, RTL utilities, cardinal directions
// Blueprint-callable function library. Zero-cost static functions.
#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "FarsiTextHelper.generated.h"

UCLASS()
class SQUADAI_API UFarsiTextHelper : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	// Convert ASCII digits 0-9 to Persian digits ۰-۹
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Farsi")
	static FString ToPersianDigits(const FString& Input);

	// Integer → Persian digit string
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Farsi")
	static FString IntToPersian(int32 Value);

	// Format seconds as Persian timer: ۲:۳۴
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Farsi")
	static FString FormatTimerPersian(float TotalSeconds);

	// "موج ۲ از ۵"
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Farsi")
	static FText FormatWavePersian(int32 Current, int32 Total);

	// "کشته: ۲۳"
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Farsi")
	static FText FormatKillsPersian(int32 Kills);

	// "باقی‌مانده: ۱۵"
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Farsi")
	static FText FormatRemainingPersian(int32 Remaining);

	// Persian cardinal: شمال / جنوب / شرق / غرب
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Farsi")
	static FString GetPersianCardinal(float YawDegrees);

	// Wrap text with RTL embedding marks (U+202B / U+202C)
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Farsi")
	static FString WrapRTL(const FString& Input);

	/** Context-aware Unicode Arabic/Persian Glyph Shaper (joins isolated letters into initial, medial, and final cursive forms) */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Farsi")
	static FString ShapeFarsi(const FString& Input);

	/** Reorders RTL shaped words for Canvas/LTR rendering so they display correctly from Right to Left */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Farsi")
	static FString ReorderBiDi(const FString& Input);

	/** Complete Persian Pipeline: Converts digits to Persian, shapes contextual glyphs, and reorders RTL runs for Canvas */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Farsi")
	static FString ShapeAndOrder(const FString& Input);

	/** Helper taking FText */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Farsi")
	static FString ShapeAndOrderText(const FText& Input) { return ShapeAndOrder(Input.ToString()); }
};

typedef UFarsiTextHelper FFarsiTextHelper;


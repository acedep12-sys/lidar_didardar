#pragma once

#include "CoreMinimal.h"
#include "GameFramework/HUD.h"
#include "GameFramework/SquadAIMapData.h"
#include "GameFramework/SquadAIWeaponData.h"
#include "GameFramework/SquadAIProgressionSubsystem.h"
#include "SaveSystem/SquadAISaveGame.h"
#include "HUD/SquadAIMainMenuWidget.h"
#include "SquadAIMainMenuHUD.generated.h"

class USquadAIMainMenuWidget;
class USoundBase;
class UTexture2D;
class UMaterialInterface;
class UMaterialInstanceDynamic; // S17-FOGFX
class UMediaPlayer;   // S16-VID
class UMediaTexture;  // S16-VID
class ASquadAIMainMenuSetupActor;
class UNiagaraSystem;

UENUM(BlueprintType)
enum class EMenuBackgroundType : uint8
{
	Cinematic3DCameraOrbit  UMETA(DisplayName = "3D Cinematic Camera Orbit"),
	AnimatedTextureMaterial UMETA(DisplayName = "Animated Video/Texture Material"),
	StaticImageKenBurns     UMETA(DisplayName = "Static Image with Cinematic Pan/Zoom")
};

UENUM(BlueprintType)
enum class EMenuColorTheme : uint8
{
	DesertKhakiGold    UMETA(DisplayName = "Rostami Field Slate (Default)"),
	TacticalForestGreen UMETA(DisplayName = "Tactical Woodland Green"),
	NightOpsBlue        UMETA(DisplayName = "Night Operations Cyan"),
	RedAlertCrimson     UMETA(DisplayName = "Red Alert Crimson")
};

USTRUCT(BlueprintType)
struct FSquadMenuParticle
{
	GENERATED_BODY()

	FVector2D Position = FVector2D::ZeroVector;
	FVector2D Velocity = FVector2D::ZeroVector;
	float Size = 2.0f;
	float Alpha = 1.0f;
	float LifeTime = 0.0f;
	float MaxLifeTime = 3.0f;
	FLinearColor Color = FLinearColor(1.0f, 0.85f, 0.4f, 1.0f);
};

USTRUCT(BlueprintType)
struct FSquadMenuTextConfig
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Localization")
	FText GameTitle = FText::FromString(TEXT("عملیات خوزستان | سرگرد شهید ایرج رستمی"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Localization")
	FText GameSubtitle = FText::FromString(TEXT("شوتر تاکتیکی جهان‌باز فرماندهی جوخه — دفاع مقدس (۱۳۵۹)"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Localization")
	FText ButtonNewGame = FText::FromString(TEXT("شروع بازی جدید"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Localization")
	FText ButtonMapSelect = FText::FromString(TEXT("انتخاب منطقه و نقشه عملیات"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Localization")
	FText ButtonArmory = FText::FromString(TEXT("زرادخانه و آزادسازی سلاح‌ها"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Localization")
	FText ButtonProgression = FText::FromString(TEXT("ارتقای توانمندی‌ها و سطح رزمنده"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Localization")
	FText ButtonPlayerProfile = FText::FromString(TEXT("پرونده و آمار نبردهای رزمنده"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Localization")
	FText ButtonAchievements = FText::FromString(TEXT("مدال‌ها و دستاوردهای جنگی"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Localization")
	FText ButtonContinue = FText::FromString(TEXT("ادامه عملیات"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Localization")
	FText ButtonLoadGame = FText::FromString(TEXT("بارگذاری ذخیره"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Localization")
	FText ButtonSettings = FText::FromString(TEXT("تنظیمات و گرافیک"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Localization")
	FText ButtonBriefing = FText::FromString(TEXT("پرونده اطلاعات عملیاتی"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Localization")
	FText ButtonQuit = FText::FromString(TEXT("خروج از بازی"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Localization")
	FText ButtonRelicCollection = FText::FromString(TEXT("یادگاری‌های همرزمان شهید"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Localization")
	FText ButtonBack = FText::FromString(TEXT("← بازگشت"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Localization")
	FText DifficultyTitle = FText::FromString(TEXT("انتخاب سطح دشواری نبرد"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Localization")
	FText DiffRecruit = FText::FromString(TEXT("سرباز تازه‌کار (آسان)"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Localization")
	FText DiffRegular = FText::FromString(TEXT("سرباز رزمنده (متوسط)"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Localization")
	FText DiffHardened = FText::FromString(TEXT("کهنه‌سرباز (دشوار)"));

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Localization")
	FText DiffVeteran = FText::FromString(TEXT("فرمانده افسانه‌ای (بسیار سنگین)"));
};

/**
 * ASquadAIMainMenuHUD
 * Comprehensive Main Menu HUD featuring procedural & textured Sacred Defense decorative frames,
 * animated Khuzestan desert sand particle motes, crimson flame sweeps, interactive Map Selection,
 * Player Profiles & Lifetime Stats, and Armory with weapon attribute bars & speciality trait badges.
 */
UCLASS(BlueprintType, Blueprintable)
class SQUADAI_API ASquadAIMainMenuHUD : public AHUD
{
	GENERATED_BODY()

public:
	ASquadAIMainMenuHUD();

	virtual void DrawHUD() override;
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	// P1-L2: re-skin on central language change.
	void OnLanguageChanged(const FString& NewLang);
	FDelegateHandle LanguageChangedHandle;

	// =========================================================================
	//  TEXT CUSTOMIZATION & LOCALIZATION
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Custom Text & Localization")
	FSquadMenuTextConfig MenuTextConfig;

	// =========================================================================
	//  BACKGROUND & TEXTURES
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Background")
	EMenuBackgroundType BackgroundType = EMenuBackgroundType::StaticImageKenBurns;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Background")
	TObjectPtr<UTexture2D> BackgroundTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Background")
	TObjectPtr<UMaterialInterface> BackgroundMaterial;

	/** S16-FLAG2: waving-flag menu background. Auto-resolved from
	 *  /Game/SquadAI/MenuFlagWave/M_MenuFlagWave (built by SquadAI_ImportMenuFlagWave.py,
	 *  same approved clean key art — no baked grid, so AAA-MW-27 does not apply).
	 *  When present it replaces the static texture draw, using the SAME
	 *  aspect-correct Ken-Burns crop/pan. Static texture remains the fallback
	 *  and is used when bReducedMenuMotion is on. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Background")
	TObjectPtr<UMaterialInterface> FlagWaveBackgroundMaterial;

	/** S16-VID: looping video background, created at runtime from
	 *  Content/Movies/MenuBackground.mp4 (drop the file there — nothing else).
	 *  Highest draw priority once frames arrive; static image until then and
	 *  whenever the file is absent. Toggle: SquadAI.MenuVideo (default 1). */
	UPROPERTY(Transient)
	TObjectPtr<UMediaPlayer> BackgroundVideoPlayer;

	UPROPERTY(Transient)
	TObjectPtr<UMediaTexture> BackgroundVideoTexture;

	// S19-PIEMEDIADEFER: open the background sequence only after the intro/fog wipe.
	bool bBackgroundVideoInitPending = false;

	/** S17-VIDLOOP: seamless loop. A second, pre-opened player takes over the
	 *  instant the first one reaches its end, so the loop point has no seek
	 *  stutter. The pointers above are SWAPPED on handoff — every existing
	 *  draw site keeps working untouched. */
	UPROPERTY(Transient)
	TObjectPtr<UMediaPlayer> BackgroundVideoPlayerB;

	UPROPERTY(Transient)
	TObjectPtr<UMediaTexture> BackgroundVideoTextureB;

	bool bVideoLoopHandoffArmed = false;

	// ---- S19-VIDLOOP2: seek grace + time-based re-arm ---------------------
	/** A Seek() is asynchronous: the player reports "not playing" until the
	 *  decoder resyncs. True while we are inside that window. */
	bool bVideoSeekInFlight = false;
	double VideoSeekStartedAt = 0.0;
	/** Seconds to ignore the not-playing gap a Seek() creates. */
	double VideoSeekGraceSeconds = 1.5;
	/** Wall-clock of the last watchdog resume attempt. */
	double VideoResumeAttemptedAt = -1.0e9;
	/** Minimum seconds between watchdog resume attempts. */
	double VideoResumeRetrySeconds = 2.0;
	int32 VideoResumeCount = 0;

	/** S18-VIDFIX2: 0..1 dip used to hide the decoder flush at the loop wrap. */
	float VideoWrapFade = 1.0f;
	/** Last sampled playback position, used to detect the wrap. */
	float VideoLastTimeSeconds = 0.0f;
	/** Counts down after a wrap while the picture fades back in. */
	float VideoWrapRecover = 0.0f;
	void UpdateBackgroundVideoLoop(); // S17-VIDLOOP: called from the draw path
	/** S19-FOGSTUTTER: true while the intro fog wipe is on screen
	 *  (intro video playing, or the smoke ramp/clear still animating).
	 *  IntroSmokeT is set to -2 once the wipe is finished for good. */
	bool IsIntroWipeActive() const { return bIntroVideoActive || IntroSmokeT >= 0.f; }

	/** S16-INTRO: silent intro video (Content/Movies/MenuIntro.mp4) played
	 *  fullscreen BEFORE the menu appears, ending in a smoke wipe. The menu
	 *  theme music starts with it (SetupActor plays it on BeginPlay). Skippable
	 *  with Space/Enter/Esc/click. File absent = straight to menu as before. */
	UPROPERTY(Transient)
	TObjectPtr<UMediaPlayer> IntroVideoPlayer;

	UPROPERTY(Transient)
	TObjectPtr<UMediaTexture> IntroVideoTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Background")
	TObjectPtr<UTexture2D> WatermarkEmblemTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Background")
	TObjectPtr<UTexture2D> ProgressionArtTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Progression Art")
	TObjectPtr<UTexture2D> ProgressionLeadershipTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Progression Art")
	TObjectPtr<UTexture2D> ProgressionMarksmanshipTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Progression Art")
	TObjectPtr<UTexture2D> ProgressionEnduranceTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Progression Art")
	TObjectPtr<UTexture2D> ProgressionTacticsTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Progression Art")
	TObjectPtr<UTexture2D> ProgressionEngineeringTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Progression Art")
	TObjectPtr<UTexture2D> ProgressionUpgradeBarTexture;

	// =========================================================================
	//  DEDICATED SECTION BACKGROUNDS
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Section Backgrounds")
	TObjectPtr<UTexture2D> BackgroundMedalsTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Section Backgrounds")
	TObjectPtr<UTexture2D> BackgroundRelicsTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Section Backgrounds")
	TObjectPtr<UTexture2D> BackgroundProgressionTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Section Backgrounds")
	TObjectPtr<UTexture2D> BackgroundArmoryTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Difficulty Backgrounds")
	TObjectPtr<UTexture2D> DiffRecruitTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Difficulty Backgrounds")
	TObjectPtr<UTexture2D> DiffRegularTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Difficulty Backgrounds")
	TObjectPtr<UTexture2D> DiffHardenedTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Difficulty Backgrounds")
	TObjectPtr<UTexture2D> DiffLethalTexture;

	// =========================================================================
	//  MODULAR UI BORDER FRAMES
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Frames")
	TObjectPtr<UTexture2D> FrameTacticalGoldTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Frames")
	TObjectPtr<UTexture2D> FrameTacticalCrimsonTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Frames")
	TObjectPtr<UTexture2D> FrameBadgeHexagonTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Frames")
	TObjectPtr<UTexture2D> FrameMedalSocketTexture; // MEGA-11: separate 3D beveled circular socket for honors (not baked into background)


	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Frames")
	TObjectPtr<UTexture2D> FrameAvatarPortraitTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Frames")
	TObjectPtr<UTexture2D> FrameMapTheaterTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Frames")
	TObjectPtr<UTexture2D> ButtonNormalTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Frames")
	TObjectPtr<UTexture2D> ButtonHoverTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Frames")
	TObjectPtr<UTexture2D> LoadingBarFrameTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Frames")
	TObjectPtr<UTexture2D> LoadingBarFillTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Frames")
	TObjectPtr<UTexture2D> PauseCardTexture;

	// =========================================================================
	//  MAIN MENU PNG ICONS / FX
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Icon PNGs")
	TObjectPtr<UTexture2D> MenuIconStartTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Icon PNGs")
	TObjectPtr<UTexture2D> MenuIconOperationsTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Icon PNGs")
	TObjectPtr<UTexture2D> MenuIconArmoryTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Icon PNGs")
	TObjectPtr<UTexture2D> MenuIconProgressionTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Icon PNGs")
	TObjectPtr<UTexture2D> MenuIconProfileTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Icon PNGs")
	TObjectPtr<UTexture2D> MenuIconRecordsTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Icon PNGs")
	TObjectPtr<UTexture2D> MenuIconSettingsTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Icon PNGs")
	TObjectPtr<UTexture2D> MenuIconExitTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Icon PNGs")
	TObjectPtr<UTexture2D> RailIconSquadTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Icon PNGs")
	TObjectPtr<UTexture2D> RailIconMessagesTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Icon PNGs")
	TObjectPtr<UTexture2D> RailIconLoadTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Icon PNGs")
	TObjectPtr<UTexture2D> RailIconRelicTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Icon PNGs")
	TObjectPtr<UTexture2D> RailIconSettingsTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Icon PNGs")
	TObjectPtr<UTexture2D> RailIconPowerTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Icon PNGs|Stats")
	TObjectPtr<UTexture2D> StatIconLevelTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Icon PNGs|Stats")
	TObjectPtr<UTexture2D> StatIconOperationsTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Icon PNGs|Stats")
	TObjectPtr<UTexture2D> StatIconAccuracyTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Icon PNGs|Stats")
	TObjectPtr<UTexture2D> StatIconHoursTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Icon PNGs|Stats")
	TObjectPtr<UTexture2D> StatIconXPTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu FX|Soft Sprites")
	TObjectPtr<UTexture2D> MenuSoftDustTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu FX|Soft Sprites")
	TObjectPtr<UTexture2D> MenuSoftEmberTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu FX|Soft Sprites")
	TObjectPtr<UTexture2D> MenuDustHazeBandTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu FX|Gradient Plates")
	TObjectPtr<UTexture2D> MenuTopBlackGradientTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu FX|Gradient Plates")
	TObjectPtr<UTexture2D> MenuBottomBlackGradientTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu FX|Gradient Plates")
	TObjectPtr<UTexture2D> MenuQuickStartPlateTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu FX|Gradient Plates")
	TObjectPtr<UTexture2D> MenuPanel3DPlateTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu FX|Gradient Plates")
	TObjectPtr<UTexture2D> MenuLeftButtonPlateTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu FX|Gradient Plates")
	TObjectPtr<UTexture2D> MenuLeftButtonHoverPlateTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu FX|Gradient Plates")
	TObjectPtr<UTexture2D> MenuLeftHoverGlowTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu FX|Niagara")
	TObjectPtr<UNiagaraSystem> MenuDustNiagaraSystem;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu FX|Niagara")
	bool bUseNiagaraMenuDustExplosion = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu FX|Niagara", meta = (ClampMin = "0.40", ClampMax = "6.00"))
	float MenuNiagaraDustBurstInterval = 1.15f;

	// =========================================================================
	//  AVATARS
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Avatars")
	TObjectPtr<UTexture2D> AvatarRostamiTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Avatars")
	TObjectPtr<UTexture2D> AvatarYoungBasijiTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Avatars")
	TObjectPtr<UTexture2D> AvatarArteshParatrooperTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Avatars")
	TObjectPtr<UTexture2D> AvatarGuerrillaHunterTexture;

	// =========================================================================
	//  TRAIT ICONS
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Trait Icons")
	TObjectPtr<UTexture2D> TraitTankDestroyerTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Trait Icons")
	TObjectPtr<UTexture2D> TraitHeavyCaliberTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Trait Icons")
	TObjectPtr<UTexture2D> TraitDesertReliabilityTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Trait Icons")
	TObjectPtr<UTexture2D> TraitAreaSuppressionTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Trait Icons")
	TObjectPtr<UTexture2D> TraitSilentMarksmanTexture;

	// =========================================================================
	//  MAP PREVIEWS
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Map Previews")
	TObjectPtr<UTexture2D> MapPreviewDehlaviehTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Map Previews")
	TObjectPtr<UTexture2D> MapPreviewBostanTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Map Previews")
	TObjectPtr<UTexture2D> MapPreviewKhorramshahrTexture;

	// =========================================================================
	//  WEAPON PREVIEWS
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Weapon Previews")
	TObjectPtr<UTexture2D> WeaponPreviewG3A3Texture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Weapon Previews")
	TObjectPtr<UTexture2D> WeaponPreviewAK47Texture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Weapon Previews")
	TObjectPtr<UTexture2D> WeaponPreviewRPG7Texture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Weapon Previews")
	TObjectPtr<UTexture2D> WeaponPreviewMG3Texture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Weapon Previews")
	TObjectPtr<UTexture2D> WeaponPreviewSVDTexture;

	// =========================================================================
	//  VISUAL THEME & PALETTE
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Visual Theme")
	EMenuColorTheme ColorTheme = EMenuColorTheme::DesertKhakiGold;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Visual Theme")
	FLinearColor PrimaryAccentColor = FLinearColor(0.407240f, 0.187821f, 0.063010f, 1.0f); // AAA-MW-13 sampled reference #AB7847

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Visual Theme")
	FLinearColor SecondaryAccentColor = FLinearColor(0.371238f, 0.124772f, 0.068478f, 1.0f); // AAA-MW-13 sampled reference fire #A4634A

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Visual Theme")
	FLinearColor PanelBgColor = FLinearColor(0.018f, 0.031f, 0.034f, 0.90f);

	// =========================================================================
	//  AUDIO SFX
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Audio SFX")
	TObjectPtr<USoundBase> ButtonHoverSound;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Audio SFX")
	TObjectPtr<USoundBase> ButtonClickSound;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Audio SFX")
	TObjectPtr<USoundBase> ButtonBackSound;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Audio SFX")
	TObjectPtr<USoundBase> UpgradePurchasedSound;

	// =========================================================================
	//  CUSTOM TYPOGRAPHY & FONTS
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Typography")
	TObjectPtr<UFont> TitleFont;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Typography")
	TObjectPtr<UFont> MenuFont;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Typography")
	TObjectPtr<UFont> BodyFont;

	// =========================================================================
	//  CONFIG & TARGET LEVEL
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Config")
	TSubclassOf<USquadAIMainMenuWidget> MenuWidgetClass;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Config")
	FName TargetGameplayLevelName = FName("L_Khuzestan");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Config")
	bool bUseProceduralCanvasMenu = true;

	// Global readability multiplier for all bounded menu text (auto-fit, never overflows).
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Config")
	float HUDFontScale = 1.08f;

	// MEGA-7: freeze menu particle motion (accessibility; frozen tableau still draws).
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Config")
	bool bReducedMenuMotion = false;

	// MEGA-8: filmic grain overlay (drawn last, over everything).
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Menu Config")
	bool bMenuFilmGrain = false;

	UPROPERTY(BlueprintReadOnly, Category = "Menu State")
	EMainMenuState MenuState = EMainMenuState::Main;
	TMap<FString, FString> ShapedTextFrameCache; // B6-15: per-frame shape cache, cleared each DrawHUD.

	// B6-4: settings-screen working copy (refreshed on entering Settings + after each change).
	FSquadGameSettingsSaveData CachedMenuSettings;

	UPROPERTY(BlueprintReadOnly, Category = "Menu State")
	int32 HoveredButtonIndex = -1;

	UPROPERTY(BlueprintReadOnly, Category = "Menu State")
	int32 SelectedMapIndex = 0;

	UPROPERTY(BlueprintReadOnly, Category = "Menu State")
	int32 SelectedWeaponIndex = 0;

	UPROPERTY(BlueprintReadOnly, Category = "Menu State")
	int32 HoveredTraitIndex = -1;

	UPROPERTY(BlueprintReadWrite, Category = "Player Profile")
	bool bIsEditingPlayerName = false;

	UPROPERTY(BlueprintReadWrite, Category = "Player Profile")
	bool bKeyboardLanguageFarsi = true;

	UPROPERTY(BlueprintReadWrite, Category = "Player Profile")
	FString CustomPlayerNameInput;

	UPROPERTY(BlueprintReadOnly, Category = "Player Profile")
	int32 ActiveProfileSlotIndex = 0;

	UPROPERTY(BlueprintReadOnly, Category = "Menu State")
	int32 ActiveProgressionInspectIdx = 0; // AAA-B3-1: persistent doctrine inspector selection

	UPROPERTY(BlueprintReadOnly, Category = "Menu State")
	int32 ActiveMedalInspectIdx = 0;

	UPROPERTY(BlueprintReadOnly, Category = "Menu State")
	int32 ActiveRelicInspectIdx = 0;
	// MEGA-5 (H-g): level-singleton setup actor, resolved once instead of per-frame.
	TWeakObjectPtr<ASquadAIMainMenuSetupActor> CachedRelicSetupActor;

	void DrawMilestoneProgressionTrack(float X, float Y, float W, float H, int32 UnlockedCount, int32 TotalMilestones, float UIScale);

	// =========================================================================
	//  1-CLICK PRESETS
	// =========================================================================

	UFUNCTION(BlueprintCallable, CallInEditor, Category = "1-Click Presets")
	void ApplyPersianFarsiPreset();

	UFUNCTION(BlueprintCallable, CallInEditor, Category = "1-Click Presets")
	void ApplyEnglishPreset();

	// P7-L4: Arabic preset (INI [MainMenu.ar] overrides win when present).
	UFUNCTION(BlueprintCallable, CallInEditor, Category = "1-Click Presets")
	void ApplyArabicPreset();

	UFUNCTION(BlueprintCallable, CallInEditor, Category = "1-Click Presets")
	void ApplyThemeColors();

	UFUNCTION(BlueprintCallable, Category = "Menu Actions")
	void NavigateToState(EMainMenuState NewState);

	UFUNCTION(BlueprintCallable, Category = "Menu Actions")
	void ProcessClickAtMousePosition(float MouseX, float MouseY);

protected:
	UPROPERTY()
	TObjectPtr<USquadAIMainMenuWidget> ActiveMenuWidget;

private:
	struct FMenuButtonRect
	{
		int32 ButtonID = 0;
		FVector2D Min;
		FVector2D Max;
		FText Label;
	};

	TArray<FMenuButtonRect> ClickableButtons;
	TArray<FSquadMenuParticle> SandParticles;
	TArray<FSquadMenuParticle> GroundDust; // MEGA-7: wind-blown streaks, bottom band.
	TArray<FSquadMenuParticle> EmberSparks; // MEGA-7: rising embers, bottom edge.
	int32 LastHoveredButtonID = -1;

	// Animation Timers
	float MasterTime = 0.0f;
	float KenBurnsTimer = 0.0f;
	float SubmenuSlideOffset = 0.0f;
	float TargetSubmenuSlideOffset = 0.0f;
	float TransitionAlpha = 1.0f;
	float IntroCascadeTimer = 0.0f;
	float CompassRotation = 0.0f;
	float ChevronHoverSlide = 0.0f;
	float HoverCardAlpha = 0.0f;
	float LastFrameDelta = 0.016f; // MEGA-8: delta for eased hover ramps.
	float LastMenuClickTime = -100.f; // MEGA-8: press-dip feedback clock.
	float ScreenFadeT = 1.f; // MEGA-8: seconds since menu-state change.
	EMainMenuState LastDrawnMenuState = EMainMenuState::Main; // MEGA-8: fade detector.
	bool bMenuDrawInitialized = false;
	// S19-INSTANT: clock for the departure screen's spinner and its fallback bar ramp.
	float DepartureSeconds = 0.f;
	TMap<FString, float> ButtonHoverRamp; // MEGA-8: eased hover 0..1, keyed by label.
	float NextMenuNiagaraDustBurstTime = 0.f; // AAA-MW-6: scheduled real Niagara dust bursts.
	int32 MenuNiagaraDustBurstCounter = 0;
	bool bLoggedMissingMenuDustNiagara = false;

	void UpdateAnimations(float DeltaTime);
	void UpdateSandParticles(float DeltaTime, float ScreenW, float ScreenH);
	void DrawSandParticles();
	void UpdateGroundDustAndEmbers(float DeltaTime, float ScreenW, float ScreenH);
	void DrawGroundDustAndEmbers(float ScreenW, float ScreenH);
	void DrawGroundFogBands(float ScreenW, float ScreenH);
	void AutoResolveMenuDustNiagara();
	void TickMenuNiagaraDust(float ScreenW, float ScreenH);
	void DrawMenuFilmGrain(float ScreenW, float ScreenH);

	void DrawBackgroundMedia(float ScreenW, float ScreenH);
	void DrawTacticalTelemetryHUD(float ScreenW, float ScreenH);
	void DrawAudioWaveformVisualizer(float X, float Y, float Width, float Height);
	void DrawCompassDial(float X, float Y, float Radius);
	void DrawScanlinesAndVignette(float ScreenW, float ScreenH);

	// Sub-panel Screens
	void DrawMainMenuScreen(float ScreenW, float ScreenH, float MouseX, float MouseY);
	void DrawMapSelectScreen(float ScreenW, float ScreenH, float MouseX, float MouseY);
	void DrawPlayerProgressionScreen(float ScreenW, float ScreenH, float MouseX, float MouseY);
	void DrawPlayerProfileScreen(float ScreenW, float ScreenH, float MouseX, float MouseY);
	void DrawArmoryScreen(float ScreenW, float ScreenH, float MouseX, float MouseY);
	void DrawAchievementsScreen(float ScreenW, float ScreenH, float MouseX, float MouseY);
	void DrawDifficultyScreen(float ScreenW, float ScreenH, float MouseX, float MouseY);
	void DrawLoadGameScreen(float ScreenW, float ScreenH, float MouseX, float MouseY);
	void DrawSettingsScreen(float ScreenW, float ScreenH, float MouseX, float MouseY);
	void DrawTacticalBriefingScreen(float ScreenW, float ScreenH, float MouseX, float MouseY);
	void DrawRelicCollectionScreen(float ScreenW, float ScreenH, float MouseX, float MouseY);

	// Procedural Drawing Helpers & Sacred Defense Borders
	// S19-INSTANT: the departure screen. Drawn by THIS HUD (canvas) the moment a
	// level transition is requested, so the player waits in it while the blocking
	// map load runs, instead of on a frozen difficulty screen.
	void DrawDepartureScreen(float ScreenW, float ScreenH, float DeltaTime);

	void DrawFarsiText(const FString& Text, const FLinearColor& Color, float X, float Y, UFont* Font = nullptr, float Scale = 1.0f, bool bDropShadow = true);
	void DrawFarsiTextBounded(const FString& Text, const FLinearColor& Color, float X, float Y, float MaxWidth, UFont* Font = nullptr, float PreferredScale = 1.0f, bool bDropShadow = true, bool bCenterHorizontal = false, float BoxHeight = 0.0f);
	void GetFarsiTextSize(const FString& Text, UFont* Font, float Scale, float& OutW, float& OutH);
	void RegisterButton(int32 ID, float X, float Y, float Width, float Height, const FText& Label);
	void DrawStyledButton(float X, float Y, float Width, float Height, const FText& Text, bool bHovered, bool bDisabled = false, float StaggerDelay = 0.0f);
	void DrawChiseledTacticalPanel(float X, float Y, float Width, float Height, const FLinearColor& BgColor, const FLinearColor& BorderColor, float CutSize = 12.0f);
		void DrawNineSliceFrame(UTexture2D* FrameTexture, float X, float Y, float Width, float Height, float CornerSize, const FLinearColor& Tint); // AAA-MM-4: transparent-center modular PNG frame overlay
	void DrawTacticalTopoGrid(float X, float Y, float Width, float Height, const FLinearColor& Tint);
	void DrawBallisticBlueprintGrid(float X, float Y, float Width, float Height, const FLinearColor& Tint);
	void DrawDossierDocumentUnderlay(float X, float Y, float Width, float Height, const FString& StampFarsi, const FLinearColor& StampColor);
	void DrawRoundedBox(float X, float Y, float Width, float Height, float CornerRadius, const FLinearColor& FillColor, const FLinearColor& BorderColor);
	void DrawSacredDefenseBorder(float X, float Y, float Width, float Height, const FLinearColor& BorderColor, bool bActiveGlow = false);
	void DrawStatBar(float X, float Y, float Width, float Height, float Fraction, const FLinearColor& FillColor, const FLinearColor& EmptyColor);
	void DrawTacticalDivider(float X, float Y, float Width, const FLinearColor& Color);
	void DrawSpecialityBadge(float X, float Y, float Width, float Height, const FSquadWeaponSpecialityTrait& Trait, bool bHovered);
	void AutoResolveMissingTextures();
	// S19-IMGSEQ: try a folder of numbered frames with the ImgMedia player.
	// It avoids video-codec decoding but still decodes frames and uses the cache.
	// Returns false if the ImgMedia plugin is disabled,
	// the folder is missing, or the player refuses the source - the caller then
	// falls back to MP4 exactly as before.
	bool TryOpenImageSequence(UMediaPlayer* Player, const FString& SequenceDir, float FPS);

	void InitBackgroundVideo(); // S16-VID
	// S16-INTRO
	void InitIntroVideo();
	bool DrawIntroSequence(float ScreenW, float ScreenH); // true = intro owns this frame
	void DrawIntroSmoke(float ScreenW, float ScreenH, float Alpha);
	void DrawIntroSmokeOverlay(float ScreenW, float ScreenH);
	void BeginIntroSmoke();
	UFUNCTION()
	void OnIntroVideoEnded();
	bool bIntroVideoActive = false;
	bool bIntroGotFrame = false;
	float IntroStartRealTime = 0.f;
	float IntroSmokeT = -1.f; // -1 idle, 0..Total running, -2 done

	// ============================ S17-FOGFX ================================
	// HQ explosion-fog wipe between the intro video and the menu, replacing
	// the 7-billow soft-dust wipe when its assets exist. Zero editor setup:
	// drop PNGs into Content/Movies/FogFX/ —
	//   puff1.png..puff4.png  smoke sprites (shipped; >=1 required)
	//   logo.png              company logo, square, transparent (optional)
	//   title.png             game name, 4:1 wide, transparent (optional)
	//   noise.png             tileable churn noise (shipped, material path)
	// Optional: run SquadAI_ImportFogFX.py once to build
	// /Game/SquadAI/FogFX/M_FogBillow -> real per-pixel churn + turbulent
	// dissolve (After-Effects-style). Material absent -> DrawTexture fallback
	// (UV-window drift churn). Folder absent or SquadAI.MenuFogFX 0 -> the
	// S16-INTRO dust wipe runs byte-for-byte as before.
	struct FFogBillow
	{
		int32 TexIdx = 0;
		float Ang = 0.f, Dist = 0.f, Delay = 0.f, S0 = 0.f, S1 = 0.f;
		float Rot = 0.f, RotV = 0.f, DriftX = 0.f, DriftY = 0.f;
		float FadeLead = 0.f, Seed = 0.f;
		FLinearColor Tint = FLinearColor::White;
	};
	struct FFogDust
	{
		float X0 = 0.f, Y0 = 0.f, VX = 0.f, VY = 0.f;
		float Size = 0.f, A0 = 0.f, Ph = 0.f, Fl = 0.f;
		FLinearColor Tint = FLinearColor::White;
	};
	UPROPERTY(Transient)
	TArray<TObjectPtr<UTexture2D>> FogPuffTextures;
	UPROPERTY(Transient)
	TObjectPtr<UTexture2D> FogLogoTexture;
	UPROPERTY(Transient)
	TObjectPtr<UTexture2D> FogTitleTexture;
	UPROPERTY(Transient)
	TObjectPtr<UTexture2D> FogNoiseTexture;
	UPROPERTY(Transient)
	TObjectPtr<UTexture2D> FogDustDotTexture;
	UPROPERTY(Transient)
	TArray<TObjectPtr<UMaterialInstanceDynamic>> FogFXMIDs;
	TArray<FFogBillow> FogWhiteBillows;
	TArray<FFogBillow> FogBlackBillows;
	TArray<FFogDust> FogDustMotes;
	bool bFogFXReady = false;
	bool bFogFXUseMaterial = false;
	void InitFogFX();
	void DrawFogFX(float ScreenW, float ScreenH, float T);
	void DrawFogBillowQuad(int32 MIDIndex, UTexture2D* Sprite, float CX, float CY, float SizeW, float SizeH, float RotDeg, float Warp, float Diss, float Alpha, float Seed, const FLinearColor& Tint);
	float FogSmokeInTotal() const;   // S17: blast-in + whiteout + logo hold (or S16 0.55)
	float FogSmokeOutTotal() const;  // S17: rising clear (or S16 1.35)

	// ---- S19-FOGSPEED: how fast the whole wipe runs -----------------------
	/** Multiplier applied to the fog clock. 1 = authored (8.15 s). Driven by
	 *  the console variable SquadAI.MenuFogSpeed, clamped to a sane range so a
	 *  typo cannot make the wipe instant or endless. */
	float GetFogSpeedScale() const;

	// ---- S19-FOGSMOOTH: one shared, hitch-proof fog clock ----------------
	/** Advance the fog clock one clamped, monotonic step and return how far
	 *  IntroSmokeT should move this frame.
	 *
	 *  The in-phase (DrawIntroSequence) and the out-phase (DrawIntroSmokeOverlay)
	 *  each used to do `IntroSmokeT += GetWorld()->GetDeltaSeconds() * Speed`
	 *  inside DRAW code. DrawHUD can be invoked more than once per frame, and the
	 *  world delta can be a frame stale, so the phase advanced in uneven steps --
	 *  the stutter seen while the fog clears. One shared, frame-stamped, clamped
	 *  step from a monotonic clock removes it: the wipe is paced by real elapsed
	 *  time and a hitch (or a duplicate draw) can never jump it. */
	float AdvanceFogClock();
	/** Wall-clock of the previous step; negative = not started yet. */
	double FogClockLastUpdate = -1.0;
	/** Frame the clock last stepped on, so one frame advances it at most once. */
	uint32 FogClockFrameStamp = 0xFFFFFFFFu;

	// ---- S19-STUTTER: deferred intro-video teardown -----------------------
	/** True while the intro media player is waiting to be released. */
	bool bIntroVideoClosePending = false;
	/** Pause + close the intro media player, once. Called after the wipe has
	 *  finished, never on the frame the clear starts. */
	void ReleaseIntroVideo();
	// ========================== /S17-FOGFX =================================

	UTexture2D* GetAvatarTexture(FName AvatarID) const;
	UTexture2D* GetTraitTexture(FName TraitID) const;
	UTexture2D* GetMapPreviewTexture(FName MapID) const;
	UTexture2D* GetWeaponPreviewTexture(FName WeaponID) const;
};

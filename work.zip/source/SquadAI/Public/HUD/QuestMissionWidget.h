// QuestMissionWidget.h — UMG widget for mission text + timer (Persian/RTL support)
// Create a Widget Blueprint from this class, add TextBlocks with the right names,
// set your Persian font, done.
#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "QuestMissionWidget.generated.h"

class AQuestChain;
class AMissionZone;
class UTextBlock;
class UVerticalBox;
class UImage;

UCLASS()
class SQUADAI_API UQuestMissionWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, Category = "Quest")
	void SetQuestChain(AQuestChain* Chain);

protected:
	virtual void NativeConstruct() override;
	virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime) override;

	// BINDWIDGET: Add these named widgets in your Widget Blueprint.
	// The C++ code auto-finds them by name.

	UPROPERTY(meta = (BindWidget))
	UTextBlock* MissionDescription = nullptr;

	UPROPERTY(meta = (BindWidget))
	UTextBlock* MissionTypeBadge = nullptr;

	UPROPERTY(meta = (BindWidget))
	UTextBlock* DefendTimer = nullptr;

	UPROPERTY(meta = (BindWidget))
	UTextBlock* EnemyCounter = nullptr;

	UPROPERTY(meta = (BindWidget))
	UVerticalBox* ChecklistContainer = nullptr;

	UPROPERTY(meta = (BindWidgetOptional))
	UTextBlock* DistanceText = nullptr;

	UPROPERTY(meta = (BindWidgetOptional))
	UImage* TimerBackground = nullptr;

	// Splash art behind mission text (set your PNG in Widget Blueprint)
	UPROPERTY(meta = (BindWidgetOptional))
	UImage* MissionSplashBackground = nullptr;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Quest|Font")
	FSlateFontInfo PersianFont;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Quest|Font")
	FSlateFontInfo DefaultFont;

private:
	UPROPERTY()
	TObjectPtr<AQuestChain> ActiveChain;

	float RefreshTimer = 0.f;

	void UpdateDisplay();
	AQuestChain* FindQuestChain();
	FSlateFontInfo GetBestFont() const;
};

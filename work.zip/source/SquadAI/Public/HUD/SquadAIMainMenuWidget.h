#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "SquadTypes.h"
#include "SaveSystem/SquadAISaveGame.h"
#include "Performance/DifficultySubsystem.h"
#include "SquadAIMainMenuWidget.generated.h"

UENUM(BlueprintType)
enum class EMainMenuState : uint8
{
	Main,
	NewGameDifficulty,
	MapSelect,
	PlayerProgression,
	PlayerProfile,
	Armory,
	Achievements,
	LoadGame,
	MissionSelect,
	Settings,
	TacticalBriefing,
	ConfirmQuit,
	RelicCollection
};

/**
 * USquadAIMainMenuWidget
 * Modular UMG Main Menu User Widget handling New Game, Map Selection,
 * Player Progression & Upgrades, Player Profiles & Lifetime Stats, Armory Weapon Unlocking, Save/Load, and Settings.
 */
UCLASS(BlueprintType, Blueprintable)
class SQUADAI_API USquadAIMainMenuWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Main Menu")
	EMainMenuState CurrentMenuState = EMainMenuState::Main;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Main Menu")
	FName GameplayLevelName = FName("L_Khuzestan");

	UPROPERTY(BlueprintReadOnly, Category = "Main Menu")
	bool bHasSavedGame = false;

	UPROPERTY(BlueprintReadOnly, Category = "Main Menu")
	TArray<FString> AvailableSaveSlots;

	// =========================================================================
	//  UI ACTIONS
	// =========================================================================

	UFUNCTION(BlueprintCallable, Category = "Main Menu")
	void StartNewGame(EGameDifficulty Difficulty);

	UFUNCTION(BlueprintCallable, Category = "Main Menu")
	void ContinueGame();

	UFUNCTION(BlueprintCallable, Category = "Main Menu")
	void LoadSaveSlot(const FString& SlotName);

	UFUNCTION(BlueprintCallable, Category = "Main Menu")
	void DeleteSaveSlot(const FString& SlotName);

	UFUNCTION(BlueprintCallable, Category = "Main Menu")
	void LaunchMission(int32 MissionIndex);

	UFUNCTION(BlueprintCallable, Category = "Main Menu")
	void ApplySettings(const FSquadGameSettingsSaveData& NewSettings);

	UFUNCTION(BlueprintCallable, Category = "Main Menu")
	void SetMenuState(EMainMenuState NewState);

	UFUNCTION(BlueprintCallable, Category = "Main Menu")
	void QuitGame();

	UFUNCTION(BlueprintCallable, Category = "Main Menu")
	void RefreshSaveSlots();
};

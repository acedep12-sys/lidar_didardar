#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "SquadAILoadingScreenWidget.generated.h"

class UTexture2D;
class UMaterialInterface;
class USoundBase;

/**
 * USquadAILoadingScreenWidget
 * Fullscreen Tactical Loading Screen UMG Widget with animated radar sweep,
 * progress indicator, rotating combat tips, and optional 'Press Any Key To Deploy' prompt.
 */
UCLASS(BlueprintType, Blueprintable)
class SQUADAI_API USquadAILoadingScreenWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;
	virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime) override;

	UFUNCTION(BlueprintCallable, Category = "Loading Screen")
	void SetLoadingContent(const FText& InSectorTitle, const FText& InMissionBriefing, const FText& InCombatTip);

	UFUNCTION(BlueprintCallable, Category = "Loading Screen")
	void MarkLoadingComplete();

	UFUNCTION(BlueprintCallable, Category = "Loading Screen")
	void OnDeployClicked();

	// =========================================================================
	//  CONFIG & CUSTOM VISUALS
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loading Screen Visuals")
	TObjectPtr<UTexture2D> BackgroundArtwork;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loading Screen Visuals")
	TObjectPtr<UMaterialInterface> BackgroundMaterial;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loading Screen Audio")
	TObjectPtr<USoundBase> DeployConfirmationSound;

	/** If true, holds the loading screen until the player presses Space / Left Click to enter combat */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loading Screen Config")
	bool bRequirePlayerInputToDeploy = false;

	// =========================================================================
	//  RUNTIME STATE & ANIMATION
	// =========================================================================

	UPROPERTY(BlueprintReadOnly, Category = "Loading Screen")
	FText SectorTitleText;

	UPROPERTY(BlueprintReadOnly, Category = "Loading Screen")
	FText MissionBriefingText;

	UPROPERTY(BlueprintReadOnly, Category = "Loading Screen")
	FText CombatTipText;

	UPROPERTY(BlueprintReadOnly, Category = "Loading Screen")
	float RadarSweepAngle = 0.0f;

	UPROPERTY(BlueprintReadOnly, Category = "Loading Screen")
	float SimulatedProgress = 0.0f;

	UPROPERTY(BlueprintReadOnly, Category = "Loading Screen")
	float PromptPulseAlpha = 1.0f;

	UPROPERTY(BlueprintReadOnly, Category = "Loading Screen")
	bool bIsReadyToDeploy = false;

private:
	float TipTimer = 0.0f;	float PulseTimer = 0.0f;
	// L2-INI: wall-clock guard for tip cadence (ticks can throttle while streaming).
	double LastTipWallTime = -100.0;
};

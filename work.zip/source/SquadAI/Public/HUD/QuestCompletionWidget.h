#pragma once
#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "Quest/MissionZone.h"
#include "QuestCompletionWidget.generated.h"

class AQuestChain;
class UTextBlock;
class UImage;

UCLASS()
class SQUADAI_API UQuestCompletionWidget : public UUserWidget
{
	GENERATED_BODY()
public:
	UFUNCTION(BlueprintCallable, Category = "Quest") void ShowCompletionMessage(const FText& Message);
	UFUNCTION(BlueprintCallable, Category = "Quest") void HideMessage();
	UFUNCTION(BlueprintCallable, Category = "Quest") void SetQuestChain(AQuestChain* Chain);
protected:
	virtual void NativeConstruct() override;
	virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime) override;
	virtual void NativeDestruct() override;

	UPROPERTY(meta = (BindWidget)) UTextBlock* CompletionText = nullptr;
	UPROPERTY(meta = (BindWidgetOptional)) UImage* BackgroundImage = nullptr;
private:
	UPROPERTY() TObjectPtr<AQuestChain> ActiveChain;

	enum class EAnimState : uint8 { Hidden, ZoomIn, Holding, FlyOut };
	EAnimState AnimState = EAnimState::Hidden;
	float AnimTimer = 0.f;
	float ZoomInDuration = 0.4f;
	float FlyOutDuration = 0.5f;
	float HoldDuration = 3.0f;

	void ApplyZoomIn(float Alpha);
	void ApplyFlyOut(float Alpha);
	UFUNCTION() void HandleMissionStateChanged(AMissionZone* Mission, EMissionZoneState NewState);
};

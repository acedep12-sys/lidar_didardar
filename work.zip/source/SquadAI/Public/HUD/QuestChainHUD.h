// QuestChainHUD.h — UMG widget for quest chain progress display
// Create a Widget Blueprint inheriting from this class to design the UI.
// Shows: quest description, mission checklist, defend timer, quest marker direction.
#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "Quest/MissionZone.h"
#include "QuestChainHUD.generated.h"

class AQuestChain;
class AMissionZone;

USTRUCT(BlueprintType)
struct FQuestMissionHUDData
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly, Category = "HUD")
	FText Description;

	UPROPERTY(BlueprintReadOnly, Category = "HUD")
	EMissionType Type = EMissionType::Reach;

	UPROPERTY(BlueprintReadOnly, Category = "HUD")
	EMissionZoneState State = EMissionZoneState::Locked;

	UPROPERTY(BlueprintReadOnly, Category = "HUD")
	float Progress = 0.f;

	UPROPERTY(BlueprintReadOnly, Category = "HUD")
	bool bIsCurrent = false;
};

UCLASS(BlueprintType, Blueprintable)
class SQUADAI_API UQuestChainHUD : public UUserWidget
{
	GENERATED_BODY()

public:
	// ===== BINDABLE DATA (bind these to your UMG widgets) =====

	// Current quest description text
	UPROPERTY(BlueprintReadOnly, Category = "HUD|Quest")
	FText CurrentQuestDescription;

	// Overall quest chain progress (0-1)
	UPROPERTY(BlueprintReadOnly, Category = "HUD|Quest")
	float OverallProgress = 0.f;

	// Current mission index / total
	UPROPERTY(BlueprintReadOnly, Category = "HUD|Quest")
	int32 CurrentMissionIndex = 0;

	UPROPERTY(BlueprintReadOnly, Category = "HUD|Quest")
	int32 TotalMissions = 0;

	// Mission checklist data (use this to populate a list view)
	UPROPERTY(BlueprintReadOnly, Category = "HUD|Quest")
	TArray<FQuestMissionHUDData> MissionChecklist;

	// Defend timer (only valid during Defend missions)
	UPROPERTY(BlueprintReadOnly, Category = "HUD|Defend")
	bool bShowDefendTimer = false;

	UPROPERTY(BlueprintReadOnly, Category = "HUD|Defend")
	float DefendTimeRemaining = 0.f;

	UPROPERTY(BlueprintReadOnly, Category = "HUD|Defend")
	float DefendDuration = 0.f;

	UPROPERTY(BlueprintReadOnly, Category = "HUD|Defend")
	float DefendProgress = 0.f;

	// Direction to current quest zone (normalized vector from player to zone)
	UPROPERTY(BlueprintReadOnly, Category = "HUD|Navigation")
	FVector QuestDirection = FVector::ZeroVector;

	// Distance to current quest zone (cm)
	UPROPERTY(BlueprintReadOnly, Category = "HUD|Navigation")
	float QuestDistance = 0.f;

	// Whether to show the quest marker
	UPROPERTY(BlueprintReadOnly, Category = "HUD|Navigation")
	bool bShowQuestMarker = false;

	// ===== API =====

	// Call this to set the active quest chain
	UFUNCTION(BlueprintCallable, Category = "HUD")
	void SetQuestChain(AQuestChain* Chain);

	// Call this every tick or from a timer to refresh data
	UFUNCTION(BlueprintCallable, Category = "HUD")
	void RefreshData();

protected:
	virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime) override;

private:
	UPROPERTY()
	TObjectPtr<AQuestChain> ActiveChain;

	float TimeSinceRefresh = 0.f;

	void BuildMissionChecklist();
	void UpdateDefendTimer();
	void UpdateNavigation();
};

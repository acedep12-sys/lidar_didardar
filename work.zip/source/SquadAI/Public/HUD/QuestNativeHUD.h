#pragma once
#include "CoreMinimal.h"
#include "Quest/MissionBriefingModel.h"
#include "Tactical/GrenadeFlightModel.h"   // S19-GRENARC
#include "Templates/SubclassOf.h" // S18-PERF: GetCachedActorsOfClass
#include "Containers/Ticker.h"
#include "GameFramework/HUD.h"
#include "InputCoreTypes.h"
#include "QuestNativeHUD.generated.h"

class AQuestChain;
class APawn;
class USceneCaptureComponent2D;
class UTextureRenderTarget2D;
class UTexture2D;
class UMaterialInstanceDynamic;
class UMaterialInterface;
class ASoldierCharacter;
class AEnemyCommander;      // S19-ELITE
class AEnemyCommanderAssistant;
class AAmmoCrateActor;
class AFirstAidKitActor;
class AMedicalStationActor;
class AMountedTurretActor;
class AExplosiveBarrelActor;

struct FMinimapSoldierDot
{
	FVector WorldLoc = FVector::ZeroVector;
	bool bAlly = false;
	bool bIsDowned = false;
	// S19-ELITE: elites get their own marker shape on the minimap.
	bool bIsCommander = false;
	bool bIsAssistant = false;
};

USTRUCT(BlueprintType)
struct FDamageHitIndicator
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, Category = "HUD")
	FVector WorldSourceLocation = FVector::ZeroVector;

	UPROPERTY(BlueprintReadWrite, Category = "HUD")
	float TimeRemaining = 1.2f;

	UPROPERTY(BlueprintReadWrite, Category = "HUD")
	float MaxLifetime = 1.2f;

	UPROPERTY(BlueprintReadWrite, Category = "HUD")
	float DamageAmount = 0.f;
};

UCLASS()
class SQUADAI_API AQuestNativeHUD : public AHUD
{
	GENERATED_BODY()
public:
	virtual void DrawHUD() override;

	void DrawFarsiText(const FString& Text, const FLinearColor& Color, float X, float Y, UFont* Font = nullptr, float Scale = 1.0f, bool bScalePosition = false);
	void DrawFarsiTextBounded(const FString& Text, const FLinearColor& Color, float X, float Y, float MaxWidth, UFont* Font = nullptr, float PreferredScale = 1.0f, bool bDropShadow = true, bool bCenterHorizontal = false, float BoxHeight = 0.0f, bool bRightAlign = false);
	// S19-CONST: const on purpose - it measures (and memoises into ShapedTextFrameCache,
	// which is mutable), so the const layout helpers can call it. WrapTutorialText was
	// calling this from a const method: C2662.
	void GetFarsiTextSize(const FString& Text, UFont* Font, float Scale, float& OutW, float& OutH) const;
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

	// ===== MINIMAP CONFIG =====
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Minimap") float MinimapRadius = 100.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Minimap") float MinimapMargin = 25.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Minimap") float MinimapCaptureHeight = 3000.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Minimap") float MinimapCaptureWidth = 20000.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Minimap") int32 MinimapResolution = 512;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD") float RefreshInterval = 1.0f;

	// ===== SCREEN OVERLAYS & FEEDBACK CONFIG =====
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Overlays")
	bool bEnableLowHealthVignette = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Overlays")
	bool bEnableFireBurnVignette = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Overlays")
	bool bEnableSuppressionVignette = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Overlays")
	bool bEnableHitMarkers = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Overlays")
	bool bEnableDamageDirectionIndicators = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Tactical")
	bool bEnableTacticalCompassRibbon = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Tactical")
	bool bEnableSquadStatusPanel = true;

	// S11-HUD: NOW ON BY DEFAULT.
	// AAA-MW-22 originally disabled this so it would not duplicate the third-party
	// pack's weapon/ammo UI in the top-right. That reasoning became wrong once the
	// pack UMG widgets were put behind deny-by-default suppression: the pack UI no
	// longer draws at all, so with this flag off NOTHING appeared top-right and the
	// player had no ammo readout. Set to false only if you re-enable a pack HUD.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Tactical")
	bool bEnableNativeWeaponStatusPlate = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Tactical")
	bool bEnableMissionObjectiveCard = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Tactical")
	bool bEnableTactical3DPings = true;

	// ===== OBJECTIVE GUIDANCE VISION (Eagle Vision / Path Scanner) =====
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Guidance")
	bool bEnableObjectiveGuidanceVision = true;
	// NO-UMG-QUESTHUD: Canvas-native gameplay HUD only; legacy WBP_QuestHUD/UMG stacks stay suppressed.
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "HUD")
	bool bSuppressLegacyUMG = true;

	// P6-6/P7-UI1: explicit ownership allow-list for viewport UMG widgets. The suppression
	// sweeps are now DENY-BY-DEFAULT: every UUserWidget on the game viewport is collapsed
	// EXCEPT widgets registered here (e.g. the SquadAI loading screen) or SquadAI*-prefixed
	// classes. The old class-name substring allow-list leaked any third-party pack widget
	// (e.g. the TPW health bar) whose class name didn't match — and viewport widgets draw
	// ON TOP of the Canvas HUD, covering the tactical weapon plate and the loading screen.
	static void RegisterAllowedViewportWidget(UUserWidget* W);
	static bool IsAllowedViewportWidget(const UUserWidget* W);
	/** Collapses every viewport UMG widget not on the ownership allow-list. Returns how many were newly neutralized. */
	static int32 SquadAISuppressForeignViewportWidgets(UWorld* World);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Guidance")
	FKey GuidanceVisionKey = EKeys::V;

	UFUNCTION(BlueprintCallable, Category = "HUD|Guidance")
	void SetGuidanceVisionActive(bool bActive) { bGuidanceVisionActive = bActive; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "HUD|Guidance")
	bool IsGuidanceVisionActive() const { return bGuidanceVisionActive; }

	// ===== FEEDBACK API =====
	UFUNCTION(BlueprintCallable, Category = "HUD|Feedback")
	void NotifyDamageReceived(const FVector& DamageSourceLocation, float DamageAmount);

	UFUNCTION(BlueprintCallable, Category = "HUD|Feedback")
	void NotifyHitConfirmed(bool bKilledTarget);

	UFUNCTION(BlueprintCallable, Category = "HUD|Feedback")
	void NotifyAllyDowned(const FVector& Location, const FText& AllyName);

	// S17-NOTE: show a collected fallen soldier's note (title + body) as a
	// timed reading overlay. Farsi/Arabic shaping handled by DrawFarsiText*.
	UFUNCTION(BlueprintCallable, Category = "HUD|Feedback")
	void ShowFallenNote(const FText& Title, const FText& Body, float Duration, int32 FoundCount, int32 TotalCount);

	// S17-STORY: mission briefing / story card (same reader card, military green
	// accent, no counter). Queued automatically until the deployment veil closes.
	UFUNCTION(BlueprintCallable, Category = "HUD|Feedback")
	void ShowStoryCard(const FText& Title, const FText& Body, float Duration = 12.f);

	UFUNCTION(BlueprintCallable, Category = "HUD|Feedback")
	void SetPlayerBurning(bool bBurning);

	UFUNCTION(BlueprintCallable, Category = "HUD|Feedback")
	void AddPlayerSuppression(float Amount);

	// ===== MORTAR WARNINGS & TARGETING API =====
	UFUNCTION(BlueprintCallable, Category = "HUD|Mortar")
	void RegisterIncomingMortarWarning(const FVector& Location, float Radius, float Duration, float TimeUntilImpact);

	// ===== S19-DEATHPROMPT =====
	/** Big centred "you died" card. Title/sub are already localised by the caller. */
	UFUNCTION(BlueprintCallable, Category = "HUD|Feedback")
	void ShowDeathPrompt(const FString& Title, const FString& Sub, float Duration = 4.f);

	/** S19-DEATHPROMPT: FA/EN localisation for HUD text, INI-overridable
	 *  ([Section] / [Section.ar]). Wraps the file-local helper (anonymous namespace in
	 *  QuestNativeHUD.cpp) so non-HUD code -- mission zone, explosive damage -- produces
	 *  exactly the same strings the HUD would, without duplicating them. */
	static FString LocalizeHUDText(const UObject* Context, const TCHAR* Section, const TCHAR* Key,
		const TCHAR* PersianText, const TCHAR* EnglishText);

	/** S19-BLASTGUARD: push a one-line alert banner (the same one mission alerts use),
	 *  so anything that hurts the player can say so on screen. */
	UFUNCTION(BlueprintCallable, Category = "HUD|Feedback")
	void ShowAlertBanner(const FString& Text, FLinearColor Color, float Duration = 4.f);

	UFUNCTION(BlueprintCallable, Category = "HUD|Mortar")
	void SetMortarAimingActive(bool bActive, const FVector& AimLocation = FVector::ZeroVector);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "HUD", meta = (WorldContext = "WorldContextObject"))
	static AQuestNativeHUD* Get(const UObject* WorldContextObject);

	// ===== WEAPON ICONS CONFIG =====
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Weapon Icons")
	TObjectPtr<UTexture2D> HUDWeaponG3Texture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Weapon Icons")
	TObjectPtr<UTexture2D> HUDWeaponAKTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Weapon Icons")
	TObjectPtr<UTexture2D> HUDWeaponRPGTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Weapon Icons")
	TObjectPtr<UTexture2D> HUDWeaponMG3Texture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Weapon Icons")
	TObjectPtr<UTexture2D> HUDWeaponSVDTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Weapon Icons")
	TObjectPtr<UTexture2D> HUDWeaponUnarmedTexture;

	// G-12: pretty health-card art (optional; procedural bar is the fallback).
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Health")
	TObjectPtr<UTexture2D> HUDHealthCardTexture;

	// ===== DEPLOYMENT WARMUP VEIL =====
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Loading")
	TObjectPtr<UTexture2D> DeploymentVeilArtwork;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Loading")
	TObjectPtr<UTexture2D> LoadingBarFrameTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Loading")
	TObjectPtr<UTexture2D> LoadingBarFillTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Loading")
	TObjectPtr<UTexture2D> ButtonNormalTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Loading")
	TObjectPtr<UTexture2D> ButtonHoverTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Loading")
	TObjectPtr<UTexture2D> TacticalButtonTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Loading")
	TObjectPtr<UTexture2D> TacticalPauseCardTexture;

	// P6-5: wall-clock (FPlatformTime::Seconds) timestamp of the last loose-PNG resolve
	// attempt for the deployment veil and pause menu art. Without these latches, missing
	// art files were re-stat'ed from disk on EVERY rendered frame while those screens were
	// visible. Wall clock is used deliberately: world TimeSeconds freezes under game pause,
	// which is exactly when the pause menu draws.
	double DeploymentVeilArtRetryTime = -10.0;
	double PauseMenuArtRetryTime = -10.0;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "HUD|Loading")
	bool IsWarmupVeilActive() const { return bDeploymentVeilActive; }

	// ===== TACTICAL PAUSE MENU =====
	UFUNCTION(BlueprintCallable, Category = "HUD|Pause")
	void TogglePauseMenu(bool bOpen);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "HUD|Pause")
	bool IsPauseMenuActive() const { return bPauseMenuActive; }

	UFUNCTION(BlueprintCallable, Category = "HUD|Pause")
	void SaveGameFromPauseMenu();

	/** S18-TUT: HUD panels register where they drew themselves so the tutorial
	 *  can grey the screen and cut a highlight hole around one of them. */
	/** S18-TUT: lazily loaded tutorial illustration (/Game/SquadAI/UI/Tutorial/T_Tut_*). */
	UPROPERTY(Transient)
	mutable TMap<FName, TObjectPtr<UTexture2D>> TutorialIllustrations;   // S26-TUTFEEL: filled lazily from const measure paths

	UPROPERTY(Transient)
	mutable TMap<FName, TObjectPtr<UTexture2D>> UITextureCache;             // S26-TUT3D: Steel/Brass surfaces & S27-REFUI icons/plates

	UTexture2D* GetTutorialIllustration(FName Key) const;   // S26-TUTFEEL: const - the layout measure needs it

	// S26-TUT3D: cached soft load for the generated surface materials (Steel,
	// Brass). Same LoadTextureSafe pattern as the illustrations.
	UTexture2D* GetUITexture(FName Key) const;

	/** S26-TUT3D: bevelled display type - a light catch on the top left, a
	 * dark extrude to the bottom right, the ink in between. Three bounded
	 * passes; centred/right-aligned boxes stay aligned because the whole box
	 * shifts, not the text inside it. */
	void DrawFarsiText3D(const FString& Text, const FLinearColor& Color, float X, float Y,
		float MaxWidth, UFont* Font, float PreferredScale, bool bCenterHorizontal,
		bool bRightAlign, float BoxHeight, float Depth);

	// S26-TUTFEEL: the card's entrance - a new beat slides its card up into
	// place over 0.30 s (smoothstep) instead of popping in fully formed.
	int32 TutLastStepSeen = -1;
	float TutCardIntroT = 1.f;

	// ===== S18-FEED: combat event ticker =====
	/** What kind of event a feed line is, which drives its colour and glyph. */
	enum class ESquadAIFeedKind : uint8 { Kill, Ally, Objective, Supply, Warning };

	struct FSquadAIFeedEntry
	{
		FString Text;
		ESquadAIFeedKind Kind = ESquadAIFeedKind::Objective;
		float SpawnTime = 0.f;
	};

	/** Push a line onto the combat feed (top-right, under the compass). */
	void AddFeedEntry(const FString& Text, ESquadAIFeedKind Kind);

	/** Draw and age the combat feed. */
	void DrawCombatFeed(float SW, float SH, UFont* Font);

	/** S18-FEED: how long a line stays before fading, seconds. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "SquadAI|Feed")
	float FeedEntryLifetime = 6.0f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "SquadAI|Feed")
	bool bShowCombatFeed = true;

	/**
	 * S18-INTRO3: true while a note / mission-briefing reader card is on
	 * screen. The scripted intro waits for this so the briefing and the
	 * major's walk never talk over each other.
	 */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|HUD")
	bool IsReaderCardOpen() const;

	/** S18-TITLE: draw the opening location/date stamp (no-op once finished). */
	void DrawLocationTitleCard(float SW, float SH, UFont* Font);

	/** S18-TITLE: top line of the stamp — the place. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "SquadAI|Title Card")
	FString TitleCardPlaceFa = TEXT("دهلاویه — خوزستان");

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "SquadAI|Title Card")
	FString TitleCardPlaceEn = TEXT("DEHLAVIEH — KHUZESTAN");

	/** S18-TITLE: second line — date / operation. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "SquadAI|Title Card")
	FString TitleCardDateFa = TEXT("فروردین ۱۳۶۱ — عملیات فتح‌المبین");

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "SquadAI|Title Card")
	FString TitleCardDateEn = TEXT("MARCH 1982 — OPERATION FATH-OL-MOBIN");

	/** S18-TITLE: third line — the unit. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "SquadAI|Title Card")
	FString TitleCardUnitFa = TEXT("گردان تکاور — خط مقدم");

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "SquadAI|Title Card")
	FString TitleCardUnitEn = TEXT("COMMANDO BATTALION — FORWARD LINE");

	/** S18-TITLE: set false to suppress the stamp entirely. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "SquadAI|Title Card")
	bool bShowTitleCard = true;

	/** S18-TUTGUIDE: the guide's cinematic subtitle band + speaker chevron. */
	void DrawGuideSubtitle(float ScreenW, float ScreenH, UFont* Font, bool bEnglish);

	/** S18-TUT4: draw one keycap glyph; returns the width it used. */
	float DrawKeycap(float X, float Y, const FString& Label, float S, UFont* Font, float Height);

	/**
	 * S18-PROMPT: one visual language for every world prompt (interact, revive,
	 * resupply, turret). Keycap glyph + label on a soft plate, optional hold
	 * ring. Centred on ScreenPos. Returns the plate width.
	 */
	float DrawWorldPrompt(const FVector2D& ScreenPos, const FString& KeyLabel, const FString& Text,
		UFont* Font, float Alpha = 1.f, float HoldPct = -1.f, bool bActive = true,
		const FString& SubText = FString());

	/** S18-PROMPT: strip "[E]", "[Hold E]" etc. out of legacy prompt strings. */
	static FString StripKeyTokens(const FString& In);

	/**
	 * S18-PERF: DrawHUD used to run a full-level TActorIterator per prompt
	 * family EVERY FRAME (7 sweeps over every actor in the map). This returns a
	 * cached, weak-pointer list per class, rescanned at most every
	 * RefreshSeconds. Dead entries are skipped by the callers.
	 */
	// S19-CONST: const - it refreshes a cache (ActorCaches is mutable), nothing observable.
	const TArray<TWeakObjectPtr<AActor>>& GetCachedActorsOfClass(TSubclassOf<AActor> Class, float RefreshSeconds = 1.0f) const;

private:
	struct FSquadAIActorCache
	{
		TArray<TWeakObjectPtr<AActor>> Actors;
		float NextRefreshTime = -1.f;
	};
	mutable TMap<TObjectPtr<UClass>, FSquadAIActorCache> ActorCaches; // S19-CONST: refreshed from const HUD helpers

	/** S18-FEED: live ticker lines, oldest first. */
	TArray<FSquadAIFeedEntry> FeedEntries;

	/** S18-TITLE: COD-style location stamp shown once when the level opens. */
	float TitleCardStartTime = -1.f;
	bool bTitleCardDone = false;

	/** S18-FEEL: time the HUD first drew, for the panel entrance animation. */
	float HUDEntranceStartTime = -1.f;

	/** S18-PERF: waypoint occlusion is traced at 10 Hz, not once per frame. */
	float TutWaypointOcclusionNextTrace = -1.f;
	bool bTutWaypointOccludedCache = false;

public:

	void RegisterTutorialUIRect(FName ElementId, float X, float Y, float W, float H);

	/** S18-SAVE: save into a specific numbered slot (0-based) from the pause menu. */
	UFUNCTION(BlueprintCallable, Category = "SquadAI|SaveLoad")
	void SaveGameToSlotFromPauseMenu(int32 SlotIndex);

	/** S18-SAVE: open/close the in-game slot picker. */
	UFUNCTION(BlueprintCallable, Category = "SquadAI|SaveLoad")
	void TogglePauseSaveSlotPanel(bool bOpen);

	UFUNCTION(BlueprintCallable, Category = "HUD|Pause")
	void ResumeGameFromPauseMenu();

	UFUNCTION(BlueprintCallable, Category = "HUD|Pause")
	void RestartLevelFromPauseMenu();

	UFUNCTION(BlueprintCallable, Category = "HUD|Pause")
	void QuitToMainMenuFromPauseMenu();

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Pause")
	FName MainMenuLevelName = FName(TEXT("M_MainMenu"));

	UFUNCTION(BlueprintCallable, Category = "HUD|Pause")
	void QuitToDesktopFromPauseMenu();

	// ===== E-KEY INTERACTION ARBITRATION =====
	// One E press = one interaction. World actors (crate/kit/station/turret-enter) yield
	// whenever a revive is available, and the first claimant consumes the press frame.
	bool TryConsumeWorldEPress();
	bool WasWorldEConsumedThisFrame() const { return WorldEConsumedFrame == GFrameCounter; }
	bool IsReviveAvailable() const { return bReviveAvailableCache; }

	// ===== MENU TRAVEL VERIFICATION =====
	bool DoesMapAssetExist(FName MapName) const;
	void VerifyMenuTravel();

	// ===== TACTICAL INVENTORY & BACKPACK =====
	UFUNCTION(BlueprintCallable, Category = "HUD|Inventory")
	void ToggleInventory(bool bOpen);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "HUD|Inventory")
	bool IsInventoryOpen() const { return bInventoryOpen; }

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Inventory")
	TObjectPtr<UTexture2D> ItemPocketQuranTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Inventory")
	TObjectPtr<UTexture2D> ItemPocketRadioTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Inventory")
	TObjectPtr<UTexture2D> ItemCombatWalletTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Inventory")
	TObjectPtr<UTexture2D> ItemFirstAidPouchTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Inventory")
	TObjectPtr<UTexture2D> ItemCanteenTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Inventory")
	TObjectPtr<UTexture2D> ItemDogTagTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Inventory")
	TObjectPtr<UTexture2D> FallenNotesArtwork;

	// S25-BUILD: the zone's completion code calls this - it was private and the
	// reader's build died on C2248 (our offline harnesses never compile the zone).
	void ShowDebriefCard(const FString& MissionTitle, const FMissionDebriefFacts& Facts);   // S23-BRIEF: the act-complete card

private:
	// Global readability multiplier for all bounded HUD text (auto-fit, never overflows).
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HUD|Fonts", meta = (AllowPrivateAccess = "true"))
	float HUDFontScale = 1.15f;

	// B6-14: resolution scale for the gameplay HUD (menu-HUD parity: clamp(ClipY/1080)).
	float GameUIScale = 1.f;

	// E-arbitration state (see TryConsumeWorldEPress).
	uint64 WorldEConsumedFrame = 0;
	bool bReviveAvailableCache = false;

	// B6-15: per-frame shaped-text cache (cleared each DrawHUD) + throttled guidance samples.
	mutable TMap<FString, FString> ShapedTextFrameCache; // S19-CONST: filled from const measuring helpers

	// S17-NOTE: fallen-note reading overlay state.
	FString ActiveNoteTitle;
	TArray<FString> ActiveNoteLines;
	TArray<FMissionSection> BriefingSections;   // S23-BRIEF: staged sections (empty = plain card)
	bool bActiveCardIsDebrief = false;        // S23-BRIEF: brass palette + grade stamp
	FString DebriefGradeLetter;               // S23-BRIEF: the stamp that slams in
	FString ActiveNoteCounter;
	float NoteDisplayStartTime = -1.f;
	float NoteDisplayEndTime = -1.f;
	void DrawFallenNoteOverlay(float SW, float SH, UFont* Font);
	void DrawMissionBriefingOverlay(float SW, float SH, UFont* Font);   // S23-BRIEF: staged + typewriter

	// S17-ALRT: localized top-center banners for MissionZone.OnMissionAlert keys.
	bool bMissionAlertsBound = false;
	FString AlertBannerText;
	FLinearColor AlertBannerColor = FLinearColor::White;
	float AlertBannerStartTime = -1.f;
	float AlertBannerEndTime = -1.f;
	void BindMissionZoneAlerts();
	/** S19-MISSUI: the banner reserves its own row from the shared top-centre
	 *  lane, so it can no longer land on the defend countdown or on the tutorial's
	 *  header strip (it used to be pinned at a flat 92 px). */
	void DrawMissionAlertBanner(float SW, float SH, UFont* Font);

	// S19-DEATHPROMPT
	FString DeathPromptTitle;
	FString DeathPromptSub;
	float DeathPromptStartTime = -1.f;
	float DeathPromptEndTime = -1.f;
	void DrawDeathPrompt(float SW, float SH, UFont* Font);
	UFUNCTION()
	void OnMissionZoneAlertReceived(class AMissionZone* Mission, FString AlertKey);

	// S17-STORY: briefing-card flavor of the note overlay + deployment easing.
	bool bActiveCardIsBriefing = false;
	FText PendingStoryTitle;
	FText PendingStoryBody;
	float PendingStoryDuration = 12.f;
	float PostVeilFadeStartTime = -1.f;
	bool bOnboardingShown = false;
	float OnboardingStartTime = -1.f;
	void OnDeploymentVeilDismissed();
	void DrawOnboardingHints(float SW, float SH, UFont* Font);
	void DrawPostVeilFade(float SW, float SH);
	TArray<FVector> CachedGuidanceSamples;
	float GuidanceSampleTimer = 0.f;

	// Menu-travel verification (see QuitToMainMenuFromPauseMenu).
	// G-4: observed pack max-HP scale per health component (max-read fails on odd scales).
	TMap<TWeakObjectPtr<UActorComponent>, double> PackMaxHPByComp;
	FName PendingMenuTravelTarget = NAME_None;
	FTSTicker::FDelegateHandle MenuTravelVerifyHandle;

	float TimeSinceRefresh = 0.f;
	TWeakObjectPtr<AQuestChain> CachedChain;
	TWeakObjectPtr<AActor> CachedLeader;
	TWeakObjectPtr<APawn> CachedPlayerPawn;
	TWeakObjectPtr<UActorComponent> CachedPlayerPackHealth;
	TArray<FMinimapSoldierDot> CachedSoldierDots;
	FVector LastMinimapCaptureLoc = FVector::ZeroVector;
	FTimerHandle MinimapCaptureTimer;

	// Overlays & Feedback State
	TArray<FDamageHitIndicator> ActiveDamageIndicators;
	float HitMarkerTimeRemaining = 0.f;
	float HitMarkerDuration = 0.25f;
	bool bHitMarkerIsKill = false;
	bool bIsPlayerBurning = false;
	float PlayerSuppression = 0.f;

	// Guidance Vision State
	bool bGuidanceVisionActive = false;
	float GuidanceVisionBlendAlpha = 0.0f;

	void RebuildSoldierDots();
	void CaptureMinimapIfNeeded();
	UPROPERTY() TObjectPtr<USceneCaptureComponent2D> MinimapCapture;
	UPROPERTY() TObjectPtr<UTextureRenderTarget2D> MinimapRT;
	UPROPERTY() TObjectPtr<UMaterialInstanceDynamic> MinimapMID;
	bool bMinimapInitialized = false;
	TWeakObjectPtr<APawn> MinimapCapturePawn;

	AQuestChain* FindQuestChain();
	AActor* FindCachedLeader();
	void InitMinimap(APawn* PlayerPawn);
	void DrawMinimap(float CX, float CY, float R, const FVector& PL, float PY, UFont* Font);
	void DrawBorderIndicator(float CX, float CY, float R, const FVector& TargetLoc, const FVector& PlayerLoc, float PlayerYaw, UTexture2D* Icon, const FLinearColor& FallbackColor);
	void DrawIcon(UTexture2D* Icon, float X, float Y, float Size);
	void DrawCircleLines(const FLinearColor& C, float CX, float CY, float R, float T);
	void DrawFilledCircleArea(const FLinearColor& C, float CX, float CY, float R);
	UFont* GetHUDFont() const;

	// Visual Overlays & HUD widgets
	float GetPlayerHealthPercent(APawn* PlayerPawn);
	float GetPlayerArmorPercent(APawn* PlayerPawn);
	float GetPlayerStaminaPercent(APawn* PlayerPawn, float DeltaTime);
	float GetActorHealthPercent(AActor* Actor);
	void DrawLowHealthVignette(float ScreenW, float ScreenH, float HealthPercent);
	void DrawFireBurnVignette(float ScreenW, float ScreenH, float DeltaTime);
	void DrawSuppressionVignette(float ScreenW, float ScreenH, float DeltaTime);
	void DrawDirectionalDamageIndicators(float CX, float CY, const FVector& PlayerLoc, float PlayerYaw, float DeltaTime);
	void DrawHitMarker(float CX, float CY, float DeltaTime);
	void DrawTacticalCompassRibbon(float CX, float StartY, float PlayerYaw, UFont* Font, const FVector& PlayerLoc);
	bool IsDefendBannerActive();
	void DrawTactical3DPings(UFont* Font, APawn* PlayerPawn);
	void DrawObjectiveGuidanceVision(float ScreenW, float ScreenH, float DeltaTime, APawn* PlayerPawn, UFont* Font);
	void DrawBattlefieldInteractionPrompts(UFont* Font, APawn* PlayerPawn);
	void DrawRadioChatterSubtitle(float ScreenW, float ScreenH, float DeltaTime, UFont* Font);
	void DrawSquadStatusPanel(float StartX, float StartY, UFont* Font, APawn* PlayerPawn);
	void DrawMissionObjectiveCard(float StartX, float StartY, AQuestChain* Chain, UFont* Font);
	void DrawTacticalWeaponStatusPlate(float ScreenW, float ScreenH, APawn* PlayerPawn, UFont* Font);
	void DrawAllyDownedAlertBanner(float ScreenW, float ScreenH, float DeltaTime, UFont* Font);
	void DrawChiseledTacticalBox(float X, float Y, float W, float H, const FLinearColor& FillColor, const FLinearColor& BorderColor, float Thickness = 1.0f, float Chamfer = 8.0f);

	// ---------------- S19-UI3D: bevelled panel primitive ------------------
	/**
	 * A panel that reads as a physical plate rather than a flat rectangle:
	 *   * three-layer soft drop shadow (real depth, not one hard offset)
	 *   * smooth vertical gradient body
	 *   * embossed bevel - light on the top/left inner edge, dark bottom/right
	 *   * chamfered corners with mitred joins
	 *   * an accent bar down the leading edge with a soft bleed
	 *
	 * Canvas-only, so it costs no assets and works in every build.
	 */
	void DrawTacticalPlate3D(float X, float Y, float W, float H,
		const FLinearColor& BodyTop, const FLinearColor& BodyBottom,
		const FLinearColor& Accent, float Alpha = 1.f,
		float Chamfer = 10.f, float Bevel = 1.6f, float Shadow = 6.f);

	// ---------------- S19-UIBRACKET / S27-REFUI: reference HUD language ----------------
	// Matches lidar_didar/index.html & docs/REFUI_left.png + REFUI_right.png:
	// Semi-transparent charcoal-gunmetal tactical glass (.glass), warm metallic
	// sand hairline border, asymmetric corner brackets (19x2px glowing amber TL,
	// 15x2px sand-taupe TR/BR/BL), warm tactical amber (#e9953b) & copper-gold
	// (#ffd27a) accents, and high-contrast dark espresso ink (#21170f) on raised
	// copper-amber buttons and active keycaps.
	struct FSquadAIHUDPalette
	{
		static FLinearColor SRGB(uint8 R, uint8 G, uint8 B, float A = 1.0f)
		{
			FLinearColor C = FLinearColor::FromSRGBColor(FColor(R, G, B, 255));
			C.A = A;
			return C;
		}

		static FLinearColor PanelTop()     { return SRGB(13, 16, 16, 0.78f); }    // #0d1010 charcoal glass
		static FLinearColor PanelBottom()  { return SRGB(22, 25, 24, 0.68f); }    // #161918 gunmetal glass
		static FLinearColor BracketGold()  { return SRGB(233, 149, 59, 1.000f); } // #e9953b warm tactical amber
		static FLinearColor BracketTaupe() { return SRGB(169, 163, 149, 0.920f); }// #a9a395 metallic sand-taupe
		static FLinearColor PanelEdge()    { return SRGB(226, 216, 196, 0.420f); }// #e2d8c46b warm sand edge
		static FLinearColor Hairline()     { return SRGB(255, 255, 255, 0.145f); }// #ffffff25 inner hairline

		static FLinearColor WithAlpha(const FLinearColor& In, float A)
		{
			return FLinearColor(In.R, In.G, In.B, A);
		}

		static FLinearColor GoldText()     { return SRGB(255, 210, 122, 1.000f); }// #ffd27a warm gold
		static FLinearColor Warm()         { return SRGB(239, 182, 103, 1.000f); }// #efb667 warm amber-gold
		static FLinearColor Success()      { return SRGB(119, 199, 116, 1.000f); }// #77c774 tactical green
		static FLinearColor SuccessText()  { return SRGB(223, 243, 207, 1.000f); }// #dff3cf luminous green ink
		static FLinearColor ArmorBlue()    { return SRGB(100, 185, 229, 1.000f); }// #64b9e5 armor cyan-blue
		static FLinearColor ArmorText()    { return SRGB(215, 237, 247, 1.000f); }// #d7edf7 luminous cyan ink
		static FLinearColor CyanAlly()     { return SRGB(103, 212, 255, 1.000f); }// #67d4ff friendly ally cyan
		static FLinearColor Cyan()         { return SRGB(103, 212, 255, 1.000f); }// #67d4ff friendly ally cyan
		static FLinearColor Muted()        { return SRGB(155, 149, 139, 0.950f); }// #9b958b muted stone
		static FLinearColor Danger()       { return SRGB(229, 89, 63, 1.000f); }  // #e5593f alert red-orange
		static FLinearColor TextWhite()    { return SRGB(241, 238, 231, 1.000f); }// #f1eee7 warm paper-ivory
		static FLinearColor TextDim()      { return SRGB(185, 180, 170, 1.000f); }// #b9b4aa secondary stone-taupe
		static FLinearColor DarkInk()      { return SRGB(33, 23, 15, 1.000f); }   // #21170f dark espresso ink
	};

	/** Ensure low-res camera-synced scene capture RT for frosted-glass HUD backdrop blur. */
	void EnsureHUDBackdropBlur(APlayerController* PC, APawn* PlayerPawn);

	/** Draw real-time blurred backdrop behind a HUD element rect [X, Y, W, H] (backdrop-filter: blur(9px) saturate(.78)). */
	void DrawFrostedGlassBackdrop(float X, float Y, float W, float H, float Alpha = 1.0f);

	/** Draw crisp 1px screen-space outer border + 1px top inner specular highlight + 1px bottom inner shade. */
	void DrawCleanPanelBorder(float X, float Y, float W, float H, const FLinearColor& BorderCol, const FLinearColor& TopInnerCol, const FLinearColor& BotInnerCol, float S);

	/** Draw an anti-aliased 9-slice rounded-corner 3D beveled box using a 256x256 SDF UI surface texture
	 *  (UV slice margin = 48/256 = 0.1875, 16-texel outer shadow/glow pad + 32-texel inner rounded corner & bevel). */
	void Draw9SliceRoundedBox(float X, float Y, float W, float H, const FName& TexKey, float Alpha, float S,
		float CornerRadiusScale = 1.0f, bool bFrostedBlur = false, float BlurAlpha = 0.85f);

	/** Draw the four L-shaped corner brackets seen on every panel in the
	 *  reference. ArmLen is how far each arm runs along the edge. */
	void DrawCornerBrackets(float X, float Y, float W, float H, const FLinearColor& Color,
		float ArmLen, float Thickness);

	/** S27-REFUI: Asymmetric instrument corner brackets matching .glass in index.html
	 *  (19x2px glowing amber TL bracket + 15x2px metallic taupe TR/BR/BL brackets). */
	void DrawAsymmetricCornerBrackets(float X, float Y, float W, float H, float S, float Alpha = 1.0f);

	/** S27-REFUI: 3D machined metal housing/tile (.step, .mini, .stat, .weapons, .item). */
	void DrawMachinedMetalTile(float X, float Y, float W, float H, bool bCurrent, float Alpha, float S, bool bLeadingAmberBar = true);

	/** S27-REFUI: 3D bevelled circular/octagonal step number medallion (.step .n). */
	void Draw3DRaisedMedallion(float CX, float CY, float R, const FString& Label, bool bCurrent, bool bCompleted, float Alpha, float S, UFont* Font);

	/** S27-REFUI: 3D raised copper-amber CTA button (.focus-bottom .next) with dark espresso ink (#21170f). */
	void Draw3DRaisedAmberButton(float X, float Y, float W, float H, const FString& Label, bool bHovered, float Alpha, float S, UFont* Font);

	/** S27-REFUI: Recessed 3D segmented vitals meter (.stat.health .meter / .stat.armor .meter). */
	void DrawRecessedSegmentedMeter(float X, float Y, float W, float H, float Pct, bool bIsArmor, float Alpha, float S);

	/** S27-REFUI: 60x58px 3D physical keycap housing (.bigkey) using T_UI_KeycapFrame. */
	void DrawBigKeycap3D(float X, float Y, float W, float H, const FString& KeyLabel, bool bHeld, float Alpha, float S, UFont* Font);

	/** S27-REFUI: Top-left Operation Masthead Plaque (.operation-banner). */
	void DrawOperationBanner(float X, float Y, float W, float H, float ProgressPct, bool bEnglish, float Alpha, float S, UFont* Font);

	/** S27-REFUI: Left 5-Step Tutorial Sequence Card (.tutorial). */
	void DrawTutorialStepsPanel(float X, float Y, float W, int32 ActiveStageOneBased, bool bEnglish, float Alpha, float S, UFont* Font, float& OutBottomY);

	/** S27-REFUI: Left-middle Focus Step Instruction Card (.focus-instruction). */
	void DrawFocusInstructionCard(float X, float Y, float W, int32 ActiveStageOneBased, const FString& Title, const FString& Body, bool bEnglish, float Alpha, float S, UFont* Font, float MouseX, float MouseY, bool bLeftClick, bool& bOutContinueClicked, float& OutBottomY);

	/** S27-REFUI: Right-lower Training Progress 3-Tile Mini-Card (.training-panel). */
	void DrawTrainingProgressPanel(float X, float Y, float W, int32 ActiveStageOneBased, bool bEnglish, float Alpha, float S, UFont* Font);

	/** S27-REFUI: Bottom-center Movement / Action Keycap Hint Banner (.movehint). */
	void DrawMoveHintBanner(float CX, float BottomY, const FString& Headline, const FString& Subline, const FString& KeyToken, bool bEnglish, float Alpha, float S, UFont* Font, APlayerController* PC);

	/** S27-REFUI: Top-Right Squad Portrait Cards (.squad) & Elapsed Clock/Gear Box (.elapsed). */
	void DrawTopRightSquadAndClockCluster(float RightEdgeX, float TopY, float S, UFont* Font, APawn* PlayerPawn, float& OutMinimapCX, float& OutMinimapCY, float& OutMinimapR);

	/** S19-UI3D: a single raised keycap glyph. Returns the width it occupied so
	 *  callers can lay a row of them out. (Named ...Glyph to avoid colliding
	 *  with the older DrawKeycap below, which has a different signature.) */
	float DrawKeycapGlyph(float X, float Y, float H, const FString& Label, UFont* Font,
		const FLinearColor& Tint, bool bHeld = false);

	/** S19-TUTCOLOR: the width DrawKeycapGlyph will occupy for a label at height
	 *  H. One function measures a cap and the same function draws it, so a row
	 *  that was laid out with this cannot be drawn somewhere else by a pixel. */
	static float MeasureKeycapGlyphW(const FString& Label, float H)
	{
		const int32 CharCount = Label.StartsWith(TEXT("[")) ? Label.Len() : (Label.Len() + 2);
		return FMath::Max(H * 1.15f, CharCount * H * 0.34f + H * 0.46f);
	}

	/** S19-UI3D: lay out a hint string such as "W A S D" or "[E] interact" as a
	 *  row of raised keycaps with plain text between them. */
	void DrawKeycapGlyphRow(float X, float Y, float H, const FString& Hint, UFont* Font,
		const FLinearColor& Tint, float MaxWidth);
	void DrawWeaponSilhouette(const FString& WeaponName, float X, float Y, float Scale, const FLinearColor& Color);
	void DrawDynamicTacticalReticle(float CX, float CY, APawn* PlayerPawn, float DeltaTime, UFont* Font);
	void DrawMortarDangerZones(APawn* PlayerPawn, float DeltaTime, UFont* Font);
	void DrawMortarTargetingMarker(APawn* PlayerPawn, float DeltaTime, UFont* Font);

	// ---------------- S19-TUT: grenade throw preview ----------------------
	/**
	 * Draws where a grenade thrown right now would land: a dotted ballistic
	 * arc from the hand, a pulsing ring on the ground at the impact point and
	 * the throw distance in metres. Drawn on the canvas, so it needs no meshes,
	 * no Niagara systems and no materials, and it works in every build.
	 *
	 * Enabled by UTacticalGrenadeComponent::bShowThrowPreview, or for the
	 * duration of the grenade lesson by the tutorial subsystem.
	 */
	void DrawGrenadeThrowPreview(APawn* PlayerPawn, UFont* Font);

	/** S19-ELITE: everything commander-facing - boss bar, world marker, aura ring, the
	 *  medic's beam. Called from DrawHUD, drawn in canvas space only. */
	void DrawCommanderLayer(float SW, float SH, UFont* Font);

	/** The nearest live commander to the player, or nullptr. */
	AEnemyCommander* FindNearestCommander() const;

	/** One commander's marker + aura ring + heal beam. */
	void DrawCommanderMarker(AEnemyCommander* Commander, APlayerController* PC, float S, UFont* Font);

	// ===== S19-ELITE: the commander layer =====

	/** Boss health bar at the top of the screen while a commander is alive and near. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|HUD|Elite", meta = (AllowPrivateAccess = "true"))
	bool bShowCommanderBar = true;

	/** Draw the bar for a commander within this distance (cm). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|HUD|Elite", meta = (AllowPrivateAccess = "true", ClampMin = "500.0"))
	float CommanderBarMaxDistance = 15000.f;

	/** World-space marker over the commander (diamond + label, clamped to the screen edge
	 *  when he is off-screen). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|HUD|Elite", meta = (AllowPrivateAccess = "true"))
	bool bShowCommanderMarker = true;

	/** Faint ring on the ground showing his command aura - "kill him and they weaken". */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|HUD|Elite", meta = (AllowPrivateAccess = "true"))
	bool bShowCommanderAuraRing = true;

	/** Green beam between an assistant and the commander while he is being healed. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|HUD|Elite", meta = (AllowPrivateAccess = "true"))
	bool bShowCommanderHealBeam = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|HUD|Elite", meta = (AllowPrivateAccess = "true"))
	FLinearColor CommanderMarkerColor = FLinearColor(1.f, 0.30f, 0.16f, 0.95f);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|HUD|Elite", meta = (AllowPrivateAccess = "true"))
	FLinearColor CommanderAssistantColor = FLinearColor(1.f, 0.68f, 0.22f, 0.95f);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|HUD|Elite", meta = (AllowPrivateAccess = "true"))
	FLinearColor CommanderHealBeamColor = FLinearColor(0.30f, 0.95f, 0.45f, 0.85f);

	/** S19-TUT: master switch for the arc (independent of the tutorial). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|HUD|Grenade", meta = (AllowPrivateAccess = "true"))  // S19-UHTFIX: UHT rejects BlueprintReadWrite on private members
	bool bDrawGrenadeThrowPreview = true;

	/** S19-UI3D / S27-REFUI: show the 5-step training sequence panel (.tutorial)
	 *  and right-side training mini-panel (.training-panel) matching index.html. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|HUD|Tutorial", meta = (AllowPrivateAccess = "true"))  // S19-UHTFIX: UHT rejects BlueprintReadWrite on private members
	bool bShowTutorialChecklist = true;

	/** S19-TUT: colour of the arc dots near the hand. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|HUD|Grenade", meta = (AllowPrivateAccess = "true"))  // S19-UHTFIX: UHT rejects BlueprintReadWrite on private members
	FLinearColor GrenadeArcNearColor = FLinearColor(0.55f, 1.0f, 0.75f, 0.95f);

	/** S19-TUT: colour of the arc dots at the far end. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|HUD|Grenade", meta = (AllowPrivateAccess = "true"))  // S19-UHTFIX: UHT rejects BlueprintReadWrite on private members
	FLinearColor GrenadeArcFarColor = FLinearColor(1.0f, 0.72f, 0.25f, 0.55f);

	/** S19-TUT: colour of the landing ring. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|HUD|Grenade", meta = (AllowPrivateAccess = "true"))  // S19-UHTFIX: UHT rejects BlueprintReadWrite on private members
	FLinearColor GrenadeImpactRingColor = FLinearColor(1.0f, 0.55f, 0.15f, 0.95f);

	/** S19-TUT: radius of the landing ring, cm. ~45 cm is a grenade's lethal-ish
	 *  footprint on sand. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|HUD|Grenade", meta = (AllowPrivateAccess = "true", ClampMin = "10.0", ClampMax = "400.0"))  // S19-UHTFIX: UHT rejects BlueprintReadWrite on private members
	float GrenadeImpactRingRadiusCm = 55.f;

	/** S19-TUT: draw a dot every Nth path sample (1 = solid line, 3 = dotted). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|HUD|Grenade", meta = (AllowPrivateAccess = "true", ClampMin = "1", ClampMax = "8"))  // S19-UHTFIX: UHT rejects BlueprintReadWrite on private members
	int32 GrenadeArcDotStride = 2;

	/** S19-TUT: show the throw distance in metres under the ring. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|HUD|Grenade", meta = (AllowPrivateAccess = "true"))  // S19-UHTFIX: UHT rejects BlueprintReadWrite on private members
	bool bShowGrenadeThrowDistance = true;

	/** S19-TUT: how long to keep the last arc on screen after the preview turns
	 *  off (seconds). Smooths the transition instead of popping. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|HUD|Grenade", meta = (AllowPrivateAccess = "true", ClampMin = "0.0", ClampMax = "1.0"))  // S19-UHTFIX: UHT rejects BlueprintReadWrite on private members
	float GrenadePreviewFadeOutSeconds = 0.25f;

	// ===== S19-GRENARC: the aiming arrow =====
	/** Follow the bounces after the first contact with a faded tail: a grenade that
	 *  lands 4 m short and rolls 6 m further is a different throw. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|HUD|Grenade", meta = (AllowPrivateAccess = "true"))
	bool bGrenadePreviewDrawBounces = true;

	/** Colour and thickness of that faded tail. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|HUD|Grenade", meta = (AllowPrivateAccess = "true"))
	FLinearColor GrenadeBounceTailColor = FLinearColor(1.f, 0.62f, 0.22f, 0.55f);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|HUD|Grenade", meta = (AllowPrivateAccess = "true", ClampMin = "0.5", ClampMax = "6.0"))
	float GrenadeBounceTailThickness = 1.3f;

	/** Draw a chevron every Nth arc sample (the "angry bird" arrowhead rhythm). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|HUD|Grenade", meta = (AllowPrivateAccess = "true", ClampMin = "0", ClampMax = "20"))
	int32 GrenadeArrowChevronStride = 5;

	/** Size of those chevrons and of the arrowhead, in UI pixels at scale 1. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|HUD|Grenade", meta = (AllowPrivateAccess = "true", ClampMin = "2.0", ClampMax = "40.0"))
	float GrenadeArrowChevronSize = 9.f;

	/** Tint the reticle red while a live enemy stands inside the blast radius. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|HUD|Grenade", meta = (AllowPrivateAccess = "true"))
	bool bGrenadePreviewDangerTint = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|HUD|Grenade", meta = (AllowPrivateAccess = "true"))
	FLinearColor GrenadeDangerTintColor = FLinearColor(1.f, 0.17f, 0.12f, 1.f);

	/** Soft dark border while aiming (COD-style focus). No lighting or post-process
	 *  is touched - this is drawn by the HUD, in canvas space. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|HUD|Grenade", meta = (AllowPrivateAccess = "true"))
	bool bGrenadePreviewAimVignette = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|HUD|Grenade", meta = (AllowPrivateAccess = "true", ClampMin = "0.0", ClampMax = "1.0"))
	float GrenadeAimVignetteStrength = 0.35f;

	/** The small hint block near the reticle ("release to throw" + the numbers). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|HUD|Grenade", meta = (AllowPrivateAccess = "true"))
	bool bGrenadePreviewLegend = true;

	// --- S19-TUT: runtime state (not designer-facing) ---
	/** Current fade weight of the arc, 0..1. Rises while wanted, falls after. */
	float GrenadePreviewAlpha = 0.f;
	/** Last computed arc, kept for the fade-out. */
	TArray<FVector> GrenadePreviewPath;
	FVector GrenadePreviewImpact = FVector::ZeroVector;
	bool bGrenadePreviewImpacted = false;
	// --- S19-GRENARC: runtime state ---
	/** Bounce tail after the first contact (faded). */
	TArray<FVector> GrenadePreviewTail;
	/** The full model result: contact point, detonation point/time, bounce count. */
	FGrenadeFlightResult GrenadePreviewResult;
	// S19-GRENBLAST: the INPUTS that produced that result. BlastRadius and bIsFrag live on the
	// params struct, not on the result - the danger tint and the blast ring used to read them
	// off the result, which does not have those members (three C2039s). Captured every frame
	// the preview runs, from the grenade the player is actually holding.
	/** Inputs of the last preview (blast radius, frag/smoke), for the HUD's threat tint. */
	FGrenadeFlightParams GrenadePreviewParams;
	/** Was a real aim session (not the tutorial preview) running last frame? */
	bool bGrenadePreviewWasAiming = false;
	void DrawDeploymentVeil(float ScreenW, float ScreenH, float DeltaTime, UFont* Font);
	void DrawPauseMenu(float ScreenW, float ScreenH, float DeltaTime, UFont* Font);

	/** S18-TUT: full-screen tutorial layer — grey veil, highlight cut-out,
	 *  instruction card, skip prompt and the completed-step checklist. */
	void DrawTutorialOverlay(float ScreenW, float ScreenH, float DeltaTime, UFont* Font);

	// =====================================================================
	//  S19-TUTLAYOUT: the tutorial UI's geometry, in one place.
	//
	//  Every piece of tutorial chrome used to compute its own pixel offsets
	//  from its own anchor: the card was a fixed 190 px slab at screen centre,
	//  the key chip hung off "card bottom + 56", the step pips off "+20", the
	//  subtitle band off "screen bottom - 118", the skip button off the
	//  top-right corner (which is where the weapon plate is), the help line off
	//  "bottom - 62". Nothing shared a width, a margin or a centre line, and
	//  three pairs of them overlapped. Body text had no wrapping at all, so a
	//  long line was shrunk to fit its box instead of being set on two lines -
	//  which is why the card read as a mostly-empty plate with one tiny line
	//  of text in it.
	//
	//  Now: ONE rail (a single width and centre line) that every element
	//  aligns to, and ONE vertical stack for the bottom chrome whose positions
	//  are derived from measured text heights, bottom-up, with the radio slot
	//  reserved. Overlap is impossible by construction rather than by luck.
	// =====================================================================

	/** One measure of a wrapped text block. */
	struct FTutorialTextBlock
	{
		TArray<FString> Lines;
		float LineH = 0.f;    // height of one line at the requested scale
		float BlockH = 0.f;   // total height, including line spacing
		bool IsEmpty() const { return Lines.Num() == 0; }
	};

	/** Greedy word wrap, measured with the SAME text sizer the drawing uses
	 *  (so a wrapped line is never shrunk by the bounded draw). Splits on
	 *  spaces and on explicit \n; never splits a word. Persian is wrapped on
	 *  the logical string and shaped per line at draw time, which is correct
	 *  because a word is never cut in half. */
	FTutorialTextBlock WrapTutorialText(const FString& Text, UFont* Font, float Scale,
		float MaxWidth, int32 MaxLines = 6) const;

	/** Draws a wrapped block, left-aligned at X, top at Y. Returns the height used. */
	float DrawTutorialTextBlock(const FTutorialTextBlock& Block, const FLinearColor& Color,
		float X, float Y, float MaxWidth, UFont* Font, float Scale, bool bCentre = false);

	/** The rail: one width, one centre line, clamped against the top-corner HUD
	 *  blocks (objective card at 30/48, weapon plate 360 wide from the right edge)
	 *  so a centred element can never overlap them at any resolution. */
	void ComputeTutorialRail(float ScreenW, float S);

	/** The bottom stack. Heights in, positions out: the radio slot (and its gap)
	 *  is reserved at the bottom, then help / banner-or-chip / subtitle /
	 *  onboarding are stacked upward with a fixed gap, each one measured. */
	void ComputeTutorialStack(float ScreenH, float S, float HelpBlockH, float BannerBlockH,
		float SubtitleBlockH);

	/** The rail plate shared by the header, the banner and the card. */
	void DrawTutorialPlate(float X, float Y, float W, float H, float Alpha, float S, bool bBrackets);

	/** The "you are clearly stuck" line for a beat (empty when the beat has no
	 *  escalation text). One place, so the layout can MEASURE it before the stack
	 *  is built instead of guessing its height. */
	FString BuildTutorialHelpText(const struct FSquadAITutorialBeat& Beat, bool bEnglish) const;

	/** Height of the guide's subtitle block this frame (0 when the guide is not
	 *  talking), measured with the same wrap the drawing uses. */
	float MeasureGuideSubtitleBlock(UFont* Font, bool bEnglish) const;

	/** The one header strip: step pips + title + counter on the left, the skip
	 *  button at the right end of the same rail. Replaces the old top-right skip
	 *  button (which sat on the weapon plate) and the old floating pips strip. */
	void DrawTutorialHeaderStrip(float ScreenW, float ScreenH, float S, UFont* Font,
		const FString& Title, int32 StepIndex, int32 StepCount, bool bEnglish,
		float MouseX, float MouseY, bool bLeftClick, bool& bOutSkipPressed);

	/** S18-SAVE: slot picker drawn inside the pause card. */
	void DrawPauseSaveSlotPanel(float CardX, float CardY, float CardW, float CardH, float S,
		float MouseX, float MouseY, bool bLeftClick, UFont* Font);
	void DrawInventoryScreen(float ScreenW, float ScreenH, float DeltaTime, UFont* Font, APawn* PlayerPawn);

	UTexture2D* GetHUDWeaponIcon(const FString& WeaponName) const;

	float AllyDownedAlertTime = 0.0f;
	FText LastDownedAllyName;
	FVector LastDownedAllyLocation = FVector::ZeroVector;
	float ReticleSpreadCurrent = 14.0f;
	TArray<FVector2D> GuidanceDustMotes;
	TArray<FVector2D> GuidanceDustVelocities;

	// Mortar incoming warnings & aiming
	struct FIncomingMortarThreat
	{
		FVector ImpactCenter = FVector::ZeroVector;
		float BlastRadius = 750.0f;
		float TimeRemaining = 2.5f;
		float TotalDuration = 2.5f;
		TArray<FVector> CachedRingPoints; // B6-15: terrain-snapped ring, refreshed at 10 Hz.
		float RingSnapTimer = 0.f;
		// S13-FX: real world-space ground decal for the danger zone.
		TWeakObjectPtr<class UDecalComponent> Decal;
		TWeakObjectPtr<class UMaterialInstanceDynamic> DecalMID;
	};

	/** S13-FX: spawn (once) the ground decal for a mortar threat. Returns null if
	 *  the decal material is missing, in which case the caller falls back to the
	 *  flat canvas ring. */
	class UDecalComponent* EnsureMortarDecal(FIncomingMortarThreat& Threat);
	TArray<FIncomingMortarThreat> ActiveMortarThreats;
	bool bMortarAimingActive = false;
	FVector MortarAimTargetLocation = FVector::ZeroVector;

	// Deployment Warmup Veil & Loading Progress
	// S19-INSTANT: the bar the menu had already filled is adopted once, on the veil's
	// first frame after the travel, so it continues instead of restarting at zero.
	bool bDeploymentVeilAdoptedHandoff = false;
	float InitialDeploymentVeilTime = 2.5f;
	bool bDeploymentVeilActive = true;
	bool bDeploymentVeilReadyToDeploy = false;
	float DeploymentProgress = 0.0f;
	float EnterPromptPulseTimer = 0.0f;

	// Tactical Pause Menu State
	bool bPauseMenuActive = false;
	bool bPauseSaveSlotPanelActive = false; // S18-SAVE
	/** S18-TUT: screen rect of each named HUD element, refreshed as it draws. */
	TMap<FName, FVector4> TutorialUIRects;

	// ---- S19-TUTLAYOUT: the geometry computed once per frame, then drawn from ----
	float TutRailX = 0.f;
	float TutRailW = 0.f;
	float TutHeaderY = 0.f;
	float TutHeaderH = 0.f;
	float TutHelpY = -1.f;        // -1 = the help line is not drawn this frame
	float TutChipY = -1.f;        // -1 = no bottom chip (cinematic banner or a paused card owns it)
	float TutChipH = 0.f;
	float TutBannerY = -1.f;      // -1 = no cinematic banner this frame
	float TutBannerH = 0.f;
	float TutSubtitleY = -1.f;    // -1 = the guide is not talking
	float TutSubtitleH = 0.f;
	float TutStackTopY = -1.f;    // top edge of the bottom stack (onboarding sits above it)
	bool bTutLayoutValid = false;

	// ---- S19-MISSUI: the top-centre notice lane -------------------------------
	// The defend countdown, the route-guidance banner and the mission alert banner
	// all used to pick their own Y in the same 46..128 px band - under the compass,
	// straight through the tutorial's header strip whenever the tutorial was up.
	// They now ask for a slot: ReserveTopNotice(H) returns the next free Y for a
	// strip H tall, and records how far down the lane now reaches. The tutorial's
	// card floor and its progress pop read the same number, so the whole top of
	// the screen is one stack instead of six independent constants.
	float TopNoticeBottomY = -1.f;   // -1 = nothing is using the lane this frame
	float ReserveTopNotice(float Height);

	/** S19-MISSUI: the rail is the centre strip the tutorial draws in, and it is
	 *  also the thing every other centre-column element has to keep clear of.
	 *  Pure geometry, so anything can ask for it (the mission stamp does, whether
	 *  or not the tutorial is running). */
	static void ComputeTutorialRailMetrics(float ScreenW, float S, float& OutX, float& OutW);

	/** S19-MISSUI: Y of the onboarding reel card, -1 when it is not on screen.
	 *  The briefing note places itself above it. */
	float OnboardingCardY = -1.f;
	int32 PauseSaveSlotHoverIndex = -1;     // S18-SAVE
	int32 PauseMenuHoveredButton = -1;
	FString PauseNotificationMessage;
	float PauseNotificationTimer = 0.0f;
	FLinearColor PauseNotificationColor = FLinearColor::Green;

	// Tactical Inventory State
	bool bInventoryOpen = false;
	int32 InventoryActiveTab = 0; // 0: Weapons, 1: Notes, 2: Radio, 3: Quran, 4: Wallet, 5: Supplies
	float RadioWaveformAnimTimer = 0.0f;

	// Frosted-Glass Backdrop Blur Capture State
	UPROPERTY(Transient)
	TObjectPtr<UTextureRenderTarget2D> HUDBlurRT = nullptr;

	UPROPERTY(Transient)
	TObjectPtr<USceneCaptureComponent2D> HUDBlurCapture = nullptr;

	UPROPERTY(Transient)
	TObjectPtr<UMaterialInstanceDynamic> HUDBlurMID = nullptr;

	TWeakObjectPtr<APawn> HUDBlurCapturePawn;
	FVector LastHUDBlurCamLoc = FVector::ZeroVector;
	FRotator LastHUDBlurCamRot = FRotator::ZeroRotator;
	double LastHUDBlurCaptureTime = -100.0;

	// Live HUD Vitals & Stamina Tracking
	float HUDLiveStamina = 0.68f;
	float HUDDamageAccumulated = 0.0f;
	float HUDLastHealthRaw = 1.0f;
};

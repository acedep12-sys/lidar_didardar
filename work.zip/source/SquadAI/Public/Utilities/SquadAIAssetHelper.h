#pragma once

#include "CoreMinimal.h"
#include "Engine/Texture2D.h"
#include "Engine/Font.h"
#include "Engine/FontFace.h"
#include "Engine/Engine.h"
#include "UObject/Package.h"
#include "ImageUtils.h"
#include "Misc/Paths.h"
#include "Misc/FileHelper.h"
#include "Misc/PackageName.h"

/**
 * FSquadAIAssetHelper
 * Robust asset resolution helper for Unreal Engine 5.7.
 * Seamlessly resolves UTexture2D from compiled .uasset packages or direct loose PNG/JPG
 * files across multiple directory candidates via FImageUtils runtime import.
 */
class SQUADAI_API FSquadAIAssetHelper
{
public:
	static UTexture2D* LoadTextureSafe(const TCHAR* PackagePath, const TCHAR* RelativePngPath = nullptr)
	{
		// Derive file name if not explicitly provided
		FString PngRel = RelativePngPath ? FString(RelativePngPath) : TEXT("");
		FString BaseName;
		if (PackagePath)
		{
			FString CleanPkg = FString(PackagePath);
			int32 LastSlash = INDEX_NONE;
			if (CleanPkg.FindLastChar(TEXT('/'), LastSlash))
			{
				BaseName = CleanPkg.Mid(LastSlash + 1);
				int32 DotIdx = INDEX_NONE;
				if (BaseName.FindChar(TEXT('.'), DotIdx))
				{
					BaseName = BaseName.Left(DotIdx);
				}
			}
		}

		// For HUD UI textures (SquadAI/UI/), always prefer the loose uncompressed PNG on disk first
		// so updated UI textures in Content/SquadAI/UI/ are never shadowed by stale or DXT-compressed .uassets.
		const bool bPreferLoosePngFirst = PngRel.Contains(TEXT("SquadAI/UI/")) || !(PackagePath && *PackagePath);

		auto TryLoadFromDiskCandidates = [&]() -> UTexture2D*
		{
			TArray<FString> Candidates;
			if (!PngRel.IsEmpty())
			{
				Candidates.Add(FPaths::ProjectContentDir() / PngRel);
				Candidates.Add(FPaths::ProjectDir() / PngRel);
				Candidates.Add(FPaths::ProjectDir() / TEXT("SquadAI/Content") / PngRel);
				Candidates.Add(FPaths::ProjectDir() / TEXT("Content") / PngRel);
				Candidates.Add(FPaths::ProjectPluginsDir() / TEXT("SquadAI/Content") / PngRel);
			}

			if (!BaseName.IsEmpty())
			{
				Candidates.Add(FPaths::ProjectContentDir() / TEXT("SquadAI/UI") / (BaseName + TEXT(".png")));
				Candidates.Add(FPaths::ProjectContentDir() / TEXT("Textures") / (BaseName + TEXT(".png")));
				Candidates.Add(FPaths::ProjectDir() / TEXT("SquadAI/Content/Textures") / (BaseName + TEXT(".png")));
				Candidates.Add(FPaths::ProjectDir() / TEXT("Content/Textures") / (BaseName + TEXT(".png")));
				Candidates.Add(FPaths::ProjectPluginsDir() / TEXT("SquadAI/Content/Textures") / (BaseName + TEXT(".png")));
			}

			if (!PngRel.IsEmpty())
			{
				Candidates.Add(PngRel);
			}

			for (const FString& DiskPath : Candidates)
			{
				if (FPaths::FileExists(DiskPath))
				{
					if (UTexture2D* DiskTex = FImageUtils::ImportFileAsTexture2D(DiskPath))
					{
						if (bPreferLoosePngFirst)
						{
							DiskTex->SRGB = true;
							DiskTex->Filter = TF_Bilinear;
							DiskTex->AddressX = TA_Clamp;
							DiskTex->AddressY = TA_Clamp;
							DiskTex->NeverStream = true;
							DiskTex->UpdateResource();
						}
						return DiskTex;
					}
				}
			}
			return nullptr;
		};

		if (bPreferLoosePngFirst)
		{
			if (UTexture2D* DiskTex = TryLoadFromDiskCandidates())
			{
				return DiskTex;
			}
		}

		// Standard Unreal Engine UAsset package loader (only if package exists on disk)
		if (PackagePath && *PackagePath)
		{
			FString PkgName = FString(PackagePath);
			int32 DotIdx = INDEX_NONE;
			if (PkgName.FindChar(TEXT('.'), DotIdx))
			{
				PkgName = PkgName.Left(DotIdx);
			}
			if (FPackageName::DoesPackageExist(PkgName))
			{
				if (UTexture2D* Tex = LoadObject<UTexture2D>(nullptr, PackagePath))
				{
					return Tex;
				}
			}
		}

		if (!bPreferLoosePngFirst)
		{
			if (UTexture2D* DiskTex = TryLoadFromDiskCandidates())
			{
				return DiskTex;
			}
		}

		return nullptr;
	}

	/**
	 * S26-BUMP: LoadTextureSafe's normal-map sibling. A normal map MUST be
	 * sampled linear (sRGB off) and compressed as a normal map, or every
	 * surface it touches tilts the wrong way - so whatever loads (asset or
	 * loose PNG) gets its settings checked and fixed before returning.
	 */
	static UTexture2D* LoadNormalTextureSafe(const TCHAR* PackagePath, const TCHAR* RelativePngPath = nullptr)
	{
		UTexture2D* Tex = LoadTextureSafe(PackagePath, RelativePngPath);
		if (Tex && (Tex->SRGB || Tex->CompressionSettings != TextureCompressionSettings::TC_Normalmap))
		{
			Tex->SRGB = false;
			Tex->CompressionSettings = TextureCompressionSettings::TC_Normalmap;
			Tex->UpdateResource();
		}
		return Tex;
	}

	/**
	 * S26-FIXUI / S27-CRASHFIX: the HUD font sibling of LoadTextureSafe.
	 * Always prioritizes the loose TTF in Content/Fonts/ (SquadAI_HUD.ttf / Vazirmatn-Bold.ttf)
	 * so any stale .uasset on disk never shadows our complete Persian + tactical symbol TTF,
	 * and provides GetHUDFontAtSize(PointSize) so UCanvas::DrawText can render 1:1 at Scale=1.0f
	 * without GPU bilinear quad scaling blur.
	 */
	static UFontFace* GetOrCreateHUDRuntimeFontFace(const TCHAR* RelativeTtfPath = nullptr)
	{
		static UFontFace* CachedFace = nullptr;
		if (CachedFace && IsValid(CachedFace))
		{
			return CachedFace;
		}

		TArray<FString> Candidates;
		if (RelativeTtfPath && *RelativeTtfPath)
		{
			Candidates.Add(FPaths::ProjectContentDir() / RelativeTtfPath);
			Candidates.Add(FPaths::ProjectDir() / RelativeTtfPath);
			Candidates.Add(FPaths::ProjectDir() / TEXT("Content") / RelativeTtfPath);
			Candidates.Add(FPaths::ProjectPluginsDir() / TEXT("SquadAI/Content") / RelativeTtfPath);
		}
		Candidates.Add(FPaths::ProjectContentDir() / TEXT("Fonts/SquadAI_HUD.ttf"));
		Candidates.Add(FPaths::ProjectContentDir() / TEXT("Fonts/Vazirmatn-Bold.ttf"));

		for (const FString& DiskPath : Candidates)
		{
			if (!FPaths::FileExists(DiskPath))
			{
				continue;
			}
			TArray<uint8> RawFontBytes;
			if (!FFileHelper::LoadFileToArray(RawFontBytes, *DiskPath) || RawFontBytes.Num() == 0)
			{
				continue;
			}
			UFontFace* RuntimeFace = NewObject<UFontFace>(GetTransientPackage(), NAME_None, RF_Transient);
			if (!RuntimeFace)
			{
				continue;
			}
			RuntimeFace->SourceFilename = DiskPath;
			RuntimeFace->LoadingPolicy = EFontLoadingPolicy::Inline;
			RuntimeFace->Hinting = EFontHinting::AutoLight;
			RuntimeFace->FontFaceData = FFontFaceData::MakeFontFaceData(MoveTemp(RawFontBytes));
			RuntimeFace->AddToRoot();
			CachedFace = RuntimeFace;
			UE_LOG(LogTemp, Log, TEXT("[SquadAIAssetHelper] HUD runtime FontFace loaded from TTF: %s"), *DiskPath);
			return CachedFace;
		}
		return nullptr;
	}

	static UFont* GetHUDFontAtSize(int32 PointSize, UFont* FallbackFont = nullptr)
	{
		const int32 ClampedPt = FMath::Clamp(PointSize, 6, 48);
		static TMap<int32, UFont*> SizeFontCache;
		if (UFont** Found = SizeFontCache.Find(ClampedPt))
		{
			if (*Found && IsValid(*Found))
			{
				return *Found;
			}
		}

		UFontFace* RuntimeFace = GetOrCreateHUDRuntimeFontFace(TEXT("Fonts/SquadAI_HUD.ttf"));
		if (!RuntimeFace)
		{
			return FallbackFont;
		}

		UFont* SizedFont = NewObject<UFont>(GetTransientPackage(), NAME_None, RF_Transient);
		if (!SizedFont)
		{
			return FallbackFont;
		}
		SizedFont->FontCacheType = EFontCacheType::Runtime;
		SizedFont->LegacyFontSize = ClampedPt;
		FTypefaceEntry& Entry = SizedFont->GetMutableInternalCompositeFont().DefaultTypeface.Fonts.AddDefaulted_GetRef();
		Entry.Name = TEXT("Default");
		Entry.Font = FFontData(RuntimeFace);
		SizedFont->AddToRoot();
		SizeFontCache.Add(ClampedPt, SizedFont);
		return SizedFont;
	}

	static UFont* LoadFontSafe(const TCHAR* PackagePath, const TCHAR* RelativeTtfPath = nullptr)
	{
		const int32 BaseFontSize = 14;

		// 1. Always prefer the loose TTF on disk first so updated Farsi/symbol glyphs in Content/Fonts/
		// are never shadowed by an older .uasset on disk.
		if (UFontFace* DiskFace = GetOrCreateHUDRuntimeFontFace(RelativeTtfPath))
		{
			// Also patch any existing UFont asset in memory/disk so anything referencing PackagePath gets the fresh FontFace
			if (PackagePath && *PackagePath)
			{
				FString PkgName = FString(PackagePath);
				int32 DotIdx = INDEX_NONE;
				if (PkgName.FindChar(TEXT('.'), DotIdx))
				{
					PkgName = PkgName.Left(DotIdx);
				}
				if (FPackageName::DoesPackageExist(PkgName))
				{
					if (UFont* ExistingFont = LoadObject<UFont>(nullptr, PackagePath))
					{
						ExistingFont->FontCacheType = EFontCacheType::Runtime;
						ExistingFont->LegacyFontSize = BaseFontSize;
						ExistingFont->GetMutableInternalCompositeFont().DefaultTypeface.Fonts.Reset();
						FTypefaceEntry& Entry = ExistingFont->GetMutableInternalCompositeFont().DefaultTypeface.Fonts.AddDefaulted_GetRef();
						Entry.Name = TEXT("Default");
						Entry.Font = FFontData(DiskFace);
						ExistingFont->AddToRoot();
					}
				}
			}
			return GetHUDFontAtSize(BaseFontSize);
		}

		// 2. Fallback to compiled asset if running in a pak-only shipping build with no loose TTF on disk
		if (PackagePath && *PackagePath)
		{
			FString PkgName = FString(PackagePath);
			int32 DotIdx = INDEX_NONE;
			if (PkgName.FindChar(TEXT('.'), DotIdx))
			{
				PkgName = PkgName.Left(DotIdx);
			}
			if (FPackageName::DoesPackageExist(PkgName))
			{
				if (UFont* ExistingFont = LoadObject<UFont>(nullptr, PackagePath))
				{
					ExistingFont->AddToRoot();
					return ExistingFont;
				}
				if (UFontFace* ExistingFace = LoadObject<UFontFace>(nullptr, PackagePath))
				{
					ExistingFace->AddToRoot();
					UFont* RuntimeFont = NewObject<UFont>(GetTransientPackage(), NAME_None, RF_Transient);
					if (RuntimeFont)
					{
						RuntimeFont->FontCacheType = EFontCacheType::Runtime;
						RuntimeFont->LegacyFontSize = BaseFontSize;
						FTypefaceEntry& Entry = RuntimeFont->GetMutableInternalCompositeFont().DefaultTypeface.Fonts.AddDefaulted_GetRef();
						Entry.Name = TEXT("Default");
						Entry.Font = FFontData(ExistingFace);
						RuntimeFont->AddToRoot();
						return RuntimeFont;
					}
				}
			}
		}

		return nullptr;
	}

	/**
	 * S26-TEX2: roughness/mask maps are DATA, not color - they must be sampled
	 * linear (sRGB off) like normal maps, but compressed as masks, not normals.
	 */
	static UTexture2D* LoadLinearTextureSafe(const TCHAR* PackagePath, const TCHAR* RelativePngPath = nullptr)
	{
		UTexture2D* Tex = LoadTextureSafe(PackagePath, RelativePngPath);
		if (Tex && (Tex->SRGB || Tex->CompressionSettings != TextureCompressionSettings::TC_Masks))
		{
			Tex->SRGB = false;
			Tex->CompressionSettings = TextureCompressionSettings::TC_Masks;
			Tex->UpdateResource();
		}
		return Tex;
	}
};

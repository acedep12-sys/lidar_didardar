// BridgeSplineActor.h — S17-BRDG: spline-driven bridge builder.
// Drag the actor over a river, pull the spline points from bank to bank
// (add points for long curves), and the bridge rebuilds instantly in-editor:
// plank deck (walkable, navmesh-supported so the squad can cross), side
// rails, longitudinal stringers, and support piers that line-trace down to
// the riverbed. Engine primitives + shared tinted material by default;
// assign the S15 trench wood PBR material for the full look.
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Containers/Ticker.h" // S17-TRPERF
#include "BridgeSplineActor.generated.h"

class USplineComponent;
class UHierarchicalInstancedStaticMeshComponent;
class UMaterialInterface;

UCLASS(BlueprintType, Blueprintable)
class SQUADAI_API ABridgeSplineActor : public AActor
{
	GENERATED_BODY()

public:
	ABridgeSplineActor();
	virtual void OnConstruction(const FTransform& Transform) override;

	// ===== SHAPE =====

	/** Deck width in cm (walkable surface). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bridge|Shape", meta = (ClampMin = "150.0"))
	float DeckWidth = 350.f;

	/** Each plank's length along the bridge (cm). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bridge|Shape", meta = (ClampMin = "20.0"))
	float PlankLength = 55.f;

	/** Visible gap between planks (cm). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bridge|Shape", meta = (ClampMin = "0.0"))
	float PlankGap = 4.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bridge|Shape", meta = (ClampMin = "4.0"))
	float PlankThickness = 10.f;

	/** Hand-built irregularity: per-plank yaw/height jitter. 0 = machine straight. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bridge|Shape", meta = (ClampMin = "0.0", ClampMax = "1.0"))
	float Roughness = 0.5f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bridge|Shape")
	int32 Seed = 1361;

	// ===== RAILS =====

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bridge|Rails")
	bool bBuildRails = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bridge|Rails", meta = (EditCondition = "bBuildRails", ClampMin = "40.0"))
	float RailHeight = 105.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bridge|Rails", meta = (EditCondition = "bBuildRails", ClampMin = "80.0"))
	float RailPostSpacing = 220.f;

	/** Also add a mid-height rail beam. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bridge|Rails", meta = (EditCondition = "bBuildRails"))
	bool bMidRail = true;

	// ===== PIERS =====

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bridge|Piers")
	bool bBuildPiers = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bridge|Piers", meta = (EditCondition = "bBuildPiers", ClampMin = "200.0"))
	float PierSpacing = 550.f;

	/** Trace down from the deck to find the riverbed for each pier leg. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bridge|Piers", meta = (EditCondition = "bBuildPiers"))
	bool bTraceForRiverbed = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bridge|Piers", meta = (EditCondition = "bBuildPiers", ClampMin = "200.0"))
	float PierTraceDepth = 4000.f;

	/** Leg length used when the trace finds nothing (cm). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bridge|Piers", meta = (EditCondition = "bBuildPiers", ClampMin = "50.0"))
	float FixedPierLength = 600.f;

	// ===== MATERIALS =====

	/** Optional authored materials (e.g. the S15 trench wood PBR). None = tinted engine primitive. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bridge|Materials")
	TObjectPtr<UMaterialInterface> DeckMaterial;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bridge|Materials")
	TObjectPtr<UMaterialInterface> RailMaterial;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bridge|Materials")
	TObjectPtr<UMaterialInterface> PierMaterial;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bridge|Materials")
	FLinearColor DeckTint = FLinearColor(0.32f, 0.22f, 0.12f);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bridge|Materials")
	FLinearColor RailTint = FLinearColor(0.24f, 0.16f, 0.09f);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bridge|Materials")
	FLinearColor PierTint = FLinearColor(0.18f, 0.13f, 0.09f);

protected:
	UPROPERTY(VisibleAnywhere, Category = "Bridge")
	TObjectPtr<USceneComponent> SceneRoot;

	UPROPERTY(VisibleAnywhere, Category = "Bridge")
	TObjectPtr<USplineComponent> BridgeSpline;

	UPROPERTY(VisibleAnywhere, Category = "Bridge")
	TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_Deck;

	UPROPERTY(VisibleAnywhere, Category = "Bridge")
	TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_Rail;

	UPROPERTY(VisibleAnywhere, Category = "Bridge")
	TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_Pier;

private:
	void RebuildBridge(); // S17-TRPERF: full rebuild (was inline in OnConstruction)
#if WITH_EDITOR
	// S17-TRPERF: debounced editor rebuild — see TrenchDetailSplineActor.
	double LastSplineEditTime = 0.0;
	bool bDebounceRebuildPending = false;
	FTSTicker::FDelegateHandle DebounceTickerHandle;
	virtual void BeginDestroy() override;
#endif
	UHierarchicalInstancedStaticMeshComponent* MakeHISM(const TCHAR* Name, bool bWalkable);
	void ConfigureHISM(UHierarchicalInstancedStaticMeshComponent* HISM, class UStaticMesh* Mesh,
		UMaterialInterface* Mat, const FLinearColor& Tint) const;
};

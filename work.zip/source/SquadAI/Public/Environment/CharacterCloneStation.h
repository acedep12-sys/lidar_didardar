// CharacterCloneStation.h — S17-CLONE: one-button ready-clone factory.
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Templates/SubclassOf.h"
#include "CharacterCloneStation.generated.h"

class ASoldierCharacter;
class USkeletalMesh;

/**
 * ACharacterCloneStation  (S17-CLONE)
 *
 * Drop this actor anywhere in the map. In its Details panel:
 *   1. Set SourceCharacter = your V3 character Blueprint
 *      (or the mannequin soldier BP + V3Mesh to swap the model).
 *   2. Press CREATE READY CLONE.
 *
 * It then does automatically what used to be 5 manual steps:
 *   - duplicates the Blueprint into CloneFolder (default /Game/SquadAI/Clones)
 *   - swaps in V3Mesh (if provided)
 *   - finds the mannequin's grip socket (auto-walks parent classes, or use
 *     GripTemplateMesh) and CREATES it permanently on the clone's skeleton
 *   - sets GripSocketTemplateMesh on the clone as a runtime safety net
 *   - compiles and SAVES the new Blueprint + skeleton
 *
 * Your original character, the mannequin and its animations are never
 * touched — everything happens on the duplicate (plus one additive socket on
 * the V3 skeleton, which cannot affect existing animation).
 * Editor-only: the button does nothing in a packaged game.
 * Log tag: [CloneStation]
 */
UCLASS(BlueprintType, meta = (DisplayName = "Character Clone Station (V3 Grip Fixer)"))
class SQUADAI_API ACharacterCloneStation : public AActor
{
	GENERATED_BODY()

public:
	ACharacterCloneStation();

	/** Your V3 character Blueprint — the one whose weapon sits at the feet.
	 *  (Or the base mannequin soldier BP, together with V3Mesh below.) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Clone Station")
	TSubclassOf<ASoldierCharacter> SourceCharacter;

	/** S17-CLONE3: the character that holds the weapon CORRECTLY (your
	 *  original mannequin soldier BP). Set this when your V3 was created
	 *  outside this project: the station copies its whole weapon-grip setup
	 *  onto the clone — socket name, socket transform, attach offsets — so
	 *  the clone is set up exactly like the mannequin one. Leave empty to
	 *  let the station auto-discover the socket instead. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Clone Station")
	TSubclassOf<ASoldierCharacter> ReferenceCharacter;

	/** OPTIONAL: a skeletal mesh to swap onto the clone (e.g. your V3 body
	 *  when SourceCharacter is the mannequin BP). Leave empty to keep the
	 *  source Blueprint's own mesh. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Clone Station")
	TObjectPtr<USkeletalMesh> V3Mesh;

	/** OPTIONAL: mannequin mesh whose grip socket is correct. Leave empty —
	 *  the station auto-finds it on the source Blueprint's parent classes. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Clone Station")
	TObjectPtr<USkeletalMesh> GripTemplateMesh;

	/** S18-GRIP: retarget the template grip socket into the clone hand bone's
	 *  own axes instead of copying it verbatim. The UE5 mannequin's hand_r and a
	 *  V3 / Character-Creator right hand point along different axes and are
	 *  authored at different sizes, which is why the rifle came out oversized
	 *  and twisted. Turn OFF only to reproduce the old behaviour. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Clone Station|Grip")
	bool bRetargetGripSocket = true;

	/** S18-GRIP: also scale the socket offset+weapon by the ratio of the two
	 *  rigs' forearm lengths, so the rifle matches the hand it sits in. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Clone Station|Grip")
	bool bAutoScaleWeaponToGrip = true;

	/** S18-GRIP: final manual size nudge on the attached weapon. 1 = auto result.
	 *  If the rifle is still a bit big/small, tweak this and re-run. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Clone Station|Grip", meta = (ClampMin = "0.05", ClampMax = "20.0"))
	float WeaponScaleMultiplier = 1.f;

	/** S19-CLONE3 — THE important one. ON (default): the clone gets its own
	 *  DUPLICATE of the mesh, and the grip socket is baked into that duplicate
	 *  as a MESH-level socket. Your V3 mesh and especially its SKELETON are
	 *  never modified, so nothing else in the project can be affected.
	 *
	 *  Why this matters: a skeleton is normally shared by several meshes. The
	 *  old code wrote the grip socket onto the shared skeleton, so (a) every
	 *  other character using that skeleton grew a hand-tuned rifle socket, and
	 *  (b) once a socket existed the station said "already exists — nothing to
	 *  create" and could NEVER correct a bad one. That is why a wrong grip
	 *  survived re-running the tool. Duplicate + bake fixes both.
	 *
	 *  Turn OFF only to go back to writing a socket on the shared skeleton. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Clone Station|Output")
	bool bDuplicateMeshForClone = true;

	/** S19-CLONE3: re-running the button REPLACES the previous output instead
	 *  of creating BP_x_Ready_2, _3, _4 ... Keeps the content browser clean and
	 *  guarantees the asset you are looking at is the one just built. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Clone Station|Output")
	bool bOverwriteExistingClones = true;

	/** S19-CLONE3 — the other half of the "weapon under the feet" bug.
	 *  ASoldierCharacter::ApplyEquippedWeaponAttachment() returns immediately
	 *  unless bAutoAttachEquippedWeaponToMesh is true and
	 *  bUsePackPresentationMode is false. Both default to false/off, and a V3
	 *  Blueprint authored outside this project usually leaves them that way —
	 *  in which case the weapon is NEVER attached and simply sits where it was
	 *  spawned: at the actor origin, i.e. between the character's feet. No
	 *  socket fix can help until that gate is open.
	 *
	 *  ON (default): the clone inherits the reference character's gate flags,
	 *  or is forced to (attach = true, pack-presentation = false) when no
	 *  reference is set. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Clone Station|Output")
	bool bForceWeaponAttachOnClone = true;

	/** S19-CLONE3: after baking, measure where the socket actually ended up in
	 *  component space and log it. If it is at or below the character's feet
	 *  (the "weapon under the feet" symptom) you get a loud ERROR naming the
	 *  bone it landed on, instead of a silent wrong grip. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Clone Station|Output")
	bool bVerifyGripSocket = true;

	/** Where the ready clone is saved. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Clone Station")
	FString CloneFolder = TEXT("/Game/SquadAI/Clones");

	/** OPTIONAL: asset name for the clone. Empty = BP_<Source>_Ready. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Clone Station")
	FString CloneName;

	/** S17-CLONE6: CREATE READY MESH bakes the grip socket under EVERY name
	 *  listed here too (same bone, same transform). External systems (your
	 *  leader pack) each look for their own socket name — with these extras
	 *  baked in, whichever name it asks for exists on the mesh. Add your
	 *  leader pack's socket name here if it is not in the defaults. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Clone Station")
	TArray<FName> AdditionalSocketNames = {
		FName(TEXT("RifleSocket")), FName(TEXT("WeaponSocket")), FName(TEXT("Weapon_R")),
		FName(TEXT("GripPoint")), FName(TEXT("hand_rSocket")), FName(TEXT("RightHandSocket")) };

	/** ONE BUTTON: duplicate + mesh swap + permanent grip socket + save. */
	UFUNCTION(CallInEditor, BlueprintCallable, Category = "Clone Station", meta = (DisplayName = "CREATE READY CLONE"))
	void CreateReadyClone();

	/** S17-CLONE5 — MESH output instead of a Blueprint: duplicates V3Mesh
	 *  into CloneFolder and bakes the grip socket INTO the mesh asset itself
	 *  (on its right-hand bone, transform taken from the grip template or
	 *  from the working character's attach offsets). Mesh-level sockets
	 *  travel with the asset and override skeleton sockets, so the result
	 *  works anywhere you plug the mesh in. Original V3 mesh is untouched. */
	UFUNCTION(CallInEditor, BlueprintCallable, Category = "Clone Station", meta = (DisplayName = "CREATE READY MESH (no Blueprint)"))
	void CreateReadyMesh();
};

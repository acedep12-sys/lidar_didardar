#pragma once

#include "CoreMinimal.h"
#include "Math/RandomStream.h"
#include "GameFramework/Actor.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h"
#include "DestroyedBuildingActor.generated.h"

class UMaterialInstanceDynamic;

class UMaterialInterface;
class AAmmoCrateActor;
class AFirstAidKitActor;
class AMountedTurretActor;
class AExplosiveBarrelActor;
class ASoldierCharacter;

UENUM(BlueprintType)
enum class EBuildingStyle : uint8
{
	TwoStorySniperRuins		UMETA(DisplayName = "Two-Story Ruined House with Sniper Loft"),
	SingleStoryMudbrick		UMETA(DisplayName = "Single-Story Collapsed Mudbrick House"),
	WalledCourtyardHouse	UMETA(DisplayName = "Walled Compound with Courtyard & Gate"),
	VillageMarketStalls		UMETA(DisplayName = "Ruined Village Marketplace Block"),
	OutpostObservationTower	UMETA(DisplayName = "Fortified Outpost Ruins with MG Nest"),
	// S6-M: appended at END — existing serialized style indices stay valid.
	VillageMosque	UMETA(DisplayName = "Village Mosque with Minaret & Ruined Prayer Hall")
};

/**
 * ADestroyedBuildingActor
 * Procedural Destroyed Middle-Eastern Village Building & Defensive Stronghold.
 * 
 * Drop this actor into the level to instantly construct an authentic war-torn Middle Eastern
 * mudbrick / concrete building with broken walls, collapsed floors, rubble scatter,
 * tactical cover points, supply crates, first aid kits, and optional defenders.
 * 
 * Supports Hierarchical Instanced Static Mesh (HISM) GPU batching for maximum frame rates.
 */
UCLASS(BlueprintType, Blueprintable, meta = (DisplayName = "Destroyed Middle East Building"))
class SQUADAI_API ADestroyedBuildingActor : public AActor
{
	GENERATED_BODY()

public:
	ADestroyedBuildingActor();

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<USceneComponent> SceneRoot;

	// =========================================================================
	//  HISM INSTANCING COMPONENTS (High Performance GPU Batching)
	// =========================================================================

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "HISM Components")
	TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_Walls;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "HISM Components")
	TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_Floors;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "HISM Components")
	TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_Wood;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "HISM Components")
	TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_Sandbags;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "HISM Components")
	TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_Metal;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "HISM Components")
	TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_Rubble;

	/** If true, batches geometry into HISM components, drastically reducing draw calls and memory */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Performance")
	bool bUseHISMInstancing = true;

	// S6-B: seeded variation — mirror the blueprint left/right, jitter dimensions
	// and piece angles per build, and apply a per-building material tone. Without
	// this, every structure of a style is pixel-identical (GenerationSeed was
	// previously never consumed by the construct functions).
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Building Variation")
	bool bSeededVariation = true;

	/** Whole-building tone jitter (fractional, warm plaster variance) applied via runtime DMIs */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Building Variation", meta = (ClampMin = "0.0", ClampMax = "0.15"))
	float ToneJitter = 0.05f;

	/** Per-piece angular jitter in degrees for wall fragments (breaks the CAD-perfect 90° look) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Building Variation", meta = (ClampMin = "0.0", ClampMax = "2.0"))
	float PieceAngleJitterDeg = 0.6f;

	// =========================================================================
	//  BUILDING CONFIGURATION
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Building Style")
	EBuildingStyle BuildingStyle = EBuildingStyle::TwoStorySniperRuins;

	/** Random variation seed for wall collapse patterns and rubble placement */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Building Style")
	int32 GenerationSeed = 12345;

	/** Building width in cm (e.g. 1000cm = 10m) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Dimensions", meta = (ClampMin = "500.0", ClampMax = "3000.0"))
	float BuildingWidth = 1200.0f;

	/** Building depth in cm (e.g. 1000cm = 10m) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Dimensions", meta = (ClampMin = "500.0", ClampMax = "3000.0"))
	float BuildingDepth = 1000.0f;

	/** Wall height per floor in cm */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Dimensions", meta = (ClampMin = "250.0", ClampMax = "500.0"))
	float FloorHeight = 320.0f;

	/** If true, automatically places Ammo Crates and First Aid Kits inside the ruins */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tactical Logistics")
	bool bSpawnSupplies = true;

	/** If true, spawns a mounted heavy machine gun on the roof / sandbag nest */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tactical Logistics")
	bool bSpawnMountedHeavyMG = true;

	/** If true, spawns red explosive fuel barrels near wall breach points */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tactical Logistics")
	bool bSpawnExplosiveBarrels = true;

	/** If true, spawns enemy defenders or snipers stationed in the building */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tactical Combat")
	bool bSpawnHostileDefenders = false;

	/** Number of enemy defenders to spawn inside */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tactical Combat", meta = (EditCondition = "bSpawnHostileDefenders", ClampMin = "1", ClampMax = "5"))
	int32 DefenderCount = 2;

	/** Optional material override for mudbrick / concrete walls */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Materials")
	TObjectPtr<UMaterialInterface> WallMaterialOverride;

	/** Optional material override for rubble and debris */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Materials")
	TObjectPtr<UMaterialInterface> RubbleMaterialOverride;

	/** Optional material override for floors and roofs */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Materials")
	TObjectPtr<UMaterialInterface> FloorMaterialOverride;

	/** Optional material override for wooden beams, rafters, and doors */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Materials")
	TObjectPtr<UMaterialInterface> WoodMaterialOverride;

	/** Optional material override for sandbags and canvas */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Materials")
	TObjectPtr<UMaterialInterface> SandbagMaterialOverride;

	/** Optional material override for corrugated metal sheets and barrels */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Materials")
	TObjectPtr<UMaterialInterface> MetalMaterialOverride;

	/** Optional custom static mesh for walls (leave empty to use procedural geometry) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Meshes")
	TObjectPtr<UStaticMesh> CustomWallMesh;

	/** Optional custom static mesh for rubble heaps */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Meshes")
	TObjectPtr<UStaticMesh> CustomRubbleMesh;

	/** Optional custom static mesh for sandbag fortifications */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Meshes")
	TObjectPtr<UStaticMesh> CustomSandbagMesh;

	/** Optional custom static mesh for wooden roof beams */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Meshes")
	TObjectPtr<UStaticMesh> CustomWoodBeamMesh;

	// =========================================================================
	//  ARCHITECTURAL DETAILS TOGGLES
	// =========================================================================

	/** If true, spawns protruding wooden roof beams and ceiling rafters */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Architectural Details")
	bool bSpawnWoodenRafters = true;

	/** If true, spawns interior partition walls creating multi-room layouts */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Architectural Details")
	bool bSpawnInteriorPartitions = true;

	/** If true, spawns multi-tiered sandbag firing parapets and sniper embrasures */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Architectural Details")
	bool bSpawnSandbagEmbrasures = true;

	/** If true, spawns multi-angle debris fields with broken plaster and masonry */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Architectural Details")
	bool bSpawnDebrisFields = true;

	/** S13-GEO: how far the bottom course of every wall is driven into the
	 *  ground. Buildings sit on flat-bottomed geometry over uneven terrain, so
	 *  without this the foot of a wall visibly floats. Raise it on rougher
	 *  ground. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Building|Structure",
		meta = (ClampMin = "0.0", ClampMax = "200.0"))
	float GroundEmbedDepth = 45.0f;

	// =========================================================================
	//  API & EDITOR ACTIONS
	// =========================================================================

	UFUNCTION(BlueprintCallable, CallInEditor, Category = "Building Actions")
	void BuildBuilding();

	UFUNCTION(BlueprintCallable, CallInEditor, Category = "Building Actions")
	void RandomizeAndRebuild();

	UFUNCTION(BlueprintCallable, CallInEditor, Category = "Building Actions")
	void ClearBuilding();

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Building Actions")
	int32 GetSpawnedElementCount() const;

protected:
	virtual void BeginPlay() override;
	/** S10-FIX: destroy the pieces we spawned. Without this, destroying the
	 *  building (e.g. from ClearVillage) orphaned every SpawnedElements actor. */
	virtual void Destroyed() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

private:
	UPROPERTY()
	TArray<TObjectPtr<AActor>> SpawnedElements;

	// S6-B: variation state (re-seeded every BuildBuilding)
	FRandomStream PieceStream;
	float CurrentToneOffset = 0.f;
	UPROPERTY(Transient)
	TMap<TObjectPtr<UMaterialInterface>, TObjectPtr<UMaterialInstanceDynamic>> ToneCache;
	UMaterialInterface* GetTonedMaterial(UMaterialInterface* BaseMaterial);

	void PrepareHISMComponents();

	void ConstructTwoStoryRuins(const FVector& Origin, const FRotator& Rot, const FRandomStream& Stream);
	void ConstructSingleStoryMudbrick(const FVector& Origin, const FRotator& Rot, const FRandomStream& Stream);
	void ConstructWalledCourtyard(const FVector& Origin, const FRotator& Rot, const FRandomStream& Stream);
	void ConstructMarketStalls(const FVector& Origin, const FRotator& Rot, const FRandomStream& Stream);
	void ConstructOutpostTower(const FVector& Origin, const FRotator& Rot, const FRandomStream& Stream);
	void ConstructVillageMosque(const FVector& Origin, const FRotator& Rot, const FRandomStream& Stream);

	void SpawnWallSegment(const FVector& Location, const FRotator& Rotation, const FVector& Scale, UMaterialInterface* Mat = nullptr);
	void SpawnRubblePile(const FVector& Location, const FRotator& Rotation, const FVector& Scale);
	void SpawnWoodenBeam(const FVector& Location, const FRotator& Rotation, const FVector& Scale);
	void SpawnSandbagParapet(const FVector& Location, const FRotator& Rotation, const FVector& Scale);
	void SpawnMetalSheet(const FVector& Location, const FRotator& Rotation, const FVector& Scale);
	void SpawnCrateStack(const FVector& Location, const FRotator& Rotation);
	void SpawnWindowFrame(const FVector& Location, const FRotator& Rotation, float Width, float Height);
	void SpawnDoorway(const FVector& Location, const FRotator& Rotation, float Width, float Height);
	void SpawnWallButtress(const FVector& Location, const FRotator& Rotation, float Height);
	void SpawnRubbleSlope(const FVector& Location, const FRotator& Rotation, const FVector& Extents);
	void SpawnHangingRafters(const FVector& Location, const FRotator& Rotation, float Span, int32 Count);

	// ---------------------------------------------------------------------
	// S10-GEO: real-geometry helpers.
	// Previously every wall/roof was ONE scaled engine cube, which reads as
	// grey-boxing next to photogrammetry terrain, and roof slabs were placed
	// whether or not anything survived underneath them (the "floating ceiling"
	// bug). These build walls from several offset masses and make the roof
	// support-aware.
	// ---------------------------------------------------------------------

	/** Wall built from stacked courses: battered (thicker at the base, as real
	 *  adobe is), with an eroded top line, broken end caps and occasional
	 *  slumped/missing blocks. Registers its top edge as roof support. */
	void SpawnCompositeWall(const FVector& Center, const FRotator& Rotation,
		float Length, float Height, float Thickness,
		float IntactFraction = 1.f, UMaterialInterface* Mat = nullptr);

	/** Khuzestan roof edge: low parapet of standing bricks with ventilation
	 *  gaps, broken down in places. Strong silhouette read. */
	void SpawnRoofParapet(const FVector& Center, const FRotator& Rotation,
		float Length, float RoofZ, float Height, float Thickness);

	/** Rafter ends poking through the wall face just under the roof line —
	 *  one of the most recognisable features of Khuzestani mudbrick building. */
	void SpawnBeamStubs(const FVector& WallCenter, const FRotator& Rotation,
		float Length, float Z, int32 Count);

	/** Roof built as a grid of slabs. A slab is only placed where the walls
	 *  below actually survived; unsupported tiles either fall to the floor as
	 *  tilted debris or are carried on a timber post. Fixes floating ceilings. */
	void SpawnSupportedRoof(const FVector& Origin, const FRotator& Rotation,
		float HalfW, float HalfD, float RoofZ, float FloorZ, const FRandomStream& Stream);

	/** Record that something load-bearing reaches this world point. */
	void RegisterSupport(const FVector& TopPoint);
	bool IsSupported(const FVector& Point, float Radius, float ZTolerance) const;

	/** Load-bearing points registered during the current build. */
	TArray<FVector> SupportPoints;
	void SpawnSuppliesAndDefenders(const FVector& Center, const FRotator& Rotation);
};

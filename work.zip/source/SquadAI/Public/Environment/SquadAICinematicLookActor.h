// SquadAICinematicLookActor.h — S18-LOOK
// Drop ONE in the level and press "Apply Look" (or let it run at BeginPlay).
// It grades the existing sun / sky / fog / post-process into a Khuzestan
// golden-hour image at the fidelity bar we discussed (COD / BF reference):
// warm low sun, real atmospheric haze, volumetric fog with dust, film-grade
// post. Everything it touches is exposed so nothing is a black box.
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Engine/EngineTypes.h"
#include "SquadAICinematicLookActor.generated.h"

class ADirectionalLight;
class ASkyLight;
class AExponentialHeightFog;
class APostProcessVolume;
class USkyAtmosphereComponent;

UENUM(BlueprintType)
enum class ESquadAILookPreset : uint8
{
	GoldenHour   UMETA(DisplayName = "Golden hour (default)"),
	HarshNoon    UMETA(DisplayName = "Harsh noon"),
	DustStorm    UMETA(DisplayName = "Dust storm"),
	ColdDawn     UMETA(DisplayName = "Cold dawn"),
	Custom       UMETA(DisplayName = "Custom (use the values below)")
};

UCLASS()
class SQUADAI_API ASquadAICinematicLookActor : public AActor
{
	GENERATED_BODY()

public:
	ASquadAICinematicLookActor();

	/** Apply the whole grade now. Safe to press repeatedly. */
	UFUNCTION(BlueprintCallable, CallInEditor, Category = "SquadAI Look")
	void ApplyLook();

	/** Put back what was there when this actor first touched the level. */
	UFUNCTION(BlueprintCallable, CallInEditor, Category = "SquadAI Look")
	void RestoreOriginalLook();

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look")
	ESquadAILookPreset Preset = ESquadAILookPreset::GoldenHour;

	/** Run ApplyLook automatically when the level starts. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look")
	bool bApplyOnBeginPlay = true;

	// ---------------- sun ----------------
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Sun")
	bool bGradeSun = true;

	/** Sun elevation above the horizon, degrees. Low = long shadows. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Sun", meta = (ClampMin = "-10.0", ClampMax = "89.0"))
	float SunPitchDeg = 14.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Sun", meta = (ClampMin = "-360.0", ClampMax = "360.0"))
	float SunYawDeg = 115.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Sun", meta = (ClampMin = "0.1", ClampMax = "50.0"))
	float SunIntensityLux = 7.5f;

	/** Kelvin. 4500 = warm afternoon, 6500 = neutral noon. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Sun", meta = (ClampMin = "1700.0", ClampMax = "12000.0"))
	float SunTemperatureK = 4700.f;

	/** Softens shadow edges — a hard stencil shadow is the #1 "looks like UE4" tell. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Sun", meta = (ClampMin = "0.0", ClampMax = "5.0"))
	float SunSourceAngleDeg = 0.75f;

	/** Short contact shadows pin props to the ground. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Sun", meta = (ClampMin = "0.0", ClampMax = "1.0"))
	float ContactShadowLength = 0.035f;

	// ---------------- sky ----------------
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Sky")
	bool bGradeSky = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Sky", meta = (ClampMin = "0.0", ClampMax = "10.0"))
	float SkyLightIntensity = 1.15f;

	/** Bounce tint: warm sand bouncing back up into the shadows. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Sky")
	FLinearColor SkyLightTint = FLinearColor(1.0f, 0.86f, 0.70f, 1.0f);

	// ---------------- fog / haze ----------------
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Fog")
	bool bGradeFog = true;

	/** Spawn an ExponentialHeightFog if the level has none. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Fog")
	bool bSpawnFogIfMissing = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Fog", meta = (ClampMin = "0.0", ClampMax = "0.5"))
	float FogDensity = 0.012f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Fog", meta = (ClampMin = "0.0", ClampMax = "1.0"))
	float FogHeightFalloff = 0.09f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Fog")
	FLinearColor FogInscatteringColor = FLinearColor(0.62f, 0.49f, 0.34f, 1.0f);

	/** The bright halo around the sun through the dust — this is the BF look. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Fog")
	FLinearColor FogDirectionalInscattering = FLinearColor(1.0f, 0.72f, 0.38f, 1.0f);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Fog", meta = (ClampMin = "2.0", ClampMax = "64.0"))
	float FogDirectionalExponent = 12.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Fog")
	bool bVolumetricFog = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Fog", meta = (ClampMin = "0.0", ClampMax = "2.0"))
	float VolumetricFogExtinctionScale = 0.55f;

	// ---------------- post process ----------------
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Post")
	bool bGradePost = true;

	/** Spawn an unbound PostProcessVolume if the level has none. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Post")
	bool bSpawnPostVolumeIfMissing = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Post", meta = (ClampMin = "-3.0", ClampMax = "3.0"))
	float ExposureCompensation = -0.25f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Post", meta = (ClampMin = "0.0", ClampMax = "4.0"))
	float BloomIntensity = 0.55f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Post", meta = (ClampMin = "0.0", ClampMax = "1.0"))
	float VignetteIntensity = 0.42f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Post", meta = (ClampMin = "0.0", ClampMax = "1.0"))
	float FilmGrainIntensity = 0.12f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Post", meta = (ClampMin = "0.0", ClampMax = "1.0"))
	float ChromaticAberration = 0.18f;

	/** Colour grade: warm highlights, cool-ish shadows, lifted blacks for dust. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Post")
	FVector4 ColorGainHighlights = FVector4(1.05f, 0.99f, 0.90f, 1.0f);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Post")
	FVector4 ColorOffsetShadows = FVector4(0.012f, 0.014f, 0.022f, 0.0f);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Post", meta = (ClampMin = "0.0", ClampMax = "2.0"))
	float Saturation = 0.94f;

	/** Ambient occlusion strength — free contact darkening in the trench. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Post", meta = (ClampMin = "0.0", ClampMax = "1.0"))
	float AmbientOcclusionIntensity = 0.62f;

	/** Lumen GI bounce, keeps the trench floor from going black. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI Look|Post", meta = (ClampMin = "0.0", ClampMax = "4.0"))
	float IndirectLightingIntensity = 1.25f;

protected:
	virtual void BeginPlay() override;

	void ApplyPreset();
	ADirectionalLight* FindSun() const;
	ASkyLight* FindSkyLight() const;
	AExponentialHeightFog* FindOrSpawnFog();
	APostProcessVolume* FindOrSpawnPostVolume();

private:
	/** Minimal restore data captured the first time we touch the level. */
	bool bCapturedOriginal = false;
	FRotator OrigSunRot = FRotator::ZeroRotator;
	float OrigSunIntensity = 0.f;
	float OrigFogDensity = 0.f;
	bool bOrigVolumetricFog = false;
};

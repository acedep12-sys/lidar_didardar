// TrenchDetailSplineActor.h — S15-TRENCH: procedural trench-line dressing
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Containers/Ticker.h" // S17-TRPERF
#include "TrenchDetailSplineActor.generated.h"

class USplineComponent;
class UHierarchicalInstancedStaticMeshComponent;
class UStaticMesh;
class UMaterialInterface;

/**
 * ATrenchDetailSplineActor  (S15-TRENCH)
 *
 * Drops period-correct Iran–Iraq war dressing along an existing trench:
 * draw the spline down the TRENCH FLOOR, press "Build Details", done.
 * Everything is batched into HISM components (one draw call per category)
 * and ground-traced per instance so it hugs the sculpted terrain.
 *
 * Categories (each toggleable, engine-primitive defaults, optional custom
 * meshes/materials so real assets can replace primitives at any time):
 *  - Duckboards        wooden walkway sections on the trench floor
 *  - Revetment planks  timber shoring leaning against the trench walls
 *  - Support posts     vertical timbers pinning the revetment
 *  - Corrugated sheets metal shoring panels (darker, thinner)
 *  - Barrels           55-gal drums, some tipped over
 *  - Ammo cans         small olive boxes clustered near the walls
 *  - Wire pickets      angled stakes on BOTH parapet lips + sagging wire strands
 *  - Tarp awnings      canvas sheets stretched from the parapet into the trench
 *  - Firing steps      low blocks against the wall to shoot over the parapet
 *  - Debris            brass casings, scattered stones, scorch patches
 *
 * Deliberately does NOT generate sandbags or crates — the map already has them
 * (user assets / TacticalTrenchSplineActor).
 */
UCLASS(BlueprintType, Blueprintable, meta = (DisplayName = "Trench Detail Dresser"))
class SQUADAI_API ATrenchDetailSplineActor : public AActor
{
	GENERATED_BODY()

public:
	ATrenchDetailSplineActor();

	// ===================== COMPONENTS =====================

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<USceneComponent> SceneRoot;

	/** Draw this along the TRENCH FLOOR (points roughly at floor height). */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<USplineComponent> DetailSpline;

	UPROPERTY(VisibleAnywhere, Category = "HISM") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_Duckboard;
	// S18-TRMESH: cube-scaled loose planks (dugout roof, collapsed revetment
	// debris, firing-step tread). Split off HISM_Duckboard so assigning a real
	// duckboard mesh can never squash those into 4%-thick slabs.
	UPROPERTY(VisibleAnywhere, Category = "HISM") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_Plank;
	UPROPERTY(VisibleAnywhere, Category = "HISM") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_Revetment;
	UPROPERTY(VisibleAnywhere, Category = "HISM") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_Post;
	UPROPERTY(VisibleAnywhere, Category = "HISM") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_Corrugated;
	UPROPERTY(VisibleAnywhere, Category = "HISM") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_Barrel;
	UPROPERTY(VisibleAnywhere, Category = "HISM") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_AmmoCan;
	UPROPERTY(VisibleAnywhere, Category = "HISM") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_Stake;
	UPROPERTY(VisibleAnywhere, Category = "HISM") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_Wire;
	UPROPERTY(VisibleAnywhere, Category = "HISM") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_Tarp;
	UPROPERTY(VisibleAnywhere, Category = "HISM") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_FiringStep;
	UPROPERTY(VisibleAnywhere, Category = "HISM") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_Casing;
	UPROPERTY(VisibleAnywhere, Category = "HISM") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_Stone;
	UPROPERTY(VisibleAnywhere, Category = "HISM") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_Scorch;
	UPROPERTY(VisibleAnywhere, Category = "HISM") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_Rug; // S15-TRENCH3
	UPROPERTY(VisibleAnywhere, Category = "HISM") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_Netting;      // S15-TRENCH4
	UPROPERTY(VisibleAnywhere, Category = "HISM") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_Helmet;       // S15-TRENCH4
	UPROPERTY(VisibleAnywhere, Category = "HISM") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_DugoutShadow; // S15-TRENCH4
	UPROPERTY(VisibleAnywhere, Category = "HISM") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_Sandbag;      // S18-TRBAG
	UPROPERTY(VisibleAnywhere, Category = "HISM") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_SandbagStack; // S18-TRBAG
	UPROPERTY(VisibleAnywhere, Category = "HISM") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_WireSet;       // S18-TRWIRE
	UPROPERTY(VisibleAnywhere, Category = "HISM") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_WireSet2;      // S18-TRWIRE
	UPROPERTY(VisibleAnywhere, Category = "HISM") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_WireSet3;      // S18-TRWIRE
	UPROPERTY(VisibleAnywhere, Category = "HISM") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_WireSet4;      // S18-TRWIRE
	UPROPERTY(VisibleAnywhere, Category = "HISM") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_WireSet5;      // S18-TRWIRE2
	UPROPERTY(VisibleAnywhere, Category = "HISM") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_WireSet6;      // S18-TRWIRE2
	UPROPERTY(VisibleAnywhere, Category = "HISM") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_WireObstacle;  // S18-TRWIRE2 (wooden X knife-rest)
	UPROPERTY(VisibleAnywhere, Category = "HISM") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_WireCoil;      // S18-TRWIRE2
	UPROPERTY(VisibleAnywhere, Category = "HISM") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_WireCoil2;     // S18-TRWIRE2
	UPROPERTY(VisibleAnywhere, Category = "HISM") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> HISM_Pigtail;       // S18-TRWIRE2

	// ===================== LAYOUT =====================

	/** Random seed — change for a different arrangement. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Layout")
	int32 Seed = 1367;

	/** Global density multiplier for every category (0.25 sparse … 2.0 packed). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Layout", meta = (ClampMin = "0.25", ClampMax = "2.0"))
	float DetailDensity = 1.0f;

	/** Half-width of the walkable trench FLOOR in cm (spline to wall base). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Layout", meta = (ClampMin = "100.0", ClampMax = "800.0"))
	float FloorHalfWidth = 250.f;

	/** Lateral distance from the spline to the trench WALL face in cm. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Layout", meta = (ClampMin = "150.0", ClampMax = "1000.0"))
	float WallOffset = 320.f;

	/** Lateral distance from the spline to the PARAPET lip (berm top) in cm. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Layout", meta = (ClampMin = "250.0", ClampMax = "1500.0"))
	float ParapetOffset = 480.f;

	/** S17-TRWALL: probe the sculpted terrain to find the REAL left/right
	 *  trench walls per segment (horizontal traces from the floor), so the
	 *  dressing hugs the actual dig even when width varies or the spline is
	 *  off-center. WallOffset/ParapetOffset/FloorHalfWidth above become
	 *  fallbacks for stretches where no wall is found. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Layout")
	bool bAutoDetectWalls = true;

	/** Height above the trench floor (cm) at which the wall probes are fired. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Layout", meta = (ClampMin = "30.0", ClampMax = "300.0"))
	float WallProbeHeight = 90.f;

	/** Rebuild automatically whenever the spline or a property changes in editor. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Layout")
	bool bAutoRebuild = true;

	/** S15-TRENCH5: mix the actor's location into the seed so multiple dressers
	 *  with the same Seed never produce copy-pasted layouts. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Layout")
	bool bUniqueSeedPerLocation = true;

	/** Barrels + firing steps physically block movement (rest never collides). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Layout")
	bool bSolidProps = true;

	/** S19-TREDGE: keep props this far clear of both SPLINE ENDS (cm), so a
	 *  duckboard, barrel or wire run never overhangs into open air where the
	 *  trench stops. Set to 0 if your spline continues into another trench
	 *  section and you want the dressing to run right up to the join. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Layout", meta = (ClampMin = "0.0", ClampMax = "600.0"))
	float EndMarginCm = 120.f;

	/** S19-TREDGE: wire strands are laid as a polyline with one node roughly
	 *  every this many cm, so the wire follows a curving parapet instead of
	 *  cutting the corner as one straight chord. Smaller = smoother curve,
	 *  more instances. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Layout", meta = (ClampMin = "40.0", ClampMax = "400.0"))
	float WireSegmentCm = 110.f;

	// ===================== CATEGORY TOGGLES =====================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Categories") bool bDuckboards = true;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Categories") bool bRevetment = true;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Categories") bool bCorrugated = true;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Categories") bool bBarrels = true;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Categories") bool bAmmoCans = true;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Categories") bool bWirePickets = true;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Categories") bool bTarps = true;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Categories") bool bFiringSteps = true;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Categories") bool bDebris = true;
	/** S15-TRENCH2: plank + corrugated-sheet roof sections spanning the trench. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Categories") bool bOverheadCover = true;
	/** S15-TRENCH2: field-telephone poles along one parapet with a sagging comm line. */
	/** S18-TRWIRE2: field-telephone / electricity poles (تیرهای چراغ برق) along the
	 *  parapet. Turned OFF by default — you asked for them gone. Set true to bring
	 *  the pole line back; nothing else depends on it. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Categories") bool bCommWire = false;
	/** S15-TRENCH3: campfire spots — scorch mark ringed by blackened stones. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Categories") bool bFirePits = true;
	/** S15-TRENCH3: worn Persian prayer/rest rugs in quiet spots near the wall. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Categories") bool bPrayerRugs = false; // S18-FIX: Persian rugs off by default
	/** S15-TRENCH3: canvas stretchers lying along the trench wall. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Categories") bool bStretchers = true;
	/** S15-TRENCH3: wooden assault ladders leaning against the trench wall. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Categories") bool bLadders = true;
	/** S18-FIX: rough, splintered plank ends instead of sawn cube corners. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Categories") bool bRaggedPlankEnds = true;

	/** S18-FIX: ladders were everywhere — chance per wall slot (was effectively 0.64). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Categories", meta = (ClampMin = "0.0", ClampMax = "1.0"))
	float LadderChance = 0.16f;
	/** S15-TRENCH4 (COD look): walls shored nearly continuously (planks/corrugated), not sparse panels. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Categories") bool bContinuousShoring = true;
	/** S15-TRENCH4 (COD look): timber-framed dugout entrances cut into the trench wall. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Categories") bool bDugouts = true;
	/** S15-TRENCH4 (COD look): camouflage netting stretched over trench sections. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Categories") bool bCamoNetting = true;
	/** S15-TRENCH4 (COD look): helmets resting on wire stakes and firing steps. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Categories") bool bHelmets = true;
	/** S15-TRENCH5: some revetment panels collapsed/tilted with fallen planks (battle damage). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Categories") bool bBattleDamage = true;
	/** S15-TRENCH5: concertina wire coils between some parapet stakes. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Categories") bool bConcertinaCoils = true;
	/** S18-TRBAG: sandbag revetting along the parapet lip. Needs CustomSandbagMesh / CustomSandbagStackMesh. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Categories") bool bSandbags = false; // S18-FIX: user supplies his own sandbags
	/** S18-TRWIRE: prop barbed-wire entanglement runs out past the parapet. Needs CustomWireSetMesh. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Categories") bool bWireSets = true;
	/** S18-TRWIRE2: wooden X-frame obstacles (knife rests / chevaux de frise) carrying the wire. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Categories") bool bWireObstacles = true;

	// ===================== VISUALS =====================

	/** Custom meshes (optional). If set, placed with scale 1 and CustomMeshScale — author at real size. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Meshes") TObjectPtr<UStaticMesh> CustomDuckboardMesh;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Meshes") TObjectPtr<UStaticMesh> CustomRevetmentMesh;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Meshes") TObjectPtr<UStaticMesh> CustomBarrelMesh;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Meshes") TObjectPtr<UStaticMesh> CustomAmmoCanMesh;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Meshes") TObjectPtr<UStaticMesh> CustomStakeMesh;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Meshes") TObjectPtr<UStaticMesh> CustomTarpMesh;
	/** S18-TRBAG: single sandbag (author ~75x33x22 cm). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Meshes") TObjectPtr<UStaticMesh> CustomSandbagMesh;
	/** S18-TRBAG: sandbag stack/pile (author ~87x38x99 cm). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Meshes") TObjectPtr<UStaticMesh> CustomSandbagStackMesh;
	/** S18-TRWIRE: barbed-wire run props, laid end-to-end along the parapet.
	 *  Up to 4 different runs — the builder picks between them per segment so the
	 *  belt is never a repeating stamp. Leave unused slots empty. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Meshes") TObjectPtr<UStaticMesh> CustomWireSetMesh;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Meshes") TObjectPtr<UStaticMesh> CustomWireSetMesh2;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Meshes") TObjectPtr<UStaticMesh> CustomWireSetMesh3;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Meshes") TObjectPtr<UStaticMesh> CustomWireSetMesh4;
	/** S18-TRWIRE2: two more run slots (the pack ships 7 — A/B/C/D/E/F/G). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Meshes") TObjectPtr<UStaticMesh> CustomWireSetMesh5;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Meshes") TObjectPtr<UStaticMesh> CustomWireSetMesh6;
	/** S18-TRWIRE: length along local X, in cm, of each wire-set mesh above. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Meshes", meta = (ClampMin = "50.0", ClampMax = "2000.0")) float WireSetLengthCm = 210.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Meshes", meta = (ClampMin = "50.0", ClampMax = "2000.0")) float WireSetLengthCm2 = 510.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Meshes", meta = (ClampMin = "50.0", ClampMax = "2000.0")) float WireSetLengthCm3 = 325.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Meshes", meta = (ClampMin = "50.0", ClampMax = "2000.0")) float WireSetLengthCm4 = 264.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Meshes", meta = (ClampMin = "50.0", ClampMax = "2000.0")) float WireSetLengthCm5 = 110.f;  // S18-TRWIRE2
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Meshes", meta = (ClampMin = "50.0", ClampMax = "2000.0")) float WireSetLengthCm6 = 470.f;  // S18-TRWIRE2

	/** S18-TRWIRE2: wooden X-frame obstacle ("cross foundation", author ~243x137x120 cm, long axis = local X). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Meshes") TObjectPtr<UStaticMesh> CustomWireObstacleMesh;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Meshes", meta = (ClampMin = "50.0", ClampMax = "2000.0")) float WireObstacleLengthCm = 243.f;
	/** S18-TRWIRE2: how much of the wire belt stands on X-frames (0 = none, 1 = all). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Meshes", meta = (ClampMin = "0.0", ClampMax = "1.0")) float WireObstacleFraction = 0.55f;
	/** S18-TRWIRE2: standalone knife-rest road/approach blocks away from the wire belt. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Meshes", meta = (ClampMin = "0", ClampMax = "40")) int32 StandaloneObstacles = 6;

	/** S18-TRWIRE2: concertina coil props dropped at belt joints and against the X-frames. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Meshes") TObjectPtr<UStaticMesh> CustomWireCoilMesh;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Meshes") TObjectPtr<UStaticMesh> CustomWireCoilMesh2;
	/** S18-TRWIRE2: iron pigtail picket. Replaces the cube stakes used as wire pickets. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Meshes") TObjectPtr<UStaticMesh> CustomPigtailMesh;
	/** S18-FIX: keep the old cylinder-built barbed wire (coils AND stake strands)
	 *  even when wire-set props are assigned. Off = props only, no double wire. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Meshes") bool bKeepProceduralCoils = false;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Meshes", meta = (ClampMin = "0.1", ClampMax = "10.0")) float CustomMeshScale = 1.0f;

	/** S18-TRMESH: when a Custom*Mesh is assigned, render it with the MESH's own
	 *  materials (an imported prop already ships the correct atlas material)
	 *  instead of this actor's family slot. Turn off to force the family slot. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Meshes") bool bUseCustomMeshMaterials = true;

	/** Material overrides per family (optional — engine basic material + tint otherwise). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Materials") TObjectPtr<UMaterialInterface> WoodMaterial;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Materials") TObjectPtr<UMaterialInterface> MetalMaterial;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Materials") TObjectPtr<UMaterialInterface> ClothMaterial;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Materials") TObjectPtr<UMaterialInterface> GroundMaterial;

	/** S15-PBR: translucent burn-decal material for scorch patches (M_TrenchScorch). Falls back to GroundMaterial. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Materials") TObjectPtr<UMaterialInterface> ScorchMaterial;
	/** S15-TRENCH3: dedicated corrugated-sheet material (M_TrenchCorrugated). Falls back to MetalMaterial. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Materials") TObjectPtr<UMaterialInterface> CorrugatedMaterial;
	/** S15-TRENCH3: dedicated oil-drum material (M_TrenchDrum). Falls back to MetalMaterial. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Materials") TObjectPtr<UMaterialInterface> BarrelMaterial;
	/** S15-TRENCH3: dedicated ammo-can material (M_TrenchAmmoCan). Falls back to MetalMaterial. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Materials") TObjectPtr<UMaterialInterface> AmmoCanMaterial;
	/** S15-TRENCH3: rug material (M_TrenchRug — one full Persian carpet per plane). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Materials") TObjectPtr<UMaterialInterface> RugMaterial;
	/** S15-TRENCH4: camo net material (M_TrenchNetting — masked holes, two-sided). Falls back to ClothMaterial. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Materials") TObjectPtr<UMaterialInterface> NettingMaterial;

	/** Category tints (applied via one dynamic material instance per HISM). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Palette") FLinearColor WoodTint = FLinearColor(0.28f, 0.20f, 0.13f);
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Palette") FLinearColor DarkWoodTint = FLinearColor(0.17f, 0.12f, 0.08f);
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Palette") FLinearColor CorrugatedTint = FLinearColor(0.16f, 0.14f, 0.12f);
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Palette") FLinearColor BarrelTint = FLinearColor(0.13f, 0.15f, 0.09f);
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Palette") FLinearColor AmmoCanTint = FLinearColor(0.10f, 0.12f, 0.07f);
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Palette") FLinearColor WireTint = FLinearColor(0.04f, 0.04f, 0.04f);
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Palette") FLinearColor TarpTint = FLinearColor(0.35f, 0.31f, 0.22f);
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Palette") FLinearColor EarthTint = FLinearColor(0.30f, 0.23f, 0.15f);
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Palette") FLinearColor CasingTint = FLinearColor(0.55f, 0.40f, 0.12f);
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Palette") FLinearColor StoneTint = FLinearColor(0.42f, 0.36f, 0.28f);
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Palette") FLinearColor ScorchTint = FLinearColor(0.03f, 0.03f, 0.03f);
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Palette") FLinearColor RugTint = FLinearColor(0.30f, 0.09f, 0.07f); // S15-TRENCH3
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Palette") FLinearColor NettingTint = FLinearColor(0.32f, 0.28f, 0.18f); // S15-TRENCH4
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Palette") FLinearColor HelmetTint = FLinearColor(0.11f, 0.12f, 0.08f);  // S15-TRENCH4
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trench Palette") FLinearColor DugoutShadowTint = FLinearColor(0.006f, 0.006f, 0.006f); // S15-TRENCH4

	// ===================== ACTIONS =====================

	/** Scatter/refresh all trench details along the spline. */
	UFUNCTION(CallInEditor, BlueprintCallable, Category = "Trench Builder")
	void BuildDetails();

	/** Remove every generated instance. */
	UFUNCTION(CallInEditor, BlueprintCallable, Category = "Trench Builder")
	void ClearDetails();

	virtual void OnConstruction(const FTransform& Transform) override;

private:
	void AutoFillMaterials(); // S17-TRAUTO: self-fill empty slots from /Game/SquadAI/TrenchMaterials
	// S17-TRWALL: detected wall distances, sampled every 150cm along the spline.
	TArray<float> WallCacheL;
	TArray<float> WallCacheR;
	TArray<float> WallLeanL; // S17-TRWALL2: wall lean from vertical, degrees
	TArray<float> WallLeanR;
	TArray<float> WallHitL; // S17-TRGATE: 1 = probe found a REAL wall here
	TArray<float> WallHitR;
	void SampleTrenchWalls();
	float WallDistAt(float D, float Side) const;
	float WallLeanAt(float D, float Side) const; // S17-TRWALL2
	bool WallHitAt(float D, float Side) const; // S17-TRGATE
	float ParapetDistAt(float D, float Side) const;
	float FloorHalfAt(float D) const;
#if WITH_EDITOR
	// S17-TRPERF: debounced editor rebuild — dragging a spline handle fires
	// OnConstruction every mouse move; rebuilding thousands of instances each
	// time froze the editor. Now it rebuilds ONCE, shortly after the last edit.
	double LastSplineEditTime = 0.0;
	bool bDebounceRebuildPending = false;
	FTSTicker::FDelegateHandle DebounceTickerHandle;
	virtual void BeginDestroy() override;
#endif
	UHierarchicalInstancedStaticMeshComponent* MakeHISM(const TCHAR* Name);
	// S18-TRMESH: bMeshOwnsMaterial = the custom mesh carries its own authored
	// materials (Megascans props) -> do not override slot 0 AND do not tint.
	void ConfigureHISM(UHierarchicalInstancedStaticMeshComponent* HISM, UStaticMesh* Mesh,
		UMaterialInterface* Mat, const FLinearColor& Tint, bool bCollide,
		bool bMeshOwnsMaterial = false) const;
	bool TraceGroundZ(const FVector& Around, float& OutZ) const;
	bool TraceGround(const FVector& Around, float& OutZ, FVector& OutNormal) const; // S15-TRENCH6

	/** S19-TREDGE — the fix behind most of the "imperfections at the edges".
	 *
	 *  Anything that spans distance along the trench used to be placed by
	 *  offsetting from one spline point with a fixed tangent vector:
	 *      P + SplineRot.Vector() * Offset
	 *  On a straight trench that is fine. On a CURVED one it is a chord: the
	 *  two ends of a 175 cm plank row cut across the trench, so one end buried
	 *  itself in the wall and the other hung out over the floor. Same story
	 *  for walers, support posts and stake-to-stake wire.
	 *
	 *  Re-evaluating the spline at (D + DeltaAlong) instead gives each element
	 *  the position, right-vector and yaw of its OWN station, so it stays on
	 *  the wall face it belongs to. OutD is the clamped station actually used
	 *  (always inside [0, spline length]) — feed it back into WallDistAt /
	 *  WallLeanAt so the lateral offset matches the station too. */
	bool SampleAlongTrench(float D, float DeltaAlong,
		FVector& OutPos, FVector& OutRight, FRotator& OutRot, float& OutD) const;

	/** S15-TRENCH7: spline distances where dugouts were built this pass, so
	 *  camp-life furniture keeps clear of the doorways. Rebuilt every build. */
	TArray<float> DugoutBuildMarks;

	/** S15-TRENCH8 (env-art clustering): story anchors (firing steps, dugouts).
	 *  Loose props gravitate toward these instead of scattering uniformly. */
	TArray<float> ClusterAnchors;

	/** S15-TRENCH8 (negative space): phase of the rest-zone wave for this build. */
	float RestZonePhase = 0.f;

	/** S15-TRENCH8: ~1/3 of the line stays quiet — filler clutter skips these
	 *  stretches so busy vignettes read against calm ground. */
	bool IsRestZone(float D) const;

	// Scatter passes (Stream advances through all of them deterministically).
	void ScatterFloorLine(FRandomStream& Stream);
	void ScatterWalls(FRandomStream& Stream);
	void ScatterParapet(FRandomStream& Stream);
	void ScatterDebris(FRandomStream& Stream);
	void ScatterOverheadCover(FRandomStream& Stream); // S15-TRENCH2
	void ScatterCommWire(FRandomStream& Stream);      // S15-TRENCH2
	void ScatterCampLife(FRandomStream& Stream);      // S15-TRENCH3: fire pits, rugs, stretchers, ladders
	void ScatterSandbags(FRandomStream& Stream);      // S18-TRBAG
	void ScatterWireSets(FRandomStream& Stream);      // S18-TRWIRE
	void ScatterWireObstacles(FRandomStream& Stream); // S18-TRWIRE2: standalone X-frame blocks
	/** S18-FIX: bite the corners off a cube plank so it stops looking like cabinetry. */
	void RagPlankEnds(UHierarchicalInstancedStaticMeshComponent* Target,
		const FTransform& PlankXf, FRandomStream& Stream) const;
	void ScatterDugoutsAndNetting(FRandomStream& Stream); // S15-TRENCH4: dugout entrances + camo nets
};

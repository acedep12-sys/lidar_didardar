// WarAmbienceDirector.h — S17-EVNT: dynamic ambient war events.
// Drop ONE into the level. On a randomized timer it fires atmosphere events
// around the player using existing systems only: distant shellfire echoes,
// far-off gunfire exchanges, Farsi radio chatter bursts, and (optional) real
// harassment mortar salvos that land near — never on — the player. Makes the
// front feel alive between objectives. Everything is a toggle.
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "WarAmbienceDirector.generated.h"

UCLASS(BlueprintType, Blueprintable)
class SQUADAI_API AWarAmbienceDirector : public AActor
{
	GENERATED_BODY()

public:
	AWarAmbienceDirector();

	// ===== CONFIG =====

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "War Ambience")
	bool bEnabled = true;

	/** Random seconds between events (min..max). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "War Ambience", meta = (ClampMin = "10.0"))
	float MinEventInterval = 40.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "War Ambience", meta = (ClampMin = "15.0"))
	float MaxEventInterval = 90.f;

	/** Distant artillery/explosion echoes (sound only, no damage). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "War Ambience|Events")
	bool bDistantShellfire = true;

	/** Far-off small-arms exchanges (sound only). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "War Ambience|Events")
	bool bDistantGunfire = true;

	/** Farsi radio chatter bursts on the squad net. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "War Ambience|Events")
	bool bRadioChatterBursts = true;

	/** REAL harassment mortar salvo landing near (never on) the player —
	 *  whistle + HUD danger ring give fair warning. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "War Ambience|Events")
	bool bHarassmentBarrages = true;

	/** Sound-only events play this far from the player (cm). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "War Ambience|Tuning", meta = (ClampMin = "1500.0"))
	float DistantSoundRangeMin = 4000.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "War Ambience|Tuning", meta = (ClampMin = "2000.0"))
	float DistantSoundRangeMax = 8000.f;

	/** Harassment salvo center distance from the player (cm) — keep generous. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "War Ambience|Tuning", meta = (ClampMin = "1500.0"))
	float HarassMinDistance = 2600.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "War Ambience|Tuning", meta = (ClampMin = "2000.0"))
	float HarassMaxDistance = 4500.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "War Ambience|Tuning", meta = (ClampMin = "1", ClampMax = "6"))
	int32 HarassShellCount = 2;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "War Ambience|Tuning", meta = (ClampMin = "0.0"))
	float HarassShellDamage = 120.f;

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

private:
	FTimerHandle EventTimerHandle;
	FTimerHandle GunBurstHandle;
	int32 GunBurstShotsLeft = 0;
	FVector GunBurstLocation = FVector::ZeroVector;

	void ScheduleNextEvent();
	void FireRandomEvent();
	FVector RandomPointNearPlayer(float MinDist, float MaxDist) const;

	void EventDistantShellfire();
	void EventDistantGunfire();
	void EventRadioChatter();
	void EventHarassmentBarrage();
	void PlayGunBurstShot();
};

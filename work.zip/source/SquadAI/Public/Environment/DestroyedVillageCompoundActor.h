#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "DestroyedVillageCompoundActor.generated.h"

class UMaterialInterface;
class UMaterialInstanceDynamic;
class UStaticMesh;
class UHierarchicalInstancedStaticMeshComponent;
class ADestroyedBuildingActor;
class ATacticalTrenchSplineActor;
class ACombatEncounterVolume;

/**
 * ADestroyedVillageCompoundActor
 * Procedural Destroyed Middle-Eastern Village Cluster & Combat Arena.
 * 
 * Drop this actor into any open space to instantly construct an entire war-torn
 * Middle Eastern village, complete with ruined houses, market alleys, defensive barricades,
 * heavy machine gun posts, and an automated combat encounter.
 */
UCLASS(BlueprintType, Blueprintable, meta = (DisplayName = "Destroyed Village Generator"))
class SQUADAI_API ADestroyedVillageCompoundActor : public AActor
{
	GENERATED_BODY()

public:
	ADestroyedVillageCompoundActor();

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<USceneComponent> SceneRoot;

	// =========================================================================
	//  CONFIG
	// =========================================================================

	/** Total number of ruined buildings to generate in the village (3 to 8) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Layout", meta = (ClampMin = "2", ClampMax = "12"))
	int32 BuildingCount = 5;

	/** Radius in cm of the village spread (e.g. 3500cm = 35m) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Layout", meta = (ClampMin = "1500.0", ClampMax = "10000.0"))
	float VillageRadius = 3500.0f;

	/** Random seed for procedural village layout */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Layout")
	int32 VillageSeed = 54321;

	/** If true, spawns a combat encounter arena volume over the village */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Combat")
	bool bCreateCombatEncounter = true;

	/** If true, automatically generates tactical cover nodes across the village */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Combat")
	bool bGenerateCoverNodes = true;

	/** Optional material override for mudbrick walls across the village */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Materials")
	TObjectPtr<UMaterialInterface> VillageWallMaterial;

		/** Optional material override for rubble across the village */
		UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Materials")
		TObjectPtr<UMaterialInterface> VillageRubbleMaterial;

		/** Optional material override for floors and plazas across the village */
		UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Materials")
		TObjectPtr<UMaterialInterface> VillageFloorMaterial;

		/** Optional material override for wooden rafters and crates across the village */
		UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Materials")
		TObjectPtr<UMaterialInterface> VillageWoodMaterial;

		/** Optional material override for sandbag fortifications across the village */
		UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Materials")
		TObjectPtr<UMaterialInterface> VillageSandbagMaterial;

		/** Optional custom static mesh for walls across the village */
		UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Meshes")
		TObjectPtr<UStaticMesh> CustomVillageWallMesh;

		/** Optional custom static mesh for sandbag fortifications */
		UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Meshes")
		TObjectPtr<UStaticMesh> CustomVillageSandbagMesh;

		/** Optional custom static mesh for wooden catwalks and beams across the village */
		UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Meshes")
		TObjectPtr<UStaticMesh> CustomVillageWoodMesh;

		/** Optional custom static mesh for rubble debris across the village */
		UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Meshes")
		TObjectPtr<UStaticMesh> CustomVillageRubbleMesh;

		/** If true, spawns street sandbag barricades and defensive checkpoints between buildings */
		UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Layout")
		bool bSpawnStreetBarricades = true;

	/** If true, spawns connecting perimeter compound walls between adjacent buildings */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Layout")
	bool bSpawnPerimeterWalls = true;

	/** If true, builds the central plaza landmark: a stone well ring with a broken monument column and its toppled cap piece */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Layout")
	bool bSpawnPlazaMonument = true;

	/** If true, scatters war-damage rubble mounds across the streets between the plaza and the buildings */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Layout")
	bool bSpawnRubbleMounds = true;

	/** How many rubble mounds to scatter (uses the rubble mesh override when set; low mounds are walkover, tall ones block movement) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Layout", meta = (ClampMin = "0", ClampMax = "24"))
	int32 RubbleMoundCount = 6;

	/** If true, drops small wooden clutter (crate stacks, cart planks) in the alleys just outside building doorways */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Layout")
	bool bSpawnStreetClutter = true;

	/** How many street clutter pieces to drop (thin cart planks are walkover, bulky crates block movement) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Layout", meta = (ClampMin = "0", ClampMax = "40"))
	int32 StreetClutterCount = 8;

	/** If true, raises defensive sandbag arcs along the outer rim of the village (facing outward, per arc: 3 segments) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Layout")
	bool bSpawnPerimeterSandbags = true;

	/** How many outer defensive sandbag arcs to raise */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Layout", meta = (ClampMin = "0", ClampMax = "8"))
	int32 PerimeterSandbagArcs = 3;

	// =========================================================================
	//  V2 REALISM PASSES (seeded; reuse the material/mesh overrides above)
	// =========================================================================

	/** If true, anchors the layout to a gently curving main street: ~60% of buildings line the road (alternating sides, facing it), the rest cluster around the plaza */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Layout")
	bool bOrganicStreetLayout = true;

	/** S6-M: include the village mosque (minaret style) in the building rotation. OFF reproduces the original 5-style rotation exactly */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Layout")
	bool bIncludeMosque = true;

	/** If true, lays a flattened dirt-road ribbon along the street plus a plaza pad and a cross alley (NoCollision, walkover) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Layout")
	bool bSpawnMainRoad = true;

	/** Tint applied to the road/plaza/alley ribbons via a runtime dynamic material instance (silently skipped if the base material exposes no colour parameter) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Materials")
	FLinearColor RoadTint = FLinearColor(0.30f, 0.25f, 0.18f, 1.0f);

	/** If true, raises makeshift gate frames (wall posts + wood lintel; one intact, one battle-collapsed) at both ends of the main street */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Layout")
	bool bSpawnGateFrames = true;

	/** If true, adds L-shaped low courtyard walls beside most buildings (the signature compound yard of Iraqi/Iranian villages) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Layout")
	bool bSpawnCourtyardWalls = true;

	/** If true, rows weathered wooden posts with crossbars along the street; ~30% are snapped and fallen */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Layout")
	bool bSpawnTelegraphPoles = true;

	/** If true, puts a leaning wooden A-frame + bucket over the plaza well */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Layout")
	bool bSpawnWellAFrame = true;

	/** If true, lays dark scorch/dust patches at building wall bases (tinted thin quads; NoCollision) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Layout")
	bool bSpawnScorchPatches = true;

	/** Tint for scorch patches (applied via runtime DMI; silently skipped on param-less materials) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Materials")
	FLinearColor ScorchTint = FLinearColor(0.09f, 0.08f, 0.07f, 1.0f);

	// =========================================================================
	//  S8-MAT: MATERIAL RESOLUTION + VILLAGE PALETTE
	//  Every prop resolves its material through a category fallback chain
	//  (explicit override -> related override -> engine BasicShapeMaterial), so
	//  the village never renders in default grey when no art is assigned, and
	//  always matches the buildings standing inside it. The palette below then
	//  separates the categories by colour via runtime DMIs. No assets created.
	// =========================================================================

	/** If true, applies the category palette tints below via runtime dynamic material instances, so mudbrick, wood, sandbags and rubble read as different materials even on a shared base material. Turn OFF when your own textured materials already carry their colour. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Materials")
	bool bApplyVillagePalette = true;

	/** Palette tint for mudbrick walls, compound walls, gate posts and the well ring (sun-bleached desert plaster) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Materials")
	FLinearColor WallTint = FLinearColor(0.72f, 0.62f, 0.47f, 1.0f);

	/** Palette tint for rubble mounds, debris and the broken monument (cool grey-brown broken masonry) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Materials")
	FLinearColor RubbleTint = FLinearColor(0.46f, 0.42f, 0.36f, 1.0f);

	/** Palette tint for catwalks, poles, lintels, crates and cart planks (weathered sun-dried timber) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Materials")
	FLinearColor WoodTint = FLinearColor(0.38f, 0.26f, 0.16f, 1.0f);

	/** Palette tint for sandbag barricades and perimeter arcs (dusty olive hessian) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Materials")
	FLinearColor SandbagTint = FLinearColor(0.44f, 0.41f, 0.28f, 1.0f);

	/** If true, places a couple of warm shadowless point lights in doorways for an occupied-at-dusk feel */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Atmosphere")
	bool bSpawnInteriorLights = true;

	/** S7-H: batch the untinted V2 props and the road/scorch ribbons into shared HISM components (huge actor-count reduction for large villages). ClearVillage-safe. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Village Performance")
	bool bBatchV2PropsIntoHISM = true;

	/** INTERNAL — S8-MAT: one palette DMI per category, rebuilt with the village. */
	UPROPERTY(Transient)
	TMap<int32, TObjectPtr<UMaterialInstanceDynamic>> PaletteCache;

	/** INTERNAL — S8-MAT: resolves the material for a village category (0=Wall 1=Rubble 2=Floor/Road 3=Wood 4=Sandbag), falling back through related overrides to the engine BasicShapeMaterial so nothing ever renders default grey. */
	UMaterialInterface* ResolveVillageMaterial(int32 Category) const;

	/** INTERNAL — S8-MAT: category material already tinted with the palette (cached dynamic instance), suitable for forwarding to child building actors so they match the props. Returns the plain resolved material when the palette is off. */
	UMaterialInterface* GetPalettedVillageMaterial(int32 Category);

	/** INTERNAL — S8-MAT: palette tint for a village category, or nullptr when the palette is disabled. */
	const FLinearColor* GetVillageCategoryTint(int32 Category) const;

	/** INTERNAL — resolves (lazily creates) the shared HISM for a V2 batch kind: 1=Road 2=Scorch 3=WallProps 4=WoodProps. Nullptr when batching disabled. */
	UHierarchicalInstancedStaticMeshComponent* EnsureV2BatchComponent(int32 BatchKind, UStaticMesh* Mesh, UMaterialInterface* Mat, const FLinearColor* Tint);

	// =========================================================================
	//  API
	// =========================================================================

	UFUNCTION(BlueprintCallable, CallInEditor, Category = "Village Actions")
	void BuildVillage();

	UFUNCTION(BlueprintCallable, CallInEditor, Category = "Village Actions")
	void RandomizeAndRebuild();

		UFUNCTION(BlueprintCallable, CallInEditor, Category = "Village Actions")
		void ClearVillage();

		/** Snaps the village compound and all child buildings firmly to the terrain elevation */
		UFUNCTION(BlueprintCallable, CallInEditor, Category = "Village Actions")
		void SnapVillageToGround();

		UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Village Actions")
		int32 GetBuildingCount() const { return SpawnedBuildings.Num(); }

protected:
	virtual void BeginPlay() override;
	/** S10-FIX: tear the village down with the actor. */
	virtual void Destroyed() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

private:
	UPROPERTY()
	TArray<TObjectPtr<AActor>> SpawnedBuildings;
};

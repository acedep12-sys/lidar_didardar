// SquadAIWeaponVisualPreset.h — Data asset storing ALL visual assets for a weapon type.
// Create one per weapon (AK, SMG, RPG, Pistol, etc.) and assign to characters.
// The factory can auto-create these from TPWCS data tables.
#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "Animation/BlendSpace.h"
#include "Particles/ParticleSystem.h"
#include "NiagaraSystem.h"
#include "Sound/SoundBase.h"
#include "Animation/AnimMontage.h"
#include "Engine/SkeletalMesh.h"
#include "SquadAIWeaponVisualPreset.generated.h"

UCLASS(BlueprintType)
class SQUADAI_API USquadAIWeaponVisualPreset : public UPrimaryDataAsset
{
	GENERATED_BODY()

public:
	// === WEAPON IDENTITY ===
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon")
	FName WeaponID = TEXT("ak");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon")
	FString DisplayName = TEXT("AK-47");

	// === FIRING VFX ===
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "VFX|Firing")
	TSoftObjectPtr<UParticleSystem> MuzzleFlashCascade;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "VFX|Firing")
	TSoftObjectPtr<UNiagaraSystem> MuzzleFlashNiagara;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "VFX|Firing")
	TSoftObjectPtr<UParticleSystem> BulletTrailCascade;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "VFX|Firing")
	TSoftObjectPtr<UNiagaraSystem> BulletTrailNiagara;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "VFX|Firing")
	float BulletTrailScale = 1.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "VFX|Firing")
	float BulletHoleSize = 5.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "VFX|Firing")
	TSoftObjectPtr<UParticleSystem> BulletImpactCascade;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "VFX|Firing")
	TSoftObjectPtr<UNiagaraSystem> BulletImpactNiagara;

	// === FIRING SOUNDS ===
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sound|Firing")
	TSoftObjectPtr<USoundBase> FireSound;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sound|Firing")
	TSoftObjectPtr<USoundBase> FireTailSound;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sound|Firing")
	TSoftObjectPtr<USoundBase> EmptyClipSound;

	// === ANIMATIONS ===
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation|Firing")
	TSoftObjectPtr<UAnimMontage> FiringMontage;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation|Firing")
	TSoftObjectPtr<UAnimMontage> FiringMontageCrouched;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation|Reload")
	TSoftObjectPtr<UAnimMontage> ReloadMontage;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation|Equip")
	TSoftObjectPtr<UAnimMontage> EquipMontage;

	// === MOVEMENT ===
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation|Movement")
	TSoftObjectPtr<UBlendSpace> AimingIdleBlendSpace;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation|Movement")
	TSoftObjectPtr<UBlendSpace> AimingMovementBlendSpace;

	// === PROJECTILE (for RPG, grenades, etc.) ===
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Projectile")
	TSoftClassPtr<AActor> ProjectileClass;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Projectile")
	TSoftObjectPtr<UParticleSystem> ExplosionVFX;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Projectile")
	TSoftObjectPtr<USoundBase> ExplosionSound;

	// === SOCKETS ===
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sockets")
	FName MuzzleSocketName = TEXT("Muzzle");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sockets")
	FName LeftHandIKSocketName = TEXT("LeftHandIK");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sockets")
	FName ShellEjectSocketName = TEXT("ShellEject");

	// === WEAPON MESH ===
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mesh")
	TSoftObjectPtr<USkeletalMesh> WeaponSkeletalMesh;

	// Helper: synchronously load all assets
	void LoadAllAssets();

	// Auto-populate all fields from TPWCS DT_Weapons + DT_WeaponAnims data tables.
	// Call this after setting WeaponID. Searches for the weapon row, reads VFX/sound/anim
	// references, and fills in all preset fields automatically.
	UFUNCTION(CallInEditor, Category = "Weapon|Auto-Setup")
	void AutoPopulateFromTPWCS();

	// Cached loaded references (runtime only, not serialized)
	UPROPERTY(Transient) // F-C2: TObjectPtr must be UPROPERTY (Transient = GC-visible, not serialized).
	TObjectPtr<UParticleSystem> LoadedMuzzleFlash = nullptr;
	UPROPERTY(Transient) // F-C2: TObjectPtr must be UPROPERTY (Transient = GC-visible, not serialized).
	TObjectPtr<UNiagaraSystem> LoadedMuzzleFlashNS = nullptr;
	UPROPERTY(Transient) // F-C2: TObjectPtr must be UPROPERTY (Transient = GC-visible, not serialized).
	TObjectPtr<UParticleSystem> LoadedBulletTrail = nullptr;
	UPROPERTY(Transient) // F-C2: TObjectPtr must be UPROPERTY (Transient = GC-visible, not serialized).
	TObjectPtr<UNiagaraSystem> LoadedBulletTrailNS = nullptr;
	UPROPERTY(Transient) // F-C2: TObjectPtr must be UPROPERTY (Transient = GC-visible, not serialized).
	TObjectPtr<UParticleSystem> LoadedBulletImpact = nullptr;
	UPROPERTY(Transient) // F-C2: TObjectPtr must be UPROPERTY (Transient = GC-visible, not serialized).
	TObjectPtr<UAnimMontage> LoadedFiringMontage = nullptr;
	UPROPERTY(Transient) // F-C2: TObjectPtr must be UPROPERTY (Transient = GC-visible, not serialized).
	TObjectPtr<UAnimMontage> LoadedReloadMontage = nullptr;
	UPROPERTY(Transient) // F-C2: TObjectPtr must be UPROPERTY (Transient = GC-visible, not serialized).
	TObjectPtr<UAnimMontage> LoadedEquipMontage = nullptr;
	UPROPERTY(Transient) // F-C2: TObjectPtr must be UPROPERTY (Transient = GC-visible, not serialized).
	TObjectPtr<USoundBase> LoadedFireSound = nullptr;
	UPROPERTY(Transient) // F-C2: TObjectPtr must be UPROPERTY (Transient = GC-visible, not serialized).
	TObjectPtr<USoundBase> LoadedFireTailSound = nullptr;
	UPROPERTY(Transient) // F-C2: TObjectPtr must be UPROPERTY (Transient = GC-visible, not serialized).
	TObjectPtr<USoundBase> LoadedEmptyClipSound = nullptr;
	UPROPERTY(Transient) // F-C2: TObjectPtr must be UPROPERTY (Transient = GC-visible, not serialized).
	TObjectPtr<USkeletalMesh> LoadedWeaponMesh = nullptr;
};

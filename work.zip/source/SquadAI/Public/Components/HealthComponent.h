// HealthComponent.h — Single chokepoint for all damage
// bInvincible clamps HP but still fires damage events (flinch animations work)
#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "HealthComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FOnHealthDamaged, float, Damage, AActor*, DamageCauser, float, NewHealth);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnHealthDied, AActor*, OwnerActor);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnHealthChanged, float, NewHealthPercent);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_FourParams(FOnExternalDamageReceived, float, Damage, AActor*, DamageCauser, AController*, InstigatorController, TSubclassOf<UDamageType>, DamageTypeClass);

UCLASS(ClassGroup=(Combat), meta=(BlueprintSpawnableComponent, DisplayName = "Health"))
class SQUADAI_API UHealthComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UHealthComponent();

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Health")
	float MaxHealth = 100.f;

	UPROPERTY(BlueprintReadOnly, Category = "Health")
	float CurrentHealth = 100.f;

	// If true, health never reaches 0 — allies use this
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Health")
	bool bInvincible = false;

	// Dev-cheat god mode (B7-5): set by USquadAIDevDebugSubsystem::ToggleGodMode.
	// Unlike bInvincible, damage is fully ignored — no events, no flinch.
	UPROPERTY(BlueprintReadWrite, Category = "Health")
	bool bCheatGodMode = false;

	// S19-ELITE: outgoing-to-incoming damage scale. 1 = normal. The commander's command
	// aura writes this on his men while the net is up; it is restored to 1 the moment the
	// net lapses (or he dies), so it can never be left sticking to an actor.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Health", meta = (ClampMin = "0.05", ClampMax = "2.0"))
	float IncomingDamageMultiplier = 1.f;

	// S19-ELITE: no single hit may take more than this fraction of MaxHealth (0 = off).
	// Set on the commander (0.45): a headshot, a shell or a direct grenade cannot delete
	// an elite between two frames - his bar has to fall in front of the player.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Health", meta = (ClampMin = "0.0", ClampMax = "1.0"))
	float MaxSingleHitFraction = 0.f;

	// Minimum health when invincible (so allies can still "look hurt")
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Health",
		meta = (EditCondition = "bInvincible"))
	float InvincibleMinHealth = 1.f;

	UPROPERTY(BlueprintReadOnly, Category = "Health")
	bool bIsDead = false;

	// ---- Events ----
	UPROPERTY(BlueprintAssignable, Category = "Health|Events")
	FOnHealthDamaged OnDamaged;

	UPROPERTY(BlueprintAssignable, Category = "Health|Events")
	FOnHealthDied OnDeath;

	UPROPERTY(BlueprintAssignable, Category = "Health|Events")
	FOnHealthChanged OnHealthChanged;

	UPROPERTY(BlueprintAssignable, Category = "Health|Events")
	FOnExternalDamageReceived OnExternalDamageReceived;

	// ---- API ----

	// THE single damage entry point. Everything goes through here.
	UFUNCTION(BlueprintCallable, Category = "Health")
	float ApplyDamage(float DamageAmount, AActor* DamageCauser);

	UFUNCTION(BlueprintCallable, Category = "Health")
	float ApplyExternalDamage(float DamageAmount, AActor* DamageCauser, AController* InstigatorController, TSubclassOf<UDamageType> DamageTypeClass);

	UFUNCTION(BlueprintCallable, Category = "Health")
	void Heal(float Amount);

	UFUNCTION(BlueprintCallable, Category = "Health")
	void Revive();

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Health")
	float GetHealthPercent() const { return MaxHealth > 0.f ? CurrentHealth / MaxHealth : 0.f; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Health")
	bool IsAlive() const { return !bIsDead; }

protected:
	virtual void BeginPlay() override;
};

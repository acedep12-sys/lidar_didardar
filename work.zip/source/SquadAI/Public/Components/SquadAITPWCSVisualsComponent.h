// SquadAITPWCSVisualsComponent.h — PURE VISUAL bridge to TPWCS pack
// SquadAI handles ALL gameplay logic. This component ONLY handles:
// - Weapon pose (aiming state, left hand IK) via TPWCS BPC_WeaponCharacterAI properties
// - Firing animation (play montage on character mesh)
// - Muzzle flash (spawn particle at weapon muzzle socket)
// - Bullet trail (spawn particle from muzzle to hit point)
// - Fire sound (play at weapon location)
// NO TPWCS firing logic. NO TPWCS damage. NO TPWCS projectiles.
#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "SquadAIWeaponVisualPreset.h"
#include "SquadAITPWCSVisualsComponent.generated.h"

class USkeletalMeshComponent;
class UParticleSystem;
class UNiagaraSystem;
class UAnimMontage;
class USoundBase;

UCLASS(ClassGroup=(SquadAI), meta=(BlueprintSpawnableComponent, DisplayName = "SquadAI TPWCS Visuals"))
class SQUADAI_API USquadAITPWCSVisualsComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	USquadAITPWCSVisualsComponent();

	// === WEAPON PRESET ===
	// Assign a weapon visual preset (created per weapon type: AK, SMG, RPG, etc.)
	// The factory auto-creates and assigns these.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|Weapon")
	TObjectPtr<USquadAIWeaponVisualPreset> WeaponPreset;

	// Quick weapon ID (used if no preset assigned — auto-searches for matching preset)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|Weapon")
	FName WeaponID = TEXT("ak");

	// === PUBLIC API (called by SquadAI adapter/controller) ===

	// Set aiming pose — weapon rotates toward target, left hand IK grips foregrip
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Visuals")
	void SetAimPose(AActor* AimTarget, const FVector& AimLocation);

	// Clear aiming pose — return to idle
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Visuals")
	void ClearAimPose();

	// Play one shot visual: firing montage + muzzle flash + bullet trail + fire sound
	// Called by our WeaponComponent after each hitscan shot.
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Visuals")
	void PlayShotVisuals(const FVector& HitLocation);

	// Play reload animation
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Visuals")
	void PlayReloadVisuals();

	// Play equip animation
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Visuals")
	void PlayEquipVisuals();

	// Initialize weapon pose on BeginPlay
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Visuals")
	void InitializeWeaponPose();

	// === RUNTIME STATE (read-only) ===
	UPROPERTY(BlueprintReadOnly, Category = "SquadAI|Runtime")
	TObjectPtr<USkeletalMeshComponent> ResolvedWeaponMesh = nullptr;

	UPROPERTY(BlueprintReadOnly, Category = "SquadAI|Runtime")
	TObjectPtr<USkeletalMeshComponent> ResolvedCharacterMesh = nullptr;

	UPROPERTY(BlueprintReadOnly, Category = "SquadAI|Runtime")
	bool bSetupComplete = false;

	UPROPERTY(BlueprintReadOnly, Category = "SquadAI|Runtime")
	bool bIsAiming = false;

protected:
	virtual void BeginPlay() override;

private:
	UPROPERTY() TObjectPtr<UObject> WeaponComp = nullptr; // BPC_WeaponCharacterAI (for pose properties only)

	bool bInitialized = false;

	void FindComponents();
	void ResolvePreset();
	void TryAutoFindPreset();

	// Pose helpers — set properties on BPC_WeaponCharacterAI for AnimBP
	bool SetBoolOnWeapon(const TArray<FName>& Names, bool bValue);
	bool SetByteOnWeapon(const TArray<FName>& Names, uint8 Value);
	bool SetVectorOnWeapon(const TArray<FName>& Names, const FVector& Value);
	bool SetObjectOnWeapon(const TArray<FName>& Names, UObject* Value);
};

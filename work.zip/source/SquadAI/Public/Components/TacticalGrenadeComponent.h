#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Tactical/TacticalGrenadeActor.h"
#include "Tactical/GrenadeFlightModel.h"   // S19-GRENARC
#include "TacticalGrenadeComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FOnGrenadeThrown, AActor*, Thrower, EGrenadeType, Type, FVector, TargetLocation);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnGrenadeInventoryChanged, int32, FragCount, int32, SmokeCount);

/**
 * UTacticalGrenadeComponent
 * Tactical Ordnance & Throwing Component.
 * Enables Player and AI soldiers to throw fragmentation and smoke grenades with physics trajectories.
 */
UCLASS(ClassGroup = (Combat), meta = (BlueprintSpawnableComponent, DisplayName = "Tactical Grenades"))
class SQUADAI_API UTacticalGrenadeComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UTacticalGrenadeComponent();

	// =========================================================================
	//  INVENTORY & CONFIGURATION
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Inventory", meta = (ClampMin = "0", ClampMax = "10"))
	int32 FragGrenadesRemaining = 2;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Inventory", meta = (ClampMin = "1", ClampMax = "10"))
	int32 MaxFragGrenades = 4;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Inventory", meta = (ClampMin = "0", ClampMax = "10"))
	int32 SmokeGrenadesRemaining = 2;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Inventory", meta = (ClampMin = "1", ClampMax = "10"))
	int32 MaxSmokeGrenades = 4;

	/** Minimum delay between successive grenade throws */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Combat", meta = (ClampMin = "0.5"))
	float ThrowCooldown = 3.0f;

	/** Base launch speed in cm/s */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Combat")
	float LaunchSpeed = 1600.0f;

	/** Class of grenade actor spawned */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Class")
	TSubclassOf<ATacticalGrenadeActor> GrenadeClass;

	/**
	 * S19-TUT: free ammo. The tutorial turns this on for the grenade lesson so
	 * the step can never dead-end on an empty pouch — you were asked to learn
	 * a throw, not to manage inventory. The throw cooldown still applies, so
	 * it cannot be spammed. Gameplay code must never set this.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Inventory")
	bool bUnlimitedGrenades = false;

	/**
	 * S19-TUT: show where a grenade would land while you look around. The arc
	 * and the landing ring are drawn by the native HUD (no assets required).
	 * Off outside the tutorial by default so normal play stays clean.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Preview")
	bool bShowThrowPreview = false;

	/** S19-TUT: seconds of simulated flight per arc sample. Lower = smoother
	 *  and slightly more expensive. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Preview", meta = (ClampMin = "0.016", ClampMax = "0.2"))
	float PreviewStepTime = 0.025f;

	/** S19-TUT: hard cap on arc samples (~0.025 s * 200 = 5 s of flight). The flight
	 *  model guarantees the cap still covers the fuse, so it can only make the arc
	 *  coarser - never cut the simulation short. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Preview", meta = (ClampMin = "10", ClampMax = "600"))
	int32 PreviewMaxSteps = 200;

	/** S19-GRENARC: how many bounces the faded tail follows. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Preview", meta = (ClampMin = "0", ClampMax = "12"))
	int32 PreviewMaxBounces = 6;

	UPROPERTY(BlueprintAssignable, Category = "Grenade|Events")
	FOnGrenadeThrown OnGrenadeThrown;

	UPROPERTY(BlueprintAssignable, Category = "Grenade|Events")
	FOnGrenadeInventoryChanged OnGrenadeInventoryChanged;

	// =========================================================================
	//  API
	// =========================================================================

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Grenade")
	bool CanThrowGrenade(EGrenadeType Type) const;

	UFUNCTION(BlueprintCallable, Category = "Grenade")
	bool ThrowGrenadeAtLocation(EGrenadeType Type, const FVector& TargetLocation);

	UFUNCTION(BlueprintCallable, Category = "Grenade")
	bool ThrowGrenadeInDirection(EGrenadeType Type, const FVector& Direction);

	// Step3 residual (G/H legacy input): no-arg Enhanced-Input-ready entries — bind
	// IA_ThrowFrag/IA_ThrowSmoke to these; the Tick single-listener rule is unchanged.
	UFUNCTION(BlueprintCallable, Category = "Grenade")
	bool ThrowFragForward();

	UFUNCTION(BlueprintCallable, Category = "Grenade")
	bool ThrowSmokeForward();

	UFUNCTION(BlueprintCallable, Category = "Grenade")
	void RefillGrenades(int32 FragCount = 2, int32 SmokeCount = 2);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Grenade")
	int32 GetFragCount() const { return FragGrenadesRemaining; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Grenade")
	int32 GetSmokeCount() const { return SmokeGrenadesRemaining; }

	// =========================================================================
	//  S19-TUT: THROW PREVIEW
	// =========================================================================

	/** Where a grenade actually leaves the hand. The preview MUST start here or
	 *  the drawn arc will not match the real throw. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Grenade|Preview")
	FVector GetThrowOrigin(const FVector& Direction) const;

	/** The launch velocity a throw in `Direction` would use (arc included). */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Grenade|Preview")
	FVector GetThrowVelocity(const FVector& Direction) const;

	/**
	 * Simulate a throw and return the flight path.
	 * OutPath      – sample points from the hand to the impact (or the last
	 *                simulated point when nothing was hit).
	 * OutImpact    – where it lands.
	 * bOutImpacted – false when the arc left the playable world / timed out.
	 * Uses the same numbers as ThrowGrenadeInDirection(), so what you see is
	 * what you get.
	 */
	UFUNCTION(BlueprintCallable, Category = "Grenade|Preview")
	bool PredictThrowPath(const FVector& Direction, TArray<FVector>& OutPath,
		FVector& OutImpact, bool& bOutImpacted) const;

	/** Where the player is currently looking (falls back to the pawn forward). */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Grenade|Preview")
	FVector GetCurrentThrowDirection() const;

	// =========================================================================
	//  S19-AIM: HOLD-TO-AIM
	//  [G]/[H] used to throw on the key PRESS, so there was no aiming phase and
	//  therefore nothing for the HUD to preview. Now: hold to aim (the HUD
	//  draws the arc + landing ring while held), release to throw.
	// =========================================================================

	/** Hold [G]/[H] to aim, release to throw. Turn off for the old
	 *  press-to-throw behaviour. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Aim")
	bool bHoldToAim = true;

	/** True while the player is holding [G]/[H] and aiming a throw. */
	UPROPERTY(BlueprintReadOnly, Category = "Grenade|Aim")
	bool bIsAimingGrenade = false;

	/** Which grenade is being aimed. Only meaningful while bIsAimingGrenade. */
	UPROPERTY(BlueprintReadOnly, Category = "Grenade|Aim")
	EGrenadeType AimingGrenadeType = EGrenadeType::Fragmentation;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Grenade|Aim")
	bool IsAimingGrenade() const { return bIsAimingGrenade; }

	// S19-GRENARC: the aim phase as an API. The input that owns G/H lives in
	// USquadAIPlayerCombatBridge (this component only listens when no bridge is
	// attached), so both listeners drive the SAME state through these three calls -
	// otherwise the HUD preview would follow a throw that never happened.
	/** Start aiming `Type`. False (and no state change) when it cannot be thrown. */
	UFUNCTION(BlueprintCallable, Category = "Grenade|Aim")
	bool BeginAim(EGrenadeType Type);

	/** Abandon the aim without throwing (pause, inventory, death). */
	UFUNCTION(BlueprintCallable, Category = "Grenade|Aim")
	void CancelAim();

	/** Release: throw what is being aimed. False when nothing was aimed or the throw
	 *  was rejected (cooldown). Always ends the aim. */
	UFUNCTION(BlueprintCallable, Category = "Grenade|Aim")
	bool ReleaseAim();

	/** Which grenade the aim would throw (Fragmentation when not aiming). */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Grenade|Aim")
	EGrenadeType GetAimingGrenadeType() const { return AimingGrenadeType; }

	// =========================================================================
	//  S19-GRENARC: FLIGHT MODEL
	// =========================================================================

	/** The real numbers behind a throw, read from the grenade class's defaults (the
	 *  actor's fuse / blast radius and its ProjectileMovement's gravity scale,
	 *  bounciness, friction, stop threshold). The HUD predicts with THIS, so the arrow
	 *  and the grenade cannot drift apart when a designer retunes the actor. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Grenade|Preview")
	FGrenadeFlightParams GetFlightParams(EGrenadeType Type) const;

	/** Everything the HUD arrow needs: the path to the first contact, the faded bounce
	 *  tail after it, and where and when the grenade actually goes off. */
	UFUNCTION(BlueprintCallable, Category = "Grenade|Preview")
	bool PredictThrowDetailed(EGrenadeType Type, const FVector& Direction,
		TArray<FVector>& OutPath, TArray<FVector>& OutTail, FGrenadeFlightResult& OutResult) const;

protected:
	virtual void BeginPlay() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

private:
	bool ThrowTowardControlRotation(EGrenadeType Type);
	float LastThrowTime = -100.0f;
	bool bGKeyDownPrev = false;
	bool bHKeyDownPrev = false;
};

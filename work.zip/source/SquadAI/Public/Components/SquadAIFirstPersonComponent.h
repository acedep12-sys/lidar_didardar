// SquadAIFirstPersonComponent.h — runtime third- to first-person conversion for the pack player.
// S27-FP: the player pawn is the third-party TPWCS pack character (never edited, WP-safe),
// so the camera conversion is a runtime component the diagnostic subsystem bolts onto the
// gameplay pawn — same attach pattern as the combat bridge. What it does while enabled:
//   * retracts the pack's camera boom to ~10 cm and raises its pivot to eye height,
//   * hides the player's own meshes with OwnerNoSee (AI perception and shadows unaffected —
//     the body still casts the shadow you see on the ground),
//   * spawns a first-person viewmodel copy of the equipped weapon attached to the camera
//     (SquadAI.FP.Viewmodel 0 keeps the real third-person weapon visible instead),
//   * eases FOV + the viewmodel toward an aim pose while the right mouse button is held.
// Restore is exact: every saved boom/camera/visibility value goes back, the clone is destroyed.
// Toggle in game with F6, or gate the auto-apply with the SquadAI.FP.Enable console variable.
#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "SquadAIFirstPersonComponent.generated.h"

class UCameraComponent;
class USpringArmComponent;
class USkeletalMeshComponent;
class UMeshComponent;
class USceneComponent;
class APawn;
class APlayerController;

UCLASS(ClassGroup = (SquadAI), meta = (BlueprintSpawnableComponent))
class SQUADAI_API USquadAIFirstPersonComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	USquadAIFirstPersonComponent();

	virtual void BeginPlay() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	virtual void EndPlay(const EEndPlayReason::Type Reason) override;

	// S27-FP: switch now. Enabling resolves the camera rig first and fails (returns false,
	// stays third person) if the pawn has no camera component yet. Disabling restores every
	// saved value. The F6 hotkey and the SquadAI.FP.Enable cvar both land here.
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Camera")
	bool SetFirstPersonEnabled(bool bEnabled);

	UFUNCTION(BlueprintPure, Category = "SquadAI|Camera")
	bool IsFirstPersonEnabled() const { return bFirstPersonActive; }

private:
	// --- rig resolution + apply/restore -------------------------------------
	bool ResolveCameraRig();
	bool ApplyFirstPerson();
	void RestoreThirdPerson();

	// --- body hiding ----------------------------------------------------------
	// S27-FP: OwnerNoSee only removes the meshes from the OWNER's view. The pack's
	// originals are saved so a disable (or EndPlay) can put every one of them back
	// exactly as the pack had it — a blind SetOwnerNoSee(false) would clobber a
	// mesh the pack itself had hidden from the owner.
	void HideBodyMeshes();
	void RestoreBodyMeshes();
	void RefreshBodyMeshSweep();

	// --- viewmodel ------------------------------------------------------------
	UMeshComponent* ResolvePackWeaponMesh() const;
	void BuildViewmodel();
	void DestroyViewmodel();
	void RefreshViewmodel();
	bool ViewmodelSourceChanged() const;

	// --- per-frame enforcement -------------------------------------------------
	void EnforceCameraRig();
	void UpdateAimPose(float DeltaTime);

	float GetDesiredArmLength() const;
	FVector ComputeEyeDelta() const;

	bool bFirstPersonActive = false;
	bool bRigResolved = false;
	bool bLoggedNoCamera = false;
	bool bF6KeyDownPrev = false;

	// Saved third-person state (all of it goes back on restore).
	bool bArmStateSaved = false;
	float SavedArmLength = 0.f;
	FVector SavedSocketOffset = FVector::ZeroVector;
	FVector SavedTargetOffset = FVector::ZeroVector;
	FVector SavedArmRelativeLocation = FVector::ZeroVector;
	bool bSavedDoCollisionTest = true;
	bool bSavedCameraLag = false;
	bool bSavedCameraRotationLag = false;
	bool bSavedArmUsePawnControlRotation = true;
	float SavedBaseFov = 90.f;

	// No-boom fallback: the camera itself is re-parented, so its old parent and
	// relative transform are the state that has to be restored.
	TWeakObjectPtr<USceneComponent> SavedCameraParent;
	FVector SavedCameraRelativeLocation = FVector::ZeroVector;
	FRotator SavedCameraRelativeRotation = FRotator::ZeroRotator;
	bool bSavedCameraUsePawnControlRotation = false;
	bool bCameraReparented = false;
	bool bFovTouched = false;

	TWeakObjectPtr<USpringArmComponent> CameraArm;
	TWeakObjectPtr<UCameraComponent> CameraComp;
	TWeakObjectPtr<UMeshComponent> PackWeaponMesh;
	TWeakObjectPtr<USceneComponent> ViewmodelMesh;

	// S27-FP: live viewmodel source identity — when the pack swaps the weapon
	// (new skeletal/static mesh asset or a fresh WeaponMesh component), the clone
	// is rebuilt to match.
	UObject* ViewmodelSourceAsset = nullptr;

	TArray<TPair<TWeakObjectPtr<UMeshComponent>, bool>> SavedOwnerNoSeeStates;

	// Slow maintenance sweep (new pack meshes, dead weapon mesh) — every 2 s.
	float MeshSweepAccum = 0.f;

	// Live aim-pose interpolation state (camera FOV + viewmodel offset).
	float CurrentFov = 90.f;
	FVector CurrentWeaponOffset = FVector::ZeroVector;
	bool bAimStateInitialized = false;
};

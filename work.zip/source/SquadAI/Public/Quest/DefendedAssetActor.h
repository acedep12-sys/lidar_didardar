// DefendedAssetActor.h - S19-ASSET
//
// The defendable friendly asset: a generator / comms relay / downed bird with
// health that the mission can be built around. The one honest way enemies threaten
// it without new targeting AI is SAPPERS - a hostile standing inside the sapper
// radius is working on it, and the asset bleeds health for every hostile there
// (the rule and its rates are in Quest/AssetDefenseModel.h). The defend dynamic is
// therefore "never let them park next to it", which the player can always act on.
//
// Stated plainly, like the convoy: regular enemy fire does NOT hit the asset -
// they target the player. Only sappers damage it, and the model says how fast.
//
// Condition language (marker disc): green pristine -> amber damaged -> red
// critical (pulsing) -> black destroyed.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Quest/AssetDefenseModel.h"
#include "DefendedAssetActor.generated.h"

class UStaticMeshComponent;
class UMaterialInstanceDynamic;
class UHealthComponent;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnAssetUnderAttack, ADefendedAssetActor*, Asset);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnAssetDestroyed, ADefendedAssetActor*, Asset);

/** The asset's public condition (reflected - the model's condition enum stays plain
 *  C++ and GetCondition converts, so UHT sees exactly one spelling of each). */
UENUM(BlueprintType)
enum class EAssetCondition : uint8
{
	Pristine,
	Damaged,
	Critical,
	Destroyed
};

UCLASS(BlueprintType)
class SQUADAI_API ADefendedAssetActor : public AActor
{
	GENERATED_BODY()

public:
	ADefendedAssetActor();

	virtual void Tick(float DeltaTime) override;

	// ===== CONFIG =====

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defended Asset")
	FText AssetName;

	/** Hostiles inside this radius are sappers: each one applies damage per second. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defended Asset", meta = (ClampMin = "300.0"))
	float SapperRadiusCm = 1200.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defended Asset", meta = (ClampMin = "100.0"))
	float VerticalToleranceCm = 500.f;

	/** Health drain per second PER sapper inside the radius. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defended Asset", meta = (ClampMin = "1.0"))
	float DamagePerSapperPerSecond = 35.f;

	/** The "under attack" alert fires at most once per this many seconds. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defended Asset", meta = (ClampMin = "2.0"))
	float AttackAnnounceQuietSeconds = 12.f;

	// ===== EVENTS =====

	UPROPERTY(BlueprintAssignable, Category = "Defended Asset")
	FOnAssetUnderAttack OnUnderAttack;

	UPROPERTY(BlueprintAssignable, Category = "Defended Asset")
	FOnAssetDestroyed OnAssetDestroyed;

	// ===== STATE =====

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Defended Asset")
	bool IsAssetAlive() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Defended Asset")
	float GetAssetHealth01() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Defended Asset")
	EAssetCondition GetCondition() const;

	/** Back to pristine (a mission restart attempt calls this). */
	UFUNCTION(BlueprintCallable, Category = "Defended Asset")
	void ResetAsset();

protected:
	virtual void BeginPlay() override;

	UPROPERTY(VisibleAnywhere, Category = "Defended Asset")
	TObjectPtr<USceneComponent> SceneRoot;

	/** The asset body. */
	UPROPERTY(VisibleAnywhere, Category = "Defended Asset")
	TObjectPtr<UStaticMeshComponent> AssetMesh;

	/** The condition marker disc at its base. */
	UPROPERTY(VisibleAnywhere, Category = "Defended Asset")
	TObjectPtr<UStaticMeshComponent> MarkerDisc;

	UPROPERTY(VisibleAnywhere, Category = "Defended Asset")
	TObjectPtr<UHealthComponent> HealthComp;

private:
	EAssetHealthCondition WorstCondition = EAssetHealthCondition::Pristine;
	float SecondsSinceLastAnnouncement = 1e9f;
	bool bDestroyed = false;
	bool bDeathBound = false;

	UPROPERTY(Transient)
	TObjectPtr<UMaterialInstanceDynamic> DiscMID;

	UPROPERTY(Transient)
	TObjectPtr<UMaterialInstanceDynamic> MeshMID;

	void SetConditionColor(EAssetHealthCondition Condition);

	int32 CountSappers() const;

	UFUNCTION()
	void HandleHealthDied(AActor* OwnerActor);
};

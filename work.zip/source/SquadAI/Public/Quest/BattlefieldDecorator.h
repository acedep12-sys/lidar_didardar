// BattlefieldDecorator.h — Auto-spawns battlefield effects (fire, smoke, debris)
// Place in your map, link to a MissionZone. Effects auto-activate when mission starts.
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "BattlefieldDecorator.generated.h"

class AMissionZone;
class UNiagaraSystem;
class UParticleSystem;

UENUM(BlueprintType)
enum class EBattlefieldEffect : uint8
{
	Fire,
	Smoke,
	Explosion,
	Dust,
	Custom
};

USTRUCT(BlueprintType)
struct FBattlefieldEffectEntry
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite) EBattlefieldEffect EffectType = EBattlefieldEffect::Fire;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) UNiagaraSystem* NiagaraEffect = nullptr;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) UParticleSystem* CascadeEffect = nullptr;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) float SpawnRadius = 500.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) int32 SpawnCount = 3;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) FVector Scale = FVector(1.f);
};

UCLASS(BlueprintType, Blueprintable)
class SQUADAI_API ABattlefieldDecorator : public AActor
{
	GENERATED_BODY()
public:
	ABattlefieldDecorator();

	// Link to a mission zone — effects activate when mission starts
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Battlefield")
	TObjectPtr<AMissionZone> LinkedMission;

	// Effects to spawn
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Battlefield|Effects")
	TArray<FBattlefieldEffectEntry> Effects;

	// Auto-activate on BeginPlay (no mission link needed)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Battlefield")
	bool bAutoActivate = false;

	// Loop effects (re-spawn after duration)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Battlefield")
	bool bLoopEffects = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Battlefield")
	float LoopInterval = 10.f;

	UFUNCTION(BlueprintCallable, Category = "Battlefield")
	void ActivateEffects();

	UFUNCTION(BlueprintCallable, Category = "Battlefield")
	void DeactivateEffects();

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

private:
	// S5-8: SpawnEffect spawns COMPONENTS (Niagara/Cascade), not actors — the old
	// TArray<AActor> could never hold them, so nothing was ever cleaned up.
	UPROPERTY() TArray<TObjectPtr<USceneComponent>> SpawnedEffects;
	FTimerHandle LoopTimerHandle;
	bool bActive = false;

	void SpawnEffect(const FBattlefieldEffectEntry& Entry);
	FVector GetRandomSpawnLocation(float Radius) const;

	UFUNCTION()
	void HandleMissionStateChanged(AMissionZone* Mission, EMissionZoneState NewState);
};

// EscortModel.h - S19-ESCORT
//
// The rule behind "get the convoy there": a route walked in order, a mercy
// leash that stops the convoy for a player who fell behind, and a progress
// number for the HUD and the mission card.
//
// Why it lives in a model header
// ------------------------------
// Nothing in the module could escort anything. The only friendly AI that moved
// on its own was a freed POW following the player, and the only thing that
// walked a route was the enemy patroller. "Walk these points, wait for the
// player, arrive" is small enough to state once, and every edge case below is
// one a designer will hit in the first ten minutes of using the actor:
//
//   * a route with 0 or 1 point must be a no-op / already-arrived, never a
//     negative index or an infinite wait,
//   * the leash needs HYSTERESIS: halt at 25 m and resume at 18 m, or a player
//     standing exactly at the boundary makes the convoy stutter,
//   * "arrived at this point" is a distance test, and the same test decides
//     the route is finished - the last point is not special,
//   * progress is measured in POINTS REACHED, so it only ever moves forward
//     when a waypoint is cleared (a distance-based number can go backwards
//     when the convoy is knocked off course),
//   * the route itself is an AEnemyPatrolRoute: the same actor the patrolling
//     enemies use, with the same draggable point handles, so this feature adds
//     no new authoring surface at all.
//
// Engine-free on purpose (no UENUM, no .generated.h): compiled and exercised
// by tools/mission_test, the same way PatrolRouteModel.h is by tools/patrol_test.

#pragma once

#include "CoreMinimal.h"

struct FEscortModel
{
	/**
	 * Should the convoy hold still because the player is behind?
	 * Hysteresis: the halt test uses HaltRadius, the resume test ResumeRadius,
	 * and ResumeRadius <= 0 or >= HaltRadius falls back to 75% of HaltRadius
	 * (so a caller that only sets one radius still gets a stable, non-flapping
	 * rule rather than a convoy that stutters at the boundary).
	 */
	static bool ShouldHoldForPlayer(bool bWaitForPlayer, bool bAlreadyHolding,
		float PlayerDistanceCm, float HaltRadiusCm, float ResumeRadiusCm)
	{
		if (!bWaitForPlayer)
		{
			return false;
		}
		const float Halt = FMath::Max(0.f, HaltRadiusCm);
		if (Halt <= 0.f)
		{
			return false; // no leash configured
		}
		float Resume = ResumeRadiusCm;
		if (!(Resume > 0.f) || Resume >= Halt)
		{
			Resume = Halt * 0.75f;
		}
		return bAlreadyHolding ? (PlayerDistanceCm > Resume) : (PlayerDistanceCm > Halt);
	}

	/** At (or inside) the point's arrive radius. */
	static bool HasArrivedAt(const FVector& ConvoyLocation, const FVector& Point,
		float ArriveRadiusCm)
	{
		const float Radius = FMath::Max(1.f, ArriveRadiusCm);
		return FVector::DistSquared(ConvoyLocation, Point) <= Radius * Radius;
	}

	/**
	 * The next index to walk toward, given the one just cleared.
	 * Looping wraps to 0; otherwise NumPoints means ROUTE FINISHED (callers test
	 * `Index >= NumPoints`), which keeps the finished state expressible without a
	 * second flag.
	 */
	static int32 AdvanceIndex(int32 ClearedIndex, int32 NumPoints, bool bLoop)
	{
		if (NumPoints <= 0)
		{
			return 0;
		}
		const int32 Next = ClearedIndex + 1;
		if (Next < NumPoints)
		{
			return Next;
		}
		return bLoop ? 0 : NumPoints;
	}

	/** Fraction of the route cleared, by waypoint count. Clamped to [0, 1]. */
	static float Progress01(int32 ClearedIndex, int32 NumPoints)
	{
		if (NumPoints <= 0)
		{
			return 1.f; // a route with nowhere to go is trivially complete
		}
		return FMath::Clamp(static_cast<float>(ClearedIndex) / static_cast<float>(NumPoints), 0.f, 1.f);
	}

	/**
	 * Pause at a point: a point's own value wins, -1 means "use the route's
	 * default" - the same convention the patrol route already documents, so the
	 * two features read identically in the Details panel.
	 */
	static float ResolveWaitSeconds(float PointWaitSeconds, float RouteDefaultWaitSeconds)
	{
		const float Chosen = (PointWaitSeconds < 0.f) ? RouteDefaultWaitSeconds : PointWaitSeconds;
		return FMath::Max(0.f, Chosen);
	}

	/** Total walked length of a route, for the log line ("convoy: 240 m, 6 points"). */
	static float RouteLengthCm(const TArray<FVector>& Points)
	{
		float Total = 0.f;
		for (int32 i = 1; i < Points.Num(); ++i)
		{
			Total += FVector::Dist(Points[i - 1], Points[i]);
		}
		return Total;
	}

	/** How many points the escort still has to clear. */
	static int32 PointsRemaining(int32 ClearedIndex, int32 NumPoints)
	{
		return FMath::Max(0, NumPoints - FMath::Max(0, ClearedIndex));
	}
};

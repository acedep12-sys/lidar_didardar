// GeneratorModel.h - S19-GEN
//
// The seeded mission generator: one integer in, one complete mission brief out, the
// same integer always producing the same brief. This is what turns the factory into a
// skirmish machine - "give me a tier-3 village raid, seed 1337" is reproducible and
// shareable (tell a friend the seed and you both get the same fight).
//
// The RNG is SplitMix32 - four multiplies, no state, no platform dependence - so the
// sequence is identical on every machine and every run, unlike rand() or FRandomStream
// re-seeding quirks. Everything downstream (type roll, counts, modifiers) reads that
// one stream in a fixed order; adding a new roll APPENDS to the sequence so existing
// seeds keep producing the same missions they always did.
//
// CONSTRAINTS the generator guarantees (the factory's validator would refuse anything
// less): an escort route always has >= 2 legs, waves >= 1, par < the hard limit (the
// par is meant to be BEATABLE inside the clock), Defend never asks for a convoy.
//
// Engine-free: no UENUM, no generated include, no RNG dependency - compiled and swept
// across hundreds of seeds by tools/mission_test.

#pragma once

#include "CoreMinimal.h"

/** The generated brief - plain facts the applier writes into a UMissionTemplateAsset. */
struct FMissionTemplateFacts
{
	uint8 TypeReachClearDefend = 2;   // 1 = Reach, 2 = Clear, 3 = Defend (EMissionType order)
	int32 TotalWaves = 2;
	int32 EnemiesPerWave = 4;
	bool bCommander = false;

	bool bEscort = false;
	int32 EscortRouteLegs = 4;
	float EscortRouteLegLengthCm = 5000.f;

	int32 IntelSiteCount = 0;
	int32 SupplyCrateCount = 0;
	int32 SabotageTargetCount = 0;
	int32 POWCaptiveCount = 0;

	bool bExtraction = false;
	// S26-EXFILFIX: default OFF - a seed without an extraction pad must not refuse to build
	// (the generator model feeds the same 'require extraction' gate the factory validates).
	bool bRequireExtraction = false;

	float TimeLimitSeconds = 0.f;
	float ParTimeSeconds = 0.f;

	float PropRingRadiusCm = 1800.f;
	bool bFortify = false;
	int32 ExplosiveBarrels = 0;

	// S19-CAP / S19-ASSET / S19-INTERDICT (the appended batch-4 rolls)
	int32 CapturePointCount = 0;
	float CaptureHoldSeconds = 10.f;
	bool bDefendedAsset = false;
	bool bInterdiction = false;
	int32 InterdictionCourierCount = 0;
	int32 InterdictionStopQuota = 0;
};

struct FMissionGeneratorModel
{
	// -----------------------------------------------------------------------------------------
	//  the stream
	// -----------------------------------------------------------------------------------------

	/** SplitMix32 advance: `State` is mutated in place; the first call with any seed
	 *  (including 0) already yields a well-mixed value. */
	static uint32 NextUInt32(uint32& State)
	{
		State += 0x9E3779B9u;
		uint32 Z = State;
		Z = (Z ^ (Z >> 16)) * 0x21F0AAADu;
		Z = (Z ^ (Z >> 15)) * 0x735A2D97u;
		return Z ^ (Z >> 15);
	}

	/** [0, 1) in 1/2^24 steps - plenty for picking missions, never rounds to 1. */
	static float UnitFloat(uint32& State)
	{
		return static_cast<float>(NextUInt32(State) >> 8) * (1.0f / 16777216.0f);
	}

	/** Inclusive integer range; a swapped or empty range falls back to Lo. */
	static int32 RangeInclusive(uint32& State, int32 Lo, int32 Hi)
	{
		if (Hi <= Lo)
		{
			return Lo;
		}
		const uint32 Span = static_cast<uint32>(Hi - Lo + 1);
		return Lo + static_cast<int32>(NextUInt32(State) % Span);
	}

	static bool Chance(uint32& State, float Probability)
	{
		return UnitFloat(State) < Probability;
	}

	// -----------------------------------------------------------------------------------------
	//  the brief
	// -----------------------------------------------------------------------------------------

	/**
	 * Difficulty tier 1..5 (clamped). Everything is drawn from the one stream in a
	 * FIXED order: type -> waves -> per-wave -> commander -> escort -> intel ->
	 * supplies -> sabotage -> POWs -> extraction -> clock -> barrels -> fortify.
	 * Append new rolls at the END only.
	 */
	static FMissionTemplateFacts BuildTemplateFacts(uint32 Seed, int32 DifficultyTier)
	{
		const int32 Tier = FMath::Clamp(DifficultyTier, 1, 5);
		uint32 State = Seed ^ 0xA5A5F00Du;   // a seed of 0 still starts mixed

		FMissionTemplateFacts F;
		FMemory::Memzero(&F, sizeof(F));   // padding included: a generated brief is byte-stable,
		                                   // so seeds can be shared (and memcmp'd) safely

		// -- the base type --------------------------------------------------------
		const float TypeRoll = UnitFloat(State);
		if (TypeRoll < 0.20f)
		{
			F.TypeReachClearDefend = 1;      // Reach
		}
		else if (TypeRoll < 0.72f)
		{
			F.TypeReachClearDefend = 2;      // Clear (the workhorse)
		}
		else
		{
			F.TypeReachClearDefend = 3;      // Defend
		}
		const bool bDefend = (F.TypeReachClearDefend == 3);
		const bool bClear = (F.TypeReachClearDefend == 2);

		// -- the fight -------------------------------------------------------------
		F.TotalWaves = 2 + (Tier / 2) + (bDefend ? 1 : 0);            // 2..4, one more to hold
		F.EnemiesPerWave = 3 + Tier + (Chance(State, 0.35f) ? 1 : 0); // 4..9
		F.bCommander = (Tier >= 4) || (Tier == 3 && Chance(State, 0.30f));

		// -- the convoy (Clear only, and only when the mission is not a siege) ------
		F.bEscort = bClear && Chance(State, 0.30f);
		if (F.bEscort)
		{
			F.EscortRouteLegs = RangeInclusive(State, 3, 6);          // validator floor is 2
			F.EscortRouteLegLengthCm = 4000.f + 500.f * RangeInclusive(State, 0, 4);
		}

		// -- objectives --------------------------------------------------------------
		F.IntelSiteCount = (Tier >= 2) ? RangeInclusive(State, 0, 1 + (Tier / 3)) : 0;
		F.SupplyCrateCount = Chance(State, 0.40f) ? RangeInclusive(State, 1, 2) : 0;
		F.SabotageTargetCount = (bClear || bDefend) ? RangeInclusive(State, 0, (Tier >= 3) ? 2 : 1) : 0;
		F.POWCaptiveCount = (Chance(State, 0.25f)) ? RangeInclusive(State, 1, 2) : 0;

		// -- the exfil ----------------------------------------------------------------
		F.bExtraction = !bDefend ? Chance(State, 0.55f) : Chance(State, 0.20f);
		F.bRequireExtraction = F.bExtraction;

		// -- the clock (never on Defend: its own timer is the clock) -------------------
		if (!bDefend && Chance(State, 0.45f))
		{
			F.TimeLimitSeconds = 180.f + 60.f * static_cast<float>(Tier)
				+ 30.f * static_cast<float>(RangeInclusive(State, 0, 2));
			F.ParTimeSeconds = F.TimeLimitSeconds * 0.8f;             // beatable INSIDE the limit
		}

		// -- scenery -------------------------------------------------------------------
		F.ExplosiveBarrels = RangeInclusive(State, 0, 2);
		F.bFortify = Chance(State, 0.35f) || bDefend;
		F.PropRingRadiusCm = 1400.f + 200.f * static_cast<float>(RangeInclusive(State, 0, 4));

		// -- the appended batch-4 rolls (NEVER insert before this line: the draw order
		//    above is frozen - existing seeds keep producing the same first facts) ------
		F.CapturePointCount = (!bDefend && Chance(State, 0.35f)) ? RangeInclusive(State, 1, 2) : 0;
		F.CaptureHoldSeconds = 10.f;
		F.bDefendedAsset = Chance(State, 0.30f);
		F.bInterdiction = bClear && Chance(State, 0.25f);
		if (F.bInterdiction)
		{
			F.InterdictionCourierCount = RangeInclusive(State, 3, 5);
			F.InterdictionStopQuota = FMath::Max(1, F.InterdictionCourierCount / 2);   // always <= count
		}

		return F;
	}

	/** A human name for the generated mission's report line. */
	static const TCHAR* TypeName(uint8 ReachClearDefend)
	{
		switch (ReachClearDefend)
		{
		case 1:  return TEXT("reach");
		case 3:  return TEXT("defend");
		default: return TEXT("clear");
		}
	}
};

// MissionOperationDirector.h - S19-OP
//
// The campaign-night actor: place ONE of these, give it an ordered list of mission
// templates, and it stages the whole night - it stamps step 1 with the mission
// factory, waits for the zone to complete, then stamps step 2, and so on, ending
// with one debrief for the operation (worst step grade, total score).
//
// Why it does not use AQuestChain: the chain binds missions that ALREADY exist in the
// level. An operation's steps mostly don't exist yet - that is the point - and the
// factory would otherwise append each stamped zone to the level's first chain,
// giving TWO owners to every step. The director therefore stamps with
// bAppendToQuestChain = false and owns its zones' lifecycles outright:
//   * a step that COMPLETES stays in the level (its score is banked; the zone is inert);
//   * a step that FAILS and retries has its zone destroyed and the template re-stamped
//     at a 15 m offset along +X - the fresh attempt's score REPLACES the botched one,
//     and the offset keeps the new props from landing on the old ones.
//
// Retry policy and the debrief arithmetic are the model's (OperationModel.h); this
// actor only executes what the model says.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Quest/OperationModel.h"
#include "Quest/MissionZone.h"        // EMissionZoneState rides the UFUNCTION handler
#include "MissionOperationDirector.generated.h"

class AMissionZone;
class UMissionTemplateAsset;

UCLASS(BlueprintType)
class SQUADAI_API AMissionOperationDirector : public AActor
{
	GENERATED_BODY()

public:
	AMissionOperationDirector();

	// =========================================================================
	//  CONFIG
	// =========================================================================

	/** The steps, in order. Each is stamped only when the previous step completes. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Operation")
	TArray<TObjectPtr<UMissionTemplateAsset>> Steps;

	/** Optional: the world location of each step. A missing entry falls back to the
	 *  deterministic ring around this actor (40 m steps). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Operation")
	TArray<FVector> StepLocations;

	/** Seconds between a step completing and the next stamp (the walk to the next
	 *  objective is the breather). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Operation", meta = (ClampMin = "0.0"))
	float NextStepDelaySeconds = 8.f;

	/** Failed steps re-stamp the same template while retry budget remains. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Operation")
	bool bRetryFailedSteps = true;

	/** Retries per step before the operation fails there. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Operation", meta = (EditCondition = "bRetryFailedSteps", ClampMin = "0"))
	int32 MaxStepRetries = 1;

	// =========================================================================
	//  STATE (read-only)
	// =========================================================================

	/** -1 = not started; otherwise the step currently live or queued for retry. */
	UPROPERTY(BlueprintReadOnly, Category = "Operation|State")
	int32 CurrentStepIndex = -1;

	UPROPERTY(BlueprintReadOnly, Category = "Operation|State")
	bool bOperationActive = false;

	UPROPERTY(BlueprintReadOnly, Category = "Operation|State")
	bool bOperationFailed = false;

	/** Completed steps over total steps, 0..1. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Operation|State")
	float GetOperationProgress() const;

	/** The debrief, filled at the end (and printed to the log). */
	UPROPERTY(BlueprintReadOnly, Category = "Operation|State")
	FString OperationReport;

	// =========================================================================
	//  API
	// =========================================================================

	/** Stamp step 1 and go. One run at a time; a call during a run is ignored. */
	UFUNCTION(BlueprintCallable, Category = "Operation")
	void StartOperation();

	/** Stop everything: clear the pending timer and release the live zone's binding. */
	UFUNCTION(BlueprintCallable, Category = "Operation")
	void AbortOperation();

protected:
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

private:
	/** The live zone reports in here. UFUNCTION because the zone's state delegate is
	 *  a dynamic multicast - UHT's binding rules are the rules. */
	UFUNCTION()
	void HandleZoneStateChanged(AMissionZone* Zone, EMissionZoneState NewState);

	void StampStep(int32 StepIndex);
	void FinishStep(int32 StepIndex, bool bSucceeded);
	FVector LocationForStep(int32 StepIndex, bool bRetry) const;
	void UnbindLiveZone();

	// The cap on steps; templates beyond it are refused with a log line, never
	// silently half-run. Declared BEFORE the arrays - array bounds are not part of
	// the class's complete-class context.
	static constexpr int32 MaxSteps = 16;

	// Parallel to Steps.
	EOperationStepState StepStates[MaxSteps];
	int32 RetriesUsed[MaxSteps];
	int32 StepScores[MaxSteps];
	int32 StepPars[MaxSteps];

	int32 CompletedSteps = 0;
	int32 FailedSteps = 0;
	int32 TotalScore = 0;

	/** The zone this director stamped for the live step. */
	TWeakObjectPtr<AMissionZone> LiveZone;

	FTimerHandle NextStepTimerHandle;

	void ResetRun();
};

// MissionZone.h — A single mission point in the world
// Supports: Reach, Clear, Defend mission types
// Place in your map, configure type + spawners + description
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Quest/ScoreModel.h"        // S19-SCORE: the debrief's arithmetic
#include "MissionZone.generated.h"

class AEnemyWaveSpawner;
class AWaveSpawner;
class UBoxComponent;
class UStaticMeshComponent;
class AQuestChain;
class AEscortTargetActor;   // S19-ESCORT
class AIntelSiteActor;      // S19-INTEL
class AExtractionZoneActor;
class ACapturePointActor;        // S19-CAP
class ADefendedAssetActor;       // S19-ASSET
class AInterdictionDirectorActor; // S19-INTERDICT // S19-EXFIL

// ===== MISSION TYPE =====
UENUM(BlueprintType)
enum class EMissionType : uint8
{
	Reach     UMETA(DisplayName = "Reach"),
	Clear     UMETA(DisplayName = "Clear"),
	Defend    UMETA(DisplayName = "Defend")
};

// ===== MISSION STATE =====
UENUM(BlueprintType)
enum class EMissionZoneState : uint8
{
	Locked,
	Active,
	Completed,
	Failed
};

// ===== DELEGATES =====
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnMissionZoneStateChanged, AMissionZone*, Mission, EMissionZoneState, NewState);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnMissionZoneProgressUpdated, AMissionZone*, Mission, float, Progress);
// S17: gameplay alert keys: OverrunWarning / OverrunCleared / CounterattackIncoming / CounterattackSpawningEnded
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnMissionZoneAlert, AMissionZone*, Mission, FString, AlertKey);

UCLASS(BlueprintType, Blueprintable)
class SQUADAI_API AMissionZone : public AActor
{
	GENERATED_BODY()

public:
	AMissionZone();

	// ===== CONFIGURATION =====

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Config")
	EMissionType MissionType = EMissionType::Reach;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Config")
	FText MissionDescription;

	// Custom badge text (e.g. Persian name like "رسیدن" instead of "REACH")
	// Leave empty to use default English badge
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Config")
	FText CustomBadgeText;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Config", meta = (EditCondition = "MissionType == EMissionType::Defend", ClampMin = "1"))
	float DefendDuration = 60.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Config", meta = (EditCondition = "MissionType == EMissionType::Defend", ClampMin = "0.5"))
	float DefendWaveInterval = 15.0f;

	// ===== S17-HOLD: Hold-the-Line pressure (Defend missions) =====
	/** Fail the Defend mission when the line is OVERRUN: at least OverrunEnemyCount
	 *  living hostiles inside OverrunRadius of the zone for OverrunGraceTime
	 *  continuous seconds. Push them back out to reset the pressure. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|HoldTheLine", meta = (EditCondition = "MissionType == EMissionType::Defend"))
	bool bFailIfOverrun = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|HoldTheLine", meta = (EditCondition = "bFailIfOverrun", ClampMin = "200.0"))
	float OverrunRadius = 1400.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|HoldTheLine", meta = (EditCondition = "bFailIfOverrun", ClampMin = "1"))
	int32 OverrunEnemyCount = 3;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|HoldTheLine", meta = (EditCondition = "bFailIfOverrun", ClampMin = "2.0"))
	float OverrunGraceTime = 12.f;

	// ===== S17-CNTR: Counterattack after completion =====
	/** After this zone completes, the enemy counterattacks it ONCE after a delay:
	 *  linked spawners re-fire for CounterattackDuration seconds. Automatically
	 *  skipped when the whole campaign is complete (S14-END rule). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Counterattack")
	bool bCounterattackAfterComplete = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Counterattack", meta = (EditCondition = "bCounterattackAfterComplete", ClampMin = "3.0"))
	float CounterattackDelay = 25.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Counterattack", meta = (EditCondition = "bCounterattackAfterComplete", ClampMin = "5.0"))
	float CounterattackDuration = 45.f;

	// ===== S17-HVT: High-Value-Target hunt (Clear missions) =====
	/** Promote one spawned enemy to a named OFFICER with boosted health.
	 *  The mission cannot complete while he lives; killing him completes it
	 *  instantly (bCompleteOnHVTKill) or leaves the mop-up (off). Optional
	 *  escape timer fails the mission if he survives too long. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|HVT", meta = (EditCondition = "MissionType == EMissionType::Clear"))
	bool bHVTHunt = false;

	/** Officer display name for logs/HUD (e.g. Persian/Arabic officer name). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|HVT", meta = (EditCondition = "bHVTHunt"))
	FText HVTName;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|HVT", meta = (EditCondition = "bHVTHunt", ClampMin = "1.0"))
	float HVTHealthMultiplier = 3.f;

	/** Seconds after designation before the officer ESCAPES (mission fails). 0 = never. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|HVT", meta = (EditCondition = "bHVTHunt", ClampMin = "0.0"))
	float HVTEscapeTime = 0.f;

	/** Killing the officer completes the zone immediately (survivors become optional mop-up). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|HVT", meta = (EditCondition = "bHVTHunt"))
	bool bCompleteOnHVTKill = true;

	/** Also toughen bodyguards near the officer at designation time. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|HVT", meta = (EditCondition = "bHVTHunt"))
	bool bBuffBodyguards = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|HVT", meta = (EditCondition = "bBuffBodyguards", ClampMin = "300.0"))
	float HVTBodyguardRadius = 1800.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|HVT", meta = (EditCondition = "bBuffBodyguards", ClampMin = "1.0"))
	float BodyguardHealthMultiplier = 1.5f;

	// ===== S17-SAB: Sabotage objectives (any mission type) =====
	/** Demolition targets that must ALL be detonated before this zone can
	 *  complete. Works with every type: Reach = get in and blow the dump;
	 *  Clear = destroy it while fighting; Defend = destroy before the timer.
	 *  Place SabotageTargetActor markers on props (stack ExplosiveBarrelActors
	 *  around them for a chain-reaction fireball) and link them here. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Sabotage")
	TArray<TObjectPtr<class ASabotageTargetActor>> SabotageTargets;

	// ===== S17-SPOT: enemy Artillery Spotter (Clear/Defend missions) =====
	/** One living hostile becomes a forward observer who calls REAL mortar
	 *  barrages onto the player's position until he is killed. The barrage
	 *  actor already whistles and paints a HUD danger ring, so the player
	 *  gets a fair warning and must keep moving. Kill the spotter to stop
	 *  the shelling (does not block zone completion). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Artillery Spotter")
	bool bArtillerySpotter = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Artillery Spotter", meta = (EditCondition = "bArtillerySpotter", ClampMin = "1.0"))
	float SpotterHealthMultiplier = 2.f;

	/** Seconds between barrages while the spotter lives. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Artillery Spotter", meta = (EditCondition = "bArtillerySpotter", ClampMin = "6.0"))
	float SpotterShellingInterval = 20.f;

	/** Grace period after designation before the first barrage. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Artillery Spotter", meta = (EditCondition = "bArtillerySpotter", ClampMin = "0.0"))
	float SpotterFirstBarrageDelay = 8.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Artillery Spotter", meta = (EditCondition = "bArtillerySpotter", ClampMin = "1", ClampMax = "12"))
	int32 SpotterShellCount = 4;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Artillery Spotter", meta = (EditCondition = "bArtillerySpotter", ClampMin = "50.0"))
	float SpotterShellDamage = 150.f;

	/** Random offset from the player's exact position per barrage (cm) — dodgeable. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Artillery Spotter", meta = (EditCondition = "bArtillerySpotter", ClampMin = "0.0"))
	float SpotterTargetScatter = 700.f;

	// ===== S17-SUPP: Supply Run (any mission type) =====
	/** Crates that must ALL be carried to the delivery point before this zone
	 *  can complete. Place SupplyCrateActor pickups out in the field (walk on
	 *  to shoulder, one at a time) and link them here. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Supply Run")
	TArray<TObjectPtr<class ASupplyCrateActor>> SupplyCrates;

	/** Where the crates must be delivered. None = this zone's own location. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Supply Run")
	TObjectPtr<AActor> SupplyDeliveryPoint;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Supply Run", meta = (ClampMin = "200.0"))
	float SupplyDeliveryRadius = 800.f;

	// ===== S17-POW: POW Rescue (any mission type) =====
	/** Captive friendly soldiers to rescue. Place AllySoldier characters in the
	 *  enemy camp and link them here: they stand frozen (AI stopped) until the
	 *  player stands beside one for POWFreeTime seconds to cut him loose. Freed
	 *  men rejoin the fight (AllySoldiers follow the player). The zone cannot
	 *  complete while a living captive is still tied up. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|POW Rescue")
	TArray<TObjectPtr<class ASoldierCharacter>> POWCaptives;

	/** Stand within this range of a captive to free him (cm). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|POW Rescue", meta = (ClampMin = "100.0"))
	float POWFreeRadius = 250.f;

	/** Seconds beside the captive to cut him loose (leaving decays progress). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|POW Rescue", meta = (ClampMin = "0.5"))
	float POWFreeTime = 2.5f;

	/** Freed AllySoldiers get the player as leader and follow him. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|POW Rescue")
	bool bPOWsFollowPlayer = true;

	/** Captives cannot be hurt until freed (prevents crossfire wipes). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|POW Rescue")
	bool bPOWsInvulnerableWhileCaptive = true;

	/** A captive (not yet freed) dying fails the mission. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|POW Rescue")
	bool bFailOnPOWDeath = true;

	// ===== S18-TITLE: per-mission opening stamp =====
	/** Place line of the COD-style opening stamp, e.g. "دهلاویه — خوزستان".
	 *  Leave empty to use the HUD's default. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Title Card")
	FText TitleCardPlace;

	/** Date / operation line, e.g. "فروردین ۱۳۶۱ — عملیات فتح‌المبین". */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Title Card")
	FText TitleCardDate;

	/** Unit line, e.g. "گردان تکاور — خط مقدم". */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Title Card")
	FText TitleCardUnit;

	// ===== S17-STORY: mission briefing card =====
	/** Optional story briefing shown as a HUD reader card when this zone
	 *  activates (queued until the deployment screen closes). Designer-entered
	 *  and localized — write it in the game language (Farsi OK). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Story")
	FText MissionBriefingTitle;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Story", meta = (MultiLine = "true"))
	FText MissionBriefingText;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Story", meta = (ClampMin = "4.0"))
	float MissionBriefingDuration = 12.f;

	// ===== S19-ESCORT: convoy / escort =====
	/** A convoy that must reach the end of its route before this zone can complete.
	 *  Place an Escort / Convoy Target actor, point it at a patrol route, link it
	 *  here. Works with every mission type. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Escort")
	TObjectPtr<AEscortTargetActor> EscortTarget;

	/** Completion is held until the convoy arrives. Off = the convoy is decoration
	 *  (it still walks, still dies, still logs) and nothing gates on it. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Escort",
		meta = (EditCondition = "EscortTarget != nullptr"))
	bool bRequireEscortArrival = true;

	/** The convoy being destroyed fails the mission. Off = it simply stops walking. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Escort",
		meta = (EditCondition = "EscortTarget != nullptr"))
	bool bFailIfEscortDies = true;

	// ===== S19-INTEL: scan sites =====
	/** Intel / recon sites that must ALL report before this zone can complete.
	 *  The player scans each (proximity hold), then the set transmits on its own. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Intel")
	TArray<TObjectPtr<AIntelSiteActor>> IntelSites;

	// ===== S19-EXFIL: extraction =====
	/** An LZ to extract from. Armed automatically when this zone's primary objective
	 *  completes (and callable early by the player with a smoke grenade on the pad). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Extraction")
	TObjectPtr<AExtractionZoneActor> ExtractionZone;

	/** Completion is held until the extraction pad is held and ready. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Extraction",
		meta = (EditCondition = "ExtractionZone != nullptr"))
	bool bRequireExtraction = false;

	// ===== S19-CLOCK: time limit and par time =====
	/** Hard time limit in seconds for this zone (0 = no clock). On expiry the zone
	 *  either fails (bFailOnTimeExpiry) or simply reports that the clock ran out. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Clock", meta = (ClampMin = "0.0"))
	float TimeLimitSeconds = 0.f;

	/** Fail the mission when the limit expires. Off = the mission may still be won
	 *  after the clock, but the expiry is announced and par is recorded as missed. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Clock",
		meta = (EditCondition = "TimeLimitSeconds > 0.0"))
	bool bFailOnTimeExpiry = true;

	/** Warning fires once, when this fraction of the limit remains (0.25 = last quarter). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Clock",
		meta = (EditCondition = "TimeLimitSeconds > 0.0", ClampMin = "0.01", ClampMax = "1.0"))
	float TimeLimitWarnFraction = 0.25f;

	/** Target time for this zone (0 = none). NOT enforced - compared at completion and
	 *  reported as beaten or missed, so a fast clear is recognisable. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Clock", meta = (ClampMin = "0.0"))
	float ParTimeSeconds = 0.f;

	// S19-SCORE/ALARM: stealth play. The alarm channel is world-wide (see
	// USquadAIAlarmSubsystem); these decide what it means for THIS mission.
	/** A full alarm fails the mission the moment it is raised. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Stealth")
	bool bFailOnFullAlarm = false;

	/** Finishing without ever reaching Searching pays the ghost bonus (+300). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Stealth",
		meta = (EditCondition = "!bFailOnFullAlarm"))
	bool bStealthBonus = true;

	// S19-CAP: capture-and-hold points (link the actors; every one must be HELD).
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Capture")
	TArray<TObjectPtr<ACapturePointActor>> CapturePoints;

	// S19-ASSET: the friendly asset to protect. Its destruction (not its damage)
	// is what matters, and only when this fail flag is on.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Asset")
	TObjectPtr<ADefendedAssetActor> DefendedAsset;

	/** A destroyed asset fails the mission. Off = the asset is only worth points. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Asset")
	bool bFailIfAssetDestroyed = true;

	// S19-INTERDICT: the courier run. The director's own quota/escape events decide
	// the gate; the zone only listens.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Interdiction")
	TObjectPtr<AInterdictionDirectorActor> InterdictionDirector;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Spawners")
	TArray<TObjectPtr<AEnemyWaveSpawner>> LinkedSpawners;

	// S5-6: template-driven spawners driven alongside LinkedSpawners (activate/
	// deactivate/reset/clear-check) — unifies the two spawner stacks at the driver.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Spawners")
	TArray<TObjectPtr<AWaveSpawner>> LinkedTemplateSpawners;

	// S5-1: fail the mission when the player dies (runs the chain failure branch:
	// retry or restart-chain + game-over UI). Off = legacy silent attempt restart.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Config")
	bool bFailMissionOnPlayerDeath = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Chain")
	TObjectPtr<AQuestChain> OwningChain;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Chain", meta = (ClampMin = "0"))
	int32 MissionIndex = 0;

	// ===== AUDIO OVERRIDES (Optional — if left empty, uses global settings from SquadAITuning) =====

	/** Optional custom ambient music override for this mission */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Audio")
	TObjectPtr<class USoundBase> CustomAmbientMusic;

	/** Optional custom combat music override for this mission (Music X) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Audio")
	TObjectPtr<class USoundBase> CustomCombatMusic;

	/** Optional custom climax music override for final moments of Defend (Music Y) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Audio")
	TObjectPtr<class USoundBase> CustomClimaxMusic;

	/** Optional custom horde war drums stem layer override for this mission */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Audio")
	TObjectPtr<class USoundBase> CustomHordeStem;

	// ===== RESPAWN =====

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Respawn")
	bool bUseTriggerAsRespawnPoint = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Respawn", meta = (EditCondition = "!bUseTriggerAsRespawnPoint"))
	FVector CustomRespawnLocation = FVector::ZeroVector;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Respawn")
	bool bResetHealthOnRespawn = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Respawn")
	bool bResetAmmoOnRespawn = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Respawn|Ammo", meta = (EditCondition = "bResetAmmoOnRespawn", ClampMin = "0"))
	int32 DefaultRespawnClipAmmo = 30;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Respawn|Ammo", meta = (EditCondition = "bResetAmmoOnRespawn", ClampMin = "0"))
	int32 DefaultRespawnReserveAmmo = 120;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Respawn|Ammo", meta = (EditCondition = "bResetAmmoOnRespawn"))
	TMap<FName, int32> PerWeaponClipAmmo;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Respawn|Ammo", meta = (EditCondition = "bResetAmmoOnRespawn"))
	TMap<FName, int32> PerWeaponReserveAmmo;

	// ===== RUNTIME STATE =====

	UPROPERTY(BlueprintReadOnly, Category = "Mission|State")
	EMissionZoneState MissionState = EMissionZoneState::Locked;

	UPROPERTY(BlueprintReadOnly, Category = "Mission|State")
	float DefendTimeRemaining = 0.f;

	UPROPERTY(BlueprintReadOnly, Category = "Mission|State")
	float MissionProgress = 0.f;

	/** S19-CLOCK: seconds this zone has been active on its current attempt. */
	UPROPERTY(BlueprintReadOnly, Category = "Mission|State")
	float ElapsedActiveSeconds = 0.f;

	/** S19-CLOCK: seconds left on the hard limit (0 when there is no clock or it ran out). */
	UPROPERTY(BlueprintReadOnly, Category = "Mission|State")
	float TimeLimitRemaining = 0.f;

	UPROPERTY(BlueprintReadOnly, Category = "Mission|State")
	int32 TotalEnemiesSpawned = 0;

	UPROPERTY(BlueprintReadOnly, Category = "Mission|State")
	int32 AliveEnemies = 0;

	/** S19-REGROUP: how many times this zone has been activated. 1 = first run; 2+ means
	 *  a failed attempt is being restarted, which is when the squad has to be pulled back
	 *  to the respawn point with the player (see RegroupSquadAtRespawn). */
	UPROPERTY(BlueprintReadOnly, Category = "Mission|State")
	int32 ActivationCount = 0;

	// S17: HUD-bindable gameplay alerts (see FOnMissionZoneAlert keys above).
	UPROPERTY(BlueprintAssignable, Category = "Mission|Events")
	FOnMissionZoneAlert OnMissionAlert;

	// ===== EVENTS =====

	UPROPERTY(BlueprintAssignable, Category = "Mission|Events")
	FOnMissionZoneStateChanged OnMissionStateChanged;

	UPROPERTY(BlueprintAssignable, Category = "Mission|Events")
	FOnMissionZoneProgressUpdated OnMissionProgressUpdated;

	// ===== API =====

	UFUNCTION(BlueprintCallable, Category = "Mission")
	void ActivateMission();

	UFUNCTION(BlueprintCallable, Category = "Mission")
	void CompleteMission();

	UFUNCTION(BlueprintCallable, Category = "Mission")
	void FailMission();

	// B6-8: silent full reset for load-restore — delegates/spawners/timers/tick cleaned
	// with NO completion side effects (no XP, music, or broadcasts). Chain unbind is the
	// caller's job (it owns the binding).
	UFUNCTION(BlueprintCallable, Category = "Mission")
	void SilentResetForLoadRestore();

	UFUNCTION(BlueprintCallable, Category = "Mission")
	void ResetMission();

	UFUNCTION(BlueprintCallable, Category = "Mission")
	void RestartCurrentAttempt();

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Mission")
	FVector GetRespawnLocation() const;

	/** S19-GROUNDRESPAWN: the respawn point dropped onto walkable ground for a specific
	 *  pawn. GetRespawnLocation() answers with the trigger volume's CENTRE (its origin),
	 *  which for a tall volume is tens of metres in the air - players respawned there,
	 *  fell, and lost most of their health to the pack's own fall damage before landing.
	 *  Falls back to the raw point if there is nothing solid below. */
	FVector GetGroundedRespawnLocation(AActor* ForActor = nullptr) const;

	/** S19-GROUNDRESPAWN: drop an arbitrary point onto the ground for this pawn
	 *  (downward trace, navmesh projection, then raw as a last resort). */
	FVector GroundLocationFor(const AActor* ForActor, const FVector& Raw) const;

	/** S19-REGROUP: put the leader and the squad in formation around a point, using the
	 *  same slots RespawnSquad() uses. Returns how many pawns were placed. */
	int32 PlaceSquadFormation(const FVector& Base, const FRotator& Rot, AActor* SkipActor);

	/** S19-REGROUP: pull the squad back to the respawn point (called when a failed mission
	 *  is restarted, so the leader is not left standing where the player died - seen live:
	 *  150 m away, halted, reading as "the leader stopped following"). */
	UFUNCTION(BlueprintCallable, Category = "Mission|Respawn")
	void RegroupSquadAtRespawn();

	// ===== S19-HUNT =====
	// "After the leader reaches the quest area he does not hunt the enemies." He had
	// nothing to tell him what was left: the mission only completes on
	// `AliveEnemies <= 0`, but no code ever handed the squad a target. These queries read
	// the zone's own spawners, so they agree with the mission's own completion test.

	/** When true (default), a leader that has ARRIVED at an active zone with enemies still
	 *  up keeps going and hunts them instead of holding position. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Combat")
	bool bHuntRemainingEnemiesOnArrival = true;

	/** Distance from the zone centre at which hunting takes over. 0 = use the default
	 *  (3000 cm). The zone has to be reached first; this only widens the arrival hold. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Combat", meta = (ClampMin = "0"))
	float HuntActivationRadius = 0.f;

	/** S19-HUNT3: how far from the objective's centre a surviving enemy may stand and
	 *  still be hunted. The live logs show the Clear-area waves settling 250-310 m from
	 *  the objective while the mission can only finish when every enemy is dead - with a
	 *  30 m "area" the leader held at the objective forever ("HUNT none inside the
	 *  objective area ... leader holds"). 0 = auto (60000 cm = 600 m, enough for the
	 *  whole spawn radius plus the walk in). Enemies inside HuntActivationRadius are
	 *  still preferred; this is the fallback that makes the squad go and clear them. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Hunt")
	float HuntPursuitRadius = 0.f;

	/** S19-DEATHPROMPT: seconds the death prompt stays on screen. 0 disables it. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Death")
	float PlayerDeathPromptSeconds = 4.0f;

	/** S19-DEATHPROMPT: seconds between the player's death and the respawn teleport, so
	 *  the prompt is actually seen. 0 = teleport immediately (old behaviour). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Death")
	float PlayerRespawnDelaySeconds = 2.0f;

	/** S19-HUNT3: resolved pursuit radius (0 on the property means auto). */
	float GetHuntPursuitRadius() const;

	/** Alive enemies across this zone's spawners. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Mission|Combat")
	int32 GetAliveEnemyCount() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Mission|Combat")
	bool HasAliveEnemies() const;

	/** Nearest still-alive enemy this zone spawned, or nullptr. MaxDistance <= 0 = no limit. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Mission|Combat")
	AActor* GetNearestAliveEnemy(const FVector& From, float MaxDistance = 0.f) const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Mission")
	bool IsComplete() const { return MissionState == EMissionZoneState::Completed; }

	// Get the badge text to display (CustomBadgeText if set, otherwise mission type name)
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Mission")
	FText GetDisplayBadgeText() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Mission")
	bool IsActive() const { return MissionState == EMissionZoneState::Active; }

	// S19-SCORE: the debrief readouts (the HUD's completed card and the operation director)
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Mission|Score")
	int32 GetMissionScore() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Mission|Score")
	int32 GetMissionParScore() const;

	/** The grade letter ("S".."D"). */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Mission|Score")
	FString GetScoreGradeString() const;

	/** S19-CAP: how many linked capture points are currently held (the card readout). */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Mission|Capture")
	int32 GetHeldCapturePointCount() const;

	/** S19-OP (deep-review fix B2): everything the mission factory spawned FOR this
	 *  zone - its spawner, prop groups, the convoy and its route, the extraction pad,
	 *  the flags, the asset, the courier route and its director. The operation
	 *  director destroys all of it BEFORE destroying the zone on a retry: without
	 *  this, an orphaned interdiction director keeps spawning couriers forever and a
	 *  fresh attempt stamps on top of the old props. Normal missions never call this. */
	UPROPERTY(BlueprintReadOnly, Category = "Mission|Factory")
	TArray<TObjectPtr<AActor>> FactorySpawnedActors;

	/** Unbinds every group, then destroys and forgets everything above. */
	UFUNCTION(BlueprintCallable, Category = "Mission|Factory")
	void DestroyFactorySpawnedActors();

protected:
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Mission")
	TObjectPtr<USceneComponent> SceneRoot;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Mission")
	TObjectPtr<UBoxComponent> TriggerVolume;

public:
	// S26-VIS: made public - the mission factory (SquadAIAutoSetupEditorLibrary)
	// sizes and tints this marker per mission type, so the campaign reads like a
	// legend on the map. Same UPROPERTY, only the access changed.
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Mission")
	TObjectPtr<UStaticMeshComponent> VisualMarker;

private:
	bool bPlayerInZone = false;
	FVector SavedPlayerLocation = FVector::ZeroVector;
	FRotator SavedPlayerRotation = FRotator::ZeroRotator;
	bool bAllSpawnersDone = false;
	bool bEventDrivenClearCheck = false;
	float LastBroadcastProgress = -1.f;

	FTimerHandle DefendWaveTimerHandle;
	FTimerHandle CounterattackStartHandle; // S17-CNTR
	FTimerHandle CounterattackStopHandle;  // S17-CNTR
	FTimerHandle HVTSelectHandle;          // S17-HVT
	FTimerHandle HVTEscapeHandle;          // S17-HVT
	FTimerHandle SpotterSelectHandle;      // S17-SPOT
	FTimerHandle SpotterShellHandle;       // S17-SPOT
	FTimerHandle PlayerDeathPollHandle;
	FTimerHandle RestartAttemptTimer;
	bool bRestartingAttempt = false;
	int32 DefendWaveCount = 0;

	// S17-HOLD runtime state
	float OverrunSeconds = 0.f;
	float OverrunCheckAccum = 0.f;
	bool bOverrunWarningActive = false;
	int32 CountLivingHostilesNear(const FVector& Center, float Radius) const;

	// S17-CNTR runtime state
	bool bCounterattackLaunched = false;
	void LaunchCounterattack();
	void StopCounterattack();
	bool AreAllMissionZonesCompleted() const;

	// S19-ESCORT runtime
	bool bEscortArrived = false;
	bool bEscortDead = false;
	bool AreEscortGatesMet() const;
	void BindEscort();
	void UnbindEscort();
	UFUNCTION()
	void OnEscortArrivedEvent(class AEscortTargetActor* Escort);
	UFUNCTION()
	void OnEscortDiedEvent(class AEscortTargetActor* Escort);

	// S19-INTEL runtime
	bool AreAllIntelSitesReported() const;
	void BindIntelSites();
	void UnbindIntelSites();
	UFUNCTION()
	void OnIntelSiteReportedEvent(class AIntelSiteActor* Site);

	// S19-EXFIL runtime
	bool bExtractionReady = false;
	bool IsExtractionGateMet() const;
	void BindExtraction();
	void UnbindExtraction();
	void ArmExtractionIfPresent();
	UFUNCTION()
	void OnExtractionReadyEvent(class AExtractionZoneActor* Zone);

	// S19-CLOCK runtime
	bool bClockWarned = false;
	bool bClockExpired = false;
	void TickMissionClock(float DeltaTime);
	void ReportParAtCompletion();

	// S19-SCORE / S19-ALARM runtime: the debrief's arithmetic and the alarm poll
	FMissionScoreState ScoreState;
	bool bScoreReported = false;
	void ComputeAndResetScore();
	void TickMissionAlarm();
	void ReportScoreAtCompletion();
	void BroadcastStoryBeat(uint8 StoryEvent);   // S24-STORY: command's voice, on the radio
	bool bSearchingBeatSaid = false;             // S24-STORY: one word per level, once per attempt
	bool bFullAlarmBeatSaid = false;

	// S19-CAP / S19-ASSET / S19-INTERDICT runtime
	bool bInterdictionQuotaMet = false;
	void BindCaptureAndAssetAndInterdiction();
	void UnbindCaptureAndAssetAndInterdiction();
	bool AreAllCapturePointsHeld() const;
	bool IsInterdictionGateMet() const;
	UFUNCTION()
	void OnCapturePointCapturedEvent(ACapturePointActor* Point);
	UFUNCTION()
	void OnCapturePointLostEvent(ACapturePointActor* Point);
	UFUNCTION()
	void OnCaptureHoldCompletedEvent(ACapturePointActor* Point);
	UFUNCTION()
	void OnAssetUnderAttackEvent(ADefendedAssetActor* Asset);
	UFUNCTION()
	void OnAssetDestroyedEvent(ADefendedAssetActor* Asset);
	UFUNCTION()
	void OnInterdictionQuotaMetEvent(AInterdictionDirectorActor* Director);
	UFUNCTION()
	void OnInterdictionEscapeLimitEvent(AInterdictionDirectorActor* Director);

	// S17-SAB runtime
	bool AreAllSabotageTargetsDetonated() const;
	void BindSabotageTargets();
	void UnbindSabotageTargets();
	UFUNCTION()
	void OnSabotageTargetDetonated(class ASabotageTargetActor* Target);

	// S17-SUPP runtime
	bool AreAllSupplyCratesDelivered() const;
	void BindSupplyCrates();
	void UnbindSupplyCrates();
	UFUNCTION()
	void OnSupplyCratePickedUpEvent(class ASupplyCrateActor* Crate);
	UFUNCTION()
	void OnSupplyCrateDeliveredEvent(class ASupplyCrateActor* Crate);

	// S17-POW runtime
	TArray<float> POWFreeProgress;
	TArray<bool> POWFreed;
	FTimerHandle POWFreezeHandle;
	bool AreAllPOWsFreed() const;
	void BindPOWCaptives();
	void FreezePOWCaptives();
	void FreePOW(int32 Index);
	void UpdatePOWRescue(float DeltaTime);
	UFUNCTION()
	void OnPOWDied(AActor* OwnerActor);

	// S17-HVT runtime state
	TWeakObjectPtr<class ASoldierCharacter> HVTTarget;
	bool bHVTDesignated = false;
	bool bHVTDead = false;
	void ArmHVTDesignation();
	void TryDesignateHVT();
	void ResetHVTState();
	void OnHVTEscapeTimeout();
	UFUNCTION()
	void OnHVTDied(AActor* OwnerActor);

	// S17-SPOT runtime state
	TWeakObjectPtr<class ASoldierCharacter> SpotterTarget;
	bool bSpotterDesignated = false;
	bool bSpotterDead = false;
	void ArmSpotterDesignation();
	void TryDesignateSpotter();
	void ResetSpotterState();
	void FireSpotterBarrage();
	UFUNCTION()
	void OnSpotterDied(AActor* OwnerActor);
	TWeakObjectPtr<UActorComponent> CachedPlayerPackHealth;

	void SetMissionState(EMissionZoneState NewState);
	void UpdateProgress();
	void OnDefendWaveTimerExpired();
	void RespawnPlayer();

	/** S19-DEATHPROMPT: the recovery body of OnPlayerDied (respawn + fail/restart), run
	 *  after the prompt delay so the player sees that he died before being moved. */
	void OnPlayerDied_Recover();

	/** S19-DEATHPROMPT: blocks OnPlayerDied re-entry while the prompt delay is running. */
	bool bDeathSequenceRunning = false;
	void RespawnSquad();
	void RevivePawnAt(APawn* Pawn, const FVector& Loc, const FRotator& Rot, bool bIsPlayer);
	void RestorePackHealth(AActor* Actor);
	void FinishRestartAttempt();
	void ResetPlayerAmmo(APawn* Player);

	// Player death
	void BindPlayerDeathDelegate();
	void UnbindPlayerDeathDelegate();
	UFUNCTION()
	void OnPlayerDied(AActor* OwnerActor);

	// Event-driven spawner integration
	void BindSpawnerEvents();
	void UnbindSpawnerEvents();
	UFUNCTION()
	void OnSpawnerEnemyDiedEvent(AActor* DeadEnemy);
	UFUNCTION()
	void OnSpawnerCompletedEvent();

	// Overlap
	UFUNCTION()
	void OnPlayerEnteredZone(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
		UPrimitiveComponent* OtherComp, int32 OtherBodyIndex,
		bool bFromSweep, const FHitResult& SweepResult);

	UFUNCTION()
	void OnPlayerLeftZone(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
		UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);

	// Spawner helpers
	void ActivateLinkedSpawners();
	void DeactivateLinkedSpawners();
	void CheckClearCompletion();
};

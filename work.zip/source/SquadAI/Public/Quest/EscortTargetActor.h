// EscortTargetActor.h - S19-ESCORT: the convoy / escort objective.
//
// WHAT THIS IS
// ------------
// A moving objective. Place this actor on a truck, an APC, a pack mule or a
// group of civilians, point its `Route` at an AEnemyPatrolRoute (the same
// actor the patrolling enemies walk, with the same draggable point handles),
// and it walks the route in order:
//
//   * it STOPS when the player falls behind (`bWaitForPlayer` + leash radii,
//     with hysteresis so it cannot stutter), and says so in the log once,
//   * it pauses at each point for that point's own WaitSeconds (or the route's
//     default), so a designer can script "wait here while the player clears
//     the checkpoint",
//   * it can be wounded: a UHealthComponent, and `OnEscortDied` when it runs
//     out - the zone decides whether that fails the mission,
//   * it reports itself ARRIVED on the last point (`OnEscortArrived`), which is
//     the gate an AMissionZone with `bRequireEscortArrival` waits on.
//
// WHAT IT IS NOT
// --------------
// It is not an AI. It walks straight toward the next point with a swept
// SetActorLocation, so it slides along walls instead of clipping through them,
// and it does not path around buildings. Keep route points on walkable ground -
// they are grounded by a downward trace when the route is read, and the log
// reports a convoy that has stopped making progress so a blocked one is visible
// rather than silent.
//
// Enemy interaction comes from what already exists: radial damage (artillery,
// grenades, barrels) reaches it through its health component, and it blocks
// nothing (collision is off) so it can never wedge the player or the squad.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Quest/EscortModel.h"
#include "EscortTargetActor.generated.h"

class USceneComponent;
class UStaticMeshComponent;
class UHealthComponent;
class AEnemyPatrolRoute;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnEscortArrived, class AEscortTargetActor*, Escort);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnEscortDied, class AEscortTargetActor*, Escort);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnEscortProgress, class AEscortTargetActor*, Escort, float, Progress01);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnEscortHoldChanged, class AEscortTargetActor*, Escort, bool, bHoldingForPlayer);

UCLASS(BlueprintType, Blueprintable, ClassGroup = (SquadAI),
	meta = (DisplayName = "Escort / Convoy Target"))
class SQUADAI_API AEscortTargetActor : public AActor
{
	GENERATED_BODY()

public:
	AEscortTargetActor();
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;

	// ===== CONFIG =====

	/** Name for the log and the mission card ("Convoy", "Ammo truck", ...). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Escort")
	FText EscortName;

	/** The route to walk. An AEnemyPatrolRoute: press its "Add Patrol Point" button and drag
	 *  the handles. Points are read in order, and the route's per-point WaitSeconds are
	 *  honoured. If it is a closed loop, the convoy laps instead of finishing. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Escort")
	TObjectPtr<AEnemyPatrolRoute> Route;

	/** Walk speed toward the next point (cm/s). 220 = a fast walk. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Escort", meta = (ClampMin = "10.0"))
	float MoveSpeedCmPerSec = 220.f;

	/** How close counts as "at the point" (cm). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Escort", meta = (ClampMin = "20.0"))
	float ArriveRadiusCm = 150.f;

	/** Seconds the convoy pauses when the route is finished (parking, engines off). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Escort", meta = (ClampMin = "0.0"))
	float ArrivalHoldSeconds = 0.f;

	/** Turn to face the direction of travel. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Escort")
	bool bFaceMovementDirection = true;

	// ===== the mercy leash =====

	/** Stop when the player is further away than this, and wait for him. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Escort|Leash")
	bool bWaitForPlayer = true;

	/** Halt beyond this distance from the player (cm). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Escort|Leash", meta = (ClampMin = "0.0"))
	float PlayerHaltRadiusCm = 3000.f;

	/** Resume once the player is back inside this distance (cm). 0 = 75% of the halt
	 *  radius. Must be PAST the halt radius for a stable, non-stuttering convoy. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Escort|Leash", meta = (ClampMin = "0.0"))
	float PlayerResumeRadiusCm = 2200.f;

	// ===== wounds =====

	/** Enemies do not target this actor directly (it is not a soldier); explosions and
	 *  every other radial damage source DO reach it. Off = a purely narrative convoy. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Escort|Health")
	bool bCanBeWounded = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Escort|Health", meta = (ClampMin = "1.0"))
	float MaxHealth = 900.f;

	/** Stops walking once health drops below this fraction (0 = keep walking while alive). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Escort|Health", meta = (ClampMin = "0.0", ClampMax = "1.0"))
	float ImmobilizedBelowHealthFraction = 0.f;

	// ===== STATE =====

	UPROPERTY(BlueprintReadOnly, Category = "Escort|State")
	int32 CurrentPointIndex = 0;

	UPROPERTY(BlueprintReadOnly, Category = "Escort|State")
	bool bArrived = false;

	UPROPERTY(BlueprintReadOnly, Category = "Escort|State")
	bool bHoldingForPlayer = false;

	UPROPERTY(BlueprintReadOnly, Category = "Escort|State")
	bool bDead = false;

	/** Points cleared / total, as a 0..1 number for any HUD. */
	UPROPERTY(BlueprintReadOnly, Category = "Escort|State")
	float Progress = 0.f;

	// ===== EVENTS =====

	UPROPERTY(BlueprintAssignable, Category = "Escort|Events")
	FOnEscortArrived OnEscortArrived;

	UPROPERTY(BlueprintAssignable, Category = "Escort|Events")
	FOnEscortDied OnEscortDied;

	UPROPERTY(BlueprintAssignable, Category = "Escort|Events")
	FOnEscortProgress OnEscortProgress;

	UPROPERTY(BlueprintAssignable, Category = "Escort|Events")
	FOnEscortHoldChanged OnEscortHoldChanged;

	// ===== API =====

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Escort|Components")
	TObjectPtr<USceneComponent> SceneRoot;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Escort|Components")
	TObjectPtr<UStaticMeshComponent> ConvoyMesh;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Escort|Components")
	TObjectPtr<UHealthComponent> HealthComp;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Escort")
	bool IsArrived() const { return bArrived; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Escort")
	bool IsEscortDead() const { return bDead; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Escort")
	bool IsHoldingForPlayer() const { return bHoldingForPlayer; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Escort")
	float GetEscortProgress01() const { return Progress; }

	/** Points still to clear. 0 = arrived (or no route). */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Escort")
	int32 GetPointsRemaining() const;

	/** Distance from the convoy to the next point (cm). -1 when arrived / no route. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Escort")
	float GetDistanceToNextPoint() const;

	/** Force the arrival branch (debug / scripted "the convoy teleported out"). */
	UFUNCTION(BlueprintCallable, Category = "Escort")
	void ForceArrival();

	/** Back to the start of the route, health restored. Used when a failed mission retries. */
	UFUNCTION(BlueprintCallable, Category = "Escort")
	void ResetEscort();

protected:
	/** Reads the route's points, grounds them, and reports an unusable route once. */
	void RefreshRoute();

	UFUNCTION()
	void OnEscortHealthDied(AActor* OwnerActor);

private:
	/** Grounded world locations, rebuilt from the route (no per-tick traces). */
	TArray<FVector> CachedPoints;
	TArray<float> CachedWaits;
	bool bRouteWarned = false;

	float WaitRemaining = 0.f;
	float LastProgressBroadcast = -1.f;
	float NoProgressSeconds = 0.f;
	float LastDistanceToNext = -1.f;
	bool bStuckWarned = false;
};

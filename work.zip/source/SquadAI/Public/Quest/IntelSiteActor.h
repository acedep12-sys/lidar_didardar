// IntelSiteActor.h - S19-INTEL: the recon / intelligence objective.
//
// WHAT THIS IS
// ------------
// Stand at the site, scan it, and the beacon reports on its own. The demolition
// charge (ASabotageTargetActor) already had the proximity-hold machinery, but it
// is welded to "blow it up": plant, fuse, radial damage. Recon needs the SAME
// hold with no explosion, and a second phase - the set transmits, then reports -
// which is what makes intel a different job from demo:
//
//   * scanning advances only while the player is close, and decays at 1.5x while
//     he walks away (the sabotage actor's shipped feel, kept so the two read the
//     same in the hand),
//   * once planted, the beacon TRANSMITS BY ITSELF for `TransmitTime` seconds -
//     unless `bTransmitNeedsPlayerNearby` turns it into a hold-the-point job,
//   * `OnIntelReported` fires when the set is done, which is the gate an
//     AMissionZone with linked `IntelSites` waits on.
//
// The rules (progress, decay, plant test, transmit test) live in
// Quest/IntelScanModel.h and are unit-tested offline by tools/mission_test.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Quest/IntelScanModel.h"
#include "IntelSiteActor.generated.h"

class UStaticMeshComponent;
class UMaterialInstanceDynamic;

UENUM(BlueprintType)
enum class EIntelSiteState : uint8
{
	AwaitingScan UMETA(DisplayName = "Awaiting Scan"),
	Scanning     UMETA(DisplayName = "Scanning"),
	Transmitting UMETA(DisplayName = "Transmitting"),
	Reported     UMETA(DisplayName = "Reported")
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnIntelSiteReported, class AIntelSiteActor*, Site);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnIntelScanProgress, class AIntelSiteActor*, Site, float, Progress01);

UCLASS(BlueprintType, Blueprintable, ClassGroup = (SquadAI),
	meta = (DisplayName = "Intel / Recon Site"))
class SQUADAI_API AIntelSiteActor : public AActor
{
	GENERATED_BODY()

public:
	AIntelSiteActor();
	virtual void Tick(float DeltaTime) override;

	// ===== CONFIG =====

	/** Name for the log and the mission card ("Radio shack", "Ammo ledger", ...). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Intel")
	FText SiteName;

	/** Stand within this range to scan (cm). Same radius the charge uses. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Intel", meta = (ClampMin = "100.0"))
	float ScanRadius = 260.f;

	/** Seconds of holding position to finish the scan. Leaving decays it. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Intel", meta = (ClampMin = "0.5"))
	float ScanTime = 4.f;

	/** Seconds the beacon transmits before it reports. The squad is free to move on. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Intel", meta = (ClampMin = "0.0"))
	float TransmitTime = 20.f;

	/** Turn the transmit phase into a hold-the-point job: the set only transmits while
	 *  the player is inside TransmitRadius. Off (default) = it finishes on its own. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Intel")
	bool bTransmitNeedsPlayerNearby = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Intel",
		meta = (EditCondition = "bTransmitNeedsPlayerNearby", ClampMin = "100.0"))
	float TransmitRadius = 900.f;

	// ===== STATE =====

	UPROPERTY(BlueprintReadOnly, Category = "Intel|State")
	EIntelSiteState SiteState = EIntelSiteState::AwaitingScan;

	/** 0..1 scan progress (1 = planted). */
	UPROPERTY(BlueprintReadOnly, Category = "Intel|State")
	float ProbeProgress01 = 0.f;

	/** 0..1 transmit progress. */
	UPROPERTY(BlueprintReadOnly, Category = "Intel|State")
	float TransmitProgress01 = 0.f;

	// ===== EVENTS =====

	UPROPERTY(BlueprintAssignable, Category = "Intel|Events")
	FOnIntelSiteReported OnIntelReported;

	UPROPERTY(BlueprintAssignable, Category = "Intel|Events")
	FOnIntelScanProgress OnIntelScanProgress;

	// ===== COMPONENTS =====

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Intel|Components")
	TObjectPtr<UStaticMeshComponent> MarkerDisc;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Intel|Components")
	TObjectPtr<UStaticMeshComponent> AntennaMesh;

	// ===== API =====

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Intel")
	bool IsReported() const { return SiteState == EIntelSiteState::Reported; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Intel")
	bool IsPlanted() const { return SiteState == EIntelSiteState::Transmitting || SiteState == EIntelSiteState::Reported; }

	/** Back to "awaiting scan" with the beacon hidden - used by mission retries. */
	UFUNCTION(BlueprintCallable, Category = "Intel")
	void ResetSite();

protected:
	virtual void BeginPlay() override;

private:
	float ScanProgressSeconds = 0.f;
	float TransmitSeconds = 0.f;

	UPROPERTY(Transient)
	TObjectPtr<UMaterialInstanceDynamic> MarkerMID;

	void SetMarkerColor(const FLinearColor& C);
	void BeginTransmit();
	void ReportNow();
};

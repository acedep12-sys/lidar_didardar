// TerrainStructureModel.h - S21-TERRAIN: the map's ELEVATION STRUCTURE as pure
// functions. The scatter used to pick mission ground by planar distance only -
// the user was right: that ignores the land itself. This model reads a sampled
// height grid and answers the designer's questions: where does the land RISE,
// which points DOMINATE the ground around them (guard posts, forts, checkpoints),
// how much of the map is lowland vs highland, and how steep is a cell. Kept
// engine-free so the harness pins every rule offline; the editor library fills
// the grid with real world traces.
#pragma once
#include "CoreMinimal.h"

/** One sampled cell of the height grid. */
struct FHeightCell
{
	float Z = 0.f;          // world ground height (cm)
	bool bValid = false;    // false = the trace found nothing there (unloaded cell?)
	float Prominence = 0.f; // S21-PROM: rise over the SADDLE connecting this hill to
	                        // higher ground (cm); 0 = not a hill (or not computed)
};

/** A rectangular height grid, row-major (Y rows of X cells). */
struct FHeightGrid
{
	TArray<FHeightCell> Cells;
	int32 W = 0;              // cells across (X)
	int32 H = 0;              // cells down (Y)
	float CellSizeCm = 0.f;   // world size of one cell
	float MinZ = 0.f;         // valid cells only
	float MaxZ = 0.f;
	int32 ValidCount = 0;
	bool bProminenceDone = false;  // S21-PROM: the flood-fill pass has run

	bool IsValid() const { return W > 0 && H > 0 && Cells.Num() == W * H && ValidCount > 0; }
	int32 Index(int32 X, int32 Y) const { return Y * W + X; }
	const FHeightCell* At(int32 X, int32 Y) const
	{
		const bool bIn = X >= 0 && Y >= 0 && X < W && Y < H;
		return bIn ? &Cells[Index(X, Y)] : nullptr;
	}
};

/** One dominant ground point - a guard-post / fort site. */
struct FTerrainHighPoint
{
	int32 CellX = 0;
	int32 CellY = 0;
	float Z = 0.f;              // absolute ground height (cm)
	float RiseCm = 0.f;         // Z - grid minimum: how far it stands above the lowland
	float ProminenceCm = 0.f;   // rise over the connecting SADDLE - the true hill rank
};

/** S21-DEEP: how a cell SITS in the land - the landform classes a surveyor
 *  reads off a contour map. The order is the report's census order. */
enum ETerrainLandform
{
	Landform_Plain = 0,      // flat and neither high nor low in its surroundings
	Landform_Peak,           // high ground standing over everything near it
	Landform_Crest,          // a steep ridge line / escarpment lip
	Landform_UpperSlope,     // on the upper part of a face
	Landform_LowerSlope,     // on the lower part of a face
	Landform_Valley,         // sitting low: a wadi, gully or river floor
	Landform_Count
};

/** A PASS: the saddle cell where two islands of high ground meet. The column
 *  height (ColProminenceCm) is the prominence the pass awards - a rank for how
 *  much land it unlocks. Passes are where crossings, checkpoints and ambushes
 *  live: the one easy way through. */
struct FTerrainSaddle
{
	int32 CellX = 0;
	int32 CellY = 0;
	float Z = 0.f;                 // the pass's ground height (cm)
	float ColProminenceCm = 0.f;   // the rise it concedes between the two hills
};

/** A CLOSED DEPRESSION: ground water cannot leave - a basin, crater or sink.
 *  DepthCm is the rise from floor to overflow rim (the prominence of the
 *  inverted land). Depots, hiding spots, and where water pools. */
struct FTerrainDepression
{
	int32 CellX = 0;
	int32 CellY = 0;
	float Z = 0.f;          // the floor's ground height (cm)
	float DepthCm = 0.f;    // floor to rim (cm)
};

/** The biggest patch of nearly-level ground: the map's TANK COUNTRY. */
struct FTerrainPatch
{
	int32 CellCount = 0;
	float CentroidX = 0.f;   // mean cell coords of the patch
	float CentroidY = 0.f;
};

/** A POSSIBLE MISSION AREA - the land's own proposal for where an operation
 *  could live, with the measured fact that makes it worth one. */
enum ETerrainCandidateKind
{
	Cand_Overwatch = 0,   // high ground with the widest measured viewshed
	Cand_Pass,            // the low way between hills: checkpoint / ambush
	Cand_Basin,           // closed ground, invisible from outside: depot / camp
	Cand_Armor,           // the big level patch's centre: mechanised going
	Cand_Count
};

struct FTerrainCandidate
{
	int32 CellX = 0;
	int32 CellY = 0;
	float Z = 0.f;           // ground height (cm)
	int32 Kind = 0;          // ETerrainCandidateKind
	int32 ScoreCells = 0;    // Overwatch: viewshed cells. Armor: patch cells.
	float ScoreCm = 0.f;     // Pass: column height. Basin: depth to rim.
};

struct FTerrainStructureModel
{
	/** Min/max over the VALID cells (call after filling the grid). */
	static void ComputeRange(FHeightGrid& G)
	{
		G.MinZ = FLT_MAX;
		G.MaxZ = -FLT_MAX;
		G.ValidCount = 0;
		for (const FHeightCell& C : G.Cells)
		{
			if (C.bValid)
			{
				G.MinZ = FMath::Min(G.MinZ, C.Z);
				G.MaxZ = FMath::Max(G.MaxZ, C.Z);
				++G.ValidCount;
			}
		}
		if (G.ValidCount == 0)
		{
			G.MinZ = 0.f;
			G.MaxZ = 0.f;
		}
	}

	/** The cell's steepest drop/rise against its 4 neighbours, as a fraction of
	 *  the cell size (0 = flat deck; 1.0 = a 45-degree face at this sample rate). */
	static float SlopeAt(const FHeightGrid& G, int32 X, int32 Y)
	{
		const FHeightCell* C = G.At(X, Y);
		if (!C || !C->bValid || G.CellSizeCm <= 0.f)
		{
			return 0.f;
		}
		float Best = 0.f;
		// D8: the steepest of EIGHT directions - diagonal faces count too
		const int32 Off[8][2] = {
			{ 1, 0 }, { -1, 0 }, { 0, 1 }, { 0, -1 },
			{ 1, 1 }, { 1, -1 }, { -1, 1 }, { -1, -1 }
		};
		for (int32 i = 0; i < 8; ++i)
		{
			const FHeightCell* N = G.At(X + Off[i][0], Y + Off[i][1]);
			if (N && N->bValid)
			{
				Best = FMath::Max(Best, static_cast<float>(FMath::Abs(N->Z - C->Z) / G.CellSizeCm));
			}
		}
		return Best;
	}

	/** True when the cell DOMINATES its neighbourhood: nothing valid within
	 *  RadiusCells stands higher, AND at least one stands lower (a plain ties
	 *  everywhere and therefore owns no high ground - a guard post is never
	 *  invented on featureless flat). */
	static bool IsLocalHigh(const FHeightGrid& G, int32 X, int32 Y, int32 RadiusCells)
	{
		const FHeightCell* C = G.At(X, Y);
		if (!C || !C->bValid)
		{
			return false;
		}
		bool bHasLower = false;
		for (int32 dy = -RadiusCells; dy <= RadiusCells; ++dy)
		{
			for (int32 dx = -RadiusCells; dx <= RadiusCells; ++dx)
			{
				if (dx == 0 && dy == 0) { continue; }
				const FHeightCell* N = G.At(X + dx, Y + dy);
				if (!N || !N->bValid) { continue; }
				if (N->Z > C->Z)
				{
					return false;   // something nearby is higher - not dominant
				}
				if (N->Z < C->Z - 1.f)
				{
					bHasLower = true;   // it actually RISES over something
				}
			}
		}
		return bHasLower;
	}

	/** S21-PROM: the map's TRUE hills, by TOPOGRAPHIC PROMINENCE. Flood the grid
	 *  from the tallest cell down (union-find): every cell joins an island; when a
	 *  cell connects islands, the saddle between them is HERE, so each merged-away
	 *  island's peak gets Prominence = PeakZ - saddleZ. An island anchored to the
	 *  map edge drains off-map, so its hill ranks by the full rise (PeakZ - MinZ).
	 *  A plain floods as one island and its "peak" gets prominence 0 - exactly the
	 *  meaning a hill-reader wants: a bump that connects to higher ground through a
	 *  high saddle is a shoulder, not a hill, no matter how locally steep. */
	static void ComputeProminence(FHeightGrid& G)
	{
		ComputeProminenceEx(G, nullptr);
	}

	/** S21-DEEP: everything the flood learns beyond the ranks, in one bundle:
	 *  Saddles - every pass where islands merge (caller ranks and caps);
	 *  PeakTouchesBorder - per cell, 1 when that peak's island had ALREADY
	 *  reached the map edge before its key saddle (an edge-reaching feature
	 *  is a range or a canyon, never a closed hill or basin); PeakSillZ -
	 *  per cell, the key-saddle height of that peak's island (0 = the island
	 *  never met another: no col, no rim). Depression depth on an inverted
	 *  grid is PeakZ - PeakSillZ: the rise from floor to overflow rim. */
	struct FTerrainProminenceAux
	{
		TArray<FTerrainSaddle> Saddles;
		TArray<uint8> PeakTouchesBorder;
		TArray<float> PeakSillZ;
	};
	static void ComputeProminenceEx(FHeightGrid& G, FTerrainProminenceAux* Aux)
	{
		G.bProminenceDone = false;
		if (!G.IsValid())
		{
			return;
		}
		const int32 N = G.W * G.H;
		TArray<int32> Order;                 // valid cells, tallest first (index ties broken - deterministic)
		for (int32 i = 0; i < N; ++i)
		{
			if (G.Cells[i].bValid)
			{
				Order.Add(i);
			}
		}
		Order.Sort([&G](int32 A, int32 B)
		{
			const float ZA = G.Cells[A].Z, ZB = G.Cells[B].Z;
			return (ZA != ZB) ? ZA > ZB : A < B;
		});
		TArray<int32> Parent;   Parent.Init(-1, N);   // -1 = this cell IS the island root
		TArray<int32> PeakIdx;  PeakIdx.Init(0, N);   // at a root: its highest cell
		TArray<float> PeakZ;    PeakZ.Init(0.f, N);
		TArray<bool>  Touches;  Touches.Init(false, N);
		TArray<bool>  Done;     Done.Init(false, N);
		if (Aux)
		{
			Aux->PeakTouchesBorder.Init(0, N);
			Aux->PeakSillZ.Init(0.f, N);
		}

		auto Find = [](TArray<int32>& P, int32 X)
		{
			while (P[X] >= 0) { X = P[X]; }
			return X;
		};
		const int32 Off[8][2] = {
			{ 1, 0 }, { -1, 0 }, { 0, 1 }, { 0, -1 },
			{ 1, 1 }, { 1, -1 }, { -1, 1 }, { -1, -1 }
		};

		for (int32 oi = 0; oi < Order.Num(); ++oi)
		{
			const int32 I = Order[oi];
			const int32 CX = I % G.W;
			const int32 CY = I / G.W;
			const bool bBorder = CX == 0 || CY == 0 || CX == G.W - 1 || CY == G.H - 1;

			int32 Roots[8];
			int32 RootCount = 0;
			for (int32 k = 0; k < 8; ++k)
			{
				const FHeightCell* Nb = G.At(CX + Off[k][0], CY + Off[k][1]);
				if (!Nb || !Nb->bValid)
				{
					continue;
				}
				const int32 J = (CY + Off[k][1]) * G.W + (CX + Off[k][0]);
				if (!Done[J])
				{
					continue;
				}
				const int32 R = Find(Parent, J);
				bool bSeen = false;
				for (int32 t = 0; t < RootCount; ++t)
				{
					bSeen = bSeen || Roots[t] == R;
				}
				if (!bSeen && RootCount < 8)
				{
					Roots[RootCount++] = R;
				}
			}

			if (RootCount == 0)
			{
				// a brand-new island - this cell is its peak for now
				Parent[I] = -1;
				PeakIdx[I] = I;
				PeakZ[I] = G.Cells[I].Z;
				Touches[I] = bBorder;
			}
			else
			{
				// the TALLEST neighbouring island survives; the saddle is at THIS cell's
				// height, so every other island's hill is ranked here and now
				int32 Keep = Roots[0];
				for (int32 t = 1; t < RootCount; ++t)
				{
					if (PeakZ[Roots[t]] > PeakZ[Keep]
						|| (PeakZ[Roots[t]] == PeakZ[Keep] && Roots[t] < Keep))
					{
						Keep = Roots[t];
					}
				}
				// THIS cell is the pass: the last way through between the
				// merged-away hills and the taller survivor
				if (Aux && RootCount >= 2)
				{
					float Col = 0.f;
					for (int32 t = 0; t < RootCount; ++t)
					{
						if (Roots[t] == Keep) { continue; }
						Col = FMath::Max(Col, PeakZ[Roots[t]] - G.Cells[I].Z);
					}
					FTerrainSaddle S;
					S.CellX = CX;
					S.CellY = CY;
					S.Z = G.Cells[I].Z;
					S.ColProminenceCm = Col;
					Aux->Saddles.Add(S);
				}
				// the key saddle of the SURVIVOR island is its FIRST merge -
				// every later merge sits lower and means nothing
				if (Aux && RootCount >= 2 && Aux->PeakSillZ[PeakIdx[Keep]] == 0.f)
				{
					Aux->PeakSillZ[PeakIdx[Keep]] = G.Cells[I].Z;
					Aux->PeakTouchesBorder[PeakIdx[Keep]] = Touches[Keep] ? 1 : 0;
				}
				for (int32 t = 0; t < RootCount; ++t)
				{
					if (Roots[t] == Keep) { continue; }
					G.Cells[PeakIdx[Roots[t]]].Prominence = PeakZ[Roots[t]] - G.Cells[I].Z;
					if (Aux)
					{
						// the merged-away peak's key saddle is THIS merge; its
						// border state is whatever the island had reached NOW
						Aux->PeakSillZ[PeakIdx[Roots[t]]] = G.Cells[I].Z;
						Aux->PeakTouchesBorder[PeakIdx[Roots[t]]] = Touches[Roots[t]] ? 1 : 0;
					}
					Parent[Roots[t]] = Keep;   // merged away - its rank is settled
				}
				// a merged island's border contact belongs to the survivor now
				for (int32 t = 0; t < RootCount; ++t)
				{
					if (Touches[Roots[t]]) { Touches[Keep] = true; }
				}
				Parent[I] = Keep;
				if (bBorder)
				{
					Touches[Keep] = true;
				}
				if (G.Cells[I].Z > PeakZ[Keep])
				{
					PeakZ[Keep] = G.Cells[I].Z;
					PeakIdx[Keep] = I;
				}
			}
			Done[I] = true;
		}

		// the survivors: border-anchored hills rank by their full rise over the lowland
		for (int32 i = 0; i < N; ++i)
		{
			if (!G.Cells[i].bValid || Parent[i] != -1)
			{
				continue;
			}
			const float Prom = PeakZ[i] - G.MinZ;   // the full rise over the lowland
			if (G.Cells[PeakIdx[i]].Prominence <= 0.f)
			{
				G.Cells[PeakIdx[i]].Prominence = Prom;
			}
		}
		G.bProminenceDone = true;
	}

	/** Which third of the map's relief this height sits in: 0 lowland, 1 mid, 2 high. */
	static int32 ElevationBand(float Z, float MinZ, float MaxZ)
	{
		if (MaxZ <= MinZ) { return 0; }
		const float T = (Z - MinZ) / (MaxZ - MinZ);
		return T < (1.f / 3.f) ? 0 : (T < (2.f / 3.f) ? 1 : 2);
	}

	/** The band's word for the report. */
	static const TCHAR* BandWord(int32 Band)
	{
		return Band == 2 ? TEXT("highland") : (Band == 1 ? TEXT("mid-slope") : TEXT("lowland"));
	}

	/** The map's dominant ground, best first: local highs (dominance radius
	 *  RadiusCells) deduped to at least SepCells apart, capped at MaxPoints.
	 *  RiseCm says how far each stands above the map's lowest valid ground. */
	static TArray<FTerrainHighPoint> FindHighGround(const FHeightGrid& G,
		int32 MaxPoints = 8, int32 RadiusCells = 2, int32 SepCells = 3)
	{
		TArray<FTerrainHighPoint> Out;
		if (!G.IsValid())
		{
			return Out;
		}
		for (int32 Y = 0; Y < G.H; ++Y)
		{
			for (int32 X = 0; X < G.W; ++X)
			{
				const FHeightCell* C = G.At(X, Y);
				if (!C || !C->bValid)
				{
					continue;
				}
				// with the prominence pass run: a REAL hill only (prominence > 0)
				if (G.bProminenceDone)
				{
					if (C->Prominence <= 1.f)
					{
						continue;
					}
				}
				else if (!IsLocalHigh(G, X, Y, RadiusCells))
				{
					continue;
				}
				bool bTooClose = false;
				for (const FTerrainHighPoint& P : Out)
				{
					const int32 DX = P.CellX - X, DY = P.CellY - Y;
					if (DX * DX + DY * DY < SepCells * SepCells)
					{
						bTooClose = true;
						break;
					}
				}
				if (bTooClose)
				{
					continue;
				}
				FTerrainHighPoint P;
				P.CellX = X;
				P.CellY = Y;
				P.Z = C->Z;
				P.RiseCm = C->Z - G.MinZ;
				P.ProminenceCm = C->Prominence;
				Out.Add(P);
			}
		}
		// best first: prominence is the true hill rank; rise is the fallback
		Out.Sort([](const FTerrainHighPoint& A, const FTerrainHighPoint& B)
		{
			return A.ProminenceCm > B.ProminenceCm;
		});
		while (Out.Num() > MaxPoints)
		{
			Out.RemoveAt(Out.Num() - 1);
		}
		return Out;
	}

	/** The best high point within RadiusCells of a cell - the guard-post site for
	 *  a mission placed at that cell. False when the grid is empty or nothing
	 *  dominant is near (the caller just skips the guard post). */
	static bool NearestHighPoint(const FHeightGrid& G, int32 X, int32 Y,
		int32 RadiusCells, FTerrainHighPoint& Out)
	{
		const TArray<FTerrainHighPoint> Highs = FindHighGround(G, 1024, 2, 2);
		int32 Best = -1;
		double BestD = 1.0e30;
		for (int32 i = 0; i < Highs.Num(); ++i)
		{
			const double DX = Highs[i].CellX - X;
			const double DY = Highs[i].CellY - Y;
			const double D = DX * DX + DY * DY;
			if (D <= double(RadiusCells) * RadiusCells && D < BestD)
			{
				BestD = D;
				Best = i;
			}
		}
		if (Best == -1)
		{
			return false;
		}
		Out = Highs[Best];
		return true;
	}

	/* ================================================================== */
	/* S21-DEEP: the full survey. Prominence alone says where the hills   */
	/* ARE; a complex landscape also asks which way every face points,    */
	/* how broken the ground is, where water runs, where it pools, where  */
	/* the one easy pass between hills lies, and which posts see which.   */
	/* Every function here is engine-free and pinned by tools/map_test.   */
	/* ================================================================== */

	/** The direction this cell drains toward: the steepest DESCENT among the
	 *  eight neighbours (diagonals compete fairly - drop divided by the true
	 *  step distance). Degrees clockwise from EAST: 0 = east, 90 = north,
	 *  180 = west, 270 = south. -1 when there is no lower neighbour (a pit
	 *  or a deck - water stands). This is the face a soldier on the slope
	 *  is looking at when he faces downhill. */
	static float AspectDegAt(const FHeightGrid& G, int32 X, int32 Y)
	{
		const FHeightCell* C = G.At(X, Y);
		if (!C || !C->bValid || G.CellSizeCm <= 0.f)
		{
			return -1.f;
		}
		const int32 Off[8][2] = {
			{ 1, 0 }, { -1, 0 }, { 0, 1 }, { 0, -1 },
			{ 1, 1 }, { 1, -1 }, { -1, 1 }, { -1, -1 }
		};
		const float Dist[8] = { 1.f, 1.f, 1.f, 1.f,
			1.41421356f, 1.41421356f, 1.41421356f, 1.41421356f };
		float BestDrop = 0.f;
		float Dx = 0.f, Dy = 0.f;
		for (int32 i = 0; i < 8; ++i)
		{
			const FHeightCell* N = G.At(X + Off[i][0], Y + Off[i][1]);
			if (!N || !N->bValid)
			{
				continue;
			}
			const float Drop = (C->Z - N->Z) / Dist[i];
			if (Drop > BestDrop + 1e-6f)
			{
				BestDrop = Drop;
				Dx = static_cast<float>(Off[i][0]) / Dist[i];
				Dy = static_cast<float>(Off[i][1]) / Dist[i];
			}
		}
		if (BestDrop <= 0.f)
		{
			return -1.f;
		}
		float Deg = FMath::Atan2(Dy, Dx) * 57.29577951f;
		while (Deg < 0.f) { Deg += 360.f; }
		return Deg;
	}

	/** TERRAIN RUGGEDNESS INDEX: the mean |height difference| against the
	 *  valid eight neighbours (cm). Broken, shell-blasted country scores
	 *  high; a paved deck 0. Rough ground hides movement and kills
	 *  vehicles' speed - the report uses it to separate cover-rich ruin
	 *  country from smooth going. */
	static float TriAt(const FHeightGrid& G, int32 X, int32 Y)
	{
		const FHeightCell* C = G.At(X, Y);
		if (!C || !C->bValid)
		{
			return 0.f;
		}
		const int32 Off[8][2] = {
			{ 1, 0 }, { -1, 0 }, { 0, 1 }, { 0, -1 },
			{ 1, 1 }, { 1, -1 }, { -1, 1 }, { -1, -1 }
		};
		float Sum = 0.f;
		int32 Count = 0;
		for (int32 i = 0; i < 8; ++i)
		{
			const FHeightCell* N = G.At(X + Off[i][0], Y + Off[i][1]);
			if (!N || !N->bValid)
			{
				continue;
			}
			Sum += FMath::Abs(N->Z - C->Z);
			++Count;
		}
		return Count > 0 ? Sum / Count : 0.f;
	}

	/** TOPOGRAPHIC POSITION INDEX: how far the cell stands ABOVE the mean of
	 *  the valid cells in a RadiusCells box around it (cm; itself excluded).
	 *  Ridges and knolls score positive, valley floors negative, mid-slope
	 *  near zero. This one number turns a height map into a LANDFORM map. */
	static float TpiAt(const FHeightGrid& G, int32 X, int32 Y, int32 RadiusCells)
	{
		const FHeightCell* C = G.At(X, Y);
		if (!C || !C->bValid)
		{
			return 0.f;
		}
		float Sum = 0.f;
		int32 Count = 0;
		for (int32 dy = -RadiusCells; dy <= RadiusCells; ++dy)
		{
			for (int32 dx = -RadiusCells; dx <= RadiusCells; ++dx)
			{
				if (dx == 0 && dy == 0) { continue; }
				const FHeightCell* N = G.At(X + dx, Y + dy);
				if (!N || !N->bValid)
				{
					continue;
				}
				Sum += N->Z;
				++Count;
			}
		}
		return Count > 0 ? C->Z - Sum / Count : 0.f;
	}

	/** The landform class of a cell (ETerrainLandform). TpiThresholdCm is how
	 *  far above/below the surroundings counts as standing over / sitting
	 *  under them; FlatSlopeCmPerCm (rise per run; default ~4.6 degrees)
	 *  splits level floors from steep crest lines. */
	static int32 ClassifyLandform(const FHeightGrid& G, int32 X, int32 Y,
		int32 RadiusCells, float TpiThresholdCm, float FlatSlopeCmPerCm = 0.08f)
	{
		const float Tpi = TpiAt(G, X, Y, RadiusCells);
		const float Slope = SlopeAt(G, X, Y);
		if (Tpi < -TpiThresholdCm)
		{
			return Landform_Valley;   // sitting under its surroundings, any grade
		}
		const bool bSteep = Slope >= FlatSlopeCmPerCm;
		if (Tpi > TpiThresholdCm)
		{
			// PEAK = nothing near stands higher (the top of its piece of
			// land, whatever the grade); CREST = high ground on a steep line
			// that still looks UP at a neighbour.
			for (int32 dy = -RadiusCells; dy <= RadiusCells; ++dy)
			{
				for (int32 dx = -RadiusCells; dx <= RadiusCells; ++dx)
				{
					if (dx == 0 && dy == 0) { continue; }
					const FHeightCell* N = G.At(X + dx, Y + dy);
					if (N && N->bValid && N->Z > G.At(X, Y)->Z + 1.f)
					{
						return bSteep ? Landform_Crest : Landform_UpperSlope;
					}
				}
			}
			return Landform_Peak;
		}
		if (!bSteep)
		{
			return Landform_Plain;
		}
		return Tpi >= 0.f ? Landform_UpperSlope : Landform_LowerSlope;
	}

	/** The landform's word for the report. */
	static const TCHAR* LandformWord(int32 Landform)
	{
		switch (Landform)
		{
			case Landform_Peak: return TEXT("peaks");
			case Landform_Crest: return TEXT("crest lines");
			case Landform_UpperSlope: return TEXT("upper slopes");
			case Landform_LowerSlope: return TEXT("lower slopes");
			case Landform_Valley: return TEXT("valley floors");
			default: return TEXT("plain floors");
		}
	}

	/** D8 FLOW: for every cell, the neighbour water takes (steepest descent,
	 *  -1 = pit or off-map) and the DRAINAGE AREA in cells - how many cells'
	 *  rainfall crosses this cell on its way out. Cells are poured tallest
	 *  first, so every cell is complete before it empties downhill: the
	 *  numbers are exact, and the map's streams fall out of the arithmetic
	 *  instead of being guessed from the biome paint. */
	static void ComputeFlow(const FHeightGrid& G, TArray<int32>& AreaCells,
		TArray<int32>& Downhill)
	{
		const int32 N = G.W * G.H;
		Downhill.Reset();
		Downhill.Init(-1, N);
		AreaCells.Reset();
		AreaCells.Init(0, N);
		if (!G.IsValid())
		{
			return;
		}
		TArray<int32> Order;
		for (int32 i = 0; i < N; ++i)
		{
			if (G.Cells[i].bValid)
			{
				Order.Add(i);
			}
		}
		Order.Sort([&G](int32 A, int32 B)
		{
			const float ZA = G.Cells[A].Z, ZB = G.Cells[B].Z;
			return (ZA != ZB) ? ZA > ZB : A < B;
		});
		const int32 Off[8][2] = {
			{ 1, 0 }, { -1, 0 }, { 0, 1 }, { 0, -1 },
			{ 1, 1 }, { 1, -1 }, { -1, 1 }, { -1, -1 }
		};
		const float Dist[8] = { 1.f, 1.f, 1.f, 1.f,
			1.41421356f, 1.41421356f, 1.41421356f, 1.41421356f };
		for (int32 oi = 0; oi < Order.Num(); ++oi)
		{
			const int32 I = Order[oi];
			AreaCells[I] += 1;   // its own rainfall (plus everything upstream)
			const int32 CX = I % G.W;
			const int32 CY = I / G.W;
			const FHeightCell* C = &G.Cells[I];
			float BestDrop = 0.f;
			int32 BestJ = -1;
			for (int32 k = 0; k < 8; ++k)
			{
				const FHeightCell* Nb = G.At(CX + Off[k][0], CY + Off[k][1]);
				if (!Nb || !Nb->bValid)
				{
					continue;
				}
				const float Drop = (C->Z - Nb->Z) / Dist[k];
				if (Drop > BestDrop + 1e-6f)
				{
					BestDrop = Drop;
					BestJ = (CY + Off[k][1]) * G.W + (CX + Off[k][0]);
				}
			}
			Downhill[I] = BestJ;
			if (BestJ >= 0)
			{
				AreaCells[BestJ] += AreaCells[I];
			}
		}
	}

	/** The stream NETWORK: polylines of cell indices, each starting at a
	 *  source (a stream cell no other stream pours into) and walking
	 *  downstream to a sink or the first already-traced cell. ThresholdCells
	 *  is the drainage area a cell needs before this calls it a stream.
	 *  Deterministic: sources scanned row-major, the steepest-descent rule
	 *  breaks drop ties by first offset. */
	static void TraceStreams(const FHeightGrid& G, const TArray<int32>& AreaCells,
		const TArray<int32>& Downhill, int32 ThresholdCells, TArray<TArray<int32>>& Out)
	{
		Out.Reset();
		if (!G.IsValid() || AreaCells.Num() != G.W * G.H || Downhill.Num() != G.W * G.H)
		{
			return;
		}
		const int32 N = G.W * G.H;
		TArray<uint8> Traced;
		Traced.Init(0, N);
		const int32 Off[8][2] = {
			{ 1, 0 }, { -1, 0 }, { 0, 1 }, { 0, -1 },
			{ 1, 1 }, { 1, -1 }, { -1, 1 }, { -1, -1 }
		};
		auto IsStream = [&](int32 I)
		{
			return G.Cells[I].bValid && AreaCells[I] >= ThresholdCells;
		};
		for (int32 I = 0; I < N; ++I)
		{
			if (!IsStream(I) || Traced[I])
			{
				continue;
			}
			const int32 CX = I % G.W;
			const int32 CY = I / G.W;
			bool bHead = true;
			for (int32 k = 0; k < 8; ++k)
			{
				const int32 NX = CX + Off[k][0], NY = CY + Off[k][1];
				if (NX < 0 || NY < 0 || NX >= G.W || NY >= G.H) { continue; }
				const int32 J = NY * G.W + NX;
				if (IsStream(J) && Downhill[J] == I)
				{
					bHead = false;   // another stream feeds this cell - not a source
					break;
				}
			}
			if (!bHead)
			{
				continue;
			}
			TArray<int32> Line;
			int32 Cur = I;
			while (Cur >= 0 && IsStream(Cur) && !Traced[Cur] && Line.Num() <= N)
			{
				Traced[Cur] = 1;
				Line.Add(Cur);
				Cur = Downhill[Cur];
			}
			if (Line.Num() > 0)
			{
				Out.Add(Line);
			}
		}
	}

	/** The map's CLOSED DEPRESSIONS, deepest first: floors water cannot leave
	 *  - basins, craters, sinks - each ranked by its depth to the overflow
	 *  rim. Found by running the prominence flood on the INVERTED land: a
	 *  basin's floor is exactly a mountain in the upside-down world, and the
	 *  same flood that ranks honest hills ranks honest pits. Islands that
	 *  reach the map edge are skipped - a canyon mouth drains, a basin does
	 *  not. Hiding spots, water pools, and where a lost patrol would
	 *  naturally bed down. */
	static TArray<FTerrainDepression> FindDepressions(const FHeightGrid& G, int32 MaxCount = 6)
	{
		TArray<FTerrainDepression> Out;
		if (!G.IsValid())
		{
			return Out;
		}
		FHeightGrid Inv;
		Inv.W = G.W;
		Inv.H = G.H;
		Inv.CellSizeCm = G.CellSizeCm;
		Inv.ValidCount = G.ValidCount;
		for (int32 i = 0; i < G.Cells.Num(); ++i)
		{
			FHeightCell C = G.Cells[i];
			C.Z = -C.Z;
			C.Prominence = 0.f;
			Inv.Cells.Add(C);
		}
		FTerrainProminenceAux Aux;
		ComputeProminenceEx(Inv, &Aux);
		for (int32 i = 0; i < Inv.Cells.Num(); ++i)
		{
			const FHeightCell& C = Inv.Cells[i];
			// a closed floor has an overflow rim (a sill in the inverted land;
			// sill 0 = the island never met another, there is no rim at all)
			// and never reached the map edge before it
			if (!C.bValid || Aux.PeakSillZ[i] == 0.f || Aux.PeakTouchesBorder[i] == 1)
			{
				continue;
			}
			const float Depth = C.Z - Aux.PeakSillZ[i];
			if (Depth <= 1.f)
			{
				continue;   // rim at or above the floor - not a basin
			}
			FTerrainDepression D;
			D.CellX = i % Inv.W;
			D.CellY = i / Inv.W;
			D.Z = -C.Z;
			D.DepthCm = Depth;
			Out.Add(D);
		}
		Out.Sort([](const FTerrainDepression& A, const FTerrainDepression& B)
		{
			return (A.DepthCm != B.DepthCm) ? A.DepthCm > B.DepthCm
				: (A.CellY != B.CellY ? A.CellY < B.CellY : A.CellX < B.CellX);
		});
		while (Out.Num() > MaxCount)
		{
			Out.RemoveAt(Out.Num() - 1);
		}
		return Out;
	}

	/** The ranked PASSES between the map's hills (best first, caller caps):
	 *  every saddle the prominence flood merged islands at, with the column
	 *  rise it concedes. The pass is the one easy way through - roadblocks,
	 *  checkpoints and ambushes live there, and a campaign route threads
	 *  pass to pass instead of climbing fences. */
	static TArray<FTerrainSaddle> FindPasses(const FHeightGrid& G, int32 MaxCount = 8)
	{
		FTerrainProminenceAux Aux;
		// the flood is deterministic and idempotent - re-running it on an
		// already-ranked grid rewrites the identical prominences, so casting
		// the const away here cannot change what the caller observes
		ComputeProminenceEx(const_cast<FHeightGrid&>(G), &Aux);
		TArray<FTerrainSaddle> Ranked = Aux.Saddles;
		Ranked.Sort([](const FTerrainSaddle& A, const FTerrainSaddle& B)
		{
			return (A.ColProminenceCm != B.ColProminenceCm)
				? A.ColProminenceCm > B.ColProminenceCm
				: (A.CellY != B.CellY ? A.CellY < B.CellY : A.CellX < B.CellX);
		});
		while (Ranked.Num() > MaxCount)
		{
			Ranked.RemoveAt(Ranked.Num() - 1);
		}
		return Ranked;
	}

	/** Can an observer at A see B? Walks the straight cell line at half-cell
	 *  steps; blocked the first time the terrain rises over the sight line
	 *  (both ends carry the observer EyeCm above their ground). GridSlackCm
	 *  forgives the smoothing a coarse grid does to sharp crests - default
	 *  10% of the cell. The rule behind every observation post, every
	 *  "this hill covers that crossing" claim, and every dead approach. */
	static bool Sees(const FHeightGrid& G, int32 AX, int32 AY, int32 BX, int32 BY,
		float EyeCm = 200.f, float GridSlackCm = -1.f)
	{
		const FHeightCell* A = G.At(AX, AY);
		const FHeightCell* B = G.At(BX, BY);
		if (!A || !B || !A->bValid || !B->bValid)
		{
			return false;
		}
		const float Slack = GridSlackCm >= 0.f ? GridSlackCm : G.CellSizeCm * 0.10f;
		const float AZ = A->Z + EyeCm;
		const float BZ = B->Z + EyeCm;
		const int32 Steps = FMath::Max(FMath::Abs(BX - AX), FMath::Abs(BY - AY)) * 2;
		for (int32 t = 1; t < Steps; ++t)
		{
			const float F = static_cast<float>(t) / static_cast<float>(Steps);
			const int32 PX = static_cast<int32>(AX + (BX - AX) * F + 0.5f);
			const int32 PY = static_cast<int32>(AY + (BY - AY) * F + 0.5f);
			const FHeightCell* P = G.At(PX, PY);
			if (!P || !P->bValid)
			{
				continue;   // no data neither proves nor breaks the line
			}
			const float LineZ = AZ + (BZ - AZ) * F;
			if (P->Z > LineZ + Slack)
			{
				return false;
			}
		}
		return true;
	}

	/** How many valid cells an observer at X,Y sees (EyeCm above the ground)
	 *  - the OBSERVATION POST score. Placed where this is large, never by
	 *  planar guess; hilltops outrank valleys because the arithmetic says
	 *  so, cell by cell. */
	static int32 ViewshedCells(const FHeightGrid& G, int32 X, int32 Y, float EyeCm = 200.f)
	{
		if (!G.IsValid())
		{
			return 0;
		}
		int32 Count = 0;
		for (int32 CY = 0; CY < G.H; ++CY)
		{
			for (int32 CX = 0; CX < G.W; ++CX)
			{
				if (Sees(G, X, Y, CX, CY, EyeCm))
				{
					++Count;
				}
			}
		}
		return Count;
	}

	/** The largest connected patch of nearly-level valid ground (4-neighbour
	 *  flood fill) - the map's TANK COUNTRY: where armour manoeuvres at
	 *  speed. MaxSlopeCmPerCm is rise per run (default 0.10, a ~5.7-degree
	 *  limit); ties keep the patch the scan finds first, so the answer is
	 *  deterministic. */
	static FTerrainPatch LargestFlatPatch(const FHeightGrid& G, float MaxSlopeCmPerCm = 0.10f)
	{
		FTerrainPatch Best;
		if (!G.IsValid())
		{
			return Best;
		}
		const int32 N = G.W * G.H;
		TArray<uint8> Seen;
		Seen.Init(0, N);
		TArray<int32> Stack;
		const int32 Off[4][2] = { { 1, 0 }, { -1, 0 }, { 0, 1 }, { 0, -1 } };
		for (int32 Start = 0; Start < N; ++Start)
		{
			if (Seen[Start])
			{
				continue;
			}
			const int32 SX = Start % G.W, SY = Start / G.W;
			if (!G.Cells[Start].bValid || SlopeAt(G, SX, SY) > MaxSlopeCmPerCm)
			{
				Seen[Start] = 1;
				continue;
			}
			int32 Count = 0;
			double SumX = 0.0, SumY = 0.0;
			Stack.Reset();
			Stack.Add(Start);
			Seen[Start] = 1;
			while (Stack.Num() > 0)
			{
				const int32 I = Stack[Stack.Num() - 1];
				Stack.RemoveAt(Stack.Num() - 1);
				++Count;
				SumX += I % G.W;
				SumY += I / G.W;
				const int32 CX = I % G.W, CY = I / G.W;
				for (int32 k = 0; k < 4; ++k)
				{
					const int32 NX = CX + Off[k][0], NY = CY + Off[k][1];
					if (NX < 0 || NY < 0 || NX >= G.W || NY >= G.H) { continue; }
					const int32 J = NY * G.W + NX;
					if (Seen[J] || !G.Cells[J].bValid) { continue; }
					if (SlopeAt(G, NX, NY) > MaxSlopeCmPerCm) { Seen[J] = 1; continue; }
					Seen[J] = 1;
					Stack.Add(J);
				}
			}
			if (Count > Best.CellCount)
			{
				Best.CellCount = Count;
				Best.CentroidX = static_cast<float>(SumX / Count);
				Best.CentroidY = static_cast<float>(SumY / Count);
			}
		}
		return Best;
	}

	/** The candidate kind's words for the report. */
	static const TCHAR* CandidateWord(int32 Kind)
	{
		switch (Kind)
		{
			case Cand_Overwatch: return TEXT("overwatch");
			case Cand_Pass: return TEXT("pass control");
			case Cand_Basin: return TEXT("hidden basin");
			case Cand_Armor: return TEXT("armor country");
			default: return TEXT("ground");
		}
	}

	/** S21-DEEP: POSSIBLE MISSION AREAS - the land's own proposal, best first.
	 *  Round-robin across the four tactical kinds (best overwatch, best pass,
	 *  deepest basin, the armour patch's centre, then each list's runner-up)
	 *  so one kind cannot crowd the others out; a candidate closer than
	 *  SepCells to one already picked is refused as redundant ground - the
	 *  pass at a peak's feet is the peak's story, not a second site.
	 *  Deterministic in kind order and rank. */
	static TArray<FTerrainCandidate> FindOperationalGround(const FHeightGrid& G,
		int32 MaxSites = 12, int32 SepCells = 3)
	{
		TArray<FTerrainCandidate> Out;
		if (!G.IsValid())
		{
			return Out;
		}
		TArray<TArray<FTerrainCandidate>> Pools;
		Pools.SetNum(Cand_Count);
		for (const FTerrainHighPoint& P : FindHighGround(G, 4))
		{
			FTerrainCandidate C;
			C.CellX = P.CellX;
			C.CellY = P.CellY;
			C.Z = P.Z;
			C.Kind = Cand_Overwatch;
			C.ScoreCells = ViewshedCells(G, P.CellX, P.CellY, 200.f);
			Pools[Cand_Overwatch].Add(C);
		}
		for (const FTerrainSaddle& S : FindPasses(G, 4))
		{
			if (S.ColProminenceCm <= 1.f)
			{
				continue;   // a plateau seam is not a way through
			}
			FTerrainCandidate C;
			C.CellX = S.CellX;
			C.CellY = S.CellY;
			C.Z = S.Z;
			C.Kind = Cand_Pass;
			C.ScoreCm = S.ColProminenceCm;
			Pools[Cand_Pass].Add(C);
		}
		for (const FTerrainDepression& D : FindDepressions(G, 4))
		{
			FTerrainCandidate C;
			C.CellX = D.CellX;
			C.CellY = D.CellY;
			C.Z = D.Z;
			C.Kind = Cand_Basin;
			C.ScoreCm = D.DepthCm;
			Pools[Cand_Basin].Add(C);
		}
		const FTerrainPatch Tanks = LargestFlatPatch(G, 0.10f);
		if (Tanks.CellCount > 0)
		{
			FTerrainCandidate C;
			C.CellX = static_cast<int32>(Tanks.CentroidX + 0.5f);
			C.CellY = static_cast<int32>(Tanks.CentroidY + 0.5f);
			const FHeightCell* CC = G.At(C.CellX, C.CellY);
			C.Z = CC ? CC->Z : G.MinZ;
			C.Kind = Cand_Armor;
			C.ScoreCells = Tanks.CellCount;
			Pools[Cand_Armor].Add(C);
		}
		auto TooClose = [&Out, SepCells](int32 X, int32 Y)
		{
			for (const FTerrainCandidate& C : Out)
			{
				const int32 DX = C.CellX - X, DY = C.CellY - Y;
				if (DX * DX + DY * DY < SepCells * SepCells)
				{
					return true;
				}
			}
			return false;
		};
		for (int32 Rank = 0; Out.Num() < MaxSites; ++Rank)
		{
			bool bAny = false;
			for (int32 Kind = 0; Kind < Cand_Count && Out.Num() < MaxSites; ++Kind)
			{
				if (Rank >= Pools[Kind].Num()) { continue; }
				bAny = true;
				const FTerrainCandidate& C = Pools[Kind][Rank];
				if (!TooClose(C.CellX, C.CellY))
				{
					Out.Add(C);
				}
			}
			if (!bAny)
			{
				break;   // every pool exhausted
			}
		}
		return Out;
	}
};

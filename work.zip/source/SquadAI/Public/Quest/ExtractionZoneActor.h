// ExtractionZoneActor.h - S19-EXFIL: the extraction / LZ objective.
//
// WHAT THIS IS
// ------------
// "Primary done - now get out." An LZ that arms when the mission's main job is
// finished (the mission zone calls `ArmExtraction`), or when the player calls it
// himself with a smoke grenade on the pad (`bArmOnSmokeGrenade`). While it is
// armed the player must HOLD the pad for `HoldSeconds`; the zone's spawners can
// re-fire during the hold (`HoldSpawners`), which is the whole point: exfil is
// the last wave, not a walk.
//
//   * it goes from dormant, to armed (the pad is lit), to holding, to ready,
//   * holding is continuous: walking out pauses the clock (and, if
//     `HoldProgressDecayRate` is set, slowly loses progress),
//   * progress is broadcast for the HUD, and `OnExtractionReady` is the gate an
//     AMissionZone with `bRequireExtraction` waits on,
//   * the pad is a plain, collisionless disc: it never blocks movement.
//
// Enemies do not "know" about the pad in this version - the pressure comes from
// the spawners it re-fires and from whatever is already hunting the player, which
// is how the shipped Defend missions work too.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "ExtractionZoneActor.generated.h"

class USceneComponent;
class UStaticMeshComponent;
class UMaterialInstanceDynamic;
class AEnemyWaveSpawner;

UENUM(BlueprintType)
enum class EExtractionState : uint8
{
	Dormant UMETA(DisplayName = "Dormant"),
	Active  UMETA(DisplayName = "Armed - get to the pad"),
	Holding UMETA(DisplayName = "Holding"),
	Ready   UMETA(DisplayName = "Ready to leave")
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnExtractionArmed, class AExtractionZoneActor*, Zone);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnExtractionHoldProgress, class AExtractionZoneActor*, Zone, float, Progress01);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnExtractionReady, class AExtractionZoneActor*, Zone);

UCLASS(BlueprintType, Blueprintable, ClassGroup = (SquadAI),
	meta = (DisplayName = "Extraction Zone / LZ"))
class SQUADAI_API AExtractionZoneActor : public AActor
{
	GENERATED_BODY()

public:
	AExtractionZoneActor();
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;

	// ===== CONFIG =====

	/** Call sign for the log and the HUD ("LZ Bravo", "Bridge exfil", ...). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Extraction")
	FText CallSign;

	/** The pad: the player must be inside this radius to hold (cm). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Extraction", meta = (ClampMin = "100.0"))
	float HoldRadiusCm = 900.f;

	/** Continuous seconds on the pad before the exfil is ready. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Extraction", meta = (ClampMin = "1.0"))
	float HoldSeconds = 45.f;

	/** Progress lost per second while the player is OFF the pad. 0 = the clock simply
	 *  pauses (default); 0.25 = a quarter of the hold is lost for each second away. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Extraction", meta = (ClampMin = "0.0"))
	float HoldProgressDecayRate = 0.f;

	/** The player can call his own exfil: a smoke grenade landing on the pad arms it. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Extraction")
	bool bArmOnSmokeGrenade = true;

	/** How close a smoke marker must land to count as "on the pad" (cm). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Extraction", meta = (ClampMin = "100.0"))
	float SmokeCallRadiusCm = 1600.f;

	/** Standalone use: armed from BeginPlay instead of by a mission zone. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Extraction")
	bool bStartArmed = false;

	/** Spawners that re-fire while the hold is running (the last wave). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Extraction|Pressure")
	TArray<TObjectPtr<AEnemyWaveSpawner>> HoldSpawners;

	/** Shut those spawners down once the exfil is ready. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Extraction|Pressure")
	bool bDeactivateSpawnersOnReady = true;

	// ===== STATE =====

	UPROPERTY(BlueprintReadOnly, Category = "Extraction|State")
	EExtractionState ExtractionState = EExtractionState::Dormant;

	/** 0..1 hold progress. */
	UPROPERTY(BlueprintReadOnly, Category = "Extraction|State")
	float HoldProgress01 = 0.f;

	/** Seconds still to hold (0 when dormant or ready). */
	UPROPERTY(BlueprintReadOnly, Category = "Extraction|State")
	float HoldRemainingSeconds = 0.f;

	// ===== EVENTS =====

	UPROPERTY(BlueprintAssignable, Category = "Extraction|Events")
	FOnExtractionArmed OnExtractionArmed;

	UPROPERTY(BlueprintAssignable, Category = "Extraction|Events")
	FOnExtractionHoldProgress OnExtractionHoldProgress;

	UPROPERTY(BlueprintAssignable, Category = "Extraction|Events")
	FOnExtractionReady OnExtractionReady;

	// ===== COMPONENTS =====

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Extraction|Components")
	TObjectPtr<USceneComponent> SceneRoot;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Extraction|Components")
	TObjectPtr<UStaticMeshComponent> PadDisc;

	// ===== API =====

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Extraction")
	bool IsExtractionReady() const { return ExtractionState == EExtractionState::Ready; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Extraction")
	bool IsArmed() const { return ExtractionState != EExtractionState::Dormant; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Extraction")
	float GetHoldProgress01() const { return HoldProgress01; }

	/** Arm the pad (the mission zone calls this when the primary objective is done). */
	UFUNCTION(BlueprintCallable, Category = "Extraction")
	void ArmExtraction();

	/** A smoke marker went off here: arm the pad if the call was close enough.
	 *  Called by the grenade when a smoke grenade detonates (see TacticalGrenadeActor). */
	UFUNCTION(BlueprintCallable, Category = "Extraction")
	void NotifySmokeMarker(const FVector& MarkerLocation);

	/** Debug / scripted: skip the hold entirely. */
	UFUNCTION(BlueprintCallable, Category = "Extraction")
	void ForceReady();

	/** Back to dormant with no progress - used when a failed mission retries. */
	UFUNCTION(BlueprintCallable, Category = "Extraction")
	void ResetExtraction();

protected:
	void SetState(EExtractionState NewState);

private:
	float HoldSecondsAccum = 0.f;
	float LastBroadcastProgress = -1.f;

	UPROPERTY(Transient)
	TObjectPtr<UMaterialInstanceDynamic> PadMID;

	void SetPadColor(const FLinearColor& C);
	void StartHoldPressure();
	void StopHoldPressure();
};

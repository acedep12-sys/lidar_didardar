// SpawnerTrigger.h — Trigger volume that activates linked enemy spawners
// Place this file in SquadAI/Public/Quest/
//
// Place in your map where you want the player to walk through.
// In the Spawner's settings, set LinkedTrigger to this trigger.
// When the player overlaps this trigger, the linked spawner activates.
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "SpawnerTrigger.generated.h"

class AEnemyWaveSpawner;
class UBoxComponent;
class UStaticMeshComponent;

UCLASS(BlueprintType, Blueprintable)
class SQUADAI_API ASpawnerTrigger : public AActor
{
	GENERATED_BODY()

public:
	ASpawnerTrigger();

	// ===== CONFIGURATION =====

	// Spawners to activate when the player enters this trigger.
	// You can link multiple spawners to one trigger.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trigger|Config")
	TArray<TObjectPtr<AEnemyWaveSpawner>> LinkedSpawners;

	// If true, this trigger can only be activated once
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trigger|Config")
	bool bOneShot = true;

	// If true, destroy this trigger actor after activation (only if bOneShot)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trigger|Config")
	bool bDestroyAfterActivation = false;

	// Optional: only trigger for specific team. 255 = any team.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trigger|Config")
	uint8 RequiredTeamId = 255;

	// ===== RUNTIME STATE =====

	UPROPERTY(BlueprintReadOnly, Category = "Trigger|State")
	bool bHasBeenActivated = false;

	UPROPERTY(BlueprintReadOnly, Category = "Trigger|State")
	int32 ActivationCount = 0;

	// ===== EVENTS =====

	DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnTriggerActivated, ASpawnerTrigger*, Trigger);

	UPROPERTY(BlueprintAssignable, Category = "Trigger|Events")
	FOnTriggerActivated OnTriggerActivated;

protected:
	virtual void BeginPlay() override;

	// Visual root for editor placement
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Trigger")
	TObjectPtr<USceneComponent> SceneRoot;

	// The trigger volume
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Trigger")
	TObjectPtr<UBoxComponent> TriggerVolume;

	// Visual mesh (optional, for editor visibility)
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Trigger")
	TObjectPtr<UStaticMeshComponent> VisualMesh;

	UFUNCTION()
	void OnOverlapBegin(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
		UPrimitiveComponent* OtherComp, int32 OtherBodyIndex,
		bool bFromSweep, const FHitResult& SweepResult);

private:
	bool ShouldTriggerForActor(AActor* Actor) const;
};

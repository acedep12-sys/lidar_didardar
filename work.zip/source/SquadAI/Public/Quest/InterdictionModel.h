// InterdictionModel.h - S19-INTERDICT
//
// The rules behind "nothing gets through": enemy couriers drive a route across the
// area one after another, and the mission is to stop a quota of them BEFORE they
// reach the far end. Stop too few and the objective fails; let too many escape and
// the mission fails - the double bar that makes interdiction a shooting problem
// (prioritise, do not chase the one already past you).
//
// The couriers themselves are actors that walk an AEnemyPatrolRoute - the SAME
// route actor the escort convoy walks and the patrollers use, so interdiction adds
// no new authoring surface. The model is the accounting: quotas, escapes,
// resolution.
//
// Engine-free: pure functions; compiled and pinned by tools/mission_test.

#pragma once

#include "CoreMinimal.h"

struct FInterdictionModel
{
	// -----------------------------------------------------------------------------------------
	//  the double bar
	// -----------------------------------------------------------------------------------------

	/** The objective bar: enough couriers stopped. Inclusive - the quota IS the goal. */
	static bool QuotaMet(int32 StoppedCount, int32 StopQuota)
	{
		return StopQuota > 0 && StoppedCount >= StopQuota;
	}

	/** The failure bar: too many got through. Reaching the limit IS the failure. */
	static bool EscapeLimitReached(int32 EscapedCount, int32 MaxEscapes)
	{
		return EscapedCount >= FMath::Max(1, MaxEscapes);
	}

	/** A courier leaving the field one way or the other (destroyed or walked off). */
	static bool AllCouriersResolved(int32 SpawnedCount, int32 StoppedCount, int32 EscapedCount)
	{
		return StoppedCount + EscapedCount >= FMath::Max(0, SpawnedCount);
	}

	// -----------------------------------------------------------------------------------------
	//  the spawn schedule
	// -----------------------------------------------------------------------------------------

	/**
	 * Seconds until the next courier leaves. `BaseIntervalSeconds` between launches,
	 * the first courier launched after `FirstDelaySeconds` (the player needs a moment
	 * to read the objective). Index is 0-based.
	 */
	static float NextSpawnDelay(int32 CourierIndex, float FirstDelaySeconds,
		float BaseIntervalSeconds)
	{
		if (CourierIndex <= 0)
		{
			return FMath::Max(0.f, FirstDelaySeconds);
		}
		return FMath::Max(0.5f, BaseIntervalSeconds);
	}

	/** The whole run is over once quota/escape resolved it OR the last courier resolved. */
	static bool RunIsOver(int32 StoppedCount, int32 EscapedCount, int32 TotalToSpawn,
		int32 StopQuota, int32 MaxEscapes)
	{
		if (QuotaMet(StoppedCount, StopQuota) || EscapeLimitReached(EscapedCount, MaxEscapes))
		{
			return true;
		}
		return AllCouriersResolved(TotalToSpawn, StoppedCount, EscapedCount);
	}

	/**
	 * The quota is still REACHABLE: not enough couriers remain (unspawned + rolling)
	 * to hit it. The director stops spawning the moment this flips - a dead run says
	 * so instead of dribbling trucks into a lost field.
	 */
	static bool QuotaStillReachable(int32 StoppedCount, int32 StopQuota,
		int32 CouriersLeftToBecome)
	{
		return StoppedCount + FMath::Max(0, CouriersLeftToBecome) >= StopQuota;
	}

	// -----------------------------------------------------------------------------------------
	//  readouts
	// -----------------------------------------------------------------------------------------

	/** "Stopped 2/3 - 1 escaped" style summary for the log and the card. */
	static FString SummaryLine(int32 StoppedCount, int32 StopQuota, int32 EscapedCount)
	{
		return FString::Printf(TEXT("Stopped %d/%d - %d escaped"), StoppedCount, StopQuota, EscapedCount);
	}

	/** The completion scoring weight: stopping MORE than the quota still pays off. */
	static int32 StoppingBonus(int32 StoppedCount, int32 StopQuota, int32 PointsPerExtraStop)
	{
		return FMath::Max(0, StoppedCount - StopQuota) * FMath::Max(0, PointsPerExtraStop);
	}
};

// SceneDecorator.h — Scatters effects and meshes across terrain
// Rebuild button spawns fire, debris, etc. around the actor's location.
// All spawning is D3D12-safe with delays and cull distances.
#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "SceneDecorator.generated.h"

class UNiagaraSystem;
class UNiagaraComponent;
class UStaticMesh;
class UStaticMeshComponent;
class USphereComponent;
class UParticleSystem;
class UParticleSystemComponent;
class UUserWidget;
class APawn;
class UDamageType;
class UActorComponent;
class UWorld;

UENUM(BlueprintType)
enum class EDecorationType : uint8
{
	NiagaraEffect,
	StaticMesh,
	Both
};

USTRUCT(BlueprintType)
struct FDecorationEntry
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Decoration")
	FName EntryName = TEXT("Fire");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Decoration")
	EDecorationType Type = EDecorationType::Both;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Decoration", meta = (EditCondition = "Type != EDecorationType::StaticMesh"))
	UNiagaraSystem* NiagaraEffect = nullptr;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Decoration", meta = (EditCondition = "Type != EDecorationType::StaticMesh"))
	UParticleSystem* CascadeEffect = nullptr;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Decoration", meta = (EditCondition = "Type != EDecorationType::NiagaraEffect"))
	UStaticMesh* GroundMesh = nullptr;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Decoration", meta = (ClampMin = "1"))
	int32 Count = 10;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Decoration", meta = (ClampMin = "50"))
	float MinSpacing = 500.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Decoration", meta = (ClampMin = "100"))
	float MaxRadius = 5000.f;

	// Random scale range
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Decoration")
	FVector MeshScaleMin = FVector(0.8f);
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Decoration")
	FVector MeshScaleMax = FVector(1.2f);

	// Rotation: if bRandomRotation=false, use FixedRotation
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Decoration")
	bool bRandomRotation = true;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Decoration", meta = (EditCondition = "!bRandomRotation"))
	FRotator FixedRotation = FRotator::ZeroRotator;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Decoration")
	float GroundOffset = 0.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Decoration")
	float MeshGroundOffset = -2.f;

	// Fire damage zone (player takes damage when standing in fire)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Decoration|Damage")
	bool bFireDamage = false;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Decoration|Damage", meta = (EditCondition = "bFireDamage"))
	float FireDamagePerSecond = 5.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Decoration|Damage", meta = (EditCondition = "bFireDamage"))
	float FireDamageRadius = 150.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Decoration|Performance")
	float NiagaraMaxDrawDistance = 15000.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Decoration|Performance")
	float MeshMaxDrawDistance = 20000.f;
};

UCLASS(BlueprintType, Blueprintable)
class SQUADAI_API ASceneDecorator : public AActor
{
	GENERATED_BODY()
public:
	ASceneDecorator();

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Decorator")
	TArray<FDecorationEntry> Decorations;

	// Click this in Details to scatter decorations NOW (editor + PIE).
	// Prefer the RebuildNow button below — the bool is kept for old workflows.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Decorator|Build")
	bool bRebuild = false;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Decorator|Build")
	bool bClearAll = false;

	// Actual buttons in the Details panel (Call In Editor)
	UFUNCTION(CallInEditor, BlueprintCallable, Category = "Decorator|Build")
	void RebuildNow();

	UFUNCTION(CallInEditor, BlueprintCallable, Category = "Decorator|Build")
	void ClearAllNow();

	// Dumps a full [SDDBG] snapshot to the Output Log. Filter the log with: SDDBG
	UFUNCTION(CallInEditor, BlueprintCallable, Category = "Decorator|Build")
	void DumpDebugNow();

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Decorator|Terrain")
	float GroundTraceUp = 2000.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Decorator|Terrain")
	float GroundTraceDown = 5000.f;

	// Delay between spawning each decoration (prevents GPU crash)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Decorator|Build", meta = (ClampMin = "0.0", ClampMax = "5.0"))
	float SpawnDelay = 0.1f;

	// P1-9: default OFF — previously every decoration became a fire hazard via the
	// actor||entry OR. Opt in per-entry (bFireDamage) or force all with this switch.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Decorator|Damage")
	bool bEnableFireDamage = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Decorator|Damage", meta = (ClampMin = "0.0"))
	float FireDamagePerSecond = 3.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Decorator|Damage", meta = (ClampMin = "50.0"))
	float FireDamageRadius = 180.f;

	// Red screen effect widget class (create a Widget Blueprint with red gradient)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Decorator|Damage")
	TSubclassOf<UUserWidget> BurnScreenEffectClass;

	// ===== RUNTIME =====
	UPROPERTY(BlueprintReadOnly, Category = "Decorator|State")
	int32 TotalSpawnedCount = 0;

	// O(fires) — no world actor scan. Used by AI pathing.
	static void CollectFireHazards(const UWorld* World, TArray<FVector>& OutLoc, TArray<float>& OutRadius);

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void Tick(float DeltaTime) override;
#if WITH_EDITOR
	virtual void PostEditChangeProperty(FPropertyChangedEvent& E) override;
#endif
private:
	UPROPERTY() TArray<TObjectPtr<AActor>> SpawnedActors;
	UPROPERTY() TArray<TObjectPtr<UNiagaraComponent>> SpawnedNiagaraComps;
	UPROPERTY() TArray<TObjectPtr<UParticleSystemComponent>> SpawnedCascadeComps;
	UPROPERTY() TArray<TObjectPtr<UStaticMeshComponent>> SpawnedMeshComps;
	UPROPERTY() TArray<TObjectPtr<USphereComponent>> SpawnedDamageSpheres;
	// P1-9: per-box DPS (parallel to SpawnedDamageSpheres; actor DPS is the fallback).
	UPROPERTY() TMap<TObjectPtr<USphereComponent>, float> FireDPSBySphere;

	void BuildAllDecorations();
	void ClearAllDecorations();
	void BuildDecoration(const FDecorationEntry& Entry);
	FVector FindGroundLocation(const FVector& Origin) const;
	FVector GetRandomPointInRadius(const FVector& Center, float Radius) const;
	bool IsFarEnough(const FVector& NewPoint, const TArray<FVector>& Placed, float MinDist) const;
	void SpawnFireDamageZone(const FVector& Location, float Radius, float DamagePerSecond);
	USphereComponent* SpawnFireHurtBox(const FVector& WorldLoc, float Radius, float DamagePerSecond);
	void EnsureFireHurtBoxes();
	void BindFireHurtBoxes();
	void PollFireDamage();
	void ApplyFireDamageToActor(AActor* Target, float Damage);
	void ShowBurnEffect();
	void HideBurnEffect();
	APawn* FindPlayerPawn() const;
	UActorComponent* FindPackHealthComp(AActor* Target) const;
	void SetPackBurning(AActor* Target, bool bBurning);
	// S5-8c: burn overlay/status is now reference counting (the enter/exit booleans from
	// overlapping fires were racing each other): first-enter shows, last-exit hides.
	void EnterBurnVisualState(AActor* Player);
	void LeaveBurnVisualState(AActor* Player);
	TSubclassOf<UDamageType> ResolveFireDamageType(UActorComponent* Health) const;
	int32 CallNamedDamageFunctions(UObject* Obj, float Damage);
	bool CallPackFunction(UObject* Obj, FName FuncName, AActor* Target, float Damage, double HealthNow, double MaxHealth, bool bBoolArg);
	void NotifyPackHealthUI(UActorComponent* Health, AActor* Target, float Damage);
	void BroadcastZeroParam(UObject* Obj, FName DelegateName);
	double ReadPackDouble(UObject* Obj, const TCHAR* PropName) const;
	void DumpDebugSnapshot(const TCHAR* Reason);
	void DumpPlayerProbe(AActor* Player);
	FRotator MakeDecorationRotation(const FDecorationEntry& Entry) const;
	void ApplyWorldTM(USceneComponent* Comp, const FVector& WorldLoc, const FRotator& WorldRot, const FVector& Scale);
	UNiagaraComponent* SpawnNiagaraAttached(UNiagaraSystem* System, const FVector& WorldLoc, const FRotator& WorldRot, float CullDistance);
	UParticleSystemComponent* SpawnCascadeAttached(UParticleSystem* Template, const FVector& WorldLoc, const FRotator& WorldRot, float CullDistance);
	UStaticMeshComponent* SpawnMeshAttached(UStaticMesh* Mesh, const FVector& WorldLoc, const FRotator& WorldRot, const FVector& Scale, float CullDistance);

	TArray<FTimerHandle> DeferredBuildHandles;
	FTimerHandle FirePollHandle;
	bool bIsRebuilding = false;
	bool bPlayerInFire = false;
	float FireDamageAccrue = 0.f;
	float LastPollTime = -1.f;
	float LastFireDebugLog = -1.f;
	bool bLoggedPlayerProbe = false;
	int32 DebugPollCount = 0;

	UPROPERTY() TObjectPtr<UUserWidget> ActiveBurnEffect;
	UPROPERTY() TSubclassOf<UDamageType> CachedFireDamageType;
	UPROPERTY() TWeakObjectPtr<UActorComponent> CachedPackHealthComp;
	bool bResolvedFireDamageType = false;
};

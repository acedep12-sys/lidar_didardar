// MissionTemplateAsset.h - S19-TEMPLATE: one asset = one mission.
//
// WHAT THIS IS
// ------------
// The authoring half of the mission system. Until now a mission existed only as
// flags scattered across an AMissionZone actor plus whatever spawners and props
// a designer had placed by hand: nothing could be saved, shared, stamped or
// randomised. This asset is that missing unit.
//
// Fill it in once (identity, base type, waves, the modifier groups from the last
// four rounds, the clock), then press the auto-setup manager's
// **"Build Mission From Template"** button: the factory stamps a complete
// mission into the level - the zone, its wave spawner, an optional fortification,
// explosive barrels, and every prop group the template asks for (convoy + route,
// intel sites, an extraction pad, supply crates, demolition targets), all wired
// to the zone it just created.
//
// The template never references level actors: everything it needs is a number, a
// class or a toggle, so the same asset can stamp the same mission into any map.
//
// What it deliberately does NOT do: it does not touch lighting, post-process,
// the camera or the level's existing actors. It only creates actors and writes
// their own fields.

#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "Quest/MissionZone.h"                        // EMissionType
#include "Actors/QuickFortificationSpawnerActor.h"    // EFortificationPreset
#include "MissionTemplateAsset.generated.h"

class APawn;
class ASoldierCharacter;

UCLASS(BlueprintType, meta = (DisplayName = "SquadAI Mission Template"))
class SQUADAI_API UMissionTemplateAsset : public UPrimaryDataAsset
{
	GENERATED_BODY()

public:
	// =========================================================================
	//  IDENTITY - what the player sees
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Identity")
	FText MissionName;

	/** The zone's Mission Description (also becomes the encounter's name). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Identity", meta = (MultiLine = "true"))
	FText MissionDescription;

	/** Badge text override, e.g. a Persian name instead of "CLEAR". */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Identity")
	FText CustomBadgeText;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Title Card")
	FText TitleCardPlace;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Title Card")
	FText TitleCardDate;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Title Card")
	FText TitleCardUnit;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Briefing")
	FText BriefingTitle;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Briefing", meta = (MultiLine = "true"))
	FText BriefingText;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Briefing", meta = (ClampMin = "4.0"))
	float BriefingDuration = 12.f;

	// =========================================================================
	//  BASE - the three mission types and their own settings
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Base")
	EMissionType MissionType = EMissionType::Clear;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Base",
		meta = (EditCondition = "MissionType == EMissionType::Defend", ClampMin = "1.0"))
	float DefendDuration = 90.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Base",
		meta = (EditCondition = "MissionType == EMissionType::Defend", ClampMin = "0.5"))
	float DefendWaveInterval = 15.f;

	/** S17-HOLD: enemies holding the zone for the grace time fail the defence. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Base",
		meta = (EditCondition = "MissionType == EMissionType::Defend"))
	bool bFailIfOverrun = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Base",
		meta = (EditCondition = "bFailIfOverrun && MissionType == EMissionType::Defend", ClampMin = "200.0"))
	float OverrunRadius = 1400.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Base",
		meta = (EditCondition = "bFailIfOverrun && MissionType == EMissionType::Defend", ClampMin = "1"))
	int32 OverrunEnemyCount = 3;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Base",
		meta = (EditCondition = "bFailIfOverrun && MissionType == EMissionType::Defend", ClampMin = "2.0"))
	float OverrunGraceTime = 12.f;

	/** S17-CNTR: one counterattack on this zone after it completes. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Base")
	bool bCounterattackAfterComplete = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Base",
		meta = (EditCondition = "bCounterattackAfterComplete", ClampMin = "3.0"))
	float CounterattackDelay = 25.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Base",
		meta = (EditCondition = "bCounterattackAfterComplete", ClampMin = "5.0"))
	float CounterattackDuration = 45.f;

	// =========================================================================
	//  CLOCK (S19-CLOCK)
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Clock", meta = (ClampMin = "0.0"))
	float TimeLimitSeconds = 0.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Clock",
		meta = (EditCondition = "TimeLimitSeconds > 0.0"))
	bool bFailOnTimeExpiry = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Clock",
		meta = (EditCondition = "TimeLimitSeconds > 0.0", ClampMin = "0.01", ClampMax = "1.0"))
	float TimeLimitWarnFraction = 0.25f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Clock", meta = (ClampMin = "0.0"))
	float ParTimeSeconds = 0.f;

	// =========================================================================
	//  ENEMY - the wave spawner the factory creates
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Enemy")
	TSubclassOf<APawn> EnemyClass;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Enemy", meta = (ClampMin = "0"))
	int32 TotalWaves = 2;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Enemy", meta = (ClampMin = "1"))
	int32 EnemiesPerWave = 4;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Enemy", meta = (ClampMin = "0.1"))
	float WaveIntervalSeconds = 8.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Enemy", meta = (ClampMin = "0.1"))
	float SpawnIntervalSeconds = 1.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Enemy", meta = (ClampMin = "0.0"))
	float SpawnRadiusCm = 4500.f;

	/** Defend zones want the waves to keep coming until the timer runs out. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Enemy")
	bool bLoopWaves = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Enemy", meta = (ClampMin = "0"))
	int32 MaxAliveEnemies = 15;

	/** S19-ELITE: a commander joins the final wave, with his assistants. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Enemy|Elite")
	bool bEliteCommander = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Enemy|Elite",
		meta = (EditCondition = "bEliteCommander", ClampMin = "0", ClampMax = "6"))
	int32 AssistantsPerCommander = 2;

	// =========================================================================
	//  MODIFIERS - the four new creators plus the prop-based ones
	//  (counts of 0 mean "not part of this mission")
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Modifiers|Intel", meta = (ClampMin = "0"))
	int32 IntelSiteCount = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Modifiers|Supply", meta = (ClampMin = "0"))
	int32 SupplyCrateCount = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Modifiers|Sabotage", meta = (ClampMin = "0"))
	int32 SabotageTargetCount = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Modifiers|POW", meta = (ClampMin = "0"))
	int32 POWCaptiveCount = 0;

	/** Required for captives: the class the factory spawns them from (e.g. your Ally BP). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Modifiers|POW")
	TSubclassOf<ASoldierCharacter> POWClass;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Modifiers|POW",
		meta = (EditCondition = "POWCaptiveCount > 0"))
	bool bPOWsFollowPlayer = true;

	/** S19-ESCORT: the factory spawns the convoy AND its route (see the route settings). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Modifiers|Escort")
	bool bEscort = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Modifiers|Escort",
		meta = (EditCondition = "bEscort", ClampMin = "2"))
	int32 EscortRouteLegs = 4;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Modifiers|Escort",
		meta = (EditCondition = "bEscort", ClampMin = "500.0"))
	float EscortRouteLegLengthCm = 5000.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Modifiers|Escort",
		meta = (EditCondition = "bEscort"))
	float EscortRouteStartYawDeg = 0.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Modifiers|Escort",
		meta = (EditCondition = "bEscort"))
	bool bRequireEscortArrival = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Modifiers|Escort",
		meta = (EditCondition = "bEscort"))
	bool bFailIfEscortDies = true;

	/** S19-EXFIL: the factory spawns an extraction pad offset from the zone. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Modifiers|Extraction")
	bool bExtraction = false;

	// S26-EXFILFIX: default OFF - only templates that configure a pad (the river finale)
	// may require it. The old default true made the factory refuse every template
	// without an extraction pad (26 of 27 acts on the first stamping press).
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Modifiers|Extraction",
		meta = (EditCondition = "bExtraction"))
	bool bRequireExtraction = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Modifiers|Extraction",
		meta = (EditCondition = "bExtraction", ClampMin = "0.0"))
	float ExtractionOffsetCm = 2500.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Modifiers|Extraction",
		meta = (EditCondition = "bExtraction", ClampMin = "1.0"))
	float ExtractionHoldSeconds = 45.f;

	// =========================================================================
	//  MODIFIERS (batch 4) - capture points, the defended asset, interdiction
	// =========================================================================

	/** S19-CAP: capture-and-hold flags on the prop ring; every one must be HELD. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Modifiers|Capture", meta = (ClampMin = "0"))
	int32 CapturePointCount = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Modifiers|Capture",
		meta = (EditCondition = "CapturePointCount > 0", ClampMin = "0.0"))
	float CaptureHoldSeconds = 10.f;

	/** S19-ASSET: a friendly asset the mission protects (spawns on the ring). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Modifiers|Asset")
	bool bDefendedAsset = false;

	/** S19-INTERDICT: couriers drive a route through the area; stop the quota. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Modifiers|Interdiction")
	bool bInterdiction = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Modifiers|Interdiction",
		meta = (EditCondition = "bInterdiction", ClampMin = "1", ClampMax = "12"))
	int32 InterdictionCourierCount = 4;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Modifiers|Interdiction",
		meta = (EditCondition = "bInterdiction", ClampMin = "1"))
	int32 InterdictionStopQuota = 2;

	// =========================================================================
	//  DEPLOYMENT - where the props and the scenery go
	// =========================================================================

	/** The ring every prop group is placed on, around the zone centre (cm). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Deployment", meta = (ClampMin = "300.0"))
	float PropRingRadiusCm = 1800.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Deployment")
	float PropRingStartAngleDeg = 0.f;

	/** 360 = a full circle; less spreads the props across that arc only. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Deployment", meta = (ClampMin = "10.0"))
	float PropRingArcDeg = 360.f;

	/** Spawn a Quick Fortification Builder at the zone (sandbags, cover, a firing line). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Deployment")
	bool bSpawnFortification = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Deployment",
		meta = (EditCondition = "bSpawnFortification"))
	EFortificationPreset FortificationPreset = EFortificationPreset::SandbagBunker;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Deployment", meta = (ClampMin = "0"))
	int32 ExplosiveBarrels = 0;

	/** Append the new zone to the level's Quest Chain (the first one found) and activate it. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission|Deployment")
	bool bAppendToQuestChain = true;

	// =========================================================================
	//  READOUTS (used by the factory and the editor button)
	// =========================================================================

	/** The archetype this template's own settings imply (see MissionArchetypeModel.h). */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Mission|Template")
	EMissionType GetBaseType() const { return MissionType; }

	/** Total enemies this template will put on the field, for the log line. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Mission|Template")
	int32 GetPlannedEnemyCount() const { return FMath::Max(0, TotalWaves) * FMath::Max(1, EnemiesPerWave); }
};

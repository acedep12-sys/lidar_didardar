// InterdictionCourierActor.h - S19-INTERDICT
//
// One enemy courier: a vehicle-like actor that walks an AEnemyPatrolRoute (the same
// route actor the escort convoy walks) from its start to its far end. Destroy it
// before the last point and it counts as STOPPED; let it reach the end and it has
// ESCAPED. The director (InterdictionDirectorActor.h) spawns them on a schedule and
// keeps the double-bar score; the rules are in Quest/InterdictionModel.h.
//
// It is an actor, not a possessed pawn, on purpose: no AI brain to spawn or manage,
// the same swept-walk pattern as the convoy, and the player shoots it like anything
// with a health component.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "InterdictionCourierActor.generated.h"

class AEnemyPatrolRoute;
class UHealthComponent;
class UStaticMeshComponent;
class UMaterialInstanceDynamic;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnCourierStopped, AInterdictionCourierActor*, Courier);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnCourierEscaped, AInterdictionCourierActor*, Courier);

UCLASS(BlueprintType)
class SQUADAI_API AInterdictionCourierActor : public AActor
{
	GENERATED_BODY()

public:
	AInterdictionCourierActor();

	virtual void Tick(float DeltaTime) override;

	// ===== CONFIG =====

	/** The route to drive. The LAST point is the escape edge. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Courier")
	TObjectPtr<AEnemyPatrolRoute> Route;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Courier", meta = (ClampMin = "50.0"))
	float MoveSpeedCmPerSec = 700.f;

	// ===== EVENTS =====

	/** Destroyed (health gone) before finishing the route. */
	UPROPERTY(BlueprintAssignable, Category = "Courier")
	FOnCourierStopped OnStopped;

	/** Reached the last point - it got through. */
	UPROPERTY(BlueprintAssignable, Category = "Courier")
	FOnCourierEscaped OnEscaped;

	// ===== API =====

	/** Re-read and re-ground the route's points (called by the director after spawning). */
	void RefreshRoute();

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Courier")
	bool WasStopped() const { return bStopped; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Courier")
	bool HasEscaped() const { return bEscaped; }

	/** Progress along the route, 0..1. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Courier")
	float GetRouteProgress01() const;

protected:
	virtual void BeginPlay() override;

	UPROPERTY(VisibleAnywhere, Category = "Courier")
	TObjectPtr<USceneComponent> SceneRoot;

	UPROPERTY(VisibleAnywhere, Category = "Courier")
	TObjectPtr<UStaticMeshComponent> BodyMesh;

	UPROPERTY(VisibleAnywhere, Category = "Courier")
	TObjectPtr<UHealthComponent> HealthComp;

private:
	TArray<FVector> CachedPoints;
	int32 CurrentPointIndex = 0;
	bool bStopped = false;
	bool bEscaped = false;
	bool bRouteWarned = false;
	bool bDeathBound = false;

	UPROPERTY(Transient)
	TObjectPtr<UMaterialInstanceDynamic> MeshMID;

	UFUNCTION()
	void HandleHealthDied(AActor* OwnerActor);
};

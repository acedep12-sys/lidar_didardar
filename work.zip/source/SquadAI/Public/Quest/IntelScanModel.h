// IntelScanModel.h - S19-INTEL
//
// The rule behind "get the intelligence": stand at a site and scan it, then the
// set transmits on its own and reports.
//
// Why it lives in a model header
// ------------------------------
// The demolition charge (ASabotageTargetActor) already had the proximity-hold
// machinery, but it is welded to "blow it up": plant, fuse, damage, and the
// zone gate reads `IsDetonated()`. Recon needed the same hold WITHOUT the
// explosion and with a second phase (the beacon transmits, then reports), and
// rather than copy the actor's inline arithmetic a second time the numbers
// moved here, where both can be driven by a harness:
//
//   * scanning only advances while the player is close, and (optionally)
//     decays at 1.5x when he walks away - that ratio is the sabotage actor's
//     shipped feel, kept so the two interactions read the same in the hand,
//   * the decay must never go below zero or above the target time, so a frame
//     hitch can neither bank progress nor lose a finished scan,
//   * "planted" is a completed-progress test, not a separate bool, so the actor
//     cannot desync from its own progress bar,
//   * transmitting is wall-clock and unconditional (unless the caller requires
//     the player to stay), i.e. the beacon finishes on its own - the tension is
//     that the player has somewhere else to be.
//
// Engine-free on purpose: compiled and exercised by tools/mission_test.

#pragma once

#include "CoreMinimal.h"

struct FIntelScanModel
{
	/** The sabotage actor's observed decay speed, shared so both feel identical. */
	static constexpr float DecayRate = 1.5f;

	/** Progress gained in one frame while the player is in range. */
	static float AdvanceProgress(float Progress, float DeltaTime, float ScanTime, bool bInRange)
	{
		const float Target = (ScanTime > 0.0001f) ? ScanTime : 0.0001f;
		if (bInRange)
		{
			return FMath::Clamp(Progress + FMath::Max(0.f, DeltaTime), 0.f, Target);
		}
		return FMath::Max(0.f, Progress - FMath::Max(0.f, DeltaTime) * DecayRate);
	}

	/** Progress lost in one frame while the player is away (for a HUD/decay read). */
	static float DecayProgress(float Progress, float DeltaTime)
	{
		return FMath::Max(0.f, Progress - FMath::Max(0.f, DeltaTime) * DecayRate);
	}

	/** The scan is done - and this is the ONLY source of truth for "planted". */
	static bool IsPlanted(float Progress, float ScanTime)
	{
		return Progress >= ((ScanTime > 0.0001f) ? ScanTime : 0.0001f);
	}

	/** Scanned fraction for the progress broadcast, clamped to [0, 1]. */
	static float Progress01(float Progress, float ScanTime)
	{
		const float Divisor = (ScanTime > 0.0001f) ? ScanTime : 0.0001f;
		return FMath::Clamp(Progress / Divisor, 0.f, 1.f);
	}

	/** Transmit progress, in seconds, while the beacon runs. */
	static float AdvanceTransmit(float TransmitElapsed, float DeltaTime, bool bTransmitting)
	{
		return bTransmitting ? FMath::Max(0.f, TransmitElapsed + FMath::Max(0.f, DeltaTime))
			: FMath::Max(0.f, TransmitElapsed);
	}

	/** The set has finished reporting: the zone gate opens on this. */
	static bool IsReported(float TransmitElapsed, float TransmitTime)
	{
		return TransmitElapsed >= FMath::Max(0.f, TransmitTime);
	}
};

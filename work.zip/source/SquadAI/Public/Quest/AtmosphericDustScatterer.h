#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "AtmosphericDustScatterer.generated.h"

class UNiagaraSystem;
class UNiagaraComponent;
class UMaterialInterface;

USTRUCT(BlueprintType)
struct FDustZone
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Dust")
	FVector Center = FVector::ZeroVector;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Dust")
	float Radius = 3000.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Dust")
	int32 ParticleCount = 2;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Dust")
	float ParticleScale = 1.f;
};

/**
 * AAtmosphericDustScatterer
 * High-performance, player-proximal atmospheric dust scatterer for massive open world maps.
 * 
 * Performance Architecture:
 * - Operates strictly within a tight sphere around the player (ActivationRadius).
 * - Distant fog/haze is left for manual world placement; this scatterer focuses 100% on local immersion.
 * - Uses squared distance checks (no sqrt), throttled async-like batching, and pooling.
 * - Automatically streams Slot #3 (ambient thin moving line) and Slot #14 (ditch windy pocket dust).
 * - Hard GPU budget caps ensure zero frame drops on massive 8 km World Partition maps.
 */
UCLASS(BlueprintType, Blueprintable, meta = (DisplayName = "Atmospheric Dust Scatterer (Optimized)"))
class SQUADAI_API AAtmosphericDustScatterer : public AActor
{
	GENERATED_BODY()

public:
	AAtmosphericDustScatterer();

	// =========================================================================
	// 1. LOCAL AMBIENT DUST (Slot #3 — Thin moving line / ground haze)
	// =========================================================================

	/** Niagara system for lightweight ambient dust particles around the player */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "1. Ambient Dust (Slot 3)")
	TObjectPtr<UNiagaraSystem> DustEffect = nullptr;

	/** Optional Volume Material for Slot #3 (if using VDB / Heterogeneous Volume) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "1. Ambient Dust (Slot 3)")
	TObjectPtr<UMaterialInterface> AmbientVolumeMaterial = nullptr;

	/** Optional custom Actor class for Slot #3 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "1. Ambient Dust (Slot 3)")
	TSubclassOf<AActor> AmbientVolumeActorClass = nullptr;

	/** Visual scale for ambient dust */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "1. Ambient Dust (Slot 3)")
	float AmbientScale = 1.0f;

	/** Distance from player where dust starts spawning (cm) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "1. Ambient Dust (Slot 3)", meta = (ClampMin = "500", ClampMax = "10000"))
	float ActivationRadius = 3000.f;

	/** Maximum active Niagara particles near player at any given moment */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "1. Ambient Dust (Slot 3)", meta = (ClampMin = "1", ClampMax = "30"))
	int32 MaxActiveParticles = 10;

	/** Maximum active Heterogeneous Volume actors near player (strictly budgeted for GPU) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "1. Ambient Dust (Slot 3)", meta = (ClampMin = "0", ClampMax = "3"))
	int32 MaxActiveAmbientVolumes = 1;


	// =========================================================================
	// 2. DITCH & LOW-GROUND DUST (Slot #14 — Hanging windy dust pocket)
	// =========================================================================

	/** Enable automatic placement of thick windy dust inside dry irrigation ditches & berms */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "2. Ditch / Low-Ground Dust (Slot 14)")
	bool bEnableDitchDust = true;

	/** Volume Material for Slot #14 (thick windy pocket dust) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "2. Ditch / Low-Ground Dust (Slot 14)")
	TObjectPtr<UMaterialInterface> DitchVolumeMaterial = nullptr;

	/** Optional custom Actor class for Slot #14 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "2. Ditch / Low-Ground Dust (Slot 14)")
	TSubclassOf<AActor> DitchVolumeActorClass = nullptr;

	/** Visual scale for ditch volumes */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "2. Ditch / Low-Ground Dust (Slot 14)")
	float DitchVolumeScale = 1.2f;

	/** S6-D: seeded per-volume scale/rotation variation so repeated fog slabs stop reading as one sheet */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "2. Ditch / Low-Ground Dust (Slot 14)")
	bool bDitchVariation = true;

	/** S6-D: seed for the variation above (per-volume seeds derive from position xor this value — stable across cull/respawn) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "2. Ditch / Low-Ground Dust (Slot 14)")
	int32 DitchVariationSeed = 77;

	/** Maximum concurrent active ditch volumes near player */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "2. Ditch / Low-Ground Dust (Slot 14)", meta = (ClampMin = "0", ClampMax = "4"))
	int32 MaxActiveDitchVolumes = 2;

	/** Height difference threshold (cm) to classify a ground point as a ditch/trench */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "2. Ditch / Low-Ground Dust (Slot 14)", meta = (ClampMin = "40"))
	float DitchDepthThreshold = 100.f;

	/** Specific ditch locations along the path (auto-populated or manually set) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "2. Ditch / Low-Ground Dust (Slot 14)")
	TArray<FVector> ManualDitchLocations;


	// =========================================================================
	// 3. PERFORMANCE & STREAMING CONFIGURATION
	// =========================================================================

	/** Number of dynamic anchor zones around the actor / path */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Performance & Generation", meta = (ClampMin = "1", ClampMax = "100"))
	int32 AutoZoneCount = 15;

	/** Radius covered by auto zones (cm) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Performance & Generation", meta = (ClampMin = "500"))
	float AutoZoneRadius = 2500.f;

	/** Manual zone definitions */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Performance & Generation")
	TArray<FDustZone> ManualZones;

	/** Interval between proximity streaming checks (seconds) — keeps CPU tick cost at near 0 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Performance & Generation", meta = (ClampMin = "0.2", ClampMax = "2.0"))
	float UpdateInterval = 0.5f;

	/** Rebuild all zones and force-refresh */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Performance & Generation")
	bool bRebuildZones = false;

	UFUNCTION(CallInEditor, BlueprintCallable, Category = "Performance & Generation")
	void RebuildAll();

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void Tick(float DeltaTime) override;

#if WITH_EDITOR
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
#endif

private:
	UPROPERTY()
	TArray<TObjectPtr<UNiagaraComponent>> ActiveParticles;

	UPROPERTY()
	TArray<TObjectPtr<AActor>> ActiveAmbientVolumes;

	UPROPERTY()
	TArray<TObjectPtr<AActor>> ActiveDitchVolumes;

	TArray<FVector> ZoneCenters;
	TArray<FVector> DetectedDitchCenters;
	float UpdateTimer = 0.f;
	int32 ZonesBuilt = 0;
	bool bBuilding = false;

	void StartZoneBuild();
	void BuildNextZoneBatch();
	void UpdateStreaming();
	void UpdateNiagaraParticles(const FVector& PlayerLoc, float ActivationRadiusSq);
	void UpdateAmbientVolumes(const FVector& PlayerLoc, float ActivationRadiusSq);
	void UpdateDitchVolumes(const FVector& PlayerLoc, float ActivationRadiusSq);
	void CleanupAllSpawned();

	AActor* SpawnVolumeInstance(TSubclassOf<AActor> ActorClass, UMaterialInterface* Material, const FVector& Location, const FVector& Scale3D, const FRotator& Rotation);
	void ApplyMaterialToActor(AActor* TargetActor, UMaterialInterface* Material);
	UClass* ResolveDefaultHeterogeneousVolumeClass() const;

	FVector GetRandomPointInZone(const FVector& Center, float Radius) const;
	bool CheckIfPointIsInDitch(const FVector& Location, float& OutDepth) const;
};

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "SandstormWeatherDirector.generated.h"

class UNiagaraSystem;
class UNiagaraComponent;
class USoundBase;
class UAudioComponent;

UENUM(BlueprintType)
enum class EWeatherStormPhase : uint8
{
	Clear,              // Bright arid sunshine
	ApproachingDust,    // Dust devils and horizon darkening
	FullHaboob,         // Severe red/orange sandstorm (low visibility, close quarters)
	Dissipating         // Storm blowing away, returning to clear
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnWeatherPhaseChanged, EWeatherStormPhase, NewPhase);

/**
 * ASandstormWeatherDirector
 * Dynamic Khuzestan Desert Sandstorm & Haboob Weather Director.
 * Modulates atmospheric fog, wind audio, and AI visibility ranges in real time.
 */
UCLASS(BlueprintType, Blueprintable, meta = (DisplayName = "Sandstorm Weather Director"))
class SQUADAI_API ASandstormWeatherDirector : public AActor
{
	GENERATED_BODY()

public:
	ASandstormWeatherDirector();

	// =========================================================================
	//  STORM CONFIGURATION
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weather|Control")
	bool bAutoCycleStorms = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weather|Control", meta = (ClampMin = "30.0"))
	float MinClearDuration = 120.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weather|Control", meta = (ClampMin = "30.0"))
	float MaxClearDuration = 300.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weather|Control", meta = (ClampMin = "20.0"))
	float StormDuration = 60.f;

	/** Multiplier applied to AI sight perception during a full sandstorm (0.35 = 35% normal range) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weather|Combat Impact", meta = (ClampMin = "0.1", ClampMax = "1.0"))
	float StormAIVisibilityMultiplier = 0.35f;

	/** Heavy howling sandstorm wind audio */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weather|Audio")
	TObjectPtr<USoundBase> SandstormHowlSound;

	/**
	 * S18-FOGFIX: start the howl at level load, silent, and never stop it — only
	 * its volume is animated. Spawning it when the storm arrives forced a
	 * synchronous decode on the audio thread, which is the audio hiccup.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weather|Audio")
	bool bPersistentStormAudio = true;

	/**
	 * S18-FOGFIX: fire one silent ApproachingDust pulse during level start so the
	 * fog/dust Niagara systems, their materials and PSOs are created behind the
	 * loading veil instead of on the first real storm (the frame hitch).
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weather|Control")
	bool bPrewarmStormFX = true;

	/** How long the silent prewarm pulse lasts, seconds. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weather|Control", meta = (ClampMin = "0.1", ClampMax = "5.0"))
	float PrewarmSeconds = 1.25f;

	/**
	 * S18-FOGFIX: seconds the intensity ramp takes. The old FInterpTo speed of
	 * 0.25 reached full haboob in ~12 s regardless of phase length; a slower,
	 * explicitly timed ramp spreads the volumetric-fog cost over more frames.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weather|Control", meta = (ClampMin = "1.0"))
	float IntensityRampSeconds = 9.f;

	UPROPERTY(BlueprintReadOnly, Category = "Weather|State")
	EWeatherStormPhase CurrentPhase = EWeatherStormPhase::Clear;

	UPROPERTY(BlueprintReadOnly, Category = "Weather|State")
	float StormIntensity = 0.0f;

private:
	/** S18-FOGFIX: true while the silent startup prewarm pulse is running. */
	bool bPrewarmActive = false;
	float PrewarmTimer = 0.f;
public:

	UFUNCTION(BlueprintCallable, Category = "Weather")
	void TriggerSandstorm(float Duration = 60.f);

	UFUNCTION(BlueprintCallable, Category = "Weather")
	void StopSandstorm();

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Weather")
	float GetCurrentAIVisibilityMultiplier() const;

	UPROPERTY(BlueprintAssignable, Category = "Weather|Events")
	FOnWeatherPhaseChanged OnWeatherPhaseChanged;

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void Tick(float DeltaTime) override;

private:
	float PhaseTimer = 0.f;
	float TargetIntensity = 0.f;

	UPROPERTY()
	TObjectPtr<UAudioComponent> StormAudioComp;

	void AdvancePhase();
	void SetPhase(EWeatherStormPhase NewPhase);
	void UpdateStormAudio(float DeltaTime);
};

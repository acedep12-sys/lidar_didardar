// WarWorksModel.h - S25-WARWORKS
//
// THE MANAGER BUILDS THE WAR, NOT JUST THE MISSIONS. The scatter already puts
// the acts, their wave spawners and their guard posts on the land; this model
// adds the GEOGRAPHY OF THE WAR around them: the enemy's bridges over the
// water (and ours, where their towers cannot see), the watchtowers on their
// ranked hills (each facing its deadliest cone), our outposts on our own high
// ground facing them, and the armor - staging on the tank country, hulls at
// its rim with ground in front of the gun, and the burnt-out hulks of the
// last push. The march table's "net" and the towers are the SAME hills: when
// a tower falls in play, the net arithmetic literally thins.
//
// All placements derive from the terrain grid the scatter already builds -
// nothing is hand-placed, nothing is random, the same map gives the same war.
// Engine-free (grids and cells only), pinned by tools/map_test.
//
// Facing convention: UE yaw in degrees - 0 = +X (east on the map's compass
// convention, north = +Y), increasing toward +Y. The caller can hand it to
// FRotator(0, FacingYawDeg, 0) unchanged.

#pragma once

#include "CoreMinimal.h"
#include "Quest/TerrainStructureModel.h"

/** One placed piece of the war. */
struct FWarWorkPoint
{
	int32 CellX = 0;
	int32 CellY = 0;
	float FacingYawDeg = 0.f;   // UE yaw: 0 = +X, toward +Y at 90
	float WidthCm = 0.f;        // bridges: the channel width the deck must span
	FString Note;               // the one-line "why", deterministic, for the report
};

/** The whole war's geography, in grid cells. */
struct FWarWorksPlan
{
	TArray<FWarWorkPoint> BridgesTheirs;   // the crossings they hold
	TArray<FWarWorkPoint> BridgesOurs;     // engineer bridges, built where their towers are blind
	TArray<FWarWorkPoint> Towers;          // watchtowers on the net hills, facing their cone
	TArray<FWarWorkPoint> Outposts;        // our fortified high ground, facing them
	TArray<FWarWorkPoint> Staging;        // the armor staging spawns on the tank country
	TArray<FWarWorkPoint> Hulls;           // armor, hull-down at the tank country rim
	TArray<FWarWorkPoint> DeadHulks;       // the burnt-out evidence of the last push
};

struct FWarWorksModel
{
	/** UE yaw for a direction, in degrees. */
	static float BearingYawDeg(double DX, double DY)
	{
		return (float)FMath::Atan2(DY, DX) * (180.f / PI);
	}

	/** Distance in cells between two points. */
	static double CellDist(const FWarWorkPoint& A, int32 BX, int32 BY)
	{
		const double DX = (double)A.CellX - BX;
		const double DY = (double)A.CellY - BY;
		return FMath::Sqrt(DX * DX + DY * DY);
	}

	// --------------------------------------------------------------------
	//  TOWERS - on their ranked hills, each facing its deadliest cone.
	//  A tower's facing is the 45-degree sector with the deepest visibility
	//  at range; its rank is how much ground it sees at all. The hills are
	//  the same ranked net the march table exposes - the towers ARE the net.
	// --------------------------------------------------------------------
	static void BuildTowers(const FHeightGrid& G, const TArray<FTerrainHighPoint>& Hills,
		int32 Count, int32 MinSepCells, int32 RangeCells, FWarWorksPlan& Out)
	{
		Out.Towers.Reset();
		if (Count <= 0 || !G.IsValid()) return;
		struct FTowerCand
		{
			FTerrainHighPoint Hill;
			float FacingYawDeg = 0.f;
			int32 SeenTotal = 0;
			int32 Order = 0;   // the hill's incoming rank - ties keep the land's order
		};
		TArray<FTowerCand> Cands;
		for (int32 i = 0; i < Hills.Num(); ++i)
		{
			FTowerCand C;
			C.Hill = Hills[i];
			C.Order = i;
			int32 BestSector = -1;
			int32 BestSectorSeen = -1;
			for (int32 Sector = 0; Sector < 8; ++Sector)
			{
				const float BaseYaw = (float)Sector * 45.f;
				int32 SectorSeen = 0;
				for (int32 S = 0; S < 3; ++S)
				{
					const float Yaw = (BaseYaw + (S - 1) * 15.f) * (float)PI / 180.f;
					const int32 TX = Hills[i].CellX + (int32)(FMath::Cos(Yaw) * RangeCells + 0.5);
					const int32 TY = Hills[i].CellY + (int32)(FMath::Sin(Yaw) * RangeCells + 0.5);
					if (TX < 0 || TY < 0 || TX >= G.W || TY >= G.H) continue;
					if (FTerrainStructureModel::Sees(G, Hills[i].CellX, Hills[i].CellY, TX, TY)) ++SectorSeen;
				}
				C.SeenTotal += SectorSeen;
				if (SectorSeen > BestSectorSeen)
				{
					BestSectorSeen = SectorSeen;
					BestSector = Sector;
				}
			}
			C.FacingYawDeg = BestSector >= 0 ? (float)BestSector * 45.f : 0.f;
			Cands.Add(C);
		}
		// deadliest first; ties by the hill's incoming rank (deterministic)
		Cands.Sort([](const FTowerCand& A, const FTowerCand& B)
		{
			if (A.SeenTotal != B.SeenTotal) return A.SeenTotal > B.SeenTotal;
			return A.Order < B.Order;
		});
		for (const FTowerCand& C : Cands)
		{
			if (Out.Towers.Num() >= Count) break;
			bool bTooClose = false;
			for (const FWarWorkPoint& T : Out.Towers)
			{
				if (CellDist(T, C.Hill.CellX, C.Hill.CellY) < MinSepCells) { bTooClose = true; break; }
			}
			if (bTooClose) continue;
			FWarWorkPoint P;
			P.CellX = C.Hill.CellX;
			P.CellY = C.Hill.CellY;
			P.FacingYawDeg = C.FacingYawDeg;
			P.Note = FString::Printf(TEXT("hill %.0f m over the lowland, sees %d of 24 bearings"),
				C.Hill.RiseCm / 100.f, C.SeenTotal);
			Out.Towers.Add(P);
		}
	}

	// --------------------------------------------------------------------
	//  BRIDGES - at the river's honest crossings: narrow channel, gentle
	//  banks. The best crossings are THEIRS (they hold the water). Ours are
	//  the best of the rest that their towers CANNOT see - a war builds
	//  where the watcher is blind.
	// --------------------------------------------------------------------
	static void BuildBridges(const FHeightGrid& G, const TArray<FIntPoint>& RiverCells,
		const TArray<FWarWorkPoint>& Towers, int32 TheirsCount, int32 OursCount,
		int32 MinSepCells, float BankRiseCm, FWarWorksPlan& Out)
	{
		Out.BridgesTheirs.Reset();
		Out.BridgesOurs.Reset();
		if (!G.IsValid() || RiverCells.Num() < 8) return;

		struct FBridgeCand
		{
			FIntPoint Cell;
			FIntPoint Normal;      // unit crossing direction (grid axes, for WALKING only)
			float WidthCells = 0.f;
			float BankGrade = 0.f; // rise per cell across the banks (lower = gentler)
			float TrueYawDeg = 0.f;   // S26-BRIDGE-MATH: the real perpendicular bearing
			int32 Order = 0;
		};
		TArray<FBridgeCand> Cands;
		const int32 Stride = FMath::Max(1, RiverCells.Num() / 64);
		for (int32 i = Stride; i < RiverCells.Num() - Stride; i += Stride)
		{
			const FIntPoint& Here = RiverCells[i];
			FIntPoint Flow(RiverCells[i + 1].X - RiverCells[i - 1].X,
				RiverCells[i + 1].Y - RiverCells[i - 1].Y);
			if (Flow.X == 0 && Flow.Y == 0) continue;
			// S26-BRIDGE-MATH: the TRUE local flow vector (raw, un-quantized)
			// gives the crossing its real bearing. The grid-unit step below is
			// only for WALKING cells; using it for the yaw quantized every
			// bridge to a multiple of 45 degrees - a river running 20 degrees
			// off an axis got a 45-degree bridge. That was a guess, and wrong.
			const double RawFX = (double)RiverCells[i + 1].X - (double)RiverCells[i - 1].X;
			const double RawFY = (double)RiverCells[i + 1].Y - (double)RiverCells[i - 1].Y;
			// a UNIT flow step (the polyline can skip cells; a (0,2) flow would
			// otherwise march the banks two cells at a time and lie about width)
			Flow = FIntPoint(Flow.X > 0 ? 1 : (Flow.X < 0 ? -1 : 0),
				Flow.Y > 0 ? 1 : (Flow.Y < 0 ? -1 : 0));
			FIntPoint Normal(-Flow.Y, Flow.X);   // diagonal (1,1) steps are fair - cells stay on-grid
			const FHeightCell* Bed = G.At(Here.X, Here.Y);
			if (!Bed || !Bed->bValid) continue;
			float LeftCells = 0.f, RightCells = 0.f, Grade = 0.f;
			for (int32 Side = 0; Side < 2; ++Side)
			{
				const int32 Dir = (Side == 0) ? 1 : -1;
				float Extent = 0.f;
				float LastRise = 0.f;
				for (int32 Step = 1; Step <= 40; ++Step)
				{
					const int32 SX = Here.X + Normal.X * Dir * Step;
					const int32 SY = Here.Y + Normal.Y * Dir * Step;
					const FHeightCell* C2 = G.At(SX, SY);
					if (!C2 || !C2->bValid) break;
					const float Rise = C2->Z - Bed->Z;
					if (Rise >= BankRiseCm)
					{
						LastRise = Rise;
						Extent = (float)Step;
						break;
					}
				}
				// S26-BRIDGE-MATH: never found a bank on this side - NOT a
				// candidate. The old code faked a 40-cell extent, sorted last
				// but still selectable: on coarse grids that stamp was a
				// multi-kilometre mega-bridge across open country.
				if (Extent <= 0.f) { LeftCells = -1.f; break; }
				if (Side == 0) LeftCells = Extent; else RightCells = Extent;
				Grade = FMath::Max(Grade, LastRise / FMath::Max(1.f, Extent));
			}
			if (LeftCells < 0.f || RightCells < 0.f) continue;   // S26-BRIDGE-MATH: bankless, not a crossing
			FBridgeCand C;
			C.Cell = Here;
			C.Normal = Normal;
			C.WidthCells = LeftCells + RightCells;
			C.BankGrade = Grade;
			C.TrueYawDeg = BearingYawDeg(-RawFY, RawFX);   // perpendicular of the true flow
			C.Order = i;
			Cands.Add(C);
		}
		// best crossing first: a bridge is a SPAN - narrower wins, gentler
		// banks break ties, then the river's own order (deterministic)
		Cands.Sort([](const FBridgeCand& A, const FBridgeCand& B)
		{
			if (A.WidthCells != B.WidthCells) return A.WidthCells < B.WidthCells;
			if (A.BankGrade != B.BankGrade) return A.BankGrade < B.BankGrade;
			return A.Order < B.Order;
		});

		auto Spaced = [&](const FWarWorkPoint& P, const TArray<FWarWorkPoint>& List) -> bool
		{
			for (const FWarWorkPoint& Q : List)
			{
				if (CellDist(P, Q.CellX, Q.CellY) < MinSepCells) return false;
			}
			return true;
		};
		auto TowerSees = [&](const FIntPoint& Cell) -> bool
		{
			for (const FWarWorkPoint& T : Towers)
			{
				if (CellDist(T, Cell.X, Cell.Y) > 60.0) continue;
				if (FTerrainStructureModel::Sees(G, T.CellX, T.CellY, Cell.X, Cell.Y)) return true;
			}
			return false;
		};

		for (const FBridgeCand& C : Cands)
		{
			if (Out.BridgesTheirs.Num() >= TheirsCount && Out.BridgesOurs.Num() >= OursCount) break;
			FWarWorkPoint Probe;
			Probe.CellX = C.Cell.X;
			Probe.CellY = C.Cell.Y;
			if (!Spaced(Probe, Out.BridgesTheirs) || !Spaced(Probe, Out.BridgesOurs)) continue;
			FWarWorkPoint P;
			P.CellX = C.Cell.X;
			P.CellY = C.Cell.Y;
			P.WidthCm = C.WidthCells * G.CellSizeCm;
			P.FacingYawDeg = C.TrueYawDeg;   // S26-BRIDGE-MATH: the measured perpendicular, not a 45-degree step
			P.Note = FString::Printf(TEXT("channel ~%.0f m (grid), bearing %.0f deg, banks grade %.2f"),
				P.WidthCm / 100.f, P.FacingYawDeg, C.BankGrade);
			// theirs: they hold the water, they take the best crossings first
			if (Out.BridgesTheirs.Num() < TheirsCount)
			{
				P.Note += TEXT(" - theirs");
				Out.BridgesTheirs.Add(P);
				continue;
			}
			// ours: only where their towers are blind. A SEEN crossing is
			// rejected outright - it does not burn an engineer's slot, the
			// search moves on down the river.
			if (TowerSees(C.Cell)) continue;
			P.Note += TEXT(" - ours, under their towers' blind spot");
			Out.BridgesOurs.Add(P);
		}
	}

	// --------------------------------------------------------------------
	//  OUTPOSTS - our high ground, spaced, each facing the enemy's centre.
	//  The caller passes OUR hills (ranked, already filtered to our side).
	// --------------------------------------------------------------------
	static void BuildOutposts(const TArray<FTerrainHighPoint>& OurHills,
		const FIntPoint& EnemyCentroid, int32 Count, int32 MinSepCells, FWarWorksPlan& Out)
	{
		Out.Outposts.Reset();
		for (int32 i = 0; i < OurHills.Num() && Out.Outposts.Num() < Count; ++i)
		{
			bool bTooClose = false;
			for (const FWarWorkPoint& O : Out.Outposts)
			{
				if (CellDist(O, OurHills[i].CellX, OurHills[i].CellY) < MinSepCells) { bTooClose = true; break; }
			}
			if (bTooClose) continue;
			FWarWorkPoint P;
			P.CellX = OurHills[i].CellX;
			P.CellY = OurHills[i].CellY;
			P.FacingYawDeg = BearingYawDeg(
				(double)EnemyCentroid.X - P.CellX, (double)EnemyCentroid.Y - P.CellY);
			P.Note = FString::Printf(TEXT("our ground, %.0f m over the lowland, facing them"),
				OurHills[i].RiseCm / 100.f);
			Out.Outposts.Add(P);
		}
	}

	// --------------------------------------------------------------------
	//  ARMOR - the tank country decides. Staging around the flat patch's
	//  centroid, hulls at the rim TOWARD the enemy with ground rising in
	//  front of the gun (hull-down), and the burnt hulks of the last push
	//  just past the rim on the enemy-facing side.
	// --------------------------------------------------------------------
	static void BuildArmor(const FHeightGrid& G, const FTerrainPatch& TankCountry,
		const FIntPoint& EnemyCentroid, float RimRiseCm, FWarWorksPlan& Out)
	{
		Out.Hulls.Reset();
		Out.DeadHulks.Reset();
		Out.Staging.Reset();
		if (!G.IsValid() || TankCountry.CellCount <= 0) return;

		const int32 CX = (int32)(TankCountry.CentroidX + 0.5f);
		const int32 CY = (int32)(TankCountry.CentroidY + 0.5f);
		const double DX = (double)EnemyCentroid.X - CX;
		const double DY = (double)EnemyCentroid.Y - CY;
		const double DLen = FMath::Sqrt(DX * DX + DY * DY);
		if (DLen < 1.0) return;
		const double UX = DX / DLen, UY = DY / DLen;         // toward the enemy
		const double PX = -UY, PY = UX;                      // across the front

		// staging: three spawns spread across the patch, facing the enemy
		for (int32 k = -1; k <= 1; ++k)
		{
			FWarWorkPoint P;
			P.CellX = CX + (int32)(PX * k * 4.0 + 0.5);
			P.CellY = CY + (int32)(PY * k * 4.0 + 0.5);
			P.FacingYawDeg = BearingYawDeg(UX, UY);
			P.Note = TEXT("staging spawn on the tank country");
			Out.Staging.Add(P);
		}

		// the rim toward the enemy: walk out until the ground rises - that
		// lip is where a hull hides and a gun still clears
		const FHeightCell* Base = G.At(CX, CY);
		if (!Base || !Base->bValid) return;
		int32 Rim = 0;
		for (int32 Step = 1; Step <= 60; ++Step)
		{
			const int32 SX = CX + (int32)(UX * Step + 0.5);
			const int32 SY = CY + (int32)(UY * Step + 0.5);
			const FHeightCell* C2 = G.At(SX, SY);
			if (!C2 || !C2->bValid) { Rim = Step; break; }
			if (C2->Z - Base->Z > RimRiseCm) { Rim = Step; break; }
			Rim = Step;
		}
		for (int32 k = -1; k <= 1; ++k)
		{
			FWarWorkPoint P;
			P.CellX = CX + (int32)(UX * (Rim - 1) + PX * k * 3.0 + 0.5);
			P.CellY = CY + (int32)(UY * (Rim - 1) + PY * k * 3.0 + 0.5);
			P.FacingYawDeg = BearingYawDeg(UX, UY);
			P.Note = FString::Printf(TEXT("hull-down at the rim, %d cells of flat behind it"), Rim - 1);
			Out.Hulls.Add(P);
		}
		// the last push died just past the rim
		for (int32 k = 0; k < 2; ++k)
		{
			FWarWorkPoint P;
			P.CellX = CX + (int32)(UX * (Rim + 3 + k * 2) + PX * (k == 0 ? 2.0 : -2.0) + 0.5);
			P.CellY = CY + (int32)(UY * (Rim + 3 + k * 2) + PY * (k == 0 ? 2.0 : -2.0) + 0.5);
			P.FacingYawDeg = BearingYawDeg(-UX, -UY) + 40.f;   // caught turning back
			P.Note = TEXT("burnt out where the last push died");
			Out.DeadHulks.Add(P);
		}
	}
};

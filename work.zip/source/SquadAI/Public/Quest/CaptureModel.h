// CaptureModel.h - S19-CAP
//
// The rules behind "take the point and keep it": a flag with a 0..1 progress that
// fills while the player's side stands on it and drains while hostiles do, a
// CONTESTED state when both are present (nobody captures under fire - that is the
// whole tension of an objective point), an optional hold phase after the capture,
// and the recapture rule (hostiles can bleed a held flag back off you).
//
// Presence is the caller's business (the actor counts pawns); the MODEL is the
// arithmetic - and it is deliberately total: every input combination has exactly
// one answer, so a designer can reason about timings on paper (a solo capture at
// the default 0.25/s takes 4 s; contested takes forever, which is the point).
//
// Engine-free: no UENUM reflection, no generated include - compiled and pinned by
// tools/mission_test like every other model in the module.

#pragma once

#include "CoreMinimal.h"

/** The flag's flow state, INTERNAL to the model (plain C++ on purpose - the actor
 * publishes its own reflected UENUM and converts, so UHT sees exactly one spelling). */
enum class ECaptureFlowState : uint8
{
	Neutral,      // nobody owns it
	Contested,    // both sides on the point - progress frozen
	Capturing,    // the player's side is on it and it is not yet captured
	Held          // captured AND (if a hold is required) held for the full time
};

struct FCapturePointModel
{
	// -----------------------------------------------------------------------------------------
	//  progress
	// -----------------------------------------------------------------------------------------

	/**
	 * One tick of the flag's progress.
	 *   both sides inside -> CONTESTED: progress does not move (firefights decide it)
	 *   player only       -> progress climbs at CapRate01PerSecond
	 *   hostiles only     -> progress DRAINS at CapRate01PerSecond (they take it back)
	 *   nobody            -> progress holds where it is (walking away does not undo work)
	 * Result is clamped to [0, 1].
	 */
	static float AdvanceProgress(float Current01, bool bPlayerInside, bool bHostileInside,
		float CapRate01PerSecond, float DeltaSeconds)
	{
		if (bPlayerInside && bHostileInside)
		{
			return FMath::Clamp(Current01, 0.f, 1.f);   // contested: frozen
		}
		const float Rate = FMath::Max(0.f, CapRate01PerSecond);   // a zero rate is a real
		                                                          // (mis)configuration: nothing moves
		if (bPlayerInside)
		{
			return FMath::Clamp(Current01 + Rate * FMath::Max(0.f, DeltaSeconds), 0.f, 1.f);
		}
		if (bHostileInside)
		{
			return FMath::Clamp(Current01 - Rate * FMath::Max(0.f, DeltaSeconds), 0.f, 1.f);
		}
		return FMath::Clamp(Current01, 0.f, 1.f);
	}

	/** The capture moment: the tick progress first reaches 1. */
	static bool CaptureCrossed(float Old01, float New01) { return Old01 < 1.f && New01 >= 1.f; }

	/** The recapture moment: a held/captured flag first drops below 1 again. */
	static bool LostCrossed(float Old01, float New01) { return Old01 >= 1.f && New01 < 1.f; }

	/**
	 * Seconds of SOLO standing needed to finish from the current progress.
	 * Contested or draining is "forever" (-1): the answer must say so, not lie.
	 */
	static float SecondsToCapture(float Current01, float CapRate01PerSecond)
	{
		const float Rate = FMath::Max(0.f, CapRate01PerSecond);
		if (Rate <= 0.f)
		{
			return -1.f;
		}
		return FMath::Max(0.f, 1.f - FMath::Clamp(Current01, 0.f, 1.f)) / Rate;
	}

	// -----------------------------------------------------------------------------------------
	//  the hold phase (after the capture, when HoldSeconds > 0)
	// -----------------------------------------------------------------------------------------

	/**
	 * One tick of the post-capture hold. The clock only runs while the player's side
	 * is present; hostiles on the point PAUSE it (contested) rather than rewinding it -
	 * taking the flag was the hard part, holding it should not feel like a restart.
	 */
	static float AdvanceHold(float HeldSeconds, bool bPlayerInside, bool bHostileInside,
		float DeltaSeconds)
	{
		if (bPlayerInside && !bHostileInside)
		{
			return HeldSeconds + FMath::Max(0.f, DeltaSeconds);
		}
		return HeldSeconds;   // contested or absent: paused, never rewound
	}

	/** The hold is done at exactly the required time, inclusive. */
	static bool HoldCompleted(float HeldSeconds, float RequiredHoldSeconds)
	{
		return RequiredHoldSeconds <= 0.f || HeldSeconds >= RequiredHoldSeconds;
	}

	// -----------------------------------------------------------------------------------------
	//  state naming
	// -----------------------------------------------------------------------------------------

	static ECaptureFlowState StateFor(float Progress01, bool bPlayerInside, bool bHostileInside,
		bool bHoldDone)
	{
		if (Progress01 >= 1.f)
		{
			return bHoldDone ? ECaptureFlowState::Held : ECaptureFlowState::Capturing;
		}
		if (bPlayerInside && bHostileInside)
		{
			return ECaptureFlowState::Contested;
		}
		if (bPlayerInside)
		{
			return ECaptureFlowState::Capturing;
		}
		return ECaptureFlowState::Neutral;
	}
};

// AssetDefenseModel.h - S19-ASSET
//
// The rules behind "protect the asset": a friendly generator / comms relay / downed
// bird with health, and the ONE honest way enemies can threaten it without new AI -
// SAPPERS. A hostile standing near the asset is working on it: the asset bleeds
// health for every hostile inside the sapper radius, so the defend dynamic is
// "never let them park next to it", which the player can always act on.
//
// WHY SAPPERS AND NOT WEAPON FIRE: the module's enemies target the PLAYER (stated
// plainly since the convoy: they do not shoot objectives). Pretending otherwise
// would need new targeting behaviour on every AI path. Sappers are a rule the
// player can see, learn and beat - and the model says exactly how fast it burns.
//
// Engine-free: pure functions; compiled and pinned by tools/mission_test.

#pragma once

#include "CoreMinimal.h"

/** The asset's condition, INTERNAL to the model (plain C++ - the actor publishes a
 *  reflected UENUM and converts, so UHT sees exactly one spelling of each). */
enum class EAssetHealthCondition : uint8
{
	Pristine,     // above 2/3
	Damaged,      // 1/3 .. 2/3
	Critical,     // below 1/3 - the "it is going to go" moment
	Destroyed
};

struct FAssetDefenseModel
{
	// -----------------------------------------------------------------------------------------
	//  sappers
	// -----------------------------------------------------------------------------------------

	/**
	 * Damage per second the asset takes with `HostileCount` hostiles inside the sapper
	 * radius. Linear and uncapped in count on purpose - six sappers is six men with
	 * demo packs - but every rate is clamped sane: negative inputs are 0.
	 */
	static float SapperDamagePerSecond(int32 HostileCount, float DamagePerSapperPerSecond)
	{
		const float Count = static_cast<float>(FMath::Max(0, HostileCount));
		return Count * FMath::Max(0.f, DamagePerSapperPerSecond);
	}

	/**
	 * The "under attack" announcement window: the first damage after `QuietSeconds`
	 * of no damage announces; continued damage does not re-alert every tick. The
	 * caller keeps LastDamageChangeSeconds. Returns true when the alert should fire.
	 */
	static bool ShouldAnnounceAttack(float SecondsSinceLastAnnouncement, float QuietSeconds)
	{
		return SecondsSinceLastAnnouncement >= FMath::Max(0.f, QuietSeconds);
	}

	// -----------------------------------------------------------------------------------------
	//  condition
	// -----------------------------------------------------------------------------------------

	static EAssetHealthCondition ConditionFor01(float Health01)
	{
		const float H = FMath::Clamp(Health01, 0.f, 1.f);
		if (H <= 0.f) return EAssetHealthCondition::Destroyed;
		if (H < (1.f / 3.f)) return EAssetHealthCondition::Critical;
		if (H < (2.f / 3.f)) return EAssetHealthCondition::Damaged;
		return EAssetHealthCondition::Pristine;
	}

	/** The one-way floor: an asset that dropped below a phase never shows a better one
	 *  until repaired (there is no repair) - the caller passes its worst-so-far. */
	static EAssetHealthCondition WorseCondition(EAssetHealthCondition A, EAssetHealthCondition B)
	{
		return (static_cast<uint8>(A) >= static_cast<uint8>(B)) ? A : B;
	}

	/** Seconds until the asset dies at the current damage rate (-1 = nothing is hurting it). */
	static float SecondsUntilDestroyed(float Health01, float DamagePerSecond)
	{
		if (DamagePerSecond <= 0.f || Health01 <= 0.f)
		{
			return -1.f;
		}
		return (FMath::Clamp(Health01, 0.f, 1.f) / DamagePerSecond);
	}

	/** The completion bonus rule: the asset was linked, still alive at the end. */
	static bool EarnsPreservedBonus(bool bAssetLinked, bool bAssetAlive)
	{
		return bAssetLinked && bAssetAlive;
	}
};

// MissionStoryModel.h - S24-STORY
//
// THE WAR TALKS BACK. The briefing sets the act up and the debrief counts it,
// but BETWEEN them the radio was silent except tactical cliches - the story
// stopped the moment the shooting started. This model writes the BATTALION'S
// voice for the moments that change a fight: the act opens, their net wakes,
// the full alarm breaks, they try to take the ground back. Major Rostami's
// command net, speaking to the player, from the land's own act number and
// place words.
//
// Deterministic like everything else in this campaign: the same act, the same
// event, the same line - and the line ROTATES by act number so twenty-eight
// acts never hear the same order twice. Bilingual: the zone passes both
// strings; the radio subtitle picks its language at draw time.
//
// Engine-free (FString only), pinned by tools/mission_test.

#pragma once

#include "CoreMinimal.h"

/** The moments in a fight that earn a word from command. */
enum class EMissionStoryEvent : uint8
{
	ActOpened = 0,     // the zone activated - the act begins
	AlarmSearching = 1, // their net woke up, patrols are out
	AlarmFull = 2,     // the whole line is up
	Counterattack = 3  // they want the ground back
};

struct FMissionStoryModel
{
	/** "Act 7 of 28" -> 7. 0 when the string carries no act number. */
	static int32 ParseActNumber(const FString& TitleCardDate)
	{
		const int32 At = TitleCardDate.Find(TEXT("Act "), ESearchCase::IgnoreCase, ESearchDir::FromStart);
		if (At == INDEX_NONE) return 0;
		int32 i = At + 4;
		int32 N = 0;
		bool bAny = false;
		while (i < TitleCardDate.Len())
		{
			const TCHAR Ch = TitleCardDate[i];
			if (Ch >= TEXT('0') && Ch <= TEXT('9'))
			{
				N = N * 10 + (int32)(Ch - TEXT('0'));
				bAny = true;
				++i;
			}
			else
			{
				break;
			}
		}
		return bAny ? N : 0;
	}

	/** The beat's line. Same act + same event = the same line, byte for byte;
	 *  consecutive acts rotate through three variants so the net never repeats
	 *  itself in the same order twice. */
	static FString BuildStoryBeat(EMissionStoryEvent E, int32 ActNumber, const FString& Place, bool bEnglish)
	{
		const int32 Act = FMath::Max(1, ActNumber);
		const int32 Variant = (Act - 1 + (int32)E) % 3;
		const FString P = Place.IsEmpty() ? FString(TEXT("the ground")) : Place;

		switch (E)
		{
		case EMissionStoryEvent::ActOpened:
			if (bEnglish)
			{
				switch (Variant)
				{
				case 0: return FString::Printf(TEXT("Command net: act %d opens. %s is the ground tonight - make it count."), Act, *P);
				case 1: return FString::Printf(TEXT("Major Rostami to all callsigns: the battalion steps off for %s. Act %d."), *P, Act);
				default: return FString::Printf(TEXT("HQ: %s, act %d. The chain moves with you - do not let it break."), *P, Act);
				}
			}
			switch (Variant)
			{
			case 0: return FString::Printf(TEXT("شبکه فرماندهی: پرده‌ی عملیات %d باز شد. امشب زمین، همین %s است - حسابی عمل کن."), Act, *P);
			case 1: return FString::Printf(TEXT("سرگرد رستمی به همه ندبه‌ها: یگان به سمت %s حرکت می‌کند. عملیات %d."), *P, Act);
			default: return FString::Printf(TEXT("فرماندهی: %s، عملیات %d. زنجیره پیش می‌آید - نگذار بشکند."), *P, Act);
			}

		case EMissionStoryEvent::AlarmSearching:
			if (bEnglish)
			{
				switch (Variant)
				{
				case 0: return FString::Printf(TEXT("Their net is awake - patrols sweeping %s. Stay off the skyline."), *P);
				case 1: return TEXT("They are SEARCHING. Break contact, or break them.");
				default: return FString::Printf(TEXT("They know something is at %s. Give them nothing."), *P);
				}
			}
			switch (Variant)
			{
			case 0: return FString::Printf(TEXT("شبکه دشمن بیدار شد - گشت‌ها در %s می‌گردند. زیر خط آسمان نرو."), *P);
			case 1: return TEXT("دشمن در حال جستجوست. یا تماس را قطع کن، یا آنها را.");
			default: return FString::Printf(TEXT("می‌دانند چیزی در %s هست. هیچی بهشان نده."), *P);
			}

		case EMissionStoryEvent::AlarmFull:
			if (bEnglish)
			{
				switch (Variant)
				{
				case 0: return FString::Printf(TEXT("FULL ALARM at %s! Loud now - speed is your cover!"), *P);
				case 1: return FString::Printf(TEXT("The whole line is up! Fight through - %s is worth it!"), *P);
				default: return FString::Printf(TEXT("No more quiet. Take %s before they dig in deeper!"), *P);
				}
			}
			switch (Variant)
			{
			case 0: return FString::Printf(TEXT("هشدار کامل در %s! دیگر بلند شو - سرعت، پناه توست!"), *P);
			case 1: return FString::Printf(TEXT("کل خط جبهه بیدار شد! بجنگ و رد شو - %s ارزشش را دارد!"), *P);
			default: return FString::Printf(TEXT("بی‌سروصدا دیگر فایده ندارد. %s را بگیر پیش از آنکه عمیق‌تر سنگر بگیرند!"), *P);
			}

		case EMissionStoryEvent::Counterattack:
		default:
			if (bEnglish)
			{
				switch (Variant)
				{
				case 0: return FString::Printf(TEXT("They WANT %s back - stand! This is why you took it!"), *P);
				case 1: return TEXT("Counterattack inbound - hold what you bled for!");
				default: return FString::Printf(TEXT("Here they come to take it back. %s stays OURS!"), *P);
				}
			}
			switch (Variant)
			{
			case 0: return FString::Printf(TEXT("می‌خواهند %s را پس بگیرند - بایست! برای همین گرفتی‌اش!"), *P);
			case 1: return TEXT("ضدحمله در راه است - نگه دار آنچه برایش خون دادی!");
			default: return FString::Printf(TEXT("آمدند که پسش بگیرند. %s مال ما می‌ماند!"), *P);
			}
		}
	}
};

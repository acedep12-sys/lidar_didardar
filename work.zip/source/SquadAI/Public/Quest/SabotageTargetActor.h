// SabotageTargetActor.h — S17-SAB: demolition objective for sabotage missions.
// Place on an ammo dump / bridge footing / radar truck built from existing props
// (stack ExplosiveBarrelActors nearby for a chain-reaction fireball). The player
// stands close to PLANT a charge (proximity hold — no input-owner conflicts),
// the fuse runs, the charge detonates with radial damage, and the owning
// MissionZone completes once every linked target is destroyed.
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "SabotageTargetActor.generated.h"

class UStaticMeshComponent;
class UMaterialInstanceDynamic;
class USoundBase;

UENUM(BlueprintType)
enum class ESabotageState : uint8
{
	Idle       UMETA(DisplayName = "Awaiting Charge"),
	Planting   UMETA(DisplayName = "Planting"),
	Armed      UMETA(DisplayName = "Fuse Burning"),
	Detonated  UMETA(DisplayName = "Detonated")
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnSabotageDetonated, class ASabotageTargetActor*, Target);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnSabotagePlantProgress, class ASabotageTargetActor*, Target, float, Progress);

UCLASS(BlueprintType, Blueprintable)
class SQUADAI_API ASabotageTargetActor : public AActor
{
	GENERATED_BODY()

public:
	ASabotageTargetActor();
	virtual void Tick(float DeltaTime) override;

	// ===== CONFIG =====

	/** Stand within this range of the marker to plant (cm). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sabotage", meta = (ClampMin = "100.0"))
	float PlantRadius = 260.f;

	/** Seconds the player must stay close to finish planting. Leaving decays progress. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sabotage", meta = (ClampMin = "0.5"))
	float PlantTime = 3.f;

	/** Fuse seconds between planted and BOOM — get clear. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sabotage", meta = (ClampMin = "1.0"))
	float FuseTime = 10.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sabotage", meta = (ClampMin = "0.0"))
	float ExplosionDamage = 900.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sabotage", meta = (ClampMin = "100.0"))
	float ExplosionRadius = 1400.f;

	/** Optional override; falls back to the audio manager's medium explosion. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sabotage")
	TObjectPtr<USoundBase> ExplosionSound;

	// ===== STATE =====

	UPROPERTY(BlueprintReadOnly, Category = "Sabotage")
	ESabotageState State = ESabotageState::Idle;

	UPROPERTY(BlueprintAssignable, Category = "Sabotage")
	FOnSabotageDetonated OnDetonated;

	UPROPERTY(BlueprintAssignable, Category = "Sabotage")
	FOnSabotagePlantProgress OnPlantProgress;

	UFUNCTION(BlueprintCallable, Category = "Sabotage")
	void ResetTarget();

	UFUNCTION(BlueprintCallable, Category = "Sabotage")
	void Detonate();

	bool IsDetonated() const { return State == ESabotageState::Detonated; }

protected:
	virtual void BeginPlay() override;

	UPROPERTY(VisibleAnywhere, Category = "Sabotage")
	TObjectPtr<UStaticMeshComponent> MarkerDisc;

	UPROPERTY(VisibleAnywhere, Category = "Sabotage")
	TObjectPtr<UStaticMeshComponent> ChargeMesh;

private:
	float PlantProgress = 0.f;
	float FuseRemaining = 0.f;

	UPROPERTY(Transient)
	TObjectPtr<UMaterialInstanceDynamic> MarkerMID;

	void SetMarkerColor(const FLinearColor& C);
};

// PathExplosionBarrage.h — After listed missions start, random ground strikes near the player.
// Warning circle, then Niagara explosion + dirt + 3D spatial dual-layer sound + camera concussion.
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Quest/MissionZone.h"
#include "PathExplosionBarrage.generated.h"

class UNiagaraSystem;
class UStaticMeshComponent;
class USoundBase;
class USoundAttenuation;
class UCameraShakeBase;

USTRUCT(BlueprintType)
struct FExplosionSizeConfig
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Explosion")
	FName SizeName = TEXT("Medium");

	// Ground warning / kill radius (cm)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Explosion", meta = (ClampMin = "50"))
	float Radius = 280.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Explosion", meta = (ClampMin = "0"))
	float Damage = 70.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Explosion", meta = (ClampMin = "0"))
	float Weight = 1.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Explosion|FX")
	TObjectPtr<UNiagaraSystem> ExplosionFX;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Explosion|FX")
	TObjectPtr<UNiagaraSystem> DirtFX;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Explosion|FX", meta = (ClampMin = "0.1"))
	float FXScale = 1.f;

	/** Close punchy explosion sound */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Explosion|Audio")
	TObjectPtr<USoundBase> CloseExplosionSound;

	/** Distant booming echo / low rumble sound (heard across the desert) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Explosion|Audio")
	TObjectPtr<USoundBase> DistantExplosionSound;

	/** Optional custom sound attenuation */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Explosion|Audio")
	TObjectPtr<USoundAttenuation> SoundAttenuation;

	/** Camera shake triggered when explosion lands near the player */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Explosion|Camera")
	TSubclassOf<UCameraShakeBase> CameraShake;
};

UCLASS(BlueprintType, Blueprintable, meta = (DisplayName = "Path Explosion Barrage"))
class SQUADAI_API APathExplosionBarrage : public AActor
{
	GENERATED_BODY()

public:
	APathExplosionBarrage();

	// If not empty, barrage runs only while one of these missions is Active.
	// If empty, it follows the current QuestChain mission.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Barrage|Missions")
	TArray<TObjectPtr<AMissionZone>> LinkedMissions;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Barrage")
	bool bEnabled = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Barrage", meta = (ClampMin = "0"))
	float FirstDelayAfterMissionStart = 4.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Barrage", meta = (ClampMin = "0.5"))
	float MinSecondsBetweenStrikes = 6.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Barrage", meta = (ClampMin = "0.5"))
	float MaxSecondsBetweenStrikes = 12.f;

	// Time the red circle is visible before the boom
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Barrage|Warning", meta = (ClampMin = "0.2"))
	float WarningTime = 2.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Barrage|Warning")
	FLinearColor WarningCircleColor = FLinearColor(1.f, 0.05f, 0.05f, 0.9f);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Barrage|Warning", meta = (ClampMin = "1"))
	float WarningLineThickness = 8.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Barrage|Warning")
	bool bShowFilledDisc = true;

	// Random point around the player, on the ground
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Barrage|Placement", meta = (ClampMin = "100"))
	float MinDistanceFromPlayer = 450.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Barrage|Placement", meta = (ClampMin = "200"))
	float MaxDistanceFromPlayer = 2200.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Barrage", meta = (ClampMin = "1"))
	int32 MaxConcurrentWarnings = 2;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Barrage|Sizes")
	TArray<FExplosionSizeConfig> Sizes;

	UFUNCTION(BlueprintCallable, Category = "Barrage")
	void StartBarrage();

	UFUNCTION(BlueprintCallable, Category = "Barrage")
	void StopBarrage();

	UFUNCTION(CallInEditor, BlueprintCallable, Category = "Barrage")
	void TestStrikeNearPlayer();

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void Tick(float DeltaTime) override;

private:
	struct FPendingStrike
	{
		int32 Id = 0;
		int32 SizeIndex = 0;
		FVector Loc = FVector::ZeroVector;
		float Radius = 200.f;
		float Damage = 50.f;
		float ExplodeAt = 0.f;
		TWeakObjectPtr<UStaticMeshComponent> Disc;
	};

	bool bRunning = false;
	int32 NextStrikeId = 1;
	TArray<FPendingStrike> Pending;
	FTimerHandle ScheduleHandle;
	FTimerHandle MissionPollHandle;

	UPROPERTY()
	TObjectPtr<UStaticMesh> WarningDiscMesh;

	UPROPERTY()
	TObjectPtr<UMaterialInterface> WarningDiscMaterial;

	void BindMissions();
	void RefreshRunningState();
	bool IsAnyLinkedMissionActive() const;
	void ScheduleNextWarning(float Delay);
	void SpawnWarning();
	void ExplodeStrike(int32 Id);
	void ClearPending();
	bool PickGroundLocation(FVector& OutLoc) const;
	int32 PickSizeIndex() const;
	UStaticMeshComponent* SpawnWarningDisc(const FVector& Loc, float Radius);
	void ApplyExplosionDamage(const FVector& Loc, float Radius, float Damage);
	void ApplyDamageToActor(AActor* Target, float Damage);

	UFUNCTION()
	void HandleMissionStateChanged(AMissionZone* Mission, EMissionZoneState NewState);
};

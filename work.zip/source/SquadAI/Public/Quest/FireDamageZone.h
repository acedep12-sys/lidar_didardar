#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "FireDamageZone.generated.h"

class USphereComponent;
class UUserWidget;

// Fire damage zone — damages player when standing inside, shows red screen effect
UCLASS(BlueprintType, Blueprintable)
class SQUADAI_API AFireDamageZone : public AActor
{
	GENERATED_BODY()
public:
	AFireDamageZone();

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fire|Damage")
	float DamagePerSecond = 5.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fire|Damage")
	float DamageRadius = 150.f;

	// Red screen effect widget class (create a Widget Blueprint with red gradient overlay)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fire|Screen")
	TSubclassOf<UUserWidget> BurnScreenEffectClass;

	// Optional fire crackle sound played while inside the fire
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fire|Audio")
	TObjectPtr<class USoundBase> FireCrackleSound;

protected:
	virtual void BeginPlay() override;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Fire")
	TObjectPtr<USphereComponent> DamageZone;

private:
	UPROPERTY() TObjectPtr<AActor> OverlappingPlayer;
	UPROPERTY() TObjectPtr<UUserWidget> ActiveBurnEffect;
	UPROPERTY() TObjectPtr<UAudioComponent> ActiveFireAudio;
	TWeakObjectPtr<UActorComponent> CachedPackHealth;
	FTimerHandle DamageTimerHandle;

	UFUNCTION() void OnOverlapBegin(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
	UFUNCTION() void OnOverlapEnd(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);

	void ApplyFireDamage();
	void ShowBurnEffect();
	void HideBurnEffect();
};

// SplinePathActor.h — Optional corridor the squad leader follows between missions.
// Place as many as you want. Set ToMission (the mission this path leads to).
// Leave bFreeWill=true, or don't place a spline, for normal navmesh pathing.
// The leader may wander inside CorridorHalfWidth so it is not glued to the curve.
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Components/SplineComponent.h"
#include "Quest/MissionZone.h"
#include "SplinePathActor.generated.h"

class APawn;

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnSplinePathCompleted);

UCLASS(Blueprintable, BlueprintType, ClassGroup = SquadAI,
	meta = (DisplayName = "Leader Spline Path", ToolTip = "Corridor the squad leader follows between missions. Place, then sculpt the spline points."))
class SQUADAI_API ASplinePathActor : public AActor
{
	GENERATED_BODY()
public:
	ASplinePathActor();

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Spline")
	TObjectPtr<USplineComponent> SplinePath;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spline|Config")
	FName PathName = TEXT("TrenchPath");

	// Mission this path leads TO (leader uses it while that mission is current).
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spline|Config")
	TObjectPtr<AMissionZone> ToMission;

	// Optional: only use this path after FromMission is completed.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spline|Config")
	TObjectPtr<AMissionZone> FromMission;

	// Legacy: start conveyor-march when this mission completes (off by default).
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spline|Config")
	TObjectPtr<AMissionZone> TriggerMission;

	// If true, this actor does NOT constrain the leader (free navmesh to the mission).
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spline|Config")
	bool bFreeWill = false;

	// How far the leader may roam off the curve (cm). ~3-5m feels like a trench, not a rail.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spline|Config", meta = (ClampMin = "50"))
	float CorridorHalfWidth = 400.f;

	// Look ahead along the spline so they walk forward, not sideways to the closest point.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spline|Config", meta = (ClampMin = "100"))
	float LookAheadDistance = 700.f;

	// Extra side-to-side drift inside the corridor (cm). Stable (not every-tick wander).
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spline|Config", meta = (ClampMin = "0"))
	float WanderAmplitude = 160.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spline|Config")
	float AcceptanceRadius = 200.f;

	// If ToMission is empty, still use this spline when the leader is this close (cm)
	// AND the curve points toward the current mission.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spline|Config", meta = (ClampMin = "0"))
	float NearbyFallbackDistance = 3500.f;

	// Old behaviour: drag every ally along the spline like a train. Leave OFF.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spline|Config")
	bool bMarchAlongSpline = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spline|Enemies")
	TSubclassOf<APawn> EnemyClass;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spline|Enemies", meta = (ClampMin = "1"))
	int32 EnemyCount = 5;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spline|Enemies", meta = (ClampMin = "0"))
	float RandomOffset = 300.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spline|Enemies")
	bool bSpawnEnemies = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spline|Enemies")
	bool bRemoveEnemies = false;

	UPROPERTY(BlueprintReadOnly, Category = "Spline|State")
	bool bIsActive = false;

	UPROPERTY(BlueprintReadOnly, Category = "Spline|State")
	bool bCompleted = false;

	UPROPERTY(BlueprintAssignable, Category = "Spline|Events")
	FOnSplinePathCompleted OnSplinePathCompleted;

	// Draw the corridor in-world (cyan spline, yellow width). Filter log: PATHDBG
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spline|Debug")
	bool bDrawDebug = false;

	UFUNCTION(CallInEditor, BlueprintCallable, Category = "Spline|Debug")
	void DumpDebugNow();

	UFUNCTION(BlueprintCallable, Category = "Spline")
	void StartSplinePath();

	UFUNCTION(BlueprintCallable, Category = "Spline")
	void StopSplinePath();

	// Leader pathing: closest matching spline for the current mission, or null = free will.
	static ASplinePathActor* FindGuide(UWorld* World, AMissionZone* CurrentMission, const FVector& PawnLoc, bool bLog = false);

	static void LogAllGuides(UWorld* World, AMissionZone* CurrentMission, const FVector& PawnLoc);

	// Goal the leader should MoveTo: along the spline, with a little wander.
	UFUNCTION(BlueprintCallable, Category = "Spline")
	FVector GetSoftFollowLocation(const FVector& PawnLoc, const FVector& FinalGoal) const;

	// Same as GetSoftFollowLocation, but if the look-ahead sits in a hazard,
	// keep walking the spline until the point is clear (skip the burning stretch).
	FVector GetFollowLocationSkipping(
		const FVector& PawnLoc,
		const FVector& FinalGoal,
		const TArray<FVector>& HazardCenters,
		const TArray<float>& HazardRadii,
		float ExtraPad) const;

	// Slot along the same trench, staggered behind the leader (allies).
	FVector GetCorridorSlotLocation(const FVector& LeaderLoc, const FVector& FinalGoal, int32 Slot, float Spacing) const;

	float GetLength() const;
	FString DescribeForLog() const;

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void Tick(float DeltaTime) override;
#if WITH_EDITOR
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
#endif

private:
	float SplineLength = 0.f;
	float CurrentProgress = 0.f;

	UPROPERTY() TArray<TObjectPtr<APawn>> SpawnedEnemies;

	void MoveFollowersAlongSpline(float DeltaTime);
	FVector GetSplinePointAtDistance(float Distance) const;
	void SpawnEnemiesAlongSpline();
	void RemoveAllEnemies();
	void DrawDebugCorridor() const;
	FString EvaluateMatch(AMissionZone* CurrentMission, const FVector& PawnLoc, bool& bOutMatch, float& OutDist) const;

	UFUNCTION()
	void HandleMissionStateChanged(AMissionZone* Mission, EMissionZoneState NewState);
};

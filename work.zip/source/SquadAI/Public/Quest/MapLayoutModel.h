// MapLayoutModel.h - S19-MAP
//
// The rules behind "read the map, then put missions on it sensibly".
//
// The user's map has a readable grammar (their words): places with CRATES are
// trenches, places with TREES are biomes, and the river line is obvious. This
// model turns that grammar into a scatter plan:
//
//   1. CLUSTER - feature points (crate positions, tree positions) are bucketed on
//      a grid and merged into ZONES by connected components, per feature kind.
//   2. CLASSIFY - a zone's kind IS its feature kind: crates -> a trench line,
//      trees -> a biome. each river is its OWN polyline - separate rivers stay separate.
//   3. SCATTER - mission spots are chosen deterministically: one Defend HQ (the
//      given anchor, usually the player start), then trench assaults on the trench
//      lines, recon in the biomes, an extraction at a river spot, convoys on the
//      open ground - always respecting the minimum separation from each other and
//      from missions that already exist in the level, and never inside the river.
//   4. DRAW - a top-down SVG of the whole plan (biomes green, trenches brown, the
//      river blue, the missions pinned and numbered) so the scatter can be judged
//      at a glance before anything is stamped.
//
// Engine-free on purpose (no UENUM reflection, no generated include): compiled by
// tools/map_test, which also RENDERS THE SAMPLE MAP from a synthetic layout using
// this real file - the same code the editor runs.

#pragma once

#include "CoreMinimal.h"

/** The feature kinds the checker distinguishes. */
enum class EMapFeatureKind : uint8
{
	Trench,   // crates / trench splines - held ground
	Biome,    // trees - cover-dense terrain
	River,    // the water line - a corridor, never a mission spot
	Open      // none of the above
};

/** A merged cluster of one feature kind. */
struct FMapZone
{
	EMapFeatureKind Kind = EMapFeatureKind::Trench;
	FVector Center = FVector::ZeroVector;   // Z is ignored by the model
	float RadiusCm = 0.f;                   // max point distance from the center
	int32 PointCount = 0;
	/** Up to 120 of the member points (even stride) - the SHAPE of the feature: a
	 *  trench's crates along a line render as a line, which a center+radius circle
	 *  can never show. The map SVG and the report's geometry section read this. */
	TArray<FVector> SamplePoints;
	/** Highest minus lowest GROUND inside the zone (cm), from real world traces.
	 *  Below zero = not scanned. The flatness words and the pick bonus read this. */
	float HeightSpreadCm = -1.f;
};

/** One chosen mission spot, with the reasoning the report shows. */
enum class EMissionSpotKind : uint8
{
	HQDefend,        // the anchor: hold the line, protect the asset
	TrenchAssault,   // clear the trench, sabotage something in it
	BiomeRecon,      // a quiet intel job under the trees
	RiverExtraction, // the pad on the water line
	OpenConvoy       // the open ground is the convoy's road
};

struct FMissionSpot
{
	FVector Position = FVector::ZeroVector;
	EMissionSpotKind Kind = EMissionSpotKind::OpenConvoy;
	FString Reason;     // WHY this place: "on the trench line (7 crates)"
	int32 ActIndex = 0; // 1-based position in the campaign (the pin number)
	FString StoryLine;  // the act's words: "the line breaks here first..."
	int32 ZoneMarkers = 0; // the source zone's size (crates/trees): scales the op
};

struct FMapLayoutModel
{
	// -----------------------------------------------------------------------------------------
	//  clustering
	// -----------------------------------------------------------------------------------------

	/**
	 * Merge same-kind feature points into zones with an 8-neighbour grid flood fill.
	 * `CellSizeCm` is the merge distance (default 20 m: crates 20 m apart are one
	 * trench, 60 m apart are two). Zones keep the mean center and the max radius;
	 * singleton buckets are kept only when `bKeepSingletons` (a lone crate is not a
	 * trench line, so the checker defaults that to false).
	 */
	static TArray<FMapZone> ClusterPoints(const TArray<FVector>& Points,
		EMapFeatureKind Kind, float CellSizeCm = 2000.f, bool bKeepSingletons = false)
	{
		TArray<FMapZone> Out;
		if (Points.Num() == 0 || CellSizeCm <= 0.f)
		{
			return Out;
		}

		// -- the buckets (plain arrays: no TMap needed for a few hundred cells) ------
		struct FMapBucket { int64 Key; TArray<int32> Members; };
		TArray<FMapBucket> Buckets;
		auto FindBucket = [&Buckets](int64 Key) -> int32
		{
			for (int32 i = 0; i < Buckets.Num(); ++i)
			{
				if (Buckets[i].Key == Key) return i;
			}
			return -1;
		};
		for (int32 i = 0; i < Points.Num(); ++i)
		{
			const int64 GX = static_cast<int64>(FMath::FloorToInt(Points[i].X / CellSizeCm));
			const int64 GY = static_cast<int64>(FMath::FloorToInt(Points[i].Y / CellSizeCm));
			const int64 Key = (static_cast<int64>(static_cast<uint32>(GX)) << 32)
				| static_cast<int64>(static_cast<uint32>(GY));   // lossless for negatives
			const int32 Existing = FindBucket(Key);
			if (Existing == -1)
			{
				FMapBucket Bucket;
				Bucket.Key = Key;
				Bucket.Members.Add(i);
				Buckets.Add(Bucket);
			}
			else
			{
				Buckets[Existing].Members.Add(i);
			}
		}

		// -- connected components over 8-neighbours (indices, not pointers) ----------
		TArray<int32> Visited;
		for (int32 i = 0; i < Buckets.Num(); ++i)
		{
			Visited.Add(0);
		}
		for (int32 Start = 0; Start < Buckets.Num(); ++Start)
		{
			if (Visited[Start])
			{
				continue;
			}
			TArray<int32> Stack;
			Stack.Push(Start);
			Visited[Start] = 1;
			TArray<int32> Members;
			while (Stack.Num() > 0)
			{
				const int32 BucketIndex = Stack.Pop();
				Members.Append(Buckets[BucketIndex].Members);
				const int64 Key = Buckets[BucketIndex].Key;
				const int64 GX = static_cast<int32>(Key >> 32);
				const int64 GY = static_cast<int32>(Key & 0xFFFFFFFFLL);   // sign-restoring
				for (int32 DX = -1; DX <= 1; ++DX)
				{
					for (int32 DY = -1; DY <= 1; ++DY)
					{
						if (DX == 0 && DY == 0)
						{
							continue;
						}
						const int64 Next = (static_cast<int64>(static_cast<uint32>(GX + DX)) << 32)
							| static_cast<int64>(static_cast<uint32>(GY + DY));
						const int32 NextIndex = FindBucket(Next);
						if (NextIndex != -1 && !Visited[NextIndex])
						{
							Visited[NextIndex] = 1;
							Stack.Push(NextIndex);
						}
					}
				}
			}

			// Three-marker floor: on a 9x8 km map, 2-5 tree clumps are yard noise, not
			// biomes - and every zone becomes a campaign stop under AUTO. (Singletons
			// were already dropped; the floor is three so a "zone" is always a place.)
			if (Members.Num() < 3 && !bKeepSingletons)
			{
				continue;
			}

			// The NOT-A-PLACE floor: a zone smaller than 50 m across with fewer than 20
			// markers is a yard clump, not a destination (the user's map grew eight of
			// them: 2-8 trees in 10-56 m circles that were eating campaign slots). A
			// zone must be either big enough to walk around or dense enough to matter.
			{
				float ClumpRadius = 0.f;
				FVector ClumpSum = FVector::ZeroVector;
				for (int32 Index : Members)
				{
					ClumpSum += Points[Index];
				}
				const FVector ClumpCentroid = ClumpSum / static_cast<float>(Members.Num());
				for (int32 Index : Members)
				{
					ClumpRadius = FMath::Max(ClumpRadius, static_cast<float>(FVector::Dist(ClumpCentroid, Points[Index])));
				}
				if (ClumpRadius < 5000.f && Members.Num() < 20 && !bKeepSingletons)
				{
					continue;
				}
			}

			FMapZone Zone;
			Zone.Kind = Kind;
			Zone.PointCount = Members.Num();
			FVector Sum = FVector::ZeroVector;
			for (int32 Index : Members)
			{
				Sum += Points[Index];
			}
			Zone.Center = Sum / static_cast<float>(Members.Num());
			for (int32 Index : Members)
			{
				Zone.RadiusCm = FMath::Max(Zone.RadiusCm, static_cast<float>(FVector::Dist(Zone.Center, Points[Index])));
			}
			// even stride, <=120 points - enough to draw the feature's true shape
			{
				const int32 Step = FMath::Max(1, (Members.Num() + 119) / 120);
				for (int32 Index = 0; Index < Members.Num(); Index += Step)
				{
					Zone.SamplePoints.Add(Points[Members[Index]]);
				}
			}
			Zone.RadiusCm = FMath::Max(Zone.RadiusCm, CellSizeCm * 0.5f);   // visible even when tight
			Out.Add(Zone);
		}

		// Deterministic order: west to east, then south to north.
		Out.Sort([](const FMapZone& A, const FMapZone& B)
		{
			if (A.Center.X != B.Center.X) return A.Center.X < B.Center.X;
			return A.Center.Y < B.Center.Y;
		});
		return Out;
	}

	/** Distance from a point to a polyline (the river corridor test). */
	static float DistanceToPolyline(const FVector& P, const TArray<FVector>& Line)
	{
		if (Line.Num() == 0)
		{
			return FLT_MAX;
		}
		if (Line.Num() == 1)
		{
			return FVector::Dist(P, Line[0]);
		}
		double Best = FLT_MAX;
		for (int32 i = 1; i < Line.Num(); ++i)
		{
			const FVector A = Line[i - 1];
			const FVector B = Line[i];
			const FVector AB = B - A;
			const float LenSq = FVector::DotProduct(AB, AB);
			float T = (LenSq > KINDA_SMALL_NUMBER)
				? FVector::DotProduct(P - A, AB) / LenSq
				: 0.f;
			T = FMath::Clamp(T, 0.f, 1.f);
			Best = FMath::Min(Best, FVector::Dist(P, A + AB * T));
		}
		return static_cast<float>(Best);
	}

	/** Distance from a point to the river SYSTEM - the nearest line among EVERY
	 *  river. A map can carry several rivers; the corridor test must respect all
	 *  of them, not just the first one read. */
	static float DistanceToRivers(const FVector& P, const TArray<TArray<FVector>>& Rivers)
	{
		float Best = FLT_MAX;
		for (const TArray<FVector>& Line : Rivers)
		{
			Best = FMath::Min(Best, DistanceToPolyline(P, Line));
		}
		return Best;
	}

	/** Every river's points, counted. */
	static int32 RiverPointCount(const TArray<TArray<FVector>>& Rivers)
	{
		int32 N = 0;
		for (const TArray<FVector>& Line : Rivers) { N += Line.Num(); }
		return N;
	}

	/** True when at least one polyline actually walks (2+ points). A lone marker
	 *  is a pin in the water, not a river. */
	static bool HasWalkableRiver(const TArray<TArray<FVector>>& Rivers)
	{
		for (const TArray<FVector>& Line : Rivers)
		{
			if (Line.Num() > 1)
			{
				return true;
			}
		}
		return false;
	}

	/**
	 * Merge water lines that are ONE river split across several spline actors:
	 * when the closest pair of endpoints sits within JoinDistCm, the two become
	 * one walkable line (reversed end-for-end as the walk needs). Interior points
	 * are NEVER reordered - each spline's point order is the river's true course.
	 * Truly separate rivers stay separate. Returns the polyline count.
	 */
	static int32 JoinRiverPolylines(TArray<TArray<FVector>>& Rivers, float JoinDistCm = 5000.f)
	{
		auto Rev = [](TArray<FVector>& V)
		{
			for (int32 A = 0, B = V.Num() - 1; A < B; ++A, --B)
			{
				const FVector T = V[A]; V[A] = V[B]; V[B] = T;
			}
		};
		bool bJoined = true;
		while (bJoined && Rivers.Num() > 1)
		{
			bJoined = false;
			for (int32 i = 0; i < Rivers.Num() - 1 && !bJoined; ++i)
			{
				if (Rivers[i].Num() == 0) { continue; }
				for (int32 j = i + 1; j < Rivers.Num() && !bJoined; ++j)
				{
					if (Rivers[j].Num() == 0) { continue; }
					TArray<FVector> A = Rivers[i];
					TArray<FVector> B = Rivers[j];
					const double DL0 = FVector::Dist2D(A.Last(), B[0]);
					const double DLL = FVector::Dist2D(A.Last(), B.Last());
					const double D00 = FVector::Dist2D(A[0], B[0]);
					const double D0L = FVector::Dist2D(A[0], B.Last());
					double Best = DL0;
					int32 Case = 0;
					if (DLL < Best) { Best = DLL; Case = 1; }
					if (D00 < Best) { Best = D00; Case = 2; }
					if (D0L < Best) { Best = D0L; Case = 3; }
					if (Best > JoinDistCm) { continue; }
					TArray<FVector> Merged;
					if (Case == 0)      { Merged = A; Merged.Append(B); }
					else if (Case == 1) { Rev(B); Merged = A; Merged.Append(B); }
					else if (Case == 2) { Rev(A); Merged = A; Merged.Append(B); }
					else                { Rev(B); Merged = B; Merged.Append(A); }
					Rivers[i] = Merged;
					Rivers.RemoveAt(j);
					bJoined = true;
				}
			}
		}
		return Rivers.Num();
	}

	/** The river corridor half-width: missions never spawn closer than this to the water. */
	static float RiverKeepOutCm() { return 1200.f; }

	/** The flatness BONUS ceiling: a zone whose ground rises/falls at most this much
	 *  counts as workable ground and out-scores a same-kind zone on a slope - fights
	 *  and objectives read best where the player can actually stand and fight. */
	static float FlatBonusMaxCm() { return 800.f; }

	/** The ground's character in one word, from the measured drop inside a zone.
	 *  <= 2 m of relief is table-flat; <= 8 m rolls; more is steep. Unknown says so. */
	static const TCHAR* TerrainWord(float HeightSpreadCm)
	{
		if (HeightSpreadCm < 0.f)    { return TEXT("unscanned"); }
		if (HeightSpreadCm <= 200.f) { return TEXT("table-flat"); }
		if (HeightSpreadCm <= 800.f) { return TEXT("rolling"); }
		return TEXT("steep");
	}

	/** True when a zone is KNOWN flat (scanned AND within the bonus ceiling). */
	static bool IsFlatGround(const FMapZone& Z)
	{
		return Z.HeightSpreadCm >= 0.f && Z.HeightSpreadCm <= FlatBonusMaxCm();
	}

	/** The zone's TACTICAL role in one phrase - what this ground is good for. From
	 *  its kind, size and measured relief: high ground forts on steep rises, tank
	 *  country on big open flats, deep forest for close fighting, cover woods,
	 *  hilltop bunkers. This is the words the mission designer reads. */
	static const TCHAR* ZoneRole(const FMapZone& Z)
	{
		const bool bSteep = Z.HeightSpreadCm >= 4000.f;      // 40 m+ of relief
		if (Z.Kind == EMapFeatureKind::Trench)
		{
			if (Z.RadiusCm >= 100000.f)                      // a km+ of ground
			{
				return bSteep ? TEXT("high-ground forts + armor ground")
								: TEXT("open tank country");
			}
			return bSteep ? TEXT("a hilltop bunker line") : TEXT("a forward trench line");
		}
		if (Z.RadiusCm >= 40000.f)                           // 400 m+ of woods
		{
			return TEXT("deep forest - close fighting under cover");
		}
		if (Z.RadiusCm >= 15000.f)
		{
			return TEXT("cover woods");
		}
		return TEXT("scattered cover");
	}

	/** Crossing sites per river: vertices that touch ANOTHER river (a junction to
	 *  bridge) or a non-adjacent vertex of their OWN river (a meander neck a ford
	 *  or footbridge fits in). One ford per 300 m stretch; fully deterministic. */
	static TArray<TArray<FVector>> FindRiverFords(const TArray<TArray<FVector>>& Rivers,
		float FordGapCm = 30000.f)
	{
		TArray<TArray<FVector>> Fords;
		for (int32 R = 0; R < Rivers.Num(); ++R)
		{
			TArray<FVector> Out;
			const TArray<FVector>& Line = Rivers[R];
			for (int32 i = 0; i < Line.Num(); ++i)
			{
				bool bFord = false;
				for (int32 R2 = 0; R2 < Rivers.Num() && !bFord; ++R2)   // junctions
				{
					if (R2 == R) { continue; }
					for (const FVector& Q : Rivers[R2])
					{
						if (FVector::Dist2D(Line[i], Q) <= FordGapCm) { bFord = true; break; }
					}
				}
				for (int32 j = 0; j < Line.Num() && !bFord; ++j)         // meander necks
				{
					if (FMath::Abs(i - j) < 2) { continue; }
					if (FVector::Dist2D(Line[i], Line[j]) <= FordGapCm) { bFord = true; }
				}
				if (bFord)
				{
					bool bDup = false;
					for (const FVector& K : Out)
					{
						if (FVector::Dist2D(K, Line[i]) <= FordGapCm) { bDup = true; break; }
					}
					if (!bDup) { Out.Add(Line[i]); }
				}
			}
			Fords.Add(Out);
		}
		return Fords;
	}

	// -----------------------------------------------------------------------------------------
	//  the scatter solver
	// -----------------------------------------------------------------------------------------

	/**
	 * The plan. Deterministic: no RNG anywhere. The anchor (usually the player start)
	 * becomes the HQ Defend mission; then candidates are greedily chosen - best kind
	 * first (trench 3, biome 2, river-edge 2, open 1), ties broken by spreading OUT
	 * from the HQ - under `MinSeparationCm` from every accepted spot and every
	 * existing mission. River-adjacent candidates become the extraction; candidates
	 * inside the river keep-out are skipped entirely.
	 *
	 * S26-SPREAD: MaxSpreadCm > 0 keeps the campaign on a TIGHT FRONT - trench and
	 * biome candidates farther than that from the anchor are never considered.
	 * The river is exempt (the finale must survive any radius); 0 = the whole map.
	 */
	static TArray<FMissionSpot> BuildScatterPlan(const TArray<FMapZone>& TrenchZones,
		const TArray<FMapZone>& BiomeZones, const TArray<TArray<FVector>>& Rivers,
		const FVector& Anchor, const TArray<FVector>& ExistingMissions,
		int32 MissionCount, float MinSeparationCm = 15000.f, double MaxSpreadCm = 0.0)
	{
		TArray<FMissionSpot> Spots;
		const float MinSep = FMath::Max(5000.f, MinSeparationCm);
		const int32 Want = FMath::Max(1, MissionCount);

		auto FarFromAccepted = [&](const FVector& P) -> bool
		{
			for (const FMissionSpot& S : Spots)
			{
				if (FVector::Dist2D(P, S.Position) < MinSep)
				{
					return false;
				}
			}
			for (const FVector& E : ExistingMissions)
			{
				if (FVector::Dist2D(P, E) < MinSep)
				{
					return false;
				}
			}
			return true;
		};

		// -- 1. the HQ -------------------------------------------------------------
		FMissionSpot HQ;
		HQ.Position = Anchor;
		HQ.Kind = EMissionSpotKind::HQDefend;
		HQ.Reason = TEXT("the anchor point: hold the line and protect the asset");
		Spots.Add(HQ);

		// -- 2. the candidates --------------------------------------------------------
		struct FCandidate { FVector P; EMissionSpotKind Kind; int32 Score; float DistFromHQ; int32 ZoneMarkers = 0; };
		TArray<FCandidate> Candidates;

		for (const FMapZone& Zone : TrenchZones)
		{
			if (MaxSpreadCm > 0.0 && FVector::Dist2D(Zone.Center, Anchor) > MaxSpreadCm)
			{
				continue;   // S26-SPREAD: outside the campaign front
			}
			if (FMath::Max(0.f, DistanceToRivers(Zone.Center, Rivers)) >= RiverKeepOutCm())
			{
				FCandidate C;
				C.P = Zone.Center;
				C.Kind = EMissionSpotKind::TrenchAssault;
				C.Score = 3 + (IsFlatGround(Zone) ? 1 : 0);   // fights on workable ground
				C.ZoneMarkers = Zone.PointCount;
				C.DistFromHQ = static_cast<float>(FVector::Dist2D(Zone.Center, Anchor));
				Candidates.Add(C);
			}
		}
		for (const FMapZone& Zone : BiomeZones)
		{
			if (MaxSpreadCm > 0.0 && FVector::Dist2D(Zone.Center, Anchor) > MaxSpreadCm)
			{
				continue;   // S26-SPREAD: outside the campaign front
			}
			if (DistanceToRivers(Zone.Center, Rivers) >= RiverKeepOutCm())
			{
				FCandidate C;
				C.P = Zone.Center;
				C.Kind = EMissionSpotKind::BiomeRecon;
				C.Score = 2 + (IsFlatGround(Zone) ? 1 : 0);   // the camp you can pitch
				C.ZoneMarkers = Zone.PointCount;
				C.DistFromHQ = static_cast<float>(FVector::Dist2D(Zone.Center, Anchor));
				Candidates.Add(C);
			}
		}
		// Every other vertex of EVERY river is a crossing candidate.
		for (const TArray<FVector>& Line : Rivers)
		{
			for (int32 i = 0; i < Line.Num(); i += 2)
			{
				FCandidate C;
				C.P = Line[i];
				C.Kind = EMissionSpotKind::RiverExtraction;
				C.Score = 2;
				C.DistFromHQ = static_cast<float>(FVector::Dist2D(Line[i], Anchor));
				Candidates.Add(C);
			}
		}

		// -- 3. the greedy pick --------------------------------------------------------
		// Variety rule: ONE river crossing per plan (the mission needs a pad, not five),
		// otherwise far-apart river vertices out-score every other feature on the
		// spread tie-break and the plan degenerates into pads along the water.
		// FINALE RESERVE: after the greedy, if the plan has no river crossing (a
		// feature-rich map can fill every slot before the river ever wins one - the
		// user's: 21 features vs the old 16-act cap), the LAST non-HQ act is swapped for the
		// best crossing. Deterministic; the ending is never cut.
		bool bHasRiver = false;
		for (const FCandidate& C : Candidates)
		{
			if (C.Kind == EMissionSpotKind::RiverExtraction) { bHasRiver = true; break; }
		}
		int32 RiverSpots = 0;
		for (const FMissionSpot& S : Spots)
		{
			RiverSpots += (S.Kind == EMissionSpotKind::RiverExtraction) ? 1 : 0;
		}
		bool bProgress = true;
		while (Spots.Num() < Want && bProgress)
		{
			bProgress = false;
			int32 BestIndex = -1;
			for (int32 i = 0; i < Candidates.Num(); ++i)
			{
				if (!FarFromAccepted(Candidates[i].P))
				{
					continue;
				}
				if (Candidates[i].Kind == EMissionSpotKind::RiverExtraction && RiverSpots >= 1)
				{
					continue;
				}
				if (BestIndex == -1
					|| Candidates[i].Score > Candidates[BestIndex].Score
					|| (Candidates[i].Score == Candidates[BestIndex].Score
						&& Candidates[i].DistFromHQ > Candidates[BestIndex].DistFromHQ))
				{
					BestIndex = i;
				}
			}
			if (BestIndex == -1)
			{
				break;
			}
			const FCandidate& C = Candidates[BestIndex];
			FMissionSpot Spot;
			Spot.Position = C.P;
			Spot.Kind = C.Kind;
			Spot.ZoneMarkers = C.ZoneMarkers;
			if (C.Kind == EMissionSpotKind::RiverExtraction)
			{
				++RiverSpots;
			}
			Spots.Add(Spot);
			Candidates.RemoveAt(BestIndex);
			bProgress = true;
		}
		if (Want > 1 && bHasRiver && RiverSpots == 0 && Spots.Num() > 1)
		{
			int32 Victim = -1;
			for (int32 i = Spots.Num() - 1; i >= 1; --i)
			{
				if (Spots[i].Kind != EMissionSpotKind::HQDefend) { Victim = i; break; }
			}
			if (Victim != -1)
			{
				const FMissionSpot Bumped = Spots[Victim];
				Spots.RemoveAt(Victim);   // measure the crossing against the plan WITHOUT it
				int32 BestRiver = -1;
				for (int32 i = 0; i < Candidates.Num(); ++i)
				{
					if (Candidates[i].Kind != EMissionSpotKind::RiverExtraction || !FarFromAccepted(Candidates[i].P))
					{
						continue;
					}
					if (BestRiver == -1
						|| Candidates[i].Score > Candidates[BestRiver].Score
						|| (Candidates[i].Score == Candidates[BestRiver].Score
							&& Candidates[i].DistFromHQ > Candidates[BestRiver].DistFromHQ))
					{
						BestRiver = i;
					}
				}
				if (BestRiver != -1)
				{
					FMissionSpot Finale;
					Finale.Position = Candidates[BestRiver].P;
					Finale.Kind = EMissionSpotKind::RiverExtraction;
					Spots.Add(Finale);   // the reasons pass below gives it the crossing words
				}
				else
				{
					Spots.Add(Bumped);   // the victim is the last act (single HQ at 0) - nothing to swap in
				}
			}
		}

		// -- 4. the reasons ---------------------------------------------------------------
		for (FMissionSpot& Spot : Spots)
		{
			if (!Spot.Reason.IsEmpty())
			{
				continue;   // the HQ already carries its own reasoning
			}
			switch (Spot.Kind)
			{
			case EMissionSpotKind::TrenchAssault:
			{
				const FMapZone* Nearest = nullptr;
				float Best = FLT_MAX;
				for (const FMapZone& Zone : TrenchZones)
				{
					const float D = static_cast<float>(FVector::Dist2D(Spot.Position, Zone.Center));
					if (D < Best) { Best = D; Nearest = &Zone; }
				}
				Spot.Reason = Nearest
					? FString::Printf(TEXT("on the trench line (%d crate markers)%s"), Nearest->PointCount,
						IsFlatGround(*Nearest) ? TEXT(" - flat ground") : TEXT(""))
					: TEXT("on a trench line");
				break;
			}
			case EMissionSpotKind::BiomeRecon:
			{
				const FMapZone* Nearest = nullptr;
				float Best = FLT_MAX;
				for (const FMapZone& Zone : BiomeZones)
				{
					const float D = static_cast<float>(FVector::Dist2D(Spot.Position, Zone.Center));
					if (D < Best) { Best = D; Nearest = &Zone; }
				}
				Spot.Reason = Nearest
					? FString::Printf(TEXT("under the trees (%d tree markers - %s ground) - a quiet recon job"),
						Nearest->PointCount, TerrainWord(Nearest->HeightSpreadCm))
					: TEXT("in a biome");
				break;
			}
			case EMissionSpotKind::RiverExtraction:
				Spot.Reason = TEXT("on the river line - the pad sits where you would cross");
				break;
			default:
				Spot.Reason = TEXT("open ground - room for a convoy run");
				break;
			}
		}
		return Spots;
	}

	// -----------------------------------------------------------------------------------------
	//  the story pass: a CAMPAIGN, not a pile of pins
	//  The map writes the plot: hold the HQ, break the trench line nearest-first, slip
	//  through the trees, run the open road - and the river crossing is ALWAYS the finale.
	// -----------------------------------------------------------------------------------------

	/** The play order for a scattered plan: a WALKING TOUR of the whole map. From the
	 *  current position the nearest not-yet-visited act is always next (kind breaks
	 *  ties, then X, then Y - never random), so the campaign sweeps the ground instead
	 *  of criss-crossing it and the player is walked past EVERY feature. The HQ opens;
	 *  the river crossing is pinned to the very end - the finale belongs at the water. */
	static TArray<FMissionSpot> ArrangeAsStory(const FVector& Anchor, const TArray<FMissionSpot>& Spots)
	{
		TArray<FMissionSpot> Tour;     // the non-river acts, in walk order
		TArray<FMissionSpot> Finale;   // river crossings: ALWAYS last
		FMissionSpot HQ;
		bool bHasHQ = false;
		for (const FMissionSpot& S : Spots)
		{
			if (S.Kind == EMissionSpotKind::HQDefend && !bHasHQ)
			{
				HQ = S;
				bHasHQ = true;         // the HQ is act one, always
			}
			else if (S.Kind == EMissionSpotKind::RiverExtraction)
			{
				Finale.Add(S);
			}
			else
			{
				Tour.Add(S);
			}
		}

		TArray<FMissionSpot> Story;
		if (bHasHQ)
		{
			Story.Add(HQ);
		}
		FVector Cursor = bHasHQ ? HQ.Position : Anchor;
		while (Tour.Num() > 0)
		{
			int32 Best = -1;
			double BestD = 1.0e30;
			for (int32 i = 0; i < Tour.Num(); ++i)
			{
				const double DX = Tour[i].Position.X - Cursor.X;
				const double DY = Tour[i].Position.Y - Cursor.Y;
				const double D = DX * DX + DY * DY;
				bool bBetter = (Best == -1);
				if (!bBetter && D <= BestD + 0.01)   // a real tie: story rank, then X, then Y
				{
					const int32 Ranks[3] =
					{
						(int32)EMissionSpotKind::TrenchAssault,
						(int32)EMissionSpotKind::BiomeRecon,
						(int32)EMissionSpotKind::OpenConvoy,
					};
					int32 RankI = 2, RankB = 2;
					for (int32 r = 0; r < 3; ++r)
					{
						if ((int32)Tour[i].Kind == Ranks[r]) { RankI = r; break; }
					}
					for (int32 r = 0; r < 3; ++r)
					{
						if ((int32)Tour[Best].Kind == Ranks[r]) { RankB = r; break; }
					}
					bBetter = RankI < RankB;
					if (!bBetter && RankI == RankB)
					{
						const double BX = Tour[Best].Position.X;
						const double BY = Tour[Best].Position.Y;
						const double X = Tour[i].Position.X;
						const double Y = Tour[i].Position.Y;
						bBetter = (X < BX - 0.01) || (X <= BX + 0.01 && Y < BY - 0.01);
					}
				}
				if (bBetter || D < BestD - 0.01)
				{
					BestD = D;
					Best = i;
				}
			}
			Cursor = Tour[Best].Position;
			Story.Add(Tour[Best]);
			Tour.RemoveAt(Best);
		}
		for (const FMissionSpot& S : Finale)   // the water ends the campaign, always
		{
			Story.Add(S);
		}
		return Story;
	}

	/** The full campaign in one call: the geometric scatter, ordered into a story, each
	 *  act numbered and given its words. Same map in, same campaign out - byte for byte. */
	static TArray<FMissionSpot> BuildStoryPlan(const TArray<FMapZone>& TrenchZones,
		const TArray<FMapZone>& BiomeZones, const TArray<TArray<FVector>>& Rivers,
		const FVector& Anchor, const TArray<FVector>& ExistingMissions,
		int32 Want, float MinSeparationCm, double MaxSpreadCm = 0.0)
	{
		TArray<FMissionSpot> Plan = BuildScatterPlan(TrenchZones, BiomeZones, Rivers,
			Anchor, ExistingMissions, Want, MinSeparationCm, MaxSpreadCm);
		Plan = ArrangeAsStory(Anchor, Plan);

		int32 TrenchSeen = 0;
		int32 BiomeSeen = 0;
		for (int32 i = 0; i < Plan.Num(); ++i)
		{
			FMissionSpot& S = Plan[i];
			S.ActIndex = i + 1;
			const int32 N = i + 1;
			switch (S.Kind)
			{
			case EMissionSpotKind::HQDefend:
				S.StoryLine = FString::Printf(TEXT("Act %d - the opening: hold the HQ and the operation has a spine."), N);
				break;
			case EMissionSpotKind::TrenchAssault:
				++TrenchSeen;
				// the words follow the GROUND: a fortress is not a bunker is not a line
				if (TrenchSeen == 1)
				{
					S.StoryLine = FString::Printf(TEXT("Act %d - the line breaks here first: take the trench and their front starts to fold."), N);
				}
				else if (S.ZoneMarkers >= 2000)
				{
					S.StoryLine = FString::Printf(TEXT("Act %d - their fortress ground: %d markers of held earth - take it and the region folds."), N, S.ZoneMarkers);
				}
				else if (S.ZoneMarkers > 0 && S.ZoneMarkers < 100)
				{
					S.StoryLine = FString::Printf(TEXT("Act %d - the hilltop bunker goes dark: one less eye on every move you make."), N);
				}
				else
				{
					S.StoryLine = FString::Printf(TEXT("Act %d - keep the push going: this trench falls, the whole line folds with it."), N);
				}
				break;
			case EMissionSpotKind::BiomeRecon:
				++BiomeSeen;
				// deep forest, cover woods and scrub do NOT read as the same job
				if (S.ZoneMarkers >= 4000)
				{
					S.StoryLine = FString::Printf(TEXT("Act %d - deep-woods work: hunt their patrols where %d trees hide them - and not you."), N, S.ZoneMarkers);
				}
				else if (S.ZoneMarkers > 0 && S.ZoneMarkers < 1000)
				{
					S.StoryLine = FString::Printf(TEXT("Act %d - a fast sweep through scattered cover: eyes on the ground, then move."), N);
				}
				else if (BiomeSeen == 1)
				{
					S.StoryLine = FString::Printf(TEXT("Act %d - slip into the trees: a quiet recon while they are busy at the front."), N);
				}
				else
				{
					S.StoryLine = FString::Printf(TEXT("Act %d - deeper into the woods: one more quiet job before the water."), N);
				}
				break;
			case EMissionSpotKind::OpenConvoy:
				S.StoryLine = FString::Printf(TEXT("Act %d - with the line broken the road is open: run the convoy through."), N);
				break;
			default:
				S.StoryLine = FString::Printf(TEXT("Act %d - the finale: everything ends at the water - take the crossing and hold it."), N);
				break;
			}
		}
		return Plan;
	}

	// -----------------------------------------------------------------------------------------
	//  reading the map OUT LOUD - the log explains the map with every detail
	// -----------------------------------------------------------------------------------------

	/** The bounds of everything readable (zones, river, anchor). False if there is
	 *  nothing readable at all. */
	static bool LayoutBounds(const TArray<FMapZone>& TrenchZones,
		const TArray<FMapZone>& BiomeZones, const TArray<TArray<FVector>>& Rivers,
		const FVector& Anchor, double& MinX, double& MaxX, double& MinY, double& MaxY)
	{
		MinX = MinY = DBL_MAX;
		MaxX = MaxY = -DBL_MAX;
		auto Grow = [&](const FVector& P, double R)
		{
			MinX = FMath::Min(MinX, (double)P.X - R);
			MaxX = FMath::Max(MaxX, (double)P.X + R);
			MinY = FMath::Min(MinY, (double)P.Y - R);
			MaxY = FMath::Max(MaxY, (double)P.Y + R);
		};
		for (const FMapZone& Z : TrenchZones) { Grow(Z.Center, Z.RadiusCm); }
		for (const FMapZone& Z : BiomeZones)  { Grow(Z.Center, Z.RadiusCm); }
		for (const TArray<FVector>& Line : Rivers)
		{
			for (const FVector& P : Line)    { Grow(P, 0.0); }
		}
		Grow(Anchor, 0.0);
		// the anchor alone is NOT a readable map - without features there is nothing to describe
		const bool bAnyFeature = TrenchZones.Num() > 0 || BiomeZones.Num() > 0 || HasWalkableRiver(Rivers);
		return bAnyFeature && MinX <= MaxX && MinY <= MaxY;
	}

	/** A "north-west"-style compass word for a position inside the given bounds.
	 *  Deterministic; the middle quarter of each axis reads as no direction. */
	static const TCHAR* CompassWord(double X, double Y,
		double MinX, double MaxX, double MinY, double MaxY)
	{
		const double CX = (MinX + MaxX) * 0.5;
		const double CY = (MinY + MaxY) * 0.5;
		const double DeadX = (MaxX - MinX) * 0.25;
		const double DeadY = (MaxY - MinY) * 0.25;
		const bool bWest = X < CX - DeadX;
		const bool bEast = X > CX + DeadX;
		const bool bNorth = Y > CY + DeadY;
		const bool bSouth = Y < CY - DeadY;
		if (bNorth && bWest) return TEXT("north-west");
		if (bNorth && bEast) return TEXT("north-east");
		if (bSouth && bWest) return TEXT("south-west");
		if (bSouth && bEast) return TEXT("south-east");
		if (bNorth) return TEXT("the north");
		if (bSouth) return TEXT("the south");
		if (bWest)  return TEXT("the west");
		if (bEast)  return TEXT("the east");
		return TEXT("the middle of the map");
	}

	/** The map explained in words - THE brief a human reads in the log before anything
	 *  is stamped: how big the world is, where the HQ sits, every zone with its compass
	 *  side and size, how far apart the fights are, where the river runs. */
	static FString DescribeLayout(const TArray<FMapZone>& TrenchZones,
		const TArray<FMapZone>& BiomeZones, const TArray<TArray<FVector>>& Rivers,
		const FVector& Anchor)
	{
		double MinX, MaxX, MinY, MaxY;
		if (!LayoutBounds(TrenchZones, BiomeZones, Rivers, Anchor, MinX, MaxX, MinY, MaxY))
		{
			return TEXT("the map has no readable features yet - place or paint crates, trees and water first.\n");
		}
		const double SizeX = MaxX - MinX;
		const double SizeY = MaxY - MinY;
		const double Diag = FMath::Sqrt(SizeX * SizeX + SizeY * SizeY);

		FString W;
		W += FString::Printf(TEXT("the map reads as about %.1f x %.1f km (diagonal %.1f km), covering about %.0f sq km.\n"),
			SizeX / 100000.0, SizeY / 100000.0, Diag / 100000.0, SizeX * SizeY / 1.0e10);
		W += FString::Printf(TEXT("your start (the HQ anchor) sits in %s at (%.0f, %.0f).\n"),
			CompassWord(Anchor.X, Anchor.Y, MinX, MaxX, MinY, MaxY),
			Anchor.X / 100.0, Anchor.Y / 100.0);

		if (TrenchZones.Num() > 0)
		{
			W += FString::Printf(TEXT("%d trench zone(s): "), TrenchZones.Num());
			for (int32 i = 0; i < TrenchZones.Num(); ++i)
			{
				const FMapZone& Z = TrenchZones[i];
				const FString Terr = Z.HeightSpreadCm >= 0.f
					? FString::Printf(TEXT(", terrain %s (drop %.0f m)"),
						TerrainWord(Z.HeightSpreadCm), Z.HeightSpreadCm / 100.0)
					: FString();
				const FString Role = FString::Printf(TEXT(", good for %s"), ZoneRole(Z));
				W += FString::Printf(TEXT("%s at (%.0f, %.0f) r=%.0f m, %d crates%s%s%s"),
					CompassWord(Z.Center.X, Z.Center.Y, MinX, MaxX, MinY, MaxY),
					Z.Center.X / 100.0, Z.Center.Y / 100.0, Z.RadiusCm / 100.0, Z.PointCount,
					*Terr, *Role, i + 1 < TrenchZones.Num() ? TEXT("; ") : TEXT(".\n"));
			}
		}
		else
		{
			W += TEXT("no trench zones found - crates not matched (check the crate tokens).\n");
		}

		if (BiomeZones.Num() > 0)
		{
			W += FString::Printf(TEXT("%d biome zone(s): "), BiomeZones.Num());
			for (int32 i = 0; i < BiomeZones.Num(); ++i)
			{
				const FMapZone& Z = BiomeZones[i];
				const FString Terr = Z.HeightSpreadCm >= 0.f
					? FString::Printf(TEXT(", terrain %s (drop %.0f m)"),
						TerrainWord(Z.HeightSpreadCm), Z.HeightSpreadCm / 100.0)
					: FString();
				const FString Role = FString::Printf(TEXT(", good for %s"), ZoneRole(Z));
				W += FString::Printf(TEXT("%s at (%.0f, %.0f) r=%.0f m, %d trees%s%s%s"),
					CompassWord(Z.Center.X, Z.Center.Y, MinX, MaxX, MinY, MaxY),
					Z.Center.X / 100.0, Z.Center.Y / 100.0, Z.RadiusCm / 100.0, Z.PointCount,
					*Terr, *Role, i + 1 < BiomeZones.Num() ? TEXT("; ") : TEXT(".\n"));
			}
		}
		else
		{
			W += TEXT("no biome zones found - trees not matched (check the tree tokens).\n");
		}

		// EVERY river is described on its own line - never one welded fake river.
		int32 Walkable = 0;
		for (const TArray<FVector>& Line : Rivers)
		{
			if (Line.Num() > 1) { ++Walkable; }
		}
		if (Walkable > 0)
		{
			int32 K = 0;
			double Total = 0.0;
			for (const TArray<FVector>& Line : Rivers)
			{
				if (Line.Num() < 2) { continue; }
				++K;
				double Len = 0.0;
				for (int32 i = 1; i < Line.Num(); ++i)
				{
					Len += FVector::Dist2D(Line[i - 1], Line[i]);
				}
				Total += Len;
				W += FString::Printf(TEXT("river %d: %d point(s), about %.0f m - enters at %s, leaves at %s.%s"),
					K, Line.Num(), Len / 100.0,
					CompassWord(Line[0].X, Line[0].Y, MinX, MaxX, MinY, MaxY),
					CompassWord(Line.Last().X, Line.Last().Y, MinX, MaxX, MinY, MaxY),
					TEXT("\n"));
			}
			if (Walkable > 1)
			{
				W += FString::Printf(TEXT("%d separate rivers, about %.0f m of water line in total.\n"),
					Walkable, Total / 100.0);
			}
		}
		else
		{
			W += TEXT("no river line found - the campaign will not have a water finale.\n");
		}
		return W;
	}

	/** How many acts the ONE campaign should run. Want <= 0 means AUTO: the HQ, EVERY
	 *  trench, EVERY biome and the river crossing, capped at 28 - the whole map becomes
	 *  the campaign and the player is walked past every feature on it (the rule: no
	 *  corner of a 9-km open world goes unvisited). An explicit Want is clamped 1..28. */
	static int32 PickMissionCount(const TArray<FMapZone>& TrenchZones,
		const TArray<FMapZone>& BiomeZones, bool bHasRiver, int32 Want)
	{
		if (Want <= 0)
		{
			return FMath::Clamp(1 + TrenchZones.Num() + BiomeZones.Num() + (bHasRiver ? 1 : 0), 1, 28);
		}
		return FMath::Clamp(Want, 1, 28);
	}

	/** Total ground between the acts in cm - how much map the campaign walks. */
	static float StoryRouteLengthCm(const TArray<FMissionSpot>& Spots)
	{
		double Total = 0.0;
		for (int32 i = 1; i < Spots.Num(); ++i)
		{
			Total += FVector::Dist2D(Spots[i - 1].Position, Spots[i].Position);
		}
		return static_cast<float>(Total);
	}

	/** The kind's display name for the report. */
	static const TCHAR* SpotKindName(EMissionSpotKind K)
	{
		switch (K)
		{
		case EMissionSpotKind::HQDefend:        return TEXT("HQ DEFEND");
		case EMissionSpotKind::TrenchAssault:   return TEXT("TRENCH ASSAULT");
		case EMissionSpotKind::BiomeRecon:      return TEXT("BIOME RECON");
		case EMissionSpotKind::RiverExtraction: return TEXT("RIVER EXTRACTION");
		default:                                return TEXT("OPEN CONVOY");
		}
	}

	// -----------------------------------------------------------------------------------------
	//  the map (SVG)
	// -----------------------------------------------------------------------------------------

	/**
	 * A top-down map of the plan as an SVG string. X maps right, Y maps DOWN-flipped
	 * (north up), everything scaled into a ~900 px wide image with a legend, a scale
	 * bar, the grid every 50 m, and the missions pinned and numbered in pick order.
	 */
	static FString BuildScatterSVG(const TArray<FMapZone>& TrenchZones,
		const TArray<FMapZone>& BiomeZones, const TArray<TArray<FVector>>& Rivers,
		const TArray<FMissionSpot>& Spots, const TArray<FVector>& ExistingMissions,
		const FVector& Anchor, float GridStepCm = 5000.f,
		const TArray<FVector>& CratePoints = TArray<FVector>(),
		const TArray<FVector>& TreePoints = TArray<FVector>())
	{
		// -- the bounds ------------------------------------------------------------
		// S26-MAPART: this is a MAP SHEET now - margins for coordinate labels, a
		// frame, a compass, a scale bar, hatched zones, arrowed route legs with
		// distances, drop pins, a legend panel and a stats footer. Every layer
		// is optional data: absent rivers/zones/spots simply draw nothing.
		double MinX = FLT_MAX, MaxX = -FLT_MAX, MinY = FLT_MAX, MaxY = -FLT_MAX;
		auto Grow = [&](const FVector& P)
		{
			MinX = FMath::Min(MinX, P.X); MaxX = FMath::Max(MaxX, P.X);
			MinY = FMath::Min(MinY, P.Y); MaxY = FMath::Max(MaxY, P.Y);
		};
		Grow(Anchor);
		for (const FMapZone& Z : TrenchZones) { Grow(Z.Center); }
		for (const FMapZone& Z : BiomeZones)  { Grow(Z.Center); }
		for (const TArray<FVector>& Line : Rivers)
		{
			for (const FVector& P : Line)    { Grow(P); }
		}
		for (const FVector& P : ExistingMissions) { Grow(P); }
		for (const FMissionSpot& S : Spots)   { Grow(S.Position); }
		if (MinX > MaxX || MinY > MaxY)
		{
			MinX = MinY = 0.f; MaxX = MaxY = 10000.f;
		}
		const double Pad = FMath::Max(3000.0, (MaxX - MinX) * 0.06);
		MinX -= Pad; MaxX += Pad; MinY -= Pad; MaxY += Pad;

		const double W = FMath::Max(1.0, MaxX - MinX);
		const double H = FMath::Max(1.0, MaxY - MinY);
		// the sheet: map plate + margins for the chrome (labels, scale bar)
		const double ML = 64.0, MR = 24.0, MT = 46.0, MB = 66.0;
		const double MapW = 900.0;
		const double MapH = MapW * (H / W);
		const double ImgW = MapW + ML + MR;
		const double ImgH = MapH + MT + MB;
		const double Scale = MapW / W;
		auto PX = [&](const FVector& P) -> float { return static_cast<float>(ML + (P.X - MinX) * Scale); };
		auto PY = [&](const FVector& P) -> float { return static_cast<float>(MT + MapH - (P.Y - MinY) * Scale); };  // north up

		FString S;
		S += FString::Printf(TEXT("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"%.0f\" height=\"%.0f\" viewBox=\"0 0 %.0f %.0f\">\n"), ImgW, ImgH, ImgW, ImgH);
		S += TEXT("<rect width=\"100%\" height=\"100%\" fill=\"#f2efe6\"/>\n");
		// defs: the hatch (trench) and stipple (biome) overlays
		S += TEXT("<defs>"
			"<pattern id=\"trenchhatch\" width=\"7\" height=\"7\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\">"
			"<line x1=\"0\" y1=\"0\" x2=\"0\" y2=\"7\" stroke=\"#5c421f\" stroke-width=\"1.6\" stroke-opacity=\"0.5\"/>"
			"</pattern>"
			"<pattern id=\"biomestipple\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\">"
			"<circle cx=\"2\" cy=\"2\" r=\"1.1\" fill=\"#2e5c2b\" fill-opacity=\"0.45\"/>"
			"<circle cx=\"6.5\" cy=\"6.5\" r=\"1.1\" fill=\"#2e5c2b\" fill-opacity=\"0.45\"/>"
			"</pattern>"
			"</defs>\n");

		// -- the sheet frame + corner ticks -----------------------------------------
		S += FString::Printf(TEXT("<rect x=\"%.0f\" y=\"%.0f\" width=\"%.0f\" height=\"%.0f\" fill=\"#faf7ee\" stroke=\"#8b8270\" stroke-width=\"2\"/>\n"),
			ML - 8.0, MT - 8.0, MapW + 16.0, MapH + 16.0);
		S += FString::Printf(TEXT("<rect x=\"%.0f\" y=\"%.0f\" width=\"%.0f\" height=\"%.0f\" fill=\"none\" stroke=\"#b7ae98\" stroke-width=\"1\"/>\n"),
			ML - 3.0, MT - 3.0, MapW + 6.0, MapH + 6.0);
		{
			const double CX[4] = { ML - 8.0, ML + MapW + 8.0, ML - 8.0, ML + MapW + 8.0 };
			const double CY[4] = { MT - 8.0, MT - 8.0, MT + MapH + 8.0, MT + MapH + 8.0 };
			const double DX[4] = { 1, -1, 1, -1 };
			const double DY[4] = { 1, 1, -1, -1 };
			for (int32 c = 0; c < 4; ++c)
			{
				S += FString::Printf(TEXT("<path d=\"M %.0f %.0f l %.0f 0 M %.0f %.0f l 0 %.0f\" stroke=\"#5a5347\" stroke-width=\"2.5\" fill=\"none\"/>\n"),
					CX[c], CY[c], 16.0 * DX[c], CX[c], CY[c], 16.0 * DY[c]);
			}
		}

		// -- the title block ----------------------------------------------------------
		S += FString::Printf(TEXT("<text x=\"%.0f\" y=\"22\" font-family=\"monospace\" font-size=\"15\" font-weight=\"bold\" fill=\"#333330\">SQUADAI - CAMPAIGN MISSION SCATTER</text>\n"), ML - 8.0);
		S += FString::Printf(TEXT("<text x=\"%.0f\" y=\"37\" font-family=\"monospace\" font-size=\"11\" fill=\"#555550\">%d spot(s) - story order 1..%d - north up - grid %.0f m - sheet %.1f x %.1f km</text>\n"),
			ML - 8.0, Spots.Num(), Spots.Num(), GridStepCm / 100.f, W / 100000.0, H / 100000.0);

		// -- the compass rose (top-right of the plate) ---------------------------------
		{
			const double NCX = ML + MapW - 34.0;
			const double NCY = MT + 34.0;
			S += FString::Printf(TEXT("<circle cx=\"%.0f\" cy=\"%.0f\" r=\"19\" fill=\"#faf7ee\" fill-opacity=\"0.85\" stroke=\"#8b8270\" stroke-width=\"1.2\"/>\n"), NCX, NCY);
			S += FString::Printf(TEXT("<polygon points=\"%.0f,%.0f %.0f,%.0f %.0f,%.0f\" fill=\"#333330\"/>\n"), NCX, NCY - 16.0, NCX - 5.0, NCY + 4.0, NCX + 5.0, NCY + 4.0);
			S += FString::Printf(TEXT("<polygon points=\"%.0f,%.0f %.0f,%.0f %.0f,%.0f\" fill=\"none\" stroke=\"#8b8270\" stroke-width=\"1\"/>\n"), NCX, NCY + 14.0, NCX - 4.0, NCY + 5.0, NCX + 4.0, NCY + 5.0);
			S += FString::Printf(TEXT("<text x=\"%.0f\" y=\"%.0f\" font-family=\"monospace\" font-size=\"10\" font-weight=\"bold\" fill=\"#333330\" text-anchor=\"middle\">N</text>\n"), NCX, NCY - 19.0);
		}

		// -- the grid + edge coordinate labels -------------------------------------------
		{
			const int32 NX = FMath::Max(1, FMath::CeilToInt(W / GridStepCm));
			const int32 LabelEvery = FMath::Max(1, (NX + 11) / 12);   // ~12 labels max per edge
			int32 IX = 0;
			for (float GX = MinX; GX <= MaxX; GX += GridStepCm, ++IX)
			{
				const float X = ML + (float)((GX - MinX) * Scale);
				const bool bMajor = (IX % LabelEvery == 0);
				S += FString::Printf(TEXT("<line x1=\"%.1f\" y1=\"%.0f\" x2=\"%.1f\" y2=\"%.0f\" stroke=\"#dcd6c6\" stroke-width=\"1\"/>\n"), X, MT, X, MT + MapH);
				if (bMajor)
				{
					const FString Km = FString::Printf(TEXT("%.1f"), GX / 100000.f);
					S += FString::Printf(TEXT("<text x=\"%.1f\" y=\"%.0f\" font-family=\"monospace\" font-size=\"9\" fill=\"#8a8270\" text-anchor=\"middle\">%s</text>\n"), X, MT + MapH + 15.0, *Km);
					S += FString::Printf(TEXT("<text x=\"%.1f\" y=\"%.0f\" font-family=\"monospace\" font-size=\"9\" fill=\"#8a8270\" text-anchor=\"middle\">%s</text>\n"), X, MT - 5.0, *Km);
				}
			}
			const int32 NY = FMath::Max(1, FMath::CeilToInt(H / GridStepCm));
			const int32 LabelEveryY = FMath::Max(1, (NY + 11) / 12);
			int32 IY = 0;
			for (float GY = MinY; GY <= MaxY; GY += GridStepCm, ++IY)
			{
				const float Y = MT + MapH - (float)((GY - MinY) * Scale);
				const bool bMajor = (IY % LabelEveryY == 0);
				S += FString::Printf(TEXT("<line x1=\"%.0f\" y1=\"%.1f\" x2=\"%.0f\" y2=\"%.1f\" stroke=\"#dcd6c6\" stroke-width=\"1\"/>\n"), ML, Y, ML + MapW, Y);
				if (bMajor)
				{
					const FString Km = FString::Printf(TEXT("%.1f"), GY / 100000.f);
					S += FString::Printf(TEXT("<text x=\"%.0f\" y=\"%.1f\" font-family=\"monospace\" font-size=\"9\" fill=\"#8a8270\" text-anchor=\"end\">%s</text>\n"), ML - 6.0, Y + 3.0, *Km);
					S += FString::Printf(TEXT("<text x=\"%.0f\" y=\"%.1f\" font-family=\"monospace\" font-size=\"9\" fill=\"#8a8270\">%s</text>\n"), ML + MapW + 6.0, Y + 3.0, *Km);
				}
			}
		}

		// -- the biomes, then the trenches (base fill + texture overlay) ------------------
		for (const FMapZone& Z : BiomeZones)
		{
			S += FString::Printf(TEXT("<circle cx=\"%.1f\" cy=\"%.1f\" r=\"%.1f\" fill=\"#3f7d3a\" fill-opacity=\"0.28\" stroke=\"#2e5c2b\" stroke-width=\"1.5\"/>\n"),
				PX(Z.Center), PY(Z.Center), Z.RadiusCm * Scale);
			S += FString::Printf(TEXT("<circle cx=\"%.1f\" cy=\"%.1f\" r=\"%.1f\" fill=\"url(#biomestipple)\" stroke=\"none\"/>\n"),
				PX(Z.Center), PY(Z.Center), Z.RadiusCm * Scale);
		}
		for (const FMapZone& Z : TrenchZones)
		{
			S += FString::Printf(TEXT("<circle cx=\"%.1f\" cy=\"%.1f\" r=\"%.1f\" fill=\"#7a5a2e\" fill-opacity=\"0.30\" stroke=\"#5c421f\" stroke-width=\"1.5\"/>\n"),
				PX(Z.Center), PY(Z.Center), Z.RadiusCm * Scale);
			S += FString::Printf(TEXT("<circle cx=\"%.1f\" cy=\"%.1f\" r=\"%.1f\" fill=\"url(#trenchhatch)\" stroke=\"none\"/>\n"),
				PX(Z.Center), PY(Z.Center), Z.RadiusCm * Scale);
		}

		// -- the raw feature points (the true SHAPE: crates along a trench read as a line) --
		{
			auto Dots = [&](const TArray<FVector>& Pts, const TCHAR* Fill, float R, float Op)
			{
				if (Pts.Num() == 0) return;
				const int32 Step = FMath::Max(1, (Pts.Num() + 399) / 400);
				S += FString::Printf(TEXT("<g fill=\"%s\" fill-opacity=\"%.2f\">"), Fill, Op);
				for (int32 i = 0; i < Pts.Num(); i += Step)
				{
					S += FString::Printf(TEXT("<circle cx=\"%.1f\" cy=\"%.1f\" r=\"%.1f\"/>"),
						PX(Pts[i]), PY(Pts[i]), R);
				}
				S += TEXT("</g>\n");
			};
			// crates ARE the trench lines - they must READ at 9-km scale, not whisper
			Dots(CratePoints, TEXT("#5c421f"), 3.4f, 0.75f);
			Dots(TreePoints, TEXT("#1d4a1a"), 3.0f, 0.5f);
		}

		// -- EVERY river gets its own true polyline - separate rivers drawn separately ----
		for (const TArray<FVector>& Line : Rivers)
		{
			if (Line.Num() < 2) { continue; }
			// the water body: wide bank stroke, then a light core = depth
			S += TEXT("<polyline points=\"");
			for (int32 i = 0; i < Line.Num(); ++i)
			{
				S += FString::Printf(TEXT("%.1f,%.1f "), PX(Line[i]), PY(Line[i]));
			}
			S += TEXT("\" fill=\"none\" stroke=\"#2f6fa3\" stroke-width=\"7\" stroke-linecap=\"round\" stroke-opacity=\"0.85\"/>\n");
			S += TEXT("<polyline points=\"");
			for (int32 i = 0; i < Line.Num(); ++i)
			{
				S += FString::Printf(TEXT("%.1f,%.1f "), PX(Line[i]), PY(Line[i]));
			}
			S += TEXT("\" fill=\"none\" stroke=\"#9cc4e0\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-opacity=\"0.9\"/>\n");
			// the flow arrow at the river's midpoint, pointing downstream
			{
				const int32 MidI = Line.Num() / 2;
				const FVector& A = Line[MidI - 1];
				const FVector& B = Line[MidI];
				const float DX = PX(B) - PX(A);
				const float DY = PY(B) - PY(A);
				const float Len = FMath::Max(1.0f, FMath::Sqrt(DX * DX + DY * DY));
				const float Deg = FMath::RadiansToDegrees(FMath::Atan2(DY, DX));
				S += FString::Printf(TEXT("<polygon points=\"0,-4 8,0 0,4\" transform=\"translate(%.1f,%.1f) rotate(%.0f)\" fill=\"#1d4a70\"/>\n"),
					PX(A) + DX * 0.5f, PY(A) + DY * 0.5f, Deg);
				(void)Len;
			}
		}

		// -- the existing missions (grey square, cancelled with an X) ------------------------
		for (const FVector& P : ExistingMissions)
		{
			S += FString::Printf(TEXT("<rect x=\"%.1f\" y=\"%.1f\" width=\"9\" height=\"9\" fill=\"#8a8a8a\"/>\n"),
				PX(P) - 4.5f, PY(P) - 4.5f);
			S += FString::Printf(TEXT("<path d=\"M %.1f %.1f l 9 9 M %.1f %.1f l 9 -9\" stroke=\"#faf7ee\" stroke-width=\"1.6\"/>\n"),
				PX(P) - 4.5f, PY(P) - 4.5f, PX(P) - 4.5f, PY(P) + 4.5f);
		}

		// -- the story route (dashed: the campaign walk in pin order) -----------------------
		if (Spots.Num() > 1)
		{
			S += TEXT("<polyline points=\"");
			for (int32 i = 0; i < Spots.Num(); ++i)
			{
				S += FString::Printf(TEXT("%.1f,%.1f "), PX(Spots[i].Position), PY(Spots[i].Position));
			}
			S += TEXT("\" fill=\"none\" stroke=\"#555555\" stroke-width=\"3\" stroke-dasharray=\"7 5\" stroke-opacity=\"0.8\"/>\n");
			// one arrow mid-leg + the leg's walking distance
			for (int32 i = 1; i < Spots.Num(); ++i)
			{
				const FVector& A = Spots[i - 1].Position;
				const FVector& B = Spots[i].Position;
				const float DX = PX(B) - PX(A);
				const float DY = PY(B) - PY(A);
				const float Deg = FMath::RadiansToDegrees(FMath::Atan2(DY, DX));
				const float MidX = PX(A) + DX * 0.5f;
				const float MidY = PY(A) + DY * 0.5f;
				S += FString::Printf(TEXT("<polygon points=\"0,-4.5 9,0 0,4.5\" transform=\"translate(%.1f,%.1f) rotate(%.0f)\" fill=\"#555555\"/>\n"), MidX, MidY, Deg);
				const double DDX = B.X - A.X; const double DDY = B.Y - A.Y;
				const double LegM = FMath::Sqrt(DDX * DDX + DDY * DDY) / 100.0;
				if (LegM >= 300.0)
				{
					S += FString::Printf(TEXT("<text x=\"%.1f\" y=\"%.1f\" font-family=\"monospace\" font-size=\"9\" fill=\"#444440\" text-anchor=\"middle\" stroke=\"#f2efe6\" stroke-width=\"3\" paint-order=\"stroke\">%.1f km</text>\n"),
						MidX, MidY - 8.0, LegM / 1000.0);
				}
			}
		}

		// -- the mission pins: drop pins with shadows, numbered in story order --------------
		for (int32 i = 0; i < Spots.Num(); ++i)
		{
			const FMissionSpot& Spot = Spots[i];
			const TCHAR* Fill = TEXT("#c22d20");
			const TCHAR* Dark = TEXT("#7d1d15");
			if (Spot.Kind == EMissionSpotKind::HQDefend)         { Fill = TEXT("#d9a013"); Dark = TEXT("#8a6808"); }
			else if (Spot.Kind == EMissionSpotKind::BiomeRecon)  { Fill = TEXT("#2f7d4f"); Dark = TEXT("#1d5032"); }
			else if (Spot.Kind == EMissionSpotKind::RiverExtraction) { Fill = TEXT("#2f6fa3"); Dark = TEXT("#1d476b"); }
			const float X = PX(Spot.Position);
			const float Y = PY(Spot.Position);
			S += FString::Printf(TEXT("<ellipse cx=\"%.1f\" cy=\"%.1f\" rx=\"10\" ry=\"3\" fill=\"#000000\" fill-opacity=\"0.18\"/>\n"), X, Y + 23.0f);
			S += FString::Printf(TEXT("<path d=\"M %.1f %.1f L %.1f %.1f L %.1f %.1f Z\" fill=\"%s\"/>\n"),
				X - 7.0f, Y + 9.0f, X + 7.0f, Y + 9.0f, X, Y + 23.0f, Dark);
			S += FString::Printf(TEXT("<circle cx=\"%.1f\" cy=\"%.1f\" r=\"13\" fill=\"%s\" stroke=\"#faf7ee\" stroke-width=\"2\"/>\n"), X, Y, Fill);
			S += FString::Printf(TEXT("<text x=\"%.1f\" y=\"%.1f\" font-family=\"monospace\" font-size=\"13\" font-weight=\"bold\" fill=\"#ffffff\" text-anchor=\"middle\" dominant-baseline=\"central\">%d</text>\n"),
				X, Y, i + 1);
			if (Spot.Kind == EMissionSpotKind::HQDefend)
			{
				S += FString::Printf(TEXT("<rect x=\"%.1f\" y=\"%.1f\" width=\"26\" height=\"13\" fill=\"#faf7ee\" stroke=\"#8a6808\" stroke-width=\"1\"/>\n"), X - 13.0f, Y - 31.0f);
				S += FString::Printf(TEXT("<text x=\"%.1f\" y=\"%.1f\" font-family=\"monospace\" font-size=\"9\" font-weight=\"bold\" fill=\"#8a6808\" text-anchor=\"middle\">HQ</text>\n"), X, Y - 21.5f);
			}
		}

		// -- the legend panel ------------------------------------------------------------------
		{
			int32 TreeDots = 0;
			for (const FMapZone& Z : BiomeZones)  { (void)Z; ++TreeDots; }
			struct FLegItem { const TCHAR* Swatch; const TCHAR* Label; };
			const FLegItem Items[] = {
				{ TEXT("#3f7d3a"), TEXT("biome zone (trees, stippled)") },
				{ TEXT("#7a5a2e"), TEXT("trench zone (crates, hatched)") },
				{ TEXT("#5c421f"), TEXT("crate points - the trench lines") },
				{ TEXT("#1d4a1a"), TEXT("tree points - the woods") },
				{ TEXT("#2f6fa3"), TEXT("river, arrow = downstream") },
				{ TEXT("#d9a013"), TEXT("pin 1 = HQ defend") },
				{ TEXT("#c22d20"), TEXT("red pin = combat mission") },
				{ TEXT("#2f7d4f"), TEXT("green pin = biome recon") },
				{ TEXT("#2f6fa3"), TEXT("blue pin = river extraction") },
				{ TEXT("#8a8a8a"), TEXT("grey square = an existing mission") },
			};
			const int32 Rows = sizeof(Items) / sizeof(Items[0]);
			const float LX = (float)ML + 10.0f;
			const float LY = (float)MT + 10.0f;
			S += FString::Printf(TEXT("<rect x=\"%.0f\" y=\"%.0f\" width=\"250\" height=\"%d\" rx=\"4\" fill=\"#faf7ee\" fill-opacity=\"0.85\" stroke=\"#b7ae98\" stroke-width=\"1\"/>\n"),
				LX, LY, Rows * 15 + 22);
			S += FString::Printf(TEXT("<text x=\"%.0f\" y=\"%.0f\" font-family=\"monospace\" font-size=\"11\" font-weight=\"bold\" fill=\"#333330\">LEGEND - %d mission spot(s)</text>\n"),
				LX + 8.0f, LY + 14.0f, Spots.Num());
			for (int32 r = 0; r < Rows; ++r)
			{
				const float RY = LY + 28.0f + r * 15.0f;
				S += FString::Printf(TEXT("<circle cx=\"%.0f\" cy=\"%.0f\" r=\"5\" fill=\"%s\"/>\n"), LX + 14.0f, RY - 3.0f, Items[r].Swatch);
				S += FString::Printf(TEXT("<text x=\"%.0f\" y=\"%.0f\" font-family=\"monospace\" font-size=\"10\" fill=\"#333330\">%s</text>\n"),
					LX + 26.0f, RY, Items[r].Label);
			}
			(void)TreeDots;
		}

		// -- the scale bar + the stats footer ----------------------------------------------------
		{
			const float BarPx = (float)(GridStepCm * Scale);
			const float BX = (float)ML + 8.0f;
			const float BY = (float)(MT + MapH) + 40.0f;
			for (int32 Seg = 0; Seg < 4; ++Seg)
			{
				S += FString::Printf(TEXT("<rect x=\"%.1f\" y=\"%.1f\" width=\"%.1f\" height=\"6\" fill=\"%s\" stroke=\"#333330\" stroke-width=\"0.8\"/>\n"),
					BX + BarPx * Seg * 0.25f, BY, BarPx * 0.25f, (Seg % 2 == 0) ? TEXT("#333330") : TEXT("#faf7ee"));
			}
			S += FString::Printf(TEXT("<text x=\"%.1f\" y=\"%.1f\" font-family=\"monospace\" font-size=\"10\" fill=\"#333330\" text-anchor=\"middle\">%.0f m</text>\n"),
				BX + BarPx * 0.5f, BY - 4.0f, GridStepCm / 100.f);
			S += FString::Printf(TEXT("<text x=\"%.0f\" y=\"%.1f\" font-family=\"monospace\" font-size=\"10\" fill=\"#555550\" text-anchor=\"end\">spots %d | biomes %d | trenches %d | rivers %d | existing %d</text>\n"),
				ML + MapW, BY + 5.0f, Spots.Num(), BiomeZones.Num(), TrenchZones.Num(), Rivers.Num(), ExistingMissions.Num());
			S += FString::Printf(TEXT("<text x=\"%.0f\" y=\"%.1f\" font-family=\"monospace\" font-size=\"10\" fill=\"#555550\">dashed line = the story route (arrowed, distances in km)</text>\n"),
				ML - 8.0, BY + 20.0);
		}
		S += TEXT("</svg>\n");
		return S;
	}
};

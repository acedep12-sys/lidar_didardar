// FallenNoteActor.h — S17-NOTE: collectible letters from fallen soldiers.
// Scatter these across the battlefield (a pale sheet of paper on a small
// glowing marker). Walking over one opens a native HUD overlay that reads the
// note (title + body, designer-entered FText — Farsi/Arabic shaping handled by
// the HUD). Pure ambient storytelling: never gates mission completion.
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "FallenNoteActor.generated.h"

class UStaticMeshComponent;
class UMaterialInstanceDynamic;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnFallenNoteCollected, class AFallenNoteActor*, Note);

UCLASS(BlueprintType, Blueprintable)
class SQUADAI_API AFallenNoteActor : public AActor
{
	GENERATED_BODY()

public:
	AFallenNoteActor();
	virtual void Tick(float DeltaTime) override;

	// ===== CONFIG =====

	/** Note heading, e.g. the soldier's name (localized FText — Farsi OK). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fallen Note")
	FText NoteTitle;

	/** The letter itself. Use Shift+Enter for line breaks; keep it short. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fallen Note", meta = (MultiLine = "true"))
	FText NoteText;

	/** Walk within this range to pick the note up (cm). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fallen Note", meta = (ClampMin = "80.0"))
	float PickupRadius = 200.f;

	/** Seconds the note stays on screen. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fallen Note", meta = (ClampMin = "3.0"))
	float ReadDuration = 10.f;

	// ===== STATE =====

	UPROPERTY(BlueprintReadOnly, Category = "Fallen Note")
	bool bCollected = false;

	UPROPERTY(BlueprintAssignable, Category = "Fallen Note")
	FOnFallenNoteCollected OnCollected;

protected:
	virtual void BeginPlay() override;

	UPROPERTY(VisibleAnywhere, Category = "Fallen Note")
	TObjectPtr<UStaticMeshComponent> PaperMesh;

	UPROPERTY(VisibleAnywhere, Category = "Fallen Note")
	TObjectPtr<UStaticMeshComponent> MarkerDisc;

private:
	UPROPERTY(Transient)
	TObjectPtr<UMaterialInstanceDynamic> MarkerMID;

	void Collect();
};

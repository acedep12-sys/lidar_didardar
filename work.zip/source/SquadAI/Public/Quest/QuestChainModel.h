// QuestChainModel.h - S20-WP: the pure sequencing rules for a quest chain that
// must survive WORLD PARTITION streaming. Missions live in cells that load and
// unload as the player crosses a 9-km open world, so a chain can never assume
// its full mission list is in memory: far acts register LATE (when their cell
// first streams in) and the finale may simply not exist yet when act 14 ends.
// These statics decide, from plain integers, what the chain totals, when it
// WAITS for a mission that has not streamed in, and when the campaign is
// genuinely finished. Kept engine-free so the harness pins every rule offline.
#pragma once
#include "CoreMinimal.h"

class FQuestChainModel
{
public:
	/** The total the HUD and the completion rule use. An explicit expected count
	 *  (the auto-scatter writes it when it stamps the campaign) WINS; a legacy
	 *  hand-placed chain without one falls back to how many missions have
	 *  registered so far - exactly the old behaviour, no surprises. */
	static int32 ExpectedTotal(int32 ExpectedMissionCount, int32 RegisteredCount)
	{
		return ExpectedMissionCount > 0 ? ExpectedMissionCount : RegisteredCount;
	}

	/** The finish line. The campaign ends only when the sequence is exhausted
	 *  (the chain waited for and completed the last act) or every expected act
	 *  is already done. It must NEVER end just because the later acts have not
	 *  streamed in yet - that premature ending is exactly the streaming bug. */
	static bool ShouldComplete(int32 NextIndex, int32 Total, int32 CompletedCount)
	{
		if (Total <= 0)
		{
			return false;
		}
		return NextIndex >= Total || CompletedCount >= Total;
	}

	/** How long the chain waits between checks for a mission whose cell has not
	 *  streamed in yet. The player walking there IS the load trigger, so a slow
	 *  polite poll is all that is needed - never a stall, never a skip. */
	static float RetryDelaySeconds() { return 2.f; }

	/** Polls between "still waiting" log lines (2 s apart) - the log stays
	 *  readable while the chain can wait for minutes of walking. */
	static int32 RetryLogEvery() { return 8; }
};

// InterdictionDirectorActor.h - S19-INTERDICT
//
// The interdiction run's bookkeeper: spawns couriers onto a route one after another
// (first after FirstDelaySeconds, then one every SpawnIntervalSeconds), counts
// stopped vs escaped, and reports the two outcomes the mission cares about -
// the quota was met (the objective is done) or the escape limit was hit (it failed).
//
// The double bar and the "stop spawning a dead run" rule are the model's
// (Quest/InterdictionModel.h); this actor only executes them. The zone binds
// OnQuotaMet / OnEscapeLimitReached exactly like the extraction pad's events.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "InterdictionDirectorActor.generated.h"

class AEnemyPatrolRoute;
class AInterdictionCourierActor;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnInterdictionQuotaMet, AInterdictionDirectorActor*, Director);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnInterdictionEscapeLimit, AInterdictionDirectorActor*, Director);

UCLASS(BlueprintType)
class SQUADAI_API AInterdictionDirectorActor : public AActor
{
	GENERATED_BODY()

public:
	AInterdictionDirectorActor();

	// ===== CONFIG =====

	/** The route the couriers drive. Its LAST point is the escape edge. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Interdiction")
	TObjectPtr<AEnemyPatrolRoute> CourierRoute;

	/** How many couriers leave in total. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Interdiction", meta = (ClampMin = "1", ClampMax = "12"))
	int32 CourierCount = 4;

	/** Seconds before the first courier leaves (the player reads the objective). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Interdiction", meta = (ClampMin = "0.0"))
	float FirstDelaySeconds = 15.f;

	/** Seconds between launches after that. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Interdiction", meta = (ClampMin = "2.0"))
	float SpawnIntervalSeconds = 25.f;

	/** How many must be stopped. Inclusive - the quota IS the goal. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Interdiction", meta = (ClampMin = "1"))
	int32 StopQuota = 2;

	/** The escape limit: this many getting through fails the objective. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Interdiction", meta = (ClampMin = "1"))
	int32 MaxEscapes = 2;

	/** The courier class. Empty = the native AInterdictionCourierActor. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Interdiction")
	TSubclassOf<AInterdictionCourierActor> CourierClass;

	// ===== EVENTS (the zone binds these two) =====

	UPROPERTY(BlueprintAssignable, Category = "Interdiction")
	FOnInterdictionQuotaMet OnQuotaMet;

	UPROPERTY(BlueprintAssignable, Category = "Interdiction")
	FOnInterdictionEscapeLimit OnEscapeLimitReached;

	// ===== API =====

	/** Start the run (the zone calls this on activation). Safe once. */
	UFUNCTION(BlueprintCallable, Category = "Interdiction")
	void StartRun();

	/** Full reset for a mission restart attempt. */
	UFUNCTION(BlueprintCallable, Category = "Interdiction")
	void ResetRun();

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Interdiction")
	bool WasQuotaMet() const { return bQuotaMet; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Interdiction")
	bool WasEscapeLimitHit() const { return bEscapeLimitHit; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Interdiction")
	int32 GetStoppedCount() const { return StoppedCount; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Interdiction")
	int32 GetEscapedCount() const { return EscapedCount; }

protected:
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

private:
	int32 SpawnedCount = 0;
	int32 StoppedCount = 0;
	int32 EscapedCount = 0;
	bool bQuotaMet = false;
	bool bEscapeLimitHit = false;
	bool bRunStarted = false;
	bool bRunOver = false;

	FTimerHandle SpawnTimerHandle;

	TArray<TWeakObjectPtr<AInterdictionCourierActor>> LiveCouriers;

	void SpawnCourier();
	void HandleCourierResolved();

	UFUNCTION()
	void HandleCourierStopped(AInterdictionCourierActor* Courier);

	UFUNCTION()
	void HandleCourierEscaped(AInterdictionCourierActor* Courier);
};

// ScoreModel.h - S19-SCORE
//
// The debrief's arithmetic: what an objective is worth, what a loss costs, and how a
// total becomes a grade. Before this the mission finished with a state and a par
// verdict - nothing answered "how did I do".
//
// The design is deliberately SMALL: points ride the events the zone already handles
// (sabotage planted, intel reported, POW rescued, supply delivered, convoy arrived,
// extraction held, defend wave survived), plus the mission-level verdicts it already
// reports (par, clock, alarm, stealth). No per-kill bookkeeping - the spawner's death
// stream is a combat statistic, not a debrief, and wiring every kill through the zone
// would buy a number nobody changes tactics for.
//
// GRADES are anchored to a ParScore the zone computes ONCE at activation from the
// mission's own objectives (every objective done, nothing lost = exactly par). So:
//   >= 1.6 x par -> S    flawless (objectives + bonuses, minimal losses)
//   >= 1.3 x par -> A
//   >= 1.1 x par -> B
//   >= 1.0 x par -> C    the mission as briefed
//   <  1.0 x par -> D    objectives missed or the bill came due
//
// Engine-free: pure functions + one small state struct, compiled by tools/mission_test
// (same treatment as the alarm, escort, intel and clock models).

#pragma once

#include "CoreMinimal.h"
#include "Tactical/AlarmModel.h"     // the ghost record is the alarm's verdict

/** Every scoring moment on the live stack. */
enum class EMissionScoreEvent : uint8
{
	// objectives
	SabotagePlanted,
	IntelReported,
	POWRescued,
	SupplyDelivered,
	EscortArrived,
	ExtractionComplete,
	DefendWaveSurvived,

	// mission-level verdicts
	MissionCompleted,    // the mission as briefed was finished - the base award
	ParBeaten,
	ParMissed,
	TimeExpired,
	FullAlarmRaised,     // once per mission - the first crossing
	StealthBonus,        // once at completion, when the ghost record holds
	FriendlyDeath,       // a POW or an escort the player was asked to protect
	CounterattackRepelled, // S17-CNTR: the post-completion counterattack was held

	// S19-CAP / S19-ASSET / S19-INTERDICT: the batch-4 creators
	CapturePointTaken,   // a flag flipped to the player's side
	CapturePointLost,    // hostiles took one back
	AssetPreserved,      // the defended asset was still alive at completion
	AssetDestroyed,      // the asset went down (usually also the mission)
	CourierStopped,      // an interdiction courier destroyed before the far edge
	CourierEscaped       // one got through
};

enum class EMissionGrade : uint8
{
	D = 0, C = 1, B = 2, A = 3, S = 4
};

struct FMissionScoreModel
{
	// -----------------------------------------------------------------------------------------
	//  the table
	// -----------------------------------------------------------------------------------------

	static int32 PointsFor(EMissionScoreEvent E)
	{
		switch (E)
		{
		case EMissionScoreEvent::SabotagePlanted:       return 250;
		case EMissionScoreEvent::IntelReported:         return 200;
		case EMissionScoreEvent::POWRescued:            return 300;
		case EMissionScoreEvent::SupplyDelivered:       return 150;
		case EMissionScoreEvent::EscortArrived:         return 350;
		case EMissionScoreEvent::ExtractionComplete:    return 300;
		case EMissionScoreEvent::DefendWaveSurvived:    return 150;
		case EMissionScoreEvent::MissionCompleted:      return 200;
		case EMissionScoreEvent::ParBeaten:             return 250;
		case EMissionScoreEvent::ParMissed:             return -100;
		case EMissionScoreEvent::TimeExpired:           return -150;
		case EMissionScoreEvent::FullAlarmRaised:       return -200;
		case EMissionScoreEvent::StealthBonus:          return 300;
		case EMissionScoreEvent::FriendlyDeath:         return -250;
		case EMissionScoreEvent::CounterattackRepelled: return 200;
		case EMissionScoreEvent::CapturePointTaken:     return 200;
		case EMissionScoreEvent::CapturePointLost:      return -100;
		case EMissionScoreEvent::AssetPreserved:        return 250;
		case EMissionScoreEvent::AssetDestroyed:        return -300;
		case EMissionScoreEvent::CourierStopped:        return 150;
		case EMissionScoreEvent::CourierEscaped:        return -100;
		default:                                        return 0;
		}
	}

	/**
	 * The par baseline: finishing the mission AS BRIEFED is exactly par - the base
	 * completion award, plus every objective the mission actually asked for, with
	 * nothing lost. `ObjectiveCount` = linked targets that exist (sabotage + intel +
	 * supplies + POWs + escort + extraction + capture/asset/interdiction); `bDefend`
	 * counts its own wave stream. (Deep-review fix B1: the base award used to be
	 * missing, so a plain Clear scored 0 against a 100 par and read "Score 0  D"
	 * AFTER WINNING.)
	 */
	static int32 ParScoreFor(int32 WaveCount, int32 EnemiesPerWave, bool bCommander,
		int32 ObjectiveCount, bool bDefend)
	{
		int32 Par = PointsFor(EMissionScoreEvent::MissionCompleted);
		if (bDefend)
		{
			Par += FMath::Max(0, WaveCount) * PointsFor(EMissionScoreEvent::DefendWaveSurvived);
		}
		Par += FMath::Max(0, ObjectiveCount) * 250;                    // the objectives' average worth
		Par += bCommander ? 400 : 0;                                   // the decapitation bonus
		return FMath::Max(PointsFor(EMissionScoreEvent::MissionCompleted), Par);
	}

	// -----------------------------------------------------------------------------------------
	//  grades
	// -----------------------------------------------------------------------------------------

	/** Ratio thresholds in hundredths, inclusive: >=1.6 S, >=1.3 A, >=1.1 B, >=1.0 C, else D. */
	static EMissionGrade GradeFor(int32 Total, int32 ParScore)
	{
		if (ParScore <= 0)
		{
			// No baseline (a bare zone): grade on raw scale.
			return Total >= 800 ? EMissionGrade::S : Total >= 500 ? EMissionGrade::A
				 : Total >= 300 ? EMissionGrade::B : Total >= 100 ? EMissionGrade::C
				 : EMissionGrade::D;
		}
		const int32 Hund = (Total * 100) / ParScore;                   // integer, floor
		if (Hund >= 160) return EMissionGrade::S;
		if (Hund >= 130) return EMissionGrade::A;
		if (Hund >= 110) return EMissionGrade::B;
		if (Hund >= 100) return EMissionGrade::C;
		return EMissionGrade::D;
	}

	/** One letter for the readout. */
	static const TCHAR* GradeLetter(EMissionGrade G)
	{
		switch (G)
		{
		case EMissionGrade::S: return TEXT("S");
		case EMissionGrade::A: return TEXT("A");
		case EMissionGrade::B: return TEXT("B");
		case EMissionGrade::C: return TEXT("C");
		default:               return TEXT("D");
		}
	}

	/** The completed card's debrief readout, e.g. "Score 1,250  B". */
	static FString DebriefLine(int32 Total, EMissionGrade G)
	{
		return FString::Printf(TEXT("Score %s  %s"),
			*FString::Printf(TEXT("%d"), Total), GradeLetter(G));
	}

	/** The worst grade across an operation's steps (S19-OP): the campaign is honest. */
	static EMissionGrade WorstGrade(EMissionGrade A, EMissionGrade B)
	{
		return (static_cast<uint8>(A) <= static_cast<uint8>(B)) ? A : B;
	}
};

/**
 * The running total on one mission. Plain C++ on purpose - it lives inside AMissionZone
 * as a non-reflected member and is read out through two reflected pure functions
 * (GetMissionScore / GetScoreGradeString), so none of the rules above enter UHT.
 */
struct FMissionScoreState
{
	int32 Total = 0;
	int32 ParScore = 100;
	float HighestAlarmValue = 0.f;     // the ghost record (S19-ALARM)
	bool bFullAlarmPenaltyApplied = false;
	bool bStealthBonusApplied = false;

	void Reset(int32 InParScore)
	{
		Total = 0;
		ParScore = FMath::Max(1, InParScore);
		HighestAlarmValue = 0.f;
		bFullAlarmPenaltyApplied = false;
		bStealthBonusApplied = false;
	}

	/** Add one scored moment. Total is clamped at >= 0: a disaster is a 0, not a debt. */
	void Add(EMissionScoreEvent E)
	{
		Total = FMath::Max(0, Total + FMissionScoreModel::PointsFor(E));
	}

	void AddPoints(int32 Points)
	{
		Total = FMath::Max(0, Total + Points);
	}

	/** The alarm channel reports every new value; the ghost record only ever climbs. */
	void NoteAlarmValue(float V)
	{
		HighestAlarmValue = FMath::Max(HighestAlarmValue, V);
	}

	/** The one-shot full-alarm penalty: true the first time, never again. */
	bool ApplyFullAlarmPenaltyOnce()
	{
		if (bFullAlarmPenaltyApplied)
		{
			return false;
		}
		bFullAlarmPenaltyApplied = true;
		Add(EMissionScoreEvent::FullAlarmRaised);
		return true;
	}

	/** The once-only ghost bonus at completion; returns true when it was applied. */
	bool ApplyStealthBonusOnce()
	{
		if (bStealthBonusApplied || !FAlarmModel::IsGhostPreserved(HighestAlarmValue))
		{
			return false;
		}
		bStealthBonusApplied = true;
		Add(EMissionScoreEvent::StealthBonus);
		return true;
	}

	EMissionGrade Grade() const { return FMissionScoreModel::GradeFor(Total, ParScore); }
};

// MissionBriefingModel.h - S23-BRIEF
//
// THE MISSION BRIEFING, WRITTEN BY THE LAND. The scatter knows real facts about
// every act it stamps - the ground's landform, how many of their ranked hills see
// the position, how exposed the march in was, the rise of the guard post going in
// beside it. This model turns those facts into a STRUCTURED briefing: titled
// sections instead of one flat paragraph, with rotating openers and closers so
// twenty-eight acts never read the same twice (consecutive acts always differ -
// the rotation is by act number, deterministic, testable).
//
// Engine-free (FString/TArray only), pinned by tools/mission_test: the format is
// "[HEADER] text" per line, round-tripped by ParseBriefingCard, which the HUD uses
// to detect a structured briefing and stage its sections with the typewriter FX.

#pragma once

#include "CoreMinimal.h"

/** One section of a briefing: a small header ("THE GROUND") and its line. */
struct FMissionSection
{
	FString Header;
	FString Text;
};

/** Everything the scatter knows about an act when it stamps the briefing. */
struct FMissionBriefingFacts
{
	int32 ActNumber = 0;      // 1-based
	int32 ActCount = 0;       // 28
	FString KindWord;         // "trench" | "forest" | "river" | "hq"
	int32 ZoneMarkers = 0;    // crates or trees on the ground
	FString LandformWord;     // "crest", "valley floor", ... (TerrainStructureModel's words)
	int32 Watchers = 0;       // ranked hills whose line of sight reaches the position
	int32 MarchPct = -1;      // % of the march in under their net (-1 = act one / unknown)
	float MarchKm = 0.f;      // length of that march
	float GuardRiseM = 0.f;   // guard post's rise over the lowland (0 = none placed)
	FString JobLine;         // the act's real objectives from its template ("" = none listed)
	FString DepartureWord;   // compass word from the LAST act to this one ("" = act one)
	bool bFinale = false;     // the river crossing ends the campaign
};

struct FMissionBriefingModel
{
	/** The briefing, section by section. Deterministic in the facts: same facts in,
	 *  same briefing out, byte for byte. */
	static void BuildBriefing(const FMissionBriefingFacts& F, TArray<FMissionSection>& Out)
	{
		Out.Reset();
		const int32 Opener = (FMath::Max(1, F.ActNumber) - 1) % 4;
		const int32 Closer = FMath::Max(1, F.ActNumber) % 4;

		// --- SITUATION: four rotating openers, finale and HQ get their own war
		FString Situation;
		if (F.bFinale)
		{
			Situation = TEXT("The ring is closed. Everything they have left stands at the river gate.");
		}
		else if (F.KindWord == TEXT("hq"))
		{
			Situation = TEXT("Their wall runs past your wire - the fortress is in mortar range. This is a lodgement, not a base.");
		}
		else
		{
			const FString Count = F.ZoneMarkers > 0
				? FString::Printf(TEXT("%d markers of enemy ground"), F.ZoneMarkers)
				: FString(TEXT("the ground itself is the objective"));
			switch (Opener)
			{
				case 0: Situation = FString::Printf(TEXT("They hold it: %s."), *Count); break;
				case 1: Situation = FString::Printf(TEXT("The war stops here: %s, all of it theirs."), *Count); break;
				case 2: Situation = FString::Printf(TEXT("Recon confirms the count: %s."), *Count); break;
				default: Situation = FString::Printf(TEXT("Last light showed it still theirs - %s."), *Count); break;
			}
		}

		// --- MISSION: the verb, by the kind of act
		FString Mission;
		if (F.KindWord == TEXT("trench"))     { Mission = TEXT("Break the line and take the trench - their front folds with it."); }
		else if (F.KindWord == TEXT("forest")){ Mission = TEXT("Sweep the trees - quiet recon first, knives when quiet fails."); }
		else if (F.KindWord == TEXT("river")) { Mission = TEXT("Force the crossing and hold the far bank."); }
		else if (F.KindWord == TEXT("road"))  { Mission = TEXT("Run the convoy through - the road is open because you broke the line."); }
		else                                  { Mission = TEXT("Hold the headquarters. Everything else depends on it."); }

		// --- THE GROUND: the measured landform and who watches it
		FString Ground = FString::Printf(TEXT("%s ground"), *F.LandformWord);
		if (F.Watchers <= 0)       { Ground += TEXT(" - no ranked hill sees it. Move quiet and keep it that way."); }
		else if (F.Watchers == 1)  { Ground += TEXT(" - one ranked hill sees it: mind the watcher."); }
		else if (F.Watchers == 2)  { Ground += TEXT(" - two of their hills see it."); }
		else                       { Ground += FString::Printf(TEXT(" - %d of their ranked hills see it: kill the watchers first."), F.Watchers); }

		// --- THE ROAD IN: the march, with its measured exposure
		FString Road;
		if (F.MarchPct >= 0)
		{
			Road = FString::Printf(TEXT("the march in: %.1f km, %d%% under their net"), F.MarchKm, F.MarchPct);
			if (F.MarchPct >= 50)      { Road += TEXT(" - go dark or go fast."); }
			else if (F.MarchPct <= 25) { Road += TEXT(" - the covered road."); }
		}

		// --- THE POST: the guard post the scatter plants beside the op
		FString Post;
		if (F.GuardRiseM >= 1.f)
		{
			Post = FString::Printf(TEXT("a post goes on the high ground %.0f m over the lowland - it holds while you fight."), F.GuardRiseM);
		}

		// --- DEPARTURE: the bearing out of the last fight, the km, four rotating
		// closers; the finale closes the war, act one starts at the wire
		FString MarchWords;
		if (F.MarchKm > 0.f && !F.DepartureWord.IsEmpty())
		{
			MarchWords = FString::Printf(TEXT("Leave the last ground heading %s - %.1f km. "), *F.DepartureWord, F.MarchKm);
		}
		FString Departure;
		if (F.bFinale)
		{
			Departure = MarchWords + TEXT("Everything ends at the water. Take the crossing and hold it.");
		}
		else if (F.KindWord == TEXT("hq")) { Departure = TEXT("The start line is the wire. Hold the line."); }
		else
		{
			FString CloserText;
			switch (Closer)
			{
			case 0: CloserText = TEXT("Make it loud."); break;
			case 1: CloserText = TEXT("Make it quiet."); break;
			case 2: CloserText = TEXT("Bring them home."); break;
			default: CloserText = TEXT("The map is watching. Give it something."); break;
			}
			Departure = MarchWords.IsEmpty()
				? TEXT("The start line is the wire. ") + CloserText
				: MarchWords + CloserText;
		}

		if (F.ActNumber > 0 && F.ActCount >= F.ActNumber)
		{
			FMissionSection Act;
			Act.Header = TEXT("ACT");
			Act.Text = FString::Printf(TEXT("Act %d of %d"), F.ActNumber, F.ActCount);
			Out.Add(Act);
		}
		FMissionSection S1; S1.Header = TEXT("SITUATION");  S1.Text = Situation;  Out.Add(S1);
		FMissionSection S2; S2.Header = TEXT("MISSION");    S2.Text = Mission;    Out.Add(S2);
		if (!F.JobLine.IsEmpty())
		{
			FMissionSection SJ; SJ.Header = TEXT("THE JOB"); SJ.Text = F.JobLine; Out.Add(SJ);
		}
		FMissionSection S3; S3.Header = TEXT("THE GROUND"); S3.Text = Ground;     Out.Add(S3);
		if (!Road.IsEmpty())
		{
			FMissionSection S4; S4.Header = TEXT("THE ROAD IN"); S4.Text = Road; Out.Add(S4);
		}
		if (!Post.IsEmpty())
		{
			FMissionSection S5; S5.Header = TEXT("THE POST"); S5.Text = Post; Out.Add(S5);
		}
		FMissionSection S6; S6.Header = TEXT("DEPARTURE"); S6.Text = Departure; Out.Add(S6);
	}

	/** The card format: one "[HEADER] text" line per section. */
	static FString FormatBriefingForCard(const TArray<FMissionSection>& Sections)
	{
		TArray<FString> Lines;
		for (const FMissionSection& S : Sections)
		{
			Lines.Add(FString::Printf(TEXT("[%s] %s"), *S.Header, *S.Text));
		}
		return FString::Join(Lines, TEXT("\n"));
	}

	/** Inverse of the format. False when the text carries no section tags - the
	 *  HUD then falls back to the plain one-paragraph card, so old missions and
	 *  hand-written briefings keep working unchanged. */
	static bool ParseBriefingCard(const FString& Formatted, TArray<FMissionSection>& OutSections)
	{
		OutSections.Reset();
		TArray<FString> Lines;
		Formatted.ParseIntoArrayLines(Lines, false);
		for (const FString& Line : Lines)
		{
			if (Line.Len() > 2 && Line[0] == TEXT('['))
			{
				const int32 Close = Line.Find(TEXT("]"), ESearchCase::CaseSensitive, ESearchDir::FromStart, 1);
				if (Close != INDEX_NONE)
				{
					FMissionSection S;
					S.Header = Line.Mid(1, Close - 1);
					S.Text = Line.Mid(Close + 1).TrimStart();
					OutSections.Add(S);
				}
			}
		}
		return OutSections.Num() > 0;
	}
};

/** What the zone knows the moment an act completes - the debrief's facts.
 *  Same treatment as the briefing: the NUMBERS the zone already computed
 *  (score, par, grade, clock, the ghost record) become titled sections the
 *  HUD stages like the briefing, instead of two flat generic lines. */
struct FMissionDebriefFacts
{
	FString Title;          // the act's name
	int32 Score = 0;
	int32 Par = 0;
	FString GradeLetter;    // "S" | "A" | "B" | "C" | "D"
	FString TimeMMSS;       // "04:12" - the time the act took
	bool bParBeaten = false;
	bool bParMissed = false;
	bool bGhost = false;    // the ghost bonus paid - they never saw you
};

struct FMissionDebriefModel
{
	/** The debrief, section by section. Deterministic in the facts. */
	static void BuildDebrief(const FMissionDebriefFacts& F, TArray<FMissionSection>& Out)
	{
		Out.Reset();
		FMissionSection R1; R1.Header = TEXT("THE RESULT");
		R1.Text = TEXT("The act is done.");
		if (F.bParBeaten)      { R1.Text += TEXT(" Par beaten - the clock never had you."); }
		else if (F.bParMissed) { R1.Text += TEXT(" Par missed - the clock won this one."); }
		Out.Add(R1);
		FMissionSection R2; R2.Header = TEXT("THE SCORE");
		R2.Text = FString::Printf(TEXT("Score %d against par %d, in %s."), F.Score, F.Par, *F.TimeMMSS);
		if (F.bGhost) { R2.Text += TEXT(" The ghost bonus paid - they never knew you were there."); }
		Out.Add(R2);
		FMissionSection R3; R3.Header = TEXT("THE VERDICT");
		const TCHAR* Words =
			F.GradeLetter == TEXT("S") ? TEXT("a perfect run.") :
			F.GradeLetter == TEXT("A") ? TEXT("a strong hand.") :
			F.GradeLetter == TEXT("B") ? TEXT("solid work.") :
			F.GradeLetter == TEXT("C") ? TEXT("the standard.") :
			TEXT("a rough night - the battalion remembers anyway.");
		R3.Text = FString::Printf(TEXT("Grade %s - %s"), *F.GradeLetter, Words);
		Out.Add(R3);
		FMissionSection R4; R4.Header = TEXT("THE CAMPAIGN");
		R4.Text = TEXT("The chain has already moved on. The next objective is marked - the war does not wait.");
		Out.Add(R4);
	}
};

// SupplyCrateActor.h — S17-SUPP: fetch-and-carry objective for supply-run missions.
// Walk onto the crate to shoulder it (proximity pickup — no interact key),
// carry it to the delivery point (the owning MissionZone, or a designer-chosen
// actor), and step inside the delivery radius to drop it off. One crate at a
// time; dying resets undelivered crates to their spawn spots on attempt restart.
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "SupplyCrateActor.generated.h"

class UStaticMeshComponent;
class UMaterialInstanceDynamic;

UENUM(BlueprintType)
enum class ESupplyCrateState : uint8
{
	AwaitingPickup UMETA(DisplayName = "Awaiting Pickup"),
	Carried        UMETA(DisplayName = "Carried"),
	Delivered      UMETA(DisplayName = "Delivered")
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnSupplyCratePickedUp, class ASupplyCrateActor*, Crate);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnSupplyCrateDelivered, class ASupplyCrateActor*, Crate);

UCLASS(BlueprintType, Blueprintable)
class SQUADAI_API ASupplyCrateActor : public AActor
{
	GENERATED_BODY()

public:
	ASupplyCrateActor();
	virtual void Tick(float DeltaTime) override;

	// ===== CONFIG =====

	/** Walk within this range of the crate to pick it up (cm). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Supply Crate", meta = (ClampMin = "100.0"))
	float PickupRadius = 220.f;

	/** Optional display label for logs (e.g. "Ammunition", "Medical supplies"). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Supply Crate")
	FText CrateLabel;

	// ===== STATE =====

	UPROPERTY(BlueprintReadOnly, Category = "Supply Crate")
	ESupplyCrateState State = ESupplyCrateState::AwaitingPickup;

	UPROPERTY(BlueprintAssignable, Category = "Supply Crate")
	FOnSupplyCratePickedUp OnPickedUp;

	UPROPERTY(BlueprintAssignable, Category = "Supply Crate")
	FOnSupplyCrateDelivered OnDelivered;

	/** Set by the owning MissionZone: where the crate must be carried. */
	void SetDeliveryTarget(const FVector& Location, float Radius);

	UFUNCTION(BlueprintCallable, Category = "Supply Crate")
	void ResetCrate();

	bool IsDelivered() const { return State == ESupplyCrateState::Delivered; }
	bool IsCarried() const { return State == ESupplyCrateState::Carried; }

protected:
	virtual void BeginPlay() override;

	UPROPERTY(VisibleAnywhere, Category = "Supply Crate")
	TObjectPtr<UStaticMeshComponent> CrateMesh;

	UPROPERTY(VisibleAnywhere, Category = "Supply Crate")
	TObjectPtr<UStaticMeshComponent> MarkerDisc;

private:
	FVector DeliveryLocation = FVector::ZeroVector;
	float DeliveryRadius = 0.f;
	FTransform HomeTransform;
	bool bHomeCached = false;

	UPROPERTY(Transient)
	TObjectPtr<UMaterialInstanceDynamic> MarkerMID;

	void SetMarkerColor(const FLinearColor& C);
	void SetCrateVisible(bool bVisible);
};

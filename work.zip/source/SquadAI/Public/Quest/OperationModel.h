// OperationModel.h - S19-OP
//
// The rules behind a CAMPAIGN NIGHT: an operation is an ordered list of mission
// templates stamped one at a time - finish the raid, the exfil appears; finish that,
// the convoy run appears - with a retry policy, an overall progress, and one debrief
// for the whole thing.
//
// Why a model: the sequencing looks trivial and is not. Does a failed step retry the
// SAME template or end the operation? Does a retry count against the score? What is
// the operation's grade when one step was an A and another a D? Those are exactly
// the decisions that drift when they live inside an actor's tick, so they live here
// as pure functions - compiled by tools/mission_test - and the director just
// executes what the model says.
//
// Score policy (stated once): a retried step keeps the LAST attempt's score, not the
// best one - a botched-then-clean run reads honestly - and retries do not reset the
// steps already banked.

#pragma once

#include "CoreMinimal.h"
#include "Quest/ScoreModel.h"     // grades and the aggregation reuse

enum class EOperationStepState : uint8
{
	Pending,
	Live,          // stamped into the level and running
	Completed,
	Failed,        // failed AND out of retries (or retries disabled) - the operation ends
	RetryQueued    // failed; the model says stamp the same template again
};

struct FMissionOperationModel
{
	// -----------------------------------------------------------------------------------------
	//  sequencing
	// -----------------------------------------------------------------------------------------

	/**
	 * What happens to the step that just failed. `RetriesUsed` is how many times THIS
	 * step already retried. With retries enabled and budget left, the same template is
	 * stamped again; otherwise the operation fails here.
	 */
	static EOperationStepState ResolveFailedStep(bool bRetriesEnabled, int32 MaxRetries,
		int32 RetriesUsed)
	{
		if (bRetriesEnabled && RetriesUsed < MaxRetries)
		{
			return EOperationStepState::RetryQueued;
		}
		return EOperationStepState::Failed;
	}

	/** The index to stamp next: a queued retry re-stamps the same step; otherwise the next. */
	static int32 NextStepIndex(int32 CurrentStepIndex, EOperationStepState CurrentStepState)
	{
		return CurrentStepState == EOperationStepState::RetryQueued
			? CurrentStepIndex
			: CurrentStepIndex + 1;
	}

	/** The operation is over (in either direction) once a step resolves to Failed. */
	static bool IsOperationOver(EOperationStepState ResolvedStep)
	{
		return ResolvedStep == EOperationStepState::Failed;
	}

	// -----------------------------------------------------------------------------------------
	//  progress
	// -----------------------------------------------------------------------------------------

	/** Completed steps over total steps, 0..1. Zero steps means "nothing to show" (0). */
	static float Progress01(int32 CompletedSteps, int32 TotalSteps)
	{
		if (TotalSteps <= 0)
		{
			return 0.f;
		}
		return FMath::Clamp(static_cast<float>(CompletedSteps) / static_cast<float>(TotalSteps), 0.f, 1.f);
	}

	// -----------------------------------------------------------------------------------------
	//  the debrief
	// -----------------------------------------------------------------------------------------

	/**
	 * The operation's grade: the WORST step grade (an A raid and a D exfil is a C
	 * night), floored to D if any step ran out of retries and failed outright.
	 */
	static EMissionGrade OperationGrade(const TArray<EMissionGrade>& StepGrades,
		int32 FailedSteps)
	{
		if (StepGrades.Num() == 0)
		{
			return EMissionGrade::D;
		}
		EMissionGrade Worst = StepGrades[0];
		for (EMissionGrade G : StepGrades)
		{
			Worst = FMissionScoreModel::WorstGrade(Worst, G);
		}
		if (FailedSteps > 0)
		{
			Worst = FMissionScoreModel::WorstGrade(Worst, EMissionGrade::D);
		}
		return Worst;
	}

	/** The debrief line the director logs and holds: "Operation complete - 3 steps, score 3,750, grade B". */
	static FString ReportLine(int32 StepsCompleted, int32 StepsFailed, int32 TotalScore,
		EMissionGrade G)
	{
		return FString::Printf(TEXT("Operation complete - %d step%s, score %s, grade %s"),
			StepsCompleted,
			StepsCompleted == 1 ? TEXT("") : TEXT("s"),
			*FString::Printf(TEXT("%d"), TotalScore),
			FMissionScoreModel::GradeLetter(G));
	}

	/** Breathing room between a completed step and the next stamp (seconds). */
	static float DefaultNextStepDelaySeconds() { return 8.f; }
};

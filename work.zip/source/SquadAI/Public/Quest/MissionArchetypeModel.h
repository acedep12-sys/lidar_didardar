// MissionArchetypeModel.h - S19-TEMPLATE
//
// The rules behind "one button should stamp a mission that matches the mission":
// which archetype a zone's own settings imply, what that archetype deploys, where
// the prop ring goes, and which template combinations cannot work.
//
// Why it lives in a model header
// ------------------------------
// The auto-populate pass used to stamp every Clear and Defend zone with the SAME
// thing (2-3 waves of 4, one barrel) and never read a single one of the zone's
// own features - the officer hunt, the artillery spotter, the sabotage list. The
// decision "given these facts, this is the mission kind" is pure logic, and so is
// the layout of the props it deploys; keeping both here means the seventh harness
// can pin them, and the editor factory only has to do the spawning.
//
// The three things every rule below protects:
//   * an archetype is chosen from FACTS (type + officers + nearby patrol routes),
//     never from randomness - the same zone always stamps the same kind;
//   * the prop ring distributes props so none of them overlap the zone centre,
//     and a full circle never places two props on top of each other;
//   * a template that cannot work is REPORTED (error / warning strings), never
//     silently half-built.
//
// Engine-free on purpose (no UENUM, no generated include): compiled and exercised
// by tools/mission_test, the same way PatrolRouteModel.h is by tools/patrol_test.

#pragma once

#include "CoreMinimal.h"

/** The mission kinds the factory knows how to stamp. */
enum class EMissionPresetKind : uint8
{
	None,          // no base type set: the factory falls back to plain defaults
	Checkpoint,    // Reach: a held roadblock, light waves, barrels
	Ambush,        // Clear: the standard fight on the objective
	CommanderHunt, // Clear + officer hunt: commander + assistants, boss at the end
	PatrolCamp,     // Clear + patrol routes nearby: an outpost that patrols
	Stronghold      // Defend: bunker, turret, supplies, the heaviest waves
};

/** What the zone (and the world around it) says about the mission. */
struct FMissionArchetypeQuery
{
	bool bReach = false;
	bool bClear = false;
	bool bDefend = false;

	/** The zone hunts an officer (S17-HVT). */
	bool bHVTHunt = false;

	/** An AEnemyPatrolRoute lives within the camp radius of this zone. */
	bool bNearbyPatrolRoute = false;
};

/** What the preset deploys. The factory applies this to the actors it spawns. */
struct FMissionPresetPlan
{
	int32 TotalWaves = 2;
	int32 EnemiesPerWave = 4;
	float DelayBetweenWaves = 8.f;
	float SpawnIntervalSeconds = 1.0f;
	float SpawnRadiusCm = 4500.f;

	/** A commander joins the last wave, with this many assistants. */
	bool bSpawnCommander = false;
	int32 AssistantsPerCommander = 2;

	bool bSpawnMountedTurret = false;
	bool bAutoScatterSupplyKits = false;
	bool bFortify = false;
	float FortificationRingRadiusCm = 700.f;
	int32 ExplosiveBarrels = 1;
};

/** Everything the validator needs to know about a template (or a zone). */
struct FMissionSetupFacts
{
	bool bReach = false;
	bool bClear = false;
	bool bDefend = false;

	bool bHVTHunt = false;
	bool bArtillerySpotter = false;

	/** The operator asked for a convoy, and how many legs its route will have. */
	bool bEscort = false;
	int32 EscortRouteLegs = 0;

	int32 IntelSiteCount = 0;
	int32 SupplyCrateCount = 0;
	int32 SabotageTargetCount = 0;
	int32 POWCaptiveCount = 0;
	bool bPOWClassSet = false;

	bool bExtraction = false;
	bool bRequireExtraction = false;
	float ExtractionHoldSeconds = 0.f;

	// S19-CAP / S19-ASSET / S19-INTERDICT
	int32 CapturePointCount = 0;
	bool bDefendedAsset = false;
	bool bInterdiction = false;
	int32 InterdictionCourierCount = 0;
	int32 InterdictionStopQuota = 0;

	float TimeLimitSeconds = 0.f;
	float ParTimeSeconds = 0.f;
	int32 TotalWaves = 0;
};

struct FMissionArchetypeModel
{
	// -----------------------------------------------------------------------------------------
	//  archetype selection
	// -----------------------------------------------------------------------------------------

	/**
	 * The zone's own facts pick the kind. Precedence is deliberate: a Defend zone is
	 * always a stronghold, an officer hunt beats a plain ambush, and a zone sitting in a
	 * patrolled area becomes a camp. No randomness anywhere.
	 */
	static EMissionPresetKind ChoosePreset(const FMissionArchetypeQuery& Q)
	{
		if (Q.bDefend)
		{
			return EMissionPresetKind::Stronghold;
		}
		if (Q.bClear)
		{
			if (Q.bHVTHunt)
			{
				return EMissionPresetKind::CommanderHunt;
			}
			return Q.bNearbyPatrolRoute ? EMissionPresetKind::PatrolCamp : EMissionPresetKind::Ambush;
		}
		if (Q.bReach)
		{
			return EMissionPresetKind::Checkpoint;
		}
		return EMissionPresetKind::None;
	}

	/** How far from a zone a patrol route still counts as "this is their camp". */
	static float CampPatrolRadiusCm() { return 6000.f; }

	/** The plan for a kind, with the caller's own wave numbers overriding the preset's. */
	static FMissionPresetPlan PlanFor(EMissionPresetKind Kind, int32 TotalWavesOverride = 0,
		int32 EnemiesPerWaveOverride = 0)
	{
		FMissionPresetPlan P;
		switch (Kind)
		{
		case EMissionPresetKind::Checkpoint:
			P.TotalWaves = 2; P.EnemiesPerWave = 4; P.DelayBetweenWaves = 6.f;
			P.bFortify = true; P.FortificationRingRadiusCm = 700.f; P.ExplosiveBarrels = 1;
			break;
		case EMissionPresetKind::Ambush:
			P.TotalWaves = 2; P.EnemiesPerWave = 5; P.DelayBetweenWaves = 7.f;
			P.ExplosiveBarrels = 2;
			break;
		case EMissionPresetKind::CommanderHunt:
			P.TotalWaves = 2; P.EnemiesPerWave = 4; P.DelayBetweenWaves = 8.f;
			P.bSpawnCommander = true; P.AssistantsPerCommander = 2;
			P.ExplosiveBarrels = 1;
			break;
		case EMissionPresetKind::PatrolCamp:
			P.TotalWaves = 2; P.EnemiesPerWave = 4; P.DelayBetweenWaves = 9.f;
			P.SpawnIntervalSeconds = 1.2f;
			P.bFortify = true; P.FortificationRingRadiusCm = 900.f;
			P.bAutoScatterSupplyKits = true; P.ExplosiveBarrels = 1;
			break;
		case EMissionPresetKind::Stronghold:
			P.TotalWaves = 3; P.EnemiesPerWave = 5; P.DelayBetweenWaves = 8.f;
			P.bSpawnMountedTurret = true; P.bFortify = true; P.FortificationRingRadiusCm = 800.f;
			P.bAutoScatterSupplyKits = true; P.ExplosiveBarrels = 2;
			break;
		case EMissionPresetKind::None:
		default:
			break; // the plain defaults above
		}

		if (TotalWavesOverride > 0)
		{
			P.TotalWaves = TotalWavesOverride;
		}
		if (EnemiesPerWaveOverride > 0)
		{
			P.EnemiesPerWave = EnemiesPerWaveOverride;
		}
		return P;
	}

	/** Name for the factory's log line. */
	static const TCHAR* PresetName(EMissionPresetKind Kind)
	{
		switch (Kind)
		{
		case EMissionPresetKind::Checkpoint:    return TEXT("checkpoint (Reach)");
		case EMissionPresetKind::Ambush:        return TEXT("ambush (Clear)");
		case EMissionPresetKind::CommanderHunt: return TEXT("commander hunt (Clear + officer)");
		case EMissionPresetKind::PatrolCamp:    return TEXT("patrol camp (Clear + patrol routes)");
		case EMissionPresetKind::Stronghold:    return TEXT("stronghold (Defend)");
		default:                                return TEXT("plain");
		}
	}

	// -----------------------------------------------------------------------------------------
	//  layout
	// -----------------------------------------------------------------------------------------

	/**
	 * Where props go around a zone centre, as 2D offsets in cm.
	 *
	 *   Count <= 0            -> empty
	 *   Count == 1            -> one offset at StartAngleDeg, at the radius
	 *   ArcDeg >= 360         -> a full circle, step 360/Count (so the first and last do
	 *                            NOT land on the same spot)
	 *   ArcDeg <  360, N > 1  -> the arc is SPREAD ACROSS the props, step ArcDeg/(N-1),
	 *                            i.e. first and last sit on the arc's ends
	 *   RadiusCm <= 0         -> a 1 cm radius, never 0 (props must not stack at the centre)
	 */
	static TArray<FVector> PropRingOffsets(int32 Count, float RadiusCm, float StartAngleDeg, float ArcDeg)
	{
		TArray<FVector> Out;
		if (Count <= 0)
		{
			return Out;
		}
		const float R = (RadiusCm > 0.f) ? RadiusCm : 1.f;
		if (Count == 1)
		{
			const float A = FMath::DegreesToRadians(StartAngleDeg);
			Out.Add(FVector(FMath::Cos(A) * R, FMath::Sin(A) * R, 0.f));
			return Out;
		}
		const bool bFullCircle = ArcDeg >= 360.f;
		const float Step = bFullCircle ? (360.f / static_cast<float>(Count))
			: (ArcDeg / static_cast<float>(Count - 1));
		for (int32 i = 0; i < Count; ++i)
		{
			const float A = FMath::DegreesToRadians(StartAngleDeg + Step * static_cast<float>(i));
			Out.Add(FVector(FMath::Cos(A) * R, FMath::Sin(A) * R, 0.f));
		}
		return Out;
	}

	/**
	 * The convoy route's points, as world offsets from the route actor's start:
	 * Legs + 1 points, each leg exactly LegLengthCm long, with a gentle alternating
	 * yaw wobble so the route is a readable snake rather than a ruler-straight line.
	 * Legs < 1 -> a single point (callers must treat that as "route too short").
	 */
	static TArray<FVector> EscortRouteOffsets(int32 Legs, float LegLengthCm,
		float StartYawDeg, float WobbleDeg = 20.f)
	{
		TArray<FVector> Out;
		Out.Add(FVector::ZeroVector);
		const int32 ClampedLegs = FMath::Max(1, Legs);
		const float Step = (LegLengthCm > 0.f) ? LegLengthCm : 1000.f;
		float Yaw = StartYawDeg;
		FVector Cursor = FVector::ZeroVector;
		for (int32 i = 0; i < ClampedLegs; ++i)
		{
			if (i > 0)
			{
				Yaw += ((i % 2) == 1) ? WobbleDeg : -WobbleDeg;
			}
			const float A = FMath::DegreesToRadians(Yaw);
			Cursor += FVector(FMath::Cos(A) * Step, FMath::Sin(A) * Step, 0.f);
			Out.Add(Cursor);
		}
		return Out;
	}

	// -----------------------------------------------------------------------------------------
	//  validation
	// -----------------------------------------------------------------------------------------

	/**
	 * Everything that cannot work in the facts above, as human-readable lines appended
	 * to OutNotes. Returns the number of ERRORS (warnings are notes only): an error means
	 * the factory would build something broken or half-configured, a warning means the
	 * template is legal but the designer probably did not mean it.
	 *
	 * The rules:
	 *   1. ESCORT with fewer than 2 route legs            -> ERROR (a one-point route arrives
	 *                                                        the instant it starts)
	 *   2. REQUIRE EXTRACTION with no extraction pad      -> ERROR (nothing can ever satisfy it)
	 *   3. POW captives with no class to spawn them from  -> warning (skipped by the factory)
	 *   4. officer hunt / artillery spotter off a Clear   -> warning (ignored at runtime)
	 *      type
	 *   5. par time longer than a hard limit              -> warning (the par cannot be met
	 *                                                        without the soft-clock option)
	 *   6. fewer than 1 wave                              -> warning (clamped to 1)
	 *   7. Defend with a clock as well as DefendDuration  -> note (both run; the log says so)
	 */
	static int32 ValidateSetup(const FMissionSetupFacts& F, TArray<FString>& OutNotes)
	{
		int32 Errors = 0;

		if (F.bEscort && F.EscortRouteLegs < 2)
		{
			++Errors;
			OutNotes.Add(FString::Printf(
				TEXT("ERROR: an escort route needs at least 2 legs (this one has %d) - a one-point route arrives immediately."),
				F.EscortRouteLegs));
		}
		if (!F.bExtraction && F.bRequireExtraction)
		{
			++Errors;
			OutNotes.Add(TEXT("ERROR: 'Require Extraction' is on but no extraction pad is configured - nothing can satisfy the gate."));
		}
		if (F.POWCaptiveCount > 0 && !F.bPOWClassSet)
		{
			OutNotes.Add(TEXT("warning: POW captives were asked for but no POW class is set - they will be skipped."));
		}
		if ((F.bHVTHunt || F.bArtillerySpotter) && !F.bClear)
		{
			OutNotes.Add(FString::Printf(
				TEXT("warning: %s only applies to Clear missions - it will be ignored on this type."),
				F.bHVTHunt ? TEXT("the officer hunt") : TEXT("the artillery spotter")));
		}
		if (F.ParTimeSeconds > 0.f && F.TimeLimitSeconds > 0.f && F.ParTimeSeconds > F.TimeLimitSeconds)
		{
			OutNotes.Add(FString::Printf(
				TEXT("warning: par (%s) is longer than the time limit (%s) - it can only be met while the clock is soft."),
				*FString::Printf(TEXT("%.0f s"), F.ParTimeSeconds),
				*FString::Printf(TEXT("%.0f s"), F.TimeLimitSeconds)));
		}
		if (F.TotalWaves < 1)
		{
			OutNotes.Add(TEXT("warning: fewer than 1 wave was configured - the factory will use 1."));
		}
		if (F.bDefend && F.TimeLimitSeconds > 0.f)
		{
			OutNotes.Add(TEXT("note: a Defend zone already runs DefendDuration; the mission clock runs alongside it."));
		}
		if (F.bInterdiction && F.InterdictionStopQuota > F.InterdictionCourierCount)
		{
			++Errors;
			OutNotes.Add(FString::Printf(
				TEXT("ERROR: the interdiction quota (%d) exceeds the courier count (%d) - nothing could ever satisfy it."),
				F.InterdictionStopQuota, F.InterdictionCourierCount));
		}
		if (F.bInterdiction && F.InterdictionCourierCount < 1)
		{
			++Errors;
			OutNotes.Add(TEXT("ERROR: interdiction with no couriers - nothing can be stopped."));
		}
		return Errors;
	}
};

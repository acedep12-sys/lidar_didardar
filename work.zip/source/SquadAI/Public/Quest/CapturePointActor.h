// CapturePointActor.h - S19-CAP
//
// The capture-and-hold objective: a flag the player's side takes by standing on it
// (progress fills while present, drains while hostiles hold it, FROZEN while both
// do - contested is where the fight lives), with an optional hold phase after the
// capture. The rules are in Quest/CaptureModel.h; this actor counts pawns, shows
// the colour language, and reports.
//
// Colour language (the marker disc, matching the module's amber/cyan/green habit):
//   grey neutral -> amber capturing -> RED contested -> green held.
//
// A zone links these and can only complete when every linked point is held (or,
// with no hold required, captured). Losing one back to the hostiles re-opens the
// gate - the zone says so and re-drives.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Quest/CaptureModel.h"
#include "CapturePointActor.generated.h"

class UStaticMeshComponent;
class UMaterialInstanceDynamic;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnCapturePointCaptured, ACapturePointActor*, Point);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnCapturePointLost, ACapturePointActor*, Point);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnCapturePointHoldCompleted, ACapturePointActor*, Point);

/** The flag's public state (reflected - the model's flow enum stays plain C++ and
 *  GetPointState converts, so UHT sees exactly one spelling of each). */
UENUM(BlueprintType)
enum class ECapturePointState : uint8
{
	Neutral,
	Contested,
	Capturing,
	Held
};

UCLASS(BlueprintType)
class SQUADAI_API ACapturePointActor : public AActor
{
	GENERATED_BODY()

public:
	ACapturePointActor();

	virtual void Tick(float DeltaTime) override;

	// ===== CONFIG =====

	/** Display name for logs and alerts. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Capture Point")
	FText PointName;

	/** Stand inside this radius (2D) and within the vertical window to capture. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Capture Point", meta = (ClampMin = "200.0"))
	float CaptureRadiusCm = 800.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Capture Point", meta = (ClampMin = "100.0"))
	float VerticalToleranceCm = 500.f;

	/** Progress per second while one side has the point alone. 0.25 = a solo capture in 4 s. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Capture Point", meta = (ClampMin = "0.05", ClampMax = "1.0"))
	float CapRate01PerSecond = 0.25f;

	/** After the capture: stand on it this long to HOLD it. 0 = captured is held. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Capture Point", meta = (ClampMin = "0.0"))
	float PostCaptureHoldSeconds = 10.f;

	// ===== EVENTS =====

	UPROPERTY(BlueprintAssignable, Category = "Capture Point")
	FOnCapturePointCaptured OnCaptured;

	UPROPERTY(BlueprintAssignable, Category = "Capture Point")
	FOnCapturePointLost OnLost;

	UPROPERTY(BlueprintAssignable, Category = "Capture Point")
	FOnCapturePointHoldCompleted OnHoldCompleted;

	// ===== STATE =====

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Capture Point")
	bool IsHeld() const { return bHoldDone; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Capture Point")
	float GetProgress01() const { return Progress01; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Capture Point")
	ECapturePointState GetPointState() const;

	/** Back to a neutral flag (a mission restart attempt calls this). */
	UFUNCTION(BlueprintCallable, Category = "Capture Point")
	void ResetPoint();

protected:
	virtual void BeginPlay() override;

	UPROPERTY(VisibleAnywhere, Category = "Capture Point")
	TObjectPtr<USceneComponent> SceneRoot;

	/** The flag pole (thin cylinder). */
	UPROPERTY(VisibleAnywhere, Category = "Capture Point")
	TObjectPtr<UStaticMeshComponent> PoleMesh;

	/** The flag itself (small cube) - tints with ownership. */
	UPROPERTY(VisibleAnywhere, Category = "Capture Point")
	TObjectPtr<UStaticMeshComponent> FlagMesh;

	/** The radius disc - drawn at 1.1x the capture radius so the edge is readable. */
	UPROPERTY(VisibleAnywhere, Category = "Capture Point")
	TObjectPtr<UStaticMeshComponent> MarkerDisc;

private:
	float Progress01 = 0.f;
	float HeldSeconds = 0.f;
	bool bCaptured = false;
	bool bHoldDone = false;
	bool bHoldAnnounced = false;
	ECaptureFlowState CurrentFlow = ECaptureFlowState::Neutral;

	UPROPERTY(Transient)
	TObjectPtr<UMaterialInstanceDynamic> DiscMID;

	UPROPERTY(Transient)
	TObjectPtr<UMaterialInstanceDynamic> FlagMID;

	void SetMarkerColors(const FLinearColor& Disc, const FLinearColor& Flag);

	void CountPresence(bool& bPlayerInside, bool& bHostileInside) const;
};

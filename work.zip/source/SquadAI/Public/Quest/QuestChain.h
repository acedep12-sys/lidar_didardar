// QuestChain.h — Manages a sequence of MissionZones
// Place in your map, add MissionZones to the chain in order.
// Starts automatically or via trigger.
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Quest/MissionZone.h"
#include "Quest/QuestChainModel.h"
#include "QuestChain.generated.h"

class AMissionZone;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnChainProgressChanged, int32, CurrentIndex, int32, TotalMissions);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnChainCompleted);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnChainFailed, AMissionZone*, FailedMission);

UCLASS(BlueprintType, Blueprintable)
class SQUADAI_API AQuestChain : public AActor
{
	GENERATED_BODY()

public:
	AQuestChain();

	// ===== CONFIGURATION =====

	// Ordered list of missions in this quest chain
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QuestChain|Config")
	TArray<TObjectPtr<AMissionZone>> Missions;

	// S5-15: stable save identity. Auto-generated in OnConstruction for editor-placed
	// chains (persists in the level asset) or at BeginPlay for runtime-spawned ones.
	// The save subsystem matches progress to chains by this GUID first, so chain
	// restore no longer depends on TActorIterator ordering.
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "QuestChain|Save")
	FGuid ChainSaveId;

	// Auto-start the chain on BeginPlay
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QuestChain|Config")
	bool bAutoStart = false;

	// Delay before starting (seconds)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QuestChain|Config", meta = (ClampMin = "0"))
	float StartDelay = 0.f;

	// If true, restart the entire chain on failure instead of just the current mission
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QuestChain|Config")
	bool bRestartChainOnFailure = false;

	// S20-WP: how many missions the WHOLE campaign has. The auto-scatter writes it
	// when it stamps the chain. With World Partition, far missions register LATE
	// (their cell only streams in when the player walks there) - without this
	// number the chain would end the campaign as soon as the registered subset
	// ran out. 0 = legacy: total = however many missions have registered.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "QuestChain|Config", meta = (ClampMin = "0"))
	int32 ExpectedMissionCount = 0;

	// ===== RUNTIME STATE =====

	UPROPERTY(BlueprintReadOnly, Category = "QuestChain|State")
	int32 CurrentMissionIndex = -1;

	UPROPERTY(BlueprintReadOnly, Category = "QuestChain|State")
	bool bIsActive = false;

	UPROPERTY(BlueprintReadOnly, Category = "QuestChain|State")
	bool bIsCompleted = false;

	UPROPERTY(BlueprintReadOnly, Category = "QuestChain|State")
	int32 CompletedMissionCount = 0;

	// ===== EVENTS =====

	UPROPERTY(BlueprintAssignable, Category = "QuestChain|Events")
	FOnChainProgressChanged OnChainProgressChanged;

	UPROPERTY(BlueprintAssignable, Category = "QuestChain|Events")
	FOnChainCompleted OnChainCompleted;

	UPROPERTY(BlueprintAssignable, Category = "QuestChain|Events")
	FOnChainFailed OnChainFailed;

	// ===== API =====

	UFUNCTION(BlueprintCallable, Category = "QuestChain")
	void StartChain();

	UFUNCTION(BlueprintCallable, Category = "QuestChain")
	void RestartChain();

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "QuestChain")
	AMissionZone* GetCurrentMission() const;

	// O(chains) — no world actor scan. Used by AI pathing and HUD.
	static AQuestChain* FindPreferred(UWorld* World, bool bActiveOnly = true);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "QuestChain")
	int32 GetTotalMissions() const
	{
		return FQuestChainModel::ExpectedTotal(ExpectedMissionCount, Missions.Num());
	}

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "QuestChain")
	float GetOverallProgress() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "QuestChain")
	FText GetCurrentMissionDescription() const;

	// Drops a Leader Spline Path at this chain. Sculpt the cyan curve, set ToMission.
	UFUNCTION(CallInEditor, BlueprintCallable, Category = "QuestChain|Spline")
	AActor* SpawnLeaderSplinePath();

	// F-P03: public save/restore entry — wraps private StartMissionAtIndex so the
	// save subsystem can rebuild chain state without touching private sequencing.
	// S20-WP: SavedActiveIndex is the mission's MissionIndex VALUE (the stamped
	// act number), not a slot in a possibly-partial array.
	UFUNCTION(BlueprintCallable, Category = "QuestChain|Save")
	void RestoreMissionState(int32 SavedActiveIndex);

	// S20-WP: register a mission whose cell just streamed in (or one the editor
	// placed after the chain began). Sorted in by MissionIndex, bound to this
	// chain, and started immediately if the chain is waiting for it.
	UFUNCTION(BlueprintCallable, Category = "QuestChain")
	void RegisterMission(AMissionZone* Zone);

	// S20-WP: a mission zone with no chain calls this from BeginPlay; the first
	// live chain adopts it. Engine-partition safe: the chain is always loaded,
	// the zone may be anywhere.
	static void AdoptOrphanZone(AMissionZone* Zone);

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void OnConstruction(const FTransform& Transform) override;

private:
	FTimerHandle StartDelayHandle;

	// S20-WP: waiting for a mission whose cell has not streamed in yet
	bool bWaitingForMission = false;
	int32 WaitRetries = 0;
	FTimerHandle WaitForMissionHandle;

	AMissionZone* FindByMissionIndex(int32 MissionIndexValue) const;
	void TryStartWaitingMission();

	void StartMissionAtIndex(int32 Index);
	void OnMissionCompleted(AMissionZone* Mission);
	void OnMissionFailed(AMissionZone* Mission);
	void AdvanceToNextMission();

	// Bound to MissionZone events
	UFUNCTION()
	void HandleMissionStateChanged(AMissionZone* Mission, EMissionZoneState NewState);
};

// EnemyWaveSpawner.h — Configurable enemy wave spawner
// Place this file in SquadAI/Public/Quest/
//
// Place in your map, configure:
//   X = EnemiesPerWave (how many enemies each wave)
//   Y = SpawnIntervalSeconds (delay between each enemy spawn)
//   Z = MaxWaves (how many waves before stopping)
//   LinkedTrigger = the SpawnerTrigger that activates this spawner
//
// Each spawned enemy uses your existing EnemySoldier class and gets full AI.
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "EnemyWaveSpawner.generated.h"

class ASpawnerTrigger;
class AEnemyCommander;
class AEnemyCommanderAssistant;

/** S19-ELITE: which wave a commander leads. */
UENUM(BlueprintType)
enum class ECommanderWavePolicy : uint8
{
	Never      UMETA(DisplayName = "No commander"),
	FirstWave  UMETA(DisplayName = "First wave"),
	FinalWave  UMETA(DisplayName = "Final wave (boss at the end)"),
	EveryWave  UMETA(DisplayName = "Every wave")
};

// ===== DELEGATES =====
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnSpawnerEnemyDied, AActor*, DeadEnemy);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnSpawnerWaveCompleted, int32, WaveNumber);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnSpawnerAllWavesDone);

UCLASS(BlueprintType, Blueprintable)
class SQUADAI_API AEnemyWaveSpawner : public AActor
{
	GENERATED_BODY()

public:
	AEnemyWaveSpawner();

	// ===== CONFIGURATION (X, Y, Z) =====

	// X: How many enemies to spawn per wave
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spawner|Config")
	int32 EnemiesPerWave = 5;

	// Y: Seconds between each enemy spawn within a wave
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spawner|Config", meta = (ClampMin = "0.1"))
	float SpawnIntervalSeconds = 1.0f;

	// Z: Total number of waves. Spawner stops after this many waves.
	// Set to 0 for infinite waves (until manually stopped).
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spawner|Config", meta = (ClampMin = "0"))
	int32 MaxWaves = 3;

	// Seconds to wait between waves (after all enemies in a wave are spawned)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spawner|Config", meta = (ClampMin = "0.1"))
	float DelayBetweenWaves = 5.0f;

	// If true, after completing all waves, restart from wave 1 automatically.
	// Useful for Defend missions. Stops only when DeactivateSpawner() is called.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spawner|Config")
	bool bLoopWaves = false;

	// ===== ENEMY SETTINGS =====

	// Enemy class to spawn. Defaults to AEnemySoldier.
	// Set this to your generated BP_Enemy if you use the pack factory.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spawner|Enemy")
	TSubclassOf<APawn> EnemyClass;

	// Radius around the spawner to randomly place spawned enemies
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spawner|Enemy", meta = (ClampMin = "0"))
	float SpawnRadius = 500.0f;

	// If true, enemies are destroyed when the spawner is destroyed
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spawner|Enemy")
	bool bDestroyEnemiesOnSpawnerEnd = false;

	// Maximum alive enemies from this spawner. 0 = no limit.
	// If this many are alive, the spawner waits until some die before spawning more.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spawner|Enemy", meta = (ClampMin = "0"))
	int32 MaxAliveEnemies = 15;

	// ===== TRIGGER =====

	// The SpawnerTrigger that activates this spawner.
	// Leave empty if you want to activate via Blueprint or auto-activate.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spawner|Trigger")
	TObjectPtr<ASpawnerTrigger> LinkedTrigger;

	// If true, starts spawning on BeginPlay without needing a trigger
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spawner|Trigger")
	bool bAutoActivate = false;

	// If true, the spawner can only be activated once
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spawner|Trigger")
	bool bOneShot = false;

	// Wave enemies join a fireteam (leader + suppress/flank/assault). Off = old independent AI.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spawner|Enemy")
	bool bEnableFireteam = true;

	// ===== S19-ELITE: the commander and his escort =====

	/** Which wave gets a commander. FinalWave is the classic boss-at-the-end. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spawner|Elite")
	ECommanderWavePolicy CommanderWavePolicy = ECommanderWavePolicy::FinalWave;

	/** Commander class. Empty = the native AEnemyCommander. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spawner|Elite")
	TSubclassOf<AEnemyCommander> CommanderClass;

	/** Assistant class. Empty = the native AEnemyCommanderAssistant. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spawner|Elite")
	TSubclassOf<AEnemyCommanderAssistant> AssistantClass;

	/** How many assistants escort him. They spawn around him and register with him. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Spawner|Elite", meta = (ClampMin = "0", ClampMax = "6"))
	int32 AssistantsPerCommander = 2;

	/** The commander this spawner put on the field, if any (read-only). */
	UPROPERTY(BlueprintReadOnly, Category = "Spawner|Elite|State")
	TObjectPtr<AEnemyCommander> SpawnedCommander;

	/**
	 * The commander's calls land here (S19-ELITE). Spawns `Count` grunts of this spawner's
	 * EnemyClass around `Around`, tracked exactly like wave enemies - so the mission's
	 * Clear objective counts them and they must be killed too - but WITHOUT touching the
	 * wave counters (a call for help is not a wave). Returns how many actually came.
	 */
	UFUNCTION(BlueprintCallable, Category = "Spawner|Elite")
	int32 SpawnReinforcementSquad(int32 Count, const FVector& Around);

	// ===== EVENTS =====

	// Fires when an enemy from this spawner dies
	UPROPERTY(BlueprintAssignable, Category = "Spawner|Events")
	FOnSpawnerEnemyDied OnSpawnerEnemyDied;

	// Fires when all enemies in a wave are dead
	UPROPERTY(BlueprintAssignable, Category = "Spawner|Events")
	FOnSpawnerWaveCompleted OnSpawnerWaveCompleted;

	// Fires when all waves are done (spawner completed, not looping)
	UPROPERTY(BlueprintAssignable, Category = "Spawner|Events")
	FOnSpawnerAllWavesDone OnSpawnerAllWavesDone;

	// ===== RUNTIME STATE (read-only) =====

	UPROPERTY(BlueprintReadOnly, Category = "Spawner|State")
	int32 CurrentWave = 0;

	UPROPERTY(BlueprintReadOnly, Category = "Spawner|State")
	int32 TotalEnemiesSpawned = 0;

	UPROPERTY(BlueprintReadOnly, Category = "Spawner|State")
	int32 AliveEnemyCount = 0;

	UPROPERTY(BlueprintReadOnly, Category = "Spawner|State")
	bool bIsActive = false;

	UPROPERTY(BlueprintReadOnly, Category = "Spawner|State")
	bool bCompleted = false;

	// ===== API =====

	UFUNCTION(BlueprintCallable, Category = "Spawner")
	void ActivateSpawner();

	UFUNCTION(BlueprintCallable, Category = "Spawner")
	void DeactivateSpawner();

	UFUNCTION(BlueprintCallable, Category = "Spawner")
	void ResetSpawner();

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Spawner")
	FString GetProgressString() const;

	// ===== S19-HUNT =====
	// The leader needs to know what is LEFT of a Clear objective so he can go and finish
	// it. SpawnedEnemies is private, so these two queries live here; both are no-alloc and
	// use SquadAIRecovery::IsActorDead, which covers pack pawns as well as native ones
	// (pack enemies are not ASoldierCharacter, so IsAlive() alone would miss them).

	/** True while at least one enemy this spawner produced is still up. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Spawner")
	bool HasAliveEnemies() const;

	/** Nearest still-alive enemy to From, or nullptr. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Spawner")
	APawn* GetNearestAliveEnemy(const FVector& From) const;

	/** How many enemies this spawner produced are still up. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Spawner")
	int32 CountAliveEnemies() const;

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

private:
	FTimerHandle SpawnTimerHandle;
	// S5-6e: keep counting pack deaths after final spawning ends (Clear checks read
	// AliveEnemyCount; without this poll late deaths left it frozen).
	void PollLatePackDeaths();
	FTimerHandle WaveDelayTimerHandle;
	int32 SpawnedInCurrentWave = 0;
	bool bActivatedOnce = false;

	UPROPERTY()
	TArray<TObjectPtr<APawn>> SpawnedEnemies;

	void SpawnNextEnemy();

	// S19-ELITE
	/** Does the wave we are about to spawn come with a commander? */
	bool ShouldSpawnCommanderThisWave() const;
	/** Spawn the commander and his assistants around the spawner. */
	void SpawnCommanderAndEscorts();

	/**
	 * S19-ELITE: the one spawn-and-track path. Acquires from the pool (falling back to
	 * SpawnActor), records it in SpawnedEnemies / AliveEnemyCount / TotalEnemiesSpawned,
	 * binds the death delegate, gives it the spawn grace window, spawns its controller,
	 * rescues a dormant pack state tree (S19-ENEMYST) and joins the fireteam. The wave
	 * counter is the CALLER's business, so reinforcement calls can use it too.
	 */
	APawn* SpawnEnemyOfClass(TSubclassOf<APawn> SpawnClass, const FVector& SpawnLocation, const FRotator& SpawnRotation);

	/** True between StartNextWave and the end of that wave's spawning. */
	bool bCommanderWaveThisWave = false;
	void StartNextWave();
	void OnWaveCompleted();
	void CleanupDeadEnemies();
	FVector GetRandomSpawnLocation() const;
	UFUNCTION()
	void OnEnemyDied(AActor* DeadActor);
	void BindEnemyDeathDelegate(APawn* Enemy);
	void UnbindEnemyDeathDelegate(APawn* Enemy);
};

// SquadAILocalizationSubsystem.h — Dynamic external text loader for all in-game & menu strings
#pragma once

#include "CoreMinimal.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "SquadAILocalizationSubsystem.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnLanguageChanged, const FString&, NewLangCode);
DECLARE_MULTICAST_DELEGATE_OneParam(FOnLanguageChangedNative, const FString&);

/**
 * USquadAILocalizationSubsystem
 * Allows users to edit any menu text, HUD prompt, weapon description,
 * or briefing directly in an external Notepad-editable INI file (SquadAILocalization.ini).
 * Auto-creates the file on disk if missing and reloads on startup or via console command.
 */
UCLASS(BlueprintType)
class SQUADAI_API USquadAILocalizationSubsystem : public UGameInstanceSubsystem
{
	GENERATED_BODY()

public:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

	/** Static accessor */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Localization", meta = (WorldContext = "WorldContextObject"))
	static USquadAILocalizationSubsystem* Get(const UObject* WorldContextObject);

	/** Set active localization language code (e.g., "fa", "en") — broadcasts on change (P1-L2) */
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Localization")
	void SetCurrentLanguage(const FString& LangCode);

	/** Fired when the active language (or reloaded strings) change — cached-text holders rebind here (P1-L2) */
	UPROPERTY(BlueprintAssignable, Category = "SquadAI|Localization")
	FOnLanguageChanged OnLanguageChanged;

	/** Native twin of OnLanguageChanged for C++ subscribers */
	FOnLanguageChangedNative OnLanguageChangedNative;

	/** Get active localization language code */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Localization")
	FString GetCurrentLanguage() const { return CurrentLanguage; }

	/** Get localized string with fallback */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Localization")
	FString GetString(const FString& Section, const FString& Key, const FString& DefaultValue = TEXT("")) const;

	/** Get localized FText with fallback */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Localization")
	FText GetText(const FString& Section, const FString& Key, const FText& DefaultValue = FText()) const;

	/** Compatibility helper: Get localized string with fallback */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Localization")
	FString GetLocalizedText(const FString& Section, const FString& Key, const FString& DefaultValue = TEXT("")) const { return GetString(Section, Key, DefaultValue); }

	/** L2-INI: explicit-language lookup for multi-slot data (map cards, traits, profiles).
	 *  Reads [Section.Lang] Key, then [Section] Key_Lang, then (for fa only) [Section] Key —
	 *  never the built-in English table and never the Persian base for non-fa languages.
	 *  Lets code fill Farsi and English struct fields independently of the active language. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Localization")
	FString GetStringForLanguage(const FString& Section, const FString& Key, const FString& LangCode, const FString& DefaultValue = TEXT("")) const;

	/** Compatibility helper: Get localized FText with fallback */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Localization")
	FText GetLocalizedFText(const FString& Section, const FString& Key, const FText& DefaultValue = FText()) const { return GetText(Section, Key, DefaultValue); }

	/** Reload all localization strings from disk without restarting */
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Localization")
	bool ReloadFromDisk();

	/** Gets the absolute disk path of the active localization file */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Localization")
	FString GetActiveFilePath() const { return ActiveFilePath; }

private:
	FString CurrentLanguage = TEXT("fa");
	FString ActiveFilePath;
	TMap<FString, TMap<FString, FString>> StringDatabase;

	void LoadOrCreateDefaultFile();
	void ParseIniContent(const FString& FileContent);
	// S14-ARAB: shared parser core — fills any target map (user file OR template).
	static void ParseIniContentInto(const FString& FileContent, TMap<FString, TMap<FString, FString>>& OutDB);
	// S14-ARAB: an ini created by an OLDER build lacks sections newer builds ship
	// (e.g. all [*.ar] Arabic blocks) and was loaded as-is forever — Arabic looked
	// "not set up". Merge template keys the user file is missing (user values always
	// win) and append them to the ini so they stay Notepad-editable.
	void MergeMissingFromTemplate();
	FString GetDefaultIniTemplate() const;
};

// EnemyCommanderAssistant.h - S19-ELITE
//
// The commander's right hand: two of them by default, one per elite pack.
//
//   * escort - if he drifts further than EscortRadius from his commander he is sent back,
//     and he says so in the log. That is what keeps the command net (and the boss fight)
//     where the player can see it instead of strung out across the map;
//   * field medic - while the commander is below 55% health, and this assistant is within
//     heal range with line of sight, he opens a heal channel (+14 HP/s, max 4 s, 12 s
//     cooldown). The HUD draws a green beam between the two of them while it runs, which is
//     the player's cue to shoot the medic first;
//   * the relay - while at least one assistant stands, the commander's aura survives his
//     death for six more seconds. Kill them first if you want the pack to fold quickly;
//   * morale - when the commander dies they go berserk (aggression 1.0, extra armour) and
//     then, once the rage burns out, they break (aggression 0.05, cowering in cover).
//
// Stats, escort distances, heal numbers and morale numbers are Details-panel properties;
// the rules themselves live in Tactical/EliteSquadModel.h and are unit-tested in
// tools/elite_test.
#pragma once

#include "CoreMinimal.h"
#include "Characters/EnemySoldier.h"
#include "Tactical/EliteSquadModel.h"
#include "EnemyCommanderAssistant.generated.h"

class AEnemyCommander;

UCLASS(BlueprintType, Blueprintable, meta = (DisplayName = "Enemy Commander Assistant"))
class SQUADAI_API AEnemyCommanderAssistant : public AEnemySoldier
{
	GENERATED_BODY()

public:
	AEnemyCommanderAssistant();

	// =========================================================================
	//  STATS
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Assistant|Stats", meta = (ClampMin = "1.0", ClampMax = "10.0"))
	float HealthMultiplier = 1.6f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Assistant|Stats", meta = (ClampMin = "0.1", ClampMax = "5.0"))
	float AccuracyMultiplierOverride = 1.25f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Assistant|Stats", meta = (ClampMin = "0.1", ClampMax = "5.0"))
	float DamageMultiplierOverride = 1.15f;

	// =========================================================================
	//  ESCORT
	// =========================================================================

	/** His commander. Auto-found at BeginPlay when left empty. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Assistant|Escort")
	TObjectPtr<AEnemyCommander> Commander;

	/** Beyond this distance from the commander he is sent back to him. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Assistant|Escort", meta = (ClampMin = "200.0"))
	float EscortRadius = 1200.f;

	/** While returning, he takes the attack point over (overriding the coordinator's) so
	 *  the walk back is not immediately overwritten by the next flank order. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Assistant|Escort")
	bool bEscortOverridesAttackPoint = true;

	// =========================================================================
	//  FIELD MEDIC
	// =========================================================================

	/** Start healing when the commander drops below this health fraction. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Assistant|Medic", meta = (ClampMin = "0.05", ClampMax = "0.95"))
	float HealBelowHealthFraction = 0.55f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Assistant|Medic", meta = (ClampMin = "100.0"))
	float HealRange = 700.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Assistant|Medic", meta = (ClampMin = "0.0"))
	float HealPerSecond = 14.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Assistant|Medic", meta = (ClampMin = "0.5"))
	float HealMaxChannelSeconds = 4.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Assistant|Medic", meta = (ClampMin = "0.0"))
	float HealCooldownSeconds = 12.f;

	/** The channel needs line of sight: a wall between them stops the medic. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Assistant|Medic")
	bool bHealRequiresLineOfSight = true;

	// =========================================================================
	//  MORALE
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Assistant|Morale", meta = (ClampMin = "0.0"))
	float EnrageSeconds = 12.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Assistant|Morale", meta = (ClampMin = "0.0"))
	float MoraleBreakSeconds = 20.f;

	// =========================================================================
	//  RUNTIME STATE (read-only)
	// =========================================================================

	UPROPERTY(BlueprintReadOnly, Category = "Assistant|State")
	bool bEnraged = false;

	UPROPERTY(BlueprintReadOnly, Category = "Assistant|State")
	bool bMoraleBroken = false;

	/** True while a heal channel is running (the HUD draws the beam). */
	UPROPERTY(BlueprintReadOnly, Category = "Assistant|State")
	bool bHealingCommander = false;

	UPROPERTY(BlueprintReadOnly, Category = "Assistant|State")
	float HealCooldownRemaining = 0.f;

	// =========================================================================
	//  API
	// =========================================================================

	UFUNCTION(BlueprintCallable, Category = "Assistant")
	void SetCommander(AEnemyCommander* InCommander);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Assistant")
	AEnemyCommander* GetCommander() const { return Commander; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Assistant")
	bool IsEnraged() const { return bEnraged; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Assistant")
	bool IsHealingCommander() const { return bHealingCommander; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Assistant")
	bool IsMoraleBroken() const { return bMoraleBroken; }

	/** Berserk for `Seconds` (the commander's last stand, or his death). */
	UFUNCTION(BlueprintCallable, Category = "Assistant")
	void BeginEnrage(float Seconds);

	/** Called by the commander the moment he dies. */
	UFUNCTION(BlueprintCallable, Category = "Assistant")
	void OnCommanderDied();

protected:
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaSeconds) override;

	/** S19-CONST: see AEnemyCommander - this hid the base's virtual HandleDeath(). */
	UFUNCTION()
	void HandleOwnerDeath(AActor* OwnerActor);

	/** Find a commander for a hand-placed assistant (never overrides an assignment). */
	void TickCommanderBind(float DeltaSeconds);

	/** Escort: keep him near his commander. */
	void TickEscort(float DeltaSeconds);

	/** Medic: open/advance/close the heal channel. */
	void TickMedic(float DeltaSeconds);

	/** Morale states that the aura is NOT writing (i.e. the commander is gone). */
	void TickMorale(float DeltaSeconds);

	FEliteSquadTuning Tuning;

	bool bReturningToCommander = false;
	bool bCommanderAssignedExplicitly = false;
	float RetryBindCooldown = 0.f;
	float EnrageEndsAt = -1.f;
	float BreakEndsAt = -1.f;
	float ChannelSeconds = 0.f;
	bool bBindingsDone = false;
};

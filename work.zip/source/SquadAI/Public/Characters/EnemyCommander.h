// EnemyCommander.h - S19-ELITE
//
// The sector commander. A native AEnemySoldier subclass (so he drives the same SquadAI
// enemy AI, state tree and fireteam code as every other enemy) with a command presence:
//
//   * he is three times a grunt's health, hits harder, more accurately, and never breaks
//     under fire - and one hit can never delete him (45% of his max health per hit, so his
//     bar has to fall in front of the player);
//   * a command aura around him: his men take less damage and push harder while he lives.
//     Killing him ends it - unless an assistant is still standing, in which case the relay
//     keeps the net up for six more seconds;
//   * he calls reinforcements: when the shooting starts, when his command is thinned, and
//     once more when he is cornered. Two calls, five men each, if a spawner is bound;
//   * a last stand below 35% health: more armour, a wider command net, his assistants
//     enraged, and one final call for help;
//   * when he dies, his men's morale breaks (they stop pushing and cower), his assistants
//     go berserk first, and he drops a field kit.
//
// Every number is a Details-panel property, and the rules themselves live in
// Tactical/EliteSquadModel.h so they are unit-tested offline (tools/elite_test).
#pragma once

#include "CoreMinimal.h"
#include "Characters/EnemySoldier.h"
#include "Tactical/EliteSquadModel.h"
#include "EnemyCommander.generated.h"

class AEnemyCommanderAssistant;
class AEnemyWaveSpawner;
class AFirstAidKitActor;
class AAmmoCrateActor;

UCLASS(BlueprintType, Blueprintable, meta = (DisplayName = "Enemy Commander"))
class SQUADAI_API AEnemyCommander : public AEnemySoldier
{
	GENERATED_BODY()

public:
	AEnemyCommander();

	// =========================================================================
	//  STATS
	// =========================================================================

	/** Max health = the tier's DefaultMaxHealth x this. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Stats", meta = (ClampMin = "1.0", ClampMax = "20.0"))
	float HealthMultiplier = 3.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Stats", meta = (ClampMin = "0.1", ClampMax = "5.0"))
	float AccuracyMultiplierOverride = 1.5f;

	/** Multiplies his weapon damage. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Stats", meta = (ClampMin = "0.1", ClampMax = "5.0"))
	float DamageMultiplierOverride = 1.35f;

	/** A single hit can never take more than this fraction of his max health. 0 = off. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Stats", meta = (ClampMin = "0.0", ClampMax = "1.0"))
	float MaxSingleHitFraction = 0.45f;

	/** Walk with the pack instead of taking a fireteam slot of his own. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Stats")
	bool bJoinFireteam = false;

	// =========================================================================
	//  COMMAND AURA
	// =========================================================================

	/** Radius of the command net, cm. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Aura", meta = (ClampMin = "200.0"))
	float AuraRadius = 1800.f;

	/** Incoming-damage reduction his men get while the net is up. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Aura", meta = (ClampMin = "0.0", ClampMax = "0.9"))
	float AuraResist = 0.25f;

	/** Extra resistance while at least one assistant is alive (the relay). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Aura", meta = (ClampMin = "0.0", ClampMax = "0.5"))
	float AuraRelayResistBonus = 0.10f;

	/** Added to nearby enemies' aggression while the net is up. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Aura", meta = (ClampMin = "0.0", ClampMax = "1.0"))
	float AuraAggressionBonus = 0.25f;

	/** How long the net survives him while an assistant still stands. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Aura", meta = (ClampMin = "0.0"))
	float AuraPersistAfterDeathSeconds = 6.f;

	/** Draw the command net on the ground (HUD, no lighting). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Aura")
	bool bShowAuraRing = true;

	// =========================================================================
	//  REINFORCEMENTS
	// =========================================================================

	/** Spawner the calls go to. Auto-found at BeginPlay when left empty. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Reinforcements")
	TObjectPtr<AEnemyWaveSpawner> BoundSpawner;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Reinforcements", meta = (ClampMin = "0", ClampMax = "10"))
	int32 MaxReinforcementCalls = 2;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Reinforcements", meta = (ClampMin = "1", ClampMax = "12"))
	int32 ReinforcementsPerCall = 5;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Reinforcements", meta = (ClampMin = "0.0"))
	float ReinforcementCooldownSeconds = 25.f;

	/** Call when this few of his men are left. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Reinforcements", meta = (ClampMin = "0"))
	int32 ReinforcementGroupThreshold = 3;

	/** Seconds of combat before the first call. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Reinforcements", meta = (ClampMin = "0.0"))
	float ReinforcementDelayAfterContactSeconds = 6.f;

	// =========================================================================
	//  LAST STAND
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|LastStand", meta = (ClampMin = "0.05", ClampMax = "0.95"))
	float LastStandHealthFraction = 0.35f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|LastStand", meta = (ClampMin = "0.0", ClampMax = "0.5"))
	float LastStandResistBonus = 0.25f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|LastStand", meta = (ClampMin = "0.0"))
	float LastStandSeconds = 10.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|LastStand", meta = (ClampMin = "1.0", ClampMax = "3.0"))
	float AuraRadiusLastStandScale = 1.4f;

	// =========================================================================
	//  DEATH
	// =========================================================================

	/** Suppression spike his death puts on every nearby enemy - their morale breaking. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Death", meta = (ClampMin = "0.0", ClampMax = "1.0"))
	float DeathSuppressionShock = 0.85f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Death", meta = (ClampMin = "0.0"))
	float DeathShockRadius = 2600.f;

	/** Dropped at his feet when he falls (both optional; class defaults are the real ones). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Death")
	TSubclassOf<AFirstAidKitActor> DropFirstAidClass;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Death")
	TSubclassOf<AAmmoCrateActor> DropAmmoClass;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Death")
	bool bAnnounceSpawnAndDeath = true;

	// =========================================================================
	//  RUNTIME STATE (read-only)
	// =========================================================================

	UPROPERTY(BlueprintReadOnly, Category = "Commander|State")
	bool bLastStandActive = false;

	UPROPERTY(BlueprintReadOnly, Category = "Commander|State")
	bool bDead = false;

	UPROPERTY(BlueprintReadOnly, Category = "Commander|State")
	int32 ReinforcementCallsUsed = 0;

	UPROPERTY(BlueprintReadOnly, Category = "Commander|State")
	float AuraActiveSeconds = 0.f;

	/** How long since he died (drives the relay). */
	UPROPERTY(BlueprintReadOnly, Category = "Commander|State")
	float SecondsSinceDeath = 0.f;

	// =========================================================================
	//  API
	// =========================================================================

	/** Register an escort. Called by the spawner and by the assistant itself. */
	UFUNCTION(BlueprintCallable, Category = "Commander")
	void RegisterAssistant(AEnemyCommanderAssistant* Assistant);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Commander")
	int32 GetAliveAssistantCount() const;

	/** Assistants still standing (the relay needs one). */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Commander")
	bool HasAliveAssistant() const;

	/** The command net's current radius (wider in a last stand). */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Commander")
	float GetCurrentAuraRadius() const;

	/** True while the net is up (he lives, or his assistants hold it). */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Commander")
	bool IsAuraActive() const;

	/** Is this actor inside the command net right now? (The aura only writes the numbers
	 *  of actors inside it, and anything outside has to manage its own.) */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Commander")
	bool IsInsideAura(const AActor* Other) const;

	/** Damage reduction a nearby ally gets right now. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Commander")
	float GetAuraResist() const;

	/** Everything the HUD needs in one call. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Commander")
	FEliteSquadTuning GetEliteTuning() const;

	/** Ask for a squad right now. Returns how many actually spawned. */
	UFUNCTION(BlueprintCallable, Category = "Commander")
	int32 CallReinforcements();

	/** Assistant reporting a heal channel (used by the HUD to draw the beam). */
	void NoteHealChannel(AEnemyCommanderAssistant* Assistant, bool bActive);

	/** The assistant currently channeling a heal on him, or nullptr (the HUD draws the beam). */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Commander")
	AEnemyCommanderAssistant* GetHealingAssistant() const;

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void Tick(float DeltaSeconds) override;

	/** S19-CONST: named HandleOwnerDeath, not HandleDeath - the base declares
	 *  virtual void HandleDeath() (no args), so a same-named handler with an AActor*
	 *  parameter did not override it and HID it (C4263/C4264). The name is only used by
	 *  the OnDeath binding below. */
	UFUNCTION()
	void HandleOwnerDeath(AActor* OwnerActor);

	UFUNCTION()
	void HandleDamaged(float Damage, AActor* DamageCauser, float NewHealth);

	/** Apply (or refresh) the net's effects on everything inside it. */
	void RefreshAura();

	/** Hand the net back: multipliers restored to 1, aggression back to base. */
	void ReleaseAura();

	void EnterLastStand();
	void BeginCombatIfNeeded();

	/** Vehicles of the aura bookkeeping: who is currently buffed and when we last touched
	 *  them, so a lapsed net can be undone precisely. */
	struct FAuraTarget
	{
		TWeakObjectPtr<ASoldierCharacter> Soldier;
		float BaseAggression = 0.4f;
		float LastTouched = 0.f;
	};
	TArray<FAuraTarget> AuraTargets;

	/** The commander's live rule set. */
	FEliteSquadTuning Tuning;

	float CombatStartedTime = -1.f;
	float LastReinforcementTime = -1000.f;
	float LastStandEndTime = -1.f;

private:
	TArray<TWeakObjectPtr<AEnemyCommanderAssistant>> Assistants;
	TWeakObjectPtr<AEnemyCommanderAssistant> HealingAssistant;

	/** Nearest wave spawner, found once at BeginPlay and again before any call. */
	void FindBoundSpawner(UWorld* World);

	bool bAuraApplied = false;
	bool bCombatSeen = false;
	bool bBindingsDone = false;
};

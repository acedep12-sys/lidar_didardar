// LeaderCharacter.h — Squad leader: follows quest waypoints and paces speed
#pragma once

#include "CoreMinimal.h"
#include "Characters/SoldierCharacter.h"
#include "SquadTypes.h"
#include "Characters/SquadLeaderTypes.h"
#include "LeaderCharacter.generated.h"

UENUM(BlueprintType)
enum class ELeaderWaypointState : uint8
{
	NotReached,
	Moving,
	Arrived,
	WaitingForClear,
	Completed
};

UCLASS(BlueprintType, Blueprintable)
class SQUADAI_API ALeaderCharacter : public ASoldierCharacter
{
	GENERATED_BODY()

public:
	ALeaderCharacter();

	// ---- Pacing ----
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Leader|Pacing")
	float WaitForPlayerRadius = 1500.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Leader|Pacing")
	float FullSpeedRadius = 800.f;

	// S19-LEASHHYST: the log showed HALT->MOVE->HALT->MOVE every few seconds while the
	// player stood on the leash boundary (playerDist 1459..1559 around a 1500 radius).
	// Once halted, the leader now waits until the player is this fraction of the radius
	// away again - a real catch-up, not a 30 cm wobble.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Leader|Pacing")
	float WaitForPlayerResumeFraction = 0.75f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Leader|Pacing")
	float NormalSpeed = 400.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Leader|Pacing")
	float WaitingSpeed = 120.f;

	// Set by the AI controller when crossing a thin flame. Leader sprints instead of walking in fire.
	UPROPERTY(BlueprintReadWrite, Category = "Leader|Pacing")
	bool bForceSprintThroughHazard = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Leader|Pacing")
	float SprintSpeed = 720.f;

	// S19-LEADWAIT: a player who never catches up must not pin the leader to the map
	// forever. After this many seconds of "player is far and behind", the squad
	// advances anyway (the gate re-arms the moment the player comes back in range).
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Leader|Pacing")
	float MaxWaitForPlayerSeconds = 25.f;

	// ---- Waypoints ----
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Leader|Quest")
	TArray<FQuestWaypoint> QuestWaypoints;

	UPROPERTY(BlueprintReadOnly, Category = "Leader|Quest")
	int32 CurrentWaypointIndex = 0;

private:
	// S19-LEADWAIT / S19-LOGGER (pacing bookkeeping)
	float PacingWaitStartTime = -1.f;
	float LastPacingResumeLogTime = -1000.f;
	bool bLastPacingHalt = false;

public:

	UPROPERTY(BlueprintReadOnly, Category = "Leader|Quest")
	ELeaderWaypointState WaypointState = ELeaderWaypointState::NotReached;

	// ---- API ----
	UFUNCTION(BlueprintCallable, Category = "Leader")
	void SetQuestWaypoints(const TArray<FQuestWaypoint>& Waypoints);

	UFUNCTION(BlueprintCallable, Category = "Leader")
	void BeginQuest();

	UFUNCTION(BlueprintCallable, Category = "Leader")
	bool AdvanceToNextWaypoint();

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Leader")
	bool HasReachedCurrentWaypoint() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Leader")
	bool IsCurrentAreaClear() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Leader")
	FVector GetCurrentWaypointLocation() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Leader")
	float GetPlayerDistance() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Leader")
	bool IsQuestComplete() const;

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Leader|Presentation")
	ESquadAnimationMode AnimationMode = ESquadAnimationMode::PackDriven;

	UPROPERTY(BlueprintReadOnly, Category = "Leader|Presentation")
	ESquadCombatPresentationState PresentationState = ESquadCombatPresentationState::Idle;

	UPROPERTY(BlueprintReadOnly, Category = "Leader|Presentation")
	bool bPresentationCombatReady = false;

	UPROPERTY(BlueprintReadOnly, Category = "Leader|Presentation")
	bool bPresentationAiming = false;

	UPROPERTY(BlueprintReadOnly, Category = "Leader|Presentation")
	bool bPresentationFiring = false;

	UPROPERTY(BlueprintReadOnly, Category = "Leader|Presentation")
	bool bPresentationHasQuest = false;

	UPROPERTY(BlueprintReadOnly, Category = "Leader|Presentation")
	FVector PresentationMoveGoal = FVector::ZeroVector;

	UPROPERTY(BlueprintReadOnly, Category = "Leader|Presentation")
	float PresentationPlayerDistance = 0.f;

	UPROPERTY(BlueprintReadOnly, Category = "Leader|Presentation")
	bool bPresentationWaitingForPlayer = false;

	UPROPERTY(BlueprintReadOnly, Category = "Leader|Presentation")
	bool bPresentationReachedWaypoint = false;

	UPROPERTY(BlueprintReadOnly, Category = "Leader|Presentation")
	bool bPresentationAreaClear = false;

	UPROPERTY(BlueprintReadOnly, Category = "Leader|Presentation")
	int32 PresentationWaypointIndex = INDEX_NONE;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Leader|Presentation")
	FLeaderQuestProgressSnapshot GetQuestProgressSnapshot() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Leader|Presentation")
	bool IsWaitingForPlayer() const;

	/** S19-LEADWAIT: true when the player is closer to the current objective than
	 *  this leader is (i.e. the player is AHEAD of him). Used by the pacing code so
	 *  "player is far away and ahead" speeds the leader up instead of freezing him. */
	bool IsPlayerAheadOnRoute(const class APawn* Player) const;

	/** S19-LEADWAIT: the single pacing decision every movement gate must ask.
	 *  True = stop and wait for the player. False = keep moving (player is within
	 *  the radius, is AHEAD of him on the route, or the bounded wait expired).
	 *  Callers pass the player distance they already computed. */
	bool ShouldHaltForPlayer(float PlayerDist);

	/** S19-LOGGER: the last pacing decision (true = standing still, waiting for the
	 *  player). Read by the situation log so "he stopped walking" is visible. */
	bool IsHoldingForPlayer() const { return bLastPacingHalt; }

	/** S19-LOGGER: seconds the current hold has been running (0 when not holding). */
	float GetPacingWaitSeconds() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Leader|Presentation")
	bool ShouldUsePackAnimationMode() const { return AnimationMode == ESquadAnimationMode::PackDriven; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Leader|Presentation")
	bool IsPresentationCombatReady() const { return bPresentationCombatReady; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Leader|Presentation")
	bool IsPresentationAiming() const { return bPresentationAiming; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Leader|Presentation")
	bool IsPresentationFiring() const { return bPresentationFiring; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Leader|Presentation")
	bool HasPresentationQuest() const { return bPresentationHasQuest; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Leader|Presentation")
	FVector GetPresentationMoveGoal() const { return PresentationMoveGoal; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Leader|Presentation")
	ESquadCombatPresentationState GetPresentationState() const { return PresentationState; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Leader|Presentation")
	bool HasValidWaypointPresentation() const { return PresentationWaypointIndex != INDEX_NONE && QuestWaypoints.IsValidIndex(PresentationWaypointIndex); }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Leader|Presentation")
	ELeaderWaypointState GetWaypointState() const { return WaypointState; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Leader|Presentation")
	int32 GetPresentationWaypointIndex() const { return PresentationWaypointIndex; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Leader|Presentation")
	float GetPresentationPlayerDistance() const { return PresentationPlayerDistance; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Leader|Presentation")
	bool IsPresentationWaitingForPlayer() const { return bPresentationWaitingForPlayer; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Leader|Presentation")
	bool HasReachedWaypointPresentation() const { return bPresentationReachedWaypoint; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Leader|Presentation")
	bool IsPresentationAreaClear() const { return bPresentationAreaClear; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Leader|Presentation")
	bool IsPresentationQuestComplete() const { return WaypointState == ELeaderWaypointState::Completed; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Leader|Presentation")
	bool IsPresentationMovingToWaypoint() const { return WaypointState == ELeaderWaypointState::Moving || WaypointState == ELeaderWaypointState::NotReached; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Leader|Presentation")
	bool HasPresentationMoveGoal() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Leader|Presentation")
	bool HasPresentationWaypointIndex() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Leader|Presentation")
	bool IsPresentationFollowingMissionPath() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Leader|Presentation")
	bool IsPresentationHoldingForCombat() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Leader|Presentation")
	bool IsPresentationAtMissionEnd() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Leader|Presentation")
	FText GetPresentationDebugStateText() const;

protected:
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;

private:
	float LingerTimer = 0.f;
	float PresentationUpdateAccumulator = 0.f;
	void UpdatePacing();
	void UpdateWaypointState(float DeltaTime);
	void UpdatePresentationState();
	float GetPresentationUpdateInterval() const;
};

// SquadAI - Grip socket retargeting.
//
// WHY THIS EXISTS
// ---------------
// A custom character mesh (e.g. the project's V3 character) almost never ships
// with the mannequin's 'RifleSocket'. When a weapon is attached to a socket
// that does not exist, UE silently snaps the attachment to the MESH ROOT --
// which sits between the character's feet. That is the "weapon under the feet"
// bug this module exists to prevent.
//
// The fix is to CLONE the mannequin's grip socket onto the custom rig:
//   1. find the grip socket on the template (mannequin) mesh,
//   2. resolve the matching right-hand bone on the custom rig,
//   3. rebuild the socket's LOCAL transform so it means the same thing in the
//      custom rig's hand frame.
//
// Step 3 is the hard part and is what S19-CLONE3 rewrote. The two rigs differ
// in bone AXES and in SIZE, so copying the template's local offset verbatim
// rotates and scales the offset wrongly. The correct mapping is:
//
//      Delta = inverse(CloneBoneCS.Rot) * TemplateBoneCS.Rot   (FQuat product)
//      OutLoc  = Delta.RotateVector(SocketLoc)  * Ratio
//      OutRot  = (Delta * SocketRot.Quaternion()).Rotator()
//      OutScale= SocketScale * Ratio * ExtraScale
//
// Delta is the rotation that carries a direction from the CLONE hand's frame
// into the TEMPLATE hand's frame, so the socket keeps the same offset and the
// same aim relative to the hand it was authored against -- on a hand of the
// right size. (Note this whole expression uses FQuat only, whose product order
// is the opposite of FTransform's; that is deliberate and is why it is spelled
// out with explicit FQuat multiplications.)
//
// where 'CS' means component space in the REFERENCE POSE, and Ratio is a
// comparable limb-length measurement taken at the SAME chain level on both
// rigs (never the degenerate hand-bone stub, which is ~0 on many rigs and
// produced wild ratios / a rifle the size of a bus).
//
// This header is shared by:
//   * ACharacterCloneStation          (editor -- bakes the socket into an asset)
//   * ASoldierCharacter::ApplyEquippedWeaponAttachment (runtime -- emulates it)
// so both paths stay in agreement. If you change the math here, both change.
//
// Header-only so the station and the character can share it without a new
// module dependency. No UCLASS/UPROPERTY on purpose (S19-CLONE2).
//
// S19-GRIPORDER CORRECTNESS FIXES (this revision):
//   * RefBoneComponentSpace() composed the chain with the operands the WRONG
//     WAY ROUND. UE's TTransform::Multiply() documents "C = A * B will yield a
//     transform C that logically first applies A then B" (FQuat is the
//     opposite order -- that inversion is the trap this code fell into). A
//     bone's component-space pose therefore needs the bone's OWN local pose
//     applied first, walking outwards to the root. The shipped revision did
//     `CS = CS * Local`, i.e. it applied the parent's accumulated transform
//     before the bone's own local pose. On a rig whose rest rotations are all
//     identity the two orders agree; on a real rig (V3 / CC4 / Mixamo -- every
//     bone carries its own rest rotation) the hand frame came out tens of
//     centimetres away and rotated, so the baked/emulated grip socket was
//     twisted and misplaced. Measured on the test rig: 48 cm of error.
//   * SocketComponentSpace() had the same inversion (`BoneCS * Socket`), which
//     matters more than it looks: the clone station's VERIFY step and the
//     runtime emulation read their positions from it, so a correct bake was
//     reported as "socket is at the mesh root / under the feet" in the editor,
//     and the runtime placed the weapon at a pose no socket occupies. Measured
//     on the test rig: 196 cm and 120 deg of error.
//   * BoneSegmentLength() measured a bone by the length of its LAST CHILD's
//     translation, which is 0 for a leaf bone. Every grip bone is a leaf or
//     near-leaf -> ratio always fell back to 1.0 (weapon the wrong size).
//   * Ratio now comes from a chain-level-matched limb segment (hand->wrist->
//     forearm, same level on both rigs) with a root-path-length fallback.
//   * Added SocketComponentSpace() so callers can VERIFY the result (a grip
//     socket below the character's feet is the bug we are hunting).
//
// S19-CLONE3 CORRECTNESS FIXES (kept):
//   * the leaf-safe segment length and the chain-level-matched size ratio;
//   * SocketComponentSpace() as a verification helper -- now with the right
//     composition order (see above).

#pragma once

#include "CoreMinimal.h"
#include "Engine/SkeletalMesh.h"
#include "Engine/SkeletalMeshSocket.h"   // S19-CLONE2: was only forward-declared -> member access was illegal
#include "ReferenceSkeleton.h"

namespace SquadAIGrip
{
	// S19-CLONE2: raised from 1 -> 3. A grip bone is usually a leaf; its last
	// child is INDEX_NONE, so a depth of 1 never found a child to measure.
	enum { MaxBoneSearchDepth = 3 };

	// Guard rails for the size ratio. A ratio outside this range means the two
	// rigs were measured on non-comparable bones; clamp rather than emit a
	// weapon scaled 40x.
	// `inline` matters: a plain namespace-scope constexpr has internal linkage,
	// so every translation unit would get its own copy and these inline
	// functions would technically violate the one-definition rule.
	inline constexpr float MinGripRatio = 0.2f;
	inline constexpr float MaxGripRatio = 5.0f;

	/* Local (parent-space) pose of a bone, straight from the reference skeleton.
	 * Returns identity for an invalid index. */
	inline FTransform RefBoneLocalPose(const FReferenceSkeleton& Ref, int32 BoneIndex)
	{
		if (BoneIndex < 0 || BoneIndex >= Ref.GetNum()) return FTransform::Identity;
		const TArray<FTransform>& Pose = Ref.GetRefBonePose();
		return Pose.IsValidIndex(BoneIndex) ? Pose[BoneIndex] : FTransform::Identity;
	}

	/* Component-space transform of a bone in the REFERENCE POSE.
	 *
	 * S19-GRIPORDER: UE transforms compose LEFT-FIRST. From
	 * TTransform::Multiply() (and the FTransform docs):
	 *
	 *     C = A * B   applies A first, then B
	 *     C.Rotation    = B.Rotation * A.Rotation
	 *     C.Translation = B.Rotation * (B.Scale3D * A.Translation) + B.Translation
	 *
	 * FQuat is the opposite order, which is where the confusion comes from.
	 *
	 * Component space means: apply the bone's own local pose FIRST, then walk
	 * outwards to the parent, the grandparent, ... the root. In this convention
	 * that is written with the local pose on the LEFT:
	 *
	 *     CS[bone] = Local[bone] * CS[parent]
	 *
	 * The previous revision (S19-CLONE3) asserted the opposite and composed
	 * `CS = CS * Local`, i.e. it applied the parent's accumulated transform
	 * before the bone's own local pose. On a rig whose chain rotations are all
	 * identity the two agree, which is why the simple test rigs did not catch
	 * it - on a real rig (every bone carrying its own rest rotation) the "hand"
	 * frame came out as a completely different transform, so Delta was wrong and
	 * the cloned grip socket landed rotated/offset away from the hand.
	 */
	inline FTransform RefBoneComponentSpace(const FReferenceSkeleton& Ref, int32 BoneIndex)
	{
		if (BoneIndex < 0 || BoneIndex >= Ref.GetNum()) return FTransform::Identity;

		const TArray<FTransform>& Pose = Ref.GetRefBonePose();

		// Collect the chain from the bone up to the root, then walk it root->bone
		// so each local pose is applied before the one it is nested inside.
		TArray<int32> Chain;
		Chain.Reserve(64);
		for (int32 Idx = BoneIndex; Idx != INDEX_NONE && Chain.Num() < 512; Idx = Ref.GetParentIndex(Idx))
		{
			Chain.Add(Idx);
			if (Idx == 0) break; // 0 is the root in UE reference skeletons
		}

		// S19-GRIPORDER: THE fix. The bone's own local pose goes on the LEFT --
		// in UE's left-first rule that is what "apply the bone's pose first,
		// then the parent chain it hangs from" means. The shipped code had the
		// operands the other way round, which is the FQuat order, not this one.
		FTransform CS = FTransform::Identity;
		for (int32 i = Chain.Num() - 1; i >= 0; --i)
		{
			const int32 Idx = Chain[i];
			if (Pose.IsValidIndex(Idx))
			{
				CS = Pose[Idx] * CS;   // local first, then everything already accumulated
			}
		}
		return CS;
	}

	/* Length of the segment ENDING at BoneIndex, i.e. the distance from that
	 * bone to its parent, measured in the reference pose.
	 *
	 * S19-CLONE3: the old helper measured a bone by the translation length of
	 * its last CHILD. Every grip bone (hand / wrist) is a leaf or near-leaf, so
	 * it returned 0 and the ratio silently degenerated to 1.0. A bone's own
	 * local translation IS the segment from its parent to itself -- that is the
	 * number we want, and it needs no composition at all.
	 */
	inline float BoneSegmentLength(const FReferenceSkeleton& Ref, int32 BoneIndex)
	{
		return RefBoneLocalPose(Ref, BoneIndex).GetTranslation().Size();
	}

	/* Length of the segment ending N levels ABOVE BoneIndex (0 = the bone's own
	 * segment, 1 = its parent's segment = the forearm when BoneIndex is a hand).
	 * Lets both rigs be measured at the SAME chain level so the ratio is
	 * actually comparable. */
	inline float SegmentLengthAtLevel(const FReferenceSkeleton& Ref, int32 BoneIndex, int32 Level)
	{
		int32 Idx = BoneIndex;
		for (int32 s = 0; s < Level && Idx != INDEX_NONE; ++s)
		{
			Idx = Ref.GetParentIndex(Idx);
		}
		return (Idx == INDEX_NONE) ? 0.f : BoneSegmentLength(Ref, Idx);
	}

	/* Total length of the bone chain from the root down to BoneIndex.
	 * A very stable whole-rig size proxy: it does not depend on finding any one
	 * comparable bone, so it works even on rigs with unusual hand chains. */
	inline float PathLengthFromRoot(const FReferenceSkeleton& Ref, int32 BoneIndex)
	{
		float Total = 0.f;
		for (int32 Idx = BoneIndex; Idx != INDEX_NONE; Idx = Ref.GetParentIndex(Idx))
		{
			Total += BoneSegmentLength(Ref, Idx);
		}
		return Total;
	}

	/* Size ratio Clone/Template, measured on COMPARABLE limb segments.
	 *
	 * We walk up the chain (own segment -> parent's -> grandparent's) and take
	 * the first level at which BOTH rigs report a real, non-degenerate segment
	 * (> 1 cm). Using the same level on both sides is what makes the ratio
	 * meaningful -- mixing a 2 cm hand stub on one rig with a 30 cm forearm on
	 * the other is exactly how the old code produced absurd scales.
	 *
	 * Falls back to root-path length, then to 1.0 (no scaling) if the rigs
	 * cannot be compared at all. Never divides by zero. */
	inline float ComputeSizeRatio(const FReferenceSkeleton& CloneRef, int32 CloneBone,
		const FReferenceSkeleton& TemplateRef, int32 TemplateBone,
		FString* OutWhy = nullptr)
	{
		constexpr float MinSegment = 1.f; // cm -- below this the segment is a stub

		for (int32 Level = 0; Level < MaxBoneSearchDepth; ++Level)
		{
			const float C = SegmentLengthAtLevel(CloneRef, CloneBone, Level);
			const float T = SegmentLengthAtLevel(TemplateRef, TemplateBone, Level);
			if (C > MinSegment && T > MinSegment)
			{
				const float Ratio = FMath::Clamp(C / T, MinGripRatio, MaxGripRatio);
				if (OutWhy)
				{
					*OutWhy = FString::Printf(TEXT("ratio %.3f from chain level %d (clone %.2fcm / template %.2fcm)"),
						Ratio, Level, C, T);
				}
				return Ratio;
			}
		}

		// Fallback: whole-chain length from the root. Robust, less precise.
		const float C = PathLengthFromRoot(CloneRef, CloneBone);
		const float T = PathLengthFromRoot(TemplateRef, TemplateBone);
		if (C > MinSegment && T > MinSegment)
		{
			const float Ratio = FMath::Clamp(C / T, MinGripRatio, MaxGripRatio);
			if (OutWhy)
			{
				*OutWhy = FString::Printf(TEXT("ratio %.3f from root-path length (clone %.2fcm / template %.2fcm)"),
					Ratio, C, T);
			}
			return Ratio;
		}

		if (OutWhy) *OutWhy = TEXT("ratio 1.000 (rigs not comparable -- no scaling applied)");
		return 1.f;
	}

	/* Component-space transform of a SOCKET in the reference pose.
	 * Used to verify the baked result: a grip socket whose component-space Z is
	 * at or below 0 sits at/below the character's feet, i.e. the bug we hunt.
	 *
	 * S19-GRIPORDER: this used to compute `BoneCS * S`, which under UE's
	 * left-first rule applies the BONE first and the socket offset second -- the
	 * wrong way round. Longhand, the socket's component-space pose is
	 *
	 *     rot = BoneCS.Rot * Socket.Rot
	 *     loc = BoneCS.Loc + BoneCS.Rot.RotateVector(Socket.Loc * Socket.Scale)
	 *
	 * i.e. the socket's own local offset is expressed in the bone's frame and
	 * then carried out to the root: `S * BoneCS`. Measured on a CC-style rig
	 * with a -90 roll grip socket, the old order reported the socket 196 cm
	 * from where it actually is, with a 120 deg orientation error -- so both
	 * the station's VE RIFY check and the runtime emulation were reading a
	 * position that no socket ever occupies.
	 */
	inline FTransform SocketComponentSpace(const USkeletalMesh* Mesh, const USkeletalMeshSocket* Socket)
	{
		if (!Mesh || !Socket) return FTransform::Identity;
		const FReferenceSkeleton& Ref = Mesh->GetRefSkeleton();
		const int32 Bone = Ref.FindBoneIndex(Socket->BoneName);
		if (Bone == INDEX_NONE) return FTransform::Identity;
		// S19-GRIPORDER: the socket's own pose is what gets applied first; it is
		// expressed in the bone's frame, so the bone's transform carries it out.
		const FTransform S(Socket->RelativeRotation, Socket->RelativeLocation, Socket->RelativeScale);
		return S * RefBoneComponentSpace(Ref, Bone);
	}

	/* Rebuild a template grip socket so it is correct on the clone's skeleton.
	 *
	 * TemplateMesh/TemplateSocket : the mannequin's mesh + grip socket.
	 * CloneMesh/CloneBoneName     : the V3 (or any custom) rig + its hand bone.
	 * bScaleCompensate            : fold the rig size ratio into location+scale.
	 * ExtraScale                  : designer multiplier (WeaponScaleMultiplier).
	 * OutWhy                      : human-readable explanation for the log.
	 *
	 * Returns false if the inputs cannot be resolved; on false the outputs are
	 * left untouched so callers can safely fall back to a verbatim copy.
	 */
	inline bool RetargetSocketTransform(
		const USkeletalMesh* TemplateMesh,
		const USkeletalMeshSocket* TemplateSocket,
		const USkeletalMesh* CloneMesh,
		FName CloneBoneName,
		bool bScaleCompensate,
		float ExtraScale,
		FVector& OutLoc,
		FRotator& OutRot,
		FVector& OutScale,
		FString& OutWhy)
	{
		if (!TemplateMesh || !TemplateSocket || !CloneMesh || CloneBoneName.IsNone())
		{
			OutWhy = TEXT("retarget skipped (missing mesh/socket/bone)");
			return false;
		}

		const FReferenceSkeleton& TRef = TemplateMesh->GetRefSkeleton();
		const FReferenceSkeleton& CRef = CloneMesh->GetRefSkeleton();

		const int32 TBone = TRef.FindBoneIndex(TemplateSocket->BoneName);
		const int32 CBone = CRef.FindBoneIndex(CloneBoneName);
		if (TBone == INDEX_NONE || CBone == INDEX_NONE)
		{
			OutWhy = FString::Printf(TEXT("retarget skipped (bone missing: template '%s'=%d, clone '%s'=%d)"),
				*TemplateSocket->BoneName.ToString(), TBone, *CloneBoneName.ToString(), CBone);
			return false;
		}

		// Bone frames in component space, reference pose.
		const FTransform TCS = RefBoneComponentSpace(TRef, TBone);
		const FTransform CCS = RefBoneComponentSpace(CRef, CBone);

		// Rotation from the clone's hand frame into the template's hand frame.
		// Delta = inverse(CloneBoneCS.Rotation) * TemplateBoneCS.Rotation
		const FQuat Delta = CCS.GetRotation().Inverse() * TCS.GetRotation();

		// Size compensation, measured at a matching chain level on both rigs.
		FString RatioWhy;
		const float Ratio = bScaleCompensate ? ComputeSizeRatio(CRef, CBone, TRef, TBone, &RatioWhy) : 1.f;
		const float SafeExtra = FMath::Max(0.01f, ExtraScale);

		const FVector SrcLoc = TemplateSocket->RelativeLocation;
		const FQuat   SrcRot = TemplateSocket->RelativeRotation.Quaternion();
		const FVector SrcScale = TemplateSocket->RelativeScale;

		OutLoc   = Delta.RotateVector(SrcLoc) * Ratio;
		OutRot   = (Delta * SrcRot).Rotator();
		OutScale = SrcScale * Ratio * SafeExtra;   // fix: was BaseScale * Ratio * max(0.01,Extra),
		                                           // which threw away the socket's own authored scale

		OutWhy = FString::Printf(TEXT("template bone '%s' -> clone bone '%s'; %s; loc %s; rot %s; scale %s"),
			*TemplateSocket->BoneName.ToString(), *CloneBoneName.ToString(), *RatioWhy,
			*OutLoc.ToString(), *OutRot.ToString(), *OutScale.ToString());
		return true;
	}

	/* Resolve the RIGHT-HAND bone on an arbitrary rig.
	 *
	 * Order:
	 *   1. the template socket's own bone, if this rig happens to have it
	 *      (identical rigs -- the cheap, exact case),
	 *   2. a list of known right-hand bone names (UE / Mixamo / 3dsMax Biped /
	 *      Character Creator / V3-style),
	 *   3. a scored scan of every bone: 'hand' / 'wrist' / 'palm' are positive
	 *      evidence, 'right' reinforces, 'left' disqualifies, and finger /
	 *      thumb / ik / twist / roll bones are penalised so we never pick a
	 *      thumb tip. Requires Score >= 6 to accept.
	 *
	 * Context is used only for log messages. Returns NAME_None if nothing
	 * matches -- callers must treat that as a failure, never as "use the root",
	 * because "the root" is the feet.
	 */
	inline FName ResolveRightHandBone(const USkeletalMesh* Mesh,
		const USkeletalMeshSocket* TemplateSocket = nullptr,
		const TCHAR* Context = TEXT("Grip"))
	{
		if (!Mesh) return NAME_None;
		const FReferenceSkeleton& Ref = Mesh->GetRefSkeleton();

		// 1. Same bone name as the template socket (identical rigs).
		if (TemplateSocket && Ref.FindBoneIndex(TemplateSocket->BoneName) != INDEX_NONE)
		{
			return TemplateSocket->BoneName;
		}

		// 2. Known right-hand bone names, in rough order of likelihood.
		static const FName HandBones[] = {
			TEXT("hand_r"), TEXT("Hand_R"), TEXT("RightHand"), TEXT("right_hand"),
			TEXT("mixamorig:RightHand"), TEXT("Bip001-R-Hand"), TEXT("CC_Base_R_Hand"),
			TEXT("R_Hand"), TEXT("RightHandBone"), TEXT("r_hand"), TEXT("RightHandIndex1")
		};
		for (const FName& Candidate : HandBones)
		{
			if (Ref.FindBoneIndex(Candidate) != INDEX_NONE)
			{
				UE_LOG(LogTemp, Log, TEXT("[%s] right-hand bone '%s' (known name) on '%s'"),
					Context, *Candidate.ToString(), *GetNameSafe(Mesh));
				return Candidate;
			}
		}

		// 3. Scored scan over every bone.
		int32 BestIndex = INDEX_NONE;
		int32 BestScore = 0;
		const int32 NumBones = Ref.GetNum();
		for (int32 i = 0; i < NumBones; ++i)
		{
			const FString Name = Ref.GetBoneName(i).ToString();
			const FString Lower = Name.ToLower();

			int32 Score = 0;
			if (Lower.Contains(TEXT("hand")))  Score += 4;
			if (Lower.Contains(TEXT("wrist"))) Score += 3;
			if (Lower.Contains(TEXT("palm")))  Score += 2;
			if (Lower.Contains(TEXT("right"))) Score += 4;
			if (Lower.Contains(TEXT("left")))  Score -= 10;      // disqualify
			if (Lower.Contains(TEXT("finger")) || Lower.Contains(TEXT("thumb")) ||
				Lower.Contains(TEXT("index"))  || Lower.Contains(TEXT("pinky"))  ||
				Lower.Contains(TEXT("ring"))   || Lower.Contains(TEXT("middle"))) Score -= 5;
			if (Lower.Contains(TEXT("ik"))    || Lower.Contains(TEXT("twist")) ||
				Lower.Contains(TEXT("roll"))   || Lower.Contains(TEXT("nub"))   ||
				Lower.Contains(TEXT("end"))) Score -= 5;

			if (Score > BestScore)
			{
				BestScore = Score;
				BestIndex = i;
			}
		}

		if (BestIndex != INDEX_NONE && BestScore >= 6)
		{
			const FName Bone = Ref.GetBoneName(BestIndex);
			UE_LOG(LogTemp, Log, TEXT("[%s] right-hand bone '%s' (scanned, score %d) on '%s'"),
				Context, *Bone.ToString(), BestScore, *GetNameSafe(Mesh));
			return Bone;
		}

		UE_LOG(LogTemp, Warning, TEXT("[%s] could not resolve a right-hand bone on '%s' (best score %d, need >= 6). "
			"Set the grip bone explicitly, otherwise the weapon will attach at the feet."),
			Context, *GetNameSafe(Mesh), BestScore);
		return NAME_None;
	}
}

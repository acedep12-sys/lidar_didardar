// EnemyPatroller.h - S19-PATROL: the enemy that walks a patrol route
//
// He walks a route (an AEnemyPatrolRoute's points, in order: 1 -> 2 -> 3 -> ...), pausing at
// each point, and he is otherwise a perfectly ordinary SquadAI enemy - he takes cover, fires,
// is suppressed, dies. The ONE thing that is different about him is his attention: he does not
// hunt, he does not advance on the objective, and he does not shoot you from 80 m. He notices
// a hostile (you, or any ally) inside SpotRange with line of sight, or inside SpotHearRange
// through cover - then he attacks, and shouts to the other patrols near him.
//
// The route rules are pure functions in Tactical/PatrolRouteModel.h, unit-tested offline.
#pragma once

#include "CoreMinimal.h"
#include "Characters/EnemySoldier.h"
#include "Tactical/PatrolRouteModel.h"
#include "EnemyPatroller.generated.h"

class AEnemyPatrolRoute;
class UCharacterMovementComponent;

/** How he walks his points. */
UENUM(BlueprintType)
enum class EPatrolMode : uint8
{
	/** 1 -> 2 -> 3 -> 1 -> ... a closed circuit. The default: this is a patrol beat. */
	Loop      UMETA(DisplayName = "Loop (1 -> 2 -> 3 -> 1)"),
	/** 1 -> 2 -> 3 -> 2 -> 1 -> ... he turns around at each end. */
	PingPong  UMETA(DisplayName = "Ping-pong (1 -> 2 -> 3 -> 2)"),
	/** 1 -> 2 -> 3, then he holds the last point for good. */
	Once      UMETA(DisplayName = "Once (1 -> 2 -> 3, then hold)")
};

UCLASS(BlueprintType, Blueprintable)
class SQUADAI_API AEnemyPatroller : public AEnemySoldier
{
	GENERATED_BODY()

public:
	AEnemyPatroller();

	// ===== the route =====

	/** The route he walks. Leave empty and he binds to the nearest route within
	 *  AutoBindRouteRadius at BeginPlay - which is the whole point of the route actor being a
	 *  separate thing: place the route, place the enemy, done. */
	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "Patrol|Route")
	TObjectPtr<AEnemyPatrolRoute> PatrolRoute;

	/** How far away (3D, to the route LINE) a route may be and still be picked up
	 *  automatically. **0 switches auto-binding off** - useful when a level has several routes
	 *  and you want this pawn on a specific one via the Patrol Route field. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Patrol|Route", meta = (ClampMin = "0.0"))
	float AutoBindRouteRadius = 6000.f;

	/** Start on the point nearest to where he is standing (so a placed patroller does not walk
	 *  across the field to reach "point 1" first). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Patrol|Route")
	bool bStartAtNearestPoint = true;

	/** Only used when bStartAtNearestPoint is off. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Patrol|Route",
		meta = (EditCondition = "!bStartAtNearestPoint", ClampMin = "0"))
	int32 StartPointIndex = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Patrol|Route")
	EPatrolMode PatrolMode = EPatrolMode::Loop;

	// ===== movement =====

	/** Close enough to count as standing on the point. Floored at 50 cm internally, so a 0 in
	 *  this field cannot make him circle a point forever. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Patrol|Movement", meta = (ClampMin = "0.0"))
	float ArriveRadius = 150.f;

	/** His walking pace. Slower than a soldier's - he is on a beat, not assaulting. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Patrol|Movement", meta = (ClampMin = "0.0"))
	float PatrolWalkSpeed = 220.f;

	/** Pace once he is alerted and has to move (close distance, take cover). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Patrol|Movement", meta = (ClampMin = "0.0"))
	float AlertWalkSpeed = 450.f;

	// ===== attention: "if they see me or allies in short range, they will attack" =====

	/** He sees a hostile this far away, line of sight required. 26 m: short range. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Patrol|Alert", meta = (ClampMin = "200.0"))
	float SpotRange = 2600.f;

	/** This close he notices you even without line of sight (footsteps, kit, voices). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Patrol|Alert", meta = (ClampMin = "0.0"))
	float SpotHearRange = 900.f;

	/** How long he stays hot after losing sight of everything. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Patrol|Alert", meta = (ClampMin = "0.0"))
	float AlertLingerSeconds = 12.f;

	/** While he can still SEE the target, the alert holds out to SpotRange x this. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Patrol|Alert", meta = (ClampMin = "1.0"))
	float AlertVisibleRangeScale = 1.6f;

	/** Shout to other patrols when he spots something (they step up without shouting onward). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Patrol|Alert")
	bool bAlertNearbyPatrols = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Patrol|Alert",
		meta = (EditCondition = "bAlertNearbyPatrols", ClampMin = "0.0"))
	float PatrolShoutRadius = 4000.f;

	/** He will not chase further than this from his route; past it he breaks off and walks
	 *  back. 0 disables the leash (he chases as far as the fight goes). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Patrol|Alert", meta = (ClampMin = "0.0"))
	float RouteLeashRadius = 6000.f;

	// ===== integration =====

	/** Patrols do not join the suppressive-fire team (it would drag them off their beat). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Patrol|Integration")
	bool bJoinFireteam = false;

	/** A patroller is not an assault enemy: he holds his ground rather than charging. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Patrol|Integration", meta = (ClampMin = "0.0", ClampMax = "1.0"))
	float PatrolAggression = 0.3f;

	/** Draw the route and his current target point in-game (debug lines only - no lighting,
	 *  no post-process). Off by default; useful while wiring a level up. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Patrol|Debug")
	bool bDrawPatrolDebug = false;

	// ===== state (read-only) =====

	UPROPERTY(BlueprintReadOnly, Category = "Patrol|State")
	bool bAlerted = false;

	/** Set when he had to break off a chase to get back to his beat. */
	UPROPERTY(BlueprintReadOnly, Category = "Patrol|State")
	bool bReturningToRoute = false;

	UPROPERTY(BlueprintReadOnly, Category = "Patrol|State")
	int32 CurrentPointIndex = 0;

	UPROPERTY(BlueprintReadOnly, Category = "Patrol|State")
	FVector CurrentPatrolPoint = FVector::ZeroVector;

	// ===== API =====

	/** Point him at a route (a spawner, a script, or the auto-bind at BeginPlay). */
	UFUNCTION(BlueprintCallable, Category = "Patrol")
	void SetPatrolRoute(AEnemyPatrolRoute* NewRoute, bool bSnapToNearestPoint = true);

	UFUNCTION(BlueprintPure, Category = "Patrol")
	AEnemyPatrolRoute* GetPatrolRoute() const { return PatrolRoute; }

	UFUNCTION(BlueprintPure, Category = "Patrol")
	bool IsAlerted() const { return bAlerted; }

	/** True while he is alerted AND has a hostile of his own to deal with: the only state in
	 *  which his movement belongs to the combat AI instead of to his route. Alerted without a
	 *  target (a neighbour's shout, a scripted ForceAlert) keeps him on his beat - walking it
	 *  at AlertWalkSpeed with his eyes open. */
	UFUNCTION(BlueprintPure, Category = "Patrol")
	bool IsEngaged() const { return bAlerted && LastSpottedActor.IsValid(); }

	/** The live attention envelope (what his controller's engagement reach is clamped to). */
	UFUNCTION(BlueprintPure, Category = "Patrol")
	float GetSpotRange() const { return Tuning.SpotRange; }

	UFUNCTION(BlueprintPure, Category = "Patrol")
	float GetSpotHearRange() const { return Tuning.SpotHearRange; }

	UFUNCTION(BlueprintPure, Category = "Patrol")
	FVector GetCurrentPatrolPoint() const { return CurrentPatrolPoint; }

	UFUNCTION(BlueprintPure, Category = "Patrol")
	int32 GetCurrentPointIndex() const { return CurrentPointIndex; }

	/** Another patrol spotted something: step up, but do not shout onward (no chains). */
	UFUNCTION(BlueprintCallable, Category = "Patrol")
	void ReceivePatrolAlert(const FVector& FromLocation);

	/** Force the alert from Blueprint or script (a commander's order, a scripted event). */
	UFUNCTION(BlueprintCallable, Category = "Patrol")
	void ForceAlert(const FString& Reason);

	/** Send him back to his beat and calm him down. */
	UFUNCTION(BlueprintCallable, Category = "Patrol")
	void ReturnToRoute();

protected:
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaSeconds) override;

	UFUNCTION()
	void HandlePatrollerDamaged(float Damage, AActor* DamageCauser, float NewHealth);

private:
	void SyncTuning();
	void ConfigureController();
	void AcquireRoute();
	void UpdateAlert(float DeltaSeconds);
	void EnterAlert(const FString& Reason, bool bBroadcast);
	void ExitAlert(const FString& Reason);
	void AlertNearbyPatrols();
	void UpdatePatrol(float DeltaSeconds);
	void HandleTeleportWake(const FVector& Where);
	void DrivePatrolMovement();
	void ApplyWalkSpeed();
	void DrawPatrolDebug() const;

	/** The EPatrolMode switch: the only place the reflected enum meets the tested model. */
	FPatrolCursor AdvanceCursorForMode(const FPatrolCursor& In, int32 Count) const;

	FPatrolTuning Tuning;
	FPatrolCursor Cursor;
	TWeakObjectPtr<AActor> LastSpottedActor;

	bool bWaiting = false;
	float WaitRemaining = 0.f;
	float SecondsSinceSpotted = 0.f;
	float LastRepathTime = -1000.f;
	float LastDamagedTime = -1000.f;
	float NextRouteScanTime = -1.f;
	/** Last tick's location: a long jump in one tick means he was moved, not that he walked. */
	FVector LastTickLocation = FVector::ZeroVector;
	FVector LastMoveGoal = FVector::ZeroVector;

	bool bBindingsDone = false;
	/** True when PatrolRoute was picked automatically (so a teleport can re-pick it). */
	bool bRouteAutoBound = false;
	bool bControllerConfigured = false;
	bool bNoRouteLogged = false;
};

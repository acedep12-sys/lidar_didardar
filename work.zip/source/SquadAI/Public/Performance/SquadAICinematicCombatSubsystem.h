#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "SquadAICinematicCombatSubsystem.generated.h"

class ASoldierCharacter;
class USoundBase;

/**
 * USquadAICinematicCombatSubsystem
 * Cinematic Combat FX, Slow-Motion Hero Moments & Dynamic Impact Audio.
 * 
 * Automatically delivers AAA combat polish (last-kill slow-mo, headshot audio punch,
 * and encounter victory stingers) without requiring custom blueprint wiring.
 */
UCLASS()
class SQUADAI_API USquadAICinematicCombatSubsystem : public UWorldSubsystem
{
	GENERATED_BODY()

public:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

	static USquadAICinematicCombatSubsystem* Get(const UObject* WorldContextObject);

	// =========================================================================
	//  CONFIG
	// =========================================================================

	/** If true, triggers a 0.35x slow-motion hero moment when the last hostile of an encounter dies */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Cinematic Combat")
	bool bEnableLastKillSlowMo = true;

	/** Duration in real seconds of slow motion effect */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Cinematic Combat", meta = (ClampMin = "0.2", ClampMax = "3.0"))
	float SlowMoDurationSeconds = 1.25f;

	/** Time dilation factor during slow mo (0.35 = 35% speed) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Cinematic Combat", meta = (ClampMin = "0.1", ClampMax = "0.9"))
	float SlowMoTimeDilation = 0.35f;

	/** Optional victory audio stinger */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Cinematic Combat|Audio")
	TObjectPtr<USoundBase> VictoryStingerSound;

	// =========================================================================
	//  API
	// =========================================================================

	UFUNCTION(BlueprintCallable, Category = "Cinematic Combat")
	void TriggerCinematicHeroMoment(float Dilation = 0.35f, float Duration = 1.25f);

	UFUNCTION(BlueprintCallable, Category = "Cinematic Combat")
	void NotifyEnemyEliminated(ASoldierCharacter* DeadSoldier, bool bWasHeadshot, bool bWasLastEnemyInArea);

private:
	FTimerHandle SlowMoTimerHandle;
	void RestoreTimeDilation();
};

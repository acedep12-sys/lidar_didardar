// SoldierRegistrySubsystem.h — Sparse 2D spatial hash for O(K) soldier queries
// Every soldier registers on BeginPlay. Bullets query nearby for suppression.
// Rebuilds buckets every 0.2s. O(K) where K = nearby soldiers, not O(N total).
#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "Tickable.h"
#include "Engine/EngineTypes.h"
#include "SoldierRegistrySubsystem.generated.h"

class ASoldierCharacter;
class ASoldierAIController;
class APawn;

UCLASS()
class SQUADAI_API USoldierRegistrySubsystem : public UTickableWorldSubsystem
{
	GENERATED_BODY()

public:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;
	virtual void Tick(float DeltaTime) override;
	virtual bool IsTickable() const override;
	virtual TStatId GetStatId() const override
	{
		RETURN_QUICK_DECLARE_CYCLE_STAT(USoldierRegistrySubsystem, STATGROUP_Tickables);
	}

	// ---- Registration ----

	void RegisterSoldier(ASoldierCharacter* Soldier);
	void UnregisterSoldier(ASoldierCharacter* Soldier);

	// ---- Queries ----

	// Find all soldiers within Radius of Center — O(K) not O(N)
	TArray<ASoldierCharacter*> QueryRadius(FVector Center, float Radius) const;

	// Apply suppression to all AI within Radius of a bullet path
	void ApplySuppressionAlongPath(FVector Start, FVector End, float Radius, float Amount, AActor* Ignore = nullptr);

	// Count hostiles near a point (for leader area-clear check)
	int32 CountHostilesNear(FVector Center, float Radius, uint8 FriendlyTeamId) const;

	// ---- Tactical Smoke Screening ----
	struct FActiveSmokeCloud
	{
		FVector Location = FVector::ZeroVector;
		float Radius = 600.f;
		float ExpirationTime = 0.f;
	};

	void RegisterSmokeCloud(const FVector& Location, float Radius, float Duration);
	bool IsLineOfSightBlockedBySmoke(const FVector& Start, const FVector& End) const;
	const TArray<FActiveSmokeCloud>& GetActiveSmokeClouds() const { return ActiveSmokeClouds; }

	// Get all registered soldiers (for minimap rendering — O(1) instead of TActorIterator)
	const TArray<TWeakObjectPtr<ASoldierCharacter>>& GetAllSoldiers() const { return AllSoldiers; }

	// Loaded pawns, rebuilt ~1 Hz. Replaces per-AI TActorIterator<APawn>.
	const TArray<TWeakObjectPtr<APawn>>& GetBroadPawns() const { return BroadPawns; }

private:
	// All registered soldiers
	UPROPERTY()
	TArray<TWeakObjectPtr<ASoldierCharacter>> AllSoldiers;

	// 2D spatial hash buckets
	struct FBucket
	{
		TArray<TWeakObjectPtr<ASoldierCharacter>> Soldiers;
	};

	TMap<FIntPoint, FBucket> Buckets;
	float CellSize = 4000.f;
	float RebuildInterval = 0.2f;
	float TimeSinceRebuild = 0.f;

	TArray<TWeakObjectPtr<APawn>> BroadPawns;
	float TimeSincePawnCache = 0.f;
	float PawnCacheInterval = 1.f;
	FTimerHandle RebuildTimer;

	TArray<FActiveSmokeCloud> ActiveSmokeClouds;

	void EnsureRebuildTimer();
	void StopRebuildTimer();
	void RunRebuild();
	void RebuildBuckets();
	void RebuildBroadPawns();
	FIntPoint WorldToCell(FVector Pos) const;
	TArray<FIntPoint> GetCellsInRadius(FVector Center, float Radius) const;
};

// SquadAIPlayerDiagnosticSubsystem.h — Player setup: wall-check fix + combat bridge (always); weapon diagnostic (dev only)
// Place this file in SquadAI/Public/Performance/
#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "Engine/EngineTypes.h"
#include "SquadAIPlayerDiagnosticSubsystem.generated.h"

UCLASS()
class SQUADAI_API USquadAIPlayerDiagnosticSubsystem : public UTickableWorldSubsystem
{
	GENERATED_BODY()

public:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;
	virtual void Tick(float DeltaTime) override;
	virtual bool IsTickable() const override;
	virtual TStatId GetStatId() const override { RETURN_QUICK_DECLARE_CYCLE_STAT(USquadAIPlayerDiagnosticSubsystem, STATGROUP_Tickables); }

	// P1-2: master setup toggle. Wall-check fix + combat bridge ALWAYS apply (gameplay);
	// the weapon DIAGNOSTIC attach additionally requires a Debug/Development build.
	UPROPERTY()
	bool bAutoAttachDiagnostic = true;

private:
	bool bFixApplied = false;
	bool bDiagnosticAttached = false;
	bool bCombatBridgeAttached = false;
	// S27-FP: first-person conversion component — attached next to the combat
	// bridge, same per-pawn FindComponentByClass check so a respawned pawn gets
	// its own (the flag is about the CURRENT pawn, not "ever attached").
	bool bFirstPersonAttached = false;
	bool bSetupComplete = false;  // All components attached + fix applied
	float FixReapplyTimer = 0.f;
	float TickThrottleTimer = 0.f;
	FTimerHandle WallFixTimer;
	// S14-NAVDIAG: periodic runtime navmesh census — logs every nav data actor,
	// its runtime-generation mode and live tile count. Exists because the
	// editor said the navmesh was fine while the game demonstrably had none;
	// this prints what the GAME actually holds, ending that argument with data.
	bool bNavCensusScheduled = false;
	FTimerHandle NavCensusTimer;
	// S14-GHOST: periodic hostile census — one line per living enemy with
	// position, distance to player, visibility, controller/StateTree state and
	// movement mode. Exists because the HUD hostile count climbed while the
	// map looked empty; this shows exactly WHERE every counted hostile is.
	FTimerHandle GhostCensusTimer;
	void ReapplyWallFix();
	void StartWallFixTimer();
	void LogNavmeshCensus();
	void LogHostileCensus();
};

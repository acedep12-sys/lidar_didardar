#pragma once

#include "CoreMinimal.h"
#include "Containers/Ticker.h"
#include "Subsystems/WorldSubsystem.h"
#include "SquadAIFXManagerSubsystem.generated.h"

class UDecalComponent;
class UMaterialInterface;
class UNiagaraSystem;
class UNiagaraComponent;
class USoundBase;

/**
 * USquadAIFXManagerSubsystem
 * High-Performance Decal Ring-Buffer, FX Budget Allocator & Niagara Explosion Subsystem.
 * 
 * Prevents GPU/CPU bottlenecks during intense 50+ enemy horde firefights by:
 * 1. Managing a zero-allocation circular ring-buffer for impact decals (bullet holes, scorch marks, blood splatters).
 * 2. Throttling visual effect (Niagara / Cascade) spawn rates based on player camera distance.
 * 3. Enforcing hardware audio voice limits on rapid-fire gunshots and explosions.
 * 4. Providing central Niagara explosion FX bindings exposed to editor and auto-resolved from /Game/NiagaraExamples/FX_Explosions.
 */
UCLASS(BlueprintType)
class SQUADAI_API USquadAIFXManagerSubsystem : public UWorldSubsystem
{
	GENERATED_BODY()

public:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|FX Manager", meta = (WorldContext = "WorldContextObject"))
	static USquadAIFXManagerSubsystem* Get(const UObject* WorldContextObject);

	// =========================================================================
	//  DECAL RING-BUFFER & BUDGET MANAGEMENT
	// =========================================================================

	/**
	 * Spawns an impact decal via the circular ring-buffer.
	 * Reuses the oldest decal component when the budget is reached, preventing GC churn.
	 */
	UFUNCTION(BlueprintCallable, Category = "SquadAI|FX Manager")
	UDecalComponent* SpawnImpactDecal(
		UMaterialInterface* DecalMaterial,
		FVector Location,
		FVector Normal,
		FVector DecalSize = FVector(8.f, 16.f, 16.f),
		float LifeSpan = 30.f,
		float FadeDuration = 3.f);

	/** Maximum allowed concurrent decals in the world (default: 128) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|FX Config", meta = (ClampMin = "16", ClampMax = "512"))
	int32 MaxActiveDecals = 128;

	// =========================================================================
	//  NIAGARA EXPLOSION SYSTEMS & DEFAULTS
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|Niagara Explosions")
	TObjectPtr<UNiagaraSystem> NS_Dirt_Explosion;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|Niagara Explosions")
	TObjectPtr<UNiagaraSystem> NS_Dirt_Explosion_Medium;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|Niagara Explosions")
	TObjectPtr<UNiagaraSystem> NS_Dirt_Explosion_Small;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|Niagara Explosions")
	TObjectPtr<UNiagaraSystem> NS_Explosion;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|Niagara Explosions")
	TObjectPtr<UNiagaraSystem> NS_Explosion_Medium;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|Niagara Explosions")
	TObjectPtr<UNiagaraSystem> NS_Explosion_Small;

	/** Attempts to auto-resolve missing Niagara explosion systems from /Game/NiagaraExamples/FX_Explosions */
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Niagara Explosions")
	void AutoResolveNiagaraExplosions();

	/** Spawns a high-fidelity Niagara explosion matched to radius and terrain type */
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Niagara Explosions")
	UNiagaraComponent* SpawnExplosionFX(FVector Location, float Radius = 500.f, bool bDirtExplosion = true);

	// =========================================================================
	//  PARTICLE & VFX RATE LIMITING
	// =========================================================================

	/**
	 * Determines if a new impact VFX should be spawned or culled based on distance and budget.
	 * Returns true if permitted to spawn, false if throttled.
	 */
	UFUNCTION(BlueprintCallable, Category = "SquadAI|FX Manager")
	bool CanSpawnImpactVFX(FVector Location, float MaxDistance = 8000.f);

	/**
	 * Determines if a weapon fire sound or muzzle flash should execute.
	 */
	UFUNCTION(BlueprintCallable, Category = "SquadAI|FX Manager")
	bool CanPlayWeaponAudio(FVector Location, float MaxDistance = 12000.f);

	/** Clear all active pooled decals and reset budgets */
	UFUNCTION(BlueprintCallable, Category = "SquadAI|FX Manager")
	void FlushAllDecals();

private:
	UPROPERTY()
	TArray<TObjectPtr<UDecalComponent>> DecalRingBuffer;

	int32 DecalBufferHead = 0;

	// Per-second particle & audio counters (reset every 1.0s by BudgetResetTickerHandle, B7-1)
	int32 ImpactFXCountThisSecond = 0;
	int32 WeaponAudioCountThisSecond = 0;
	float SecondTimer = 0.f;
	FTSTicker::FDelegateHandle BudgetResetTickerHandle;
};

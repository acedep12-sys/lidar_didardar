// SquadAIPlayerWeaponDiagnostic.h — Runtime diagnostic for player weapon state
// Place this file in SquadAI/Public/Performance/
// This component auto-attaches to the local player character and logs weapon state
// to help diagnose Bug 1 (player loses shooting at distance from spawn).
#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "SquadAIPlayerWeaponDiagnostic.generated.h"

UCLASS(ClassGroup = (SquadAI), meta = (BlueprintSpawnableComponent))
class SQUADAI_API USquadAIPlayerWeaponDiagnostic : public UActorComponent
{
	GENERATED_BODY()

public:
	USquadAIPlayerWeaponDiagnostic();

	// How often to log weapon state (seconds). 0 = every frame.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Diagnostic")
	float LogInterval = 3.0f;

	// Enable/disable logging
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Diagnostic")
	bool bEnableLogging = false;

	// Log detailed weapon component properties via reflection
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Diagnostic")
	bool bLogDetailedProperties = false;

protected:
	virtual void BeginPlay() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

private:
	float TimeSinceLastLog = 0.f;
	FVector LastLogLocation = FVector::ZeroVector;
	bool bLastHadWeapon = false;
	bool bLastWasAiming = false;
	bool bLastWasShooting = false;

	void LogWeaponState();
	void LogDetailedWeaponProperties(UObject* WeaponTarget);
	static UObject* FindPlayerWeaponComponent(AActor* Owner);
};

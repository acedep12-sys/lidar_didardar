// DifficultySubsystem.h — One-call difficulty change
// SetDifficulty(EGameDifficulty) walks every registered soldier and adjusts stats
// Uses SoldierRegistry (O(K)), not TActorIterator (O(N))
#pragma once

#include "CoreMinimal.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "SquadTypes.h"
#include "DifficultySubsystem.generated.h"

class ASoldierCharacter;

UCLASS()
class SQUADAI_API UDifficultySubsystem : public UGameInstanceSubsystem
{
	GENERATED_BODY()

public:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;

	// THE one-call difficulty setter
	UFUNCTION(BlueprintCallable, Category = "Difficulty")
	void SetDifficulty(EGameDifficulty NewDifficulty);

	// P1-3: per-soldier application of the CURRENT difficulty — the spawn/registration
	// hook (fresh spawns, wave members, pooled re-acquires, post-travel soldiers).
	UFUNCTION(BlueprintCallable, Category = "Difficulty")
	void ApplyToSoldier(ASoldierCharacter* Soldier);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Difficulty")
	EGameDifficulty GetCurrentDifficulty() const { return CurrentDifficulty; }

	// Static accessor
	static UDifficultySubsystem* Get(const UObject* WorldContext);

private:
	EGameDifficulty CurrentDifficulty = EGameDifficulty::Normal;

	float GetAllyPower(EGameDifficulty Diff) const;
	float GetEnemyDamage(EGameDifficulty Diff) const;
	float GetEnemyAccuracy(EGameDifficulty Diff) const;
};

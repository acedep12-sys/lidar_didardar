#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "SquadAIAssetCacheSubsystem.generated.h"

class UStaticMesh;
class UMaterialInterface;
class USoundBase;

/**
 * USquadAIAssetCacheSubsystem
 * High-Performance Centralized Asset Registry & Flyweight Cache Subsystem.
 * 
 * Solves duplicate memory allocation and synchronous LoadObject overhead by:
 * 1. Pre-caching and holding single canonical instances of common engine shapes and meshes in memory.
 * 2. Caching materials, shared dynamic material instances, and audio cues.
 * 3. Providing zero-overhead O(1) pointer access for procedural generation and AI systems.
 */
UCLASS(BlueprintType)
class SQUADAI_API USquadAIAssetCacheSubsystem : public UWorldSubsystem
{
	GENERATED_BODY()

public:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Asset Cache", meta = (WorldContext = "WorldContextObject"))
	static USquadAIAssetCacheSubsystem* Get(const UObject* WorldContextObject);

	// =========================================================================
	//  CANONICAL STATIC MESH RETRIEVAL (Single instance in RAM)
	// =========================================================================

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Asset Cache")
	UStaticMesh* GetCubeMesh();

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Asset Cache")
	UStaticMesh* GetCylinderMesh();

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Asset Cache")
	UStaticMesh* GetSphereMesh();

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Asset Cache")
	UStaticMesh* GetPlaneMesh();

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Asset Cache")
	UStaticMesh* GetOrLoadMesh(const FString& Path);

	// =========================================================================
	//  CANONICAL MATERIAL RETRIEVAL
	// =========================================================================

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Asset Cache")
	UMaterialInterface* GetDefaultBasicMaterial();

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Asset Cache")
	UMaterialInterface* GetOrLoadMaterial(const FString& Path);

	// =========================================================================
	//  DYNAMIC MATERIAL INSTANCE (MID) RECYCLING / FLYWEIGHT
	// =========================================================================

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Asset Cache")
	UMaterialInterface* GetSharedDynamicMaterial(UMaterialInterface* BaseMaterial, FName ParameterName, FLinearColor Value);

	// =========================================================================
	//  S26-MAT: textured prop materials
	// =========================================================================
	/** A dynamic material on the shared M_SquadAIProp parent (TextureSample 'Tex' x
	 *  VectorParameter 'Tint' -> BaseColor): the texture is looked up as
	 *  /Game/Textures/SquadAI/<Key>.<Key> first (if you imported it) and as
	 *  Content/Textures/SquadAI/<Key>.png second (just copy the folder - no import
	 *  needed). The base material is created and SAVED to /Game/Materials once,
	 *  automatically, the first time anything asks for a prop material. Returns
	 *  nullptr when neither exists - callers fall back to their tint material. */
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Asset Cache")
	// S26-TEX3: UVScale tiles the base texture across big surfaces (a bridge
	// deck stretched one sample across 4.6 m before this). Default 1 = old look.
	UMaterialInterface* GetPropMaterial(const FString& TextureKey, FLinearColor Tint, float UVScale = 1.f);

	/** Clear all cached dynamic assets and release unused RAM */
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Asset Cache")
	void FlushDynamicCache();

	// S27-COMPILEFIX: the material factories are PUBLIC - QuestNativeHUD asks
	// the cache for the minimap material directly (EnsureMinimapMaterial at the
	// rotating-map draw path), and a private declaration compiled to
	// C2248 on the first real build.
	/** Find-or-author the shared M_SquadAIProp base material (Tex x Tint chain). */
	class UMaterial* EnsurePropBaseMaterial();

	/** S26-MMAT: author/find the default minimap material (unlit, translucent,
	 * circular mask, texture param "MinimapTexture"). Guarantees the rotating
	 * minimap draw path works even when no material is tuned. */
	class UMaterial* EnsureMinimapMaterial();

	/** S27-BLUR: author/find the 5-tap Gaussian frosted-glass HUD blur material
	 * (unlit, translucent, texture param "BlurTexture", vector param "BlurTint",
	 * scalar param "BlurOpacity"). Ignores SceneCapture's alpha channel. */
	class UMaterial* EnsureHUDFrostedBlurMaterial();

private:
	UPROPERTY()
	TObjectPtr<UStaticMesh> CachedCubeMesh;

	UPROPERTY()
	TObjectPtr<UStaticMesh> CachedCylinderMesh;

	UPROPERTY()
	TObjectPtr<UStaticMesh> CachedSphereMesh;

	UPROPERTY()
	TObjectPtr<UStaticMesh> CachedPlaneMesh;

	UPROPERTY()
	TObjectPtr<UMaterialInterface> CachedDefaultMaterial;

	UPROPERTY()
	TMap<FString, TObjectPtr<UStaticMesh>> LoadedMeshCache;

	UPROPERTY()
	TMap<FString, TObjectPtr<UMaterialInterface>> LoadedMaterialCache;

	// S26-MAT: one MID per (texture, tint); the parent material, found or authored
	UPROPERTY()
	TObjectPtr<UMaterialInterface> CachedPropBaseMaterial;
	UPROPERTY()
	TObjectPtr<UMaterialInterface> CachedMinimapMaterial;   // S26-MMAT
	UPROPERTY()
	TObjectPtr<UMaterialInterface> CachedHUDBlurMaterial;   // S27-BLUR
	UPROPERTY()
	TMap<FString, TObjectPtr<UMaterialInterface>> CachedPropMaterials;

	void PrewarmCanonicalAssets();
};

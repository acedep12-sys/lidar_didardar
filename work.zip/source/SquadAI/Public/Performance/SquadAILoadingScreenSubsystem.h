#pragma once

#include "CoreMinimal.h"
#include "Containers/Ticker.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "TimerManager.h"
#include "Engine/World.h"
#include "Performance/SquadAILoadingHandoffModel.h" // S19-INSTANT: the paint-before-travel rule
#include "SquadAILoadingScreenSubsystem.generated.h"

class UUserWidget;
class UTexture2D;
class UMaterialInterface;
class USoundBase;

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnLoadingScreenShown);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnLoadingScreenHidden);

/**
 * USquadAILoadingScreenSubsystem
 * Seamless level transition director with animated tactical loading screen,
 * mission briefing teasers, rotating combat tips, custom artwork/videos,
 * and optional 'Hold / Press Any Key to Deploy' gating.
 */
UCLASS(BlueprintType)
class SQUADAI_API USquadAILoadingScreenSubsystem : public UGameInstanceSubsystem
{
	GENERATED_BODY()

public:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Loading", meta = (WorldContext = "WorldContextObject"))
	static USquadAILoadingScreenSubsystem* Get(const UObject* WorldContextObject);

	// =========================================================================
	//  CONFIG
	// =========================================================================

	/** If true, requires player input (Enter / Space / Left Click) before dismissing loading screen */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loading Screen Config")
	bool bRequirePlayerInputToDeploy = true;

	/** Default background artwork / concept art texture */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loading Screen Visuals")
	TObjectPtr<UTexture2D> DefaultBackgroundArtwork;

	/** Default video texture or animated material */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loading Screen Visuals")
	TObjectPtr<UMaterialInterface> DefaultBackgroundMaterial;

	/** Sound played when player confirms deployment */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loading Screen Audio")
	TObjectPtr<USoundBase> DeployConfirmationSound;

	/** S19-INSTANT: optional custom (UMG) loading screen. The screen the player
	 *  actually sees during a transition is drawn by the canvas HUDs - the menu
	 *  HUD in the source world, the gameplay HUD's deployment veil in the
	 *  destination - so this is only for a designer who wants their own widget
	 *  layered on top. Set it to a Blueprint whose tree draws something; a class
	 *  with no widget tree is refused at spawn (it would be an invisible
	 *  full-screen overlay, which is what this round removed). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loading Screen Config")
	TSubclassOf<UUserWidget> LoadingScreenWidgetClass;

	// =========================================================================
	//  API
	// =========================================================================

	/**
	 * Initiates a level transition with a full-screen tactical loading screen.
	 */
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Loading")
	void LoadLevelWithScreen(
		FName LevelName,
		FText SectorTitle = FText(),
		FText MissionBriefing = FText(),
		TSubclassOf<UUserWidget> CustomLoadingWidgetClass = nullptr);

	/**
	 * High-level transition trigger using Map/Sector identifier.
	 */
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Loading")
	void StartDeploymentTransition(FName LevelName, FName MapOrSectorID = NAME_None);

	/**
	 * Hides and destroys the active loading screen (called when gameplay starts).
	 */
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Loading")
	void HideLoadingScreen(float FadeDuration = 1.0f);

	/** Marks loading complete, triggering the deploy prompt or auto-dismiss */
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Loading")
	void MarkLoadingComplete();

	/** Returns a random tactical combat tip */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Loading")
	FText GetRandomTacticalTip() const;

	/** S19-INSTANT: true from the moment a transition is requested until the
	 *  blocking travel fires. Whichever HUD is on screen draws the departure
	 *  screen while this is true. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Loading")
	bool IsDeparturePending() const;

	/** S19-INSTANT: the source world drew the departure screen this frame. The
	 *  travel cannot start until this has been reported MinPaintedFrames times
	 *  (see SquadAILoadingHandoffModel.h), so the player is always waiting in the
	 *  screen - never on the menu it replaced. */
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Loading")
	void NotifyDepartureScreenPainted();

	/**
	 * S19-INSTANT: advance the handoff clock by one drawn frame's delta.
	 *
	 * The live HUD calls this every frame it draws the departure screen. Without it the
	 * only clock was the 0.25 s travel ticker, so the progress bar advanced in 10.5%
	 * steps four times a second. S19-DEEPREVIEW: the HUD calls this once per drawn departure
 * frame, so the bar moves every frame instead of in 0.25 s jumps. The ticker still
 * supplies time when nobody else does
	 * (a BP HUD, a headless run, a paused game), which is what keeps the hard timeout
	 * reachable - see FireDeferredTravel.
	 */
	void TickTransition(float DeltaSeconds);

	/** S19-INSTANT: simulated bar fill of the transition, carried across the
	 *  travel so the destination's veil continues it instead of restarting. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Loading")
	float GetTransitionProgress() const;

	UPROPERTY(BlueprintAssignable, Category = "SquadAI|Loading")
	FOnLoadingScreenShown OnLoadingScreenShown;

	UPROPERTY(BlueprintAssignable, Category = "SquadAI|Loading")
	FOnLoadingScreenHidden OnLoadingScreenHidden;

	UPROPERTY(BlueprintReadOnly, Category = "SquadAI|Loading")
	FText CurrentSectorTitle;

	UPROPERTY(BlueprintReadOnly, Category = "SquadAI|Loading")
	FText CurrentMissionBriefing;

	UPROPERTY(BlueprintReadOnly, Category = "SquadAI|Loading")
	FText CurrentCombatTip;

	UPROPERTY(BlueprintReadOnly, Category = "SquadAI|Loading")
	bool bIsLoading = false;

private:
	UPROPERTY()
	TObjectPtr<UUserWidget> ActiveLoadingWidget;

	// P1-6: travel-surviving layer + destination handshake state.
	FDelegateHandle PostLoadMapHandle;
	TSubclassOf<UUserWidget> PendingWidgetClass;
	TWeakObjectPtr<UWorld> HandshakeWorld;
	FTimerHandle DestinationHandshakeHandle;
	float HandshakeElapsed = 0.f;
	// P7: deferred travel (paint the screen before the blocking OpenLevel) + readiness settle.
	FTSTicker::FDelegateHandle DeferredTravelHandle;   // S9-FIX: FTSTicker has its own handle type
	FName PendingTravelLevel;
	float HandshakeSettleElapsed = 0.f;
	bool FireDeferredTravel(float DeltaTime);

	// S19-INSTANT: the paint-before-travel rule (painted frames, defer window and
	// the hard timeout that keeps a HUD-less source world from stalling).
	FSquadAILoadingHandoff Handoff;

	/** The handoff clock as the ticker last saw it: equal means nobody drove it.
	 *  0, not -1: BeginDeparture resets the clock to 0, so on the first callback the
	 *  test 'nobody advanced it' is true exactly when no HUD drew a frame - which is
	 *  when the ticker must supply the time (a HUD-less world still gets the full
	 *  1.5 s timeout instead of 1.75 s). */
	float LastHandoffSeconds = 0.f;

	TArray<FText> TacticalCombatTips;

	void PopulateCombatTips();
	void SpawnLoadingWidget(UWorld* World);
	void HandlePostLoadMap(UWorld* LoadedWorld, UWorld::InitializationValues InitValues);
	void PollDestinationReady();
};

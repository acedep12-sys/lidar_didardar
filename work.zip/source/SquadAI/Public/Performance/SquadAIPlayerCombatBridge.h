// SquadAIPlayerCombatBridge.h — Custom damage system for player
// Traces from player camera, detects enemy hits, applies damage directly.
// Works with BOTH SquadAI ASoldierCharacter AND TPWCS pack enemies.
// Bypasses TPWCS pack damage entirely. Auto-attached to player by diagnostic subsystem.
#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "SquadAIPlayerCombatBridge.generated.h"

class ASoldierCharacter;
class FBoolProperty;

UCLASS(ClassGroup = (SquadAI), meta = (BlueprintSpawnableComponent))
class SQUADAI_API USquadAIPlayerCombatBridge : public UActorComponent
{
	GENERATED_BODY()

public:
	USquadAIPlayerCombatBridge();

	// How often to check if player is firing (seconds)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat")
	float TraceInterval = 0.1f;

	// Max distance for the camera trace.
	// S14-RANGE: was 15000 (150 m). The distant wave spawns stand ~300 m out,
	// so every shot past 150 m silently hit nothing - "my bullets won't damage
	// them". 40000 (400 m) covers realistic rifle engagement on the open map.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat")
	float MaxTraceDistance = 40000.f;

	// Damage per hit for SquadAI enemies
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat")
	float DamagePerHit = 25.f;

	// Damage per hit for pack enemies (uses reflection on BPC_HealthAI)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat")
	float PackDamagePerHit = 25.f;

	// Physical impulse applied to hit ragdoll bone on kill (Lyra/Battlefield style)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat|Physics")
	float DeathImpulseForce = 500.f;

	// Draw debug line for traces
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat|Debug")
	bool bDrawDebugTrace = false;

	// Log every hit
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat|Debug")
	bool bLogHits = false;

protected:
	virtual void BeginPlay() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

private:
	// S19-PACKHP: periodic audit of the player's TPWCS pack health (see
	// SquadAIRecovery::ClampPackHealthToMax). Bullets clamp on the damage path;
	// this catches an inflation that happens on any other pack code path.
	float PackHealthAuditAccum = 0.f;
	float TraceTimer = 0.f;
	bool bWasFiring = false;
	mutable bool bWeaponCompCached = false;
	mutable bool bShootingPropResolved = false;
	mutable TWeakObjectPtr<UActorComponent> CachedWeaponComp;
	mutable FBoolProperty* CachedIsShootingProp = nullptr;

	// B7-7 infinite-ammo top-up cache (resolved once, same pattern as above).
	mutable bool bAmmoPropsResolved = false;
	mutable FIntProperty* CachedCurrentAmmoProp = nullptr;
	mutable FIntProperty* CachedReserveAmmoProp = nullptr;

	void TopUpPackAmmoForInfiniteCheat();

	void PerformCombatTrace();
	bool IsPlayerFiring() const;

	bool bGKeyDownPrev = false;
	bool bHKeyDownPrev = false;
	bool bMedKeyDownPrev = false;
	// S14-INPUT: UI keys are edge-detected from IsInputKeyDown again (rising
	// edge), NOT WasInputKeyJustPressed. Event counts behind WasInputKeyJust-
	// Pressed are only rebuilt when the PlayerController processes input; on
	// the first PAUSED frame this component can tick BEFORE the controller
	// (the tick-prerequisite chain through the pawn is broken while paused,
	// because the pawn itself does not tick when paused), so the previous
	// frame's Pressed event was still visible and one keypress toggled the
	// menu open and instantly back closed. A level-based rising edge can
	// never double-fire off stale state - at worst it lands one frame late.
	bool bUIPauseKeyDownPrev = false;
	bool bUIInvKeyDownPrev = false;
	// S14-INPUT: belt-and-braces - never accept two UI toggles within 0.2 s.
	// Real time, because the game is paused while these menus are open.
	double LastUIToggleRealTime = -1.0;
	float AmmoTopUpAccum = 0.f;

	// Damage helpers for different enemy types
	bool DamageSoldierCharacter(ASoldierCharacter* Target, const FVector& TraceDir, FName HitBoneName);
	bool DamagePackEnemy(AActor* Enemy, const FVector& TraceDir, FName HitBoneName);
	bool ApplyDamageViaReflection(AActor* Enemy, float Damage, const FVector& TraceDir, FName HitBoneName);
};

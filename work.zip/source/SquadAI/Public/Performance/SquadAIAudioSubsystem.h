#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "SquadAIAudioSubsystem.generated.h"

class USoundBase;
class UAudioComponent;
class USoundAttenuation;
class UCameraShakeBase;
class AMissionZone;
class AQuestChain;
class ASquadAIAudioManager;

UENUM(BlueprintType)
enum class EAudioGameState : uint8
{
	Exploration,        // Quiet exploration / desert ambient
	MissionActive,      // Approaching or entering a mission area
	Combat,             // Standard combat (1-5 enemies)
	CombatHorde,        // Large horde attack (6+ enemies attacking)
	DefendEarlyStage,   // First half of defend quest (Music X)
	DefendClimax,       // Final countdown / intense climax of defend quest (Music Y)
	Victory,            // Mission completed stinger
	Defeat              // Mission failed stinger
};

UENUM(BlueprintType)
enum class ETacticalVoicelineType : uint8
{
	Radio_MissionStart,
	Radio_MissionSuccess,
	Radio_MissionFail,
	Leader_OrderMove,
	Leader_OrderEngage,
	Ally_EnemySpotted,
	Ally_UnderFire,
	Ally_Reloading,
	Ally_IncomingGrenade,
	Ally_ManDown,
	Ally_KillConfirmed,
	Ally_Flanking,
	Ally_Victory,
	Enemy_Alerted,
	Enemy_CombatBark,
	// Appended at the end on purpose: never insert above, it would renumber Blueprint-serialized values.
	Command_Hold,
	Ally_Healing
};

/**
 * USquadAIAudioSubsystem
 * Global, ultra-efficient Audio, Dynamic Music & Tactical Voiceover Director for Open World FPS.
 * Tailored for Khuzestan Tactical War Theater (Southern Iran desert/trenches/berms).
 * 
 * Performance & Realism Features:
 * 1. Zero-Asset Fallbacks: Procedural 6-DOF camera shake & logarithmic 3D attenuation built-in.
 * 2. Tactical Squad Voiceovers & Radio: Spatial squad shouts + 2D HQ radio comms with smart anti-spam priority.
 * 3. Khuzestan Battlefield Ambience: Desert wind, periodic distant artillery rumble, low-health heartbeat.
 * 4. Dynamic Horde Scaling: Heavy war drums stem layer scales with active enemy count.
 * 5. Multi-Stage Mission Music: Transitions between Music X (early defense) and Music Y (final countdown climax).
 * 6. Speed-of-Sound Simulation (343 m/s) and Hardware Voice Budgeting.
 */
UCLASS(BlueprintType)
class SQUADAI_API USquadAIAudioSubsystem : public UWorldSubsystem
{
	GENERATED_BODY()

public:
	USquadAIAudioSubsystem();

	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;
	virtual void Tick(float DeltaTime);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Audio", meta = (WorldContext = "WorldContextObject"))
	static USquadAIAudioSubsystem* Get(const UObject* WorldContextObject);

	void RegisterAudioManager(ASquadAIAudioManager* InManager);

	// =========================================================================
	//  DYNAMIC MUSIC & HORDE INTENSITY
	// =========================================================================

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Audio")
	void SetAudioGameState(EAudioGameState NewState, USoundBase* CustomMusicOverride = nullptr, float FadeDuration = 2.5f);

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Audio")
	void CrossfadeMusic(USoundBase* NewMusic, float FadeDuration = 2.5f, float TargetVolume = 1.0f);

	// B6-9: settings volumes (pushed by ApplySettingsToEngine; default = full).
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Audio")
	void ApplyVolumeSettings(float Master, float Music, float SFX, float Voice);

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Audio")
	void PlayStinger(USoundBase* StingerSound, float DuckMusicMultiplier = 0.35f, float DuckDuration = 3.0f);

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Audio")
	void StopMusic(float FadeOutDuration = 2.0f);

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Audio")
	void NotifyMissionStateChanged(AMissionZone* Mission, uint8 NewState);

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Audio")
	void NotifyMissionProgress(AMissionZone* Mission, float Progress, float TimeRemaining, int32 AliveEnemyCount);

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Audio")
	void SetHordeIntensity(float InIntensity, int32 NearbyEnemyCount = 0);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Audio")
	float GetCurrentCombatIntensity() const { return CurrentCombatIntensity; }


	// =========================================================================
	//  TACTICAL SQUAD VOICEOVERS & RADIO COMMS
	// =========================================================================

	/**
	 * Plays a prioritized tactical voiceline (e.g. Enemy spotted, Under fire, Incoming mortar, HQ radio).
	 * Spatialized at SpeakerActor's location for squad members, or played 2D with radio filter for HQ.
	 */
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Audio")
	void PlayTacticalVoiceline(ETacticalVoicelineType VoicelineType, AActor* SpeakerActor = nullptr);


	// =========================================================================
	//  3D SPATIAL DISTANCE AUDIO & SPEED-OF-SOUND ENGINE
	// =========================================================================

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Audio")
	void PlaySpatialSoundWithDistanceLayers(
		USoundBase* CloseSound,
		USoundBase* DistantSound,
		FVector WorldLocation,
		float CloseRadius = 2500.f,
		float DistantRadius = 40000.f,
		bool bSimulateSpeedOfSound = true,
		float VolumeMultiplier = 1.0f,
		USoundAttenuation* AttenuationSettings = nullptr);

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Audio")
	void TriggerExplosionConcussion(
		FVector ExplosionLocation,
		float InnerRadius = 700.f,
		float OuterRadius = 2200.f,
		TSubclassOf<UCameraShakeBase> CameraShakeClass = nullptr);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Audio")
	ASquadAIAudioManager* GetActiveAudioManager() const { return ActiveAudioManager.Get(); }

protected:
	UPROPERTY()
	TObjectPtr<UAudioComponent> PrimaryMusicComp;

	UPROPERTY()
	TObjectPtr<UAudioComponent> FadingMusicComp;

	UPROPERTY()
	TObjectPtr<UAudioComponent> StingerComp;

	UPROPERTY()
	TObjectPtr<UAudioComponent> HordeStemComp;

	UPROPERTY()
	TObjectPtr<UAudioComponent> DesertWindAudioComp;

	UPROPERTY()
	TObjectPtr<UAudioComponent> HeartbeatAudioComp;

	UPROPERTY()
	TObjectPtr<UAudioComponent> ActiveVoicelineComp;

	UPROPERTY()
	TWeakObjectPtr<ASquadAIAudioManager> ActiveAudioManager;

	UPROPERTY()
	TWeakObjectPtr<AMissionZone> CurrentActiveMission;

	UPROPERTY()
	EAudioGameState CurrentState = EAudioGameState::Exploration;

private:
	FTimerHandle DuckTimerHandle;
	FTimerHandle MusicTickTimerHandle;
	FTimerHandle DistantArtilleryTimerHandle;

	float TargetMusicVolume = 1.0f;
	float DuckMultiplier = 1.0f;

	// B6-9: user settings mix (see ApplyVolumeSettings).
	float SettingsMasterVolume = 1.0f;
	float SettingsMusicVolume = 0.8f;
	float SettingsSFXVolume = 1.0f;
	float SettingsVoiceVolume = 1.0f;
	float CrossfadeRemaining = 0.f;
	// P1-A3: old-track absolute volume captured at crossfade start (VolOut baseline).
	float CrossfadeStartVolume = 0.f;
	float CrossfadeTotalDuration = 2.5f;
	bool bIsCrossfading = false;

	// Dynamic Horde & Stem Layering
	float CurrentCombatIntensity = 0.0f;
	float TargetCombatIntensity = 0.0f;
	float CombatCooldownTimer = 0.0f;
	float HordeStemVolume = 0.0f;

	// Voiceline Anti-Spam & Priorities
	float LastContactVoicelineTime = -100.f;
	float LastUnderFireVoicelineTime = -100.f;
	float LastReloadVoicelineTime = -100.f;
	float LastMortarWarningVoicelineTime = -100.f;
	float LastManDownVoicelineTime = -100.f;
	float LastKillConfirmedVoicelineTime = -100.f;
	float LastHealingVoicelineTime = -100.f;
	float LastFlankingVoicelineTime = -100.f;
	float LastOrderVoicelineTime = -100.f;
	float LastEnemyBarkVoicelineTime = -100.f;

	// Hardware Voice Budgeting & Rate Limiting
	int32 GunshotVoiceCounter = 0;
	int32 ExplosionVoiceCounter = 0;
	float VoiceBudgetResetTimer = 0.f;

	// Playlist rotation indexes
	int32 CurrentAmbientPlaylistIndex = 0;
	int32 CurrentCombatPlaylistIndex = 0;

	void UpdateCrossfade(float DeltaTime);
	void UpdateHordeStemMixing(float DeltaTime);
	void EvaluateThreatsAndCooldown(float DeltaTime);
	void UpdateKhuzestanBattlefieldAmbience(float DeltaTime);
	void TriggerDistantHorizonArtillery();
	void ResetDuckVolume();
	USoundBase* ResolveDefaultTrackForState(EAudioGameState State) const;
	USoundBase* GetNextPlaylistTrack(const TArray<TObjectPtr<USoundBase>>& Playlist, int32& InOutIndex) const;
	USoundBase* PickRandomSoundFromArray(const TArray<TObjectPtr<USoundBase>>& SoundArray) const;
};

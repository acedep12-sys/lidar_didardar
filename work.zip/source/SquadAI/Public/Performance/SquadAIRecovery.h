// ==== S19-RECOVERY ====
// SquadAIRecovery.h — shared helpers for bringing a pawn back from death.
//
// WHY THIS EXISTS (S19-DEATHPOSE / S19-PACKALIVE / S19-PACKHP)
// -----------------------------------------------------------
// The project's pawns are a mix of native ASoldierCharacter and the TPWCS pack's
// Blueprint characters (BP_PlayerCharacter_C, BP_Enemy_*, BP_Ally_*, BP_Leader_*).
// The pack owns its own death presentation: BPC_Health* sets `bIsDead?`, plays a
// death montage or hands the mesh to BPC_RagdollMaster, and HI_GetDespawnOnDeath
// may hide it. Nothing in the pack knows that *we* teleported the pawn back to a
// spawn point, so after a mission restart the pawn came back as a body frozen in
// its death pose with the AnimBP no longer driving it:
//
//   * `SetSimulatePhysics(false)` alone does NOT hand the pose back to the
//     AnimBP - the component keeps the last physics (ragdoll) pose until the
//     blend weight is reset. That is the "death pose, no animations" report.
//   * Clearing `bIsDead?` from the outside does not run the pack's own
//     SetDeadStatus(false) / HI_ReinitializeHealth(), so its HUD, stimuli
//     source and AnimBP state stay latched on "dead".
//   * A pack health component can also report MORE health than its own
//     maxHealth (observed live: currentHealth=1998.338 vs maxHealth=100 on
//     BPC_HealthPlayer). Enemy bullets were then real but invisible - the bar
//     stayed pinned at 100% and the player was effectively 20x tougher. That is
//     the "the first enemy shot doesn't damage me" report.
//
// Everything here is reflection-based and null-safe: it works on native pawns,
// on pack pawns, and on pawns without any of the pack's components.
//
// Header-only on purpose (same rule as SquadAIGripRetarget.h): no new module
// dependency, no UCLASS, no UPROPERTY.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "GameFramework/Character.h"
#include "Components/ActorComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Animation/AnimInstance.h"
#include "Engine/EngineTypes.h"
#include "UObject/UnrealType.h"
#include "Characters/SoldierCharacter.h"   // ASoldierCharacter::IsAlive() (native death test)
#include "GameFramework/Pawn.h"
#include "GameFramework/Controller.h"
#include "Components/StateTreeComponent.h"   // S19-ENEMYST: the component we have to restart

namespace SquadAIRecovery
{
	// =========================================================================
	// S19-ENEMYST - "the enemies are alive but brain-dead"
	// =========================================================================
	// Live log: every wave spawn produced
	//
	//   LogStateTree: Error: UStateTreeComponentSchema::SetContextData: Could not find
	//   context actor of type Pawn. StateTree will not update.
	//   ... Missing external data requirements ...
	//   LogStateTree: Warning: Context Requirements in UStateTreeComponent::StartTree
	//   failed. Component tick is disabled.
	//
	// 15 of 15 enemies, twice (once per mission start), exactly when the wave spawner
	// activates and the pool prewarms. The state tree that fails is NOT the controller's:
	// GhostCensus reports `stRunning=1` for those same enemies, i.e. the AI controller's
	// own tree (the S18 rescue in OnPossess) is fine. What fails is another state tree
	// component - the pack puts one on the enemy pawn/controller Blueprint - and it
	// auto-starts while the pawn is being spawned at (0,0,-10000) by the pool, before it
	// is possessed. `Component tick is disabled` is permanent: nothing in the engine ever
	// retries a failed StartTree.
	//
	// These two helpers do the retry, for ANY UStateTreeComponent (including the AI
	// variant and any pack subclass) on the actor, and on its controller. Same rule as the
	// rest of this header: null-safe, no assumptions about who authored the component.

	/** Start every dormant UStateTreeComponent on one actor. Returns how many now run. */
	inline int32 EnsureStateTreesRunning(AActor* Owner, const TCHAR* Why)
	{
		if (!Owner) return 0;

		TArray<UStateTreeComponent*> Trees;
		Owner->GetComponents<UStateTreeComponent>(Trees);

		int32 Started = 0;
		int32 StillDormant = 0;
		for (UStateTreeComponent* Tree : Trees)
		{
			if (!Tree || Tree->IsRunning()) continue;

			// StartLogic() re-runs SetContextData/SetContextRequirements; by the time we
			// call it the possession (and therefore the Pawn context) usually exists.
			Tree->StartLogic();

			if (Tree->IsRunning())
			{
				++Started;
				UE_LOG(LogTemp, Warning, TEXT("[S19-ENEMYST] %s: started dormant state tree '%s' on %s (%s)"),
					Why ? Why : TEXT("rescue"), *Tree->GetName(), *GetNameSafe(Owner),
					Cast<APawn>(Owner) ? TEXT("pawn") : TEXT("controller"));
			}
			else
			{
				++StillDormant;
			}
		}

		if (StillDormant > 0)
		{
			// Not an error yet: a retry is scheduled by the caller (possession may still be
			// in flight). Logged so the reason a later retry succeeds is visible.
			UE_LOG(LogTemp, Verbose, TEXT("[S19-ENEMYST] %s: %s still has %d dormant state tree component(s) - context not ready"),
				Why ? Why : TEXT("rescue"), *GetNameSafe(Owner), StillDormant);
		}
		return Started;
	}

	/** The pawn's own state trees AND its controller's. Returns how many now run. */
	inline int32 EnsurePawnStateTreesRunning(APawn* Pawn, const TCHAR* Why)
	{
		if (!Pawn) return 0;
		int32 Started = EnsureStateTreesRunning(Pawn, Why);
		Started += EnsureStateTreesRunning(Pawn->GetController(), Why);
		return Started;
	}

	// ------------------------------------------------------------------
	//  Reflected property access (double / float / int / bool)
	// ------------------------------------------------------------------

	/** First property of any numeric type among Names, or nullptr. */
	inline FProperty* FindNumericProp(UObject* Obj, std::initializer_list<const TCHAR*> Names)
	{
		if (!Obj || !Obj->GetClass()) return nullptr;
		for (const TCHAR* N : Names)
		{
			if (!N) continue;
			if (FProperty* P = FindFProperty<FProperty>(Obj->GetClass(), FName(N)))
			{
				if (P->IsA<FDoubleProperty>() || P->IsA<FFloatProperty>() || P->IsA<FIntProperty>())
				{
					return P;
				}
			}
		}
		return nullptr;
	}

	inline bool ReadNumericProp(FProperty* P, UObject* Container, double& OutValue)
	{
		if (!P || !Container) return false;
		if (const FDoubleProperty* DP = CastField<FDoubleProperty>(P))
		{
			OutValue = DP->GetPropertyValue_InContainer(Container);
			return true;
		}
		if (const FFloatProperty* FP = CastField<FFloatProperty>(P))
		{
			OutValue = static_cast<double>(FP->GetPropertyValue_InContainer(Container));
			return true;
		}
		if (const FIntProperty* IP = CastField<FIntProperty>(P))
		{
			OutValue = static_cast<double>(IP->GetPropertyValue_InContainer(Container));
			return true;
		}
		return false;
	}

	inline bool WriteNumericProp(FProperty* P, UObject* Container, double Value)
	{
		if (!P || !Container) return false;
		// Non-const accessors: FProperty itself is const in the container, the
		// property object is not.
		if (FDoubleProperty* DP = CastField<FDoubleProperty>(P))
		{
			DP->SetPropertyValue_InContainer(Container, Value);
			return true;
		}
		if (FFloatProperty* FP = CastField<FFloatProperty>(P))
		{
			FP->SetPropertyValue_InContainer(Container, static_cast<float>(Value));
			return true;
		}
		if (FIntProperty* IP = CastField<FIntProperty>(P))
		{
			IP->SetPropertyValue_InContainer(Container, FMath::RoundToInt(Value));
			return true;
		}
		return false;
	}

	inline bool ReadBoolProp(UObject* Obj, std::initializer_list<const TCHAR*> Names, bool& OutValue)
	{
		if (!Obj || !Obj->GetClass()) return false;
		for (const TCHAR* N : Names)
		{
			if (!N) continue;
			if (const FBoolProperty* BP = FindFProperty<FBoolProperty>(Obj->GetClass(), FName(N)))
			{
				OutValue = BP->GetPropertyValue_InContainer(Obj);
				return true;
			}
		}
		return false;
	}

	inline bool WriteBoolProp(UObject* Obj, std::initializer_list<const TCHAR*> Names, bool Value)
	{
		if (!Obj || !Obj->GetClass()) return false;
		bool bAny = false;
		for (const TCHAR* N : Names)
		{
			if (!N) continue;
			if (FBoolProperty* BP = FindFProperty<FBoolProperty>(Obj->GetClass(), FName(N)))
			{
				BP->SetPropertyValue_InContainer(Obj, Value);
				bAny = true;
			}
		}
		return bAny;
	}

	/** TPWCS spells the death flag "bIsDead?" - with a literal question mark. */
	inline bool IsDeadFlagged(UObject* Obj)
	{
		bool bValue = false;
		if (!ReadBoolProp(Obj, { TEXT("bIsDead?"), TEXT("bIsDead"), TEXT("bDead?"), TEXT("bDead"),
			TEXT("IsDead"), TEXT("isDead?"), TEXT("isDead") }, bValue))
		{
			return false;
		}
		return bValue;
	}

	inline int32 ClearDeathFlags(UObject* Obj)
	{
		if (!Obj || !Obj->GetClass()) return 0;
		int32 Cleared = 0;
		for (const TCHAR* N : { TEXT("bIsDead?"), TEXT("bIsDead"), TEXT("bDead?"), TEXT("bDead"),
			TEXT("IsDead"), TEXT("isDead?"), TEXT("isDead") })
		{
			if (FBoolProperty* BP = FindFProperty<FBoolProperty>(Obj->GetClass(), FName(N)))
			{
				if (BP->GetPropertyValue_InContainer(Obj))
				{
					++Cleared;
				}
				BP->SetPropertyValue_InContainer(Obj, false);
			}
		}
		return Cleared;
	}

	// ------------------------------------------------------------------
	//  "Is this thing dead?" - native pawns AND pack pawns
	// ------------------------------------------------------------------

	/** True when a health-ish component exists and reports zero. */
	inline bool HasZeroHealthComponent(AActor* Actor)
	{
		if (!Actor) return false;
		TArray<UActorComponent*> Comps;
		Actor->GetComponents(Comps);
		for (UActorComponent* C : Comps)
		{
			if (!C || !C->GetClass()) continue;
			const FString ClassName = C->GetClass()->GetName();
			if (!ClassName.Contains(TEXT("Health"))) continue;
			if (IsDeadFlagged(C)) return true;
			FProperty* P = FindNumericProp(C, { TEXT("currentHealth"), TEXT("CurrentHealth"),
				TEXT("Current Health"), TEXT("Health"), TEXT("HP"), TEXT("currentHP"), TEXT("CurrentHP") });
			double Cur = 0.0;
			if (P && ReadNumericProp(P, C, Cur) && Cur <= 0.0)
			{
				return true;
			}
		}
		return false;
	}

	/**
	 * S19-CORPSE: the AI's threat memory and the leader's "close threat?" gate
	 * used to treat a CORPSE as a live enemy. Native soldiers were filtered by
	 * ASoldierCharacter::IsAlive(), but the pack's enemies are not
	 * ASoldierCharacter, so a dead one stayed a valid, permanently-visible
	 * memory entry - the leader would then stop on the mission path next to a
	 * body and cover-dance around it forever.
	 */
	// S19-CORPSE
	inline bool IsActorDead(AActor* Actor)
	{
		if (!Actor) return true;
		if (Actor->IsActorBeingDestroyed()) return true;
		if (const ASoldierCharacter* Soldier = Cast<ASoldierCharacter>(Actor))
		{
			return !Soldier->IsAlive();
		}
		if (IsDeadFlagged(Actor)) return true;
		return HasZeroHealthComponent(Actor);
	}

	// ------------------------------------------------------------------
	//  Pack health sanity (S19-PACKHP)
	// ------------------------------------------------------------------

	/** Reads the first health component's current/max. Returns false if none. */
	// S19-PACKHP
	inline bool GetPackHealth(AActor* Actor, double& OutCurrent, double& OutMax)
	{
		if (!Actor) return false;
		TArray<UActorComponent*> Comps;
		Actor->GetComponents(Comps);
		for (UActorComponent* C : Comps)
		{
			if (!C || !C->GetClass()) continue;
			const FString ClassName = C->GetClass()->GetName();
			const FString CompName = C->GetName();
			if (!ClassName.Contains(TEXT("Health")) && !CompName.Contains(TEXT("BPC_Health"))) continue;

			FProperty* MaxP = FindNumericProp(C, { TEXT("maxHealth"), TEXT("MaxHealth"), TEXT("Max Health"), TEXT("MaxHP") });
			FProperty* CurP = FindNumericProp(C, { TEXT("currentHealth"), TEXT("CurrentHealth"),
				TEXT("Current Health"), TEXT("Health") });
			if (!MaxP || !CurP) continue;
			if (!ReadNumericProp(MaxP, C, OutMax) || !ReadNumericProp(CurP, C, OutCurrent)) continue;
			return true;
		}
		return false;
	}

	/**
	 * S19-PACKHP: a pack health component may report more health than its own
	 * maxHealth (seen live: 1998.338 / 100). Every damage event is then real but
	 * invisible - the HUD bar never leaves 100% - and the pawn is effectively
	 * Nx tougher. Clamp it back down to the authored max.
	 *
	 * Returns true when something was clamped. OutWhy (optional) gets a
	 * human-readable description for the log.
	 */
	// S19-PACKHP
	inline bool ClampPackHealthToMax(AActor* Actor, FString* OutWhy = nullptr)
	{
		if (!Actor) return false;
		TArray<UActorComponent*> Comps;
		Actor->GetComponents(Comps);

		bool bChanged = false;
		for (UActorComponent* C : Comps)
		{
			if (!C || !C->GetClass()) continue;
			const FString ClassName = C->GetClass()->GetName();
			const FString CompName = C->GetName();
			if (!ClassName.Contains(TEXT("Health")) && !CompName.Contains(TEXT("BPC_Health"))) continue;

			// Never "fix" a pawn that is already dead: zero health with a live
			// death flag is the pack's own state, not an inflation.
			if (IsDeadFlagged(C)) continue;

			FProperty* MaxP = FindNumericProp(C, { TEXT("maxHealth"), TEXT("MaxHealth"), TEXT("Max Health"), TEXT("MaxHP") });
			FProperty* CurP = FindNumericProp(C, { TEXT("currentHealth"), TEXT("CurrentHealth"),
				TEXT("Current Health"), TEXT("Health") });
			if (!MaxP || !CurP) continue;

			double Max = 0.0, Cur = 0.0;
			if (!ReadNumericProp(MaxP, C, Max) || !ReadNumericProp(CurP, C, Cur)) continue;
			if (Max <= 0.0 || Cur <= Max + 1.e-4) continue;

			if (WriteNumericProp(CurP, C, Max))
			{
				bChanged = true;
				if (OutWhy)
				{
					*OutWhy = FString::Printf(TEXT("%s%s: currentHealth %.3f > maxHealth %.3f -> clamped to max"),
						*GetNameSafe(Actor), *C->GetName(), Cur, Max);
				}
			}
		}
		return bChanged;
	}

	// ------------------------------------------------------------------
	//  Pack function calls (reflection; Blueprint-implemented functions)
	// ------------------------------------------------------------------

	inline bool CallNoArgFunction(UObject* Obj, const TCHAR* FuncName)
	{
		if (!Obj || !FuncName) return false;
		UFunction* F = Obj->FindFunction(FName(FuncName));
		if (!F) return false;
		TArray<uint8> Buf;
		Buf.SetNumZeroed(F->ParmsSize > 0 ? F->ParmsSize : 1);
		Obj->ProcessEvent(F, Buf.GetData());
		return true;
	}

	inline bool CallBoolFunction(UObject* Obj, const TCHAR* FuncName, bool Value)
	{
		if (!Obj || !FuncName) return false;
		UFunction* F = Obj->FindFunction(FName(FuncName));
		if (!F) return false;
		TArray<uint8> Buf;
		Buf.SetNumZeroed(F->ParmsSize > 0 ? F->ParmsSize : 1);
		for (TFieldIterator<FProperty> It(F); It; ++It)
		{
			FProperty* P = *It;
			if (!P || !P->HasAnyPropertyFlags(CPF_Parm)) continue;
			if (FBoolProperty* BP = CastField<FBoolProperty>(P))
			{
				BP->SetPropertyValue_InContainer(Buf.GetData(), Value);
				break;
			}
		}
		Obj->ProcessEvent(F, Buf.GetData());
		return true;
	}

	// ------------------------------------------------------------------
	//  S19-PACKALIVE: tell the pack the pawn is alive again
	// ------------------------------------------------------------------

	/**
	 * Clears every reflected death flag on the actor and its components, then
	 * runs the pack's own "alive again" entry points (all optional; missing ones
	 * are simply skipped):
	 *
	 *   SetDeadStatus(false)     - BPC_Health*: the pack's internal dead state
	 *   HI_ReinitializeHealth()  - refill + broadcast OnHealthInitialized
	 *   EnableStimuliSource()    - perception stimulus (disabled on death)
	 *   HI_ToggleHealthbar(true) - bring the pack's own healthbar back
	 *
	 * Deliberately NOT called: BPC_Health*::RespawnPlayer(). Its parameter
	 * semantics are unknown and the mission layer already positions the pawn.
	 */
	// S19-PACKALIVE
	inline bool RevivePackActor(AActor* Actor, FString* OutWhy = nullptr)
	{
		if (!Actor) return false;

		int32 Cleared = ClearDeathFlags(Actor);
		TArray<UActorComponent*> Comps;
		Actor->GetComponents(Comps);

		bool bCalled = false;
		for (UActorComponent* C : Comps)
		{
			if (!C) continue;
			Cleared += ClearDeathFlags(C);

			if (!C->GetClass()) continue;
			const FString ClassName = C->GetClass()->GetName();
			if (!ClassName.Contains(TEXT("Health"))) continue;

			if (CallBoolFunction(C, TEXT("SetDeadStatus"), false)) bCalled = true;
			if (CallNoArgFunction(C, TEXT("HI_ReinitializeHealth"))) bCalled = true;
			if (CallBoolFunction(C, TEXT("HI_ToggleHealthbar"), true)) bCalled = true;
		}

		if (Actor->FindFunction(TEXT("EnableStimuliSource")))
		{
			bCalled |= CallNoArgFunction(Actor, TEXT("EnableStimuliSource"));
		}

		if (OutWhy)
		{
			*OutWhy = FString::Printf(TEXT("%s: cleared %d death flag(s)%s"),
				*GetNameSafe(Actor), Cleared, bCalled ? TEXT(", pack revive functions called") : TEXT(""));
		}
		return bCalled || Cleared > 0;
	}

	// ------------------------------------------------------------------
	//  S19-DEATHPOSE: hand a mesh back to the AnimBP
	// ------------------------------------------------------------------

	/**
	 * S19-DEATHPOSE: the physics blend weight and the animation flags, written
	 * through the PROPERTY system on purpose.
	 *
	 * The accessor names are not stable across engine versions - UE 5.7 has no
	 * USkeletalMeshComponent::GetPhysicsBlendWeight (a real build failure in this
	 * project) - while the UPROPERTY names below have been stable for years. A
	 * property that does not exist on this engine version is simply skipped, so the
	 * fix degrades instead of breaking the build.
	 *
	 * Blend weight is the one that matters: physics simulation being off is not
	 * enough, a weight of 1 keeps the component rendering the last simulated pose
	 * (the frozen death pose) forever. The caller clears the weight with the
	 * documented SetPhysicsBlendWeight(0.f); this helper covers the flags around it,
	 * which have no stable accessors at all.
	 */
	inline void ClearPhysicsBlendAndAnimFlags(USkeletalMeshComponent* Mesh)
	{
		if (!Mesh || !Mesh->GetClass()) return;

		if (FProperty* BlendProp = FindNumericProp(Mesh, { TEXT("PhysicsBlendWeight") }))
		{
			WriteNumericProp(BlendProp, Mesh, 0.0);
		}
		if (FProperty* RateProp = FindNumericProp(Mesh, { TEXT("GlobalAnimRateScale") }))
		{
			WriteNumericProp(RateProp, Mesh, 1.0);
		}
		WriteBoolProp(Mesh, { TEXT("bBlendPhysics") }, false);
		WriteBoolProp(Mesh, { TEXT("bNoSkeletonUpdate") }, false);
		WriteBoolProp(Mesh, { TEXT("bPauseAnims") }, false);
	}

	/**
	 * Kills every bit of physics on a skeletal mesh AND gives the pose back to
	 * the AnimBP. Turning simulation off is not enough on its own: the component
	 * keeps the last physics pose (the frozen death pose) until the physics
	 * blend weight is reset and the animation mode is re-armed. Conversely a
	 * death sequence can leave the component paused (bPauseAnims), tick-disabled
	 * or skeleton-update-disabled, which reads as "no animations" even when the
	 * pose is fine - so all of those are reset too.
	 *
	 * Returns true if the mesh's anim instance was re-initialised.
	 */
	// S19-DEATHPOSE
	inline bool RestoreAnimatedPose(USkeletalMeshComponent* Mesh, bool bReinitializeAnim = true, bool bForceAnimMode = false)
	{
		if (!Mesh) return false;

		Mesh->SetAllPhysicsLinearVelocity(FVector::ZeroVector);
		Mesh->SetAllPhysicsAngularVelocityInDegrees(FVector::ZeroVector);
		Mesh->PutAllRigidBodiesToSleep();
		Mesh->SetAllBodiesSimulatePhysics(false);
		Mesh->SetSimulatePhysics(false);

		// The line that actually un-freezes the death pose: with a physics blend weight
		// of 1 (set when simulation was switched on) the component keeps rendering its
		// last physics pose no matter what else is restored. Per Epic's docs this call
		// also switches simulation off for the whole component when the weight is 0,
		// which is exactly the state a revived pawn must be in. (There is no
		// GetPhysicsBlendWeight() - hence the reflection read in the situation log.)
		Mesh->SetPhysicsBlendWeight(0.f);

		// The remaining animation flags a death sequence can leave behind
		// (anim rate, blend-physics, pause, no-skeleton-update), by property name.
		ClearPhysicsBlendAndAnimFlags(Mesh);

		Mesh->SetComponentTickEnabled(true);

		// A death sequence can leave the component in a non-animation mode (a
		// single-node death pose, or a custom/frozen pose). The character's own
		// mesh must be AnimBP-driven again; other meshes on the pawn (weapon,
		// camera proxy, ragdoll proxy) keep whatever mode they were authored
		// with - they only needed the physics killed.
		bool bReinitialised = false;
		if (bForceAnimMode || Mesh->GetAnimationMode() == EAnimationMode::AnimationBlueprint)
		{
			// Second argument: force the anim script instance to (re)initialise even if
			// the mode is already AnimationBlueprint - the 5.3+ signature has it, and
			// passing it explicitly avoids relying on a default value.
			Mesh->SetAnimationMode(EAnimationMode::AnimationBlueprint, /*bForceInitAnimScriptInstance=*/true);

			if (bReinitializeAnim)
			{
				if (UAnimInstance* Anim = Mesh->GetAnimInstance())
				{
					// Re-runs the AnimBP's initialisation, which is what clears a
					// state machine latched in its death/dead state.
					Anim->InitializeAnimation();
					bReinitialised = true;
				}
			}
		}

		Mesh->SetVisibility(true);
		Mesh->SetHiddenInGame(false);
		return bReinitialised;
	}

	/**
	 * RestoreAnimatedPose() for every skeletal mesh on a pawn (pack characters
	 * own several: CharacterMesh0, WeaponMesh, a ragdoll proxy, ...). The
	 * character's primary mesh also gets the CharacterMesh collision profile
	 * back, because the pack swaps it to "Ragdoll" on death.
	 */
	// S19-DEATHPOSE
	inline int32 RestoreAllMeshes(AActor* Actor, bool bResetCollision = true)
	{
		if (!Actor) return 0;
		USkeletalMeshComponent* Primary = nullptr;
		if (const ACharacter* AsCharacter = Cast<ACharacter>(Actor))
		{
			Primary = AsCharacter->GetMesh();
		}

		TArray<USkeletalMeshComponent*> Meshes;
		Actor->GetComponents<USkeletalMeshComponent>(Meshes);
		int32 Count = 0;
		for (USkeletalMeshComponent* Mesh : Meshes)
		{
			if (!Mesh) continue;
			const bool bIsPrimary = (Mesh == Primary);
			RestoreAnimatedPose(Mesh, /*bReinitializeAnim=*/true, /*bForceAnimMode=*/bIsPrimary);
			if (bIsPrimary && bResetCollision)
			{
				Mesh->SetCollisionProfileName(TEXT("CharacterMesh"));
				Mesh->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
			}
			++Count;
		}
		return Count;
	}
}

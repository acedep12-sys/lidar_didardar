#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "SquadAIDevDebugSubsystem.generated.h"

class APawn;
class APlayerController;

/**
 * USquadAIDevDebugSubsystem
 * In-Game Developer Testing & Debug Automation Subsystem.
 * 
 * Provides instantaneous cheat and debugging functions in PIE (Play In Editor)
 * so creators can test missions, AI encounters, and weapons without friction.
 */
UCLASS()
class SQUADAI_API USquadAIDevDebugSubsystem : public UWorldSubsystem
{
	GENERATED_BODY()

public:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

	static USquadAIDevDebugSubsystem* Get(const UObject* WorldContextObject);

	// =========================================================================
	//  CONFIG & TOGGLES
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Developer Cheats")
	bool bEnableDeveloperHotkeys = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Developer Cheats")
	bool bGodModeActive = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Developer Cheats")
	bool bInfiniteAmmoActive = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Developer Cheats")
	bool bDrawAIDebugVisuals = false;

	// =========================================================================
	//  CHEAT & TESTING API
	// =========================================================================

	UFUNCTION(BlueprintCallable, Exec, Category = "Developer Cheats")
	void ToggleGodMode();

	UFUNCTION(BlueprintCallable, Exec, Category = "Developer Cheats")
	void ToggleInfiniteAmmo();

	UFUNCTION(BlueprintCallable, Exec, Category = "Developer Cheats")
	void RefillAllAmmo();

	UFUNCTION(BlueprintCallable, Exec, Category = "Developer Cheats")
	void TeleportToNextObjective();

	UFUNCTION(BlueprintCallable, Exec, Category = "Developer Cheats")
	void TeleportToSquadLeader();

	UFUNCTION(BlueprintCallable, Exec, Category = "Developer Cheats")
	void SpawnEnemySquadAtCrosshair(int32 Count = 3);

	UFUNCTION(BlueprintCallable, Exec, Category = "Developer Cheats")
	void SpawnAllyReinforcementsAtCrosshair(int32 Count = 2);

	UFUNCTION(BlueprintCallable, Exec, Category = "Developer Cheats")
	void DropSupplyKitAtFeet();

	// MEGA-5 (P1-L3): console torture-test for the Farsi shaper (mixed EN/FA, digits, timers, diacritics, ZWNJ).
	UFUNCTION(BlueprintCallable, Exec, Category = "Developer Cheats")
	void TestFarsiShaping();

	UFUNCTION(BlueprintCallable, Exec, Category = "Developer Cheats")
	void CompleteCurrentObjective();

	UFUNCTION(BlueprintCallable, Exec, Category = "Developer Cheats")
	void ToggleSandstormWeather();

	UFUNCTION(BlueprintCallable, Exec, Category = "Developer Cheats")
	void CallDevMortarStrikeAtCrosshair();

	UFUNCTION(BlueprintCallable, Exec, Category = "Developer Cheats")
	void TriggerDevRadioChatter();

	UFUNCTION(BlueprintCallable, Exec, Category = "Developer Cheats")
	void SpawnDestroyedBuildingAtCrosshair();

	UFUNCTION(BlueprintCallable, Exec, Category = "Developer Cheats")
	void ToggleAIDebugVisuals();

	/**
	 * Scans and verifies all textures, icons, backgrounds, and frames.
	 * Logs detailed status with '[SQUADAI_ASSET_AUDIT]' filter tag.
	 * Callable via console: SquadAI.CheckAssets, CheckAssets, AuditTextures
	 */
	UFUNCTION(BlueprintCallable, Exec, Category = "Developer Cheats")
	void AuditGameAssets();

	UFUNCTION(BlueprintCallable, Exec, Category = "Developer Cheats")
	FString DumpDiagnostics();

	UFUNCTION(BlueprintCallable, Exec, Category = "Developer Cheats")
	void ToggleDebugLogs();

	/** Ticked from HUD to poll developer function keys F1-F10 */
	void PollDeveloperHotkeys(APlayerController* PC);

private:
	FVector GetPlayerCrosshairWorldLocation(APlayerController* PC) const;
};

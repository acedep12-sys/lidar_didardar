// SquadAILoadingHandoffModel.h - S19-INSTANT
//
// The rule behind "the loading screen must appear the moment the player picks a
// difficulty", expressed as plain functions so it can be compiled and exercised
// offline (tools/loading_test) without Unreal.
//
// What was wrong before this file existed
// ---------------------------------------
// The transition request did put a screen up before travelling - but the screen it
// put up was a UMG widget that draws nothing in C++ (no widget tree, no Blueprint
// to supply one), and the source world's HUD never drew a loading screen of its
// own. So the sequence the player saw was:
//
//   1. click the difficulty card  -> "loading screen shown" is logged,
//   2. the widget is added to the viewport -> invisible,
//   3. the map load blocks the game thread -> the last DRAWN frame (the menu) stays
//      on screen for the several seconds the load takes,
//   4. the new world initialises and the gameplay HUD's deployment veil appears.
//
// Which is exactly the report: *"it stucks a few second on that screen before going
// to the loading screen"*. The fix is to make the SOURCE world draw the loading
// screen on the same frame, and to make the blocking travel wait until it has been
// drawn - this file is that wait.
//
// The rule
// --------
//   * travel may not start until the screen has been painted at least
//     MinPaintedFrames times (a frame the player never saw is not a screen);
//   * it may not start before DeferSeconds either, so the screen is up for a
//     moment the player can register rather than a single flicker;
//   * and it must start by HardTimeoutSeconds regardless, so a HUD that never
//     reports (a custom/BP HUD, a headless run) can never stall the game.
//
// The progress value is the *same* simulated ramp the destination's deployment
// veil uses, and it survives the travel (the destination seeds its bar from it),
// so the bar does not jump back to zero when the new world appears.

#pragma once

#include "CoreMinimal.h"

struct FSquadAILoadingHandoff
{
	/** Seconds between the request and the first travel attempt. */
	static constexpr float DeferSeconds = 0.25f;

	/** How many times the departure screen must have been DRAWN before the
	 *  blocking travel is allowed to start. Two, not one: the frame that draws
	 *  the screen is the frame the click was processed in, and one frame of a
	 *  full-screen image is not yet a screen the player has waited on. */
	static constexpr int32 MinPaintedFrames = 2;

	/** Absolute cap. If the source HUD never reports a paint, the travel still
	 *  has to happen - a missing screen must not become a stuck game. */
	static constexpr float HardTimeoutSeconds = 1.5f;

	/** The simulated bar ramp, in fraction per second (1 / 0.42 ~ 2.4 s). */
	static constexpr float ProgressPerSecond = 0.42f;

	/** The bar never claims completion while a travel is still outstanding; the
	 *  destination shares the destination-side ramp and takes it to 1. */
	static constexpr float MaxProgress = 0.92f;

	/** Request accepted, screen not necessarily drawn yet. */
	bool bPending = false;

	/** The blocking travel has been fired: nothing more to hold. */
	bool bTravelled = false;

	/** Times the departure screen has been drawn while pending. */
	int32 PaintedFrames = 0;

	/** Seconds since the request (accumulated by Tick). */
	float ElapsedSeconds = 0.f;

	/** Simulated bar fill, 0 .. MaxProgress while pending. */
	float Progress = 0.f;

	/** A transition was requested. Resets the counters, so a second transition
	 *  is gated exactly like the first. */
	void BeginDeparture()
	{
		bPending = true;
		bTravelled = false;
		PaintedFrames = 0;
		ElapsedSeconds = 0.f;
		Progress = 0.f;
	}

	/** One frame in which the source world drew the departure screen. */
	void NotifyScreenPainted()
	{
		if (IsDeparturePending())
		{
			++PaintedFrames;
		}
	}

	/** Advance the clock. Safe to call before the first paint, and after travel
	 *  (a no-op then): the HUDs run every frame whether a transition is brewing
	 *  or not. */
	void Tick(float DeltaSeconds)
	{
		if (!IsDeparturePending())
		{
			return;
		}
		const float Step = FMath::Max(0.f, DeltaSeconds);
		ElapsedSeconds += Step;
		Progress = FMath::Min(MaxProgress, Progress + ProgressPerSecond * Step);
	}

	/** May the blocking travel start now? */
	bool ShouldFireTravel() const
	{
		if (!IsDeparturePending())
		{
			return false;
		}
		if (ElapsedSeconds >= HardTimeoutSeconds)
		{
			return true;
		}
		return ElapsedSeconds >= DeferSeconds && PaintedFrames >= MinPaintedFrames;
	}

	/** Is the departure screen the thing the player should be looking at? */
	bool IsDeparturePending() const { return bPending && !bTravelled; }

	bool HasTravelled() const { return bTravelled; }

	/** Travel fired. Progress is deliberately NOT reset: the destination reads it
	 *  to continue the bar instead of restarting it. */
	void MarkTravelled()
	{
		bPending = false;
		bTravelled = true;
	}

	/** Abandon without travelling (world teardown). Progress survives, like
	 *  MarkTravelled, so a cancelled transition cannot corrupt the next one. */
	void Cancel() { bPending = false; }

	float GetProgress() const { return Progress; }

	/** Seconds left before the hard timeout fires the travel anyway. */
	float SecondsUntilTimeout() const
	{
		return FMath::Max(0.f, HardTimeoutSeconds - ElapsedSeconds);
	}
};

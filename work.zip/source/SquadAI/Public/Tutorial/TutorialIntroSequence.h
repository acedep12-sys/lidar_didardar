// TutorialIntroSequence.h — S18-INTRO
// A proper first-mission opening instead of a list of disconnected lessons:
// the guide walks you down the trench and the beats fire off the walk —
// "stay with me", "this is the firing step", "wire starts here", then he hands
// you the rifle at the practice range and the normal tutorial steps take over.
//
// Authoring: place this actor, drop a few target points in the level, add one
// entry per beat. No Blueprint and no Sequencer needed.
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Tutorial/SquadAITutorialSubsystem.h"
#include "Quest/MissionZone.h" // S18-INTRO2: UHT needs the full enum + class for the bound UFUNCTION
#include "TutorialIntroSequence.generated.h"

class ATutorialGuideActor;
class USoundBase;

UENUM(BlueprintType)
enum class ESquadAIIntroAction : uint8
{
	/** Guide walks to the point, then the line plays. */
	WalkAndSay        UMETA(DisplayName = "Walk there and speak"),
	/** Guide waits until the player is within Radius, then speaks. */
	WaitForPlayer     UMETA(DisplayName = "Wait for the player"),
	/** Speak immediately, no movement. */
	SayOnly           UMETA(DisplayName = "Just speak"),
	/** Hand over to the normal tutorial flow and end the intro. */
	HandOffToTutorial UMETA(DisplayName = "Hand off to the tutorial")
};

USTRUCT(BlueprintType)
struct SQUADAI_API FSquadAIIntroBeat
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Intro")
	ESquadAIIntroAction Action = ESquadAIIntroAction::WalkAndSay;

	/** Where the guide goes / where the player must reach. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Intro")
	TObjectPtr<AActor> Point;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Intro")
	FString LineFa;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Intro")
	FString LineEn;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Intro")
	TObjectPtr<USoundBase> Voice;

	/** Acceptance radius for arrival / for the player catching up, cm. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Intro", meta = (ClampMin = "100.0", ClampMax = "5000.0"))
	float Radius = 350.f;

	/** Extra pause after the beat resolves, seconds. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Intro", meta = (ClampMin = "0.0", ClampMax = "20.0"))
	float DwellSeconds = 1.2f;

	/** Safety valve: give up on this beat after this long. 0 = never. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Intro", meta = (ClampMin = "0.0", ClampMax = "120.0"))
	float TimeoutSeconds = 35.f;
};

UCLASS()
class SQUADAI_API ATutorialIntroSequence : public AActor
{
	GENERATED_BODY()

public:
	ATutorialIntroSequence();

	/** Start the walk now. Runs automatically at BeginPlay unless disabled. */
	UFUNCTION(BlueprintCallable, CallInEditor, Category = "Intro")
	void StartIntro();

	/** Abort and hand straight over to the normal tutorial. */
	UFUNCTION(BlueprintCallable, CallInEditor, Category = "Intro")
	void SkipIntro();

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Intro")
	bool bAutoStart = true;

	/** Seconds after level start before the first beat. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Intro", meta = (ClampMin = "0.0", ClampMax = "30.0"))
	float StartDelaySeconds = 2.0f;

	/** Who leads. Empty = the first ATutorialGuideActor in the level. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Intro")
	TObjectPtr<ATutorialGuideActor> Guide;

	/** Walk speed the guide is pushed to while leading, cm/s. 0 = leave alone. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Intro", meta = (ClampMin = "0.0", ClampMax = "900.0"))
	float LeadWalkSpeed = 240.f;

	/** If the player falls further behind than this the guide waits, cm. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Intro", meta = (ClampMin = "200.0", ClampMax = "5000.0"))
	float PlayerLagDistance = 900.f;

	/** S18-LOC: objective banner shown while following the guide. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Intro|Text")
	FString ObjectiveFollowFa = TEXT("به دنبال سرگرد");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Intro|Text")
	FString ObjectiveFollowEn = TEXT("FOLLOW THE MAJOR");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Intro|Text")
	FString ObjectiveListenFa = TEXT("گوش کن");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Intro|Text")
	FString ObjectiveListenEn = TEXT("LISTEN");

	/** S18-INTRO3: hold the walk until any mission-briefing card has closed. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Intro")
	bool bWaitForBriefingCard = true;

	/** S18-INTRO2: play at most once per level, remembered across saves. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Intro")
	bool bPlayOncePerLevel = true;

	/** S18-INTRO2: skip entirely once training is done. Turn OFF for a later
	 *  mission's own walk, which should play even for a trained player. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Intro")
	bool bOnlyBeforeTutorial = true;

	/** S18-INTRO2: instead of starting at level open, wait for this mission
	 *  zone to go Active. Leave empty for the opening walk. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Intro")
	TObjectPtr<AMissionZone> TriggerMission;

	/** The script. Leave empty to use the built-in five-beat trench walk. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Intro")
	TArray<FSquadAIIntroBeat> Beats;

	/** True while the intro owns the player's attention. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Intro")
	bool IsIntroRunning() const { return bRunning; }

	/** Index of the beat being played, for the HUD. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Intro")
	int32 GetCurrentBeatIndex() const { return CurrentBeat; }

	/** "Follow Major Rostami" style objective line while the intro runs. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Intro")
	FString GetIntroObjective(bool bEnglish) const;

protected:
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaSeconds) override;
	virtual void EndPlay(const EEndPlayReason::Type Reason) override;

	void EnterBeat(int32 Index);
	void AdvanceBeat();
	void BuildDefaultBeats();
	FString GetLevelKey() const;
	void MarkIntroPlayed();

	UFUNCTION()
	void HandleMissionStateChanged(AMissionZone* Mission, EMissionZoneState NewState);
	ATutorialGuideActor* ResolveGuide();
	AActor* GuidePawnActor() const;
	bool MoveGuideTo(const FVector& Target, float Accept, float DeltaSeconds);

private:
	bool bRunning = false;
	int32 CurrentBeat = INDEX_NONE;
	float BeatStartTime = 0.f;
	float DwellUntil = -1.f;
	bool bBeatSpoken = false;
	FTimerHandle StartTimer;

	/** S18-FIX: path-request throttling so the guide does not stutter. */
	FVector LastMoveTarget = FVector(FLT_MAX);
	float NextMoveRefresh = -1.f;
};

// TutorialRangeActor.h — S18-TUT
// Drop ONE of these in the map near the player start. It spawns the whole
// practice range for the tutorial: a row of small cans to shoot and a barrel to
// put a grenade into, both reported back to USquadAITutorialSubsystem.
#pragma once

#include "CoreMinimal.h"
#include "Tutorial/TutorialBarrelModel.h" // S19-BARREL: the mouth rule
#include "GameFramework/Actor.h"
#include "TutorialRangeActor.generated.h"

class UStaticMeshComponent;
class USphereComponent;
class UBoxComponent;

/** A small can: a few hitpoints, falls over and reports the hit. */
UCLASS()
class SQUADAI_API ATutorialTargetCan : public AActor
{
	GENERATED_BODY()

public:
	ATutorialTargetCan();

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Tutorial")
	TObjectPtr<UStaticMeshComponent> CanMesh;

	/** Called by a bullet trace, radial damage, or Blueprint. Idempotent. */
	UFUNCTION(BlueprintCallable, Category = "Tutorial")
	void RegisterHit(const FVector& ImpactDirection);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Tutorial")
	bool IsKnockedDown() const { return bKnockedDown; }

protected:
	virtual void BeginPlay() override;

	UFUNCTION()
	void HandleAnyDamage(AActor* DamagedActor, float Damage, const class UDamageType* DamageType,
		class AController* InstigatedBy, AActor* DamageCauser);

	UFUNCTION()
	void HandlePointDamage(AActor* DamagedActor, float Damage, class AController* InstigatedBy,
		FVector HitLocation, class UPrimitiveComponent* HitComponent, FName BoneName,
		FVector ShotDirection, const class UDamageType* DamageType, AActor* DamageCauser);

private:
	bool bKnockedDown = false;
};

/** The barrel the player must drop a grenade into. */
UCLASS()
class SQUADAI_API ATutorialGrenadeBarrel : public AActor
{
	GENERATED_BODY()

public:
	ATutorialGrenadeBarrel();

	/** The mouth rule - the same numbers that build the cup's collision, so the
	 *  geometry and the acceptance test cannot disagree. S19-BARREL. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tutorial")
	FTutorialBarrelMouth Mouth;

	/**
	 * S19-BARREL: the barrel's collision, built as a **cup**: one floor plate and
	 * a ring of wall segments (invisible; they sit inside the visual mesh, which
	 * no longer collides). Before this the barrel was a solid cylinder, so a
	 * grenade could never actually go inside it - and the lesson's test faked it
	 * with a huge sphere. Nobody can put a grenade in a sealed drum.
	 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Tutorial")
	TArray<TObjectPtr<UStaticMeshComponent>> CupParts;

	/** The visual barrel body (engine cylinder). NoCollision: it is a shell. */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Tutorial")
	TObjectPtr<UStaticMeshComponent> BarrelBody;

	UFUNCTION(BlueprintCallable, Category = "Tutorial")
	void RegisterGrenadeHit();

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Tutorial")
	bool IsSatisfied() const { return bSatisfied; }

	/** S19-BARREL: true while a grenade is inside the mouth (read by the HUD's
	 *  world marker and by the tests). */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Tutorial")
	bool IsOccupied() const { return bOccupied; }

	/** Build the cup collision from Mouth. Safe to call again (rebuilds). */
	UFUNCTION(BlueprintCallable, Category = "Tutorial")
	void BuildCup();

protected:
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaSeconds) override;

private:
	bool bSatisfied = false;
	bool bOccupied = false;
	float ScanTimer = 0.f;
	/** S19-BARREL: last time a live grenade was seen *near* the barrel but not in
	 *  it - used to say so in the log once per throw instead of silently ignoring
	 *  the miss (the whole point of this round's report). */
	double LastMissTime = -1.0;
};

UCLASS()
class SQUADAI_API ATutorialRangeActor : public AActor
{
	GENERATED_BODY()

public:
	ATutorialRangeActor();

	/** Spawn the range now (also runs automatically at BeginPlay). */
	UFUNCTION(BlueprintCallable, CallInEditor, Category = "Tutorial Range")
	void BuildRange();

	UFUNCTION(BlueprintCallable, CallInEditor, Category = "Tutorial Range")
	void ClearRange();

	/** Number of cans; must match USquadAITutorialSubsystem::CansToShoot. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tutorial Range", meta = (ClampMin = "1", ClampMax = "12"))
	int32 CanCount = 3;

	/** Spacing between cans, cm. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tutorial Range")
	float CanSpacingCm = 90.f;

	/** Where the can row sits relative to this actor, cm. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tutorial Range")
	FVector CanRowOffset = FVector(900.f, -250.f, 0.f);

	/** Where the grenade barrel sits relative to this actor, cm. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tutorial Range")
	FVector BarrelOffset = FVector(1400.f, 450.f, 0.f);

	/** Optional override meshes; engine shapes are used when empty. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tutorial Range")
	TObjectPtr<UStaticMesh> CanMeshOverride;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tutorial Range")
	TObjectPtr<UStaticMesh> BarrelMeshOverride;

	// ---------------- S19-MAT: the props were naked grey engine shapes ----
	/** Force this material onto the cans. Empty = auto (see below). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tutorial Range|Materials")
	TObjectPtr<UMaterialInterface> CanMaterialOverride;

	/** Force this material onto the barrel. Empty = auto (see below). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tutorial Range|Materials")
	TObjectPtr<UMaterialInterface> BarrelMaterialOverride;

	/**
	 * When no override is set, look for the trench material pack the importer
	 * script creates — /Game/SquadAI/TrenchMaterials/M_TrenchAmmoCan for the
	 * cans and M_TrenchDrum for the barrel — and use it if it is present.
	 * Without this the props render with the default engine material, which is
	 * exactly the flat grey "no texture" look.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tutorial Range|Materials")
	bool bAutoResolveTrenchMaterials = true;

	/** Resolve one of the trench pack materials by asset name (no extension).
	 *  Returns null when the pack has not been imported yet. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Tutorial Range|Materials")
	static UMaterialInterface* ResolveTrenchMaterial(const FString& AssetName);

	/** Drop everything onto the ground with a downward trace. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tutorial Range")
	bool bSnapToGround = true;

	/** Despawn the range once the tutorial is over. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tutorial Range")
	bool bClearWhenTutorialEnds = true;

protected:
	virtual void BeginPlay() override;

	UFUNCTION()
	void HandleTutorialFinished();

	FVector GroundedLocation(const FVector& In) const;

private:
	UPROPERTY()
	TArray<TObjectPtr<AActor>> SpawnedProps;
};

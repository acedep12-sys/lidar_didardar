// TutorialBarrelModel.h - S19-BARREL
//
// The rule behind the grenade lesson: *the grenade has to go in the barrel*.
//
// What was wrong before this file existed
// ---------------------------------------
// The barrel was a solid engine cylinder with BlockAllDynamic collision - it
// had no opening at all - so "put the grenade inside it" was physically
// impossible. The acceptance test papered over that with a sphere: radius
// 140 cm, centred 60 cm above the barrel's own origin, scaled by whatever the
// barrel actor's scale happened to be. That is a ~2.5 m ball around the rim of
// a 60 cm drum, and it accepted a grenade that landed **a metre away in any
// direction**, at any height up to 2.3 m - and it grew with the actor's scale,
// so a barrel placed or scaled in the level accepted almost anything.
//
// The shape of the fix
// --------------------
// The barrel now has a real mouth: the visual mesh stopped colliding and the
// actor builds a **cup** out of collision parts (a floor and a ring of wall
// segments) - and the wall rectangles' placement lives HERE, next to the rule,
// so the collision the player feels and the test the lesson applies are built
// from one set of numbers. A grenade lobbed at the mouth falls in and rests on
// the floor.
// Acceptance is then the same question the player is asking - "is the grenade
// inside the barrel?" - expressed once, here, as a cylinder test, and used by
// both the actor that builds the cup and the test that decides the lesson is
// done. Geometry and rule cannot drift apart, because they are the same
// numbers.
//
// Engine-free on purpose: this header is compiled and exercised by
// tools/tutorial_test (no Unreal required), the same way PatrolRouteModel.h is
// exercised by tools/patrol_test.

#pragma once

#include "CoreMinimal.h"
#include "TutorialBarrelModel.generated.h"

/**
 * The barrel's interior, in the barrel's own local space (Z = 0 is the middle
 * of the 90 cm mesh, exactly like the engine cylinder the visual uses).
 *
 *   OuterRadiusCm  30   - the visual barrel (engine Cylinder, scale 0.6, 0.6, 0.9)
 *   WallThicknessCm 5   - wall segments, centred on the ring radius
 *   InnerRadiusCm  25   - the free space the grenade may occupy: 30 - 5
 *   RimZCm        +45   - top of the barrel = the mouth
 *   FloorTopZCm   -43   - top face of the floor plate
 *
 * So the acceptance volume is a cylinder 50 cm across and 88 cm deep - a
 * grenade's centre has to be in that volume. For scale: the old test accepted
 * anything within 126 cm of a point above the rim.
 */
USTRUCT(BlueprintType)
struct FTutorialBarrelMouth
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tutorial|Barrel")
	float OuterRadiusCm  = 30.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tutorial|Barrel")
	float InnerRadiusCm  = 25.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tutorial|Barrel")
	float WallThicknessCm = 5.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tutorial|Barrel")
	float RimZCm         = 45.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tutorial|Barrel")
	float FloorTopZCm    = -43.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tutorial|Barrel")
	float FloorThicknessCm = 4.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tutorial|Barrel")
	int32 WallSegments   = 8;
	/** Each wall segment's width. 8 x 24 cm = 192 cm of wall on a 173 cm
	 *  circumference, so neighbouring segments overlap and there are no gaps. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tutorial|Barrel")
	float WallWidthCm    = 24.f;
	/** How far above the rim a grenade may still count (it is perched in the
	 *  mouth rather than resting on the floor). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tutorial|Barrel")
	float MouthSlackZCm  = 6.f;

	/** The mouth's centre, in the barrel's local space (what the guide's demo
	 *  arcs at, and what the tutorial's world marker points at). */
	FVector MouthCentre() const { return FVector(0.0, 0.0, RimZCm + 10.0); }

	/** Radius of the ring the wall segments sit on. */
	float WallRingRadiusCm() const { return OuterRadiusCm - WallThicknessCm * 0.5f; }

	/** How tall a wall segment is: floor to rim. */
	float WallHeightCm() const { return RimZCm - FloorTopZCm; }

	/**
	 * Is a grenade centred at LocalPos inside the barrel?
	 *
	 * Deliberately exact and deliberately plain: horizontal distance from the
	 * barrel's axis within the inner radius, and Z between the floor and the
	 * rim (plus the small perched-in-the-mouth slack). A grenade on the ground
	 * beside the barrel is at |Z| ~ 105 + 8 from the barrel's centre and fails
	 * on Z as well as on radius.
	 */
	static bool ContainsPoint(const FVector& LocalPos, const FTutorialBarrelMouth& M)
	{
		const double HorizSq = LocalPos.X * LocalPos.X + LocalPos.Y * LocalPos.Y;
		if (HorizSq > static_cast<double>(M.InnerRadiusCm) * static_cast<double>(M.InnerRadiusCm))
		{
			return false;
		}
		return LocalPos.Z >= static_cast<double>(M.FloorTopZCm)
			&& LocalPos.Z <= static_cast<double>(M.RimZCm + M.MouthSlackZCm);
	}

	/**
	 * S19-BARREL: has a grenade at LocalPos, moving at Velocity, actually GONE IN?
	 *
	 * Being inside the mouth is not enough - the actor scans at 20 Hz while the grenade
	 * is still in the air. A grenade racing through the opening on its way out (a hard
	 * bounce off the cup floor, a throw that overshoots the rim and clips the mouth on
	 * the way past) used to register the lesson as done and then sail away, which reads
	 * exactly like the bug this round was about.
	 *
	 * The rule: inside, and no longer travelling fast. A lobbed grenade that lands in the
	 * drum slows within a few hundred milliseconds as it bounces and rolls, and the
	 * lesson fires then - the moment the player sees it settle. Anything still doing
	 * more than ~2.5 m/s has not arrived yet.
	 *
	 * S19-DEEPREVIEW: acceptance lives here, not in the caller, because the old caller rule
 * ('not climbing fast') accepted a grenade crossing the mouth at speed. The test is the
 * total speed, not the vertical component, and it is inclusive at 250 cm/s.
 *
 * Callers with no velocity to offer (a grenade actor without a mover component) pass
	 * ZeroVector: unknown motion never withholds the count.
	 */
	static bool CountsAsLanded(const FVector& LocalPos, const FVector& Velocity,
		const FTutorialBarrelMouth& M)
	{
		if (!ContainsPoint(LocalPos, M))
		{
			return false;
		}
		constexpr double SettledSpeedCmS = 250.0;
		return Velocity.SizeSquared() <= SettledSpeedCmS * SettledSpeedCmS;
	}

	/** How many wall segments the cup is built from. */
	int32 WallSegmentCount() const { return FMath::Max(4, WallSegments); }

	/** Angle of segment Index around the barrel's axis, in degrees. */
	float WallSegmentAngleDeg(int32 Index) const
	{
		const int32 Count = WallSegmentCount();
		const int32 Wrapped = ((Index % Count) + Count) % Count;
		return FMath::RadiansToDegrees(2.f * PI * static_cast<float>(Wrapped) / static_cast<float>(Count));
	}

	/** The centre of wall segment Index, in the barrel's local space. */
	FVector WallSegmentOffsetCm(int32 Index) const
	{
		const float AngleDeg = WallSegmentAngleDeg(Index);
		const float Angle = FMath::DegreesToRadians(AngleDeg);
		return FVector(FMath::Cos(Angle) * WallRingRadiusCm(), FMath::Sin(Angle) * WallRingRadiusCm(),
			FloorTopZCm + WallHeightCm() * 0.5f);
	}

	/** The yaw segment Index is placed at: its width runs along the tangent, so
	 *  the rectangle's faces point at the axis. */
	float WallSegmentYawDeg(int32 Index) const { return WallSegmentAngleDeg(Index) + 90.f; }

	/**
	 * Does wall segment Index occupy LocalPos? The segment is a
	 * WallWidthCm x WallThicknessCm box on the ring, rotated by WallSegmentYawDeg.
	 *
	 * The actor builds its collision from WallSegmentOffsetCm / WallSegmentYawDeg,
	 * and this is the same rectangle - that is what makes "the walls seal the cup"
	 * a property of the shipped geometry rather than a claim about it.
	 */
	static bool WallSegmentCoversPoint(const FVector& LocalPos, int32 Index, const FTutorialBarrelMouth& M)
	{
		if (LocalPos.Z < M.FloorTopZCm || LocalPos.Z > M.RimZCm)
		{
			return false;
		}
		const FVector Centre = M.WallSegmentOffsetCm(Index);
		const double Yaw = static_cast<double>(FMath::DegreesToRadians(M.WallSegmentYawDeg(Index)));
		const double DX = LocalPos.X - Centre.X;
		const double DY = LocalPos.Y - Centre.Y;
		// Two rotations to min/max form: enough for a point-in-rectangle test.
		const double LX = DX * FMath::Cos(Yaw) + DY * FMath::Sin(Yaw);
		const double LY = -DX * FMath::Sin(Yaw) + DY * FMath::Cos(Yaw);
		return FMath::Abs(LX) <= M.WallWidthCm * 0.5 + 1e-6
			&& FMath::Abs(LY) <= M.WallThicknessCm * 0.5 + 1e-6;
	}

	/** Is LocalPos inside any wall segment? */
	static bool AnyWallCoversPoint(const FVector& LocalPos, const FTutorialBarrelMouth& M)
	{
		for (int32 i = 0; i < M.WallSegmentCount(); ++i)
		{
			if (WallSegmentCoversPoint(LocalPos, i, M))
			{
				return true;
			}
		}
		return false;
	}

	/** Distance from LocalPos to wall segment Index (0 inside it). */
	static float WallSegmentDistanceCm(const FVector& LocalPos, int32 Index, const FTutorialBarrelMouth& M)
	{
		const FVector Centre = M.WallSegmentOffsetCm(Index);
		const double Yaw = static_cast<double>(FMath::DegreesToRadians(M.WallSegmentYawDeg(Index)));
		const double DX = LocalPos.X - Centre.X;
		const double DY = LocalPos.Y - Centre.Y;
		const double LX = DX * FMath::Cos(Yaw) + DY * FMath::Sin(Yaw);
		const double LY = -DX * FMath::Sin(Yaw) + DY * FMath::Cos(Yaw);
		const double DZ = FMath::Max(0.f, static_cast<float>(FMath::Abs(LocalPos.Z - Centre.Z) - M.WallHeightCm() * 0.5f));
		const double OX = FMath::Max(0.f, static_cast<float>(FMath::Abs(LX) - M.WallWidthCm * 0.5));
		const double OY = FMath::Max(0.f, static_cast<float>(FMath::Abs(LY) - M.WallThicknessCm * 0.5));
		return static_cast<float>(FMath::Sqrt(OX * OX + OY * OY + DZ * DZ));
	}

	/** Distance from LocalPos to the nearest wall segment: 0 inside a wall, and
	 *  every point of the ring within a grenade's radius of one means the ring
	 *  cannot pass a grenade no matter how the segments are angled. */
	static float WallCoverageDistanceCm(const FVector& LocalPos, const FTutorialBarrelMouth& M)
	{
		float Best = 1.0e9f;
		for (int32 i = 0; i < M.WallSegmentCount(); ++i)
		{
			Best = FMath::Min(Best, WallSegmentDistanceCm(LocalPos, i, M));
		}
		return Best;
	}

	/**
	 * The broadphase radius the actor should sweep before applying
	 * ContainsPoint: big enough to catch a grenade anywhere near the barrel,
	 * small enough to stay cheap. It only has to be a superset of the volume.
	 */
	float BroadphaseRadiusCm() const
	{
		return FMath::Max(RimZCm + MouthSlackZCm, InnerRadiusCm) + 20.f;
	}
};

// SquadAITutorialSubsystem.h — S18-TUT
// Native tutorial director: first-run skip prompt, a paused UI walkthrough that
// greys the HUD and highlights one element at a time, then hands-on tasks that
// lock the player in place until they are done.
#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "SquadAITutorialSubsystem.generated.h"

class USoundBase;

UENUM(BlueprintType)
enum class ESquadAITutorialStep : uint8
{
	Inactive        UMETA(DisplayName = "Inactive"),
	SkipPrompt      UMETA(DisplayName = "Skip Prompt"),
	UI_Objective    UMETA(DisplayName = "UI: Objective Bar"),
	UI_Squad        UMETA(DisplayName = "UI: Squad Status"),
	UI_Compass      UMETA(DisplayName = "UI: Compass"),
	UI_Weapon       UMETA(DisplayName = "UI: Weapon Plate"),
	UI_Artillery    UMETA(DisplayName = "UI: Artillery Request"),
	Task_Move       UMETA(DisplayName = "Task: Move"),
	Task_ShootCans  UMETA(DisplayName = "Task: Shoot Cans"),
	Task_Grenade    UMETA(DisplayName = "Task: Grenade Into Barrel"),
	Task_Artillery  UMETA(DisplayName = "Task: Call Artillery"),
	Finished        UMETA(DisplayName = "Finished")
};

/** One tutorial beat: what to say, what to highlight, how hard to stop the game. */
USTRUCT(BlueprintType)
struct SQUADAI_API FSquadAITutorialBeat
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly, Category = "Tutorial")
	ESquadAITutorialStep Step = ESquadAITutorialStep::Inactive;

	/** HUD element id to highlight (see AQuestNativeHUD::RegisterTutorialUIRect). */
	UPROPERTY(BlueprintReadOnly, Category = "Tutorial")
	FName HighlightElement;

	UPROPERTY(BlueprintReadOnly, Category = "Tutorial")
	FString TitleFa;

	UPROPERTY(BlueprintReadOnly, Category = "Tutorial")
	FString BodyFa;

	UPROPERTY(BlueprintReadOnly, Category = "Tutorial")
	FString TitleEn;

	UPROPERTY(BlueprintReadOnly, Category = "Tutorial")
	FString BodyEn;

	/** True = freeze the whole game (UI lessons). False = unpause, lock movement. */
	UPROPERTY(BlueprintReadOnly, Category = "Tutorial")
	bool bFullPause = true;

	/** S18-TUT3: key chip shown on the card, e.g. "W A S D", "ماوس چپ", "G". */
	UPROPERTY(BlueprintReadOnly, Category = "Tutorial")
	FString KeyHintFa;

	UPROPERTY(BlueprintReadOnly, Category = "Tutorial")
	FString KeyHintEn;

	/** Hands-on steps need this many successes (cans to shoot, etc.). */
	UPROPERTY(BlueprintReadOnly, Category = "Tutorial")
	int32 RequiredCount = 1;

	/**
	 * S18-TUT batch 4: illustration shown above the instruction card. The HUD
	 * loads /Game/SquadAI/UI/Tutorial/T_Tut_<IllustrationKey>. Empty = no art.
	 */
	UPROPERTY(BlueprintReadOnly, Category = "Tutorial")
	FName IllustrationKey;
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnTutorialStepChanged, ESquadAITutorialStep, NewStep);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnTutorialFinished);

UCLASS(BlueprintType)
class SQUADAI_API USquadAITutorialSubsystem : public UWorldSubsystem
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Tutorial", meta = (WorldContext = "WorldContextObject"))
	static USquadAITutorialSubsystem* Get(const UObject* WorldContextObject);

	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void OnWorldBeginPlay(UWorld& InWorld) override;
	/** S19-INPUT: last-resort release — a subsystem must never leave the player
	 *  with a dead pawn if the world tears down mid-lesson. */
	virtual void Deinitialize() override;

	// ---- flow ---------------------------------------------------------------

	/** Shows the skip question (first play only) or starts/skips automatically. */
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Tutorial")
	void BeginTutorialFlow();

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Tutorial")
	void AnswerSkipPrompt(bool bSkip);

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Tutorial")
	void StartTutorial();

	/** Player pressed continue on a UI lesson / an instruction card. */
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Tutorial")
	void AcknowledgeCurrentBeat();

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Tutorial")
	void SkipTutorial();

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Tutorial")
	void FinishTutorial();

	// ---- progress reporting (called by the tutorial props / gameplay) -------

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Tutorial")
	void ReportProgress(ESquadAITutorialStep ForStep, int32 Amount = 1);

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Tutorial")
	void NotifyCanDestroyed();

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Tutorial")
	void NotifyBarrelGrenaded();

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Tutorial")
	void NotifyArtilleryCalled();

	// ---- queries used by the HUD -------------------------------------------

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Tutorial")
	bool IsTutorialActive() const { return bActive; }

	/**
	 * S18-TUT2: true while the tutorial is running and combat protection is on.
	 * AI must not target the player and the player must take no damage — being
	 * shot while your legs are locked by a tutorial card is not acceptable.
	 */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Tutorial")
	static bool IsTutorialProtectingPlayer(const UObject* WorldContextObject);

	/**
	 * S18-TUT3: wipe the saved tutorial flags and run the whole thing again.
	 * Wired to the pause-menu button and to the console command
	 * "SquadAI.Tutorial.Reset".
	 */
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Tutorial")
	void RestartTutorial();

	/** S18-TUT3: seconds left on the "2 / 3" progress pop, for the HUD. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Tutorial")
	float GetProgressPopAlpha() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Tutorial")
	ESquadAITutorialStep GetCurrentStep() const { return CurrentStep; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Tutorial")
	bool GetCurrentBeat(FSquadAITutorialBeat& OutBeat) const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Tutorial")
	int32 GetCurrentProgress() const { return StepProgress; }

	/** Steps already completed — the HUD greys a tick over each finished entry. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Tutorial")
	const TArray<ESquadAITutorialStep>& GetCompletedSteps() const { return CompletedSteps; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Tutorial")
	bool IsAwaitingSkipAnswer() const { return bActive && CurrentStep == ESquadAITutorialStep::SkipPrompt; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Tutorial")
	bool IsMovementLocked() const { return bMovementLocked; }

	/** All beats, so the HUD can draw the checklist with grey ticks. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Tutorial")
	const TArray<FSquadAITutorialBeat>& GetAllBeats() const { return Beats; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Tutorial")
	bool IsStepCompleted(ESquadAITutorialStep Step) const { return CompletedSteps.Contains(Step); }

	/** Set by the content layer (batch 4) so the HUD can point at the props. */
	UPROPERTY(BlueprintReadWrite, Category = "SquadAI|Tutorial")
	FVector CurrentTaskWorldFocus = FVector::ZeroVector;

	UPROPERTY(BlueprintAssignable, Category = "SquadAI|Tutorial")
	FOnTutorialStepChanged OnTutorialStepChanged;

	UPROPERTY(BlueprintAssignable, Category = "SquadAI|Tutorial")
	FOnTutorialFinished OnTutorialFinished;

	/** How far the player must walk before Task_Move counts as done. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|Tutorial")
	float MoveTaskDistanceCm = 500.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|Tutorial")
	int32 CansToShoot = 3;

	/**
	 * S18-TUT2: the tutorial NEVER hard-pauses the game any more. A real pause
	 * stopped the HUD panels and the world from drawing, which is the empty blue
	 * screen. Instead time is slowed to this dilation while a card is up, so you
	 * can still see the level and the UI element being explained.
	 * 1.0 = no slowdown at all, 0.05 = near freeze.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|Tutorial", meta = (ClampMin = "0.02", ClampMax = "1.0"))
	float CardTimeDilation = 0.18f;

	/**
	 * S18-TUT4: AAA presentation mode (COD / BF convention, on by default).
	 * Hands-on steps NEVER slow time, never veil the screen and never show a
	 * modal card — they get a compact bottom banner with keycap glyphs and an
	 * all-caps objective line with a live counter. Only the five UI lessons use
	 * the slow-motion card, because those genuinely point at the HUD.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|Tutorial")
	bool bCinematicPromptMode = true;

	/** S18-TUT4: seconds of no progress before the helper line escalates. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|Tutorial", meta = (ClampMin = "3.0", ClampMax = "60.0"))
	float HintEscalationSeconds = 12.f;

	/** S18-TUT4: seconds since the current task beat started (HUD reads this). */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Tutorial")
	float GetTimeOnCurrentStep() const;

	/** S18-TUT4: true once the player has been stuck longer than the escalation time. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Tutorial")
	bool ShouldEscalateHint() const;

	/** S18-TUT2: block enemies from targeting or damaging the player during the tutorial. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|Tutorial")
	bool bCombatSafeDuringTutorial = true;

	/** S18-TUT2: auto-spawn the cans/barrel range if the level has no ATutorialRangeActor. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|Tutorial")
	bool bAutoSpawnPracticeRange = true;

	// ---------------- S18-TUTAUDIO: feedback sounds ----------------
	/** Plays when a card appears. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|Tutorial|Audio")
	TObjectPtr<USoundBase> CardOpenSound;

	/** Plays on Continue / acknowledge. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|Tutorial|Audio")
	TObjectPtr<USoundBase> CardConfirmSound;

	/** Plays on every counted success (each can, the barrel, the fire mission). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|Tutorial|Audio")
	TObjectPtr<USoundBase> ProgressSound;

	/** Plays when a whole step is completed. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|Tutorial|Audio")
	TObjectPtr<USoundBase> StepCompleteSound;

	/** Plays once when the training finishes. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|Tutorial|Audio")
	TObjectPtr<USoundBase> TutorialCompleteSound;

	/** S18-TUT2: how far in front of the player the auto-spawned range is placed, cm. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|Tutorial", meta = (ClampMin = "300.0", ClampMax = "4000.0"))
	float PracticeRangeDistanceCm = 850.f;

	/** Delay after level start before the flow begins (lets the veil finish). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|Tutorial")
	float StartDelaySeconds = 1.5f;

	// ---------------- S19-INPUT: the Space / jump collision ----------------
	/**
	 * While a modal card is up the PAWN's input components are detached from
	 * the controller's input stack, so the key never reaches the character's
	 * Jump (or Fire) binding and you stop hopping every time you advance a
	 * lesson. Polling still works — the HUD reads the key straight off
	 * PlayerController, which is why "press Space to continue" still responds.
	 *
	 * Side effect: mouse-look is frozen too while a card is up (standard for
	 * COD/BF-style lessons). Turn this off to keep looking around, in which
	 * case only Enter / the on-screen button will advance the lesson.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|Tutorial|Input")
	bool bBlockPawnInputDuringCards = true;

	/**
	 * Space is bound to Jump in practically every character pack. With pawn
	 * input blocked it is perfectly safe, so it stays on by default. If you
	 * turn the block off, switch this off too and use Enter.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|Tutorial|Input")
	bool bAllowSpaceToAdvance = true;

	// ---------------- S19-TUT: grenade lesson -----------------------------
	/** Grenades are free while the throwing lesson is running — you are being
	 *  taught a throw, not inventory management. Cleared the moment the step
	 *  ends, and on skip/finish, so normal play is unaffected. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|Tutorial|Grenade")
	bool bUnlimitedGrenadesDuringLesson = true;

	/** Draw the predicted arc and the landing ring during the grenade lesson. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|Tutorial|Grenade")
	bool bShowGrenadeArcDuringLesson = true;

	/** Keep the arc on for the rest of the tutorial, not just the lesson. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SquadAI|Tutorial|Grenade")
	bool bShowGrenadeArcForWholeTutorial = false;

	/** S19-TUT: true when the HUD should be drawing the throw arc right now. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Tutorial|Grenade")
	bool IsGrenadePreviewWanted() const;

protected:
	void BuildBeats();
	void EnterStep(ESquadAITutorialStep NewStep);
	void AdvanceToNextStep();
	void ApplyStepGating();
	void SetGamePausedForTutorial(bool bPause);
	/** S18-TUT2: spawn the practice range in front of the player if the map has none. */
	void EnsurePracticeRange();
	void SetMovementLocked(bool bLocked);
	void MarkTutorialDoneInSettings(bool bSkipped);
	void TickMoveTask();

	/** S19-INPUT: detach / re-attach the pawn's input components so a modal
	 *  lesson card cannot leak Space into the character's Jump binding. */
	void SetPawnInputBlocked(bool bBlocked);

	/** S19-TUT: grant (and later revoke) free grenade ammo + the throw arc. */
	void ApplyGrenadeLessonPerks(bool bOn);

private:
	UPROPERTY()
	TArray<FSquadAITutorialBeat> Beats;

	UPROPERTY()
	TArray<ESquadAITutorialStep> CompletedSteps;

	ESquadAITutorialStep CurrentStep = ESquadAITutorialStep::Inactive;
	int32 CurrentBeatIndex = INDEX_NONE;
	int32 StepProgress = 0;
	bool bActive = false;
	/** S18-TUT2: retry counter for the "wait until the level is actually up" gate. */
	int32 StartAttempts = 0;
	/** S18-TUT3: world time the last progress tick happened, drives the pop. */
	float LastProgressTime = -100.f;
	/** S18-TUT4: world time the current step began. */
	float StepStartTime = -1.f;
	bool bMovementLocked = false;
	bool bPausedByTutorial = false;
	/** S19-INPUT: true while we have detached the pawn from the input stack. */
	bool bPawnInputBlocked = false;
	/** S19-TUT: true while the player's grenade component has free ammo. */
	bool bGrenadePerksApplied = false;
	FVector MoveTaskStartLocation = FVector::ZeroVector;
	FTimerHandle MoveTaskTimer;
	FTimerHandle StartDelayTimer;
};

// TutorialGuideActor.h — S18-TUTGUIDE
// A veteran who actually shows you the job instead of a card doing all the
// talking: he walks to each station, demonstrates it (knocks a can down, lobs
// a grenade at the barrel, calls a fire mission), and speaks a line that the
// HUD prints as a subtitle.
//
// He does NOT need a Blueprint: if no guide pawn is assigned he adopts the
// nearest friendly ASoldierCharacter, and if there is none he simply speaks
// from off-screen so the tutorial still works.
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Tutorial/SquadAITutorialSubsystem.h"
#include "TutorialGuideActor.generated.h"

class ASoldierCharacter;
class USoundBase;
class ATutorialTargetCan;

USTRUCT(BlueprintType)
struct SQUADAI_API FSquadAIGuideLine
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Guide")
	FString TextFa;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Guide")
	FString TextEn;

	/** Optional VO. Plays at the guide's location; subtitle shows either way. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Guide")
	TObjectPtr<USoundBase> Voice;

	/** How long the subtitle stays up when there is no VO, seconds. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Guide", meta = (ClampMin = "1.0", ClampMax = "20.0"))
	float Seconds = 4.5f;
};

UCLASS()
class SQUADAI_API ATutorialGuideActor : public AActor
{
	GENERATED_BODY()

public:
	ATutorialGuideActor();

	/** Who speaks. Leave empty to adopt the nearest friendly soldier. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Guide")
	TObjectPtr<AActor> GuidePawn;

	/** Name shown before every subtitle. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Guide")
	FString GuideNameFa = TEXT("سرگرد رستمی");

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Guide")
	FString GuideNameEn = TEXT("Major Rostami");

	/** One line per step. Any left empty falls back to a built-in line. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Guide")
	TMap<ESquadAITutorialStep, FSquadAIGuideLine> Lines;

	/** He physically walks to the props and demonstrates them. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Guide")
	bool bPhysicalDemonstration = true;

	/** Seconds he spends lining up before the demonstration fires. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Guide", meta = (ClampMin = "0.5", ClampMax = "10.0"))
	float DemoWindUpSeconds = 2.0f;

	/** Muzzle/impact cue for the demonstration shot. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Guide")
	TObjectPtr<USoundBase> DemoShotSound;

	/** Current subtitle in the requested language. Empty = nothing to draw. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Guide")
	FString GetActiveSubtitleFor(bool bEnglish) const;

	/** Speaker name for the subtitle plate. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Guide")
	FString GetSpeakerName(bool bEnglish) const { return bEnglish ? GuideNameEn : GuideNameFa; }

	/** 0..1 fade for the subtitle plate. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Guide")
	float GetSubtitleAlpha() const;

	/** Say something immediately (also used by the step hook). */
	UFUNCTION(BlueprintCallable, Category = "Guide")
	void Speak(const FString& TextFa, const FString& TextEn, USoundBase* Voice, float Seconds);

	/** S18-VOX: true while a line is on screen (queue included). */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Guide")
	bool IsSpeaking() const;

	/**
	 * S18-VOX: optional ducking. If both are set, the mix is pushed while the
	 * guide talks and popped when he stops, so gunfire and ambience drop under
	 * his voice the way they do in a scripted AAA mission. Leave empty to do
	 * nothing — no asset is required.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Guide|Audio")
	TObjectPtr<class USoundMix> DuckingMix;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Guide|Audio")
	TObjectPtr<class USoundClass> DuckingClass;

	/** Volume the ducked class drops to while he speaks. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Guide|Audio", meta = (ClampMin = "0.0", ClampMax = "1.0"))
	float DuckedVolume = 0.35f;

	/** Seconds to fade the duck in and out. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Guide|Audio", meta = (ClampMin = "0.0", ClampMax = "3.0"))
	float DuckFadeSeconds = 0.35f;

	/** S18-INTRO: the actor actually doing the guiding (assigned or adopted). */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Guide")
	AActor* GetGuideActor() const { return IsValid(ResolvedGuide) ? ResolvedGuide.Get() : GuidePawn.Get(); }

	/** Where the guide currently is, for the HUD marker. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Guide")
	FVector GetGuideLocation() const;

protected:
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaSeconds) override;
	virtual void EndPlay(const EEndPlayReason::Type Reason) override;

	UFUNCTION()
	void HandleStepChanged(ESquadAITutorialStep NewStep);

	void BeginDemonstration(ESquadAITutorialStep Step);
	void FireDemonstration();
	AActor* ResolveGuidePawn();
	void FaceTowards(const FVector& Target) const;

private:
	UPROPERTY(Transient)
	TObjectPtr<AActor> ResolvedGuide;

	/** S18-VOX: lines waiting their turn so one never cuts another off. */
	struct FGuidePendingLine
	{
		FString Fa;
		FString En;
		TObjectPtr<USoundBase> Voice;
		float Seconds = 4.5f;
	};
	TArray<FGuidePendingLine> LineQueue;
	bool bDuckingActive = false;
	void SetDucking(bool bEnable);

	FString SubtitleFa;
	FString SubtitleEn;
	float SubtitleEndTime = -1.f;
	float SubtitleStartTime = -1.f;

	ESquadAITutorialStep PendingDemoStep = ESquadAITutorialStep::Inactive;
	float DemoFireTime = -1.f;
	FVector DemoTarget = FVector::ZeroVector;
};

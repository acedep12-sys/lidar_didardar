#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "CoverSystem/CoverTypes.h"
#include "TacticalCoverGeneratorActor.generated.h"

class UBoxComponent;

/**
 * ATacticalCoverGeneratorActor
 * Automated Tactical Cover Point Generator.
 * 
 * Drop this volume over any combat area (or across the entire map) and click 'Bake Cover Points'.
 * It automatically raycasts obstacles (rocks, sandbags, walls, trenches), classifies low vs high cover,
 * and generates tactical cover nodes so you never have to place cover points by hand.
 */
UCLASS(BlueprintType, Blueprintable, meta = (DisplayName = "Automated Cover Generator"))
class SQUADAI_API ATacticalCoverGeneratorActor : public AActor
{
	GENERATED_BODY()

public:
	ATacticalCoverGeneratorActor();

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<USceneComponent> SceneRoot;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UBoxComponent> GenerationBounds;

	// =========================================================================
	//  CONFIG
	// =========================================================================

	/** Grid step spacing in cm (default 250cm = 2.5m) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Cover Generation", meta = (ClampMin = "100.0", ClampMax = "1000.0"))
	float GridSpacing = 250.0f;

	/** Minimum obstacle height for low cover (crouch) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Cover Generation")
	float LowCoverHeight = 75.0f;

	/** Minimum obstacle height for high cover (standing) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Cover Generation")
	float HighCoverHeight = 175.0f;

	/** If true, automatically generates and registers cover points at BeginPlay */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Cover Generation")
	bool bGenerateOnBeginPlay = true;

	// =========================================================================
	//  API
	// =========================================================================

	UFUNCTION(BlueprintCallable, Category = "Cover Generation")
	int32 BakeCoverPoints();

	UFUNCTION(BlueprintCallable, Category = "Cover Generation")
	void ClearCoverPoints();

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Cover Generation")
	int32 GetGeneratedCoverCount() const { return GeneratedCoverCount; }

protected:
	virtual void BeginPlay() override;

private:
	// S4-4: baked points fed nothing (ForceScanArea feeds the AI) — keep the count only.
	UPROPERTY()
	int32 GeneratedCoverCount = 0;
};

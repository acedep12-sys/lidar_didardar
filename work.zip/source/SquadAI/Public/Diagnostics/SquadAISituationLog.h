// ==== S19-LOGGER ====
// SquadAISituationLog.h — one line per CHANGE, describing the situation of the pawns
// that matter, instead of thousands of unconditional debug warnings.
//
// WHY
// ---
// A PIE log from this project is ~4,000 lines of which ~95% are per-spawn, per-tick
// debug prints. When something went wrong (a pawn frozen in its death pose, a bullet
// that did not move the health bar, a leader who stopped walking) the state that
// explains it was never in the log at all - only hundreds of lines saying "something
// spawned".
//
// This logger writes ONE structured line per tracked actor per state CHANGE, e.g.
//
//   LogSquadAISituation: P[BP_PlayerCharacter_C_0] hp 100.0/100.0(100%) dead=0 | rag=0
//       blend=0.00 anim=AB paused=0 vis=1 tick=1 hid=0 | grav=1 move=Walking v=0
//   LogSquadAISituation: L[BP_Leader_PackClean_Auto_C] mode=HALT(waited 4.2s) spd=0/720
//       vel=0 playerDist=2310 goalDist=8750 taskDriving=1 dead=0
//
// When nothing changes, nothing is written (a 30 s heartbeat line proves the logger
// is alive). Event lines - damage, death, revive, pacing decisions - are written the
// moment they happen via Note().
//
// HOW TO USE (documented in full in the setup guide)
// ------------------------------------------------
//   SquadAI.SituationLog 1            // on/off (default ON)
//   SquadAI.SituationLog.Period 1.0   // seconds between snapshots
//   SquadAI.SituationLog.Force 1      // log every period, not only on change
//   SquadAI.SituationLog.Dump         // print the full state of every tracked pawn NOW
//   SquadAI.SituationLog.Dump Actor   // ... or of the actors whose name contains "Actor"
//   LogSquadAISituation Off           // category-level mute (UE standard)
//
// Driven from the existing ticking components (player combat bridge + leader tick), so
// it needs no new subsystem and no new UCLASS; two hosts cannot double-log because the
// snapshot throttle is shared.

#pragma once

#include "CoreMinimal.h"
#include "Logging/LogMacros.h"

class AActor;
class UWorld;

/** Everything the situation logger prints, so the whole narrative can be filtered
 *  out of a noisy log with a single category:
 *      -LogCmds="LogSquadAISituation Log, LogTemp Off"      (situation lines only)  */
DECLARE_LOG_CATEGORY_EXTERN(LogSquadAISituation, Log, All);

namespace SquadAISituation
{
	/** Call from any ticking host, every frame. Throttles itself (Period cvar) and
	 *  writes one snapshot line per tracked pawn, but only when something changed. */
	SQUADAI_API void Tick(UWorld* World, float DeltaTime);

	/** One-off event line, printed immediately at Log level, and forces the next
	 *  snapshot so the state around the event is captured even if nothing changes
	 *  afterwards. Keep Msg to a single line. */
	SQUADAI_API void Note(const FString& Msg);

	/** Note(), but only the first time for a given Key (bounded, so a per-tick call
	 *  site cannot flood the log). */
	SQUADAI_API void NoteOnce(const FString& Key, const FString& Msg);

	/** True when the logger is switched on (cvar). Callers can skip building strings. */
	SQUADAI_API bool IsEnabled();

	// ---- state readers (also useful from the debugger / your own debug code) ----

	/** "P[name] hp 100.0/100.0(100%) dead=0 | rag=0 blend=0.00 anim=AB paused=0 ..." -
	 *  health AND pose AND movement in one grep-able line. */
	SQUADAI_API FString DescribeActor(AActor* Actor);

	/** Health half of DescribeActor: native HealthComponent plus every pack
	 *  BPC_Health* component (current/max, dead flags). */
	SQUADAI_API FString DescribeHealth(AActor* Actor);

	/** Pose half of DescribeActor: per skeletal mesh - simulating / physics blend
	 *  weight / animation mode / paused / visible / ticked / hidden. This is the line
	 *  that proves whether a revive really handed the pose back to the AnimBP. */
	SQUADAI_API FString DescribePose(AActor* Actor);

	/** "weapon:<...>" - where the weapon ACTUALLY is, which is the only way to answer
	 *  "the weapon is in the wrong position" without looking at the screen: every actor
	 *  attached to the pawn (name, parent component, ATTACH SOCKET, whether that socket
	 *  exists on the parent mesh, its relative transform), every weapon-ish mesh
	 *  component, the grip sockets that DO exist on the character mesh and their offsets,
	 *  and - for native soldiers - the configured socket name and the two flags that
	 *  decide whether our own attach code runs at all. */
	SQUADAI_API FString DescribeWeapon(AActor* Actor);

	/** Full inventory of an actor: class hierarchy, every component, and for health
	 *  components every reflected numeric/bool property that looks interesting. This is
	 *  the on-demand version of the old one-shot "[SDDBG] PLAYER PROBE" dump. */
	SQUADAI_API void DumpActor(AActor* Actor, const TCHAR* Label);
}

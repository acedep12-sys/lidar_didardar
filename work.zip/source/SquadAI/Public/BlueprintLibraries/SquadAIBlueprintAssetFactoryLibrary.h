#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "SquadAIBlueprintAssetFactoryLibrary.generated.h"

class UBlueprint;
class USquadAIWeaponVisualPreset;

UCLASS()
class SQUADAI_API USquadAIBlueprintAssetFactoryLibrary : public UBlueprintFunctionLibrary
{
    GENERATED_BODY()

public:
    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Asset Factory")
    static UBlueprint* CreateLeaderPackBlueprintAsset(const FString& PackagePath, const FString& AssetName);

    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Asset Factory")
    static UBlueprint* CreateAllyPackBlueprintAsset(const FString& PackagePath, const FString& AssetName);

    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Asset Factory")
    static UBlueprint* CreateEnemyPackBlueprintAsset(const FString& PackagePath, const FString& AssetName);

    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Asset Factory")
    static UBlueprint* DuplicatePackTemplateAsLeaderBlueprintAsset(const FString& TemplateBlueprintAssetName, const FString& PackagePath, const FString& AssetName);

    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Asset Factory")
    static UBlueprint* DuplicatePackTemplateAsAllyBlueprintAsset(const FString& TemplateBlueprintAssetName, const FString& PackagePath, const FString& AssetName);

    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Asset Factory")
    static UBlueprint* DuplicatePackTemplateAsEnemyBlueprintAsset(const FString& TemplateBlueprintAssetName, const FString& PackagePath, const FString& AssetName);

    // Auto-creates a weapon visual preset by searching for TPWCS assets matching the weapon name.
    // Searches for: muzzle flash, bullet trail, firing montage, fire sound, etc.
    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Asset Factory|Weapons")
    static USquadAIWeaponVisualPreset* CreateOrFindWeaponVisualPreset(FName WeaponID, const FString& PackagePath);
};

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "UObject/SoftObjectPath.h"   // S26-VIDEO: FFilePath (the details-panel file picker)
#include "SquadAIAutoSetupEditorLibrary.generated.h"

class AActor;
class UBlueprint;
class UMissionTemplateAsset;   // S19-TEMPLATE
class AMissionZone;             // S19-OP: the director needs the stamped zone, not just the log

UCLASS()
class SQUADAI_API USquadAIAutoSetupEditorLibrary : public UBlueprintFunctionLibrary
{
    GENERATED_BODY()

public:
    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Editor Setup")
    static bool ValidateActorForPackSetup(AActor* Actor);

    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Editor Setup")
    static bool AutoSetupActorForPackInEditor(AActor* Actor, bool bTreatAsLeader = false);

    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Editor Setup")
    static bool AutoSetupLeaderTeamInEditor(AActor* LeaderActor, const TArray<AActor*>& AllyActors);

    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Editor Setup")
    static FString AutoFixAndWireLevelMissions(UWorld* World);

    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Editor Setup")
    static FString EnsureEssentialEnvironmentActors(UWorld* World);

    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Editor Setup")
    static FString AutoPopulateLevelWithEncounterZones(UWorld* World);

    /**
     * S19-TEMPLATE: stamp a COMPLETE mission from a template asset into the level -
     * the mission zone, its wave spawner, an optional fortification and explosive
     * barrels, plus every prop group the template asks for (convoy + its route, intel
     * sites, an extraction pad, supply crates, demolition targets, POW captives), all
     * wired to the zone that was just created. Nothing in the level is modified except
     * the actors this function creates (and the quest chain it appends the zone to).
     * Returns a human-readable report, including the validation notes.
     */
    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Mission Factory")
    static FString BuildMissionFromTemplate(UWorld* World, UMissionTemplateAsset* Template,
        FVector Origin, FRotator Rotation, bool bAppendToQuestChain = true);

    // =========================================================================
    //  S19-MAP: the landscape checker and the automatic mission putter
    // =========================================================================

    /** Actor-name tokens the checker reads as TRENCH markers (crates, trench splines). */
    static TArray<FString> DefaultCrateTokens();
    /** Actor-name tokens the checker reads as TREE/BIOME markers. */
    static TArray<FString> DefaultTreeTokens();
    /** Actor-name tokens the checker reads as the RIVER. */
    static TArray<FString> DefaultRiverTokens();

    /**
     * S19-MAP: read the CURRENT map's layout and log + save a report. Crate clusters
     * are read as trench lines, tree clusters as biomes, and the token-matched actors
     * (or their splines) as the river line. Writes SquadAIReports/LandscapeReport.md
     * next to the project and RETURNS the same text for the log.
     */
    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Landscape")
    static FString AnalyzeLandscapeLayout(UWorld* World,
        const TArray<FString>& CrateTokens,
        const TArray<FString>& TreeTokens,
        const TArray<FString>& RiverTokens);

    /**
     * S19-MAP: the automatic mission putter. Runs the landscape analysis, then stamps
     * a full mission (with the factory) at every spot the scatter plan picks: the HQ
     * defend at the player start, trench assaults on the crate clusters, recon under
     * the trees, one extraction pad on the river, convoys on the open ground - always
     * respecting the minimum separation and the missions that already exist. Writes
     * SquadAIReports/MissionScatterReport.md AND MissionScatterMap.svg (the map of the
     * plan). With bDryRun on, it only reports and draws - nothing is stamped.
     */
    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Landscape")
    static FString AutoScatterMissionsFromLandscape(UWorld* World,
        int32 MissionCount, float MinSeparationCm, bool bDryRun,
        const TArray<FString>& CrateTokens,
        const TArray<FString>& TreeTokens,
        const TArray<FString>& RiverTokens,
        bool bAppendToQuestChain = true,
        double CampaignSpreadKm = 0.0);   // S26-SPREAD: 0 = the whole map; >0 = a tight front around the HQ

    /**
     * S26-DELBTN: tear down everything the auto-scatter stamped on this map -
     * the SAME teardown a re-press performs before restamping, extracted so
     * the manager's "Delete Scattered Content" button runs the identical code
     * path. Tag-based (SquadAIStampedWarWork / SquadAIStampedMission), so a
     * hand-placed tower or mission is never touched; a renamed label never
     * orphans a piece. bAlsoStampedMissions=false keeps the mission zones and
     * removes only the war works and guard posts.
     */
    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Landscape")
    static FString DeleteScatteredContent(UWorld* World, bool bAlsoStampedMissions = true,
        bool bRepressWording = false);

    /**
     * S26-VIDEO: copy any video file on disk to Content/Movies/<DestFileName> - the
     * canonical files the menu HUD auto-plays (MenuBackground.mp4 loops behind the
     * menu, MenuIntro.mp4 plays fullscreen before it). Shared by the auto-setup
     * manager and the main menu director actor.
     */
    static FString InstallMenuVideoFile(const FFilePath& SrcFile,
        const FString& DestFileName, const FString& WhatFor);

    /**
     * S26-VIDEOFIX: the diagnostic. Reports exactly what the menu intro and
     * background will play next time the menu opens - file sizes and dates,
     * image-sequence overrides, cvar states - and WHY an install did or did
     * not take effect. Shows as an editor notification.
     */
    UFUNCTION(BlueprintCallable, Category="SquadAI|Main Menu")
    static FString WhatWillTheMenuVideosPlay();

    /**
     * S19-OP: the same factory, returning the stamped zone (and the report through
     * OutReport when asked). The operation director needs the zone to own - the
     * FString overload above is a thin wrapper over this one.
     */
    static AMissionZone* BuildMissionFromTemplate_GetZone(UWorld* World, UMissionTemplateAsset* Template,
        FVector Origin, FRotator Rotation, bool bAppendToQuestChain, FString* OutReport = nullptr);

    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Editor Setup")
    static FString AutoBakeCoverNodesAcrossMap(UWorld* World);

    UFUNCTION(BlueprintCallable, CallInEditor, Category="SquadAI|Editor Setup")
    static FString AutoSpawnDestroyedVillageInLevel(UWorld* World, FVector Location, int32 BuildingCount = 5);
};

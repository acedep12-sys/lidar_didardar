// SquadAIAlarmSubsystem.h - S19-ALARM
//
// The world's shared alarm channel: one 0..100 value per level with four named
// levels (Calm / Suspicious / Searching / Full alarm), raised by witnessed events,
// decaying back toward calm when nothing happens. The RULES live in
// Tactical/AlarmModel.h (engine-free, harness-pinned); this subsystem only holds
// the state, enforces the per-event cooldowns, applies the decay on a timer, and
// announces level crossings.
//
// WHY THE API IS C++-ONLY: the event and level enums deliberately live in the model
// as plain C++ enums. Reflecting them here (UENUM + UFUNCTION signatures) would put
// a second, UHT-visible spelling of every rule into the tree - the exact drift the
// model headers exist to prevent. Callers are the systems that already speak C++:
// the grenade's detonation, the controllers' perception, and AMissionZone's tick,
// which POLLS GetValue()/GetLevel() every frame instead of binding (a world
// subsystem outlives mission resets; polling cannot leak a binding).

#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "Tactical/AlarmModel.h"
#include "SquadAIAlarmSubsystem.generated.h"

/** Fired only when the NAMED level changes (not on every value tick). */
DECLARE_MULTICAST_DELEGATE_TwoParams(FOnAlarmLevelChangedNative, EAlarmLevel /*NewLevel*/, EAlarmLevel /*OldLevel*/);

UCLASS(BlueprintType)
class SQUADAI_API USquadAIAlarmSubsystem : public UWorldSubsystem
{
	GENERATED_BODY()

public:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

	/** The world's alarm channel, or null outside a game world. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Alarm", meta = (WorldContext = "WorldContextObject"))
	static USquadAIAlarmSubsystem* Get(const UObject* WorldContextObject);

	// -----------------------------------------------------------------------------------------
	//  C++-only API (see the class comment for why these are not UFUNCTIONs)
	// -----------------------------------------------------------------------------------------

	/**
	 * Report one event at a world location. `WitnessRadiusCm` > 0 means the event only
	 * counts when a hostile (a non-ally soldier) is alive inside the radius - an
	 * explosion nobody hears is nobody's business. 0 means unconditional (the senser
	 * IS the witness). Cooldowns per event type are enforced here; an event inside its
	 * cooldown is silently ignored.
	 */
	void RaiseEvent(EMissionAlarmEvent Event, const FVector& Location, float WitnessRadiusCm = 0.f);

	float GetValue() const { return Value; }
	EAlarmLevel GetLevel() const { return FAlarmModel::LevelForValue(Value); }

	/** The level's display name for logs ("Calm", "Suspicious", ...). */
	static const TCHAR* LevelName(EAlarmLevel L);

	/** C++ binders only: level crossings (Suspicious reached, the sweep began, ...). */
	FOnAlarmLevelChangedNative OnAlarmLevelChanged;

	/** Test hook: set the value directly (clamped, level-change broadcast honoured). */
	void DebugSetValue(float NewValue) { SetValue(FAlarmModel::ClampValue(NewValue)); }

private:
	/** The one writer of Value; handles clamping and level-crossing broadcasts. */
	void SetValue(float NewValue);

	float Value = 0.f;
	float LastRaiseSeconds[5] = { -1e9f, -1e9f, -1e9f, -1e9f, -1e9f };   // per EMissionAlarmEvent

	FTimerHandle AlarmTickTimerHandle;

	/** The 0.1 s decay tick. */
	void TickAlarm();
};

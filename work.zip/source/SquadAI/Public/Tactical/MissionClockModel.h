// MissionClockModel.h - S19-CLOCK
//
// The rule behind "the mission has a clock": a hard time limit, a warning
// threshold, and a par time that is recorded rather than enforced.
//
// Why it lives in a model header
// ------------------------------
// The live mission stack (AMissionZone) had no clock at all. `TimeLimitSeconds`
// existed only on the older AQuestMission, and nothing anywhere recorded a par
// time, so Clear and Reach missions could not be timed and no mission could
// report "you beat par".
//
// The rule is small but it has four boundary questions that are easy to get
// subtly wrong and impossible to see in play:
//   * a limit of 0 means NO clock (not "instant failure"),
//   * the limit is reached at Elapsed >= Limit (inclusive - the last frame counts),
//   * the warning must still fire for a caller that ticks past the exact frame,
//     so it is a window (0 < Remaining <= fraction * Limit), not an equality,
//   * finishing exactly on par is BEATING it (inclusive), because that is what
//     a player who is told "par time 6:00" and lands on 6:00 expects.
//
// Engine-free on purpose: compiled and exercised by tools/mission_test (no
// Unreal required), the same way PatrolRouteModel.h is by tools/patrol_test.

#pragma once

#include "CoreMinimal.h"

/**
 * The clock, as pure arithmetic. Every function takes the numbers it needs and
 * returns the answer; nothing here reads an actor, a world or a timer, so the
 * harness can drive any timeline it likes.
 */
struct FMissionClockModel
{
	/** Par verdict: only meaningful when a par time was set at all. */
	enum class EParVerdict : uint8
	{
		NotSet,
		Beaten,   // finished at or under par
		Missed
	};

	/** Clamp a configured warn fraction into a sane window. */
	static float SanitizeWarnFraction(float WarnFraction)
	{
		if (!(WarnFraction > 0.f))
		{
			return 0.25f; // not set / NaN -> the documented default
		}
		return FMath::Clamp(WarnFraction, 0.01f, 1.f);
	}

	/** True when a limit is configured at all. 0 (or negative) = no clock. */
	static bool HasLimit(float LimitSeconds)
	{
		return LimitSeconds > 0.f;
	}

	/** Seconds left on a hard limit. No limit (or already expired) = 0. */
	static float Remaining(float LimitSeconds, float ElapsedSeconds)
	{
		if (!HasLimit(LimitSeconds))
		{
			return 0.f;
		}
		return FMath::Max(0.f, LimitSeconds - FMath::Max(0.f, ElapsedSeconds));
	}

	/** The limit is spent AT the limit - inclusive, so the last frame is the end. */
	static bool IsExpired(float LimitSeconds, float ElapsedSeconds)
	{
		return HasLimit(LimitSeconds) && ElapsedSeconds >= LimitSeconds;
	}

	/**
	 * Inside the warning window: once the remaining time is at or below
	 * fraction x limit, and only while there is still time left. A caller that
	 * missed the exact crossing frame still gets a true here on the next tick,
	 * and the expiry frame itself belongs to the expiry, not to the warning.
	 */
	static bool ShouldWarn(float LimitSeconds, float ElapsedSeconds, float WarnFraction)
	{
		if (!HasLimit(LimitSeconds) || IsExpired(LimitSeconds, ElapsedSeconds))
		{
			return false;
		}
		const float Left = Remaining(LimitSeconds, ElapsedSeconds);
		return Left <= SanitizeWarnFraction(WarnFraction) * LimitSeconds;
	}

	/** Par: not enforced, only compared. Par <= 0 = no par recorded. */
	static EParVerdict EvaluatePar(float ParSeconds, float ElapsedSeconds)
	{
		if (!(ParSeconds > 0.f))
		{
			return EParVerdict::NotSet;
		}
		return (ElapsedSeconds <= ParSeconds) ? EParVerdict::Beaten : EParVerdict::Missed;
	}

	/** mm:ss for logs and the HUD's plain-text paths. Negative input reads 00:00. */
	static FString FormatMMSS(float Seconds)
	{
		const int32 Total = FMath::Max(0, FMath::CeilToInt(Seconds));
		return FString::Printf(TEXT("%02d:%02d"), Total / 60, Total % 60);
	}
};

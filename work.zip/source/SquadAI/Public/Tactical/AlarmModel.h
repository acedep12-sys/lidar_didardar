// AlarmModel.h - S19-ALARM
//
// The rules behind "does the base know". Until now hostility was per-soldier: a man
// who lost sight of the player forgot, and his neighbour two compounds away never
// learned anything. The alarm is the shared channel between them: a value 0..100 on
// the whole level with four named levels, raised by witnessed events, decaying back
// toward calm when nothing happens.
//
//   Calm  0..24      nobody is looking
//        Suspicious  25..54   patrols walk faster and look harder
//        Searching   55..84   the base sweeps for the player
//        Full alarm  85..100  everyone knows, reinforcements think about it
//
// WHY A MODEL HEADER: the raise table, the decay per level, the level thresholds and
// the "ghost" test are exactly the rules a designer will tune for years, and exactly
// the rules that break quietly (a decay that goes negative, an edge that fires twice,
// a stealth run that tripped Full alarm for one frame and still got the bonus). All
// of it is pure functions here, compiled by tools/mission_test; the subsystem is just
// the state holder.
//
// Engine-free on purpose: no UENUM, no UCLASS, no generated include. The subsystem's
// API is C++-only for the same reason - reflected signatures would force a reflected
// copy of these enums, and two spellings of one rule is how the drift starts.

#pragma once

#include "CoreMinimal.h"

/** What happened somewhere. The subsystem maps these to raises with a witness test. */
enum class EMissionAlarmEvent : uint8
{
	GunshotHeard,       // unsuppressed gunfire with a hostile in earshot
	Explosion,          // grenade / barrel / demo charge
	BodyFound,          // a body a patroller walked up to
	EnemySensed,        // a hostile sees the player (cooldown keeps this from spamming)
	SabotageTriggered   // a demolition target just went up mid-base
};

/** The four named levels over the 0..100 value. */
enum class EAlarmLevel : uint8
{
	Calm = 0,
	Suspicious = 1,
	Searching = 2,
	FullAlarm = 3
};

struct FAlarmModel
{
	// -----------------------------------------------------------------------------------------
	//  raises
	// -----------------------------------------------------------------------------------------

	/** How far one witnessed event pushes the value. Tuned so two heard gunfights do
	 *  NOT reach Searching on their own (2 x 18 < 25 ... but a body right after does). */
	static float RaiseAmountFor(EMissionAlarmEvent E)
	{
		switch (E)
		{
		case EMissionAlarmEvent::GunshotHeard:      return 18.f;
		case EMissionAlarmEvent::Explosion:         return 40.f;
		case EMissionAlarmEvent::BodyFound:         return 32.f;
		case EMissionAlarmEvent::EnemySensed:       return 12.f;
		case EMissionAlarmEvent::SabotageTriggered: return 35.f;
		default:                                    return 0.f;
		}
	}

	/**
	 * The minimum seconds between two raises of the SAME event counting. Sensing fires
	 * every perception tick while the player is visible - without a cooldown one glance
	 * is a full alarm in half a second. The subsystem enforces this per event type.
	 */
	static float CooldownSecondsFor(EMissionAlarmEvent E)
	{
		switch (E)
		{
		case EMissionAlarmEvent::GunshotHeard:      return 2.5f;
		case EMissionAlarmEvent::Explosion:         return 4.0f;
		case EMissionAlarmEvent::BodyFound:         return 6.0f;
		case EMissionAlarmEvent::EnemySensed:       return 3.0f;
		case EMissionAlarmEvent::SabotageTriggered: return 8.0f;
		default:                                    return 1.0f;
		}
	}

	// -----------------------------------------------------------------------------------------
	//  value and levels
	// -----------------------------------------------------------------------------------------

	/** 0..100 inclusive, negatives and spikes clamp. */
	static float ClampValue(float V)
	{
		return FMath::Clamp(V, 0.f, 100.f);
	}

	/** The named level for a value: >=85 full, >=55 searching, >=25 suspicious, else calm. */
	static EAlarmLevel LevelForValue(float V)
	{
		if (V >= 85.f) return EAlarmLevel::FullAlarm;
		if (V >= 55.f) return EAlarmLevel::Searching;
		if (V >= 25.f) return EAlarmLevel::Suspicious;
		return EAlarmLevel::Calm;
	}

	/** The value where each level begins (the thresholds, stated as data). */
	static float LevelFloor(EAlarmLevel L)
	{
		switch (L)
		{
		case EAlarmLevel::FullAlarm:  return 85.f;
		case EAlarmLevel::Searching:  return 55.f;
		case EAlarmLevel::Suspicious: return 25.f;
		default:                      return 0.f;
		}
	}

	static EAlarmLevel HigherLevel(EAlarmLevel A, EAlarmLevel B)
	{
		return (static_cast<uint8>(A) >= static_cast<uint8>(B)) ? A : B;
	}

	// -----------------------------------------------------------------------------------------
	//  decay
	// -----------------------------------------------------------------------------------------

	/**
	 * Points per second the value bleeds while nothing happens. Higher levels hold
	 * longer - a base that just went to full alarm does not calm down in ten seconds.
	 */
	static float DecayPerSecond(EAlarmLevel L)
	{
		switch (L)
		{
		case EAlarmLevel::Suspicious: return 2.0f;
		case EAlarmLevel::Searching:  return 1.0f;
		case EAlarmLevel::FullAlarm:  return 0.35f;
		default:                      return 2.0f;  // Calm bleeds too: leftovers from a
		                                              // cooled-down sweep must not sit at 24 forever
		}
	}

	/** Apply one tick of decay: never below zero, never depends on the raise history. */
	static float ApplyDecay(float Value, float DeltaSeconds)
	{
		if (DeltaSeconds <= 0.f)
		{
			return ClampValue(Value);
		}
		const float Rate = DecayPerSecond(LevelForValue(Value));
		return ClampValue(Value - Rate * DeltaSeconds);
	}

	// -----------------------------------------------------------------------------------------
	//  edges - the one-shot moments the HUD and the score care about
	// -----------------------------------------------------------------------------------------

	/** True exactly on the tick the value first reaches or passes `Level` upward. */
	static bool LevelUpCrossed(float OldValue, float NewValue, EAlarmLevel Level)
	{
		return LevelForValue(OldValue) < Level && LevelForValue(NewValue) >= Level;
	}

	/** True exactly on the tick the value first drops below `Level` downward. */
	static bool LevelDownCrossed(float OldValue, float NewValue, EAlarmLevel Level)
	{
		return LevelForValue(OldValue) >= Level && LevelForValue(NewValue) < Level;
	}

	/**
	 * The stealth record: the run stayed quiet enough for the ghost bonus - the value
	 * never crossed into SEARCHING at any point (a moment of suspicion is forgivable;
	 * a base-wide sweep is not). The caller tracks the highest value ever seen.
	 */
	static bool IsGhostPreserved(float HighestValueSeen)
	{
		return LevelForValue(HighestValueSeen) < EAlarmLevel::Searching;
	}
};

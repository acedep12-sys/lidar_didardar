#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "SquadAICommandSubsystem.generated.h"

UENUM(BlueprintType)
enum class ETacticalSquadCommand : uint8
{
	FollowLeader,    // Default: Follow squad leader in staggered formation
	HoldCover,       // Seek nearest cover and hold defensive stance
	SuppressSector,  // Lay down heavy suppressive fire on target area (Base of Fire)
	RegroupOnPlayer, // Break engagement and sprint directly to regroup with player
	Assault          // Aggressive bounding push toward objective / enemy position
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnSquadCommandExecuted, ETacticalSquadCommand, Command, FVector, TargetLocation);

/**
 * USquadAICommandSubsystem
 * Global Tactical Squad Command & Fireteam Authority System.
 * Inspired by Brothers in Arms, Squad, and Mass Effect.
 * Gives players and leaders tactical command over squad behavior in real time.
 */
UCLASS(BlueprintType)
class SQUADAI_API USquadAICommandSubsystem : public UWorldSubsystem
{
	GENERATED_BODY()

public:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Command", meta = (WorldContext = "WorldContextObject"))
	static USquadAICommandSubsystem* Get(const UObject* WorldContextObject);

	/** Issue a tactical order to all ally squad members */
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Command")
	void IssueSquadCommand(ETacticalSquadCommand Command, FVector TargetLocation = FVector::ZeroVector);

	/** Get the current active squad command */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Command")
	ETacticalSquadCommand GetCurrentCommand() const { return CurrentCommand; }

	/** Get human-readable localized command name */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Command")
	FString GetCommandDisplayName(ETacticalSquadCommand Command) const;

	UPROPERTY(BlueprintAssignable, Category = "SquadAI|Command")
	FOnSquadCommandExecuted OnCommandExecuted;

private:
	UPROPERTY()
	ETacticalSquadCommand CurrentCommand = ETacticalSquadCommand::FollowLeader;

	UPROPERTY()
	FVector CurrentCommandTarget = FVector::ZeroVector;
};

#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "SquadAIRadioChatterSubsystem.generated.h"

class USoundBase;

UENUM(BlueprintType)
enum class ETacticalRadioContext : uint8
{
	SpotHostile			UMETA(DisplayName = "Enemy Spotted"),
	SuppressingFire		UMETA(DisplayName = "Suppressing Fire"),
	FlankingManeuver	UMETA(DisplayName = "Flanking Maneuver"),
	TargetNeutralized	UMETA(DisplayName = "Target Neutralized"),
	HeavyMGActive		UMETA(DisplayName = "Heavy MG Mounted"),
	FirstAidApplied		UMETA(DisplayName = "First Aid Applied"),
	MortarInbound		UMETA(DisplayName = "Artillery Inbound"),
	ObjectiveSecured	UMETA(DisplayName = "Objective Secured"),
	StoryBeat		UMETA(DisplayName = "Story Beat")   // S24-STORY: command's voice, from the campaign
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_FourParams(FOnRadioTransmission, const FString&, CallSign, const FString&, MessageFarsi, const FString&, MessageEnglish, ETacticalRadioContext, Context);

/**
 * USquadAIRadioChatterSubsystem
 * Dynamic Military Radio Comms & Tactical Chatter Subsystem.
 * 
 * Provides authentic, high-immersion military radio voice chatter with
 * radio squelch clicks, subtitles, and squad callouts.
 */
UCLASS()
class SQUADAI_API USquadAIRadioChatterSubsystem : public UWorldSubsystem
{
	GENERATED_BODY()

public:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

	static USquadAIRadioChatterSubsystem* Get(const UObject* WorldContextObject);

	// =========================================================================
	//  CONFIG
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Radio Comms")
	bool bEnableRadioChatter = true;

	/** Minimum delay between radio transmissions to avoid chatter spam */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Radio Comms", meta = (ClampMin = "1.0"))
	float MinChatterIntervalSeconds = 3.5f;

	UPROPERTY(BlueprintAssignable, Category = "Radio Comms|Events")
	FOnRadioTransmission OnRadioTransmission;

	// =========================================================================
	//  API
	// =========================================================================

	UFUNCTION(BlueprintCallable, Category = "Radio Comms")
	void BroadcastRadioChatter(const FString& CallSign, ETacticalRadioContext Context);

	/** S24-STORY: a STORY transmission from command - the act opening, the net
	 *  waking, the counterattack. Rare and important: it PREEMPTS the chatter
	 *  interval instead of queueing behind it, and holds the subtitle a beat
	 *  longer. Both languages are stored; the subtitle picks at draw time. */
	UFUNCTION(BlueprintCallable, Category = "Radio Comms")
	void BroadcastStoryTransmission(const FString& MessageEnglish, const FString& MessageFarsi);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Radio Comms")
	FString GetLastRadioMessage() const { return LastMessageFarsi; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Radio Comms")
	FString GetLastRadioMessageForLanguage(bool bEnglish) const { return (bEnglish && !LastMessageEnglish.IsEmpty()) ? LastMessageEnglish : LastMessageFarsi; }

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Radio Comms")
	float GetLastRadioTimeRemaining() const { return MessageDisplayTimeRemaining; }

	void TickRadio(float DeltaTime);

private:
	float LastTransmissionTime = -100.0f;
	float MessageDisplayTimeRemaining = 0.0f;
	FString LastCallSign;
	FString LastMessageFarsi;
	FString LastMessageEnglish;
};

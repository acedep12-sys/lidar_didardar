#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "SquadAIMortarPressureSubsystem.generated.h"

class ATacticalMortarBarrageActor;
class APawn;

/**
 * USquadAIMortarPressureSubsystem
 * Automatic enemy mortar/artillery pressure directed at the PLAYER.
 *
 * Owner request (FR-mortar-pressure): on a repeating cycle, ~10 shells land on the
 * player's position at 0.1s intervals, then a rest window, then repeat — forcing the
 * player to keep moving. The rest window shrinks on higher difficulties (the stated
 * 15s cadence is the EASY setting).
 *
 * Implementation deliberately reuses ATacticalMortarBarrageActor (dispersion, ground
 * snap, FX, radial damage, suppression, AI-hearing stimulus, and the HUD red-zone
 * warning via RegisterIncomingMortarWarning) instead of duplicating explosion code.
 * The player's own fire-support path (USquadAIFireSupportSubsystem) is untouched and
 * keeps its independent cooldown semantics.
 */
UCLASS()
class SQUADAI_API USquadAIMortarPressureSubsystem : public UWorldSubsystem
{
	GENERATED_BODY()

public:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

	static USquadAIMortarPressureSubsystem* Get(const UObject* WorldContextObject);

	// =========================================================================
	//  CONFIG (owner-tunable)
	// =========================================================================

	/** Master switch — the pressure loop stays dormant while false. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mortar Pressure")
	bool bEnabled = true;

	/** Shells per volley (owner spec: around 10). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mortar Pressure", meta = (ClampMin = "1", ClampMax = "12"))
	int32 ShellsPerVolley = 10;

	/** Interval between shells inside a volley (owner spec: 0.1s). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mortar Pressure", meta = (ClampMin = "0.05"))
	float ShellIntervalSeconds = 0.1f;

	/** Warning/travel time before the first shell lands — the player sees the HUD
	 *  red zone for this long and can sprint out. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mortar Pressure", meta = (ClampMin = "0.5"))
	float VolleyInitialDelaySeconds = 2.5f;

	/** Dispersion of impacts around the player's position in cm. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mortar Pressure", meta = (ClampMin = "100.0"))
	float DispersionRadiusCm = 600.0f;

	/** Damage per shell (center / edge falloff is 30% like the stock barrage). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mortar Pressure", meta = (ClampMin = "1.0"))
	float ShellDamage = 160.0f;

	/** Explosion radius per shell in cm. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mortar Pressure", meta = (ClampMin = "100.0"))
	float ExplosionRadiusCm = 650.0f;

	/** Rest time AFTER a volley before the next one — EASY difficulty (owner spec: 15s). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mortar Pressure", meta = (ClampMin = "1.0"))
	float RestSecondsEasy = 15.0f;

	/** Rest scaling per difficulty (higher difficulty = shorter rest, per owner spec). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mortar Pressure", meta = (ClampMin = "1.0"))
	float RestSecondsNormal = 11.0f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mortar Pressure", meta = (ClampMin = "1.0"))
	float RestSecondsHard = 8.0f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mortar Pressure", meta = (ClampMin = "1.0"))
	float RestSecondsLethal = 5.5f;

	/** Grace period after level entry / pawn possession before the first volley. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mortar Pressure", meta = (ClampMin = "0.0"))
	float EntryGraceSeconds = 15.0f;

	// =========================================================================
	//  API
	// =========================================================================

	/** Seconds until the next volley is scheduled (0 while a volley is in flight). */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Mortar Pressure")
	float GetTimeUntilNextVolley() const;

private:
	void EvaluateScheduler();
	void FireVolleyAtPlayer();
	float GetRestSecondsForCurrentDifficulty() const;
	APawn* FindLocalPlayerPawn() const;

	FTimerHandle SchedulerTimerHandle;

	/** Game-time when the next volley may start. Recomputed after every volley. */
	float NextVolleyTimeSeconds = -1.0f;
	/** Game-time when the in-flight volley finishes (0 = no volley in flight). */
	float VolleyBusyUntilSeconds = 0.0f;
	bool bPlayerSeenOnce = false;
	bool bLoggedDormant = false;
};

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "TacticalMortarBarrageActor.generated.h"

class USoundBase;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnMortarBarrageFinished, ATacticalMortarBarrageActor*, BarrageActor);

/**
 * ATacticalMortarBarrageActor
 * Heavy Mortar / Artillery Strike Salvo.
 * 
 * Spawns a salvo of heavy explosive mortar rounds that drop from the sky onto a designated combat zone,
 * obliterating enemy fortifications, suppressing trenches, and clearing hostile encampments.
 */
UCLASS(BlueprintType, Blueprintable, meta = (DisplayName = "Tactical Mortar Barrage"))
class SQUADAI_API ATacticalMortarBarrageActor : public AActor
{
	GENERATED_BODY()

public:
	ATacticalMortarBarrageActor();

	// =========================================================================
	//  CONFIG
	// =========================================================================

	/** Number of mortar shells in this barrage salvo */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mortar Barrage", meta = (ClampMin = "1", ClampMax = "12"))
	int32 ShellCount = 5;

	/** Delay in seconds before the first shell impacts */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mortar Barrage", meta = (ClampMin = "0.5"))
	float InitialDelaySeconds = 2.0f;

	/** Interval in seconds between successive shell impacts */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mortar Barrage", meta = (ClampMin = "0.2"))
	float ShellIntervalSeconds = 0.65f;

	/** Maximum dispersion radius in cm from center for mortar impacts */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mortar Barrage", meta = (ClampMin = "100.0"))
	float DispersionRadius = 450.0f;

	/** Lethal explosion damage per shell */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mortar Barrage", meta = (ClampMin = "50.0"))
	float ShellDamage = 250.0f;

	/** Explosion damage radius in cm */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mortar Barrage", meta = (ClampMin = "200.0"))
	float ExplosionRadius = 750.0f;

	/** S18-BOOM: friendly-fire scale applied to the local player (0 = immune,
	 *  1 = full). The player is damaged through a dedicated path because pack
	 *  Blueprint health does not respond to engine radial damage. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Explosion", meta = (ClampMin = "0.0", ClampMax = "2.0"))
	float PlayerDamageMultiplier = 0.5f;

	/** Whistling incoming shell audio */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mortar Barrage|Audio")
	TObjectPtr<USoundBase> WhistleSound;

	/** Heavy mortar explosion audio */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mortar Barrage|Audio")
	TObjectPtr<USoundBase> DetonationSound;

	UPROPERTY(BlueprintAssignable, Category = "Mortar Barrage|Events")
	FOnMortarBarrageFinished OnMortarBarrageFinished;

	// =========================================================================
	//  API
	// =========================================================================

	UFUNCTION(BlueprintCallable, Category = "Mortar Barrage")
	void StartBarrage(const FVector& TargetLocation);

protected:
	virtual void BeginPlay() override;

private:
	FVector TargetCenter = FVector::ZeroVector;
	int32 ShellsFired = 0;
	FTimerHandle SalvoTimerHandle;

	void DetonateSingleShell();
};

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "TacticalGrenadeActor.generated.h"

class USphereComponent;
class UStaticMeshComponent;
class UProjectileMovementComponent;
class USoundBase;

UENUM(BlueprintType)
enum class EGrenadeType : uint8
{
	Fragmentation UMETA(DisplayName = "Fragmentation"),
	SmokeScreen   UMETA(DisplayName = "Tactical Smoke Screen")
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnGrenadeDetonated, ATacticalGrenadeActor*, Grenade, EGrenadeType, Type);

/**
 * ATacticalGrenadeActor
 * Physics-simulated tactical grenade (Fragmentation or Smoke Screen).
 * Supports bounce physics, fuse timers, radial shrapnel damage, suppression, and AI vision-blocking smoke fields.
 */
UCLASS(BlueprintType, Blueprintable)
class SQUADAI_API ATacticalGrenadeActor : public AActor
{
	GENERATED_BODY()

public:
	ATacticalGrenadeActor();

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<USphereComponent> CollisionComp;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UStaticMeshComponent> GrenadeMesh;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UProjectileMovementComponent> ProjectileMovement;

	// =========================================================================
	//  GRENADE CONFIGURATION
	// =========================================================================

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Type")
	EGrenadeType GrenadeType = EGrenadeType::Fragmentation;

	/** Fuse time in seconds before detonation */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Fuse", meta = (ClampMin = "0.5", ClampMax = "10.0"))
	float FuseTime = 2.5f;

	/** Maximum explosion damage at ground zero (Frag only) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Combat", meta = (EditCondition = "GrenadeType == EGrenadeType::Fragmentation"))
	float ExplosionDamage = 165.0f;

	/** S18-BOOM: friendly-fire scale applied to the local player (0 = immune,
	 *  1 = full). The player is damaged through a dedicated path because pack
	 *  Blueprint health does not respond to engine radial damage. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Explosion", meta = (ClampMin = "0.0", ClampMax = "2.0"))
	float PlayerDamageMultiplier = 0.5f;

	/** Radius in cm of lethal blast damage */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Combat")
	float BlastRadius = 600.0f;

	/** Physics force applied to physics objects and ragdoll bodies */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Combat")
	float ExplosionImpulse = 95000.0f;

	/** Radius in cm across which enemies are heavily suppressed */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Combat")
	float SuppressionRadius = 1100.0f;

	/** Duration in seconds that smoke persists (Smoke only) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Smoke", meta = (EditCondition = "GrenadeType == EGrenadeType::SmokeScreen"))
	float SmokeDuration = 18.0f;

	/** Detonation sound override */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Audio")
	TObjectPtr<USoundBase> DetonationSound;

	/** Bouncing metal clink sound */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Audio")
	TObjectPtr<USoundBase> BounceSound;

	UPROPERTY(BlueprintAssignable, Category = "Grenade|Events")
	FOnGrenadeDetonated OnGrenadeDetonated;

	// =========================================================================
	//  API
	// =========================================================================

	UFUNCTION(BlueprintCallable, Category = "Grenade")
	void LaunchGrenade(const FVector& LaunchVelocity, AActor* InInstigator);

	UFUNCTION(BlueprintCallable, Category = "Grenade")
	void Detonate();

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Grenade")
	bool HasDetonated() const { return bHasDetonated; }

protected:
	virtual void BeginPlay() override;

	UFUNCTION()
	void OnHit(UPrimitiveComponent* HitComponent, AActor* OtherActor,
		UPrimitiveComponent* OtherComp, FVector NormalImpulse, const FHitResult& Hit);

private:
	bool bHasDetonated = false;
	FTimerHandle FuseTimerHandle;
	TWeakObjectPtr<AActor> GrenadeInstigator;

	void ExplodeFrag();
	void DeploySmokeScreen();
};

// SquadAIExplosiveDamage.h — S18-BOOM
// The player pawn is a pack Blueprint whose health lives on a Blueprint
// component (BPC_HealthAI-style), so UGameplayStatics::ApplyRadialDamage* —
// which routes through AActor::TakeDamage — never touched it. Artillery,
// grenades and explosive barrels were therefore completely harmless to the
// player. This library applies explosive damage to the player through the same
// reflection path the player combat bridge uses for pack enemies.
#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "SquadAIExplosiveDamage.generated.h"

UCLASS()
class SQUADAI_API USquadAIExplosiveDamageLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	/**
	 * Damage the local player from an explosion. Mirrors
	 * ApplyRadialDamageWithFalloff: full damage inside InnerRadius, falling off
	 * to MinDamageFraction at OuterRadius.
	 * @return the damage actually applied (0 if out of range / blocked).
	 */
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Damage", meta = (WorldContext = "WorldContextObject"))
	static float ApplyExplosiveDamageToPlayer(
		const UObject* WorldContextObject,
		FVector ImpactLocation,
		float BaseDamage,
		float InnerRadius,
		float OuterRadius,
		float MinDamageFraction = 0.3f,
		float PlayerDamageMultiplier = 0.5f,
		AActor* DamageCauser = nullptr,
		bool bRequireLineOfSight = true);

	/** Raw health write used above; public so other systems can reuse it. */
	UFUNCTION(BlueprintCallable, Category = "SquadAI|Damage")
	static bool ApplyDamageToPlayerPawn(APawn* PlayerPawn, float Damage, AActor* DamageCauser);

	/** True while the player stands inside Radius of Center. For danger-close warnings. */
	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Damage", meta = (WorldContext = "WorldContextObject"))
	static bool IsPlayerWithinBlastRadius(const UObject* WorldContextObject, FVector Center, float Radius);
};

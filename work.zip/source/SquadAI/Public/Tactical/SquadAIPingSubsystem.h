#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "SquadAIPingSubsystem.generated.h"

UENUM(BlueprintType)
enum class ETacticalPingType : uint8
{
	Danger,     // Red warning / danger zone
	Hostile,    // Enemy spotted
	MoveTo,     // Move / advance order
	Defend      // Hold / defensive position
};

USTRUCT(BlueprintType)
struct FTacticalPing
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, Category = "Ping")
	FVector WorldLocation = FVector::ZeroVector;

	UPROPERTY(BlueprintReadWrite, Category = "Ping")
	ETacticalPingType Type = ETacticalPingType::MoveTo;

	UPROPERTY(BlueprintReadWrite, Category = "Ping")
	float TimeRemaining = 8.0f;

	UPROPERTY(BlueprintReadWrite, Category = "Ping")
	float MaxDuration = 8.0f;

	UPROPERTY(BlueprintReadWrite, Category = "Ping")
	TWeakObjectPtr<AActor> Instigator = nullptr;
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnTacticalPingPlaced, FVector, Location, ETacticalPingType, Type);

/**
 * USquadAIPingSubsystem
 * Global Tactical World 3D Pinging & Spotting System inspired by Battlefield, Squad, and Apex.
 * Allows players and squad leaders to mark danger zones, enemy contacts, and move orders.
 */
UCLASS(BlueprintType)
class SQUADAI_API USquadAIPingSubsystem : public UWorldSubsystem
{
	GENERATED_BODY()

public:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Ping", meta = (WorldContext = "WorldContextObject"))
	static USquadAIPingSubsystem* Get(const UObject* WorldContextObject);

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Ping")
	void PlacePing(FVector Location, ETacticalPingType Type, AActor* Instigator = nullptr);

	UFUNCTION(BlueprintCallable, Category = "SquadAI|Ping")
	void ClearAllPings();

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "SquadAI|Ping")
	const TArray<FTacticalPing>& GetActivePings() const { return ActivePings; }

	UPROPERTY(BlueprintAssignable, Category = "SquadAI|Ping")
	FOnTacticalPingPlaced OnPingPlaced;

private:
	UPROPERTY()
	TArray<FTacticalPing> ActivePings;

	FTimerHandle PingTickTimerHandle;

	void TickPings();
};

// SquadAI - S19-GRENARC: the grenade flight model.
//
// Why this is a header and not a .cpp: the trajectory the HUD draws has to be the SAME
// trajectory the grenade actually flies, or the arrow lies and the player stops trusting
// it. Everything numeric about the preview lives here, in one file, following the same
// integration order as UProjectileMovementComponent (gravity is applied to the velocity
// FIRST, then the position is advanced by velocity * dt) and the same bounce response
// (restitution on the normal component, friction on the tangential one).
//
// It is deliberately engine-light and template-based so tools/grenade_test can compile
// THIS header against a stub and check the numbers offline: the test bench feeds it an
// analytic plane instead of a UWorld trace and compares against closed-form solutions.
#pragma once

#include "CoreMinimal.h"
#include "GrenadeFlightModel.generated.h"

/** S19-GRENARC: the numbers that decide where a grenade goes. */
USTRUCT(BlueprintType)
struct FGrenadeFlightParams
{
	GENERATED_BODY()

	/** World gravity * the grenade's ProjectileGravityScale, cm/s^2 (negative). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Flight")
	float GravityZ = -980.f;
	/** UProjectileMovementComponent::Bounciness. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Flight")
	float Bounciness = 0.42f;
	/** UProjectileMovementComponent::Friction. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Flight")
	float Friction = 0.55f;
	/** UProjectileMovementComponent::BounceVelocityStopSimulatingThreshold. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Flight")
	float StopSpeed = 80.f;
	/** UProjectileMovementComponent::MaxSpeed (cm/s). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Flight")
	float MaxSpeed = 2500.f;
	/** ATacticalGrenadeActor::FuseTime - the grenade goes off this long after the throw
	 *  whatever it is touching, so this is what "where it lands" really means. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Flight")
	float FuseTime = 2.5f;
	/** ATacticalGrenadeActor::BlastRadius (cm), for the danger tint on the HUD. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Flight")
	float BlastRadius = 600.f;
	/** False for a smoke grenade: the HUD then skips the threat tinting. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Flight")
	bool bIsFrag = true;
	/** Whether the projectile bounces at all (PMC bShouldBounce). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Flight")
	bool bShouldBounce = true;
	/** Simulation step, seconds. The preview and the test bench use the same one. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Flight")
	float StepTime = 0.02f;
	/** Hard cap on steps so a straight-down trace into the void cannot spin. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Flight")
	int32 MaxSteps = 260;
	/** How many bounces to follow for the faded "roll" tail. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grenade|Flight")
	int32 MaxBounces = 6;
};

/** S19-GRENARC: what the simulation found. */
USTRUCT(BlueprintType)
struct FGrenadeFlightResult
{
	GENERATED_BODY()

	/** A surface was touched before the fuse expired. */
	UPROPERTY(BlueprintReadOnly, Category = "Grenade|Flight")
	bool bHit = false;
	UPROPERTY(BlueprintReadOnly, Category = "Grenade|Flight")
	FVector FirstImpact = FVector::ZeroVector;
	UPROPERTY(BlueprintReadOnly, Category = "Grenade|Flight")
	FVector FirstImpactNormal = FVector::UpVector;
	UPROPERTY(BlueprintReadOnly, Category = "Grenade|Flight")
	float FirstImpactTime = 0.f;
	/** The fuse expired in the air: the grenade never touched anything. */
	UPROPERTY(BlueprintReadOnly, Category = "Grenade|Flight")
	bool bAirburst = false;
	/** The grenade came to rest before the fuse expired (it explodes where it stopped). */
	UPROPERTY(BlueprintReadOnly, Category = "Grenade|Flight")
	bool bRested = false;
	UPROPERTY(BlueprintReadOnly, Category = "Grenade|Flight")
	FVector RestPoint = FVector::ZeroVector;
	UPROPERTY(BlueprintReadOnly, Category = "Grenade|Flight")
	float RestTime = 0.f;
	/** Where it actually goes off - the point the HUD reticle marks. */
	UPROPERTY(BlueprintReadOnly, Category = "Grenade|Flight")
	FVector DetonationPoint = FVector::ZeroVector;
	UPROPERTY(BlueprintReadOnly, Category = "Grenade|Flight")
	float DetonationTime = 0.f;
	UPROPERTY(BlueprintReadOnly, Category = "Grenade|Flight")
	int32 BounceCount = 0;
	UPROPERTY(BlueprintReadOnly, Category = "Grenade|Flight")
	float SimulatedTime = 0.f;
	/** The fuse this run simulated, so callers can report "boom at 2.5 s". */
	UPROPERTY(BlueprintReadOnly, Category = "Grenade|Flight")
	float FuseTime = 0.f;
};

namespace SquadAIGrenadeFlight
{
	/** The bounce response of UProjectileMovementComponent, in one place.
	 *  Normal component: reversed and scaled by Bounciness.
	 *  Tangential component: scaled by (1 - Friction). */
	static inline FVector GrenadeBounceVelocity(const FVector& Velocity, const FVector& ImpactNormal,
		float Bounciness, float Friction)
	{
		const FVector N = ImpactNormal.GetSafeNormal();
		const float Along = FVector::DotProduct(Velocity, N);
		if (Along >= 0.f)
		{
			// Already separating from the surface - nothing to bounce off.
			return Velocity;
		}
		const FVector NormalPart = N * Along;          // points INTO the surface (negative along N)
		const FVector TangentPart = Velocity - NormalPart;

		const float B = FMath::Clamp(Bounciness, 0.f, 1.f);
		const float F = FMath::Clamp(Friction, 0.f, 1.f);

		return TangentPart * (1.f - F) - NormalPart * B;
	}

	/** One integration step, in UProjectileMovementComponent's order. */
	static inline void GrenadeStep(const FGrenadeFlightParams& P, FVector& Position, FVector& Velocity, float DeltaTime)
	{
		Velocity.Z += P.GravityZ * DeltaTime;
		if (P.MaxSpeed > 0.f)
		{
			const float Speed = Velocity.Size();
			if (Speed > P.MaxSpeed)
			{
				Velocity *= (P.MaxSpeed / Speed);
			}
		}
		Position += Velocity * DeltaTime;
	}
}

/**
 * Simulate a throw and report where it goes.
 *
 * OutPath  - samples from the throw origin to the first contact.
 * OutTail  - samples after the first contact, following the bounces until rest or fuse.
 *            Approximate by nature: the engine also has sleep thresholds, rolling and
 *            angular damping that a preview has no business simulating.
 * Trace    - bool(const FVector& From, const FVector& To, FVector& OutPoint,
 *                 FVector& OutNormal, float& OutFraction). Returns false when clear.
 *
 * Returns false only when nothing could be simulated (no steps, zero step time).
 */
template <typename TTrace>
bool SimulateGrenadeFlight(const FGrenadeFlightParams& P, const FVector& Start, const FVector& InitialVelocity,
	TTrace&& Trace, TArray<FVector>& OutPath, TArray<FVector>& OutTail, FGrenadeFlightResult& OutResult)
{
	OutPath.Reset();
	OutTail.Reset();
	OutResult = FGrenadeFlightResult();

	const int32 MaxSteps = FMath::Max(1, P.MaxSteps);
	const float Fuse = FMath::Max(0.f, P.FuseTime);
	// The step count is a safety net, but it must never cut the simulation short of the
	// fuse: a preview that stops early would report a "detonation" at the truncation
	// point (the bench caught exactly that - a fine step of 0.005 s with a 260-step cap
	// ended at 1.3 s of a 2.5 s fuse). So the step is widened if it would not reach.
	const float Dt = FMath::Max(FMath::Clamp(P.StepTime, 0.005f, 0.1f), Fuse / static_cast<float>(MaxSteps));

	FVector Pos = Start;
	FVector Vel = InitialVelocity;
	float Time = 0.f;
	int32 Bounces = 0;
	bool bContacted = false;

	OutPath.Add(Pos);

	for (int32 i = 0; i < MaxSteps; ++i)
	{
		if (Time >= Fuse)
		{
			break;
		}

		const float Step = FMath::Min(Dt, Fuse - Time);
		const FVector Prev = Pos;

		SquadAIGrenadeFlight::GrenadeStep(P, Pos, Vel, Step);
		Time += Step;

		FVector HitPoint = FVector::ZeroVector;
		FVector HitNormal = FVector::UpVector;
		float HitFraction = 0.f;

		if (Trace(Prev, Pos, HitPoint, HitNormal, HitFraction))
		{
			const float Frac = FMath::Clamp(HitFraction, 0.f, 1.f);
			const FVector Contact = Prev + (Pos - Prev) * Frac;
			const float ContactTime = Time - Step + Step * Frac;

			if (!bContacted)
			{
				bContacted = true;
				OutResult.bHit = true;
				OutResult.FirstImpact = Contact;
				OutResult.FirstImpactNormal = HitNormal.GetSafeNormal();
				OutResult.FirstImpactTime = ContactTime;
				OutPath.Add(Contact);
			}

			++Bounces;
			OutResult.BounceCount = Bounces;

			// The engine's rule (UProjectileMovementComponent): bounce first, then decide
			// whether the RESULTING velocity is still worth simulating. Testing the
			// incoming speed instead would let a dead-stop bounce re-hit the ground every
			// few milliseconds and push the reported rest time late (the bench caught
			// exactly that: 1.0555 s instead of the closed-form 1.0102 s).
			const FVector Bounced = P.bShouldBounce
				? SquadAIGrenadeFlight::GrenadeBounceVelocity(Vel, HitNormal, P.Bounciness, P.Friction)
				: FVector::ZeroVector;

			if (Bounced.Size() <= P.StopSpeed || Bounces >= FMath::Max(1, P.MaxBounces))
			{
				// Done bouncing: it sits here until the fuse goes.
				Pos = Contact + HitNormal.GetSafeNormal() * 1.f;
				Vel = FVector::ZeroVector;
				OutResult.bRested = true;
				OutResult.RestPoint = Pos;
				OutResult.RestTime = ContactTime;
				break;
			}

			Vel = Bounced;
			Pos = Contact + HitNormal.GetSafeNormal() * 1.f;   // nudge clear of the surface
			OutTail.Add(Pos);
			continue;
		}

		if (!bContacted)
		{
			OutPath.Add(Pos);
		}
		else
		{
			OutTail.Add(Pos);
		}
	}

	OutResult.SimulatedTime = Time;
	OutResult.FuseTime = Fuse;
	OutResult.bAirburst = !bContacted;
	OutResult.DetonationPoint = Pos;
	// A grenade that came to rest still waits for its fuse: the detonation TIME is the
	// fuse, and only the detonation POINT moves to where it stopped (the bench caught
	// this too - it reported 1.34 s for a grenade that rested at 1.34 s and exploded at
	// 2.5 s).
	OutResult.DetonationTime = OutResult.bRested ? Fuse : Time;

	return true;
}

// SquadAI - S19-ELITE: the commander & commander-assistant brain, as pure functions.
//
// Why this is a separate header and not inside the two pawn classes: every decision that
// matters here (when he calls reinforcements, when the aura lapses, when a single hit is
// capped, when the medic should channel, when the escort is out of position) is arithmetic
// over a handful of numbers. Keeping it engine-free means tools/elite_test can compile the
// REAL file and check it against hand-computed expectations - the same arrangement that
// caught three defects in the grenade flight model before it ever ran in PIE.
//
// The pawns (AEnemyCommander / AEnemyCommanderAssistant) own the state and the ticking;
// this file owns the rules.
#pragma once

#include "CoreMinimal.h"
#include "EliteSquadModel.generated.h"

/** Which elite behaviours are on. Mirrors the commander's Details-panel properties. */
enum class EEliteSquadRole : uint8
{
	Commander,
	Assistant
};

/** Why the commander is calling for help this time (drives the HUD line and the log). */
enum class EEliteReinforcementReason : uint8
{
	None,
	FirstContact,   // the shooting just started and he has not called yet
	GroupThinned,   // his command has been whittled down
	LastStand       // wounded badly enough to be desperate: one last call
};

/** S19-ELITE: every number the elite pair uses, in one place. */
USTRUCT(BlueprintType)
struct FEliteSquadTuning
{
	GENERATED_BODY()

	// ---- stats ----
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float HealthMultiplier = 3.0f;          // commander: 3x a grunt's health
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float AssistantHealthMultiplier = 1.6f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float AccuracyMultiplier = 1.5f;        // commander
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float AssistantAccuracyMultiplier = 1.25f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float DamageMultiplier = 1.35f;         // commander's weapon
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float AssistantDamageMultiplier = 1.15f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float Aggression = 0.85f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float SuppressionThreshold = 0.95f;     // he does not break under fire
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float MaxSingleHitFraction = 0.45f;     // cannot be one-shot (0 = off)

	// ---- command aura ----
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float AuraRadius = 1800.f;              // 18 m: "kill him and they all weaken"
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float AuraResist = 0.25f;               // incoming damage reduction for his men
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float AuraAggressionBonus = 0.25f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float AuraRefreshSeconds = 0.5f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float AuraPersistAfterDeathSeconds = 6.f;   // while an assistant still stands (the relay)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float AuraRelayResistBonus = 0.10f;         // extra resistance while an assistant lives
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float AuraRadiusLastStandScale = 1.4f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float AuraMaxResist = 0.85f;                // never fully immune

	// ---- reinforcements ----
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	int32 MaxReinforcementCalls = 2;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	int32 ReinforcementsPerCall = 5;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float ReinforcementCooldownSeconds = 25.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	int32 ReinforcementGroupThreshold = 3;      // call when this few of his men are left
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float ReinforcementDelayAfterContactSeconds = 6.f;

	// ---- last stand ----
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float LastStandHealthFraction = 0.35f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float LastStandResistBonus = 0.25f;         // added to the aura resist for himself
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float LastStandSeconds = 10.f;

	// ---- assistants ----
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float EnrageSeconds = 12.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float EnrageAggression = 1.0f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float EnrageResistBonus = 0.20f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float MoraleBreakSeconds = 20.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float MoraleBreakAggression = 0.05f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float EscortRadius = 1200.f;                // beyond this he pulls back to the commander
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float HealBelowHealthFraction = 0.55f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float HealRange = 700.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float HealPerSecond = 14.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float HealMaxChannelSeconds = 4.0f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Commander|Tuning")
	float HealCooldownSeconds = 12.f;
};

namespace SquadAIEliteSquad
{
	/** The health an elite spawns with (base = the tier's own DefaultMaxHealth). */
	static inline float EliteMaxHealth(float BaseMaxHealth, float Multiplier)
	{
		return FMath::Max(1.f, BaseMaxHealth * FMath::Max(0.1f, Multiplier));
	}

	/**
	 * S19-ELITE: cap a single damaging hit for an elite. 1000 damage on a 450 HP commander
	 * with a 0.45 fraction becomes 202.5 - a headshot from anything, an artillery shell, a
	 * direct grenade: none of them can delete him between two frames. His health bar has to
	 * fall in front of the player for the fight to read as a fight.
	 * Fraction <= 0 disables the cap (returns the damage unchanged).
	 */
	static inline float ClampSingleHit(float Damage, float MaxHealth, float MaxSingleHitFraction)
	{
		if (Damage <= 0.f || MaxHealth <= 0.f || MaxSingleHitFraction <= 0.f)
		{
			return Damage;
		}
		const float Cap = MaxHealth * FMath::Clamp(MaxSingleHitFraction, 0.f, 1.f);
		return FMath::Min(Damage, FMath::Max(Cap, 1.f));
	}

	/** Incoming-damage reduction granted by the command aura. Assistants carry the relay. */
	static inline float AuraResist(const FEliteSquadTuning& T, bool bAssistantsAlive)
	{
		const float R = T.AuraResist + (bAssistantsAlive ? T.AuraRelayResistBonus : 0.f);
		return FMath::Clamp(R, 0.f, T.AuraMaxResist);
	}

	/** The aura grows while he is cornered - the classic "wounded boss" escalation. */
	static inline float AuraRadius(const FEliteSquadTuning& T, bool bLastStand)
	{
		return T.AuraRadius * (bLastStand ? FMath::Max(1.f, T.AuraRadiusLastStandScale) : 1.f);
	}

	/**
	 * Is the aura still running? It ends with him - unless his assistants are still up, in
	 * which case they hold the command net together for AuraPersistAfterDeathSeconds. That
	 * is the whole reason to shoot the assistants first.
	 */
	static inline bool IsAuraActive(bool bCommanderAlive, float SecondsSinceCommanderDeath,
		bool bAssistantsAlive, const FEliteSquadTuning& T)
	{
		if (bCommanderAlive)
		{
			return true;
		}
		return bAssistantsAlive && SecondsSinceCommanderDeath < T.AuraPersistAfterDeathSeconds;
	}

	/**
	 * Should he call for reinforcements right now?
	 * Precedence: last stand beats a thinned group beats first contact; the cooldown and the
	 * call budget gate all three, and nothing at all happens without a live fight on.
	 */
	static inline EEliteReinforcementReason EvaluateReinforcements(
		const FEliteSquadTuning& T, bool bInCombat, float SecondsSinceCombatStarted,
		int32 AliveCommandSize, int32 CallsUsed, float SecondsSinceLastCall, bool bLastStand)
	{
		if (!bInCombat || CallsUsed >= FMath::Max(0, T.MaxReinforcementCalls))
		{
			return EEliteReinforcementReason::None;
		}
		if (SecondsSinceLastCall < T.ReinforcementCooldownSeconds)
		{
			return EEliteReinforcementReason::None;
		}
		if (bLastStand)
		{
			return EEliteReinforcementReason::LastStand;
		}
		if (AliveCommandSize <= T.ReinforcementGroupThreshold)
		{
			return EEliteReinforcementReason::GroupThinned;
		}
		if (CallsUsed == 0 && SecondsSinceCombatStarted >= T.ReinforcementDelayAfterContactSeconds)
		{
			return EEliteReinforcementReason::FirstContact;
		}
		return EEliteReinforcementReason::None;
	}

	/** One-shot trigger for the last stand (he gets exactly one). */
	static inline bool ShouldBeginLastStand(const FEliteSquadTuning& T, float HealthFraction, bool bAlreadyTriggered)
	{
		return !bAlreadyTriggered && HealthFraction > 0.f && HealthFraction <= T.LastStandHealthFraction;
	}

	/** Damage reduction an elite has against a hit, from aura + state. */
	static inline float TotalResist(const FEliteSquadTuning& T, bool bAuraActive, bool bAssistantsAlive,
		bool bLastStand, bool bEnraged)
	{
		float R = bAuraActive ? AuraResist(T, bAssistantsAlive) : 0.f;
		if (bLastStand)
		{
			R += T.LastStandResistBonus;
		}
		if (bEnraged)
		{
			R += T.EnrageResistBonus;
		}
		return FMath::Clamp(R, 0.f, T.AuraMaxResist);
	}

	// ---- assistant rules -------------------------------------------------------

	/** Should this assistant be walking back to the commander? (hysteresis at 0.75x) */
	static inline bool NeedsEscortReturn(const FEliteSquadTuning& T, float DistanceToCommander)
	{
		return DistanceToCommander > T.EscortRadius;
	}

	static inline bool EscortReturnFinished(const FEliteSquadTuning& T, float DistanceToCommander)
	{
		return DistanceToCommander <= T.EscortRadius * 0.75f;
	}

	/**
	 * Should the medic open a heal channel on the commander right now?
	 * All of these have to hold: the commander is hurt enough, the assistant is close
	 * enough, the cooldown is done, and the commander is still alive.
	 */
	static inline bool ShouldBeginHeal(const FEliteSquadTuning& T, float CommanderHealthFraction,
		float DistanceToCommander, float CooldownRemaining, bool bCommanderAlive)
	{
		if (!bCommanderAlive || CooldownRemaining > 0.f)
		{
			return false;
		}
		if (CommanderHealthFraction <= 0.f || CommanderHealthFraction > T.HealBelowHealthFraction)
		{
			return false;
		}
		return DistanceToCommander <= T.HealRange;
	}

	/** One heal tick: never past max, and never healing a dead man. */
	static inline float HealStep(const FEliteSquadTuning& T, float CurrentHealth, float MaxHealth,
		float DeltaTime, bool bCommanderAlive)
	{
		if (!bCommanderAlive || CurrentHealth <= 0.f || MaxHealth <= 0.f || DeltaTime <= 0.f)
		{
			return CurrentHealth;
		}
		return FMath::Min(MaxHealth, CurrentHealth + T.HealPerSecond * DeltaTime);
	}

	static inline bool HealChannelExpired(const FEliteSquadTuning& T, float ChannelSeconds)
	{
		return ChannelSeconds >= T.HealMaxChannelSeconds;
	}

	/** Their morale state after the commander dies: enraged first, then broken. */
	static inline float AssistantAggression(const FEliteSquadTuning& T, bool bEnraged, bool bBroken, float BaseAggression)
	{
		if (bEnraged)
		{
			return FMath::Max(BaseAggression, T.EnrageAggression);
		}
		if (bBroken)
		{
			return FMath::Min(BaseAggression, T.MoraleBreakAggression);
		}
		return BaseAggression;
	}
}

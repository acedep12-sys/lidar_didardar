// SquadAI - S19-PATROL: the patrolling enemy's route logic, as pure functions.
//
// Why this is a separate header: "which point am I walking to next", "have I waited long
// enough at this one", "did that shape in the grass just see me", "have I chased him far
// enough to give up" are all arithmetic over a handful of numbers. Keeping it engine-free
// is what lets tools/patrol_test/run.sh compile the REAL file and check every rule against
// hand-computed expectations - the arrangement that has now caught defects in three
// separate rounds of this project before they ever reached PIE.
//
// The pawn (AEnemyPatroller) owns the state, the ticking and the navmesh; the route actor
// (AEnemyPatrolRoute) owns the points; this file owns the rules.
#pragma once

#include "CoreMinimal.h"

// The three ways to walk a route are three functions below (AdvanceLoop / AdvancePingPong /
// AdvanceOnce) rather than an enum, on purpose: the reflected patrol-mode enum lives on the
// pawn (a normal reflected header), so THIS file needs no UENUM and no .generated.h include -
// which is what keeps it compilable by the offline harness, where no UHT ever runs.

/** Which point a patroller is on and which way he is walking. */
struct FPatrolCursor
{
	int32 Index = 0;
	int32 Direction = 1;      // +1 forward, -1 backward (used by PingPong)
	bool bFinished = false;   // Only mode Once ever sets this
};

/** Every number the patrol uses. Mirrors the patroller's Details-panel properties. */
struct FPatrolTuning
{
	// ---- movement ----
	// (The arrive radius and the pause at a point are arguments of the functions below, not
	//  fields here: the route actor owns the pause, the patrol pawn owns the radius.)

	// ---- detection: "if they see me or allies in short range, they will attack" ----
	float SpotRange = 2600.f;            // 26 m, line of sight required
	float SpotHearRange = 900.f;         // 9 m: this close he notices you even through cover
	float AlertLingerSeconds = 12.f;     // he stays hot this long after losing sight
	float AlertVisibleRangeScale = 1.6f; // ...but keeps alert while the target is still visible out to 1.6x SpotRange

	// ---- giving up the chase ----
	float RouteLeashRadius = 6000.f;     // 0 = never leave the route; beyond this he walks back
};

namespace SquadAIPatrol
{
	/** A count is valid when there is at least one point to walk to. */
	inline bool HasPoints(int32 Count)
	{
		return Count > 0;
	}

	inline int32 ClampIndex(int32 Index, int32 Count)
	{
		if (Count <= 0)
		{
			return 0;
		}
		return FMath::Clamp(Index, 0, Count - 1);
	}

	/** Where a patroller starts. PreferredIndex is normally the point nearest to him, so a
	 *  placed patroller walks to the closest point of the route first instead of all the way
	 *  across the field. */
	inline FPatrolCursor MakeStartCursor(int32 Count, int32 PreferredIndex, bool bPingPong)
	{
		FPatrolCursor C;
		if (!HasPoints(Count))
		{
			C.Index = 0;
			C.Direction = 1;
			C.bFinished = true;
			return C;
		}

		C.Index = ClampIndex(PreferredIndex, Count);
		C.bFinished = false;

		// Starting on the last point of a ping-pong route means the next step is backwards:
		// without this the first advance would reverse on the spot at the far end.
		C.Direction = (bPingPong && Count > 1 && C.Index == Count - 1) ? -1 : 1;
		return C;
	}

	/** The shared preamble of every step: a route with no points is finished, and a finished
	 *  cursor never moves again. Returns false when the caller should just stop here. */
	inline bool StepPreconditions(const FPatrolCursor& C, int32 Count, FPatrolCursor& Out)
	{
		Out = C;
		if (!HasPoints(Count))
		{
			Out.Index = 0;
			Out.bFinished = true;
			return false;
		}
		return !C.bFinished;
	}

	/** LOOP: 1 -> 2 -> 3 -> 1 -> ... The default patrol. A single-point route keeps him there. */
	inline FPatrolCursor AdvanceLoop(const FPatrolCursor& In, int32 Count)
	{
		FPatrolCursor C;
		if (!StepPreconditions(In, Count, C))
		{
			return C;
		}
		if (Count == 1)
		{
			C.Index = 0;
			return C;
		}
		C.Index = (ClampIndex(C.Index, Count) + 1) % Count;
		return C;
	}

	/** PING-PONG: 1 -> 2 -> 3 -> 2 -> 1 -> ... He turns around at both ends. */
	inline FPatrolCursor AdvancePingPong(const FPatrolCursor& In, int32 Count)
	{
		FPatrolCursor C;
		if (!StepPreconditions(In, Count, C))
		{
			return C;
		}
		if (Count == 1)
		{
			C.Index = 0;
			return C;
		}

		const int32 Index = ClampIndex(C.Index, Count);
		if (C.Direction >= 0)
		{
			if (Index + 1 >= Count)
			{
				C.Direction = -1;
				C.Index = Count - 2;
			}
			else
			{
				C.Index = Index + 1;
			}
		}
		else
		{
			if (Index - 1 < 0)
			{
				C.Direction = 1;
				C.Index = 1;
			}
			else
			{
				C.Index = Index - 1;
			}
		}
		return C;
	}

	/** ONCE: 1 -> 2 -> 3, then he stands on the last point for good (a one-way sweep). */
	inline FPatrolCursor AdvanceOnce(const FPatrolCursor& In, int32 Count)
	{
		FPatrolCursor C;
		if (!StepPreconditions(In, Count, C))
		{
			return C;
		}
		const int32 Index = ClampIndex(C.Index, Count);
		if (Index + 1 >= Count)
		{
			C.Index = Count - 1;
			C.bFinished = true;
		}
		else
		{
			C.Index = Index + 1;
		}
		return C;
	}

	/** The smallest arrive radius that is safe to hand a MoveTo request. Zero would mean
	 *  "stand exactly on the point", which the mover can never satisfy - a patroller with a
	 *  0 radius would stall on his first point forever. 50 cm is under a body width. */
	static constexpr float MinArriveRadius = 50.f;

	/** Is the point reached? The arrive radius is a "close enough" and is floored at
	 *  MinArriveRadius so a 0 in the Details panel cannot brick the patrol. */
	inline bool ArrivedAtPoint(float DistanceToPoint, float ArriveRadius)
	{
		return DistanceToPoint <= FMath::Max(MinArriveRadius, ArriveRadius);
	}

	/** The radius to actually hand to MoveToLocation (same floor). */
	inline float EffectiveArriveRadius(float ArriveRadius)
	{
		return FMath::Max(MinArriveRadius, ArriveRadius);
	}

	/** Count the pause at a point down. Never goes below zero. */
	inline float TickWaitRemaining(float Remaining, float DeltaTime)
	{
		return FMath::Max(0.f, Remaining - FMath::Max(0.f, DeltaTime));
	}

	inline bool WaitFinished(float Remaining)
	{
		return Remaining <= 0.f;
	}

	/** The pause at a point: the point's own override when it has one, else the route default. */
	inline float PointWaitSeconds(float PointOverride, float RouteDefault)
	{
		return (PointOverride >= 0.f) ? PointOverride : FMath::Max(0.f, RouteDefault);
	}

	// ---------------------------------------------------------------------
	//  Detection - "if they see me or allies in short range, they will attack"
	// ---------------------------------------------------------------------

	/** Did the patrol just notice a hostile? Line of sight counts out to SpotRange; this
	 *  close (SpotHearRange) he notices you through cover as well - footsteps, kit rattle. */
	inline bool ShouldSpotTarget(float Distance, bool bHasLineOfSight, const FPatrolTuning& T)
	{
		if (Distance < 0.f)
		{
			return false;
		}
		if (Distance <= FMath::Max(0.f, T.SpotHearRange))
		{
			return true;
		}
		return bHasLineOfSight && Distance <= FMath::Max(0.f, T.SpotRange);
	}

	/** While already alerted: does he stay alerted? He keeps the alert while the target is
	 *  still visible inside the (wider) visible range, and for AlertLingerSeconds after the
	 *  last time he saw anything at all. */
	inline bool ShouldKeepAlert(float DistanceToTarget, bool bTargetVisible, float SecondsSinceSpotted,
		const FPatrolTuning& T)
	{
		if (bTargetVisible && DistanceToTarget <= FMath::Max(0.f, T.SpotRange) * FMath::Max(1.f, T.AlertVisibleRangeScale))
		{
			return true;
		}
		return SecondsSinceSpotted < FMath::Max(0.f, T.AlertLingerSeconds);
	}

	inline float TickSinceSpotted(float SecondsSinceSpotted, float DeltaTime)
	{
		return FMath::Max(0.f, SecondsSinceSpotted) + FMath::Max(0.f, DeltaTime);
	}

	/** Edge detector: true on the frame the patrol goes from calm to alerted (drives the
	 *  one-shot shout to nearby patrols and the single situation-log line). */
	inline bool IsNewlyAlerted(bool bWasAlerted, bool bNowSpottedOrDamaged)
	{
		return !bWasAlerted && bNowSpottedOrDamaged;
	}

	// ---------------------------------------------------------------------
	//  The leash - a patrol that ran after you has to come back
	// ---------------------------------------------------------------------

	/** Has he strayed further from his route than he is allowed to? 0 disables the leash
	 *  (he may chase as far as the fight takes him). */
	inline bool BeyondRouteLeash(float DistanceFromRoute, const FPatrolTuning& T)
	{
		if (T.RouteLeashRadius <= 0.f)
		{
			return false;
		}
		return DistanceFromRoute > T.RouteLeashRadius;
	}

	/** Close enough that the leash pulls him back to the route (hysteresis, so he does not
	 *  oscillate on the boundary). */
	inline bool LeashReturnFinished(float DistanceFromRoute, const FPatrolTuning& T)
	{
		if (T.RouteLeashRadius <= 0.f)
		{
			return true;
		}
		return DistanceFromRoute <= T.RouteLeashRadius * 0.75f;
	}
}

#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "Tactical/TacticalMortarBarrageActor.h"
#include "SquadAIFireSupportSubsystem.generated.h"

/**
 * USquadAIFireSupportSubsystem
 * Tactical Fire Support & Artillery Calling Subsystem.
 * 
 * Provides runtime coordination for calling in mortar strikes, artillery barrages,
 * and airstrikes onto enemy fortified positions.
 */
UCLASS()
class SQUADAI_API USquadAIFireSupportSubsystem : public UWorldSubsystem
{
	GENERATED_BODY()

public:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

	static USquadAIFireSupportSubsystem* Get(const UObject* WorldContextObject);

	// =========================================================================
	//  CONFIG
	// =========================================================================

	/** Cooldown in seconds between artillery call-ins. Default is 0 so artillery can be reused freely. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fire Support", meta = (ClampMin = "0.0"))
	float SupportCooldownSeconds = 0.0f;

	/** If true, every call-in is accepted immediately; no cooldown gate blocks the button. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fire Support")
	bool bUnlimitedArtilleryCalls = true;

	// =========================================================================
	//  API
	// =========================================================================

	UFUNCTION(BlueprintCallable, Category = "Fire Support")
	bool CallMortarStrike(const FVector& TargetLocation, int32 ShellCount = 5);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Fire Support")
	bool IsFireSupportReady() const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Fire Support")
	float GetCooldownRemaining() const;

	// Legacy per-frame ticker (kept for API compatibility). Readiness is timestamp-based,
	// so no external caller is required to tick the cooldown anymore (B7-2).
	void TickCooldown(float DeltaTime);

private:
	float CurrentCooldownTimer = 0.0f;
	// Timestamp of the last successful call-in. Cooldown math is derived from this.
	float LastStrikeTimeSeconds = -100000.f;
};

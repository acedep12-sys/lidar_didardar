# SquadAI HUD & Gameplay Data Integration — Code Changes (`HUD_CODE_CHANGES.md`)

This document records all C++ and asset modifications made across the `SquadAI` Unreal Engine 5.7 project to:
1. Reproduce the exact visual design, 9-slice rounded corners, 3D internal/external bevels, transparency hierarchy, and frosted-glass backdrop blur of `HTML_Reference_Bundle.zip` (`index.html`).
2. Connect every HUD panel and widget—including the **chosen weapon**, the **amount of bullets** (magazine & reserve), the **mission**, health, armor, stamina, squadmates, compass, and minimap—to live gameplay data.
3. **Keep the exact same HUD style after the tutorial ends for the missions too**, changing only the texts inside the panels using the mission titles, objectives, alerts, briefings, and radio chatter from the rest of the codebase.
4. Preserve third-person gameplay camera and Main Menu fonts.

---

## 1. Summary of Modified Source Files

| File Path | Summary of Changes |
| :--- | :--- |
| `source/SquadAI/Public/HUD/QuestNativeHUD.h` | Added `Draw9SliceRoundedBox`, `EnsureHUDBackdropBlur`, `DrawFrostedGlassBackdrop`, `GetActorHealthPercent`, `GetPlayerHealthPercent`, `GetPlayerArmorPercent`, and `GetPlayerStaminaPercent`, plus `HUDBlurRT`, `HUDBlurCapture`, and `HUDBlurMID` properties. Set `bEnableNativeWeaponStatusPlate = true`. |
| `source/SquadAI/Private/HUD/QuestNativeHUD.cpp` | Implemented 9-slice rounded-bevel rendering, 25-tap 2D Gaussian frosted-glass backdrop blur, repositioned `.footer-actions` between `.controls` and `.solo-badge`, connected all HUD panels (including chosen weapon & bullets) to live runtime data, and kept the exact same `index.html` HUD style active after the tutorial ends in Mission Mode with live mission texts from the codebase. |
| `source/SquadAI/Public/GameFramework/SquadAIInventorySubsystem.h` | Added `SelectWeaponByID(FName WeaponID)` to synchronize weapon selection with `USquadAIProgressionSubsystem` (Main Menu Armory) and TPWCS weapon components. |
| `source/SquadAI/Private/GameFramework/SquadAIInventorySubsystem.cpp` | Fixed `[Armory]` localization key mapping in `PopulateDefaultArsenal()` (`G3A3 -> Weapon2`, `AK47 -> Weapon1`, `RPG7 -> Weapon3`, `MG3 -> Weapon4`, `SVD -> Weapon5`, `Knife -> Weapon6`, `Pistol -> custom`), added `SelectWeaponByID`, preserved live clip/reserve ammo across `OnInventoryOpened()`, and updated `EquipSelectedWeapon()` to write `Active Weapon`, `Ammo Clip Current`, and `Ammo Current` to both `ASoldierCharacter::WeaponComp` and TPWCS `BPC_WeaponCharacter`. |
| `source/SquadAI/Private/GameFramework/SquadAIProgressionSubsystem.cpp` | Updated `EquipWeapon(FName WeaponID)` and `LoadProgressionFromDisk()` so selecting a weapon in the Main Menu Armory immediately syncs `USquadAIInventorySubsystem`. |
| `source/SquadAI/Private/Performance/SquadAIPlayerCombatBridge.cpp` | Synced chosen Armory weapon on `BeginPlay()`, wired keys `[1]..[6]` and `[Q]` for live weapon switching, `[R]` for magazine reload, `[G]`/`[H]` for grenade count sync, and per-shot ammo consumption in `PerformCombatTrace()` across `USquadAIInventorySubsystem`, `ASoldierCharacter::WeaponComp`, and TPWCS `BPC_WeaponCharacter`. |
| `source/SquadAI/Private/Actors/AmmoCrateActor.cpp` | Updated `ResupplyPlayer()` so interacting with an Ammo Crate (`[E]`) refills clip ammo, reserve ammo, and grenades in `USquadAIInventorySubsystem` as well as TPWCS weapon components. |
| `source/SquadAI/Private/Quest/MissionZone.cpp` | Updated `ResetPlayerAmmo()` so respawning at a MissionZone refills all weapons and grenades in `USquadAIInventorySubsystem`. |
| `source/SquadAI/Public/Performance/SquadAIAssetCacheSubsystem.h` & `.cpp` | Added `EnsureHUDFrostedBlurMaterial()` to create and cache `/Game/SquadAI/UI/M_HUD_FrostedBlur` (`MSM_Unlit`, `BLEND_Translucent`), sampling `BlurTex` with a 5-tap Gaussian kernel and driving `MP_Opacity` from scalar parameter `Opacity` so `SCS_FinalColorLDR` (`A = 0`) renders visibly. |
| `source/SquadAI/Public/Utilities/SquadAIAssetHelper.h` | Updated `LoadTextureSafe` and `LoadFontSafe` to prioritize loose uncompressed PNGs (`Content/SquadAI/UI/*.png`) and `Content/Fonts/SquadAI_HUD.ttf` on disk over stale `.uasset` binaries, added `GetHUDFontAtSize(int32 PointSize)` for 1:1 crisp font rendering, and replaced deprecated `Font->CompositeFont` with `Font->GetMutableInternalCompositeFont()`. |
| `source/SquadAI/Private/HUD/FarsiTextHelper.cpp` | Fixed Farsi contextual shaping for `ۀ` (`0x06C0`) and `هٔ`, and omitted `0x200C` (ZWNJ) from `ShapeFarsi` output after contextual joining so `UCanvas::DrawText` never renders a vertical line/box inside ZWNJ words. |
| `source/SquadAI/Private/Performance/SquadAIPlayerDiagnosticSubsystem.cpp` & `SquadAIFirstPersonComponent.cpp` | Restored third-person view (`SquadAI.FP.Enable` default set to `0`, removed auto-attachment of `USquadAIFirstPersonComponent`). |
| `source/SquadAI/Private/HUD/SquadAIMainMenuHUD.cpp` & `SquadAIMainMenuSetupActor.cpp` | Reverted Main Menu font changes while retaining `#include "Utilities/SquadAIAssetHelper.h"` and UE 5.7 `GetMutableInternalCompositeFont()`. |

---

## 2. Live Chosen Weapon & Bullet Synchronization

### 2.1 Fixing Weapon Name/ID Swap in `USquadAIInventorySubsystem::PopulateDefaultArsenal()`
- In `SquadAILocalization.ini` (`[Armory]`), `Weapon1` is `AK-47` (`کلاشینکف AK-47`) and `Weapon2` is `G3A3` (`تفنگ ژ۳ G3A3`).
- Previously, `PopulateDefaultArsenal()` constructed `KeyBase = FString::Printf(TEXT("Weapon%d"), Weapons.Num() + 1)` by array index, which caused slot 0 (`G3A3`) to receive `Weapon1_Name` (`AK-47`) and slot 1 (`AK47`) to receive `Weapon2_Name` (`G3A3`).
- `MakeWep` now explicitly binds each `WeaponID` to its exact `[Armory]` key prefix:
  - `G3A3` (`Weapon2`): `تفنگ ژ۳ G3A3` — `20 / 120` rounds (`7.62x51mm NATO`)
  - `AK47` (`Weapon1`): `کلاشینکف AK-47` — `30 / 150` rounds (`7.62x39mm`)
  - `RPG7` (`Weapon3`): `راکت‌انداز RPG-7` — `1 / 6` rockets (`85mm PG-7V`)
  - `MG3` (`Weapon4`): `تیربار گرینوف / MG3` — `100 / 300` rounds (`7.62x51mm`)
  - `SVD` (`Weapon5`): `دراگونوف SVD` — `10 / 40` rounds (`7.62x54mmR`)
  - `Pistol` (custom): `کلت سازمانی / طارق` — `9 / 48` rounds (`9x19mm`)
  - `Knife` (`Weapon6`): `خنجر رزمی / سرنیزه` — melee (`Melee Steel`)

### 2.2 End-to-End Weapon & Bullet Sync
- **Main Menu Armory (`USquadAIProgressionSubsystem::EquipWeapon`)**:
  - Selecting a weapon in the Main Menu Armory or loading a profile from disk calls `Inv->SelectWeaponByID(WeaponID)`, and `USquadAIPlayerCombatBridge::BeginPlay()` equips that weapon on the player pawn as soon as the level starts.
- **In-Game Weapon Switching & Backpack (`[1]..[6]`, `[Q]`, `[I]`/`[TAB]`)**:
  - Pressing `[1]..[6]` or `[Q]` in gameplay, or clicking `<` / `>` / `EQUIP` in the Backpack (`DrawBackpackOverlay`), switches the active weapon in `USquadAIInventorySubsystem`, updates `USquadAIProgressionSubsystem`, and calls `EquipSelectedWeapon(PlayerPawn)`.
- **Live Bullet Consumption, Reload (`[R]`), & Resupply (`[E]`)**:
  - Every shot fired in `USquadAIPlayerCombatBridge::PerformCombatTrace()` decrements `ClipAmmo` (auto-reloading from `ReserveAmmo` at `0`), pressing `[R]` reloads `ClipAmmo` from `ReserveAmmo`, and `EquipSelectedWeapon` writes `Active Weapon`, `Ammo Clip Current`, and `Ammo Current` to both `ASoldierCharacter::WeaponComp` and reflected TPWCS `BPC_WeaponCharacter` properties.
  - Interacting with an `AAmmoCrateActor` (`[E]`) or respawning at an `AMissionZone` (`ResetPlayerAmmo`) refills clip ammo, reserve ammo, and grenades in `USquadAIInventorySubsystem` as well as on the pawn.
- **HUD Weapon & Ammo Plate (`DrawTacticalWeaponStatusPlate` — `.weapons`)**:
  - Enforced `bEnableNativeWeaponStatusPlate = true` in `BeginPlay()` and `DrawHUD()` so Blueprint subclass CDOs cannot hide the weapon plate.
  - Displays the chosen weapon's localized name, 3D silhouette/icon (`T_UI_IconRifle3D.png` for `G3A3`, `T_UI_IconSidearm3D.png` for `Pistol`, and `GetHUDWeaponIcon` for `AK47`, `RPG7`, `MG3`, `SVD`, and `Knife`), fire mode (`خودکار` / `تک‌تیر`), caliber, live magazine bullet count (`ClipAmmo`, turning red when low), live reserve bullet count (`ReserveAmmo`), and live 5-slot loadout strip (`[1]` Primary, `[2]` Sidearm, `[G]` Frag, `[H]` Smoke, `[C]` Stance).

---

## 3. Post-Tutorial Mission Mode (Same HUD Style, Text Change Only)

When the tutorial finishes or is skipped (`!Tut->IsTutorialActive()`), **every single HUD panel from `index.html` remains on screen in the exact same style, geometry, 9-slice rounded bevels, and frosted-glass backdrop blur**, and legacy flat `DrawRect` overlays (`S19-MISSUI` top slab, `DrawMissionBriefingOverlay`, `DrawFallenNoteOverlay`, `DrawMissionAlertBanner`, `DrawRadioChatterSubtitle`, `DrawOnboardingHints`, and `DrawLocationTitleCard`) are routed into the `index.html` panels so only the texts change:

1. **Top-Left Operation Masthead (`.operation-banner` — `DrawOperationBanner`)**:
   - **Tutorial Mode**: `ستاد جنگ‌های نامنظم // آموزش رزم` | `عملیات: خط آتش دهلاویه` | `محور دهلاویه و رودخانه کرخه • آموزش رزمنده`
   - **Mission Mode**: Pulls `MainMenu.Watermark` (`ستاد جنگ‌های نامنظم — سرگرد شهید ایرج رستمی`), `MainMenu.GameTitle` (`دفاع مقدس: خط آتش دهلاویه` or active `AMissionZone::TitleCardPlace`), and `MapSelection.Map1_Title` (`محور دهلاویه و رودخانه کرخه • مرحله X از ۵`), with the bottom progress bar driven by live campaign/mission progress.
2. **Left 5-Stage Sequence Panel (`.tutorial` — `DrawTutorialStepsPanel`)**:
   - **Tutorial Mode**: `روند آموزش` (`TUTORIAL PROGRESS`) with the 5 tutorial steps (`۱..۵`).
   - **Mission Mode**: `روند ماموریت‌ها` (`MISSION SEQUENCE`) | `مرحله X از ۵` (`STAGE X OF 5`) with the 5 Dehlavieh campaign missions from the codebase:
     - `۱`: `پیشروی در محور دهلاویه` (`حرکت با جوخه سرگرد رستمی تا خط اول سنگرهای دهلاویه`)
     - `۲`: `حمله به خط سنگر و پاکسازی` (`انهدام سنگرهای تیربار دشمن و پاکسازی مواضع خط مقدم`)
     - `۳`: `پدافند مقر فرماندهی` (`حفظ خط دفاعی دهلاویه و دفع موج‌های پاتک دشمن`)
     - `۴`: `شناسایی و گشت نخلستان` (`شناسایی مواضع دیده‌بان و جمع‌آوری اطلاعات عملیاتی`)
     - `۵`: `تثبیت معبر رودخانه کرخه` (`پاکسازی کامل محور کرخه و تامین منطقه تخلیه جوخه`)
   - Completed missions display `✓` (`تکمیل شد`), and the active mission row highlights with `StepTileCurrent` and shows live enemy counts (`%s از %s دشمن`) or defend countdown timer (`%s`).
3. **Left-Middle Focus Directive Card (`.focus-instruction` — `DrawFocusInstructionCard`)**:
   - **Tutorial Mode**: `راهنمای گام` (`STEP GUIDE`) + active tutorial beat title & body + `[F] ادامه ›`.
   - **Mission Mode**: `فرمان عملیاتی` (`TACTICAL DIRECTIVE`) + `[I] کوله‌پشتی ›` button (opens Backpack on click), dynamically displaying:
     - Active Mission Briefing / Debrief / Story Card (`ActiveNoteTitle` & `BriefingSections` / `ActiveNoteLines`) when triggered by `AMissionZone::ActivateMission()` or `OnPlayerEntered()`.
     - Active Mission Zone Alert (`هشدار عملیاتی محور` + `AlertBannerText` from the 34 localized alerts in `OnMissionZoneAlertReceived`).
     - Active Radio Chatter (`بی‌سیم // ` + `LastCallSign` + `LastMessageFarsi` / `LastMessageEnglish` from `USquadAIRadioChatterSubsystem`).
     - Active Mission Stage directive & live Squad Order (`فرمان جوخه: ...` from `USquadAICommandSubsystem`).
4. **Right-Middle Mission Objective Card (`.mission` — `DrawMissionObjectiveCard`)**:
   - Remains visible throughout both Tutorial Mode and Mission Mode.
   - In Mission Mode, displays `هدف ماموریت` (`MISSION OBJECTIVE`), `مرحله X از ۵`, mission type badge (`پیشروی` / `پاکسازی` / `پدافند` from `HUD.BadgeAdvance` / `BadgeClear` / `BadgeDefend`), live mission title & description, live enemy counter (`پاکسازی دشمن: %s از %s`) or defend timer (`پدافند و پایداری: %s`), live distance in meters, and live progress bar.
5. **Right-Lower Progress Mini-Card (`.training-panel` — `DrawTrainingProgressPanel`)**:
   - **Tutorial Mode**: `پیشرفت آموزش` (`TRAINING PROGRESS`) with the 3 tutorial sub-steps.
   - **Mission Mode**: `پیشرفت ماموریت` (`MISSION PROGRESS`) with 3 live mission sub-objectives (`۱` پیشروی و ورود به موضع عملیاتی, `۲` پاکسازی نیروهای دشمن / پدافند و حفظ خط, `۳` تثبیت موضع با جوخه / انهدام اهداف / جمع‌آوری اطلاعات / آزادسازی اسرا), highlighting the active sub-objective with `StepTileCurrent` and `اکنون` (`NOW`).
6. **Bottom-Center Action Keycap Banner (`.movehint` — `DrawMoveHintBanner`)**:
   - In Mission Mode, dynamically displays the live contextual keycap & prompt from `SquadAILocalizationSubsystem`:
     - `[E]` `احیای همرزم مجروح در میدان` (when a downed ally is nearby)
     - `[E]` `برداشتن مهمات و تجدید خشاب` (when an `AAmmoCrateActor` is nearby)
     - `[E]` `استقرار پشت تیربار سنگین دوشکا` (when an `AMountedTurretActor` is nearby)
     - `[F]` `استفاده از بسته کمک‌های اولیه` (when player health `< 55%`)
     - `[R]` `تعویض خشاب سلاح سازمانی` (when magazine ammo is low)
     - `[RMB]` `سنگرگیری و اجرای آتش روی دشمن` (when enemies are active in the mission zone)
     - `[V]` `پیشروی تاکتیکی به موضع ماموریت` (default navigation prompt)
7. **Bottom-Left Status & Action Strips (`DrawSquadStatusPanel`)**:
   - `.footer-actions` (positioned between `.controls` and `.solo-badge`) switches from `[TAB] هدف‌ها | [?] راهنما | [ESC] رد کردن آموزش` during the tutorial to `[TAB] کوله‌پشتی | [V] مسیرنما | [ESC] توقف عملیات` during missions.
   - `.solo-badge` switches from `شما / آموزش انفرادی` during the tutorial to `شما / نبرد با جوخه` during missions.
8. **3D World Waypoint (`.waypoint`) & Ally Marker (`.ally`)**:
   - In Mission Mode, `.waypoint` tracks the active `AMissionZone` world location with the mission title and live distance in meters, and `.ally` tracks `FindCachedLeader()` (`◆ فرمانده · سرگرد رستمی`) with live distance in meters.

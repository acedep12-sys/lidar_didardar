# HANDOFF: Recreate the reference UI (2 screenshots) in SquadAI's HUD/tutorial layer

You are an AI **with vision** taking over a focused task. The previous agent (no vision) has
prepared everything else: the codebase, the text pipeline, texture loaders, the layout
verification harness, and this brief. Your job: **look at two screenshots and make the game's
UI look exactly like them.**

---

## 1. Mission

Two reference screenshots were provided by the user:

| File | What it is |
|---|---|
| `docs/REFUI_left.png` (also `/home/user/uploads/12234.png`, 1281×1024) | **LEFT side** of the reference screen |
| `docs/REFUI_right.png` (also `/home/user/uploads/123.png`, 1311×1024) | **RIGHT side** of the reference screen |

The user's instruction, verbatim: *"create the exact same ui in the images."*

Project root: `/home/user/project`. Screenshots live at `/home/user/uploads/`.

**Your deliverable:** restyle the game HUD / tutorial layer in
`source/SquadAI/Private/HUD/QuestNativeHUD.cpp` (+ its header, + the Python layout mirror,
+ optionally new texture assets) so the in-game UI reproduces the reference: panel shapes,
borders, colors, typography, text proportions, and depth/3D treatment.

### Why (the user's complaints about the CURRENT UI — these are the acceptance criteria)

1. **Proportion of text to its box is wrong** — text must fill its containers properly.
2. **Font size** wrong. **Font style** wrong.
3. **Text color** wrong; there was **white text on a yellow/gold background that could not be
   read** — that specific contrast failure must never reappear.
4. **The text has no 3D effect** — the user wants bevelled/extruded type (the helper
   `DrawFarsiText3D` already exists — see §5).
5. **The yellow/brass UI color is bad.**
6. **"everything should look 3d"** — and the user explicitly allows generated images:
   *"if its hard to do that by code, create images using third parties in here and bring that
   instead for the border or texture or the backgrounds or whatever"* — i.e. you may generate
   texture/border/background art and load it as PNGs (see §7).

Whatever colors/typography the screenshots actually show **override** all of that: the
screenshots are the spec. Extract their exact values.

---

## 2. What we already know about the screenshots (machine-extracted — VERIFY with your eyes)

A no-vision agent ran edge/saturation analysis. Treat these as hints, not facts:

**12234.png (left half):**
- Strong vertical panel edges at **x≈28 and x≈486–487** (one more at x≈533).
- Dense regular horizontal edge rows from **y≈28 down to y≈520** (candidates: y=118, 163,
  179, 220, 284, 350, 394–403, 457–468, 477–518) — spacing suggests **text rows ~40–60 px**.
- Top-right of the image is very bright (near-white haze); lower 2/3 is brown/earth-toned.
- Saturated colors are mostly earth/orange-browns (96,48,48)/(144,96,48) — possibly period
  content or orange UI accents.

**123.png (right half):**
- A **dark vertical sidebar at x=0–130** (~#292929).
- A **large light grey/blue-grey gradient panel** from x≈130 to x≈680, y≈0–290
  (top rows ~d2d5d9 → bottom ~b0c1ce: grey fading into blue). Long horizontal edges at
  y≈72, 269, 311–318, 385–388, 426–431.
- A cluster of dense vertical edges x≈308–421 (text block?).
- Strong **orange accents** (#a85923, #955122, #824a22) bottom-left, y≈950–1024, x≈0–100.
- Lower 2/3 is brown/earth-toned (scene content).

The two images may be halves of ONE ~2560×1024 screen (check horizon continuity) or two
different shots. **Determine this yourself.** Also determine whether the reference is:
(a) an in-game HUD over a 3D scene, (b) a full-screen menu/map/briefing UI, or (c) a mix —
and which parts are UI chrome vs. game world. Map every UI element you identify to a
bounding box + measured colors + typography before writing any code. **Write that spec into
a file (`docs/REFUI_SPEC.md`) as your first step** — the user may want to review it.

---

## 3. Critical user constraints (standing rules — never break these)

- **Period-correct 1980s Iran–Iraq war.** Any generated art: olive-khaki fatigues, M1 steel
  helmets, G3 rifles with wooden furniture + iron sights, **bare hands (never gloves)**,
  backpack radios. **No** body armor, optics, rails, or modern tactical gear.
- **In-game text is Farsi** (with English variants behind a language flag). Replies to the
  user are **English only**.
- **Keyboard/mouse only** — button prompts are keycaps (W/A/S/D, SPACE, RMB/LMB/MMB), never
  gamepad glyphs.
- **One campaign, one map. WP-safe.** No engine source edits, ever.
- **Never modify the test harnesses to make them pass.** Harnesses never compile engine cpp.
- The user reviews **PNG mocks by eye** (they cannot run the engine from chat). Always
  finish by rendering review mocks with PIL (raqm is available for proper Farsi shaping).

---

## 4. The HUD code you will edit

Everything is **immediate-mode Canvas drawing** — no UMG, no widgets, no Slate. One class
draws the whole HUD every frame:

```
source/SquadAI/Public/HUD/QuestNativeHUD.h      (class, palette, declarations)
source/SquadAI/Private/HUD/QuestNativeHUD.cpp   (~7100 lines — all draw code)
```

Tutorial-specific flow inside `QuestNativeHUD.cpp` (search these names):

| Function | Role |
|---|---|
| `DrawTutorialOverlay(ScreenW, ScreenH, DeltaTime, Font)` | Entry point; measures everything BEFORE drawing, then draws |
| `ComputeTutorialRailMetrics / ComputeTutorialRail` | One rail: width + center line for all tutorial chrome (cvar-tunable, clamped between the top-corner HUD blocks) |
| `ComputeTutorialStack(...)` | Bottom-up stack: radio box slot (reserved) → banner → help line → guide subtitle → onboarding card. **Every element's top derives from the one below — nothing may overlap** |
| `MeasureGuideSubtitleBlock(Font, bEnglish)` | Mirrors `DrawGuideSubtitle`'s geometry EXACTLY. **Invariant: measure == draw** |
| `DrawTutorialPlate(X, Y, W, H, Alpha, S, bBrackets)` | The one plate helper every tutorial panel uses (gradient body + steel texture + bevel + gold top rule + inner hairline + optional corner brackets) |
| `DrawTutorialHeaderStrip(...)` | Top strip: pip track (diamonds, current has pulsing ring), step counter, title, skip button |
| `DrawGuideSubtitle(...)` | Bottom band: guide portrait (T_Tut_Guide.png) + speaker name + radio waveform + subtitle lines |
| `DrawButton` (lambda inside `DrawTutorialOverlay`) | Shared chiseled button (first-run prompt + "Begin") |
| `DrawProgressBar` (lambda) | Segmented progress bar (hands-on beats) |
| `GetTutorialIllustration(Key)` / `GetUITexture(Key)` | Cached texture loads — see §7 |

Primitives available (engine AHUD methods + project helpers — all already used, copy the
existing call style):

```cpp
// engine (AQuestNativeHUD : AHUD)
DrawRect(FLinearColor Color, float X, float Y, float W, float H);
DrawLine(float X1, float Y1, float X2, float Y2, FLinearColor Color, float Thickness = 1.f);
DrawTexture(UTexture* Tex, float X, float Y, float W, float H,
           float U, float V, float UL, float VL, const FLinearColor& Tint);
// NOTE: DrawTile cannot rotate. Keep 0/1 UVs for full-image stretches.

// project text pipeline (Farsi shaping handled inside — ALWAYS use these, never raw DrawText)
void DrawFarsiTextBounded(const FString& Text, const FLinearColor& Color, float X, float Y,
    float MaxWidth, UFont* Font = nullptr, float PreferredScale = 1.0f,
    bool bDropShadow = true, bool bCenterHorizontal = false, float BoxHeight = 0.0f,
    bool bRightAlign = false);                       // auto-shrinks to fit MaxWidth
void DrawFarsiText3D(const FString& Text, const FLinearColor& Color, float X, float Y,
    float MaxWidth, UFont* Font, float PreferredScale, bool bCenterHorizontal,
    bool bRightAlign, float BoxHeight, float Depth); // 3-pass bevel: highlight up-left,
                                                     // dark extrude down-right, ink between
void GetFarsiTextSize(const FString& Text, UFont* Font, float Scale, float& OutW, float& OutH) const;
FTutorialTextBlock WrapTutorialText(const FString& Text, UFont* Font, float Scale,
    float MaxWidth, int32 MaxLines) const;           // greedy wrap; BlockH = LineH*1.18*Lines
float DrawTutorialTextBlock(const FTutorialTextBlock& Block, const FLinearColor& Color,
    float X, float Y, float MaxWidth, UFont* Font, float Scale, bool bCentre);
                                                    // Farsi paragraphs flush right (bRTLFlush)

// chrome helpers
void DrawTacticalPlate3D(X, Y, W, H, BodyTop, BodyBottom, Accent, Alpha, Chamfer, Bevel, Shadow);
void DrawChiseledTacticalBox(X, Y, W, H, FillColor, BorderColor, Thickness, Chamfer);
void DrawCornerBrackets(X, Y, W, H, Color, Len, Thickness);
float DrawKeycapGlyph(X, Y, H, Label, Font, Tint, bHeld);   // held = gold face + DARK ink
float MeasureKeycapGlyphW(Label, H);
void DrawKeycapGlyphRow(X, Y, H, Hint, Font, Tint, MaxWidth);
```

Color truth lives in `FSquadAIHUDPalette` (QuestNativeHUD.h). Current values (post
S26-TUT3D): `BracketGold (0.83,0.64,0.30)`, `GoldText (0.94,0.79,0.48)`, `TextWhite
(0.98,0.972,0.94)` warm ivory, `TextDim (0.79,0.80,0.80)`, `Success`, `SuccessText`, `Warm`,
`Muted`, `PanelTop/PanelBottom/PanelEdge`, `WithAlpha(In, A)`. **Change the palette, not
individual call sites** — that rule keeps the layer coherent.

Current type scale (measure+draw pairs, all `* GameUIScale`): card title 1.42, card body
0.98, subtitle 1.00, speaker 0.86, eyebrow/caption 0.74/0.70, keycap label 0.52·H, BtnH 48,
CardPad 20, EyebrowH 24, line spacing 1.18. **If the screenshots say otherwise, change both
the measure and the draw — never one alone.**

Other HUD layers the screenshots may correspond to (same file): objective card
(`DrawMissionObjectiveCard`, top-left), weapon plate (`DrawTacticalWeaponStatusPlate`,
top-right), squad panel (bottom-left), compass, radio chatter box (bottom-center reserved
slot SH−120..SH−72), mission notices lane (top-center), onboarding card. If the reference
shows those elements, restyle their draw functions the same way.

Menu HUD (different screen, only if the screenshots are a MENU): 
`source/SquadAI/Private/HUD/SquadAIMainMenuHUD.cpp` — loads every texture via
`FSquadAIAssetHelper::LoadTextureSafe(TEXT("/Game/Textures/UI_X.UI_X"),
TEXT("Textures/UI_X.png"))` so loose PNGs in `Content/Textures/` work with zero code edits.

---

## 5. Font pipeline — the one trap that silently breaks everything

- The HUD font is **`Content/Fonts/SquadAI_HUD.ttf`** (currently **Amiri Bold**), loaded via
  `LoadFontSafe("/Game/Fonts/SquadAI_HUD")` with WITH_EDITOR auto-import.
- Farsi is shaped by `UFarsiTextHelper::ShapeAndOrder()` into **Unicode presentation forms**
  (U+FB50–FDFF / U+FE70–FEFF) and re-ordered, because Canvas does no OpenType shaping.
  **Any font you swap in MUST contain those presentation-form codepoints (plus Latin A–Z
  for keycaps and Persian digits).** Verify with fontTools before shipping:

  ```bash
  python3 - <<'EOF'
  from fontTools.ttLib import TTFont
  cmap = TTFont("Content/Fonts/SquadAI_HUD.ttf").getBestCmap()
  pf = [c for c in cmap if 0xFB50 <= c <= 0xFDFF or 0xFE70 <= c <= 0xFEFF]
  latin = [c for c in range(0x41, 0x5B) if c in cmap]
  print(len(pf), "presentation forms;", len(latin), "/26 Latin")
  EOF
  ```

  Known-good: Amiri (751 PF, full Latin). **Lalezar was tested and REJECTED** — 85 missing
  Persian presentation forms (گ/چ/ج families) → tofu boxes in-game. If the reference font is
  something else, find a TTF that passes the check above, then recalibrate `CH` in
  `tools/hud_layout_check.py` (see §8) by measuring average advance widths of the real
  strings (PIL + `direction="rtl"`) old-vs-new font, ratio × CH.
- ASCII digits render fine in-game (all counters print `%d`).

---

## 6. Layout invariants (the part that keeps the tests green)

1. **Measure == draw.** Every text block is measured (`WrapTutorialText`/`GetFarsiTextSize`)
   before drawing; heights feed the card/stack geometry. If you change a scale, a font, a
   padding, or a formula, change it in BOTH the measure path and the draw path.
2. **The bottom stack is built bottom-up from the reserved radio slot** — banner pinned
   first, then help, then subtitle band, then card clamped between header and stack top.
   Nothing may overlap; `tools/hud_layout_check.py` verifies 70 resolution/state
   combinations × 5,068 rect pairs.
3. **Python mirror:** `tools/hud_layout_check.py` re-implements the geometry (functions
   `layout()`, `site_widths()`, `fit_report()`; constant `CH = 13.5`). It extracts the REAL
   shipped strings from source and checks they fit their line budgets at 7 resolutions.
   When you change engine geometry you MUST update the mirror in the same commit: the card
   height formula (cardpad/eyebrow/titleb/bodyb/btnh/rulegap), the subtitle band formula
   (two-pass, avatar column `avw = max(46*S, band0 - pad)`, text re-wraps narrower), help
   scale, and the `site_widths()` tuples (title/body/sub/name/help scales).
4. Known mirror anchors (line numbers drift — search by value):
   `titleb = block_h(1.42 * S, ...)`, `bodyb = block_h(0.98 * S, ...)`,
   `btnh, rulegap, footrow = 48 * S, 16 * S, 24 * S`, `eyebrow = 24 * S + 8 * S`,
   `CH = 13.5`.

---

## 7. Textures & assets

- **Loose-PNG loading is the pattern**: `FSquadAIAssetHelper::LoadTextureSafe(PackagePath,
  RelativePngPath)` — tries the imported `/Game/...` asset first, then the loose PNG under
  `Content/`. Shipping a texture = dropping a PNG in the folder. No editor import step.
- Existing generated surfaces (loaded via `GetUITexture(FName)` → 
  `Content/SquadAI/UI/T_UI_Steel.png`, `Content/SquadAI/UI/T_UI_Brass.png`, drawn with
  `DrawTexture(Tex, X, Y, W, H, 0,0,1,1, tint)`). Tone-map any new generated surface into
  the palette before shipping (PIL: brightness to target mean, desaturate ~0.7–0.85, blur
  20–25% to kill AI hot pixels).
- Tutorial illustrations: `Content/SquadAI/UI/Tutorial/T_Tut_*.png` (Welcome, Move, Shoot,
  Grenade, Artillery, Squad, Guide portrait).
- The HUD font: §5. The menu font is the same file.
- **If the reference UI has ornate borders/frames**: variable-size panels stretch textures,
  so generate *surfaces* (low-frequency, tileable) and keep *geometry* (bevels, corner
  brackets, frames) in code; or generate fixed-size assets for fixed-size elements only.
- Any generated character art must obey §3 period rules (embed them in the image prompt).

---

## 8. Verification suite (all must be green before you report done)

Run from `/home/user/project`:

```bash
python3 tools/squadai_lint.py source            # expect: errors: 0, warnings: 15
python3 tools/hud_layout_check.py               # expect: 70 states, 5068 rect-pairs, 0 overlaps
                                                #        + 469 strings fit, no key-hint overflow
for d in elite grenade grip loading map mission patrol tutorial; do
  bash tools/${d}_test/run.sh | tail -1         # expect: 50/26/38/44/155/271/85/39 passed, 0 failed (708 total)
done
python3 tools/preflight_audit.py source         # expect: 315 files, 0 errors
python3 tools/build_single_file.py              # rebuilds SQUADAI_COMPLETE.md (the shippable pack)
python3 tools/check_pack.py                     # expect: all checks passed
```

**Baselines if you change nothing:** pack ≈ 3,214,733 B / ~71,344 lines / 484 blocks / 116
files. After your edits the pack grows — that's expected; check_pack must still pass.

Add a glossary entry for your change in `tools/build_single_file.py` (dict near the top,
key like `"S27-REFUI": "..."`, one-paragraph as-built description) — then rebuild the pack.

---

## 9. Edit conventions (the codebase's house style)

- **TABS for indentation** in all C++ files. Python files use 4 spaces.
- Edit via scripted exact-string replacement (python `assert s.count(old) == 1` then
  `s.replace`) — anchors must be unique; make each edit script atomic (write file only after
  all asserts pass).
- The linter checks brace/paren balance — a botched multi-line replace shows up as
  `unclosed '{' at end of file`. Fix immediately.
- Comments in code are part of the culture: tag your changes like the existing
  `// S26-TUT3D: ...` markers and explain WHY, tersely.
- Do not rename existing functions; other call sites and the pack depend on them.

---

## 10. Suggested workflow

1. **Look** at both screenshots properly. Decide: one screen split in two, or two screens?
   UI vs. world content. Write `docs/REFUI_SPEC.md`: every panel (bbox, fill, border,
   corner treatment, shadow/bevel), every text style (size relative to its box, weight,
   color, alignment, 3D treatment), spacing rhythm, and the exact color palette as RGB.
2. **Map** each spec element to code: which existing draw function owns it (§4) — or needs
   to be added.
3. **Decide the palette**: update `FSquadAIHUDPalette` once, globally. No lemon yellow, no
   white-on-gold (if the reference uses gold plates, its text on them is dark).
4. **Restyle** panel-by-panel: geometry → typography → chrome → textures. Keep
   measure==draw for every text site. Use `DrawFarsiText3D` for display type if the
   reference text has depth; tune `Depth`.
5. **Sync the mirror** (`tools/hud_layout_check.py`) for every geometry/scale change; if you
   swap the font, recalibrate `CH`.
6. **Generate + tone-map textures** if the reference has material surfaces (§7). Keep them
  low-frequency.
7. **Run the full suite** (§8). Iterate until green.
8. **Render PIL mocks** of your new UI at 1920×1080 (both the paused lesson card view and
   the hands-on banner view) using the real geometry, real strings, and the real font —
   the user judges by these mocks. PIL raqm is available:
   `dr.text(xy, txt, font=f, fill=col, anchor=..., direction="rtl")`.
9. **Rebuild the pack** + check_pack, add the glossary entry.
10. **Report in English**, terse numbered list: what changed, file paths, suite numbers,
    and the mock PNGs. Offer per-element retunes.

## 11. Do NOT

- Do not edit anything under `tools/*_test/` or weaken a check to pass.
- Do not touch engine files, other subsystems (AI, missions, terrain), or the pack format.
- Do not use a font that fails the presentation-forms check (§5) — it renders tofu in-game.
- Do not draw text with raw `Canvas->DrawText` — always the Farsi pipeline (§4).
- Do not load textures per-frame — only through the caches (`GetUITexture`,
  `GetTutorialIllustration`), and never `LoadObject` in a draw path.
- Do not ship a white/near-white label on any gold/yellow/brass fill.
- Do not add gamepad glyphs; no modern tactical gear in any generated art.

## 12. Current state (what the previous agent shipped — your starting point)

- Font: **Amiri Bold** (Naskh display, presentation-forms complete).
- Palette: brass gold + warm ivory text + steel-blue panels (user dislikes the current
  brass — the screenshots decide the final colors).
- Tutorial card: eyebrow chip (right edge) → 1.42-scale 3D title → 0.98 body, art column
  with caption strip + brackets, footer with brass action button (dark ink, keycap inside,
  RTL chevrons), segmented progress bar, pip track header, guide subtitle band with
  portrait + waveform. Right-flush Farsi paragraphs, 1.18 line spacing, tight text shadow
  (1.6 px / 60%).
- Steel + brass generated surfaces in `Content/SquadAI/UI/`.
- Suite is fully green at the baselines in §8. Pack: `SQUADAI_COMPLETE.md`.

Good hunting. The screenshots are the spec.

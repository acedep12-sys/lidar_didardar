# SquadAI — Complete Delivery (final merged source + assets)
**Date:** 2026-10-01 · **Engine:** Unreal Engine 5.7 (no newer APIs used anywhere)
**Project:** Open-world tactical FPS, Iran–Iraq war, Khuzestan / Dehlavieh front.

This folder is the single source of truth. Everything previously shipped as separate zips
is merged here.

```
source/SquadAI/            ← complete drop-in module (249 files: pristine + all patches merged)
assets/FogFX/              ← fog intro sprites + SquadAI_ImportFogFX.py
assets/TrenchMaterials/    ← Textures/ (25 war-worn maps, latest v4/v5) + SquadAI_ImportTrenchMaterials.py
README.md                  ← this file
```

## Install
1. **Code** — replace your project's `Source/SquadAI` with `source/SquadAI` (drop-in; never edit other modules). Compile with Live Coding OFF.
2. **Fog assets** — put `assets/FogFX` images in your named import folder, run `SquadAI_ImportFogFX.py` (Tools → Execute Python Script).
3. **Trench materials** — keep `Textures/` next to `SquadAI_ImportTrenchMaterials.py`, run the script. It imports 25 textures and builds all `M_Trench*` materials under `/Game/SquadAI/TrenchMaterials`.
4. Select a Trench Detail Dresser actor → **Build Details** (materials auto-fill, S17-TRAUTO).

## Files changed vs pristine source
| File | Status |
|---|---|
| `Private/HUD/SquadAIMainMenuHUD.cpp` + `.h` | modified |
| `Private/HUD/QuestNativeHUD.cpp` | modified |
| `Private/Environment/TrenchDetailSplineActor.cpp` + `.h` | modified |
| `Private/Environment/BridgeSplineActor.cpp` + `.h` | modified |
| `Private/Environment/CharacterCloneStation.cpp` + `.h` | **new** |

---

# Everything done, by feature tag

## Menu / presentation
- **S17-FOGFX** — cinematic fog intro for the main menu: hybrid billow sprites (4 puffs + noise), black smoke with the first blast, orange-ish grade, round radial dust, logo keyed to the whiteout instantly (no delay). Assets in `assets/FogFX`, drawn by `SquadAIMainMenuHUD`.
- **S17-VIDLOOP** — menu background video loops seamlessly via a dual-MediaPlayer A/B handoff (single player + SetLooping always hitched).
- **S17-HINT2** — replayable hint cards (4 hints, 7 s each) gated by CVar `SquadAI.ReplayHints`.
- **S17-ARFIX** — full Arabic main menu: 241-entry single-line Arabic map in `SquadAIMainMenuHUD.cpp` (external `SquadAILocalization.ini` keeps serving in-game HUD; Arabic is the 3rd language; S14-ARAB auto-heals the ini on boot).
- Canvas/UI lessons baked in: UI-domain materials draw as nothing through `DrawMaterial` (Surface domain used), gamma compensation 0.4545 for DrawMaterial, no shared MIDs across batched draws.

## Character Clone Station (`CharacterCloneStation.h/.cpp`, new actor)
- **S17-CLONE…4** — editor station that clones a character for the V3 leader mesh workflow (V3 is a mesh-only import, not a BP).
- **S17-CLONE5** — `CreateReadyMesh()`: outputs a **socketed skeletal mesh asset** (not a Blueprint — BP route rejected) ready for the user's "leader clean pack auto".
- **S17-CLONE6** — weapon-under-feet fix: the grip socket is baked under `SocketName` **plus** `AdditionalSocketNames` (defaults: `RifleSocket, WeaponSocket, Weapon_R, GripPoint, hand_rSocket, RightHandSocket`) via `GetMeshOnlySocketList()`, same grip bone/transform. Clone-only — main character and mannequin animations untouched.
- **Important:** the leader must stay on his ORIGINAL Blueprint. Swapping him to a clone BP caused `BPC_WeaponComponent: Weapon ID not valid` (×3 on screen) and broke his AI ("dumb leader").

## Trench Detail Dresser (`TrenchDetailSplineActor`) — the big arc
- **S17-TRAUTO** — `AutoFillMaterials()` runs first in `BuildDetails()`: empty slots self-fill from `/Game/SquadAI/TrenchMaterials`; hand-assigned slots always win.
- **S17-TRPERF** — editor-freeze fix: spline edits debounce through an `FTSTicker` (0.45 s) instead of actor timers (unreliable in editor worlds).
- **S17-TRWALL / TRWALL2** — wall auto-detection: probes every 150 cm cache real wall distance & slope per side (`WallDistAt / ParapetDistAt / FloorHalfAt / WallLeanAt`); panels lean INTO the wall at its real slope. Log: `[TrenchDresser] S17-TRWALL: N/M wall probes hit real walls`.
- **S17-TRFIX** — screenshot round 1: ragged camo net (masked texture), weathered wood, barbs that read, roofs rest on both lips or get legs — nothing floats.
- **S17-TRMESH** — geometry de-CAD pass: revetment = 5–7 individually jittered planks (10 % missing, 10 % broken) + waler; corrugated pitch/scale jitter; wire thinned to 0.9 cm strands with midpoint sag; twisted 45 cm-spaced barbs at random clock angles; ragged roof planks (varied length/width/slide).
- **S17-TRGATE** — "trench furniture without a trench" fix: per-sample wall HIT flags (`WallHitAt`); revetments, corrugated, firing steps, dugouts (side-flip then skip), netting & overhead cover (both sides) only spawn where a REAL wall exists. Open ground keeps only wire/pickets/debris — correct for no-man's-land. Every revetment plank traces its own ground and sinks in; roof legs plant whenever a lip sits >40 cm above traced ground. Empty cache (auto-detect off) ⇒ old manual behaviour preserved.
- **S17-TRPOLISH** — ladders need a wall; roofs carry 2–3 earth spoil heaps and 50 % get a camo net thrown over; comm poles get crossarms; barrels vary per-instance and sit at true contact height.
- **S17-TRVAR** — nothing flat, nothing repeated: nets = 3 sagging strips per panel (middle drops, edges droop); slumped spoil piles break the straight floor/wall crease; rugs tilt + 40 % folded corner; firing steps settle with 2–3° tilt and per-step size; scorch marks non-circular.
- **S17-TRWOOD** — history pass (timber was SCARCE on the Khuzestan front): wood revetment 55 %→16 %, corrugated becomes primary shoring (48 %), duckboard runs rationed, roofs 3–5 gapped planks; plank silhouettes stepped (offset half-strips) + splinter spikes past ragged top lines; net edge flaps hang 55–80° over the lips so a net never reads paper-thin edge-on.

## Trench materials & textures (assets/TrenchMaterials)
- Import script builds world-aligned PBR materials (no UV smear on stretched primitives) + UV-prop materials, netting (masked, two-sided), scorch (translucent decal).
- **Per-instance randomness (S17-TRVAR in the script):** every HISM instance gets its own brightness (0.72–1.15), its own dusty-warm↔bleached-cool hue shift, and its own UV crop (corrugated/drum/ammo-can/rug/netting) — BC/N/R stay aligned; no two props share a shade or stain.
- **Texture history:** v2 rejected (too clean) → **v3** dark damaged wood/metal, olive dense netting, scorch → **v4** full regen of Corrugated (aged zinc, rust runs, bullet holes), Earth (trampled dark soil, damp patches, stones), Canvas (stained khaki, stitched patches, seam) + weathering pass on Drum/AmmoCan/Rug → **v5 wood**: rough-sawn dark war wood — long splits along the grain, knots, nail heads with rust bleed, tar/mud, raw shrapnel gashes; wood tiling 150→95 cm so damage reads at plank scale.
- `ConfigureHISM` tint parameters are no-ops by design — appearance lives entirely in the textures/materials.

## Other
- **BridgeSplineActor** — spline bridge builder (earlier batch; shipped and kept in sync).
- Distant enemy spawning is intentional — untouched. Pack UMG widgets remain deny-by-default backups, never shown. Sandbags dropped (user has own mesh). Leader character-swap shelved.

---

# Open diagnostics (answers pending from you)
1. **Leader stops after mission 1** — read the log at that moment, in this order:
   - `counterattack scheduled/COUNTERATTACK` → S17-CNTR retakes the zone; leader correctly stops while hostiles are within ~15 m. Mop up, or untick `bCounterattackAfterComplete` on the zone.
   - `completion held` lines → HVT/sabotage/supplies/POW gate — mission 1 isn't actually complete.
   - Missing `[QuestChain] Mission 1 completed` → next `[MissionZone] … activated` pair → mission 2 isn't in the chain's `Missions` array.
   - Leader waits whenever the player is >35 m behind him (pacing gate).
   - Leader on a swapped clone BP (`Weapon ID not valid`) → put him back on the original BP.
   - Debug: set `bDebugLeaderPath = true` on his AI controller or call `DumpLeaderPathDebug` → `[PATHDBG] … goal=…`.
2. **READY MESH** — send the log line `CreateReadyMesh` prints, plus the exact socket name your leader pack expects (goes into `AdditionalSocketNames` if missing).
3. **GPU D3D12 crash** — TDR guidance already sent; tell me if it correlates with a dressed trench stretch.
4. **Trench visual check** — the latest screenshots predate these patches. Re-import materials, recompile, Build Details **on a stretch with a real dug trench cut**, then send a new shot.

# Standing rules honored
UE 5.7 APIs only · only `SquadAI` module touched · drop-in delivery, originals never overwritten · no code changes without per-batch permission · materials folders contain only materials · fog look is approved and frozen · Khuzestan (not Gulf/Arabic) setting accuracy · quality bar: Call of Duty.

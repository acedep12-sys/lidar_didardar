# Step 2 — muddy pack → trench builder (CORRECTED after a full code read)

Source: `MilitaryTrenchMegascansSa` — Megascans *Military Trench*. 179 static meshes,
187 MIs, real-world cm, Nanite, Virtual-Texture masters.

## Corrections to what I said before

| Earlier claim | Truth (from `TrenchDetailSplineActor.cpp`) |
|---|---|
| "`BaseColor Tint` param mismatch kills your tints — patch the candidate list" | **Wrong.** `ConfigureHISM` (l.69-89) only calls `TrenchTint()` when the material is **null** — "an authored material is shown exactly as authored". Tint is deliberately skipped for every family that has a material. The only tinted HISMs are **Casing, Helmet, DugoutShadow** (passed `nullptr`). No patch needed. |
| "Swap all 10 materials for pack materials" | **Wrong and harmful.** Megascans prop MIs are **per-prop UV-atlas** materials. Your dresser paints `WoodMaterial / MetalMaterial / GroundMaterial` onto **engine Cubes and Cylinders** (Post, Wire, FiringStep, Stone, Corrugated, and every non-custom fallback). An atlas material on a scaled cube = a smeared blob. Your own `M_Trench*` are **box-projected world-UV** — those must stay for all primitive families. |
| "ISM flag on `M_MS_Srf_VT`" | Still true and still required. |

## The real blocker: shared HISMs

Only 6 families take a custom mesh, and material slots are **shared across families**:

- `WoodMaterial` drives **Duckboard + Revetment + Post + Stake** (l.377-383)
- `MetalMaterial` drives **Wire + (Corrugated/Barrel/AmmoCan fallbacks)**
- `GroundMaterial` drives **FiringStep + Stone**
- `ClothMaterial` drives **Tarp (+ Netting fallback)**

So you can't give the Megascans revetment its own pack material without repainting
every wooden cube in the trench.

And one family is **unsafe to swap at all today**: `HISM_Duckboard` is reused for
cube-scaled geometry that is *not* gated by `bCustomBoard`:

| Line | What | Scale passed |
|---|---|---|
| 787 / 797 | dugout **roof planks** + splinters | `(PlankLen, 0.17-0.30, 0.04-0.06)` |
| 1229 | planks fallen off a **collapsed revetment** | cube scale |
| 1284 | wooden **tread on the firing step** | `(1.15-1.35, 0.48-0.56, 0.04)` |

Set `CustomDuckboardMesh` and those three become a 120 cm duckboard squashed to
4 % thickness — visible garbage. (Lines 966-992, 1037, 1097, 1155, 1321, 1390 **are**
properly gated: Barrel, AmmoCan, Revetment, Tarp, Stake are safe.)

## What the script now does by default (SAFE — zero code change)

`SquadAI_TrenchAssetBridge.py`, `PRESET = "SAFE"`:

| Slot | Mesh | cm | Material slot set |
|---|---|---|---|
| `CustomBarrelMesh` | `SM_Ind_Storage_Barrel_Metal_Rust_01` | 59×59×85 | `M_TrenchDrum` ← `MI_Ind_Storage_Barrel_Metal_Rust_01` |
| `CustomAmmoCanMesh` | `SM_Mil_Trench_Storage_Box_Metal_Rusted` | 35×9×17 | `M_TrenchAmmoCan` ← `MI_..._Storage_Box_Metal_Rusted` |
| `CustomStakeMesh` | `SM_Mil_Trench_Equipment_Stake_Wood` | 30×5×5 | — (keeps your wood) |
| `CustomTarpMesh` | `SM_Cloth_01` | 22×174×156 | `M_TrenchCanvas` ← `MI_Mil_Trench_Detail_Sandbag_Canvas` (tiling surface, safe) |
| `CustomRevetmentMesh` | `SM_Mil_Trench_Wall_Wood_Low_01` | 160×12×53 | — (keeps your wood) |
| `CustomDuckboardMesh` | **not set** | | blocked by the 3 ungated call sites |

`M_TrenchDrum` / `M_TrenchAmmoCan` are only ever used by their own custom-mesh HISM,
so pack atlas materials are correct there. Everything else keeps your world-projected PBR.

## SHIPPED code batch `S18-TRMESH` (in `source/SquadAI`, compile it)

1. **Mesh keeps its own material.** New `bUseCustomMeshMaterials` (default **true**): when a
   `Custom*Mesh` is assigned, `ConfigureHISM` calls `EmptyOverrideMaterials()` instead of
   forcing slot 0 — the Megascans prop renders with its real atlas material, and is not tinted.
   Applied to Duckboard / Revetment / Barrel / AmmoCan / Stake / Tarp.
2. **`HISM_Plank` split off `HISM_Duckboard`.** The 4 ungated cube-plank call sites (dugout
   roof planks + splinters, collapsed-revetment debris, firing-step tread) now go to
   `HISM_Plank`, which is always Cube + your `WoodMaterial`. `CustomDuckboardMesh` is safe.
   Build-stats line now reads `/18 categories`.

Files: `source/SquadAI/{Public,Private}/Environment/TrenchDetailSplineActor.{h,cpp}`.
Grep marker: `S18-TRMESH`.

With this, the script's `PRESET = "FULL"` assigns all 6 mesh slots and no atlas material is
ever pushed onto a primitive family.

3. **`S18-TRBAG` sandbags** — new `HISM_Sandbag` + `HISM_SandbagStack`, props
   `CustomSandbagMesh` / `CustomSandbagStackMesh`, toggle `bSandbags`. Lays runs of 3-9 stacks
   (240-720 cm) along the parapet lip, 1-2 courses high, with blown gaps, rest-zone awareness,
   and occasional bags slumped into the trench. Does nothing if no mesh is assigned.
4. **`S18-TRWIRE` barbed-wire runs** — new `HISM_WireSet`, props `CustomWireSetMesh` +
   `WireSetLengthCm` (210 for `Set_B`), toggle `bWireSets`. Lays the prop end-to-end (3% overlap)
   150-260 cm beyond the parapet, random flips, blown gaps, with a picket at the joints.
   Assigning it auto-suppresses the old cylinder concertina coils (`bKeepProceduralCoils` to keep both).

Build-stats line now reads `/21 categories`.

## Old notes

1. ~~Mesh-own materials~~ **done.** When a `Custom*Mesh` is set, pass `nullptr` as the material so the Megascans mesh keeps its *own* MI (and skip the DMI). One-line-per-family change in `BuildDetails`, plus a `bUseCustomMeshMaterials` toggle.
2. **Split `HISM_Plank` off `HISM_Duckboard`** for the 3 ungated sites (roof planks, collapsed debris, firing-step tread) → unlocks `CustomDuckboardMesh` (`Duckboard_Wood_M_02`, 120.7 cm = exactly the 120 cm section the code lays).
3. **New custom slots**: `CustomPostMesh` (`Equipment_Stick_Wood_S_01`, 133 cm), `CustomCorrugatedMesh` (`Sheet_Metal_Corrugated_01`, 80×100), `CustomStoneMesh` (`Scatter_Rock_S_01..10`, 8-18 cm), `CustomSandbagMesh` + new HISM (`Equipment_Sandbag_Canvas_Single`, 75×33×22 — the pack's best asset, you currently have no sandbags at all).
4. **Barbed wire**: the pack's wire is **whole runs** — `Wire_Barbed_Set_A/B/C` = 110 / 210 / 510 cm long, 118 cm tall, plus `Wire_Iron_Pigtail` (73 cm). Your wire is built from ~1.4 cm cylinder segments with hand-placed barbs (l.1438-1488) — a prop can't drop into that loop. Proposal: a new `HISM_WireSet` that places `Set_A/B/C` along the parapet as entanglement runs, and `bProceduralWire` to turn the cylinder version off.

Say which of 1-4 you want and I'll do them one small batch at a time.

## Also still true

- Enable **Virtual Textures** in the SquadAI project or the Megascans textures come in black (`M_MS_Base_VT` / `M_MS_Srf_VT`).
- `M_MS_Srf_VT` has **Used-with-ISM = False** → the WIRE pass sets and saves it.
- Ground alternatives to `MI_Mt_Slope_Ground_Mud_Soil_01` if the mud is too wet for Khuzestan: `MI_Mil_Trench_Ground_Dirt_Fine_02 / _03 / _Rough_02`. **Not** applied by default — `GroundMaterial` paints cubes.

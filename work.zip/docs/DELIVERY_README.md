# SquadAI — delivery folder (S18 series)

Everything in here is **meant to be copied into your project or run in the editor**. Nothing else from the workspace is needed.

---

## 1_Source_SquadAI — C++ (copy over your module)

Copy the `Public/` and `Private/` trees onto `<YourProject>/Source/SquadAI/`, keeping the folder structure. These are the **only** files that changed; every edit is marked with an `S18-` comment so you can diff/search.

| Marker | Files | What it does |
|---|---|---|
| `S18-TRMESH` / `S18-FIX` | `Environment/TrenchDetailSplineActor.*` | Trench dresser: real pack meshes + materials instead of engine BasicShapes. |
| `S18-GRIP` | `Characters/SoldierCharacter.*`, `Characters/SquadAIGripRetarget.h`, `Environment/CharacterCloneStation.*` | Weapon grip retarget for your V3 / non-UE rigs (the "rifle on the floor" fix). |
| `S18-LEAD` | `AI/SoldierAIController.*`, `AI/StateTreeTasks/STTask_LeaderPath.*` | Leader follows the spline corridor, single movement owner, correct wait radius. |
| `S18-BOOM` | `Tactical/SquadAIExplosiveDamage.*`, `Tactical/TacticalMortarBarrageActor.*`, `Tactical/TacticalGrenadeActor.*`, `Actors/ExplosiveBarrelActor.*` | Explosions actually damage pack-BP enemies and the player. |
| `S18-SAVE` | `HUD/QuestNativeHUD.*`, `SaveSystem/SquadAISaveGame.h` | Pause-menu save-slot picker. |
| `S18-TUT` | `Tutorial/SquadAITutorialSubsystem.*`, `Tutorial/TutorialRangeActor.*`, `HUD/QuestNativeHUD.*`, `Performance/SquadAIPlayerCombatBridge.cpp`, `Tactical/SquadAIFireSupportSubsystem.cpp` | Full tutorial: UI walkthrough, practice range (cans + grenade barrel), artillery step, illustrated cards. |
| `S18-VIDFIX` / `S18-VIDFIX2` | `HUD/SquadAIMainMenuHUD.*` | Menu background video: no A/B jump-cut, no Ken-Burns over video, loop-wrap stutter masked. |
| `S18-FOGFIX` | `Quest/SandstormWeatherDirector.*` | Fog/sandstorm audio hiccup, leaked audio components, first-storm frame hitch. |

New folder `Source/SquadAI/{Public,Private}/Tutorial/` — make sure it is picked up (regenerate project files after copying).

**In the level:** drop one `ATutorialRangeActor` near the player start. Everything else is automatic.

---

## 2_EditorScripts — run inside the UE editor (Output Log > Python)

| Script | Run it in | Purpose |
|---|---|---|
| `RUN_IN_TRENCH_PROJECT.py` | the *other* (muddy / MilitaryTrench) project | Dumps its assets to a TXT. |
| `SquadAI_DumpProjectAssets.py` | either project | Generic full asset dump. |
| `RUN_IN_SQUADAI_PROJECT.py` | this project | Applies the chosen meshes/materials to the trench dresser. |

---

## 3_Textures_TrenchMaterials — prebuilt trench textures

`Textures/` (25 maps) + `SquadAI_ImportTrenchMaterials.py`. Edit `SOURCE_DIR` at the top of the script, run it from the editor Python console; it imports and builds the `M_Trench*` materials. Materials only — no source, no docs.

## 4_Images_Tutorial — tutorial card art

Six 1280×720 stills (`T_Tut_Welcome / Squad / Move / Shoot / Grenade / Artillery`) + `SquadAI_ImportTutorialImages.py`. Edit `SOURCE_DIR`, run it; they land in `/Game/SquadAI/UI/Tutorial/`. **Do not rename them** — the HUD loads them by name. A missing image is harmless: the card just draws text.

## 5_Images_FogFX — menu / fog FX textures

Puff + noise + logo/title plates with `SquadAI_ImportFogFX.py`. Same procedure.

## 6_Docs — change logs

`S18B` (trench meshes), `S18C` (grip + leader), `S18D` (explosions, save picker, tutorial, video, fog), `TRENCH_ASSET_MAPPING.md` (which pack mesh replaces which primitive).

---

## Suggested order

1. Copy `1_Source_SquadAI` over your module, regenerate project files, **compile**.
2. Run the importers in `3`, `4`, `5` (set `SOURCE_DIR` in each).
3. Place one `ATutorialRangeActor`; rebuild the trench spline actor (`Build Details`).
4. Play from the main menu and check the logs: `[S18-TUT]`, `[S18-SAVE]`, `[S18-BOOM]`, `[WeatherDirector] S18-FOGFIX`, `[SquadAIMenu] S18-VIDFIX`.

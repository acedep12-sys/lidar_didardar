# REFUI_SPEC — Reference Tutorial & Tactical HUD Specification (`lidar_didar` -> `SquadAI`)

## 1. Overview & Visual Language
This document specifies the exact visual, color, typographic, and geometric design of the AAA Tactical Tutorial HUD from `lidar_didar` (`HTML_Reference_Bundle.zip` -> `index.html` + `assets/`, and reference screenshots `docs/REFUI_left.png` [Ref A] & `docs/REFUI_right.png` [Ref B]) as implemented natively in Unreal Engine 5.7 immediate-mode Canvas (`AQuestNativeHUD` + `USquadAITutorialSubsystem`).

### Key Visual Principles
1. **Semi-Transparent Charcoal-Gunmetal Glass (`.glass`)**:
   - Primary panels use a multi-stop translucent charcoal/gunmetal fill (`rgba(13, 16, 16, 0.72)` -> `rgba(22, 25, 24, 0.58)`) so the warm desert trench environment softly bleeds through.
   - Outer border: `1px solid rgba(226, 216, 196, 0.57)` (`#e2d8c491`) with inner specular top bevel (`inset 0 2px 0 rgba(255, 255, 255, 0.32)`), inner bottom dark recess bevel (`inset 0 -3px 0 rgba(0, 0, 0, 0.65)`), and multi-pass drop shadow (`0 8px 24px rgba(0, 0, 0, 0.65)`).
   - **Asymmetric Instrument Corner Brackets**:
     - Top-Left corner: `19x19 px` (`2px` stroke) glowing warm amber L-bracket (`#f2a64b`).
     - Top-Right, Bottom-Right, Bottom-Left corners: `15x15 px` (`2px` stroke) metallic sand-taupe L-brackets (`#a9a395`).
2. **3D Machined Metal Tiles & Housings (`.step`, `.mini`, `.stat`, `.weapons`, `.weapon-foot .item`)**:
   - Standard raised 3D metal tile: 145° metallic bevel gradient (`#464844` -> `#252826` -> `#171a19` -> `#343633`), `2px` top specular highlight (`#ffffff55`), `3px` bottom dark bevel (`#000000cc`), outer border `#d6d0c188`, and inner inset hairline frame (`inset 3px`, `#ffffff1a`).
   - Active / `.current` 3D copper-amber tile: warm copper-amber 3D gradient (`#724c27` -> `#29221b` -> `#4f331c`), outer amber border `#f1a953`, top specular `#ffe2b488`, outer amber halo glow (`#e9953b55`), and leading `3px` vertical amber-gold bar (`#ffd58c` -> `#ee8e35` -> `#9e4b1e`).
3. **High-Contrast 3D Copper-Amber CTA Buttons & Keycaps (`.focus-bottom .next`, `.keycluster .active`)**:
   - 4-stop copper-amber bevel gradient (`#ffe1a0` -> `#eaa04d` -> `#b86427` -> `#713819`), `2px` white top specular bevel (`#ffffffcc`), `3px` deep umber bottom bevel (`#552609`), and **dark espresso ink (`#21170f`)** — never white text on amber/gold.

---

## 2. Color Palette (`FSquadAIHUDPalette`)
| Token | Hex / CSS | `FLinearColor` | Usage |
|---|---|---|---|
| `PanelTop` | `rgba(13, 16, 16, 0.74)` | `(0.051, 0.063, 0.063, 0.740)` | Top stop of `.glass` tactical plates |
| `PanelBottom` | `rgba(22, 25, 24, 0.62)` | `(0.086, 0.098, 0.094, 0.620)` | Bottom stop of `.glass` tactical plates |
| `PanelEdge` | `#e2d8c491` | `(0.886, 0.847, 0.769, 0.570)` | Warm metallic sand outer hairline border |
| `Hairline` | `#ffffff25` | `(1.000, 1.000, 1.000, 0.145)` | Internal row/column hairline dividers |
| `Amber` (`Brass`) | `#e9953b` | `(0.914, 0.584, 0.231, 1.000)` | Primary tactical amber accent, active bars, corner brackets |
| `Gold` (`Warm`) | `#ffd27a` | `(1.000, 0.824, 0.478, 1.000)` | Highlighted numerals, kickers, badges, active borders |
| `BracketTaupe` | `#a9a395` | `(0.663, 0.639, 0.584, 0.920)` | Secondary corner L-brackets (TR, BR, BL) |
| `TextWhite` | `#f1eee7` | `(0.945, 0.933, 0.906, 1.000)` | Warm paper-ivory primary ink |
| `TextDim` | `#b9b4aa` | `(0.725, 0.706, 0.667, 1.000)` | Secondary descriptions & labels |
| `Muted` | `#9b958b` | `(0.608, 0.584, 0.545, 0.950)` | Micro-captions & metadata |
| `DarkInk` | `#21170f` | `(0.129, 0.090, 0.059, 1.000)` | High-contrast dark ink on copper-amber buttons/keycaps |
| `Success` | `#77c774` | `(0.467, 0.780, 0.455, 1.000)` | Health meter, live status dots, completed steps |
| `ArmorBlue` | `#64b9e5` | `(0.392, 0.725, 0.898, 1.000)` | Armor meter & shield highlights |
| `Danger` | `#e5593f` | `(0.898, 0.349, 0.247, 1.000)` | Critical health / danger alerts |

---

## 3. Component Layout & Geometry (1920x1080 Reference Frame)

1. **Top-Left Operation Masthead Plaque (`.operation-banner`)**:
   - Anchor: `Left = 2.35%`, `Top = 2.8%`, `W = 500 px`, `H = 88 px`.
   - Contents: 3D Eagle Shield Crest (`T_UI_TaskforceInsignia`, `57x54 px`), eyebrow `نیروی ضربت // آموزش`, H1 `عملیات: آزادسازی دهلاویه`, subtitle `نقشه: دهلاویه • آموزش انفرادی`, bottom `3px` glowing amber `.progressline`.
2. **Left 5-Step Tutorial Sequence Panel (`.tutorial`)**:
   - Anchor: `Left = 2.35%`, `Top = 14.5%`, `W = 460 px`, `H = 312 px`.
   - Header: `روند آموزش` | `مرحله ۱ از ۵`.
   - 5 Raised 3D Metallic Step Rows (`50 px` height, `5 px` gap):
     1. `۱` `حرکت` — `برای پیشروی حرکت کنید` (`T_UI_IconRunner3D`, `.badge` `در حال انجام`)
     2. `۲` `پناه‌گیری` — `از عوارض زمین و کیسه‌های شن استفاده کنید` (`T_UI_ArmorShield3D`)
     3. `۳` `نشانه‌گیری و حالت‌گیری` — `نشانه بروید، خم شوید یا دراز بکشید` (`T_UI_IconReticle3D`)
     4. `۴` `درگیری` — `اهداف تمرینی را از بین ببرید` (`T_UI_IconFlag3D`)
     5. `۵` `تأمین سنگر` — `به سنگر پیشرو برسید` (`T_UI_IconFlag3D`)
3. **Left-Middle Focus Instruction Card (`.focus-instruction`)**:
   - Anchor: `Left = 2.35%`, `Top = 45.0%`, `W = 365 px`, `H = 136 px`.
   - Top row: rotated 45° amber diamond `۰۱`, `راهنمای گام` / `حرکت به‌سوی محل سقوط`, pill `۱ / ۵`.
   - Body: `نشانگر زرد را دنبال کنید و به محل سقوط برسید.`
   - Bottom row: `علامت‌گذاری هدف [Q]` | 3D copper-amber CTA button `[F] ادامه ›` (`#21170f` dark ink).
4. **Top Compass Instrument Rail (`.compass`)**:
   - Anchor: `Left = 42.0%`, `Top = 3.0%`, `W = 22.0%` (`422 px`), `H = 42 px`.
   - 9 bearing slots (`NW`, `۳۰۰`, `۳۱۵`, `۳۳۰`, center 3D copper-amber `.bearing` pill `شمال` + downward pointer `▼`, `۱۵`, `۳۰`, `NE`, `۶۰`) with top tick marks.
5. **Top-Right Tactical Cluster (`.topright`)**:
   - Anchor: `Right = 97.5%`, `Top = 2.4%`.
   - Circular Tactical Minimap (`.mapbox`, `132x132 px` radar circle + caption `نگه‌دار [M] نقشه تاکتیکی`).
   - 3 Squad Member Portrait Cards (`.squad`, `62x99 px` each): `آلفا ۱ / رهبر تیم` (`T_UI_SquadAlpha1`), `آلفا ۲ / پشتیبانی` (`T_UI_SquadAlpha2`), `آلفا ۳ / تیرانداز` (`T_UI_SquadAlpha3`) with live status dots & green health bars.
   - Elapsed Clock & Gear Box (`.elapsed`, `69x99 px`): `۰۸:۴۲` / `زمان سپری‌شده` + `T_UI_IconSettings3D`.
6. **Right Mission Objectives Card (`.mission`)**:
   - Anchor: `Right = 97.65%`, `Top = 25.5%`, `W = 380 px`, `H = 216 px`.
   - Header: amber stripe + `T_UI_IconObjectives3D` + `هدف‌ها` | `ماموریت جاری`.
   - Objective row: `T_UI_IconObjectiveFire3D` (`42x42 px`), `تأمین محل سقوط`, `لاشه را بررسی و محدوده را ایمن کنید`, tag `منطقهٔ خطر`.
   - Distance row (`به محل سقوط برسید` | `۶۸ متر`) + segmented gold progress bar (`.track`) + ping box (`علامت‌گذاری محل سقوط [Q]`) + metadata (`مختصات 34T · 428 761` | `● سیگنال پایدار`).
7. **Right-Lower Training Progress Mini-Card (`.training-panel`)**:
   - Anchor: `Right = 97.5%`, `Bottom = 27.0%`, `W = 280 px`, `H = 160 px`.
   - Header: `پیشرفت آموزش` | `مرحله ۱ از ۵`.
   - 3 Raised 3D Mini-Tiles: `۱ حرکت [اکنون]`, `۲ پناه‌گیری`, `۳ نشانه‌گیری و حالت‌گیری`.
8. **Bottom-Center Movement Keycap Hint Banner (`.movehint`)**:
   - Anchor: `Center X = 50%`, `Bottom = 15.0%`, `W = 400 px`, `H = 74 px`.
   - Left `W A S D` 3D mini-keycap cluster (active key lit in copper-amber with dark ink `#21170e`), center copy (`به‌سوی هدف حرکت کنید` / `برای حرکت به جلو، [W] را نگه دارید` + mouse scroll icon), right `58x56 px` 3D physical keycap (`T_UI_KeycapFrame`) + amber arrow `➤`.
9. **Bottom-Left Vitals, Controls & Footer Cluster (`.solo-badge`, `.bottomleft`, `.footer-actions`)**:
   - `.solo-badge` (`Left = 2.35%`, `Bottom = 21%`, `148x36 px`): `شما / آموزش انفرادی` + green readiness bar.
   - `.controls` (`Left = 2.35%`, `W = 315 px`, `H = 32 px`): `[C] خم‌شدن • [SHIFT] دویدن • [SPACE] پرش از مانع`.
   - `.stats` (`Left = 2.35%`, `W = 315 px`, `H = 54 px`): twin 3D metal housings for Health (`T_UI_HealthCrest3D`, `۱۰۰ سلامت`, recessed 3D green segmented meter) and Armor (`T_UI_ArmorShield3D`, `۵۰ زره`, recessed 3D blue segmented meter).
   - `.stamina` (`Left = 2.35%`, `Bottom = 3%`): `استقامت` + `78x5 px` brass-gold bar.
   - `.footer-actions` (`Left = 370 px`, `Bottom = 3%`): `[TAB] هدف‌ها` | `[?] راهنما` | `[ESC] رد کردن آموزش`.
10. **Bottom-Right Weapon Readout & Quick-Slots (`.weapons`, `.weapon-foot`)**:
    - `.weapons` (`Right = 97.5%`, `Bottom = calc(3% + 48px)`, `W = 390 px`, `H = 110 px`):
      - Top 3-column housing: `۱۰۰ HP / زره ▰ ▰ ▰ ▱ ▱` | `سلاح اصلی / M4` + `T_UI_IconRifle3D` + `تفنگ تهاجمی • دوربین ۴× • صداخفه‌کن` | `حالت شلیک [خودکار]` + `۳۰` + `۹۰ • ۵.۵۶ ناتو`.
      - Bottom `.weapon-extra` row: `T_UI_IconSidearm3D ۵۷ ثانویه` | `×۲ نارنجک` | `×۲ دودزا`.
    - `.weapon-foot` (`Right = 97.5%`, `Bottom = 3%`, 5 tiles of `44x42 px`):
      - Slot 1: `T_UI_IconRunner3D` `۳ SPD`, Slot 2: `T_UI_IconStance3D` `۲`, Slot 3: `T_UI_IconRunner3D` `۳`, Slot 4 (active copper-amber): `T_UI_IconRifle3D` `۴`, Slot 5: `T_UI_IconSidearm3D` `۵`.
11. **3D World Waypoint & Ally Markers (`.waypoint`, `.ally`)**:
    - `.waypoint`: `T_UI_IconObjectiveFire3D` (`40x40 px`) + stem line + ground ellipse + `محل سقوط` / `۶۸ متر`.
    - `.ally`: cyan diamond `◆ هم‌تیمی · رایلی` / `۲۲ متر`.

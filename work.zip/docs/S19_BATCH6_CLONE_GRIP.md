# S19-BATCH6 — Clone Station & Grip Correctness

Final hardening pass on the weapon-clone pipeline. Three real defects found and
fixed, one of which (`S19-SCALE`) meant the bake could compute perfect maths and
still produce a wrong result at runtime.

**No lighting, post-process, fog, sky or exposure was touched.** All changes are
pure geometry / pure code.

---

## The bug that mattered: S19-SCALE

`Private/Characters/SoldierCharacter.cpp`

```cpp
AttachToComponent(Mesh, FAttachmentTransformRules::SnapToTargetNotIncludingScale, ResolvedSocket);
```

`SnapToTargetNotIncludingScale` **deliberately discards the socket's own
`RelativeScale`**. The clone station bakes the rig size ratio (e.g. 1.5 for a
V3 hand that is 15 cm against the mannequin's 10 cm) into exactly that field —
so the branch that runs when the socket EXISTS (i.e. every successful bake)
never read it back. **A correctly-baked weapon would still come out
mannequin-sized.**

Fix: read the socket scale and fold it back in.

```cpp
FVector SocketScale = FVector::OneVector;
bool bHasSocketScale = false;
if (!bEmulateSocket && bAutoScaleWeaponToGrip)
{
    // FindSocket() checks mesh-level sockets first, then the skeleton.
    if (const USkeletalMeshSocket* Socket = OwnMesh->FindSocket(ResolvedSocket))
    {
        SocketScale     = Socket->RelativeScale;
        bHasSocketScale = !SocketScale.Equals(FVector::OneVector)
                       && SocketScale.GetAbsMax() > KINDA_SMALL_NUMBER;
    }
}
if (bOverrideWeaponAttachScale) { FVector FinalScale = WeaponAttachScale;
                                  if (bEmulateSocket) { /* existing */ }
                                  else if (bHasSocketScale) FinalScale *= SocketScale;
                                  EquippedWeaponMesh->SetRelativeScale3D(FinalScale); }
else if (bHasSocketScale)       { EquippedWeaponMesh->SetRelativeScale3D(SocketScale); }
```

Hand-authored sockets are all `(1,1,1)`, so the guard makes this a strict no-op
for everything already working. `Engine/SkeletalMeshSocket.h` was already
included (S17-GRIP2).

---

## Fix 2 — ODR violation

`Public/Characters/SquadAIGripRetarget.h`

`MinGripRatio` / `MaxGripRatio` were plain namespace-scope `constexpr` (internal
linkage) referenced from `inline` functions. Every TU got its own copy, so the
inline function bodies were not identical across TUs — formally an ODR
violation, at risk of a link error or silently divergent clamping.

Changed to `inline constexpr`. (The `constexpr float MinSegment` inside
`ComputeSizeRatio` is function-local and correctly left alone — block scope has
no linkage.)

---

## Fix 3 — `VerifyGripSocket` measured nothing

`Private/Environment/CharacterCloneStation.cpp`

The verification used `Mesh->GetBounds()`, which requires **render data** and
reads as **zero on an unbuilt mesh**. The one check that was supposed to catch a
bad bake was therefore either blind or wrong — which is why a socket at Z=0
looked identical to a good run.

Replaced with **reference-pose extents** computed directly from the ref
skeleton:

```cpp
double RigMinZ = 1e30, RigMaxZ = -1e30;
for (int32 i = 0; i < Ref.GetNum(); ++i)
{
    const double Z = SquadAIGrip::RefBoneComponentSpace(Ref, i).GetTranslation().Z;
    RigMinZ = FMath::Min(RigMinZ, Z);
    RigMaxZ = FMath::Max(RigMaxZ, Z);
}
const bool   bHaveRig        = (RigMaxZ > RigMinZ);
const double MeshHeight      = bHaveRig ? (RigMaxZ - RigMinZ) : 0.0;
const double HeightAboveFeet = bHaveRig ? (P.Z - RigMinZ) : P.Z;
const double BoneAboveFeet   = bHaveRig ? (BonePos.Z - RigMinZ) : BonePos.Z;
```

Checks now:

| Condition | Severity | Meaning |
|---|---|---|
| socket ≤ 1 cm above the rig's lowest bone | **Error** | at the mesh root / under the feet |
| socket < 50 % of its bone's height | Warning | hangs suspiciously low |
| socket > 60 cm from its bone | Warning | detatched from the hand |
| socket above rig height | Warning | above the head |

Because this measures against `RigMinZ` rather than an assumed Z=0, it is also
correct for skeletons **not** authored with the feet at the origin.

---

## Pipeline invariant (unchanged, re-confirmed)

1. Bake into a **duplicate** of the mesh, never the source asset.
2. Bake as a **mesh-level** socket — `FindSocket` resolves mesh sockets before
   skeleton sockets.
3. **Replace** an existing socket of the same name rather than skipping it; the
   old skip made a bad grip permanent.
4. **Always verify afterwards.** The old code had none.

---

## Verification

| Check | Result |
|---|---|
| `python3 tools/squadai_lint.py source/SquadAI` | **0 errors / 16 warnings** (baseline matched) |
| Grip harness `cd tools/grip_test && ./run.sh` | **29 passed, 0 failed** |
| Brace / paren balance on all 3 touched files | `+0` / `+0` |
| `GetBounds` live calls remaining | **0** (one mention in a comment) |
| Editor scripts parse (7 files) | all OK |
| Workspace | **4.9 MB / 363 files** (cap 128 MB) |

### New end-to-end test (T8)

T8 reproduces both halves of the pipeline — what the station writes and what
`ASoldierCharacter` then does with it — so a mismatch between them cannot slip
through again. Result on a V3 rig with hands 1.5× the mannequin's:

```
template bone 'hand_r' -> clone bone 'RightHand'; ratio 1.500 from chain level 0
  (clone 15.00cm / template 10.00cm); loc (9.00, 1.50, -3.00); scale (1.50, 1.50, 1.50)
hand Z = 153.0 | weapon pos (102.00, 19.50, 150.00) | final scale (1.50, 1.50, 1.50)
PASS  weapon is at hand height, NOT under the feet
PASS  weapon sits within 15cm of the hand bone
PASS  S19-SCALE applies the rig ratio to the weapon (expect 1.5)
PASS  a (1,1,1) socket leaves the weapon scale untouched (no regression)
```

The weapon lands at Z=150 against a hand at Z=153 — in the hand, not under the
feet — and carries the 1.5× size compensation.

### T8 was not enough — T9, the "twisted rifle" test

T8 uses two rigs that share the mannequin's axis convention, so it would pass
even if the retarget ignored bone orientation entirely. Real V3 / CC / Mixamo
rigs do **not** share it: the hand bone reaches the same place by a different
chain of rotations.

T9 builds template/clone pairs whose hand bones sit on different axes — a yawed
upper arm, a rolled hand bone, and a complex pitched socket — and asserts the
invariant that actually matters:

> the socket's **component-space rotation** must be the same on the clone as on
> the mannequin, i.e. the weapon points the same direction on the character.

```
  yawed     |dot| = 1.000000  (1.0 = weapon points the same way)
            socket 9.6cm from hand (want ~9.6cm)  scale 1.500
  rolled    |dot| = 1.000000
  pitched   |dot| = 1.000000   socket 14.2cm from hand (want ~14.2cm)
```

### The tests were mutation-tested, not just run

A test that cannot fail is worthless, so the retarget was deliberately broken
(dropping the bone-orientation `Delta`) and the suite re-run:

| Build | T9 result | Meaning |
|---|---|
| naive (no `Delta`) | `|dot|` = 0.707107 → **FAIL** | cos 45°, i.e. the weapon lands **90° twisted** |
| shipped | `|dot|` = 1.000000 → PASS | orientation preserved |

T8 **still passed under the mutation**, which confirms it alone would never
have caught this class of bug. T9 does.

**Not verified:** no UE install exists in this sandbox. Everything above is
lint, brace/paren balance, and the executed C++ harness. The riskiest new
symbols are `GFrameCounter` (fog fix, earlier batch) and the ref-skeleton loop
above.

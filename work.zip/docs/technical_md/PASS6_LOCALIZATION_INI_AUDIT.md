# Localization INI audit — your `SquadAILocalization.ini` vs. the code (2026-09-21)

**Input audited:** your uploaded `SquadAILocalization.ini` (received as `.txt`) against
`Source/SquadAI` at repo commit `1578dfb2`.
**Audited surfaces:** every `GetString` / `GetLocalizedText` call with literal keys (37 pairs),
every `SquadAIHUDLocal` HUD helper call (25 pairs), every dynamically built key
(`Note%d_*`, `Station%d_*`, `Verse%d_*`, `Weapon%d_*`) in `SquadAIInventorySubsystem.cpp`.
**Verdict:** your file is *half-alive*. 61 of ~139 entries actually drive the game today.
78 entries are "decoys" — editing them changes **nothing**, with no error message.
42 keys the code *does* read are missing from your file (they silently fall back to
hardcoded Persian defaults).

---

## 1. Section-by-section truth table

Legend: ✅ live (your edits take effect) · ❌ decoy (silently ignored) · ➕ missing live key

### `[MainMenu]` — 1 of 11 entries live ❗
| Your key | Status | Reality |
|---|---|---|
| `GameTitle` | ✅ live | queried at `SquadAIMainMenuHUD.cpp:692` |
| `SubTitle` | ❌ decoy | code queries **`GameSubtitle`** |
| `BtnStartGame` | ❌ decoy | code queries **`ButtonNewGame`** |
| `BtnMapSelect` | ❌ decoy | code queries **`ButtonMapSelect`** |
| `BtnArmory` | ❌ decoy | code queries **`ButtonArmory`** |
| `BtnProfile` | ❌ decoy | code queries **`ButtonPlayerProfile`** |
| `BtnSettings` | ❌ decoy | code queries **`ButtonSettings`** |
| `BtnSaveGame` | ❌ decoy | no such query exists (menu uses `ButtonContinue`/`ButtonLoadGame`) |
| `BtnExit` | ❌ decoy | code queries **`ButtonQuit`** |
| `Watermark` | ❌ decoy | the watermark is a *texture*, never queried as text |
| `CopyrightNotice` | ❌ decoy | never queried |
| ➕ missing | | 19 live keys: `GameSubtitle`, `ButtonNewGame…ButtonBack` (14 buttons), `DifficultyTitle`, `DiffRecruit/Regular/Hardened/Veteran` |

### `[PauseMenu]` — 9 of 10 live ✅
Your 9 core keys match the code exactly. `ResumeHint` ❌ is never queried.

### `[Loading]` — 3 of 10 live
`LoadingTitle`, `LoadingDesc`, `PressEnterPrompt` ✅ (queried `QuestNativeHUD.cpp:1472-1474`).
`Tip1–Tip7` ❌ — **no code anywhere reads loading tips** (the game's own auto-template has the same dead keys).
➕ missing: `DeploymentVeil` (the post-travel deployment veil text, `QuestNativeHUD.cpp:1608`).

### `[HUD]` — 1 of 9 live
`AmmoCratePrompt` ✅. The rest ❌ — the code queries *different key names*: `ReviveHoldPrompt` (not `RevivePrompt`), `PickupFirstAid` (not `FirstAidPrompt`), plus `DownedAllyAidMarker`, `ExplosionDanger`, `MedicalStationPrompt/Preparing`, `MountedTurretEnter/Exit`, `MortarReleasePrompt`, `ObjectiveGoalDefault/Leader/Position`, `RadioHeader`, `ReviveProgress`. `SquadLeaderName`, `AllyNamePrefix`, `AllyStatusWounded`, `GrenadesLabel`, `MortarPrompt`, `GuidancePrompt` are drawn from hardcoded bilingual strings — not from this file at all.

### `[Inventory]` — 2 of 16 live
`HeaderTitle`, `SubHeader` ✅. Decoys ❌: `Tab*` (tabs are hardcoded bilingual at `QuestNativeHUD.cpp:3053+`), `BtnEquipWeapon` (code: `EquipWeaponButton`), `BtnNextNote` (code: `NextNoteButton`), `AmmoLabel`, `RadioTunerLabel`, `RadioVolumeLabel`, `Wallet*`.
➕ missing: `BallisticsHeader`, `ClosePrompt`, `EquipWeaponButton`, `NextFrequency`, `NextNoteButton`, `NextVerseButton`, `PreviousFrequency`, `QuranTitle`, `RadioTitle`.

### `[Armory]` — 12 of 18 live ✅
All `Weapon1..6_Name/_Desc` ✅ — queried dynamically (`SquadAIInventorySubsystem.cpp:50-54`).
`HeaderTitle`, `Stat_Damage…Stat_Reliability` ❌ (stat labels are hardcoded per panel).

### `[FallenTroopNotes]` — 13 of 13 live ✅✅
Perfect coverage. Bonus feature you may not know: **`Note1_Image=MyScan`** selects `Content/Textures/MyScan.png` as that note's scan (defaults to stem `Note<N>`).

### `[RadioStations]` — 11 of 11 live ✅✅ (incl. `StationCount` add/remove support)
### `[QuranVerses]` — 9 of 9 live ✅✅

### Dead whole sections ❌
`[MapSelection]` (map cards come from `FSquadMapDefinition` in the progression subsystem),
`[Traits]` (from `FSquadWeaponSpecialityTrait` in `SquadAIWeaponData.h`),
`[Profile]` (hardcoded menu page). **None of these ever touch the localization file.**

---

## 2. Two additional defects found during this audit

- **P6-8 (new): the hot-reload command does not exist.** Your file's header says to type
  `SquadAI.ReloadText` — no console command is registered anywhere in the module.
  `ReloadFromDisk()` exists but is unreachable from the console.
- **P6-4 (restated, now critical for you):** the file is searched **only** in read-only/packaged-hostile
  locations (`ProjectDir`, `Config`, `Content`) and auto-created at `ProjectDir`. In a packaged
  install your edits would live in a folder users can't (and shouldn't) write to. `ProjectSavedDir`
  was never searched.

---

## 3. What I prepared for you (nothing of yours was overwritten)

Your original file stays untouched at `/home/user/uploads/SquadAILocalization.txt` — permanent backup.

1. **`SquadAILocalization_v2_MASTER.ini`** — drop-in replacement for your INI.
   - Every key is verified **live** against the code (your audit table above).
   - Your own wording wins everywhere: decoy values were *migrated to the real keys*
     (e.g. your `SubTitle` text now sits under `GameSubtitle`).
   - The 42 missing live keys filled with the exact Persian defaults the code currently shows.
   - Your dead-but-meaningful sections (`[MapSelection]`, `[Traits]`, `[Profile]`, tips, tabs,
     wallet…) are **kept verbatim** under a clearly marked `⏸ RESERVED` block — full backup,
     zero harm, and they become editable when we do the L2 wiring pass.
   - Your asset-replacement guide is preserved unchanged (it matches the code's PNG paths).

2. **Code patch `L1` — `patched/localization_L1.patch` + ready-to-copy file**
   `patched/SquadAI/Private/Localization/SquadAILocalizationSubsystem.cpp`
   (verified: applies cleanly to your current source, round-trip byte-identical; header file unchanged):
   - **`SquadAI.ReloadText` console command actually registered** (fixes P6-8) — logs where it loaded from.
   - **Writable-first search order** (fixes P6-4): `<Project>/Saved/SquadAILocalization.ini` first,
      existing legacy locations kept as fallbacks; auto-created master now goes to `Saved/`.
   - **Legacy alias bridge** (fixes P6-3 softly): if the canonical key is missing, the old v1 name is
     tried automatically (`SubTitle`↔`GameSubtitle`, `BtnStartGame`↔`ButtonNewGame`, `BtnExit`↔`ButtonQuit`,
     `BtnEquipWeapon`↔`EquipWeaponButton`, `BtnNextNote`↔`NextNoteButton`,
     `RevivePrompt`↔`ReviveHoldPrompt`, `FirstAidPrompt`↔`PickupFirstAid`, …). Your **current**
     file — even without the v2 rename — starts driving the main menu the moment this patch is in.
   - **Auto-generated template replaced** with the full verified key list (byte-identical to your
     v2 master) — the game will never again write a template full of decoys.

### Deploy steps (when ready)
1. Copy `patched/SquadAI/Private/Localization/SquadAILocalizationSubsystem.cpp` over
   `<YourProject>/Source/SquadAI/Private/Localization/SquadAILocalizationSubsystem.cpp` (keep your old one as backup).
2. Rebuild the module (existing workflow — only the SquadAI folder is replaced, target files untouched).
3. Put `SquadAILocalization_v2_MASTER.ini` content into `<Project>/Saved/SquadAILocalization.ini`
   (create it, or let the game create it once and then paste your values). Your project-root INI
   keeps working too — `Saved/` just wins when both exist.
4. Test: launch PIE → console `SquadAI.ReloadText` → edit `GameTitle` → `SquadAI.ReloadText`
   → main menu title updates live.

*Risk note: the patch changes only the localization subsystem. No call sites, no HUD files,
no gameplay code were touched — the English built-in fallback table is untouched, and all
current compiled-in behavior is preserved when a key is absent from the file.*

---

## 4. Not yet editable (needs the optional "L2 full-wiring" pass)

True to your goal (*"change any texts… without hassle"*), these surfaces are today **hardcoded
bilingual** and can't be INI-driven until wired (small, mechanical edits in the two HUD files —
each `bEnglish ? X : Y` becomes `Loc->GetString(...)` with the same X/Y as fallback):
map-selection cards, traits, profile page, loading tips, inventory tabs, stat labels, wallet
dog-tag fields, ammo/grenade counter formats, squad-leader/wounded labels, watermark/copyright.
Your wording for all of them is already staged in the v2 master under `⏸ RESERVED`.

# Round 13 — S9-FIX: UE 5.7 compile errors

Five errors across two build attempts. All were UE 5.7 API tightenings, none were
logic bugs. Marker in code: `S9-FIX`.

| # | Error | File | Cause | Fix |
|---|---|---|---|---|
| 1 | C2065 `'AQuestZone': undeclared identifier` (cascaded to ~25 files) | `Public/AI/SoldierAIController.h:402` | `TWeakObjectPtr<AQuestZone>` member with no declaration of the class | added `class AQuestZone;` |
| 2 | C2440 cannot convert `IConsoleManager` to `IConsoleManager*` | `SquadAILocalizationSubsystem.cpp` ×2 | `IConsoleManager::Get()` returns a reference | `IConsoleManager& CMan = IConsoleManager::Get();` |
| 3 | C2664 `FDelegateHandle` → `FTSTicker::FDelegateHandle` | `SquadAILoadingScreenSubsystem.h:118` | FTSTicker uses its own handle type | changed member type, added `Containers/Ticker.h` |
| 4 | C2664 ×16 on `FString::Printf` | `QuestNativeHUD.cpp` | **5.7 validates format strings at compile time** | new `SquadAIFormatRuntime()` helper |
| 5 | C4716 `GetDefaultIniTemplate: must return a value` | `SquadAILocalizationSubsystem.cpp:983` | 500-line chain of adjacent string literals with no `return` | added `return` |

## #4 in detail — the only non-trivial one

UE 5.7 added `Core/Public/String/FormatStringSan.h`. `FString::Printf` now takes a
`TCheckedFormatString`, which is **consteval-constructed from a string literal only**.
Any runtime format string is rejected outright:

```cpp
FString::Printf(*MortarFmt, DistM);   // error C2664 in 5.7
```

Every format in the `SquadAILocalization.ini` system is runtime by definition, so all
16 localised format calls broke simultaneously. This cannot be cast or worked around at
the call site.

`FCString::GetVarArgs` still accepts a plain runtime `const TCHAR*`, so localised
formats are routed through a helper:

```cpp
static FString SquadAIFormatRuntime(const TCHAR* Fmt, ...)
{
    if (!Fmt) return FString();
    TArray<TCHAR> Buffer;
    Buffer.AddUninitialized(512);
    while (true)
    {
        va_list ArgPtr;
        va_start(ArgPtr, Fmt);
        const int32 Written = FCString::GetVarArgs(Buffer.GetData(), Buffer.Num(), Fmt, ArgPtr);
        va_end(ArgPtr);
        if (Written >= 0 && Written < Buffer.Num() - 1) break;
        if (Buffer.Num() >= 32768) { Buffer[Buffer.Num()-1] = TEXT('\0'); break; }
        Buffer.AddUninitialized(Buffer.Num());
    }
    return FString(Buffer.GetData());
}
```

Grows on overflow, caps at 32 KB, null-safe. The INI keeps its `%s`/`%d`/`%f`
placeholders unchanged.

**Convention going forward:** literal format → `FString::Printf` (keeps compile-time
checking). Format loaded from the INI → `SquadAIFormatRuntime`.

## Preventive sweeps run

- `IConsoleManager*` from `Get()` elsewhere: **0**
- Other `FTSTicker` handle members (`QuestNativeHUD.h`, `SquadAIFXManagerSubsystem.h`,
  `SquadAISaveLoadSubsystem.h`): already correct
- `Printf(*` anywhere else in the module: **0**
- AST-style scan for other non-void functions whose body starts with a bare literal
  (the #5 bug class): **0**

All five touched files brace/paren balanced.

# Pass 2 — Startup and ownership graph

Date: 2026-09-21
Scope: direct source inspection of the current `Source.zip` module. No code was changed.

## 1. The real ownership boundary

`SquadAI` is a large gameplay module, but it does **not** own the complete gameplay framework.

It defines:

- one main-menu GameMode (`ASquadAIMainMenuGameMode`),
- two native Canvas HUDs (`ASquadAIMainMenuHUD`, `AQuestNativeHUD`),
- one AI controller (`ASoldierAIController`),
- AI soldier character classes,
- many subsystems/components/actors.

It does **not** define:

- a gameplay GameMode,
- a gameplay PlayerController,
- a gameplay player pawn/character,
- a GameState or PlayerState,
- project/map defaults.

Therefore the host project outside the editable module owns the real player and gameplay-map boot configuration. `SquadAI` integrates itself into that host player at runtime, especially through `USquadAIPlayerDiagnosticSubsystem` and `USquadAIPlayerCombatBridge`.

## 2. Startup sequence

### Stage A — module load

`FSquadAIModule::StartupModule()`:

1. Logs `SquadAI module loaded`.
2. Installs a global `FGenericTeamId` attitude solver.
3. Same team = Friendly, different team = Hostile, `NoTeam` = Neutral.

The module currently uses `IMPLEMENT_PRIMARY_GAME_MODULE`.

### Stage B — GameInstance lifetime

Seven `UGameInstanceSubsystem` classes are automatically created and persist through map travel:

1. `USquadAIInventorySubsystem`
   - Creates the default arsenal.
   - Loads notes, radio stations, and Quran verses.
   - Owns player supplies and inventory-like data across maps.

2. `USquadAIProgressionSubsystem`
   - Creates a default profile and hard-coded catalogs.
   - Loads its progression save.
   - Owns profile, XP, unlocks, achievements, weapon selection, and map catalog.

3. `USquadAILocalizationSubsystem`
   - Loads `SquadAILocalization.ini` from several project paths.
   - If no file exists, attempts to create one in `ProjectDir` and still parses a built-in template.

4. `UDifficultySubsystem`
   - Starts at Normal.
   - Persists during ordinary map travel because it belongs to the GameInstance.

5. `USquadAILoadingScreenSubsystem`
   - Registers `OnPostWorldInitialization`.
   - Owns level-transition state across map destruction/recreation.

6. `UQuestLogSubsystem`
   - Stores mission-history entries for the GameInstance lifetime.

7. `USquadAISaveLoadSubsystem`
   - Loads saved user settings and applies what can be applied at that time.
   - Owns pending post-travel save restoration.

No subsystem uses `Collection.InitializeDependency`, so there is no explicit initialization ordering between these systems.

### Stage C — each UWorld/map

Nineteen World or TickableWorld subsystems are automatically created for each world, including the main-menu world:

- cover scanner,
- enemy fireteams,
- AI significance,
- soldier registry,
- shared threat memory,
- asset cache,
- audio director,
- cinematic combat,
- developer/debug tools,
- FX manager,
- player diagnostic/bridge installer,
- enemy pool,
- quest registry/ticker/validator,
- squad command,
- fire support,
- tactical pings,
- radio chatter.

Most expensive tickable systems are demand-driven or timer-driven, but their objects still exist in every map unless they implement a creation guard. Only `UQuestValidatorSubsystem` explicitly disables itself in Shipping.

## 3. Main-menu boot path

The intended main-menu map setup is:

```text
Main-menu map
  -> ASquadAIMainMenuGameMode
      -> DefaultPawnClass = ASpectatorPawn
      -> HUDClass = ASquadAIMainMenuHUD
  -> ASquadAIMainMenuSetupActor placed in the level
```

### `ASquadAIMainMenuGameMode`

Despite its comment, the class itself only assigns the HUD and SpectatorPawn and logs in `BeginPlay`. Cursor/input configuration is actually performed by the HUD.

### `ASquadAIMainMenuHUD`

At `BeginPlay` it:

1. Reads the saved language.
2. Applies English or Persian menu text.
3. Resolves textures from `/Game/Textures` or loose image files.
4. Forces resolution/screen-percentage console variables.
5. Subscribes to localization changes.
6. Shows the mouse cursor and selects `GameAndUI` input mode.
7. Builds procedural menu particle arrays.

At every `DrawHUD` it:

1. Removes any legacy main-menu UMG widget.
2. Draws a Canvas-only menu.
3. Builds a fresh list of clickable rectangles.
4. Polls raw mouse/keyboard input.
5. Routes clicks by global numeric button IDs.

Its states include Main, Map Select, Armory, Progression, Profile, Achievements, Difficulty, Load, Settings, Briefing, and Relics.

### `ASquadAIMainMenuSetupActor`

This actor is a level director rather than a true global manager. At `BeginPlay` it:

1. Reads saved language.
2. Subscribes to language changes.
3. Obtains player 0's HUD; if it is not the menu HUD, calls `ClientSetHUD`.
4. Pushes target map, menu text, textures, theme, Niagara and sound references into the HUD.
5. Optionally starts menu music and wind with `PlaySound2D`.
6. Optionally spawns an atmospheric dust actor.
7. Optionally drives a cinematic orbit camera every tick.

It defaults to `TargetGameplayLevelName = L_Khuzestan`.

The menu can still partially function without this actor because the HUD has defaults and resolves many textures itself. The setup actor is needed for level-specific custom assignments, sounds, Niagara settings, and orbit-camera behavior.

## 4. Menu-to-game transition

Launch routes are:

- Continue: latest save if one exists; otherwise `L_Khuzestan`.
- Difficulty cards: set GameInstance difficulty, then launch `L_Khuzestan`.
- Map Select: launch one of the hard-coded progression catalog maps.

Hard-coded map catalog:

- `Dehlavieh_Karkheh` -> `L_Khuzestan`
- `Bostan_Chazzabeh` -> `L_Bostan`
- `Khorramshahr_Arvand` -> `L_Khorramshahr`

The preferred travel path is:

```text
MainMenuHUD
  -> USquadAILoadingScreenSubsystem::StartDeploymentTransition
  -> LoadLevelWithScreen
  -> create old-world loading widget
  -> OpenLevel
  -> OnPostWorldInitialization in destination
  -> recreate loading widget
  -> poll until world BeginPlay + PlayerController exist
  -> mark ready after at least 1 second
  -> player confirms deployment (default behavior)
```

If the loading subsystem is unavailable, the HUD falls back to raw `OpenLevel`.

## 5. Gameplay-map boot path

The gameplay map must obtain its gameplay GameMode, PlayerController, player pawn, and HUD from the host project. For full module behavior, the host gameplay GameMode must ultimately produce `AQuestNativeHUD` or an appropriate subclass.

`AQuestNativeHUD` is not assigned by any gameplay GameMode inside this module.

At gameplay HUD `BeginPlay`:

1. It resolves HUD/inventory/loading textures.
2. It collapses explicitly recognized legacy/TPWCS UMG HUD widgets.
3. It remains Canvas-native.

The HUD starts with its own `bDeploymentVeilActive = true`. It draws a second Canvas deployment screen, simulates progress for about 2.4 seconds, and requires Enter/Space/gamepad/left-click before showing normal combat HUD.

The normal combat HUD then owns:

- pause/inventory overlays,
- health/fire/suppression effects,
- damage directions and hit markers,
- reticle,
- compass and minimap,
- squad panel,
- mission card,
- pings,
- interaction/revive prompts,
- mortar UI,
- objective guidance.

## 6. Host-player integration

`USquadAIPlayerDiagnosticSubsystem` is automatically created in each world and searches for player pawn 0.

When a player pawn exists, it:

1. Searches for a TPWCS weapon component and repeatedly applies a close-wall reflection fix.
2. Dynamically adds `USquadAIPlayerCombatBridge` in all builds.
3. Adds a weapon diagnostic component in Debug/Development.
4. Stops subsystem ticking only after all required setup flags complete; wall-fix maintenance then runs on a 5-second timer.

`USquadAIPlayerCombatBridge` polls raw input every 0.05 seconds and supplies module gameplay to the externally owned player pawn:

- middle mouse: mortar aiming/fire support,
- V: objective guidance,
- G/H: fragmentation/smoke grenades,
- number keys: medkit,
- Escape/P: pause,
- I/Tab: inventory,
- player firing detection and hit traces/damage bridging.

This is the main reason the module can work without owning the project's player class.

## 7. AI/mission actor activation

### Soldiers

`ASoldierCharacter`:

- defaults to `ASoldierAIController`,
- auto-possesses AI when placed or spawned,
- owns Aim, Weapon, Health, Grenade and Adapter components,
- registers perception stimuli and a navigation invoker,
- registers with significance and soldier registries,
- applies current GameInstance difficulty,
- activates pack-health bridging when pack-presentation mode is enabled.

### AI controller

`ASoldierAIController`:

- owns Perception, StateTree and GameplayTasks components,
- configures perception at BeginPlay,
- establishes team ID at possession,
- adds an adapter component to non-native pawns when missing,
- starts/restarts StateTree logic at possession,
- has direct/fallback combat logic even when StateTree is incomplete.

No StateTree asset is assigned in C++. The actual StateTree asset must be configured on an inherited Blueprint/controller/component in the host project. Calling `StartLogic()` alone does not provide the tree.

### Quest chain

`AQuestChain` registers itself in a static weak list. If its mission list is empty, it discovers every `AMissionZone`, sorts by `MissionIndex`, assigns ownership, and optionally auto-starts after `StartDelay`.

A mission activates its linked spawners and tracks Reach/Clear/Defend behavior. Wave spawners default to native `AEnemySoldier` if no external enemy Blueprint is assigned, and prewarm through `UEnemyPoolSubsystem`.

### Setup manager

`ASquadAIAutoSetupManager` is primarily an editor/level-authoring tool. Default settings prevent runtime auto-setup:

- `bRunInEditorOnly = true`
- `bRunOnBeginPlay = false`

At normal BeginPlay it still copies debug switches and pushes assigned Niagara defaults into the FX subsystem. Its destructive/spawning setup operations run only when explicitly invoked.

## 8. Static findings from this pass

These are source-confirmed observations, not engine-tested failures.

### P2-01 — expected host-project dependency

There is no gameplay GameMode/PlayerController/player pawn in the module and no in-module assignment of `AQuestNativeHUD`. This is intentional-looking adapter architecture, but it must remain documented because the module cannot bootstrap gameplay by itself.

### P2-02 — combat bridge can attach to the menu SpectatorPawn

The player diagnostic subsystem has no map, GameMode, HUD, pawn-class, or `IsGameplayMap` gate. The main-menu GameMode creates a SpectatorPawn, so the subsystem can attach `USquadAIPlayerCombatBridge` to that pawn.

Because the SpectatorPawn lacks the expected TPWCS weapon component, `bFixApplied` may never become true, keeping the diagnostic subsystem tickable. The attached combat bridge can also poll gameplay keys in the menu; G/H or middle mouse can potentially spawn grenades/fire-support effects in the menu world.

This is a real architecture risk and a strong candidate for a later fix inside `SquadAI`.

### P2-03 — saved audio volume and FOV are not reliably reapplied after startup

The SaveLoad GameInstance subsystem applies settings during GameInstance initialization. At that time:

- the per-world audio subsystem commonly does not exist yet,
- a player camera manager commonly does not exist yet.

The audio subsystem does not read `USquadAISaveLoadSubsystem::GetCachedSettings()` when its world initializes, and no later startup hook reapplies FOV. Therefore quality/VSync/motion blur/language can apply, while persisted audio volumes and FOV can remain at defaults until settings are changed again or another external system applies them.

### P2-04 — menu cached settings are not initialized in `BeginPlay`

`ASquadAIMainMenuHUD::BeginPlay` loads `LanguageCode` into a local `SavedLang` variable but does not assign the loaded struct to `CachedMenuSettings`.

Many drawing and input branches decide English versus Persian from `CachedMenuSettings.LanguageCode`, whose default is `fa`. As a result, `ApplyEnglishPreset()` can run while later menu branches still believe the menu is Persian until the Settings screen refreshes the cache or the user toggles a setting.

### P2-05 — the default loading widget has state but no native visuals

`USquadAILoadingScreenWidget` has no native widget tree construction and no `NativePaint`. It stores text/art/progress and handles input, but the C++ class alone does not draw the advertised screen. A visual UMG Blueprint subclass is required for that path to render. Otherwise the visible loading presentation comes from `AQuestNativeHUD` only after the destination gameplay HUD exists.

### P2-06 — two independent deployment gates

There are two loading/deployment systems:

1. GameInstance loading-widget handshake.
2. Gameplay HUD Canvas deployment veil.

Both can require player input and both listen for the same keys. They may dismiss together on the same press, but they are independent state machines and can drift or create invisible gating when the default loading widget has no visual Blueprint.

### P2-07 — StateTree content is an external asset dependency

C++ defines task structs and owns a `UStateTreeAIComponent`, but it never assigns a StateTree asset. The host project must have the correct inherited Blueprint/component asset configuration. Source-only replacement must preserve that Blueprint linkage.

### P2-08 — duplicated main-menu audio ownership is possible

The world audio subsystem automatically enters Exploration and can play configured tuning/manager music. The MainMenuSetupActor independently starts `MenuThemeMusic` and `DesertWindAmbience` through unmanaged `PlaySound2D` calls. If both paths are populated, overlapping music/wind is possible.

### P2-09 — loading texture slot on MainMenuSetupActor is not connected

`ASquadAIMainMenuSetupActor::LoadingScreenTexture` is resolved and counted in diagnostics but never pushed to `USquadAILoadingScreenSubsystem`. The subsystem separately resolves the same conventional texture path, so the default asset works, but a custom texture assigned only to the setup actor has no effect on the loading subsystem.

## 9. Current mental model

The cleanest description is:

> `SquadAI` is an auto-created subsystem layer plus a set of Canvas HUDs, AI pawn/controller classes, map actors, and reflection adapters around a host UE FPS project. Persistent state lives in GameInstance subsystems; simulation services live in World subsystems; map-authored actors activate missions/environment; the host owns the actual player/gameplay framework.

## 10. Next pass

Pass 3 should follow the complete player/squad combat loop:

- host player firing -> combat bridge,
- native/pack target selection,
- one-path damage chokepoint,
- health/death/downed/revive,
- inventory/grenade/medkit synchronization,
- leader and ally survival guarantees,
- weapon visuals and TPWCS reflection adapters.

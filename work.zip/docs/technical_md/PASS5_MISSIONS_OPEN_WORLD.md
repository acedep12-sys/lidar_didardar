# Pass 5 — Missions and the open-world loop

**Repository:** `lid_rostami123` at `1578dfb276d153cfac960d41275273339a0484a9`  
**Source inspected:** `/home/user/project/extracted/source-full/Source/SquadAI/`  
**Date:** 2026-09-21  
**Status:** static source analysis only; no `Source/SquadAI` file was modified

## Scope and confidence boundary

This pass independently traced all 46 files under `Public/Quest` and `Private/Quest` (about 10,168 lines), then followed their consumers into AI, HUD, save/load, combat encounters, procedural villages/buildings/trenches, explosive barrels, registries, health, audio, pooling, progression, and lifecycle code.

The archive does not include the host project's maps, Blueprints, StateTree asset, World Partition settings, Data Assets, or third-party pack implementation. Therefore this report distinguishes:

- behavior that is definitely implemented in C++,
- behavior that can only work if external Blueprint/content calls it,
- and behavior contradicted by the current C++ implementation.

The archived `STEP5_MISSIONS.md` was deliberately read only after the current source trace. Its findings are compared near the end.

---

## 1. Executive conclusion

The current module does not have one mission/open-world authority. It has **three independent mission authorities, two wave-spawner implementations, two fire-damage implementations, several independent goal sources, and a save format that persists only a small part of one authority**.

### The three mission authorities

| Authority | Main path | Completion authority | HUD/save integration |
|---|---|---|---|
| Mission-chain system | `AQuestChain -> AMissionZone -> AEnemyWaveSpawner` and/or `AWaveSpawner` | Mission zone state and linked-spawner counters | Native HUD primarily supports this; main save partially supports it |
| Legacy/tag objective system | `AQuestDirector -> AQuestMission -> UQuestObjective_AutoZone -> AQuestZone/AWaveSpawner` | Objective state ticked at 4 Hz | Legacy UMG supports it, but native HUD suppresses that stack; main save ignores it |
| Standalone encounter system | `ACombatEncounterVolume` | Its own local wave polling and flags | No chain/director/save contract |

These are not alternate front ends over a common mission model. They independently own activation, spawning, progress, failure, completion, cleanup, UI, and persistence.

### Highest-risk conclusions

1. **`AAutoSpawnZone` is structurally broken as a runtime “one-drop encounter.”** It spawns `AQuestZone` and `AWaveSpawner` normally and configures them only after their `BeginPlay`. The zone therefore misses tag registration and custom shape configuration; the spawner misses tag registration and cannot auto-start from the late configuration. Reach objectives can stall, Clear can auto-succeed after five seconds with enemies still alive, and Defend can fail its outside-zone test because the objective never resolves the zone.
2. **Template-wave restart/restore is not a reset.** `AWaveSpawner::StopWaves()` only clears two timers. It does not destroy/release living enemies, remove their death delegates, unregister fireteams/coordinator membership, or clear `AllSpawned`. Restarting zeroes counters and starts another run while old enemies remain capable of decrementing the new run.
3. **Save/load is not mission-safe.** It stores an arbitrary first chain's mission index/count/title, but no chain identity, mission identity, mission state, wave state, enemies, timers, objective state, encounter state, legacy quest state, or procedural-world state. Load again selects an arbitrary first auto-start chain. Auto-start can already spawn combat before the delayed post-travel restore runs.
4. **Open-world lifecycle ownership is incomplete.** Auto zones, villages, buildings, trenches, and combat encounters spawn runtime child actors without `Owner`, without a level override, and often without `EndPlay` cleanup. Attachment is not ownership. In a World Partition map, those children can be created in the persistent level and outlive the cell actor that generated them.
5. **Environmental damage has incompatible contracts.** Decorator fire does not damage a native player with `UHealthComponent`; overlapping fires fight over global boolean burn state; standalone fire and barrage directly mutate third-party pack health, bypassing damage/death/HUD contracts; barrage can damage a native player twice.
6. **The sandstorm AI fix exists, but weather remains only partially systemic.** AI sight radii are now scaled every 0.5 seconds. Existing memory/targets, hearing, direct omniscient pursuit, visuals, lighting, fog, and particles are unaffected. Manual Trigger/Stop do not advance phases when auto-cycle is disabled.

The immediate architectural need is not another local patch. It is a product decision: **which mission authority is canonical, which HUD must display it, and what “load an active mission” is supposed to reconstruct.**

---

## 2. Mission-chain system: `AQuestChain` + `AMissionZone`

### 2.1 Chain discovery and selection

`AQuestChain` contains an ordered `Missions` array. If empty at `BeginPlay`, it scans all currently loaded `AMissionZone` actors and sorts them by `MissionIndex`. It assigns each zone's `OwningChain`, optionally starts immediately, and advances on zone state delegates.

Important behavior:

- `StartChain()` resets index and completion count.
- A completed zone awards 800 XP; completion of the chain awards another 1,500 XP and achievement progress.
- Player death now reaches the failure branch by default through `bFailMissionOnPlayerDeath = true`.
- Failure either restarts the whole chain or resets/retries the current mission after one second.
- `FindPreferred()` returns the first active chain encountered in a process-static weak registry, or an arbitrary fallback when inactive chains are allowed.

Open-world/multiple-chain risks:

- Two chains with empty mission arrays each discover **all** currently loaded zones and overwrite `OwningChain` on the same actors.
- Mission zones streamed in after chain `BeginPlay` are not discovered.
- The process-static registry is world-filtered, but has no explicit priority or stable chain identifier.
- AI, barrage, HUD, and save/load can select different chains because their selection and caching rules differ.

### 2.2 Mission types

`AMissionZone` implements:

- **Reach:** completes when a player-controlled pawn overlaps the box; activation also inspects existing overlaps.
- **Clear:** activates linked spawners and completes after all configured spawning is done, alive count is zero, and at least one enemy was spawned.
- **Defend:** counts down in the actor's 0.5-second tick and periodically calls `ActivateLinkedSpawners()`.

Player death handling now revives the player first, then fails the mission by default. This makes the formerly dead `AQuestChain::OnMissionFailed` branch reachable. The optional legacy mode still restarts an attempt and respawns the squad.

### 2.3 Partial spawner-stack unification

Current source adds `LinkedTemplateSpawners` alongside legacy `LinkedSpawners`. This is useful, but it is only driver-level unification:

- activation calls `ActivateSpawner()` or `StartWaves()`,
- deactivation calls `DeactivateSpawner()` or `StopWaves()`,
- polling aggregates both counter types.

The systems still have different completion semantics, delegate models, reset behavior, pack compatibility, pooling behavior, and ownership.

There is also a mixed-stack completion defect. `BindSpawnerEvents()` and `OnSpawnerEnemyDiedEvent()` observe only legacy `AEnemyWaveSpawner` instances. The death event recomputes only legacy counters and can complete a Clear mission once legacy spawners are done, **ignoring linked template spawners that may still be active**. A template-only Clear mission uses the 0.5-second safety poll and is safer than a mixed mission.

For Defend, the periodic activation is more dangerous for template spawners: every interval calls `AWaveSpawner::StartWaves()`, which stops timers, zeroes counters, and starts from wave zero while previously spawned living enemies remain.

### 2.4 Clear and malformed configuration

- A Clear mission with no linked spawners completes immediately.
- A configured spawner that never successfully creates an enemy can leave `TotalEnemiesSpawned == 0`; the mission then cannot satisfy its `> 0` completion guard.
- `SilentResetForLoadRestore()` deactivates spawners but does not reset/destroy their enemy populations.
- The mission's progress counters are runtime aggregates, not persisted state.

---

## 3. Tag/objective system: `AQuestDirector` + `AQuestMission`

### 3.1 Execution model

`AQuestDirector` discovers all loaded `AQuestMission` actors, or attached children, sorts them by `Order`, and auto-starts after one second. `UQuestTickerSubsystem` finds one director once, then uses a 0.25-second timer to tick the active mission and publish `FQuestHudSnapshot`.

Current source fixes two archived defects:

- failed missions no longer stall the director; they are recorded and the director advances,
- `UQuestLogSubsystem::RecordMission` is now called.

However, “failure advances to the next mission” is equivalent to skipping a failed stage. There is no director-level retry, game-over, or failed-campaign authority.

One-time discovery is not robust for World Partition:

- if the ticker's first search occurs before a director cell is loaded, it permanently decides that the map is not a quest map,
- the director collects only missions loaded during its `BeginPlay`,
- the validator also runs only once, 0.5 seconds after world start.

### 3.2 `UQuestObjective_AutoZone`

The objective now implements explicit Reach, Clear, and Defend modes instead of hardcoding Reach:

- **Reach:** player overlap, with any living team-0 ally within 600 cm as a fallback.
- **Clear:** succeeds when zone hostile count reaches zero, with a five-second empty-zone grace.
- **Defend:** succeeds when a cached template spawner completes or the duration elapses; it can fail after too much time outside the zone.

But integration remains incomplete:

- `Mode = Auto` always resolves to Reach; no configuration is inferred.
- `AutoStartZoneTag` on `AQuestMission` has no C++ reader.
- The objective finds a same-tagged `AWaveSpawner`, but **does not start it**.
- `OnFinish()` does not clear `UQuestRegistry::CurrentActiveGoal` or the move commands force-pushed to allied AI. The final objective can leave a stale GPS/command goal indefinitely.
- A failed objective's `OnFinish()` is called before `FailMission()`, and `FailMission()` calls it again.
- HUD enemy count is a near-global registry count around the mission actor, not the objective zone's actual count.

### 3.3 `AAutoSpawnZone` late-configuration failure

`SpawnChildActors()` uses ordinary `SpawnActor` for each child and then writes configuration:

1. spawn `AQuestZone`,
2. set `ZoneTag`, shape, and extent,
3. spawn `AWaveSpawner`,
4. set spawner tag, template, enemy class, points, and actor tag,
5. optionally spawn/configure attack coordinator.

Normal `SpawnActor` completes `BeginPlay` before returning in a begun-play world. Consequences:

- `AQuestZone::BeginPlay()` sees an invalid/default tag, so it does not register.
- It configures the default box extent, so a custom parent `ZoneExtents` is not applied.
- Overlap delegates are bound to the default selected shape before the parent writes shape settings.
- `AWaveSpawner::BeginPlay()` sees an invalid/default spawner tag, so it does not register.
- Any auto-start decision occurs before its template/class/points are assigned.
- No later function re-registers or reconfigures either child.

Observable objective failures:

- **Reach:** registry lookup returns no zone; GPS becomes zero; player overlap cannot be observed; ally fallback also has no valid goal. The mission stalls.
- **Clear:** cached zone is null, so hostile count reads zero and the objective succeeds after five seconds regardless of spawned combat.
- **Defend:** cached spawner may be found through the actor tag, but it was not started by the objective; with an outside limit, the unresolved zone means the player is always considered outside.
- `QuestValidator` reports that the tag has no registered zone.

The parent also has no `EndPlay` cleanup and gives children neither `Owner` nor attachment. Re-streaming can produce duplicate orphaned zones/spawners/coordinators.

### 3.4 Quest log persistence is still incomplete

Mission results are now recorded in the GameInstance subsystem. `ToBytes()` and `FromBytes()` exist, but have no callers, and `USquadAISaveGame` has no quest-log byte field. Thus the log works within the current process but is still not integrated into disk save/load.

---

## 4. The two wave-spawner stacks

## 4.1 `AEnemyWaveSpawner` (legacy X/Y/Z stack)

Strengths:

- supports arbitrary enemy classes, including pack pawns,
- throttles by `MaxAliveEnemies`,
- uses pooling first and direct spawn as fallback,
- tracks native deaths by delegate and pack deaths by reflected health polling,
- supports fireteam registration and full reset.

Critical semantics:

- `OnSpawnerWaveCompleted` fires after all enemies have been **spawned**, not killed, despite the header saying “all enemies in a wave are dead.”
- `OnSpawnerAllWavesDone` also means the spawning schedule is finished, not that combat is clear.
- After final spawning it sets `bIsActive = false`. Pack deaths are only discovered by `CleanupDeadEnemies()` during future spawn attempts; therefore pack enemies dying after final spawning may never decrement `AliveEnemyCount`. A Clear mission can stall permanently.
- Failed spawns increment `SpawnedInCurrentWave` to avoid an infinite loop but do not increment total spawned. If every spawn fails, the mission sees zero total and cannot complete.
- Default `bDestroyEnemiesOnSpawnerEnd` is false, so stream-out/destruction normally leaves its enemies in the world.

`ResetSpawner()` is destructive rather than pool-aware: it destroys tracked pawns and an Owner sweep, including pooled instances currently assigned to it. The pool can retain weak entries for actors that were destroyed externally.

## 4.2 `AWaveSpawner` + `UWaveTemplate`

This stack advances on actual native death delegates and supports batches, per-wave classes, round-robin points, NavMesh projection, coordinator registration, and fireteams.

Critical defects:

- `StopWaves()` only clears timers. It is not a reset or cleanup operation.
- `StartWaves()` calls `StopWaves()`, zeroes counters, but leaves old enemies, bindings, and `AllSpawned` intact.
- A death from an old run later decrements the new run's `CachedLiving`, can make a wave appear cleared early, and can release a pawn now assigned elsewhere.
- `EndPlay()` does not clean living spawned enemies or unregister them from coordinator/fireteam ownership.
- A wave with `NumSoldiers == 0` never generates a death event and never advances.
- A missing class, zero batch size, or persistent spawn failure can schedule forever or stall forever.
- Pool prewarm chooses one class even though later waves may override it.
- There is no pack-health death polling, so non-native enemy classes without `UHealthComponent` never advance this stack.

## 4.3 Pooling

The archived “Prewarm has zero callers” defect is fixed. Both spawner stacks now top up the pool when activated.

The pool itself is still not a complete actor reset contract:

- Native soldier death sets a 10-second lifespan. `SleepEnemy()` and `WakeEnemy()` do not cancel it, so a released or reacquired pawn can be destroyed while pooled or during a later wave.
- Direct writes to `CurrentHealth`/`bIsDead` do not call the component's full revive/reset events.
- Pack health/death state is not reset.
- Controller memory, suppression, cover reservations, commands, fire state, delayed timers, and late async callbacks are not comprehensively cleared.
- Ragdoll/death timers can still fire after wake.
- `Release()` silently does nothing for a fallback-spawned pawn not present in the pool.
- `GetAvailableCount()` counts availability flags without purging invalid weak entries.

This confirms the Pass 3/4 conclusion: pooling must be an explicit lifecycle interface, not a visibility/health toggle.

---

## 5. Standalone `ACombatEncounterVolume`

This is a third, self-contained combat authority:

- player overlap starts it,
- it directly spawns `AEnemySoldier` waves around the volume,
- it polls alive weak references every 0.25 seconds,
- it spawns supplies/turret independently,
- it owns completion and optional global slow motion.

Findings:

- `EncounterType` is cosmetic; all enum variants execute the same flow.
- If a wave produces zero enemies, `ActiveEnemies.Num() == 0` prevents wave-clear detection and the encounter stalls.
- `ResetEncounter()` empties arrays/flags but does not destroy living enemies or supplies.
- There is no pool, fireteam, coordinator, mission-chain, HUD, XP, or save integration.
- It directly sets global time dilation to 0.35 and later to 1.0, with no ownership/arbitration against other cinematic systems.
- No `EndPlay` cleanup exists for enemies or logistics.

`ADestroyedVillageCompoundActor` spawns this encounter at runtime and configures it after `BeginPlay`. Its default supply setting is already true, but any BeginPlay-sensitive property would have the same deferred-configuration problem.

---

## 6. Save/load and mission reconstruction

### 6.1 What is persisted

The main save stores:

- player transform/native health/native weapon ammo,
- allies by runtime object name, transform and limited health/downed state,
- `ActiveMissionIndex`, title, and completed count from the first iterated `AQuestChain`,
- difficulty, supplies, and equipped weapon.

### 6.2 What is not persisted

It does not identify or reconstruct:

- which chain the three saved chain fields belong to,
- stable mission IDs,
- `AMissionZone` state beyond an inferred index,
- Defend time remaining or Clear counts,
- either spawner's wave/batch/timers/alive members,
- spawned enemy identity/health/location,
- `AQuestDirector`, `AQuestMission`, objectives, quest log bytes, or GPS goal,
- combat encounters,
- procedural supplies, consumed pickups, barrels, generated actors, fires, weather, dust, or barrage,
- world-partition cell-specific state.

`TotalWavesCleared` exists in the save object but is not gathered/restored by this flow.

### 6.3 Restore ordering hazards

Post-travel apply waits until `World->HasBegunPlay()`. By then:

- an auto-start chain with zero delay has already started mission zero,
- linked spawners may already have prewarmed and spawned enemies,
- procedural buildings/villages/encounters have already generated actors and supplies.

Restore calls `SilentResetForLoadRestore()` on mission zones, but that only stops/deactivates spawners. For the template stack it does not remove living enemies; even legacy deactivation does not reset them. The saved mission is then activated from its beginning, potentially retaining or duplicating pre-restore combat.

Restore selects the first iterated chain that has `bAutoStart == true`, then breaks. A manually started chain cannot be restored; multiple chains are ambiguous. A completed chain is reconstructed by directly writing state, while active missions restart from their beginning rather than from the saved wave/timer/objective state.

This is checkpoint-style persistence presented as full tactical state persistence. The product needs to choose and document one of two models:

1. **Checkpoint restore:** save stable chain/mission checkpoint IDs, intentionally wipe transient combat, regenerate deterministically, and respawn at the checkpoint.
2. **Full encounter restore:** serialize each authority, spawner, actor, timer, health, and procedural object with stable IDs.

The first model is much smaller and more reliable for this project.

---

## 7. HUD and mission authority mismatch

`AQuestNativeHUD` is the intended gameplay HUD. It explicitly collapses the older quest UMG widgets, including `QuestHUDWidget`, `QuestMissionWidget`, mission briefing/minimap/compass widgets, and pack HUD classes.

But its mission cards, Defend banner, pips, guidance goal, compass/minimap mission data, and chain progress are driven by `AQuestChain`/`AMissionZone`, not `AQuestDirector`/`AQuestMission` snapshots.

Additional issue: `FindQuestChain()` caches the first valid chain forever. It does not reselect when that chain becomes inactive and another chain starts. Therefore multiple operations can leave objective card, guidance, pips, minimap/compass, and Defend UI stale.

The tag/objective system still publishes a UMG-oriented `FQuestHudSnapshot`, but the native HUD suppresses the consumer stack. This makes that mission authority largely invisible in the current intended HUD path.

---

## 8. AI mission-goal consumption

### 8.1 `STTask_EnemyMission`

The task prioritizes:

1. a known threat within 12,000 cm,
2. the player within 12,000 cm even without current perception,
3. the active mission goal.

The 12,000 cm cap is an improvement over unbounded pursuit, but it still creates omniscient player hunting inside 120 meters and means mission movement is preempted by combat memory/direct player range.

### 8.2 Direct leader mission pathing

The controller resolves goal sources from mission commands/chain/GPS/fallback zones and applies spline/fire adjustment. The fallback `AQuestZone` cache is a function-static weak pointer shared by all controllers and world contexts. If no effective goal exists, it chooses an arbitrary first zone.

This can cross-contaminate PIE worlds and send leaders to unrelated zones. It also compounds the stale `CurrentActiveGoal` and multiple-chain ambiguity.

### 8.3 Spline guides

`ASplinePathActor` has a useful matching registry, mission gates, hazard skipping, corridor slots, and an opt-out. However:

- leader follow locations lie on the spline centerline; `WanderAmplitude` is never used,
- an explicit `ToMission` match has no proximity limit, so a distant mapped spline can capture a leader,
- legacy marching advances by elapsed distance, not actual squad progress,
- all allies are commanded to the same marching point,
- marching can complete while allies are blocked, dead, or absent.

The header describes a soft wandering corridor; current direct leader behavior is a centerline guide.

---

## 9. Scene decoration, fire, and barrage

## 9.1 `ASceneDecorator`

Strengths include editor/runtime rebuild support, instance-component ownership, hazard collection for AI avoidance, spacing attempts, ground-trace fallbacks, cull configuration, debug probes, and delayed build scheduling.

Findings:

- Delay is per decoration entry, not per spawned instance. One callback can still create a large entry all at once.
- Spacing is enforced only within one entry; effects from different entries can overlap.
- Fire hurt boxes target player zero only, not AI/squad/world actors.
- The health-component detector treats native `UHealthComponent` as a third-party pack component. It then attempts reflected pack health functions instead of native damage. **A native player therefore receives no decorator-fire damage.**
- Burn state is one boolean per decorator. Multiple decorators/fires are not reference counted; leaving one can clear the native HUD overlay and pack burning state while another fire remains active.
- Missing player/box paths can leave burn state stuck.

## 9.2 `AFireDamageZone`

The standalone variant handles native `ASoldierCharacter` directly, but:

- it directly subtracts reflected pack health properties, bypassing pack damage, death, attribution, and HUD contracts,
- one `bPlayerInside` boolean cannot represent multiple component overlaps; an EndOverlap can stop damage while another overlap remains,
- overlapping zones fight over the same native HUD burning boolean and pack fire state,
- destruction has no explicit overlay/audio cleanup.

The two fire implementations should share one overlap/reference-counted status-effect service and one damage bridge.

## 9.3 `APathExplosionBarrage`

The warning, scheduling, FX budget, audio layers, camera concussion, suppression, mission linkage, and cleanup of pending warning discs are substantial.

Damage defects:

- it damages player zero separately, then queries all registered soldiers. A native player present in `USoldierRegistrySubsystem` is damaged twice,
- player distance is 2D while soldier distance is 3D, so the player can be hit across large vertical separation,
- non-native targets receive generic `ApplyDamage` and then direct reflected health subtraction, risking duplicate pack damage while bypassing pack death/HUD semantics,
- placement traces only `ECC_WorldStatic`, so valid landscapes/custom collision on other channels can fail.

The barrage follows only `AMissionZone`/`AQuestChain`, not tag missions or standalone encounters.

## 9.4 `ABattlefieldDecorator`

The archived component-tracking bug is fixed: spawned Niagara/Cascade components are now stored and destroyed on deactivation.

Remaining issues:

- activation uses `SpawnCount`; each loop interval spawns only one effect per entry,
- `SpawnedEffects` is never compacted while active, so auto-destroyed component references accumulate; persistent effects accumulate until mission end,
- `EffectType` is descriptive only,
- when both Niagara and Cascade are assigned, only Niagara spawns,
- loading/streaming the decorator after its linked mission is already Active misses the event and leaves effects off unless `bAutoActivate` is true,
- placement traces only `ECC_WorldStatic`.

---

## 10. Weather and atmospheric dust

## 10.1 Sandstorm

`ASandstormWeatherDirector` implements phase/intensity interpolation, audio, events, and an AI visibility multiplier. `ASoldierAIController` now reads that multiplier every 0.5 seconds and reconfigures sight/lose-sight radii from clean-weather baselines. This archived defect is genuinely fixed.

Limits:

- it does not directly control fog, lighting, sky, post-process, or particles despite the weather-director description,
- it does not clear existing perception memory/current targets,
- hearing, damage sense, registry close-range recognition, 1,800 cm no-LOS combat overrides, and 12,000 cm direct player mission pursuit remain unchanged,
- each controller selects the first director found; multiple directors have no arbitration,
- when `bAutoCycle == false`, `Tick()` returns before phase timers advance. `TriggerSandstorm()` remains in Approaching and `StopSandstorm()` remains in Dissipating rather than completing manual transitions,
- fade-out nulls the audio pointer immediately, allowing a quickly retriggered storm to overlap the old fading component.

## 10.2 Atmospheric dust

The archived bare-`AActor` fallback is fixed; failure to resolve `HeterogeneousVolume` now skips spawning.

Remaining mismatches:

- `FDustZone::Radius`, `ParticleCount`, and `ParticleScale` are ignored; only manual center is used,
- “closest zones” are not sorted by player distance; generation order wins the budget,
- comments describe radius multipliers of 1.6/1.8, but squared thresholds are multiplied by 1.6/1.8, yielding actual radius multipliers of about 1.26/1.34,
- actor volumes are spawned/destroyed rather than pooled despite the header's pooling claim,
- auto anchors are fixed around the scatterer actor, not regenerated around the player,
- ground-trace failure retains an unsnapped point,
- a streamed-out scatterer stops the whole local-dust service, so an open-world deployment needs explicit always-loaded or cell-local ownership.

---

## 11. Procedural villages, buildings, trenches, and barrels

## 11.1 Buildings and villages

`ADestroyedBuildingActor` builds deterministic HISM-heavy geometry from `GenerationSeed`, then spawns supplies, turret, barrel, and optional defenders. `ADestroyedVillageCompoundActor` arranges buildings, street actors, perimeter actors, an encounter, and a cover generator.

Lifecycle/integration findings:

- Each actor rebuilds automatically in `BeginPlay`, so editor-built state is destroyed/regenerated at runtime.
- The village spawns a building normally; that building runs `BeginPlay` and builds with defaults before the village sets style/seed/materials and calls `BuildBuilding()` again. This causes an unnecessary full build/spawn/destroy cycle per building.
- Runtime child actors are spawned without `Owner` and only attached afterward. Building/village/trench classes have no `EndPlay` cleanup. World Partition stream-out can leave persistent-level children orphaned.
- Streaming/reloading regenerates consumed supplies, barrels, turrets, defenders, and encounters because none has stable persistence.
- `CustomVillageRubbleMesh` is exposed but never forwarded to spawned buildings.
- Building documentation claims tactical cover points, but the building class creates none. The village optionally creates one separate cover generator.
- Runtime geometry creation has no explicit navigation rebuild ownership.
- Hundreds of village wall/barricade elements are separate `AStaticMeshActor`s rather than a village-level instance set.

The runtime village also spawns `ACombatEncounterVolume` and configures it after `BeginPlay`, reinforcing the general need for deferred spawning (`SpawnActorDeferred` + configure + finish) and explicit ownership.

## 11.2 Tactical trench spline

The trench actor builds HISM barricades and spawns supplies/turrets along a spline.

Findings:

- documentation promises automated low/high cover points, but no cover points are generated,
- `FloorToInt(TotalLength / Spacing)` means a non-multiple tail is not covered and the “end” turret is placed before the actual spline endpoint,
- runtime `SupplyCacheInterval <= 0` is not guarded; metadata clamps only editor entry, and zero can spawn a cache at every segment,
- spawned supplies/turrets have no owner and no EndPlay cleanup,
- runtime rebuild/streaming replenishes logistics.

## 11.3 Explosive barrel

The barrel correctly listens to generic damage, uses a fuse, applies radial damage with LOS prevention, reports an AI hearing event, resolves an audio fallback, broadcasts, and destroys itself.

But its advertised behavior exceeds implementation:

- `ExplosionImpulse` is never read; no physics impulse is applied,
- surviving AI are not suppressed; the suppression loop only adds native HUD suppression when a registered soldier is player-controlled,
- there is no explosion visual property/use despite the class description and unused particle forward declaration,
- pack radial-damage/death behavior depends entirely on external pack AnyDamage handling,
- barrels are not persisted and will respawn with procedural generators.

---

## 12. Comparison with archived `STEP5_MISSIONS.md`

The current source contains explicit `S5-*` changes addressing the archived list. The archive is useful history, not current truth.

| Archived finding | Current status | Remaining concern |
|---|---|---|
| `FailMission` had no caller | **Fixed** | Default player death now revives then fails/retries; save and HUD semantics remain fragmented |
| Unused Defend timer handle | **Fixed/replaced** | Periodic defend-wave timer is now armed, but repeatedly restarts template spawners without cleanup |
| AutoZone mode hardcoded Reach | **Partially fixed** | Explicit modes work; Auto still means Reach, spawner is not started, runtime auto-zone registration is broken |
| Failed `AQuestMission` stalled director | **Fixed** | Failure now skips to next mission rather than retry/game-over |
| Quest log never recorded | **Fixed at runtime** | `ToBytes`/`FromBytes` still have no save integration |
| Two spawner stacks disconnected | **Partially fixed** | MissionZone can drive both, but reset/events/completion/pooling remain incompatible; mixed-stack early completion exists |
| Pool never prewarmed | **Fixed** | Lifespan, full reset, pack state, callbacks, invalid entries, and ownership remain broken |
| Battlefield FX never tracked | **Fixed** | Active-loop accumulation, stale references, and SpawnCount inconsistency remain |
| Weather visibility multiplier unread | **Fixed** | Sight only; direct pursuit/memory/visual weather remain unaffected; manual transitions stall |
| Dust fallback spawned bare actor | **Fixed** | Other dust configuration/documentation mismatches remain |
| Pack actors invisible to zone hostile count | **Attempted** | Generic-team + visible approximation can still miss pack pawns or count visible corpses indefinitely |

The independent pass also found issues absent from the archived report: a third mission authority, fatal runtime AutoSpawn ordering, mixed-stack completion, delayed-load contamination, native decorator-fire immunity, overlapping burn-state conflicts, barrage double damage, spline explicit-distance capture, procedural-child World Partition ownership, unused trench cover promise, unused barrel impulse/suppression, and several persistence gaps.

---

## 13. Prioritized correction order

### P0 — choose contracts before implementation

1. Select the canonical mission authority:
   - recommended: `AQuestChain + AMissionZone` as runtime authority,
   - either retire `AQuestDirector/AQuestMission` or adapt it into the same interface,
   - make `ACombatEncounterVolume` a mission-owned encounter component/service rather than a third campaign.
2. Define save semantics: deterministic checkpoint restore is recommended over serializing live combat.
3. Define one damage bridge for native and third-party pack actors; prohibit direct reflected health writes outside it.
4. Define an explicit pooled-enemy reset interface.

### P1 — correctness blockers

1. Convert runtime parent-child creation to deferred spawn and configure before `BeginPlay`.
2. Assign `Owner`, explicit level/cell ownership, and `EndPlay` cleanup to every generated child.
3. Give `AWaveSpawner` a real `ResetWaves(bool bDestroyOrReleaseLiving)` and generation-safe death ownership.
4. Fix legacy final pack-death polling and clarify “spawn schedule done” versus “combat clear.”
5. Persist stable chain/mission checkpoint IDs; prevent auto-start until restore intent is known.
6. Make native HUD query a current mission-provider interface instead of caching one chain forever.
7. Fix decorator fire's native health path, overlap reference counting, and burn-effect cleanup.
8. Deduplicate barrage victims and route pack damage through the bridge.
9. Cancel lifespan/death timers and fully reset native/pack state on pool release/wake.

### P2 — open-world/systemic behavior

1. Make chain/director discovery streaming-aware or register mission providers dynamically.
2. Reconcile AI mission goal priority with perception and weather; remove static cross-controller zone caching.
3. Put proximity limits on explicit spline guides and implement or remove `WanderAmplitude`.
4. Decide whether sandstorm owns visuals and make manual Trigger/Stop complete with auto-cycle disabled.
5. Compact BattlefieldDecorator effects and honor loop count semantics.
6. Correct procedural documentation or implement claimed cover, impulse, suppression, dust-zone, and encounter-type behavior.
7. Add configuration validation for empty waves, batch size, classes, intervals, duplicate chain ownership, and save IDs.

### P3 — validation

After the contracts above are chosen, add automated/PIE scenarios for:

- two chains and streamed mission cells,
- auto-zone Reach/Clear/Defend,
- native and pack enemies in both spawner stacks,
- death during final pack wave,
- retry/load with living old enemies,
- pool release/reacquire beyond ten seconds,
- overlapping fire sources,
- native player registered as soldier during barrage,
- manual sandstorm with auto-cycle off,
- stream-out/reload of villages, trenches, and procedural supplies.

---

## 14. Product decisions needed before substantial code changes

1. Which mission authoring workflow is actually used in the working maps: MissionZone/QuestChain, QuestDirector/AutoZone, CombatEncounterVolume, or a mixture?
2. Should a failed mission retry, show game over, restart the whole chain, or be skipped?
3. Should loading resume the exact active wave, or intentionally restart the mission from a checkpoint with transient enemies wiped?
4. Are procedural villages/buildings intended to be editor-baked static content, or runtime World Partition generators?
5. Is the playable pawn native `ASoldierCharacter`, a third-party pack character, or selectable between both?
6. Should environmental fire/barrage damage allies and enemies, or player only?

Until those are answered, local fixes risk strengthening the wrong authority and increasing migration cost.

---

## Final Pass 5 assessment

The mission/open-world code has many strong local features—designer-facing actors, mission events, wave templates, pooling intent, spline guidance, procedural dressing, weather hooks, audio/FX integration, and extensive diagnostics. The main problem is not lack of functionality. It is **lack of one ownership model across mission, spawn, damage, HUD, save, and World Partition lifecycle**.

Current code can work in a carefully authored, always-loaded, single-chain map using native enemies and no mid-combat load. It is not yet reliable as a general UE 5.7 open-world campaign framework with streamed missions, runtime procedural settlements, mixed native/pack actors, retries, and saves.

No module source was changed during this pass.

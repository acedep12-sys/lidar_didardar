# Round-2 fix packages — your reported bugs + remaining found defects (2026-09-21)

**⚠ Deployment: use the cumulative files, not the per-package patches.**
Everything from L1 + B1 (previous round) + B2 + B3 (this round) is merged into 9 files under
`patched/SquadAI/`. Copy these 9 files over the same relative paths in your project's
`Source/SquadAI/` (keep your originals as backup as usual), then rebuild. The
`fixes_ALL_cumulative.patch` is the same change as one review diff; `fixes_B2_gameplay_infra.patch`
and `fixes_B3_menu_polish.patch` are the per-package splits for reading.

*Not compiled here (no UE 5.7 toolchain in this environment). Paste any build error verbatim
and I'll fix immediately.*

---

## 1. Old TPW UI visible + new HUD parts (top-right gun/bullets) missing + old UI over the loading screen — FIXED (P6-6/P6-7)

**Root cause (two-sided):** after the F-G12 patch narrowed the suppression from blanket `WBP_*` to a
class-name list, any old-interface widget whose class name does NOT match those exact substrings
slips through — the pack's health-bar HUD is one of those. UMG viewport widgets render **on top of
the Canvas HUD**, so the leaked old widget was *covering* the new top-right weapon plate (the plate
was drawn correctly all along — I verified; it was hidden behind the leaked widget). The same leak
sits above the loading screen during travel.

**Fix (`QuestNativeHUD.cpp/.h`):** suppression is now **deny-by-default** via an explicit ownership
allow-list:
- Every `UUserWidget` on the game viewport is collapsed **except** (a) widgets the module itself
  registered (the loading screen registers itself) and (b) `SquadAI*`-prefixed classes.
- Your old pack HUD — regardless of its class name — gets collapsed every sweep, forever.
- Widgets already collapsed are skipped, so the sweep still idles at 10 s when there's nothing to do
  (no perf cost). Loading-screen ordering is untouched (ZOrder 1000 + allow-list).
- Your SquadAI Canvas UI is not a widget, so it can't be suppressed by anything — it just needed
  the old covering layer gone.

*Fallback note:* collapse is used instead of destruction (safe for pack state). If you ever see the
old HUD flash briefly because the pack re-forces visibility, tell me and I'll escalate the sweep to
`RemoveFromParent`.

## 2. Difficulty select sits "thinking" before the loading screen appears — FIXED

**Root cause:** `LoadLevelWithScreen` spawned the loading widget and called the blocking
`OpenLevel` in the **same frame**, so the screen painted ~0 frames; the menu froze while the map
loaded and the loading screen only appeared afterwards.

**Fix (`SquadAILoadingScreenSubsystem`):** travel is now deferred 0.25 s on the core ticker
(survives world teardown) — the loading screen paints immediately when you pick a difficulty,
*then* the map begins loading. The feel: click → instant loading screen → wait there, as you wanted.

## 3. FPS drops in the first seconds after entering the game — FIXED (improved)

**Root cause:** the loading handshake released on "world begun + player controller + 1 second"
(30 s failsafe). At that point wave-spawner bursts, cover baking, level streaming and shader
first-use were still running — the loading screen's whole purpose is to hide exactly that work.

**Fix:** the handshake now waits for: begun-play **+ streaming levels loaded & visible + player
pawn possessed** (pawn optional after 6 s for menu destinations), **plus a 2 s settle buffer** after
all conditions hold — so spawn/cover/shader work finishes behind the loading screen, and the
"Press Enter to deploy" gate only appears when the world is genuinely ready. 30 s failsafe kept.
Also fixed **P6-7**: if the destination's loading widget failed to spawn (PC-not-ready race), it is
now retried every 0.25 s instead of vanishing silently.

## 4. Enemies no longer run to the quest zone — FIXED

**Root cause (the real regression):** `RunDirectEnemyMovement` was gated behind
`CurrentLODBucket < 5`. The significance manager assigns **bucket 5 (Dormant) to anything far from
the player** — and your waves spawn far away *on purpose* (correct design, untouched). Result:
every distant enemy got frozen by the LOD gate and never moved.

**Fix (`SoldierAIController.cpp`):**
- Movement now runs in **every** LOD bucket (it's cheap — it self-throttles move re-issues to
  2.5–3 s; distant controllers already tick at a coarse interval).
- Hardened the goal fallback: if the quest chain isn't active yet (start delay / save restore) or
  the active mission isn't Clear/Defend, enemies now fall back to any chain's current assault
  mission → any Clear/Defend zone in the world → any mission zone — they will always advance
  instead of standing at the spawn point. You'll see them running to the zone again, and spawning
  stays out of the player's sightline as intended.

## 5. Watermark emblem looks low quality / shadowy — FIXED (4 draw sites)

- Big bottom-right emblem: was a **flickering 0.145–0.195 alpha "lantern" pulse** (that's the
  shadowy look) → now a **stable 0.55 alpha**, true untinted colors.
- Profile crest (top-left): was drawn with a **Brass × 0.95 color multiply** (darkens/tints your
  logo) → now full white tint, full opacity.
- Top-pill crest: was warm-tinted at 0.88 alpha → full white, full opacity.
- Map-panel crest: was `Brass * 0.72f` → full white.
Your PNG is drawn as-is — no new image needed; the "low quality" came from those fade/tint
multipliers, not your art. (If you want the big one more/less visible, it's now a single `0.55f`
constant.)

## 6. Bottom stat ribbon (Level/Ops/Accuracy/Hours/XP) — FIXED

- The number sat at **Y+35 while the glowing icon base reaches ~Y+42** (that's why they felt fused
  together). Number moved to **Y+43 — centered between icon and label**, label to Y+68.
- The number was drawn **flat with no shadow** (left buttons use Title + drop shadow = why theirs
  look crisp). Number now: **TitleFont, scale 1.02→1.12, drop shadow ON** — same font/depth
  pipeline as the left buttons.

## 7. Tiny description fonts in Progression / Dossier / Battle record / Equipment / Operations — FIXED

26 `BodyFont` description call sites across `DrawMapSelectScreen`, `DrawArmoryScreen`,
`DrawPlayerProgressionScreen` and `DrawPlayerProfileScreen` were bumped **+0.14 scale**
(≈ +5 px at the 36 pt reference you measured by) — e.g. `0.66f → 0.80f`, `0.72f → 0.86f`,
`0.62f → 0.76f`. The exact list is in the patch; every one is a single number if you want
individual tweaks, and the bounded draw's auto-shrink still prevents any overflow.

## 8. Quick Start button — RESTYLED

Removed the old flat custom plate and the hand-drawn thin ">>" strokes (that's what read as ugly),
and replaced it with the **same beveled 3D reference-panel treatment the left menu buttons use**:
3D frame + hover lift + gold top accent, plus a **depth-shadowed double chevron** (crisp 3D
affordance instead of flat lines). The "Quick Start" text now goes through the identical
TitleFont + drop-shadow pipeline as the left buttons (its previous low-quality look came from the
cluttered plate behind it, not the font itself).

## 9. Persian words merged (`جبهه‌ها` → `جبههها`) — FIXED (root cause, affects everywhere)

**Root cause:** the shaper (a) **deleted the ZWNJ character (U+200C)** from the output and
(b) treated it as *transparent for letter joining* — so letters joined across every ZWNJ and no
gap was ever emitted. There are **182 ZWNJ usages** in the shipped menu/HUD strings (149 in the
main menu alone) — all of them were rendering merged.

**Fix (`FarsiTextHelper.cpp`):** ZWNJ is now **emitted** (fonts render the small intra-word gap
themselves) and is a **hard join boundary** (only tashkeel stays join-transparent). One 2-spot
change, every string in the game benefits — `دست‌نوشته`, `می‌رود`-style constructs, half-spaces
everywhere. Also fixes the museum-swap: **`همیشه جاری`**, `ماموریت‌ها و جبهه‌ها` etc. (This is
shaping-level, so your own texts in the INI are fixed too.)
*Note: your Persian UI font must contain U+200C — every Persian font includes it; if you ever see
a hollow box where a half-space should be, tell me which font asset is assigned and I'll add a
substitution.*

## 10. Arabic language added — DONE (infrastructure + core texts)

- **Language tri-cycle** in Settings: فارسی → English → **العربية** (saved, boots in Arabic).
- New `ApplyArabicPreset()` with full Arabic main-menu core (title, subtitle, all 14 buttons,
  difficulty cards) — consulted from the INI first, Arabic defaults otherwise.
- **Localization chain (important):** with language = `ar`, lookup order per key is
  `[Section.ar] Key` → `Key_ar` → **built-in English** → Persian base → call-site default.
  An Arabic player **never sees Persian**; anything not yet localized to Arabic falls back to
  English, not Persian. (The built-in English fallback was previously en-only; it's now the
  fallback for all non-Persian languages.)
- Arabic shaping works: the glyph table already covered Arabic Kaf/Ye/Teh-Marbuta/etc., and the
  ZWNJ fix above applies to Arabic as well.
- `SquadAILocalization_AR_ADDON.ini`: full Arabic `[*.ar]` sections for MainMenu / PauseMenu /
  Loading / HUD / Inventory / Armory — paste into your master INI (or grab
  `SquadAILocalization_v2_MASTER.ini`, now regenerated **with** these sections appended; the
  auto-created template carries them too). Quran tab needs nothing — its base strings are Arabic
  already.
- *Remaining for a later pass:* fallen-notes bodies and radio station names still need Arabic
  translations (they'll show short English placeholders until then — say the word and I'll write
  them), and the hardcoded bilingual surfaces (map cards, traits, profile page = the INI "L2
  wiring" list) are currently English-fallback under ar.

## 11. Your question — swapping the mannequin in `BP_Leader_PackClean_Auto` for your character (weapon leaves the hand) — answer: YES, fixable later without touching animations

The animations are fine — the weapon is attached to a **socket / bone name on the mannequin's
skeleton** (typical: a custom `weapon_r`/`ik_hand_gun`-family socket the pack bridge queries by
name). When you swap the skeletal mesh to your character, that named socket **doesn't exist on
your skeleton**, so the attach code silently falls back (root/hand bone) and the weapon floats.
The clean fix — no animation changes, no retargeting — is a **socket-mapping layer in the attach
bridge**: resolve the socket by name, if missing use a per-skeleton override table (your skeleton's
hand bone) or read an offset transform. We can also add the socket on your skeleton in the editor
(zero-risk, 5 minutes) once we know which name the bridge asks for — I'll trace the exact socket
name from the pack bridge code when we do this phase.

---

## Verification checklist after rebuild

1. In game: no old health bar / pack widgets anywhere, top-right SquadAI weapon plate visible,
   loading screen clean (no pack UI on top).
2. Menu → New Game → pick difficulty: loading screen appears **immediately**, waits there, deploy
   prompt only when world is ready → no/far less hitching on entry.
3. Start a defense/clearing mission: distant enemies visibly advance toward the zone; the close
   test enemy behaves as before.
4. Menu: emblem crisp and steady in all spots; stat numbers clearly seated between icons and
   labels, with depth; descriptions in the five pages readable; Quick Start matches left buttons.
5. Any ZWNJ phrase (e.g. `ماموریت‌ها و جبهه‌ها` on the operations card) renders with proper
   half-spaces — please eyeball a few other screens for me.
6. Settings → Language cycles through three entries; العربية shows Arabic core menu + English
   fallback elsewhere; `SquadAI.ReloadText` after INI edits still hot-reloads.

## Still on the table (your call, next phase)

- **L2 full INI wiring** — makes every remaining hardcoded bilingual surface INI-editable
  (map cards, traits, profile, tips, tabs, stat labels, counters, leader/wounded labels…). Your
  wording is already staged in the master's `⏸ RESERVED` block.
- **UMG policy** — delete the 5 compiled-but-suppressed widget classes or keep with the new
  opt-in registration API (P6-6 made suppression explicit; the classes themselves are still there).
- **Pass-5 structural work** — canonical mission authority, stable checkpoint IDs, spawner reset
  contract, one damage bridge, WP child ownership.
- **Arabic completion** — fallen notes + radio names translation (offer).
- **Character swap phase** — the weapon-socket mapping from item 11.

## Missing from this round — please re-send

- The **main-menu screenshot** and the **other AI's study notes** you mentioned did not come
  through as attachments — only the localization `.txt` arrived. Please attach them again; with
  the screenshot I can do the pixel-color/detail pass you hinted at (e.g. exact ribbon spacing,
  emblem edges), and I'll mine the notes + nested docs for design intent conflicts.

---

## Pixel-Verification Polish Pass (screenshot `Screenshot 2026-09-21 172149.png`)

The main-menu screenshot was re-sent and analyzed pixel-by-pixel (exact RGB sampling, not eyeballing). Findings and what changed:

### Verified against pixels (no action needed — Round 2 fixes were correct)
- **Merged Persian words confirmed at 3x zoom**: subtitle renders `ماموریتها و جبههها` while the source string is `ماموریت‌ها و جبهه‌ها` (ZWNJ present) → root cause was the shaper dropping U+200C (already fixed in the Farsi helper).
- **Quick Start "battered" glyph mystery solved**: the old title used `RefGoldText` (dark gold) — pixel median `(149,119,59)` ≈ 0.7× the left labels' near-white `(167,145,98)` — thin dark-gold strokes over the bright plate are exactly what read as "low quality". Fix below.
- **"کارنامه نبرد" is correct** (3x zoom shows the ن dot; earlier read "تبرد" was a misread).
- **"Version 1.0.0 AR" does not exist** — it was the XP counter `۱۷۰۰ / ۱۲۰۰۰` misread at thumbnail scale.
- **Green carousel dot** in آخرین گزارش is intentional (`0x14C819` sampled from the owner's reference).

### Fixed in this pass (all in `SquadAIMainMenuHUD.cpp`)
1. **Emblem — 2 draw sites were still tinted** (Round 2 caught 3 of 5):
   - Mission card crest (`سقوط خوزستان`, 52px, top-right of card): `Brass * 0.74f` → **`FLinearColor::White`**. Screenshot proof: its highlight pixels averaged `(103,65,25)` vs the header crest's `(143,87,29)` → **0.72× exactly** — the tint multiply measured in-game.
   - Portrait-fallback emblem (visible only when avatar art is missing): `Brass * 0.82f` → **`White`** for consistency.
   - All five `UI_Military_Watermark_Emblem.png` sites are now: full white tint (texture-native colors), stable alpha — 0.55 for the 220px backdrop watermark, 1.0 for the four placements.
2. **Stat ribbon numbers — pixel-calibrated placement**: icon band measured `y 886–920`, labels `y 962–969` → gap midpoint `y≈945`. Value moved `StatsY + 43` → **`StatsY + 46`**, scale `1.12` → **`1.15`**, drop shadow kept ON, still `TitleFont` (proven to carry Persian digits — the difficulty cards draw `۰۱`–`۰۴` with it).
3. **Quick Start title — exact left-button recipe**: now `MenuFont` scale `1.15`, color `TextBright` (near-white) idle / `RefLabelBright` on hover, one tight drop shadow — the identical pipeline that produces the left labels the owner praised. Subtitle switched to `TextMuted` to match the left buttons' title/muted-subtitle hierarchy. Title shifted `+14` → `+20` to center the text stack against the row.

### Deploy
Same as before — replace `Source/SquadAI/` with `patched/SquadAI/` (9 cumulative files), or apply `patched/fixes_ALL_cumulative.patch` (regenerated; round-trip byte-verified against originals). This pass touches **only** `SquadAIMainMenuHUD.cpp`; every other Round-2 file is unchanged.

# SquadAI — Round 9 — Tactical Trench Seeded Variation (S6-T)

## Finding
The trench spline builder produced a perfectly uniform parapet: identical
(0.45, 2.0, 0.85) bags at exact spline spacing under one rotation — reading like
concrete barriers, not dug-in earthworks.

## Changes (2 files: TacticalTrenchSplineActor.{h,cpp})
| Piece | Change |
|---|---|
| S6-T seed/tone | `TrenchSeed` UPROPERTY re-seeds `TrenchStream` every BuildTrench; one warm DMI tint per build (`TintTrenchMaterial`, candidate-name reflection, silent on plain materials) |
| PlaceBag lambda | One unified HISM/actor placement call used by every variant — variation lives in BOTH rendering paths at zero extra cost in HISM mode |
| Segment jitter | ±8cm along / ±6cm across, ±4° yaw, ±1.5° tilt, ±10% length/height per bag |
| Double tiers | 40% of segments get a staggered second firing-tier on top (62cm up, 65–85% length) — classic parapet build-up |
| Battle gaps | 8% of MID segments (never the mouths) become sunken partial bags — ragged firing gaps through the wall |
| Debris bags | 15% chance of a half-buried torn bag beside the wall base |
| End caps | Perpendicular closure bags at both trench mouths |

Flags (all in *Trench Variation*, default ON): `bSeededVariation` master +
`bDoubleLayerBags`, `bBattleGaps`, `bEndCaps`, `bBrokenBags`, `ToneJitter`,
`TrenchSeed`. With every flag OFF the build is byte-identical to the old uniform
wall (same transforms, same counts).

## Verification
Braces/parens balanced both files; 5 PlaceBag call sites; all header members
machine-checked; RandomStream include added to header.

_Delta on batches 1–4 + Rounds 7–8: `TacticalTrenchSplineActor.{h,cpp}`._

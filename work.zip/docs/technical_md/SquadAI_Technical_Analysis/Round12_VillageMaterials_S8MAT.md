# Round 12 — S8-MAT: Village Materials, Textures & Palette

## The problem found by audit

The building generator resolved materials properly (override → related override →
`/Engine/BasicShapes/BasicShapeMaterial`) and tone-varied them through a per-building DMI.
**The village did not.** All 22 prop spawn sites passed a possibly-null `TObjectPtr`
straight into `SetMaterial(0, ...)`:

- With no art assigned, every road, wall, catwalk, sandbag and rubble mound fell through to
  the engine default **grey `WorldGridMaterial`**, while the buildings *inside* the same
  village rendered in `BasicShapeMaterial` — a visible mismatch out of the box.
- Only roads and scorch patches had tints. Mudbrick, timber, hessian and broken masonry all
  read as one undifferentiated surface.

No new textures or meshes could be authored (user art rule), so the fix is **resolution +
runtime tinting** of whatever material is present.

## Category model

| Category | Id | Covers |
|---|---|---|
| Wall | 0 | mudbrick walls, compound/courtyard walls, gate posts, well ring |
| Rubble | 1 | rubble mounds, debris, monument column + toppled cap |
| Floor/Road | 2 | road ribbons, plaza pad, cross alley, scorch quads |
| Wood | 3 | catwalks, telegraph poles, lintels, A-frame, crates, cart planks |
| Sandbag | 4 | plaza barricades, perimeter defensive arcs |

## `ResolveVillageMaterial(Category)`

Fallback chains, mirroring how the building generator pairs its slots:

- Wall → Wall, Rubble, Floor
- Rubble → Rubble, Wall, Floor
- Floor → Floor, Rubble, Wall
- Wood → Wood, Wall
- Sandbag → Sandbag, Wall
- **all → `BasicShapeMaterial`** (via the asset-cache subsystem, one cached load)

Result: the village can never render default grey, and an un-authored village matches its
own buildings exactly.

## Palette (`bApplyVillagePalette`, default ON)

Per-category runtime DMI tints, so categories separate visually even when they share one
base material. Applied through the existing `VillageTint` candidate-parameter probe
(`Color`/`BaseColor`/`Tint`/`BaseColorTint`/`Albedo`/`Colour`) — a **silent no-op** on
materials with no colour parameter, so authored PBR art is never damaged.

| Property | Default | Reads as |
|---|---|---|
| `WallTint` | 0.72, 0.62, 0.47 | sun-bleached desert plaster |
| `RubbleTint` | 0.46, 0.42, 0.36 | cool grey-brown broken masonry |
| `WoodTint` | 0.38, 0.26, 0.16 | weathered sun-dried timber |
| `SandbagTint` | 0.44, 0.41, 0.28 | dusty olive hessian |
| `RoadTint` *(existing)* | 0.30, 0.25, 0.18 | packed dirt |
| `ScorchTint` *(existing)* | 0.09, 0.08, 0.07 | blast soot |

Turn `bApplyVillagePalette` **off** when your own textured materials already carry colour;
everything then falls back to plain resolved materials.

## Buildings now match the props

`GetPalettedVillageMaterial(Category)` creates **one cached DMI per category per village**
and forwards it into every child building's `WallMaterialOverride`,
`RubbleMaterialOverride`, `FloorMaterialOverride`, `WoodMaterialOverride` and
`SandbagMaterialOverride`. The building's own S6-B per-building tone offset still layers on
top, so buildings stay individually varied *within* the village palette.

`PaletteCache` is `UPROPERTY(Transient)` (GC-safe) and cleared in `ClearVillage`, so
rebuilds and editor `RandomizeAndRebuild` pick up edited tints immediately.

## Batching interaction

Tints flow through the existing batch path: `EnsureV2BatchComponent` applies the tint **once
per HISM batch**, not per instance — so full palette colour costs 8 DMIs for the whole
village. Batch kinds, collision profiles and instance counts are unchanged.

## Dropping in your own art

1. Assign `VillageWallMaterial` / `Rubble` / `Floor` / `Wood` / `Sandbag` on the village actor.
2. Anything left empty inherits from its chain — you can ship with only `Wall` assigned.
3. Meshes work the same way via `CustomVillageWallMesh` / `Sandbag` / `Wood` / `Rubble`,
   which are also forwarded to the child buildings.
4. If your materials are already coloured, set `bApplyVillagePalette = false`.

## Verification

- Brace/paren balance: 4 touched files OK.
- 22 `SpawnVillageProp(World, this,` sites — **0** still pass a raw `Village*Material`.
- 24 `ResolveVillageMaterial(` / 22 `GetVillageCategoryTint(` uses; 0 leftover `, nullptr, /*S7-H` tint slots.
- All 5 building overrides forwarded through the palette; monument column + cap tinted.
- S7-H/S7-H2 markers and batch behaviour unchanged (7 S7-H2, 22 helper sites).

# SquadAI — Round 7 — Ownership Sweep + Village Generator V2

## S5-14c — Spawn-ownership sweep completed (5 files)

Every runtime `FActorSpawnParameters` site that created child actors without an
owner now declares `Owner = this`:
`TacticalTrenchSplineActor`, `QuickFortificationSpawnerActor` (bunkers/turrets/
supplies), `CombatEncounterVolume` (2 sites), `SplinePathActor` (path enemies),
`QuestChain` (auto-spline). `AtmosphericDustScatterer` already had it.
Result: no remaining owner-less gameplay spawn in the module (editor/dev tools and
transient projectiles intentionally excluded). Fighting under WP: consistent.

## S6-V2 — Destroyed Village Generator: visual realism upgrade

Two files: `DestroyedVillageCompoundActor.{h,cpp}`. Zero new assets — all geometry
is the existing override meshes or the `/Engine/BasicShapes/Cube` fallback; color
variation happens through runtime `CreateAndSetMaterialInstanceDynamic` which is a
silent no-op when the base material exposes no common colour parameter
(`Color/BaseColor/Tint/BaseColorTint/Albedo/Colour`).

### Defects fixed this pass
- **Street barricades + explosive barrels (step 2) NEVER ground-snapped** — they
  floated mid-air on any terrain that wasn't perfectly flat. Now per-piece traced.
- **Plaza monument column + toppled cap** shared the well's single plaza trace —
  floated or sank on slopes. Now individually traced (ignoring village children).

### Layout rework (seeded, flag: `bOrganicStreetLayout`, default ON)
Villages no longer form a mathematically even ring. A gently curving **main street**
(seeded yaw + sine wobble) anchors composition: ~60% of buildings line it on
alternating sides and FACE THE ROAD (front-to-road orientation, ±12° jitter); the
rest keep plaza-ring placement with inward faces. Same `VillageSeed` semantics.

### New realism passes (all toggleable, all in SpawnedBuildings for ClearVillage)
| Pass | Content |
|---|---|
| 7b MainRoad | Dirt-road ribbon segments along the street curve + double-rotated plaza pad + cross alleys; flattened walkover cubes, tinted `RoadTint` |
| 7c GateFrames | Makeshift gate at each street end: wall posts + wood lintel; one end INTACT, the other battle-collapsed (tilted sunk post, lintel thrown in the dirt) |
| 7d CourtyardWalls | Seeded (~62%) L-shaped low yard walls at building corners — the signature Khuzestan compound yard |
| 7e TelegraphPoles | Weathered wood posts + crossbars along the street (alternating sides, slight tilts); ~30% battle-snapped into stump + half-buried fallen shaft |
| 7f WellAFrame | Leaning wood A-frame + crossbar + bucket over the plaza well |
| 7g ScorchPatches | Dark tinted thin quads at building wall bases (1–2 per building, outward-facing, trace ignores village children so they never sit on roofs/rubble) |
| 7h InteriorLights | Two warm shadowless point lights in doorways (`FLinearColor(1.0, 0.55, 0.24)`, 240 i / 1050 r) — occupied-at-dusk feel |

New tunables (header, categories *Village Layout / Materials / Atmosphere*):
`bOrganicStreetLayout, bSpawnMainRoad, RoadTint, bSpawnGateFrames,
bSpawnCourtyardWalls, bSpawnTelegraphPoles, bSpawnWellAFrame, bSpawnScorchPatches,
ScorchTint, bSpawnInteriorLights`.

### Mechanical verification
- Both files braces/parens balanced; pass execution order asserted 1→9.
- 15 `SpawnVillageProp` call sites; helper + both includes present; every header
  member referenced from the cpp exists (machine-checked).
- UE 5.7-safe APIs only: `CreateAndSetMaterialInstanceDynamic`,
  `NewObject<UPointLightComponent>` + `RegisterComponent`.

_Delta on batches 1–4: `DestroyedVillageCompoundActor.{h,cpp}` plus the five
S5-14c files above._

# SquadAI Module — Round 6, Pass 5, Batch 3 — Save Identity (#5, final finding)

## Decision: versioned save + stable identity + legacy fallback (no save break)

Chosen over a clean save-format break. New saves get stable identity and version 2;
old saves (auto-detected as format 1) restore through the previous order-based path —
one new code path, one already-proven legacy path. No player save is killed.

## The defect

- **Capture side** (`USquadAISaveLoadSubsystem`): progress was read from the FIRST
  `AQuestChain` yielded by `TActorIterator` (with an unconditional `break`).
- **Restore side**: progress was stamped onto the FIRST chain in iterator order too.
- `TActorIterator` order is NOT stable across sessions (level actor arrays re-order
  with streaming/WP cells and dynamically spawned quest content). So a session could
  save chain-B's progress and restore it onto chain-A — silent cross-contamination,
  or (worse) restore onto a chain whose `bAutoStart=false` and lose everything: the
  old loop `break`ed after the first chain even when it failed the `bAutoStart` check.

## Fix (S5-15)

| Piece | Where | What |
|---|---|---|
| `FGuid ChainSaveId` | `AQuestChain` | Minted in `OnConstruction` (editor-placed chains → ID persists in the level asset, never regenerated) or at `BeginPlay` (runtime-spawned chains → session ID) |
| `SaveFormatVersion` + `CurrentSaveFormatVersion = 2` | `USquadAISaveGame` | Missing property in old archives deserializes as class-default **1** = legacy |
| `SavedChainId` + `SavedChainName` | `USquadAISaveGame` | Stable identity of the chain `ActiveMissionIndex`/`CompletedMissionCount` refer to |
| Capture | save subsystem | Now reads from `AQuestChain::FindPreferred(World, false)` — the same chain the HUD follows — with first-chain fallback; stamps version 2 + identity (name always recorded: it also rescues *new* saves whose runtime-spawned chains can't GUID-match across sessions) |
| Restore | save subsystem | Selects chain by GUID (v2+, GUID valid) → by actor name → legacy first-`bAutoStart`-chain fallback. Old `break`-after-first (even non-auto-start) eliminated. Restore of an identity-matched chain no longer requires `bAutoStart` — if the save recorded progress, the chain was running |

Notes:
- Identity-matched restore applies even when `bAutoStart` is false — correct by
  construction (a chain with recorded progress was active when saved).
- After the next level save in-editor, `ChainSaveId` is baked into placed
  `AQuestChain` instances (VisibleAnywhere, read-only in details).

## Verification (mechanical)

- 4 touched files: braces/parens balanced after string/comment stripping.
- Restore loop's old `break`-in-`for` gone; single identity-selection block; GUID
  match, name match, and legacy fallback each compiled from verified declarations.
- All referenced members (`ChainSaveId`, `SaveFormatVersion`, `SavedChainId`,
  `SavedChainName`, `FindPreferred`) exist in the patched headers.
- UE 5.7-safe: `FGuid`, `FGuid::NewGuid()`, `OnConstruction(const FTransform&)` — all
  engine-stable APIs.

## Pass-5 status after batch 3

All 11 findings resolved: batch 1 (#1, #2, #3, #7, #8, #9, #10), batch 2 (#4, #6,
WP-ownership subset of #11), batch 3 (#5). #11's cover-creation/barrel-suppression
ownership changes remain intentionally open pending design decisions.

_Batch 3 files (deltas on batches 1+2): `Public/Quest/QuestChain.h`,
`Private/Quest/QuestChain.cpp`, `Public/SaveSystem/SquadAISaveGame.h`,
`Private/SaveSystem/SquadAISaveLoadSubsystem.cpp`._

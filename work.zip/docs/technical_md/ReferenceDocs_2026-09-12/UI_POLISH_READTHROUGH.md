# SquadAI / Lidar Rostami — UI + Image Read-Through Notes

Date: 2026-09-12  
Repo read: `https://github.com/acedep12-sys/lidar_rostami2223.git` → `lidar_project.zip` → `extracted/lidar_project/`

## 1. What I found in the repo

- The GitHub repo currently contains one zip: `lidar_project.zip`.
- Inside the zip is a UE C++ module snapshot plus docs:
  - `docs/` — project/read-through/audit docs.
  - `project/lidar_rostami_a_FIXED/SquadAI/` — the Unreal C++ module.
  - `project/lidar_rostami_a_FIXED/ASSET_MANIFEST.md` — texture registry.
- Code scale in this snapshot:
  - 230 `.cpp/.h` files under `SquadAI/`.
  - `validate_codebase.py` reports brace/paren clean.
- Important: this repo snapshot does **not** include the PNG art files, even though the docs mention `art/`, `Content/Textures/`, and `content/texture/`. I checked for `.png/.jpg/.svg`: **0 image files found**.

## 2. Game identity / art rules to obey

The game is a Sacred Defense tactical squad shooter set on the Iranian side of the Iran–Iraq War, mainly 1980–81 Khuzestan front.

Binding art direction from the docs:

- Farsi/Persian-first UI, RTL-aware.
- 1980s Iranian-side battlefield tone.
- Use: steel helmets, black-and-white keffiyehs, plain crimson headbands with no writing, olive drab uniforms, canvas webbing, G3 rifles, RPG-7, date palms, mosque domes, Red Crescent.
- Avoid: Latin readable text, Western troops, modern sci-fi UI, fantasy armor, US/WWI vibes, Red Cross, open wallet contents.
- UI should feel tactical, respectful, dusty, high-contrast, cinematic, but not casino-gold or mobile-game overdecorated.

## 3. Existing UI architecture

The live UI is Canvas-based C++ HUD, not Blueprint/UMG-first:

- Main menu: `ASquadAIMainMenuHUD`
  - Files: `Public/HUD/SquadAIMainMenuHUD.h`, `Private/HUD/SquadAIMainMenuHUD.cpp`
  - 11 menu states: Main, Map Select, Armory, Player Progression, Profile, Achievements, New Game Difficulty, Load Game, Settings, Tactical Briefing, Relic Collection.
  - Has procedural backgrounds, dust/ember/fog particles, hover easing, film grain, screen fade, chiseled tactical panels.

- Gameplay HUD: `AQuestNativeHUD`
  - Files: `Public/HUD/QuestNativeHUD.h`, `Private/HUD/QuestNativeHUD.cpp`
  - Draws pause menu, inventory, deployment veil, health/weapon plate, minimap, compass, objective card, interaction prompts, hitmarkers, low-HP/fire/suppression vignettes, pings, squad panel, radio subtitles.

- UMG widgets exist, but docs say they are legacy/suppressed. Canvas is the authoritative UI stack right now.

## 4. Border / stylization requirements already documented

The canonical border direction is in `docs/BORDER_STYLE_GUIDE.md`:

- Borders are seasoning, not the meal.
- Gameplay HUD border footprint: max 3–4 percent of panel width; usually 8–18 px at 1080p.
- Difficulty/menu cards: max 6 percent; thin brass rim + 1px turquoise girih pinstripe.
- Medal socket: ring width max 12 percent of diameter.
- Full-screen loading/veil: no hard border, only vignette.
- Palette:
  - deep cobalt / matte obsidian base,
  - brushed brass highlights,
  - turquoise micro Girih/Khatam details,
  - crimson only for active combat/alert states.
- Transparent-center PNG frames are expected for 9-slice drawing:
  - `UI_Frame_TacticalBorder_Gold.png` — rectangular tactical border.
  - `UI_Frame_MedalSocket.png` — circular medal socket.

## 5. Important UI/code observation

The docs say the separate 3D border texture is drawn via 9-slice, but in the current code snapshot:

- `ASquadAIMainMenuHUD::AutoResolveMissingTextures()` loads `FrameTacticalGoldTexture` and other frame textures.
- `FrameMedalSocketTexture` is actually drawn on the achievements screen.
- However, `DrawChiseledTacticalPanel()` currently draws only procedural rectangles/lines. It does **not** use `FrameTacticalGoldTexture` for panel borders.
- `AQuestNativeHUD::DrawChiseledTacticalBox()` is also procedural-only and does not have a tactical frame texture member.

So if you install a beautiful transparent border PNG today, the medal socket can use its image, but most panels may still appear as procedural line borders unless the code is patched to draw a 9-slice/tinted frame overlay.

This is the biggest UI-stylization opportunity I found.

## 6. Texture registry / missing art targets

Docs reference about 60 unique PNGs under `/Game/Textures/*`. Major groups:

### Frames/buttons/bars
- `UI_Frame_TacticalBorder_Gold.png`
- `UI_Frame_TacticalBorder_Crimson.png`
- `UI_Frame_Badge_Hexagon.png`
- `UI_Frame_MedalSocket.png`
- `UI_Frame_Avatar_Portrait.png`
- `UI_Frame_Tactical_PauseCard.png`
- `UI_Frame_MapTheater.png`
- `UI_Button_Tactical_Normal.png`
- `UI_Button_Tactical_Hover.png`
- `UI_LoadingBar_Frame.png`
- `UI_LoadingBar_Fill.png`
- `UI_Progression_UpgradeBar.png`
- `UI_Military_Watermark_Emblem.png`

### Backgrounds/screens
- `Menu_Background_KhuzestanDesertWar.png`
- `Menu_Background_NightOperations.png`
- `Loading_Background_TrenchAssault.png`
- `UI_Background_Medals.png`
- `UI_Background_Progression.png`
- `UI_Background_Armory.png`
- `UI_Player_Progression_Art.png`

### Difficulty cards
- `UI_Diff_Recruit.png`
- `UI_Diff_Regular.png`
- `UI_Diff_Hardened.png`
- `UI_Diff_Lethal.png`

### HUD icons/items
- `HUD_Weapon_G3A3.png`, `HUD_Weapon_AK47.png`, `HUD_Weapon_RPG7.png`, `HUD_Weapon_MG3.png`, `HUD_Weapon_SVD.png`, `HUD_Weapon_Unarmed.png`, `HUD_Weapon_Fist.png`
- `HUD_Health_Card.png`
- `UI_Item_PocketQuran.png`, `UI_Item_PocketRadio.png`, `UI_Item_CombatWallet.png`, `UI_Item_FirstAidPouch.png`, `UI_Item_Canteen.png`, `UI_Item_DogTag.png`, `UI_FallenNotes_Background.png`

## 7. Recommended first UI polish batch

I recommend starting with a **drop-in UI skin pack + small C++ border integration patch**, not with all 60 images at once.

### Batch 1 — high-impact, low-risk

1. Generate/install core transparent UI assets:
   - `UI_Frame_TacticalBorder_Gold.png`
   - `UI_Frame_TacticalBorder_Crimson.png`
   - `UI_Frame_MedalSocket.png`
   - `UI_Button_Tactical_Normal.png`
   - `UI_Button_Tactical_Hover.png`
   - `UI_LoadingBar_Frame.png`
   - `UI_LoadingBar_Fill.png`
   - `HUD_Health_Card.png`
   - `HUD_Weapon_Fist.png`

2. Patch Canvas code so the frame texture is actually used:
   - Add a reusable 9-slice draw helper in `ASquadAIMainMenuHUD`.
   - Add `FrameTacticalGoldTexture`/`FrameTacticalCrimsonTexture` to `AQuestNativeHUD` or load them safely at HUD startup.
   - Draw texture frame as an overlay after the existing procedural chisel fallback.
   - Keep current procedural lines as fallback if PNG is missing.

3. Update `IMAGE_USE_MAP.md` and `BUG_REGISTER.md` after the patch.

### Batch 2 — menu identity

Generate/install:
- `Menu_Background_KhuzestanDesertWar.png`
- `Menu_Background_NightOperations.png`
- `Loading_Background_TrenchAssault.png`
- `UI_Background_Armory.png`
- `UI_Background_Progression.png`
- `UI_Background_Medals.png`

### Batch 3 — cards/profile polish

Generate/install:
- `UI_Diff_Recruit.png`
- `UI_Diff_Regular.png`
- `UI_Diff_Hardened.png`
- `UI_Diff_Lethal.png`
- Trait badges and inventory item icons.

## 8. Validation state

I ran the included validator on the extracted module:

```text
Scanning 230 files (111 cpp, 119 h)...
Zero brace issues found across all files!
Zero paren issues found across all files!
```

No Unreal Engine build is available in this workspace, so compile/runtime verification still needs your local UE project.

## 9. Next recommended action

Next, I should create Batch 1:

- produce a `Content/Textures/` folder with transparent PNG UI borders/buttons/bars/icons,
- patch the C++ Canvas HUDs to actually draw the modular border images,
- run static validation,
- provide clear install instructions for your local UE 5.7 project.

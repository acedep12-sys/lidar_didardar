# Install — AAA Menu Batch 2 Field-Slate Patch 2026-09-12

This package includes Batch 1 plus Batch 2.

Owner requests handled:

1. Ignore legacy UMG for the main menu.
2. Recreate/restructure main UI for a better AAA style.
3. Remove the gold-heavy look; use the cooler field-slate/teal style instead.
4. Batch 2 rebuilds Map Select, Armory, and Difficulty screens.

## Copy paths

From this package:

- `Source/SquadAI/` → `<YourProject>/Source/SquadAI/`
- `Content/Textures/*.png` → `<YourProject>/Content/Textures/`

Then regenerate project files if needed and build Development Editor.

## Important filename note

`UI_Frame_TacticalBorder_Gold.png` still has the word `Gold` because the existing code and docs already reference that filename. In this patch the image itself is **not gold** anymore — it is field-slate / oxidized teal / cool steel.

## Edited code markers

Batch 1:

- `AAA-MM-1` — ignore/remove legacy UMG menu at Canvas draw time.
- `AAA-MM-2` — rebuilt command header.
- `AAA-MM-3` — rebuilt telemetry pill.
- `AAA-MM-4` — transparent-center 9-slice frame support.
- `AAA-MM-5` — rebuilt main menu screen.

Batch 2:

- `AAA-B2-0` — default no-gold field-slate palette.
- `AAA-B2-1` — Map Select rebuilt as recon board.
- `AAA-B2-2` — Armory rebuilt as gunsmith workbench.
- `AAA-B2-3` — Difficulty rebuilt as deployment cards.
- `AAA-B2-4` — difficulty-card click guard fixed to `NewGameDifficulty`.

## Verify in UE 5.7

1. Main menu opens as Canvas UI, no legacy UMG overlay.
2. Default color is cool teal/slate, not gold.
3. Main screen buttons still route correctly.
4. Start New Game → Difficulty screen; each card launches with correct difficulty.
5. Map Select rows update the right preview/briefing and launch selected map.
6. Armory rows update selected weapon, stats, traits, equip/unlock.
7. Run `SquadAI.CheckAssets` and search `[SQUADAI_ASSET_AUDIT]`.

## Static validation

```text
Scanning 230 files (111 cpp, 119 h)...
Zero brace issues found across all files!
Zero paren issues found across all files!
```

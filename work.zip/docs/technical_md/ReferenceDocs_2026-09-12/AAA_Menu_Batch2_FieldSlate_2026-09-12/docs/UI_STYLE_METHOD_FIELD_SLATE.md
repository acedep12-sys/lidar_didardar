# UI Style Method — How the Current AAA Field-Slate Look Was Built

This is the design recipe used for the current SquadAI main menu and Batch 2 screens.

## 1. First decision: protect the key art

The screenshot already had good cinematic background energy, but the UI fought it. The fix is not to cover the whole image with giant ornate frames. Instead:

- use dark transparent scrims only behind functional UI zones,
- keep the soldier and battlefield readable,
- let the UI sit like command equipment laid over the image.

## 2. Layout language: military command desk, not web page

The screens are structured like operational tools:

- Main Menu = operations command deck + commander dossier.
- Map Select = recon board + theater intelligence card.
- Armory = gunsmith workbench + weapon rack.
- Difficulty = deployment cards.

This avoids the "flat list of buttons" look.

## 3. Color correction after feedback

The gold version felt wrong because the background is dusty, brown, war-torn, and already warm. Gold competes with it and can look decorative or mobile-game-like.

The replacement palette is:

- **Field Slate / Olive Black** — panel base.
- **Oxidized Teal** — active accent, readable against dust.
- **Cool Steel/Bone** — bevel/highlight.
- **Rust/Crimson** — danger, locked, lethal only.

Gold is no longer the default feeling. The filename `UI_Frame_TacticalBorder_Gold.png` remains only because code already references it.

## 4. Borders: micro-detail only

The border style uses:

- transparent center,
- thin steel/teal outlines,
- tiny Khatam/Girih teeth,
- small corner rosettes,
- no thick decorative frame.

In code, `DrawChiseledTacticalPanel()` still draws a safe procedural fallback, then `DrawNineSliceFrame()` overlays the PNG frame if installed.

## 5. AAA readability rules used

- One dominant focal area per screen.
- Text lives in glass/dark bands, never directly on busy art.
- Active/selected states have a left rail or strip.
- Buttons have codes/labels/hints instead of same-looking bars.
- Large panels use desaturated tint and low alpha; hover adds brightness.
- Danger colors are rare so they actually mean something.

## 6. Unreal implementation style

Because the project uses Canvas HUD instead of UMG:

- all layout is procedural in C++,
- every click rect keeps the existing button IDs,
- images are loaded through `/Game/Textures/*` and loose PNG fallback,
- the design must be resilient if textures are missing.

That is why every new screen has procedural fallback grids and panels.

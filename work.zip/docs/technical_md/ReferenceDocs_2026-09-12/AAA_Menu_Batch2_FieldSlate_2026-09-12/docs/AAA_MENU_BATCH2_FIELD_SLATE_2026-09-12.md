# AAA Menu Batch 2 — Field-Slate Palette + Map/Difficulty/Armory Rebuild

Date: 2026-09-12  
Owner request: continue Batch 2; explain the style; gold does not work here.

## Summary

Batch 2 extends the AAA Canvas menu pass and removes the warm gold-heavy look from the default theme. The menu now uses a cooler **Rostami field-slate** direction:

- oxidized teal / desaturated cyan for active UI language,
- dark olive-black and gunmetal panel backing,
- bone/steel bevel highlights,
- rust/crimson reserved for locked/danger states,
- no large gold fills or gold-dominant borders.

The existing filenames are kept for compatibility, especially `UI_Frame_TacticalBorder_Gold.png`, but the actual art/color is now field-slate/teal rather than gold.

## Code changes

File: `project/lidar_rostami_a_FIXED/SquadAI/Private/HUD/SquadAIMainMenuHUD.cpp`

### `AAA-B2-0` — default palette changed

The default enum value remains `DesertKhakiGold` so existing Blueprints/configs do not break, but its display/default colors are changed to **Rostami Field Slate**.

New default accents:

- Primary: `FLinearColor(0.48, 0.72, 0.68, 1.0)` — oxidized field teal.
- Secondary: `FLinearColor(0.72, 0.25, 0.18, 1.0)` — rust alert.
- Panel BG: `FLinearColor(0.018, 0.031, 0.034, 0.94)` — olive-black slate.

Common helper color passes were also cooled:

- inner pinstripe is teal, not gold,
- bevel highlight is cool steel,
- button hover is teal/field slate instead of amber/gold.

### `AAA-B2-1` — Map Select rebuilt

Replaced the old general panel with a **Recon Board** layout:

- left sector ledger with thumbnails/status,
- right large 16:9 theater preview,
- status chips for readiness / XP / estimated duration,
- tactical briefing block,
- launch button preserved as ID `199`,
- map selection IDs remain `100+i`.

### `AAA-B2-2` — Armory rebuilt

Replaced the old list/detail layout with a **Gunsmith Workbench** layout:

- left compact weapon rack,
- large selected weapon hero viewport,
- stat bars in two columns,
- combat trait badges,
- equip/unlock action preserved as IDs `299` / `298`,
- weapon select IDs remain `200+i`.

### `AAA-B2-3` — Difficulty rebuilt

Replaced the old text-heavy difficulty columns with **Deployment Cards**:

- four vertical cinematic cards,
- image remains dominant,
- top identity/risk strip,
- lower glass sheet for title/modifiers/action,
- color-coded: olive → teal → dusty rust → crimson,
- no gold wash.

### `AAA-B2-4` — Difficulty click state fixed

The existing click handler had difficulty launch guarded to `MapSelect`, while the Start New Game path navigates to `NewGameDifficulty`. Batch 2 fixes the guard so difficulty cards launch only from `NewGameDifficulty`.

This keeps the earlier medal-collision fix intact because achievements still use `520+i`.

## Texture changes

Generated/updated in `Content/Textures/` and mirrored to `art/`:

- `UI_Frame_TacticalBorder_Gold.png` — compatibility name, field-slate/teal appearance.
- `UI_Frame_TacticalBorder_Crimson.png` — rust/crimson alert frame.
- `UI_Frame_MapTheater.png` — same field-slate frame style for map preview cards.
- `UI_Frame_MedalSocket.png` — cool steel/teal medal socket.
- `UI_Button_Tactical_Normal.png` — dark slate button.
- `UI_Button_Tactical_Hover.png` — teal hover button.
- `UI_LoadingBar_Frame.png` — steel/teal bar housing.
- `UI_LoadingBar_Fill.png` — teal segmented fill.
- `HUD_Health_Card.png` — neutral card + Red Crescent retained.
- `HUD_Weapon_Fist.png` — olive/steel full-color fist icon.

## Validation

```text
Scanning 230 files (111 cpp, 119 h)...
Zero brace issues found across all files!
Zero paren issues found across all files!
```

No UE 5.7 engine exists in this workspace, so local compile/PIE verification is still required.

## In-engine verification

1. Main menu still ignores legacy UMG and shows Canvas HUD.
2. Default accent is now teal/slate, not gold.
3. Main screen still routes all buttons correctly.
4. Start New Game opens difficulty screen; clicking each card launches with selected difficulty.
5. Map Select:
   - click each theater row,
   - selected preview/briefing updates,
   - locked maps cannot launch,
   - launch button still uses selected map.
6. Armory:
   - click each weapon row,
   - preview/stat/trait panel updates,
   - equip/unlock buttons still work.
7. Run `SquadAI.CheckAssets` and check `[SQUADAI_ASSET_AUDIT]` for frame/buttons/bar/icon files.

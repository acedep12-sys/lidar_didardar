# AAA Main Menu Reference-Style Pass — Modern Warfare Layout

Date: 2026-09-12  
Owner request: change the main menu UI/button style to match the supplied reference screenshot, **minus the Arabic text**, and do not replace the already-owned background image.

## Scope

Applied directly to the active workspace project:

`project/lidar_rostami_a_FIXED/SquadAI/Private/HUD/SquadAIMainMenuHUD.cpp`

No UMG work was done. The Canvas HUD remains the active menu path.

## What changed

### `AAA-MW-1` — Main menu visual rebuild

`DrawMainMenuScreen()` was replaced with a reference-style layout:

- image-first background remains visible in the center;
- dark left/right vignette scrims like the reference;
- top-left player/operation strip with crest, level, XP, and progress bar;
- left vertical stacked command menu;
- thin glass panels with muted brass linework;
- square icon wells on each main button;
- top-right compact utility icon rail;
- right-side mission card, daily objective card, map card, and quick-start CTA;
- bottom-left latest-intel module;
- English-only labels in this main menu screen.

The global old title/telemetry header is now skipped on `EMainMenuState::Main` so it does not place Farsi/Persian text over the reference-style main screen. Submenu screens still keep their existing headers.

## Text policy

The main menu block was checked for Arabic/Persian Unicode codepoints after patching:

```text
Main menu Arabic/Persian codepoint count: 0
```

This means the reference screenshot's Arabic labels were not copied into the main menu. The rest of the game/submenus can still use their existing localization.

## Button routing preserved

The new visual buttons still use existing click IDs:

| UI label | ID | Existing action |
|---|---:|---|
| START MISSION | `1` | New game difficulty screen |
| OPERATIONS | `2` | Map select |
| CUSTOMIZE | `3` | Armory |
| PROGRESSION | `4` | Progression |
| DOSSIER | `5` | Player profile |
| RECORDS | `6` | Achievements |
| QUICK START | `7` | Continue latest save, or fast deploy if no save |
| LOAD icon | `8` | Load game |
| SETTINGS | `9` | Settings |
| EXIT | `11` | Quit |
| RELICS icon | `12` | Relic collection |
| VIEW DETAILS / READ INTEL | `13` | Tactical briefing |

## Background image

This pass only changed the UI layout and button/panel rendering. It does not require a new background image. Use your own background by assigning/importing it to the existing menu background texture slot or the existing `Menu_Background_KhuzestanDesertWar.png` asset path.

## Validation

```text
Scanning 230 files (111 cpp, 119 h)...
Zero brace issues found across all files!
Zero paren issues found across all files!
```

No Unreal Engine 5.7 compile/PIE is available in this workspace, so local UE verification is still needed.

## In-engine checklist

1. Open the main menu.
2. Confirm the old top Farsi title/telemetry strip is gone on the main screen.
3. Confirm labels are English-only on the main screen.
4. Hover each left command row and the quick-start CTA.
5. Click each route and verify it still opens the expected existing screen.
6. Verify your background image remains visible and is not covered by large opaque panels.

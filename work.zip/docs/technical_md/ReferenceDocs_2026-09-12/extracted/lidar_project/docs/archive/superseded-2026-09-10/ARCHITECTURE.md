# Architecture — consolidated post-fix system map (2026-09-10)

Merged from both sessions' STEP docs, corrected to the FIXED+ F-batch state. Line counts are approximate
(FIXED snapshot). Deep dives: `reference/session_steps/STEP*.md` (this session), `reference/prev_session/STEP*.md` (original reads).

## Module bootstrap

- `SquadAI` primary game module (`IMPLEMENT_PRIMARY_GAME_MODULE` — D1 pending). Deps: Core/Engine/InputCore
  public (+AssetRegistry runtime); AIModule/Navigation/GameplayTasks/StateTree/GameplayStateTree/Niagara/
  GameplayTags/GameplayAbilities/SmartObjects/Significance/EnhancedInput/UMG/Slate(+Core) private;
  UnrealEd/AssetTools/ToolMenus editor-only.
- `SquadAI.cpp` installs a **global 2-team attitude solver** at startup (Team0 allies vs Team1 enemies).
  Blocks >2 factions until P-2 replaces it. `USquadAITuning` (UDeveloperSettings) holds ~all balance numbers.

## Characters & combat

- `ASoldierCharacter` (abstract, TeamId from Faction) + `ALeaderCharacter` (immortal Rostami, waypoint FSM,
  player pacing) + `AAllySoldier` (downable-never-die, `PowerLevel` dial) + `AEnemySoldier` (mortal,
  coordinator-driven). Full cover-state, downed/revive, left-hand-IK data, per-stance montage selection.
- Components: `Weapon` (burst hitscan, lead prediction, layered hit resolution, penetration, suppression;
  AI ammo infinite BY DESIGN) → `Health` (**the** SquadAI damage chokepoint; leader branch: ×0.25, floor 35,
  never down) → `Aim` (critically-damped spring, LOD-aware) → `TacticalGrenade` (G/H, counts enforced,
  bridge-arbitrated) → `TPWCSVisuals` (pure-visual pack bridge).
- ⚠️ Damage paths still overlap (P1-1/Step3-#2 OPEN): `HealthComp` + pack sync + bridge (SquadAI side fixed
  via B7-11; pack-side static `ApplyTPWCSPlayerDamage` still multi-dips up to 3× — Phase 2 item 1).

## AI brain & cover

- `SoldierAIController` (0.1 s tick: suppression → memory → registry poll → combat fallback → enemy movement →
  leader pathing), confidence memory (`FPerceivedTarget`), smoke-aware LOS, fire-avoidance pathing, held cover
  reservations (1d fix), immediate perception + dormant safety net.
- StateTree: schema + threat/suppression/health evaluators + Hold/EnemyMission(12000 gate)/LeaderPath/
  TakeCover(smooth Rotating arrival)/Engage(enemy-only suppression gate)/FollowLeader(V-slots, revive, fire).
- Enemy coordination: fireteam roles (Suppress/Flank/Assault/Lead + shared intel) + attack state machine
  (Gather→Suppress→Flank→Assault→Hold).
- Cover: chunked async scanner (1000 cm chunks, 6×6, 8 dirs × 5 heights, mission-anchored top-8 verify,
  reservations by `(FIntPoint, LocalID)` — F-G4 fixed negative-Y decode) + baked volumes + EQS debug nodes.

## Missions, spawners, battlefield

- System A (live gameplay): `MissionZone` (Reach/Clear/Defend + retry/restart + XP) ← `QuestChain` sequencer,
  fed by `EnemyWaveSpawner` (X/Y/Z + fireteams + pool) via `SpawnerTrigger`. Failure branch reachable (S5-1).
- System B (HUD-visible): `QuestMission` + tag `AutoZone` objectives (modes work, S5-3) ← `QuestDirector`,
  ticked 4 Hz by `QuestTickerSubsystem` (Failed advances, S5-4), validated by `QuestValidator`, logged (S5-5).
- Template stack: `UWaveTemplate` + `AWaveSpawner` (batched, round-robin) + `AAutoSpawnZone` one-drop
  (F-G5 world-space flag, F-G6 actor tag). `EnemyPool` prewarmed on activation (S5-7).
- Battlefield: `SceneDecorator` (scatter + pack-aware fire damage + AI hazard feed; P1-9 defaults OPEN) +
  `FireDamageZone` + `BattlefieldDecorator` (tracked FX, S5-8) + sandstorm director (AI-sight wired, S5-9) +
  dust streaming (null-safe, S5-10) + `PathExplosionBarrage` + trench splines + procedural buildings/village.

## UI (Canvas live; UMG suppressed), save, meta

- **Live:** `QuestNativeHUD` (3323 lines: 18-layer draw order, prompts, revive, guidance ribbon, scene-capture
  minimap, squad panel, radio, objective card, defend banner, pause/inventory/veil, GameUIScale, E-arbitration)
  + `SquadAIMainMenuHUD` (3075 lines: 11 screens incl. Relic Collection, per-frame click rects with GLOBALLY
  unique IDs (F-G3 corrected rule), UIScale, ISIRI FA/EN input, medallion/topo fallbacks).
- **Suppressed:** both UMG stacks (collapsed at BeginPlay + periodic sweep, gated by `bSuppressLegacyUMG`;
  sweep narrowed by F-G12). D2 decides delete vs finish.
- Farsi: `UFarsiTextHelper` (41-glyph shaper, Lam-Alef, tashkeel strip, BiDi reorder, Persian digits;
  ZWNJ-drop cleared harmless; P1-L1 hardening queued) + external INI localization (hot-reload).
- Save: `SquadAISaveGame` slots + `SquadAISaveLoadSubsystem` (gather/apply, post-travel 30 s ticker, surgical
  chain restore — P0-3 private-access OPEN) + progression self-persist. Settings apply incl. volumes/FOV.
- Meta: `ProgressionSubsystem` (profiles + XP curve + 7 attributes + 5-weapon armory with ENFORCED level+XP
  unlocks (F-G1/F-G2) + achievements + 3 theaters + doctrines) + `InventorySubsystem` (6-weapon backpack,
  fallen notes, radio, Quran, supplies).

## Audio, perf, tactical, world actors, bridges

- Audio: `AudioSubsystem` 8-state director (20 Hz, crossfades, horde stem, speed-of-sound, voicelines w/
  anti-spam; F-C1 single `Command_Hold` case; P1-A1…A4 queued) + `AudioManager` actor (content slots).
- Perf: significance LOD brain, soldier spatial hash, asset cache flyweight, FX manager (pooled, budgeted),
  cinematic slow-mo (P1-4 input + P1-5 check queued), dev-debug cheats (wired; P1-P1 audit gating queued),
  player bridge (input glue; P1-2 auto-attach queued), diagnostics.
- Tactical: command (orders), fire support (timestamp cooldown), ping (markers), radio chatter, frag/smoke
  grenades, mortar barrages (single bridge path) — all three explosions now emit hearing stimuli (F-G13).
- Actors: ammo crate, medkit (F-G8 consume gate), medical station, explosive barrel, mounted turret (mount
  lock), encounter volumes, fort/trench builders, audio manager, menu director, auto-setup manager.
- Pack bridge: TPWCS reflection adapters (fuzzy prop names, by-type ProcessEvent params), pack bridges for
  health/damage/anim/weapon; editor factory (1-click BP setup, SCS surgery) + template/pack libraries.

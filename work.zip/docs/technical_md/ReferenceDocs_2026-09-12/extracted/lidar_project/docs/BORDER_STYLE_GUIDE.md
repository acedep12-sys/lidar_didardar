# Border Style Guide — SquadAI (2026-09-10)

**Rule: borders are seasoning, not the meal.**  
A game border must **frame** content without stealing screen space or attention. This guide is binding for all future border assets.

## 1. Screen-space budget

| Context | Max border footprint | Typical thickness | Example |
|---------|---------------------|-------------------|---------|
| Gameplay HUD (pause, inventory, veil, weapon plate, health) | **≤ 3-4%** of panel width | **8–18 px** at 1080p (12–24px at 4K source) | `DrawChiseledTacticalBox` chamfer 8px, line 1px |
| Difficulty cards (menu) | **≤ 6%** | **16–28 px** at 4K source (scales down) | thin brass rim + 1px turquoise girih pinstripe |
| Medal socket (circular) | **ring width ≤ 12%** of diameter | **10–18 px** brass + **4–8 px** khatam inlay | outer 12px, inner 6px |
| Full-screen veil / loading | **no border**, only edge vignette 12px | — | procedural only |

**Measure:** On a 1920×1080 screen, a 16px border is 0.8% of width — correct. A 120px ornate frame is 6.2% — too heavy for HUD, okay *only* for ceremonial medals screen. Previous 1.7MB ornate `UI_Frame_TacticalBorder_Gold` was **too thick** — replaced with subtle variant below.

## 2. Visual hierarchy

1. **Content first.** Weapon art, soldier face, map preview must be 90% of perceived area.
2. **Border second.** It should be noticed only on second glance. Use low-contrast base (deep cobalt #0E3A5C matte, 85% opacity) with *tiny* high-contrast accent (turquoise #2CB4B4 1px line, brushed brass #C9A86A highlight 1.5px).
3. **Corner accents last.** Small 8-point Girih star rosette at corners, **≤ 32×32px** at 1080p, not 128×128.

**Anti-patterns (do NOT do):**
- Thick 80px+ wood/gold frame on every panel (feels like mobile casino).
- Full-pattern Girih tiling across entire border band (noisy, steals focus).
- Bevel + drop shadow + glow + rivets all at once (visual noise).
- Opaque center — must be **transparent** for 9-slice overlay over any background.

## 3. Persian arts — use subtly

Girih / Khatam / islimi must be **micro-details**, not wallpaper:

- **Girih strapwork:** Single 1.5px turquoise line forming interlocked stars along inner edge, over-under weave implied with shadow, not full 5-tile fill. Repeat every 180px.
- **Khatam mosaic:** 4–6px triangle band inset inside brass rim, mother-of-pearl / walnut / turquoise at 30% saturation — you see shimmer only when looking.
- **Islimi vine:** Hairline 1px engraved on outer brass, visible only at 200% zoom — adds craftsmanship without clutter.
- **Palette:** Cobalt #0E3A5C (80% of border area), Turquoise #3AB3A3 (5%), Brass #D4B678 (15%). No saturated blue fire or large gold blobs.

**Placement:**
- Horizontal edges: centered Girih star every ~200px, faint.
- Vertical edges: stretched slightly, same.
- Corners: single Girih 8-point star rosette, 24–28px, brass fill, turquoise center dot 4px.

## 4. Technical spec (PBR, 9-slice, transparency)

- **Source resolution:** 1536×1024 for rectangular, 1024×1024 for circular — downsampled via Lanczos to 768×512 at runtime.
- **Center:** Fully transparent (alpha 0). Engine does `LoadTextureSafe("/Game/Textures/UI_Frame_TacticalBorder_Gold")` and draws via `Canvas->DrawTexture` with 9-slice (corners + edges tiled, center stretched transparent).
- **Edges:** 12px inner chamfer (45°) with 1px highlight (#E8D9B0, top/left) and 1px shadow (#081A2E, bottom/right) for 3D bevel without thickness.
- **Material cues:** Brushed brass — subtle horizontal grain, 15% specular. Velvet recess inside — matte 5% sheen.
- **File:** PNG-32 + alpha, optimized, ≤ 600KB. No baked background, no text, no vignette.

## 5. Code integration

- **Texture path:** `/Game/Textures/UI_Frame_TacticalBorder_Gold` (subtle) and `/Game/Textures/UI_Frame_MedalSocket` (subtle). Single physical copy at `Content/Textures/` (symlinked to `art/`).
- **Draw call:** `DrawChiseledTacticalPanel(X,Y,W,H, FrameTexture)` does 9-slice: corners fixed, edges stretched. Keep `Thickness=1.2`, `Chamfer=8` for gameplay; `Chamfer=12` for menu cards.
- **Fallback:** If texture missing, procedural `DrawChiseledTacticalBox` draws plain cobalt+brass — game never breaks (`[SQUADAI_ASSET_AUDIT]` logs missing).
- **Where to use which:**
  - **Subtle thin** (`UI_Frame_TacticalBorder_Gold` new): **all gameplay HUD** — pause, inventory, weapon plate, deploy veil, minimap.
  - **Ceremonial heavy** (old ornate, archived): **only** medals/achievement screen if you want grandeur — but even there, thin is preferred.

## 6. How to replace / test

1. Replace PNG → `Content/Textures/UI_Frame_TacticalBorder_Gold.png` (keep 1536×1024, transparent center).
2. In PIE, open pause (ESC) + inventory (Tab) — border should be barely visible at arm's length, but crisp when you lean in.
3. Screenshot at 1080p, measure border width in paint — should be 12–18px.
4. Run `SquadAI.CheckAssets` in console — must show `[SQUADAI_ASSET_AUDIT] FOUND UI_Frame_TacticalBorder_Gold`.

## 7. History

- 2026-09-10 early: 1.7MB ornate Girih frame (120px, heavy) — **deprecated** for HUD, kept as example of what NOT to do on gameplay screens.
- 2026-09-10 late: **subtle** 24px Khatam-Girih hybrid — current canonical for all panels.

Keep borders humble. Let the soldiers and the desert do the talking.

# Texture Audit — `/Game/Textures` (UI/Menu/HUD batch)

Where every texture path referenced by the menu/HUD code lives, what happens when it is
missing, and what art still needs to ship. All paths below are game-content paths
(`/Game/...`) — **none of them exist in the C++ module repo**; they must be supplied by
the artist in the UE project's `Content/` folder.

Rule of thumb used by this batch: **code must never visibly break when art is missing** —
every draw site either had a fallback already or got one (M4–M7, Q6).

## 1. References by draw site

| # | Draw site | Getter / property | Content path(s) | Missing-art behavior |
|---|-----------|-------------------|-----------------|----------------------|
| 1 | Difficulty cards (3 cols) | `Col.BackgroundTex` | set per-column in code (`DifficultyCol` init) | **M4 (new):** procedural topo-grid tinted with the column theme color |
| 2 | Avatar matrix (profile screen) | `AvatarsList[].Tex` | avatar gallery entries | **M5 (new):** brass-plate medallion + name initial |
| 3 | Profile switcher slots | `GetAvatarTexture(ID)` | avatar per profile | **M6 (new):** brass-plate medallion + profile initial |
| 4 | Main header commander card | `GetAvatarTexture(ActiveID)` | active profile avatar | **M7 (new):** brass-plate medallion + profile initial |
| 5 | HUD weapon plate icon | `HUDWeaponUnarmedTexture` etc. | unarmed/weapon icons | **Q6 (new):** monochrome fist is warm-tinted so it reads as intentional |
| 6 | Inventory tabs (radio/Quran) | tab icon getters | radio + Quran art | pre-existing: null-guarded, tab still draws with text label |
| 7 | Relic gallery | relic texture resolve | relic art | pre-existing: null-guarded draws (verified working) |
| 8 | Map topo background | map art getter | map art | pre-existing: procedural topo fallback (verified working) |
| 9 | Armory weapon preview | weapon preview getter | per-weapon widescreen art | pre-existing: widescreen layout + placeholder (verified working) |
| 10 | Main-menu vista/backdrop | menu BG getter | menu backdrop | pre-existing: procedural gradient/vignette (verify in-engine) |

## 2. Art still to ship (priority order)

1. **Avatar set** (unblocks 2/3/4 — most visible): N portrait textures, square, referenced by
   `AvatarsList` / `GetAvatarTexture`. Until they ship, brass medallions stand in.
2. **Difficulty card backgrounds ×3** (unblocks 1): widescreen scenes matching the three
   `DifficultyCol` theme colors. Until they ship, tinted topo-grids stand in.
3. **`HUD_Weapon_Fist`** full-color icon (unblocks 5): 120×50-ish unarmed icon. Until it
   ships, the warm tint keeps the monochrome stock art presentable.
4. **Radio + Quran tab art** (6): tab icons; text labels already carry the meaning.
5. **Menu vista backdrop** (10): fullscreen art; confirm the procedural gradient reads well
   without it.

## 3. How to point the code at real art

- Avatar/difficulty/relic getters resolve fixed `/Game/Textures/...` paths — drop the
  `.uasset` files at those exact paths (or update the path literals) and the fallbacks
  automatically stop drawing (every fallback is `else` of a null check).
- No code change is needed when art lands; to force-verify a fallback in-engine, temporarily
  rename the asset and confirm the procedural stand-in appears.

## 4. In-engine verification checklist (this batch)

- [ ] Profile screen with zero avatar art: medallions + initials, no blank holes.
- [ ] Difficulty screen with zero card art: three tinted topo columns, hover brightens.
- [ ] Unarmed HUD plate: warm fist icon, readable at 1080p and 4K.
- [ ] Segmented dossier/armory bars: 10 discrete blocks, partial block smooth.
- [ ] Chiseled panel: bevel + brass rivets visible, halo on the active panel only.
- [ ] Font scale 1.15: Farsi + Latin bounded text larger, nothing overflows its box.
- [ ] E near crate + downed ally in range: revive wins, crate does not fire.
- [ ] E near two crates same frame: exactly one fires.
- [ ] Pause → Quit to Menu on a missing map name: red Farsi error, pause reopens.
- [ ] Save with grenades/kits/ammo → load in another map: all counts + allies + equipped
      weapon restored (see `SchedulePostTravelApply` 30 s timeout log on failure).

# Step 3 — Characters & Combat Components (READ COMPLETE ✅)

Files read in full:
- `Public/Characters/SquadLeaderTypes.h` + `SoldierCharacter.h` (565) + `Private/...cpp` (1209) + `SoldierCharacter_PresentationHelpers.inc`
- `LeaderCharacter.h` + `.cpp` (320) | `AllySoldier.h` + `.cpp` (245) | `EnemySoldier.h` + `.cpp`
- `WeaponComponent.h` + `.cpp` (**1088**) | `HealthComponent.h` + `.cpp` | `AimComponent.h` + `.cpp` (253)
- `TacticalGrenadeComponent.h` + `.cpp` | `SquadAITPWCSVisualsComponent.h` + `.cpp` (334)
- `Animation/SoldierAnimInstance.h` + `.cpp`

---

## 1. ASoldierCharacter (abstract base, ACharacter + IGenericTeamAgentInterface)
**Ctor:** tick OFF by default (0.5s interval, started selectively), AIControllerClass=SoldierAIController, AutoPossessAI=PlacedOrSpawned.
Creates: AimComp, WeaponComp, HealthComp, GrenadeComp, AIAdapterComp. Movement: orient-to-movement + controller-desired-rotation, 720°/s, walk 400, crouch enabled (44 half-height).
PerceptionStimuliSource (sight+hearing+damage), NavInvoker, **default Faction=Enemy, TeamId=1** (BeginPlay recomputes from Faction: Enemy→1 else 0).

**BeginPlay:** leader/enemies `bCanBeDowned=false`, allies true. 4.5s spawn grace. Pack-mode: 0.5s damage-bridge timer + OnTakeAnyDamage bind.
NavInvoker registered **20000/30000** (!). All primitive comps `bCanEverAffectNavigation=false`. AIAdapter init + pack-safe mode.
Pack mode tags: `TPWCS_RagdollCapsule`, `TPWCS_WeaponMesh`. TeamId pushed to controller. Registers with SignificanceManager + SoldierRegistry.
Weapon accuracy ← AccuracyMultiplier. OnDeath ← OnHealthDied. **Player-controlled: applies progression** (speed ×, +bonus HP, accuracy ×(2−recoilMult)).
Enemies: URO on, fixed skel bounds, AlwaysTickPose.

**TakeDamage:** leader → 25% dmg, floor 35 HP. Else HealthComp.ApplyDamage + random hit-react montage + `UAISense_Damage::ReportDamageEvent`.

**Downed/revive:** `bCanBeDowned` (allies only), bleedout 45s, revive 3s. EnterDownedState: stops weapon/aim/AI/movement, capsule ignores pawn/vehicle,
mesh → ragdoll + downward impulse, voiceline Ally_ManDown, HUD `NotifyAllyDowned`. CompleteRevive: HealthComp.Revive, pack-health restore to 100,
capsule+PWN restore, mesh un-ragdoll + reattach + re-init anim, walk 450, `AIC->RestartStateTree()`, re-register.

**Cover state:** bIsInCover/bIsCrouchingInCover, CurrentCoverPoint, CoverSide (Right preferred), CoverPeekType (Over only if Low+Over-flag).
SetCoverState crouch/uncrouches the Character.

**Weapon visuals/IK:** EquippedWeaponMesh + attach socket `RifleSocket` (+offset/rot/scale), muzzle `Muzzle`, LH-IK `LeftHandIK`.
Full left-hand IK runtime data (effector CS, elbow dynamic target from `lowerarm_l`, rotation distribution forearm 0.35/hand 0.65, grip pose) —
consumed by AnimBP via `GetWeaponIKRuntimeData()` / `FSoldierAnimRuntimeData`.

**Animation montages:** Fire/Reload × {base, crouch, cover-high-L/R, cover-low-L/R/Over} selected by `SelectFire/ReloadMontage()`;
HitReact(Montage[s]); DeathMontage(s) + `DeathMontageToRagdollDelay` 2s. PlayFire/Reload with heavy diagnostic logging.
`bWantsToFire` + LastFireAnimTime (WeaponComponent clears after 0.25s).

**Team/identity:** Faction, AccuracyMultiplier (0.65 default), Get/SetGenericTeamId. `IsSquadLeader()` = IsA<Leader> OR tag/name contains "Leader"/"Rostami".

**Pack bridge:** TryBindPackDamageDelegate (finds `BPC_Health*`, probes currentHealth/CurrentHealth/Health double→float; marks bound w/o real bind —
TakeDamage/0.5s poll do the work). SyncPackHealthToSquadAI: mirrors pack HP→HealthComp, kills at 0 (leader floored 35, pack refilled to 50).
NotifyPackDamage → ApplyExternalDamage + damage sense.

## 2. ALeaderCharacter (Rostami — heroic, immortal)
- Ally/Team0, accuracy 0.55, HP 180 (tuning invincible flag), display name "سرگرد شهید ایرج رستمی", tick 0.25s.
- **Tick enforces immortality:** bIsDowned=false, bIsDead=false, HP≥50.
- **Pacing:** player dist >1500 → speed 0; hazard → sprint 720; else lerp normal 400 → waiting 120 between 800–1500, scaled by `AIC->PathSpeedScale` (0.45–1).
- **Waypoint FSM:** NotReached→Moving→Arrived→(WaitingForClear if bRequireAreaClear)→linger→Advance; area-clear via `SoldierRegistry->CountHostilesNear(loc, radius, teamId)==0`.
- **Presentation mirror** (PackDriven default): quest/move-goal/player-dist/waiting/reached/clear state + combat state (firing>bWantsToFire, aiming=AimComp.bHasTarget,
  combatReady=`AIC->HasCombatThreat(0.25)`), LOD-scaled update interval (0.1–0.75s from `AIC->CurrentLODBucket`).

## 3. AAllySoldier (immortal-ish, PowerLevel dial)
- Ally/Team0, `bCanBeDowned=true`, HP 150, tick 0.2s. **Bleedout clamped ≥15s** (never dies; awaits triage).
- **ApplyPowerLevel()** (BeginPlay + DifficultySubsystem): Accuracy=lerp(.05,.85,P), Damage=lerp(.20,1.40,P), FireRate=DefaultFireRate×lerp(.70,1.30,P);
  per-stat overrides (≥0 win). Default P=0.25 (tuning AllyDefaultPowerLevel) unless BP overrode.
- FormationSlot + LeaderOverride; leader resolution: override → static-cached registry scan → TActorIterator fallback.
- Same presentation-mirror pattern as leader (leader loc/dist instead of waypoints).

## 4. AEnemySoldier (mortal attacker)
- Enemy, tuning-driven BeginPlay: accuracy 0.65, Aggression 0.4, SuppressionThreshold 0.6, HP 100, invincible false.
- Coordinator-assigned: AssignedAttackPoint (+leash 2500), CurrentPhase (EAttackPhase).

## 5. UWeaponComponent (hitscan + burst + suppression + penetration)
- **Config:** dmg 8, rate 12/s, spread 1.5+0.3/shot (decay 5, cap 20), range 10000, falloff from 2500 → ×0.35, accuracy mult (ally .25/enemy .65),
  damage mult, burst 5 + 0.4s cooldown, suppression r250 ×0.35, **bullet speed 60000 (lead prediction!)**, penetration ≤40 thick ×0.5 (depth<2),
  whiz sound, logical AI muzzle (h105/fwd35), muzzle-LOS gate ON, pack-fire allowed, debug traces off. Barrel heat 0.08/shot, cool 0.35/s (visual only).
- **FireAtTarget:** pack/dead guards → lead-predict vs registry/player velocity → muzzle-LOS trace (suppressed if blocked by non-health geometry) →
  spread → PerformHitscan → suppression → heat/spread/rate bookkeeping → PlayFireAnimation → delayed shell-casing sound (0.35s) → ally reload voiceline at burst end → OnFired.
- **PerformHitscan (layered hit resolution):** 30cm muzzle-clearance nudge → Visibility trace → **registry ray test (r95, 3 body heights)** so soldiers die even if meshes don't block Visibility →
  **player proximity test (r150, head/chest/pelvis, friendly-fire team check)** → trace blocker (HealthComponent walk-up-attach-chain, else raw TakeDamage) → penetration recurse.
  Damage = base × falloff × DamageMult × Tuning.DamageMult. Ammo is NOT consumed (no clip decrement anywhere in this component).
- **Player damage path** (`ApplyTPWCSPlayerDamage`): ① SoldierCharacter/HealthComp decrement ② TakeDamage + ApplyDamage ③ HUD NotifyDamageReceived ④ TPWCS `currentHealth` property decrement ⑤ `HI_TakeDamage` ProcessEvent (type-matched params). + `EnsureTPWCSPlayerHealthInitialized` (fills 0-max HP to 100).
- **Suppression:** `Registry->ApplySuppressionAlongPath` + bullet-whiz (50–500cm, volume by distance, fallback to AudioManager->BulletWhizBySound).
- **Muzzle:** pack mode → weapon-mesh Muzzle/barrel sockets; else logical shoulder/eye; else mesh socket; else eye+50fwd.

## 6. UHealthComponent (damage chokepoint, no tick)
- Max/Current, bInvincible (+floor, still broadcasts), bIsDead. Events: OnDamaged, OnDeath, OnHealthChanged(%), OnExternalDamageReceived.
- ApplyDamage: downed-owners bypass invincible clamp; broadcasts; player-owner → HUD NotifyDamageReceived; HP≤0 → downed (if bCanBeDowned & not downed) else dead (if !invincible).
- Heal (un-deads!), Revive (full).

## 7. UAimComponent (critically-damped spring, TG_PrePhysics, tick-on-demand)
- Tuning-driven: yaw rate 360, stiffness 14, damping 1.0 (true critical: 2√k·ζ), cone yaw 75/pitch 50, error 2.5°.
- Default `bRotateWholeBodyWhenAiming=true` (CombatTurnRate 540) so soldiers visually face targets without full AnimBP aim-offsets; else body only turns past cone.
- LOD≥3 buckets snap (no spring). **Fully disabled in pack presentation mode** (TPWCS owns aim).
- Outputs: GetAimedRotation (+random error), GetSpineAimOffset (clamped, for AnimBP), IsAimedAtTarget(tol).

## 8. UTacticalGrenadeComponent (ticks EVERY frame)
- Frag 2/4, smoke 2/4, cooldown 3s, launch 1600, class ATacticalGrenadeActor. Player BeginPlay syncs counts from inventory subsystem.
- **G=throw frag / H=throw smoke** edge-triggered via `PC->IsInputKeyDown` (legacy input, not Enhanced Input!).
- Spawn at eye+60/forward+50, +0.28Z arc (direction) or dist-based arc (location); decrements, syncs back to inventory (player only),
  voiceline Leader_OrderEngage, broadcasts OnGrenadeThrown/OnGrenadeInventoryChanged. RefillGrenades clamps to max.

## 9. USquadAITPWCSVisualsComponent (pure-visual TPWCS bridge, no tick)
- Finds `BPC_Weapon*`/`WeaponCharacterAI` comp + weapon/character meshes (tags `TPWCS_WeaponMesh`, names WeaponMesh/Mesh/CharacterMesh0).
- Resolves USquadAIWeaponVisualPreset by WeaponID (default "ak") via asset registry; LoadAllAssets.
- InitializeWeaponPose: ONLY sets left-hand-IK bool (comment: touching more broke the AnimBP).
- SetAimPose: aimingState=1 + traceEndPoint + aimedActor + AIControllerHandle. ClearAimPose: aimingState=0.
- PlayShotVisuals: fire montage ×1.5 + bIsShooting pulse (0.1s) + muzzle flash (Cascade+Niagara) + beam trail (Source/End/Target/Scale params) + impact + `PlaySpatialSoundWithDistanceLayers` (1800/30000) w/ AudioManager fallbacks.

## 10. USoldierAnimInstance (thin C++ AnimBP base)
- Caches SoldierOwner + SoldierAI; every update copies `GetSoldierAnimRuntimeData()` (speed/dir/alive/crouch/combat/fire/cover×8/aim yaw-pitch/full IK+grip) into `bAnim*/Anim*` vars for TwoBoneIK/aim-offset nodes. Tunables: cover thresholds 20/0.35, threat confidence 0.25.

---

## ⚠️ BUGS / FIX-PHASE FINDINGS
1. **MAJOR — `HandleDeath()` has unreachable code:** after the ally branch there is a bare `{ EnterDownedState(); return; }` block, so the player-death branch, death-montage/ragdoll branch, pack `bIsDead` propagation, `DetachFromControllerPendingDestroy()` and `SetLifeSpan(10)` NEVER run. Worse: enemies have `bCanBeDowned=false`, so `EnterDownedState()` no-ops → **enemies become `bIsDead` with zero death visual and never despawn** (unless an external system cleans IsAlive==false actors — verify in Step 4/5: EnemyPool/QuestTicker/MissionZone). Looks like a leftover debug hack.
2. **Player takes multiplied damage:** `ApplyTPWCSPlayerDamage` calls BOTH `Player->TakeDamage()` AND `UGameplayStatics::ApplyDamage()` (=TakeDamage again) AND direct HealthComp.ApplyDamage → up to **3× SquadAI damage**, plus 2× pack-HP reduction (property write + HI_TakeDamage). Needs single-path refactor.
3. **Weapon BeginPlay tuning-override guards are stale:** checks `Damage==15` (header default 8), `FireRate==8` (header 12), `SpreadPerShot==0.4` (0.3), `SpreadDecay==4` (5) → **never true, tuning values for these 4 never apply**. The matching ones (1.5/10000/2500/0.35/250/0.35) work.
4. **NavInvoker radii hardcoded 20000/30000** in SoldierCharacter::BeginPlay, ignoring Tuning NavInvokerRadius 5000/10000 + INI `bGenerateNavigationOnlyAroundNavigationInvokers`. Perf + nav-gen cost concern on 8km map.
5. **Ammo never consumed:** WeaponComponent tracks CurrentClipAmmo/ReserveAmmo but FireAtTarget never decrements; no reload trigger in code (reload voiceline only). If design wants infinite AI ammo this is fine; player ammo must be handled elsewhere (verify in Step 4/6).
6. **Grenade input uses legacy `IsInputKeyDown(G/H)` polling every frame on every soldier** (AI included — harmless but wasteful; player-only tick + Enhanced Input action would be cleaner).
7. **CompleteRevive hardcodes MaxWalkSpeed 450** (leader normal is 400) — revive changes move speed.
8. **Leader HP floors inconsistent:** TakeDamage 35 / Tick 50 / HandleDeath 50 / pack-bridge 35→50.
9. `IsSquadLeader()` name/tag matching is fragile (any actor named *Leader*/*Rostami* qualifies).
10. `TryBindPackDamageDelegate()` never actually binds a delegate (marks bound; poll+TakeDamage do the work) — misleading name/logs.

## Cross-links
- Needs from Step 4: SoldierAIController API (PathSpeedScale, HasCombatThreat, CurrentLODBucket, RestartStateTree, StopCombatPresentation), SoldierRegistry (QueryRadius, CountHostilesNear, ApplySuppressionAlongPath), cover EQS.
- Needs from Step 5: TacticalGrenadeActor, corpse cleanup (CorpseLingerSeconds consumer?), EnemyPool behavior for dead enemies.
- Needs from Step 6/7: QuestNativeHUD Notify* API, AudioSubsystem voiceline enum, adapter component.

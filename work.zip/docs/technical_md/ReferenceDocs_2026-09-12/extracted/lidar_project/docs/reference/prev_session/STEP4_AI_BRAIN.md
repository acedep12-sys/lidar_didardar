# STEP 4 — AI Brain: Controller, StateTree, Fireteams, Cover (DETAILED)

Read: `SquadAI/Public+Private/AI/**` (17 files), `SquadAI/Public+Private/CoverSystem/**` (12 files),
`SquadAI/Public/AI/SquadAICommandTypes.h`. Line counts: SoldierAIController.cpp 1878, TakeCover 538,
CoverSystemSubsystem.cpp 554, CoverScanner.cpp 398, TerrainCoverHelper.cpp 319, Fireteam 379,
EngageTarget 319, FollowLeader 263, AttackCoordinator 248.

---

## 1. SoldierAIController — the brain stem (1878 lines)

### 1.1 Construction / possession / lifecycle
- `UCrowdFollowingComponent` as PathFollowing (detour crowd avoidance for hordes), `bWantsPlayerState=true`,
  `PrimaryActorTick` 0.1s interval + random 0.1 stagger + `bTickEvenWhenPaused=false`.
- `BeginPlay`: applies **all** AI tunables from `SquadAITuning` (senses, memory, suppression, combat, fire ranges)
  into UPROPERTYs (see §1.6); `EndPlay` stops/pushes AI budgets, releases cover reservation.
- `OnPossess`: TeamId **Enemy=1 else 0**; adds runtime `USquadAIAdapterComponent` if missing;
  enemy → Ensure→`RequestDifficultyProfile` from Director; StateTree **StartLogic only if dormant**
  (no restart if already running) + **2s safety-net timer** that force-starts a still-dormant tree.
- `SetupPerception` runs on a **1s delay** after BeginPlay (comment: avoids clash with TPWCS competing brain):
  sight (range/angle from tuning, loses-sight 5s, detection-by-affiliation enemies+neutrals), hearing,
  damage sense; binds `OnPerceptionUpdated`.
- Perception callback: hostile-only filtering, **voiceline** on new hostile (Combat contact + 35% chance,
  only if AI service + enemy faction present), forwards to memory.

### 1.2 Tick (0.1s) pipeline
1. Suppression decay (SuppressionDecayPerSecond; **halved while bHasCover**), clamped ≥0; high-suppression voiceline.
2. `UpdateMemory(Delta)` — decay + drop dead/destroyed actors.
3. `PollPerception(dt)`: every **0.5s** `PollRegistryForHostiles`, every **0.25s (= every tick-ish)** `TickThreatReacquire`
   (decay fast 0.1/s if no stimulus >5s).
4. `RunDirectCombatFallback(dt)` — aim+shoot when tree doesn't (see §1.4).
5. Enemies: `RunDirectEnemyMovement(dt)` — always-on movement driver (see §1.5).
6. Warmup gate for engagement (`bHoldDuringWarmup`, veil alive).
7. Significance/LOD decay multiplier; leader mission-stride pathing tick.
8. Busy-wait stall detector: >10 frames same task → `RequestCoverAndStrafe` positional refresh.

### 1.3 Memory / targeting model
- Live store: `TArray<FPerceivedTarget>` (actor, conf 0..1, last-seen, last-known-pos, visible flag,
  spawn-grace timestamp) — **NOT** the `UPerceptionMemory` class (dead code, see Bugs §7.1).
- `UpsertPerceivedHostile(actor, bSensed, pos)`: new contacts enter at **0.65 conf visible / 0.15 heard**;
  seen → conf=1, pos+time updated; unseen ticks decay `MemoryDecayRate*dt`; new-but-unseen entries removed;
  removal below `MemoryMinConfidence`.
- `IngestSharedThreat`: fireteam-shared intel enters at `max(0.15, conf)` as non-visible.
- `GetPrimaryThreat()`: skips actors in spawn grace; score = `conf*1000 − dist²*0.001`; ties → nearest.
  `GetPrimaryThreatLocation()` returns live pos if visible else last-known.
- `HasLineOfSightTo(target)`: 0.12s-cached Visibility trace eye→target+88cm; **smoke-blocked check first**
  via `USquadAIRegistrySubsystem::IsLineOfSightBlockedBySmoke`.

### 1.4 Direct combat fallback (runs even if StateTree stalls)
- Gates: enabled, has threat, conf ≥0.15, dist ≤ `DirectCombatRange` (1500), LOS-or-close (≤500 near = auto-visible).
- Aim: `Adapter->AimAt(threat + 70cm up)`; movement: fireteam-hold members cap range at 2800 else 1500.
- Fire: **1s burst cycle** (`TryStartBurst` + `Adapter->SetTriggerDown`, release between bursts).
- Grenades: smoke when **suppression ≥0.7** (leader-distress path), frag toward threat at 800–2200cm with 35% roll.
- ⚠️ `bAllowDirectCombatFallbackFire` + `DirectCombatFallbackFireRange` are **set from tuning but never read**
  (Bugs §7.3) — fallback always fires when it runs.

### 1.5 Enemy direct movement (threat advance / zone defense / player hunt)
- If threat with conf ≥0.2 + LOS: **advance, halt at 550cm**; strafe via fireteam slot (220cm accept).
- With active fireteam attack: hold slot; no team: hunt player pawn **500–12000cm** band.
- Mission zones honored: **Clear** (advance through zone), **Defend** (stay within radius of post).

### 1.6 Controller tunables (UPROPERTY, all overwritten from SquadAITuning in BeginPlay)
Senses: SightRange 1200 / LoseSightRange 1400 / PeripheralAngle 90 / HearingRange 2500 / DamageRange 3000.
Memory: sighted grace 1.5s / decay 0.35 / min-conf 0.15. Suppression: threshold 0.85 / decay 0.25 / move-slow 0.45.
Combat: DirectCombatRange 1500 / AimAtThreatRange 2500 / MaxEngageDistance 3000 / Min 150 /
SuppressionFireThreshold 0.6 / FireBurstLength 1.0. Cover: SearchRadius 1500 / TacticalRadius 2000.
Regen 2.5/s after 5s. LOD: PollIntervalFar 0.75 / RangeFar 4500 / LOSBudgetNear 3 / Far 1.

### 1.7 Leader movement driver (fire-aware pathing)
- Gates: not downed, leader role, warmup-veil, no close combat (conf≥0.55 or hostile ≤ min(DirectCombat,1500)),
  player pacing: **wait if >3500cm ahead of player**, 180cm arrival.
- **Fire avoidance** (`ShouldAvoidFireAt` + side-step): 0.25s-cached fire-hazard query; if INSIDE fire → MoveTo
  nearest safe point and sprint; chord-vs-max path analysis → sprint-through (short hazard) vs perpendicular detour;
  spline guide, **0.45s hesitate + 1.15s sprint**, turn-rate and trench speed scaling; `PATHDBG` gated debug draws.

### 1.8 Cover plumbing on the controller
- `RequestCover(threat, radius)`: async via CoverSystemSubsystem; callback sets PendingCover →
  TakeCover consumes; guards re-request <1.5s.
- `SetInCoverState/SetHasCover`, `ClearCover`, `FaceCoverDirection`, `GetCoverNormalWorld`,
  `GetCorridorSlot` (V-slot for FollowLeader), revive-progress passthrough to soldier.

---

## 2. StateTree: schema, evaluators, tasks

**Schema** `UShooterAIStateTreeData` (`ShooterAIStateTreeData.h/.cpp`):
bindings `AIController` (controller), `ControlledPawn` (pawn), `SelfActor`, `ThreatActor` (EStateTreeAnyEnum/NoVariant),
`ThreatLocation`, `CoverLocation`, `CoverNormalWorld`, `MissionGoal`, `Suppression`, `HealthFraction`,
`bHasCover`, `bIsInCombat`, `SlotIndex`, `FireteamRole`.
**Evaluators** tick from controller: Threat (primary actor+visible flag), Suppression, Health.
Missing binding → evaluator logs once and stops updating that channel (fail-soft).

| Task | Enter | Tick | Exit |
|---|---|---|---|
| **HoldPosition** | — | Aim at visible threat (conf≥0.2, ≤MaxEngage) else clear presentation; optional duration timer | — |
| **EnemyMission** | — | Priority: visible threat → player pawn → mission goal; MoveTo 300 accept; repath if goal moved >500 or same-goal >2s; warmup hold | — |
| **LeaderPath** | — | Warmup-veil hold; close combat → cancel move, aim+70, RequestCover-once, move to pending cover (300 accept, ≤350 arrival = Succeeded); else ClearCover, wait if >3500 ahead of player, AITask_MoveTo goal 250 accept | — |
| **TakeCover** (538) | reentry cooldown → Succeeded; pack close-combat override; resume active goal; 0.75s debounce; RequestCover max(Search,Tactical) | real cover → Reserve + MoveTo; natural-cover + obstacle-intercept + fallback-grid analyses; timeouts 3.5/1.5s → open-ground Succeeded; moving: arrival → set/clear cover + face normal (teleport-rotate); not-moving 0.75s → re-request; 8s stuck → Succeeded | **releases reservation** (keeps active goal+cover state for Engage) |
| **EngageTarget** (319) | real cover → Waiting (crouch) else Peeking (open ground); bEngageAtWill | Waiting: open-ground→peek; supp>threshold resets cycle; cooldown→stand+peek. Peeking: aim update, burst once; **muzzle raycast every 0.5s**, MaxBlockedShots→Succeeded; open-ground re-burst per peek duration; cover → Cooldown on timer or supp>1.2×thr. Cooldown: Cycles≥Max(3)→Succeeded else back to Waiting | restores stance, clears cover state |
| **FollowLeader** (263) | — | find leader (override else cached/TActorIterator 0.5s cache); downed→stop+crouch; **revive** downed ally ≤2500 (MoveTo 120 or crouch+ApplyReviveProgress); V-slot via corridor with 1.75× slack; repath if drift>max(thr,550) or >accept×1.35, stagger 1.15+slot×0.2s; MoveTo loose slot+jitter+NudgeOutOfFire; opportunistic fire conf>0.3 per 2.5s cd | — |

- Suppression gate is **enemy-only**: `SupThreshold = bIsEnemy ? controller threshold : 100` → allies never gated.
- `FStateTreeDataHandles` (SquadAICommandTypes.h): shared blackboard-ish struct for threat/cover/mission/suppression.
- `FSquadAIOrder` (same header): order struct for command layer (used by command system, Step 5).

## 3. Enemy fireteam subsystem (379 lines)
- `RegisterMember(TeamKey)`: slot = index; `EnsureAssignTimer` debounce → `RunAssign`.
- `AssignTeam`: compact dead; best shared threat (max conf); leader = closest-to-threat else closest-to-centroid.
- Roles cycle by slot: **Suppress** (threat−fwd×2400, ±450 jitter) / **FlankL/R** (threat±right×(1800+250n), −500 fwd)
/ **Assault** (threat−fwd×(800+200n)); no-threat → V-formation slots; **Lead** = threat−1400.
- Pushes per-AI: role, slot, move goal, shared threat; `IngestSharedThreat(max(0.55, conf×0.85))`; 3s state log.

## 4. Enemy attack coordinator (248 lines, tick 0.25s, gated)
State machine: **Idle → Gather → Suppress → Flank → Assault → Hold**. Transitions:
BeginAttack needs MinEnemies → Gather; ≥60% within 800cm or 15s → Suppress; timer → Flank;
timer → Assault; ≥50% within 600cm or 20s → Hold (indefinite). `TransitionTo` sets attack points;
Flank: `AssignRoles` Ceil(n×ratio) flankers + flank point attack+right×1500.

## 5. Cover system

### 5.1 CoverSystemSubsystem (554) — chunked async cover brain
- `Initialize`: caches tuning (chunk 1000, 6×6 samples, 96 traces/frame, scan 2/frame, timeouts) +
  `Scanner.Configure`; `Tick`: finalize completed → scan queue → resolve queries → debug draw.
- `RequestCoverAsync(querier, threat, radius, cb)`: computes required chunks, queues unscanned (+ref-Z),
  stores pending query. Queries **can resolve partially** after `PartialResolveSeconds`, else fail at timeout.
- `KickChunkScan`: Phase-1 floor samples → **Phase-2 submits ALL samples' probes** (overrides 96/frame budget
  deliberately — "queries go unfulfilled under threading"); finalize on completion.
- `ResolveSingleQuery`: skip reserved; within radius; **mission-anchoring** (reject cover taking AI >900cm
  farther from mission unless very close); score = threatFacing×1.5 + closeness×1.25 + mission-progress×0.0015;
  **top-8 verify**: +2.0 if real protection trace blocked, +1.0 if any of 4 peek points has a shot; best>0 wins.
- `HasPeekShotFromCover`: 4 peek origins (160/125/145±70cm lateral) → threat+90; `IsProtectedByCover`:
  threat+90 → body+85 blocked.
- Reservations: Reserve/Release by (ChunkKey, LocalID) — only caller is TakeCover.
- `InvalidateArea` (destruction hook), `ForceScanArea`, `GetAllCoverPointsInRadius` (EQS/debug),
  debug draw color-coded by height (green/yellow/orange/red, purple=reserved).

### 5.2 CoverScanner (398) — 4-phase async probing
- Phase 1: per-chunk 6×6 grid → vertical Visibility trace in **ReferenceZ ± max(500, halfheight)** band
  (map Z varies 6000–22000; uses querier altitude) + 50000cm fallback trace; NavMesh project (50,50,NavExtent).
  ⚠️ 1440 async traces per chunk (36 samples × 8 dirs × 5 heights, 450cm reach) × 2 chunks/frame — perf note.
- Phase 2: `SubmitAsyncProbes` with per-trace context map (chunk/sample/dir/height → `OnAsyncTraceComplete`);
  probe heights 15/35/crouch/100/stand; comment documents a fixed cross-chunk key bug.
- Phase 3: harvest → HitResults/Distances/Actors; sample complete when pending=0.
- Phase 4: `FindBestDirection` (≥2 heights blocked, max hits) → `ClassifyHeight`:
  crouch+high=High, knee/crouch=Low (sandbag-friendly), high-only=Partial → lean sides (perp ±90° clear at
  crouch height; Over if crouch blocked + head clear) → `ArcScore` (#dirs blocked <80cm / 7) → AI stand pos
  70cm behind → dedup (<25cm + normal·>0.8).
- `ScoreAgainstThreat` (0..1): facing 0.4 + arc 0.3 + height 0.2 (High .2 / Low .14 / Partial .06) + leans 0.1.

### 5.3 Open-terrain / tactical / EQS
- **TerrainCoverHelper (319, namespace TerrainCover)**: exact height probes every 10cm (ECC_WorldStatic, 200cm);
  body-coverage model legs 30 / torso 40 / head 30; trench detect (≥40cm below 150cm-ring avg, cap 170);
  enclosed-space reject (ceiling + 3/4 walls, trench-exempt); escape-path check (retreat + ±30°);
  lean-quality 0..1 per side; weighted scorer (coverage .4 / arc .2 / lean .15 / trench .1 / escape .1 / height .05).
  ⚠️ Entire namespace is **never called** (Bugs §7.2).
- **TacticalCoverGeneratorActor**: editor-placeable box (2000,2000,500), BeginPlay→Bake (grid 250cm,
  low 75 / high 175, 120cm cardinal detect). ⚠️ `GeneratedCoverLocations` is **write-only** — never fed into
  the subsystem; only the ForceScanArea side-effect matters (Bugs §7.4).
- **EQS**: generator emits unreserved points ≤ SearchRadius as Point items; test scores vs threat context
  via `ScoreAgainstThreat` (temp scanner, stateless — fine). Intended for EQS visual debugging, not the live path.

---

## 6. Tunables quick index (Step 4 surface)
Controller senses/memory/suppression/combat/cover/regen/LOD (§1.6) + cover chunking
(ChunkSize 1000, SamplesPerAxis 6, TraceBudget 96, ChunksPerFrame 2, async timeouts) + fireteam geometry
(Suppress 2400 / Flank 1800+250n / Assault 800+200n / Lead 1400 / V-slots) + coordinator
(MinEnemies, Gather 60%@800/15s, Assault 50%@600/20s, FlankRatio, +1500 flank offset) +
Engage (peek 1.2s / cooldown 2.0 / MaxCycles 3 / MaxBlockedShots 3 / conf 0.2 / 0.5s muzzle check) +
TakeCover (debounce 0.75 / timeouts / reentry 8s / stuck 8s) + LeaderPath (combat dist / 3500 pacing / 180 accept).

## 7. Bugs / dead code found in Step 4 (11)
1. `UPerceptionMemory` (enhanced decaying memory w/ prediction + forgetting curve) is **never instantiated** —
   controller uses its own simpler `FPerceivedTarget` array. Either wire it or delete it.
2. `namespace TerrainCover` (319 lines: trenches, body coverage, lean quality, open-terrain scorer) is
   **never called from anywhere** — open-terrain sophistication is dormant.
3. `bAllowDirectCombatFallbackFire` + `DirectCombatFallbackFireRange`: set from tuning, **never read** —
   fallback always fires; the "production safety" switch does nothing.
4. `TacticalCoverGeneratorActor::GeneratedCoverLocations` is **write-only**; baked points never reach the AI.
5. `GEnemyPatrolTimer` / `GEnemyPatrolGoal` static globals declared, never used.
6. TakeCover **releases its reservation on ExitState** — while Engaging from that cover the point is
   unreserved, so a teammate can be assigned the identical spot.
7. `EnemyMission` enemies always know the player pawn location with **no range limit** (omniscient hunting);
   the controller-side hunter at least gates 500–12000cm. Intended wave behavior or missing stealth?
8. Cover scan submits **~1440 async traces/chunk × 2 chunks/frame** — physics-thread spike on first contact
   in new areas (budget override is deliberate but untracked).
9. `CoverScanner::MakeSampleKey` (`(X*100000+Y)*1000+sample`) can theoretically **collide for negative chunk
   coords** (e.g. X=1,Y=−50000 vs X=0,Y=50000) → cross-chunk sample corruption. Use int64 bit-pack instead.
10. TakeCover arrival does `Pawn->SetActorRotation(Normal.Rotation())` — **teleport-rotates** the soldier
    to face the threat; should be a smooth turn ( cosmetic snap).
11. `SetupPerception` 1s delay + `StartLogic` 2s safety net mean AI is **deaf/blind/dormant for the first
    1–2s after spawn**; also `OnPossess` adds adapter/StateTree even for non-combat pawns (harmless but noisy).

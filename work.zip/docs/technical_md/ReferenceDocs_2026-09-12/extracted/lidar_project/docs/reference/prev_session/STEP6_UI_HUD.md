# Step 6 — UI / HUD / Farsi / Loading / Save — Full Findings

Scope: `SquadAI/Public+HUD/*` + `SaveSystem/*` = **9848 lines** across ~30 files.
 read 100%: all small HUD headers+cpps, `FarsiTextHelper`, `QuestNativeHUD.h/.cpp` (335+3009),
 `SquadAIMainMenuHUD.h/.cpp` (476+2748), `SquadAISaveGame.h/.cpp`, `SquadAISaveLoadSubsystem.h/.cpp` (408).

## 1. Big picture: THREE HUD stacks, only one is live

| # | Stack | Driver | Status |
|---|-------|--------|--------|
| 1 | UMG snapshot widgets: `QuestHUDWidget` (master) + `MissionBriefing/Compass/Minimap` children | `QuestTickerSubsystem.OnHudUpdated` @4Hz | **Suppressed at runtime** (see B6-2). Snapshot zone/objective wiring left as empty stubs anyway |
| 2 | QuestChain-bound UMG: `QuestChainHUD` (0.5s pull), `QuestMissionWidget` (0.5s pull, shaped Farsi), `QuestCompletionWidget` (zoom/flyout anim) | direct `AQuestChain` bind | **Suppressed at runtime** (QuestMissionWidget is in the kill list) |
| 3 | **Canvas HUDs**: `AQuestNativeHUD` (gameplay) + `ASquadAIMainMenuHUD` (menus) | `DrawHUD()` immediate-mode | **THE live UI. All fix work lands here** |

`SquadAIMainMenuWidget` is a thin UMG shell (New/Continue/Load/Settings/Difficulty nav) over the
 same subsystems; the Canvas menu (`bUseProceduralCanvasMenu=true`, default) draws instead whenever
 `ActiveMenuWidget==nullptr`. `LoadingScreenWidget` (radar/progress/tips/deploy gate) is the UMG side
 of the `SquadAILoadingScreenSubsystem` transition (subsystem itself is Step 7).

## 2. Farsi pipeline (shared by everything)

`UFarsiTextHelper` (`typedef ... FFarsiTextHelper`, same class — both call styles exist, no issue):
 41-entry contextual glyph table (isolated/final/initial/medial + right-join flags, Lam-Alef
 ligatures, tashkeel strip, ZWNJ dropped 0x200C→skipped) + token-based BiDi line reorder with
 bracket mirroring. `ShapeAndOrder` = Persian digits → shape → reorder. `FindGlyph` is O(41)
 linear per char — called per-draw-call on every frame for every string (perf note, §9).
 Both Canvas HUDs wrap it in `DrawFarsiText` / `DrawFarsiTextBounded` (auto-shrink-to-fit,
 optional center + vertical-center in box, drop shadow) and `GetFarsiTextSize`.

## 3. AQuestNativeHUD — gameplay HUD (3009 lines, `SquadAI/Private/HUD/QuestNativeHUD.cpp`)

**BeginPlay:** auto-resolves ~20 textures via `FSquadAIAssetHelper::LoadTextureSafe(GamePath,
 FallbackPng)` (weapon icons G3/AK/RPG/MG3/SVD/fist, veil art, button/loading-bar plates, 5 pouch
 icons, fallen-notes art); collapses any `WBP_*` / `QuestHUDWidget` / `QuestMissionWidget` /
 `MissionBriefingWidget` / `TPWCS` UMG by class-name match.
**Font:** `SquadAITuning.HUDFontPath` (statically cached `LoadObject`) → `Tuning.HUDFont` →
 `GEngine->GetMediumFont()`.

**DrawHUD master order** (all positions hardcoded px, NO UIScale — 1080p-assumed, B6-14):
 1. Dev hotkeys: `DevSys->PollDeveloperHotkeys(PC)` every frame (bundle: F1–F7 cheat/test keys).
 2. `RebuildSoldierDots()` when `TimeSinceRefresh==0` (i.e. every `RefreshInterval`=1.0s) or empty —
    registry-first, `TActorIterator` fallback; skips dead, skips neutrals.
 3. Legacy-widget suppression sweep every 1.5s (`TObjectIterator<UUserWidget>` over ALL widgets —
    expensive-ish, B6-2/B6-15).
 4. **Exclusive full-screen modes (early return):** pause menu → inventory → deployment veil.
 5. Overlays: low-HP blood vignette (<35%, pulsing), fire-burn vignette (while `bIsPlayerBurning`),
    suppression vignette (decays 1.25/s toward 0 *inside the draw call*).
 6. Directional damage arcs (max 8, 1.25s life, rotated by control yaw) + crosshit hitmarker
    (white hit / red kill, 0.25s) + dynamic reticle (spread 8 crouch-still → 32 sprint, interp 12/s).
 7. Compass ribbon (top-center, 90° FOV, cardinals + degree ticks, gold mission pip + blue leader pip).
 8. Weapon/health plate (top-right 360×92): SquadAI `WeaponComp` (clip/reserve/display name) →
    visual-only fallback "ژ-۳ / ۲۰/۱۲۰" → TPWCS reflection fallback
    (`ActiveWeapon/CurrentWeapon/EquippedWeapon/WeaponName` + `currentAmmo/...`, reserve hardcoded
    `/120`). Icon via `GetHUDWeaponIcon` substring match (order AK→RPG→MG3→SVD→Unarmed→G3-default;
    MG3-before-G3 ordering is load-bearing and correct). HP bar green→amber→red + `سلامت: n%`.
    `GetPlayerHealthPercent`: `HealthComp` → TPWCS reflection (`currentHealth/CurrentHealth/Health/HP`
    + max variants, default 100).
 9. Ally-downed banner (6s pulse, shows ally name + [E] hint).
 10. Mortar: hold **MiddleMouse** → camera ray (20m) sets aim; on release plays
    `Ally_IncomingGrenade` voiceline (! — wrong line, should be fire-support call, B6-16) and
    `SpawnActor<ATacticalMortarBarrageActor>->StartBarrage(target)`. `RegisterIncomingMortarWarning`
    draws terrain-snapped 28-seg danger ring + floating countdown badge (`⚠️ خطر اصابت خمپاره`).
    Aiming marker draws 750m blast + 450m dispersion circles + bobbing holo arrow + order card.
 11. Tactical 3D pings (`SquadAIPingSubsystem`, Move/Danger/Hostile/Defend diamonds + `[n m]` tag).
 12. Interaction prompts (all projected, 20px edge-culled): ammo crates (visible ≤400, accent ≤220,
    uses crate's own `PromptText`), downed allies (visible ≤2000!, E-hold revive with progress fill,
    bleedout bar; **leader excluded — invincible**), first-aid kits (≤400/200, hardcoded `[E] برداشتن`).
    Medical stations / turrets / barrels have NO prompts despite the comment claiming so (B6-17).
 13. Guidance vision (hold **V** or `SetGuidanceVisionActive`): 6/s blend; desat veil + gold frame;
    goal = current `MissionZone` (`CustomBadgeText` or موضع عملیاتی) else leader (فرمانده سرگرد رستمی);
    24-step ground-clamped (line trace per step, per frame!) gold ribbon with flow pulse + chevrons;
    header banner with Farsi distance; downed allies get pulsing red rescue rings + labels, others dots.
 14. Minimap (bottom-right, R=100): `USceneCaptureComponent2D` ortho snapshot from 3000cm over
    20000cm width into a 512 RT (BaseColor only, lighting/particles/fog/shadows/PP off), recaptured
    (≥0.5s apart) on 400cm move or 10° yaw; drawn via Tuning minimap MID (`MinimapTexture` param)
    else raw tile else green fallback box. Rotating projection; mission icon / leader icon / ally dots
    (downed = pulsing red + expanding ring) / enemy rects / player dot from Tuning icons with
    primitive fallbacks. Static "N" label is wrong on a rotating map (B6-18). Off-map mission/leader
    get border pips (only while chain active).
 15. Squad panel (bottom-left 380×220): header + `CommandSubsystem` stance line, leader row (name +
    distance + blue HP bar), up to **3** allies (HP or bleedout bar when downed), frag/smoke counts
    from `GrenadeComp` (`[G]`/`[H]` hints).
 16. Objective card (top-left 380×105): type badge (Reach=gold پیشروی / Clear=red پاکسازی /
    Defend=cyan پدافند, `CustomBadgeText` override), `مرحله n از m`, description, `MissionProgress`
    bar, defend timer (`FormatTimerPersian`) or `نیروهای دشمن: n`.
 17. Defend countdown banner (top-center red bar) for active Defend missions.
 18. Radio subtitles (bottom-center): **HUD drives `RadioSys->TickRadio(DeltaTime)`** then shows
    last message + `بیسیم تاکتیکی // ستاد جنگ‌های نامنظم` header while time remains.

**Deployment veil** (in-level load gate, `bDeploymentVeilActive` starts true): artwork/vignette,
 fake progress +0.42/s (~2.4s), dossier card with localized title/desc, % readout, then pulsing
 Enter/Space/Pad/Click prompt → dismiss + `Leader_OrderMove` voiceline. Separate layer from the
 `LoadingScreenSubsystem` level-transition screen (Step 7) — two loading UXs, don't confuse them.
**Pause menu** (`TogglePauseMenu`, real `SetGamePaused` + cursor + GameAndUI): 5 buttons
 (resume/save/restart/quit-to-menu `L_MainMenu`/quit-to-desktop) + save-result toast 4s. Save writes
 literal slot `"AutoSave_SquadAI"` (B6-1).
**Inventory** (`ToggleInventory`, pauses + `Inv->OnInventoryOpened()`; I/Esc close, Q/E cycle
 weapons): 6 tabs backed by `USquadAIInventorySubsystem` — (0) weapons carousel + equip + ballistics
 bars + live ammo, (1) fallen notes (multi-line letters + next-note), (2) pocket radio (station,
 freq, power, tuner, 24-bar EQ while playing), (3) pocket Quran (verse+translation, next-verse),
 (4) ID/wallet dossier (hardcoded identity strings!), (5) supplies grid (FirstAidKits/FragGrenades/
 SmokeGrenades/CanteenWaterPercent + 2 static flavor items).
Draw helpers: `DrawChiseledTacticalBox` (chamfered + tick marks), `DrawWeaponSilhouette`
 (RPG/AK/SVD/G3-default line art), `DrawCircleLines` (24-seg), `DrawFilledCircleArea` (**squares**,
 B6-3), `DrawIcon`, `DrawBorderIndicator`.

## 4. ASquadAIMainMenuHUD — Canvas main menu (2748 lines)

Immediate-mode: ctor (Persian preset + theme + 10 `ConstructorHelpers` texture finds) →
 BeginPlay (cursor, GameAndUI, 45 sand motes, `AutoResolveMissingTextures` ~40 `LoadTextureSafe`
 calls) → per-frame `DrawHUD`: KenBurns/material/grid background + sand + scanlines → header
 title/subtitle + laser divider → active screen registers click rects into `ClickableButtons`
 (**emptied every frame** — same-screen ID uniqueness is all that matters) → hover-sound on change →
 `ProcessClickAtMousePosition` on click. `UIScale = clamp(ScreenH/1080, 0.70, 1.35)` used throughout
 (unlike gameplay HUD). 4 color themes (`ApplyThemeColors`), Title/Menu/Body fonts, 4 SFX slots.
 Name editing: full key capture incl. **ISIRI-2901 Persian keymap**, F2/Tab toggles fa/EN, 28-char cap.
**Screens & button IDs** (`NavigateToState` resets cascade/slide; Armory/MapSelect reset sel→0):
 - Main: 1 hero New Game → Difficulty; 7 Continue (latest save if `HasAnySaveGames()` else deploy
   `TargetGameplayLevelName`=`L_Khuzestan` via LoadingScreenSubsystem else OpenLevel); 2/3/4/5/6/8 =
   Map/Armory/Progression/Profile/Achievements/Load; right dossier card (avatar, level, sitrep slate,
   kills/playtime boxes, XP bar; click=10 → Profile); bottom bar 10 Briefing / 9 Settings / 11 Quit
   + fake audio visualizer. ID 10 disambiguated by `MenuState==Main` (dossier→Profile else Briefing).
 - MapSelect: 100+i select, 199 launch (`LoadingScreenSubsystem.StartDeploymentTransition(LevelPkg,
   MapID)` else OpenLevel), 99 back. 16:9 preview + briefing slate + reward line.
 - Armory: 200+i select, 298 unlock (`Prog.UnlockWeapon`, needs level), 299 equip (`Prog.EquipWeapon`);
   **G3A3/AK47 hardcoded unlocked**; showcase + 4 stat bars + ≤2 trait badges.
 - Progression: 300+i buy node (`Prog.UnlockProgressionNode`); hover-inspect deck w/ category art
   (Leadership/Marksmanship/Endurance/Tactics/Engineering by NodeID substring, index-mod-5 fallback);
   milestone track = filled cells = unlocked count (not per-node ranks).
 - Profile: 410+i switch (shows ≤3), 460 create (`رزمنده N`), 400–403 avatar, 450 edit/save, 451 cancel,
   452 random (`CyclePresetCallsign`), 453 lang toggle, 480–483 martyr preset chips (instant-apply),
   **600+ki on-screen Persian keyboard** (33 keys); 8 lifetime-stat rows (dual-field fallbacks:
   CurrentLevel/PlayerLevel, EnemiesEliminated/EnemiesHunted, AlliesRevived/TriageRevives).
 - Achievements: 500+i inspect-**on-hover** card + list (icons via `GetTraitTexture` substring match).
 - Difficulty: 501–504 = set `DifficultySubsystem` + deploy L_Khuzestan (4 themed columns w/ modifiers).
 - LoadGame: **600–603 slots** (`GetAllSaveSlots`, 4 slots, timestamp or خالی) → `LoadGameFromSlot(i)`.
 - Settings: **placebo** — 4 hardcoded rows (Epic/فارسی/100%/90%), IDs 701–704 never handled (B6-4).
 - Briefing: static classified dossier, 99 back.
ID-range reuse across screens (500s achievements vs difficulty, 600s Farsi-keys vs load-slots, 10
 dossier vs briefing) is benign ONLY because of the per-frame rebuild — fragile, document before touching.
`MenuTextConfig` (19 Farsi strings) loads from `LocalizationSubsystem` (forces `fa`) with hardcoded
 defaults; `ApplyEnglishPreset` exists for EN. Continue flow: `LoadLatestSave()` (most-recent by
 Timestamp across auto/quick/Slot0-9/manual).

## 5. Small widgets (UMG, currently suppressed — see B6-2)

- `QuestHUDWidget`: master container binding `OnHudUpdated(FQuestHudSnapshot)`; owns Briefing/Minimap/
  Compass child refs; zone/objective snapshot wiring are **empty stubs**.
- `QuestChainHUD`: 0.5s timer pull of `AQuestChain` (title/index/state/counts).
- `QuestMissionWidget`: 0.5s pull of current `MissionZone` (badge/desc/progress/timer, shaped Farsi,
  checklist, distance) — in the native-HUD kill list.
- `QuestCompletionWidget`: completion zoom/flyout animation widget.
- `MissionBriefingWidget` / `CompassWidget` / `MinimapWidget`: children of the master (briefing text,
  cardinal compass, simple dot minimap).
- `LoadingScreenWidget`: radar sweep, progress bar, rotating tips, deploy-gate prompt — UMG face of the
  Step-7 loading subsystem.
- `SquadAIMainMenuWidget`: UMG menu shell (New/Continue/Load/Settings/Difficulty + save-exists flag);
  unused while `bUseProceduralCanvasMenu` is true (default) and no widget is spawned.

## 6. Save system (`SaveSystem/`)

**Container** `USquadAISaveGame`: SlotName/Timestamp/MapName/SectorDisplayName/ActiveMissionTitle+Index/CompletedMissionCount/
 DifficultyRating/XP+Level/Achievements/PlayerTransform+HP/AmmoInClip/SavedAllies(TArray
 FAllyData: name/transform/HP/down/dead)/SavedSettings(quality preset, vsync, volumes, language).
 Farsi-flavored defaults (`L_Khuzestan`, G3A3, دهلاویه).
**Subsystem** (`USquadAISaveLoadSubsystem`, GameInstance; ctor loads+applies settings):
 slots = `SquadAISave_Manual`(default) / `SquadAISave_Slot0-9` / `SquadAISave_AutoSave` /
 `SquadAISave_QuickSave` / `SquadAISettings_Profile`. `SaveGame`→gather→`SaveGameToSlot`→`OnSaveCompleted`;
 `LoadGame(slot, bTransitionToMap)`→`LoadLevelWithScreen(map…)` else `ApplySaveDataToWorld`→`OnLoadCompleted`;
 Quick/Auto/Delete/DoesExist/`GetAllSaveSlotNames`(auto+quick+Slot0-9+manual)/`ReadSaveMetadata`/
 `GetMostRecentSaveSlot`(loads EVERY slot to compare timestamps — slow-ish, fine at this scale)/
 `HasAnySaves`(+`HasAnySaveGames` inline alias — the menu call compiles, verified)/`LoadLatestSave`/
 `LoadGameFromSlot(i)`/`GetAllSaveSlots`(4-slot UI view, DisplayName=sector or `موقعیت ذخیره شماره n`).
`SaveSettings`/`LoadSettings` round-trip the settings slot; `ApplySettingsToEngine` applies ONLY
 quality preset + vsync — volumes/language saved but never applied (B6-9).
`GatherWorldDataIntoSave`: player transform + HP + `AmmoInClip = WeaponComp->BurstShots` (**wrong
 field** — should be CurrentClipAmmo, B6-6); allies via `TActorIterator<AAllySoldier>`; FIRST
 `AQuestChain` only (`ActiveMissionIndex = CompletedMissionCount = CurrentMissionIndex` — completed
 == active, B6-7); difficulty int. **Never gathers**: XP/level/achievements/unlocks/radio/notes —
 `FSquadPlayerProfile` progress shown in menus is NOT persisted here (unless ProgSubsystem self-saves;
 Step 7 must confirm — B6-10).
`ApplySaveDataToWorld`: player transform + `bIsDowned=false` + HP + `bIsDead=false`; chain index
 restore then `StartChain()` if `bAutoStart` — **but `StartChain()` resets index to −1→0, discarding
 the restore** (B6-8, verified in QuestChain.cpp:99); difficulty clamp 0–3. **Allies never restored**
 (`SavedAllies` is write-only — B6-11); ammo never restored. Called ONLY when `bTransitionToMap=false`;
 the `true` path relies on `LoadingScreenSubsystem.LoadLevelWithScreen` to apply post-load —
 hookup unverified (B6-12, Step 7).

## 7. Tunables & config index (UI/HUD/save)

- `QuestNativeHUD`: MinimapRadius/Margin/CaptureHeight(3000)/CaptureWidth(20000)/Resolution(512),
  RefreshInterval(1.0), 9× `bEnable*` feature flags, `GuidanceVisionKey`=V, weapon/item textures,
  `MainMenuLevelName`=L_MainMenu.
- `SquadAITuning` (read by HUD): HUDFontPath/HUDFont, MinimapMaterialPath/Material(`MinimapTexture`
  param), MissionZoneIcon/LeaderIcon/AllyIcon/EnemyIcon/PlayerIcon, Mission/LeaderBorderIcon,
  MinimapBorderColor/Thickness.
- `SquadAIMainMenuHUD`: MenuTextConfig(19 strings), BackgroundType(StaticImageKenBurns default),
  ~45 texture slots (backgrounds/frames/avatars/traits/maps/weapons/difficulty/progression),
  ColorTheme + 3 palette colors, 4 SFX, 3 fonts, MenuWidgetClass, TargetGameplayLevelName,
  bUseProceduralCanvasMenu(true).
- Save slots/names: see §6. Settings slot applies quality+vsync only.
- Gameplay keys owned by HUD: V guidance, E revive/interact, G frag, H smoke, I/Esc inventory,
  Esc pause?, MiddleMouse mortar, Enter/Space deploy. (Pause open key + inventory open key live
  outside HUD — Step 7 input/PlayerController check.)

## 8. Bugs & risks (Step 6)

- **B6-1 Pause-save slot mismatch (real):** pause menu saves to literal `"AutoSave_SquadAI"` but
  subsystem `AutoSaveSlotName = "SquadAISave_AutoSave"`; `GetAllSaveSlotNames()` never scans the
  pause slot → pause saves invisible to Continue / MostRecent / HasAnySaves. Fix: use the subsystem
  constant (needs a getter — it's a private/const member).
- **B6-2 UMG stacks suppressed (real, architectural):** native HUD collapses `QuestHUDWidget` /
  `QuestMissionWidget` etc. at BeginPlay AND every 1.5s via global `TObjectIterator` — the two UMG
  HUD stacks can never display while `AQuestNativeHUD` is active. Decide: delete UMG stack or gate
  the sweep behind a flag; the sweep is also an O(all-widgets) hitch.
- **B6-3 `DrawFilledCircleArea` draws squares** for R≤12 (all minimap dots, player dot, compass pips).
- **B6-4 Settings screen is a placebo:** static hardcoded rows, no click handling, `ApplySettingsToEngine`
  wouldn't apply volumes/language anyway (see B6-9).
- **B6-5 (cleared):** `HasAnySaveGames()` DOES exist (inline alias, header:100) — menu Continue compiles.
- **B6-6 Gather reads `WeaponComp->BurstShots` as `AmmoInClip`** — wrong field (HUD itself uses
  CurrentClipAmmo/ReserveAmmo); saved ammo is garbage (and never restored anyway).
- **B6-7 `CompletedMissionCount = CurrentMissionIndex`** — completed==active; chain HUD/progress math
  built on this field is off by semantics.
- **B6-8 Load discards mission progress (real, verified):** `ApplySaveDataToWorld` sets
  `CurrentMissionIndex=saved` then `StartChain()` resets to −1→mission 0. Every load restarts the chain.
- **B6-9 Settings half-applied:** volumes + language persist in the slot but `ApplySettingsToEngine`
  only pushes quality + vsync.
- **B6-10 Progression/XP/unlocks never gathered** — menu-visible profile progress likely lost on load
  unless `ProgressionSubsystem` self-persists (verify Step 7).
- **B6-11 `SavedAllies` write-only:** allies saved, never restored — post-load squad is always map-fresh
  (dead allies resurrect, wounded heal, positions reset). Decide intended behavior.
- **B6-12 Post-map-load apply unverified:** `bTransitionToMap=true` path never calls
  `ApplySaveDataToWorld` directly; depends on `LoadingScreenSubsystem` hookup (verify Step 7).
- **B6-13 (cleared):** no dual timestamps — verified single `Timestamp` in `USquadAISaveGame`
  (SaveGame.h:92) plus the separate `FSquadSaveSlotInfo.Timestamp` UI mirror (correct).
- **B6-14 Gameplay HUD is 1080p-hardcoded** (no UIScale; menu HUD has one) — breaks layout at other
  resolutions; compass pips may overlap the defend banner; revive prompt visible to 2000cm.
- **B6-15 Per-frame/per-tick costs:** `ShapeAndOrder` (O(41) glyph scan) per string per frame;
  24 guidance ground traces + mortar ring traces in DrawHUD; global widget sweep every 1.5s;
  `GetMostRecentSaveSlot` deserializes every slot.
- **B6-16 Wrong voiceline:** mortar call-in plays `Ally_IncomingGrenade` on the player.
- **B6-17 Missing prompts:** medical stations / turrets / barrels have no interaction prompts despite
  the function's comment; first-aid prompt is display-only (no E pickup logic in HUD — pickup must live
  in the actor; verify).
- **B6-18 Static "N" on a rotating minimap** is misleading; border pips gated on chain-active (leader
  pip disappears with no active chain).
- **B6-19 Fragile button-ID namespaces** in menu (500s/600s/10 reused across screens) — safe today via
  per-frame rebuild, but any persistent/multi-screen registration will collide.
- **B6-20 Minimap never re-inits:** capture component is outered to the player pawn; after
  respawn/possess change, `bMinimapInitialized` stays true with a dead component → minimap freezes.
- **B6-21 `ApplyPersianFarsiPreset()` in the menu-HUD ctor** calls `LocalizationSubsystem::Get(this)`
  during construction (world/game-instance may not exist → null-safe fallback today, but CDO/construction
  order dependent).
- **B6-22 Hardcoded identity dossier** (name/unit/blood-type/plate#) in inventory tab 4 — not wired to
  the editable profile name/avatar.

## 9. Notes for the coming UI-fix prompts (first priority)

- Live edit targets: `QuestNativeHUD.cpp` (§3 draw order) + `SquadAIMainMenuHUD.cpp` (§4 screens/IDs) +
  `SquadAISaveLoadSubsystem.cpp` (§6) + `FarsiTextHelper` (§2). UMG widgets are dead weight until B6-2
  is decided.
- Any new menu button needs a same-screen-unique ID + a `ProcessClickAtMousePosition` branch; any new
  HUD element needs a `bEnable*` flag to match the existing pattern.
- Save/load fixes (B6-1/6/7/8/10/11/12) span HUD + subsystem + chain + Step-7 loading subsystem —
  best handled as one work package after Step 7 confirms the loading/progression hookups.

# Gameplay-Core Fix Log — applied to `extracted/SquadAI` (UE 5.7 module snapshot)

Date: 2026-09-08. Your local project is newer than this snapshot, so **merge by anchor**
(function name + distinctive code), not by line number. Every fix below was verified present
after application. Nothing here was compile-tested (no engine in this environment) — the
patches are small, idiomatic, and each is independently revertible.

Rule learned the hard way this session: apply **one edit per file at a time**
(parallel same-file edits silently clobber each other).

---

## 1. Your 4 reported gameplay bugs

### 1a. Shahid Rostami must never die / never go down, allies downable-but-never-die
Root causes: (1) the 0.5s pack bridge bypassed `ApplyDamage` and set `bIsDead` by hand;
(2) a stray unconditional `{ EnterDownedState(); return; }` block in `HandleDeath` swallowed
all non-ally deaths; (3) no pack-side clamp existed for allies.

- `Private/Characters/SoldierCharacter.cpp` — `SyncPackHealthToSquadAI`, damage branch:
  pack-clamp heroes (`ClampPackHealthMinimum(35)` leader / `(1.0)` ally), then route the
  delta through `HealthComp->ApplyDamage(Damage, nullptr)` instead of manual flags.
- `Private/Components/HealthComponent.cpp` — `ApplyDamage`: new leader branch
  (chip damage ×0.25, floor 35, never down/dies) covering bridge/turret/radial callers.
- `Private/Characters/SoldierCharacter.cpp` — `HandleDeath`: stray block is now
  `if (bCanBeDowned && !bIsDowned)`; enemies/player fall through to full death handling.
- `Private/Characters/SoldierCharacter.cpp` — new helpers + decls in
  `Public/Characters/SoldierCharacter.h`: `ClampPackHealthMinimum`,
  `RestorePackHealth`, `GetPackMaxHealth`, `ResetPackDeathFlags`
  (double/float/int aware, 8 health-prop names, 4 death-flag names).
- `BeginPlay` bridge timer: 0.15s for leader/allies, 0.5s for enemies (`BridgeInterval`).
- `OnAnyDamageReceived`: same-frame pack clamp for leader/ally (closes the one-shot
  window between polls).

### 1b. Healing makes followers disappear (+ "AttachToComponent … use the Teleport flag" error)
Root causes: pack played its own death (mesh hide) while SquadAI saw alive/downable;
revive never restored visibility, zeroed ragdoll velocity, restored pack max, or cleared
pack death flags; hardcoded `100.0f` pack restore.

- `CompleteRevive`: zero linear+angular physics velocity before re-attach; `SetVisibility(true)`
  + `SetHiddenInGame(false)`; pack restore via `GetPackMaxHealth(100.f)` +
  `RestorePackHealth(...)` + `ResetPackDeathFlags(false)`.

### 1c. Health bar dead on first life / phantom directional damage after revive
Root causes: first-match-wins health read (stale full-health comp masked damage); spawn
grace declared but never enforced; bridge permanently disabled itself when the pack comp
registered late.

- `Private/HUD/QuestNativeHUD.cpp` — `GetPlayerHealthPercent`: min across ALL health
  sources + `Current Health`/`currentHP`/`CurrentHP` prop names.
- `HealthComp::ApplyDamage`: `HasSpawnGracePeriod() && !IsEnemy()` → no damage
  (enemies exempt so fresh waves stay killable).
- Bridge: grace forgives pack-side too (`RestorePackHealth(LastPackHealth)`); search
  failure retries forever with throttled warning (no more `ClearTimer` / `bPackHealthSearchFailed = true`).

### 1d. Enemies circle instead of engaging
Root causes: (1) TakeCover freed its cover reservation on exit while still engaging from
it → teammates stole the point → two AI ran at the same spot, avoidance-jostled, repathed,
circled; (2) EnemyMission hunted threats/players at ANY range (cross-map bee-lines).

- `Public/Private/AI/SoldierAIController.*`: new `HeldCoverChunk/HeldCoverLocalID/bHasHeldCover`
  + `HoldCoverReservation` / `ReleaseHeldCoverReservation`.
- `Private/AI/StateTreeTasks/STTask_TakeCover.cpp`: exit transfers the reservation while
  `bHasCover` or an active real-cover move goal; new reserve releases the old hold only
  after securing the new point; all 7 abandon paths (fallback arrival ×2, no-cover/timeout
  ×2, move-failed, stuck-timeout) release the hold.
- `UnregisterFromSystems`: releases held cover on death/EndPlay.
- `Private/AI/StateTreeTasks/STTask_EnemyMission.cpp`: threat/player goals gated to
  12000cm (`HunterMaxRangeSq`); beyond that enemies advance on the mission zone.

---

## 2. Compile blockers fixed (from STEP8)

- **C8-1** `Private/Actors/SquadAIAutoSetupManager.cpp`: SCS-template block wrapped in
  `#if WITH_EDITOR` (CompileBlueprint + USCS_Node are editor-only).
- **C8-2** `SquadAI.Build.cs`: `AssetRegistry` moved to public runtime deps (factory uses
  it outside `WITH_EDITOR`).
- **C8-4** `Public/Private/Performance/SquadAIAudioSubsystem.*`: appended `Command_Hold`
  to the voiceline enum (appended, not inserted — preserves serialized values) + anti-spam
  case + selection case (temporary `LeaderOrderMoveVoicelines` bark, TODO noted).
- **C8-5**: added missing direct includes (`SquadAIInventorySubsystem.h` ×2,
  `SquadAIAudioSubsystem.h` ×1) to CombatBridge + FirstAidKitActor.

## 3. Adjacent bugs fixed along the way (Step 6/7 inventory)

- **B7-11** `DamageSoldierCharacter`: player shots now route through `ApplyDamage`
  (invincible/grace/leader/ally rules, events, AI stimuli) with the player pawn as causer.
- **B7-10 + B6-16**: removed the HUD's duplicate mortar spawn + wrong
  `Ally_IncomingGrenade` voiceline; the combat bridge is now the single
  (cooldown-gated, radio-chatter) firing path.
- **B7-2** FireSupport: cooldown is timestamp-based (`LastStrikeTimeSeconds`) — no
  external tick required; `TickCooldown` kept for API compat.
- **B7-1** FXManager: per-second FX/audio budgets reset on a 1s core ticker
  (`BudgetResetTickerHandle`) — distant FX no longer permanently culled mid-session.
- **B7-3**: `HandleDeath` calls `NotifyEnemyEliminated` for enemies (slow-mo had zero callers).

## 4. Intentionally NOT changed

- Downed bleedout never decrements (no `Tick`) — correct under your "allies never die"
  rule; the HUD bleedout bar reads as "stable, awaiting revive". Say the word if you want
  a bleedout timer that kills.
- Dev-cheat flags (god mode / infinite ammo / AI visuals, B7-5–B7-9) have no readers —
  cheats stay inert until wired. 10-minute job when you want it.
- TakeCover arrival still snap-rotates to the cover normal (cosmetic, Step 4 #10).

## 5. Still queued (next turns)

1. Merge into your local project, compile, and run `docs/VERIFICATION_CHECKLIST.md`.
2. Nothing else queued — every inventoried bug (Steps 4–8) is now fixed or verified-working.

## 6. Ordnance batch (done, script-verified, NOT compiled)

- **O1** Combat bridge: removed the extra inventory decrements — one throw = one grenade
  (double-decrement gone). Bridge owns the G/H input while attached (**O2**: component
  `Tick` skips G/H when a bridge instance is present).
- **O3a/O3b** Med-kits: heals route through `Heal()` and are consumed only if the target
  is actually hurt; pack heal reads the pack's own max (double/float/int tolerant).
- **O4** `Refill`: inventory sync is player-gated (allies no longer rewrite the UI counts).
- **O5** HUD plate: height 92→118 + live frag/smoke/kit readout from the inventory
  subsystem (Farsi literals as `\u` escapes — file must stay bytesafe).

## 7. UI/menu + save/load batch (done, script-verified, NOT compiled)

E-arbitration (Q1/Q4/Q5 + 4 actor gates): one E press = one interaction — revive wins
over props, first claimant per `GFrameCounter` wins, turret exit stays ungated
(emergency egress). `QuestNativeHUD.h` also fixes a real compile break: `FallenNotes`
`TArray`→`TObjectPtr` (every use site treated it as a single texture).
Pause→menu travel (Q2): `QuitToMainMenuFromPauseMenu` goes through
`LoadLevelWithScreen` + a 2 s ticker verify — a missing map reopens pause with a red
Farsi error instead of silently dropping the player into combat.
Bigger fonts (Q7/M3): `HUDFontScale = 1.15f` choke on both bounded-text renderers;
bounded text auto-shrinks so it can never overflow. Segmented stat bars (M1: 10
discrete blocks, smooth partial fill) + ornate 3D panel upgrade (M2: bevel, brass
corner rivets, active halo). Warm-tinted fist icon until full-color art ships (Q6).
Missing-art fallbacks (M4–M7): difficulty topo-grid, avatar/profile medallions with
initials — see `docs/TEXTURE_AUDIT.md` for the full art punchlist.
B6-12 save/load root cause (L1–L4): `AmmoInClip` was saving `BurstShots` (a burst
counter, not ammo) — now `CurrentClipAmmo` + `ReserveAmmo`; supplies/equipped-weapon
gathered; allies + supplies + loadout applied (downed allies re-enter via the public
`EnterDownedState` UFUNCTION); post-travel apply via 30 s-timeout core ticker with
`Deinitialize` cleanup.
Verified-working, no fix needed: armory unlock display, difficulty cards + Lethal,
all 4 texture getters, profile system + ISIRI FA/EN typing, segmented milestone,
map topo fallback, armory widescreen, Farsi shaping, relic textures.
Compile-risk notes: new `Containers/Ticker.h` includes in both touched headers;
`GFrameCounter` needs `HAL/PlatformTime.h` transitively (verify if PCH is lean);
Farsi/printf format changes use escapes only — keep the files bytesafe.

## 8. Dev-cheat wiring + TakeCover rotation (done, script-verified, NOT compiled)

- **B7-5** God mode is real: `UHealthComponent::bCheatGodMode` early-outs `ApplyDamage`
  (also covers `ApplyExternalDamage`, which routes through it). `ToggleGodMode` sets it
  on the player pawn's health comp (any pawn class, not just `ASoldierCharacter`) and
  heals via `Heal(Max)` so `bIsDead` clears too.
- **B7-7** Infinite ammo is real: new `ToggleInfiniteAmmo` Exec (hotkey Shift+F1; plain
  F1 unchanged). Reader in `SquadAIPlayerCombatBridge::TickComponent` tops up the TPWCS
  pack mag/reserve every frame with once-resolved cached `FIntProperty*` — necessary
  because SquadAI's own `WeaponComponent` never consumes ammo (zero `ammo` references
  in its .cpp; the pack owns the mag).
- **B7-6** AI debug visuals real: `SoldierAIController::Tick` draws red threat lines,
  green cover spheres, cyan move-goal spheres while `bDrawAIDebugVisuals` is on (F6).
- **B7-8** `ToggleDebugLogs` drives the real `ShouldLog*` gates via new static
  `ASquadAIAutoSetupManager::SetVerboseDebugLogsEnabled` (was a placebo static).
- **B7-9** `CompleteCurrentObjective` calls `Cur->CompleteMission()` (timers, spawners,
  chain advance) instead of field-hacks that never advanced the quest.
- **Step 4 #10** TakeCover arrival: new `Rotating` phase eases pawn yaw onto the cover
  normal (`RInterpTo` 8/s, 2° tolerance, 1 s cap) — no more snap-rotate, and yaw-only
  so the old pitch/roll slam can't tilt the soldier.
- **Corruption found + fixed**: `Private/Actors/SquadAIAutoSetupManager.cpp` ended with
  stray `}` + `alse);` lines (workspace-introduced, absent from the pristine zip — a
  hard compile break). Removed; full-tree audit vs the pristine zip now shows all 33
  touched files brace-balanced with zero brace-in-string confounds.
- Full in-engine checklist: `docs/VERIFICATION_CHECKLIST.md` (all batches; UI half
  still in `docs/TEXTURE_AUDIT.md` §4).

## 9. Save/load integrity batch (done, script-verified, NOT compiled)

- **B6-8 (critical):** loads no longer restart the mission chain. `ApplySaveDataToWorld`
  restores the saved position surgically: neutralize pending auto-start (`bIsActive`),
  `RemoveAll(Chain)` + new `AMissionZone::SilentResetForLoadRestore()` on every mission
  (delegates/spawners/timers/tick cleaned, zero side effects), direct-write pre-active
  missions to Completed (no broadcast → no auto-advance, no XP re-award — the naive
  `CompleteMission()` loop would have duplicated 800 XP per skipped mission), then
  `StartMissionAtIndex(SavedActive)` through the normal bind+activate path. Fully
  finished chains park as completed; out-of-range indexes fall back to `StartChain()`.
- **B6-7:** gather copies the chain's real `CompletedMissionCount` (was `CurrentMissionIndex`).
- **B6-1:** pause menu saves via new `GetAutoSaveSlotName()` getter into
  `SquadAISave_AutoSave` (the old `AutoSave_SquadAI` literal matched nothing Continue scans).
- **B6-9:** `ApplySettingsToEngine` now pushes volumes (new audio-subsystem mix:
  master/music/SFX/voice applied at music, crossfade, horde stem, spatial SFX, voiceline
  2D/3D, wind ambience, stinger, heartbeat, tinnitus sites), language (new
  `LanguageCode` settings field — B6-9 claimed it persisted but no field existed), and
  clamped FOV. Residual with no in-module consumer: sensitivity/invert/subtitles/motion-blur.
- **B6-10 (cleared, no fix):** `SquadAIProgressionSubsystem` self-persists to the
  `SquadAI_PlayerProgression` slot (save :900 / load :906-908); equipped weapon was
  already gathered by L2b.

## 10. Step 5 missions batch S5-1–S5-10 (done, script-verified, NOT compiled)

- **S5-1:** `OnPlayerDied` revives the player, then calls `FailMission()` (new
  `bFailMissionOnPlayerDeath=true` opt-out restores legacy silent retry). The chain
  failure branch (`OnMissionFailed` → retry / `bRestartChainOnFailure` → full restart /
  `OnChainFailed` for game-over UI) is reachable from C++ for the first time.
- **S5-2:** deleted the dead `DefendTimerHandle` (member + 5 clear sites; defend
  countdown lives in Tick via `DefendTimeRemaining`). Verified the sibling handles
  (`DefendWave/RestartAttempt/PlayerDeathPoll`) are all armed — left alone.
- **S5-3:** `ResolveMode` honors the designer `Mode` (Auto→Reach); `Tick` implements
  Defend (spawner-cleared OR survive `DefendDurationSeconds`, new 90 s UPROPERTY;
  `MaxSecondsOutsideZone` fails, `OutsideTimer` wired) and Clear (zone empty +
  started-nonempty or 5 s age grace; `InitialHostileCount` wired). OnStart resolves a
  same-tagged `AWaveSpawner` for Defend and snapshots hostiles. Ally-arrival fallback
  is Reach-only now.
- **S5-4:** new `AQuestDirector::OnMissionFailed` (log + record + advance); ticker
  advances past Failed missions instead of stalling forever.
- **S5-5:** director records every completed/failed mission (`MissionTitle`, `Order`,
  `MissionState`, `ElapsedTime`) — history + `ToBytes()` save payload now fill.
- **S5-6:** drive-level unification — `MissionZone.LinkedTemplateSpawners` driven in
  activate/deactivate/reset/retry-attempt/Clear-completion + the no-spawner instant-
  complete gate. New `AWaveSpawner::IsSpawningActive()` getter; `StartWaves` calls
  `StopWaves()` first so mission retry is idempotent (no double-batch timers).
- **S5-7:** both spawners top up the pool on activation (`GetAvailableCount`-gated, so
  retries reuse `Release()`d pawns instead of stockpiling): X/Y/Z stack to
  `MaxAliveEnemies`, template stack to min(total, 20). Both stacks already
  Acquire+Release — only the Prewarm calls were missing (no GameMode prewarm possible:
  the only GameMode in-module is the menu one).
- **S5-8:** `SpawnedEffects` is now `TArray<USceneComponent>` (it held actors but
  `SpawnEffect` spawns Niagara/Cascade *components*); both empty `if` blocks fill it;
  deactivate deactivates + destroys components. Loop-timer emitters tracked too.
- **S5-9:** `RefreshSightForWeather` (0.5 s poll, 0.02 hysteresis, cached director)
  rescales `SightConfig` radii from the tuning baseline by the storm multiplier and
  re-applies the sense. Manual 12000 cm gates (ping investigate, hunter fallback)
  intentionally untouched (radio/ping isn't weather-blocked).
- **S5-10:** dust fallback returns nullptr with a warning (callers null-check) instead
  of spawning a bare actor per zone; zone hostile queries also count team-Hostile
  non-SquadAI pawns (pack enemies visible to Clear checks; alive-approximated as
  not-destroyed + not-hidden, noted in code).

## 11. Step 4 AI batch S4-1–S4-11 (done, script-verified, NOT compiled)

- **S4-1 (deleted):** removed `Public/Private/AI/PerceptionMemory.*` — a parallel memory
  system with zero instantiations and zero UFUNCTIONs (Blue-Prints couldn't reach it
  either). The controller's working array stays canonical. **Merge note: delete these
  two files locally too.** Restore path: the pristine `lidar_rostami_a.zip`.
- **S4-2 (deleted):** removed `Public/Private/CoverSystem/TerrainCoverHelper.*` — a
  redundant parallel scorer (partial-cover/lean/escape all duplicate working
  `ClassifyHeight`/`ComputeLeanSides`/`ScoreAgainstThreat` paths; trench rescue would
  need threat-context threading = blind surgery on the system every TakeCover uses).
  Same merge note + restore path as S4-1. Trenches keep working via TakeCover's
  natural-cover line-trace fallback.
- **S4-3:** `RunDirectCombatFallback` honors `bAllowDirectCombatFallbackFire` +
  `DirectCombatFallbackFireRange` (stops presentation + returns when gated). Tuning
  defaults (true / 8000 cm) preserve current behavior — the switch is now a real opt-out.
- **S4-4:** baked array → `GeneratedCoverCount` int (getter/Bake/Clear API unchanged).
  `BakeCoverPoints` already feeds the AI via `ForceScanArea`; the FVector array was a
  redundant copy serving only the count.
- **S4-5:** deleted unused `GEnemyPatrolTimer`/`GEnemyPatrolGoal` statics.
- **S4-8:** `MaxChunkScansPerFrame` 2→1 (full-chunk 1440-trace scans serialize instead
  of double-spiking; coverage unchanged) + throttled over-budget Verbose tracking in
  `KickChunkScan` (the budget break stays out by design — it starved samples).
- **S4-9:** `MakeSampleKey` is now a 21/21/21-bit pack (was decimal, collided on
  negative chunk coords); header comment fixed (it didn't even match the old def).
- **S4-11 (half-cleared):** perception configures immediately at BeginPlay
  (`bPerceptionInitialized` guard; the 1 s timer stays as fallback) — the 1 s deaf/
  blind window is gone. The 2 s StateTree timer is NOT a dormancy bug (`StartLogic`
  runs immediately in `OnPossess`; the timer only fires if still dormant) — left as is,
  as is the harmless adapter-creation for non-combat pawns.

## 12. HUD pass (H2b-complete, H3/B6-14, H4/B7-21; B7-19 verified HUD-side)

- **H2b 6/6 (save/load):** `SquadAISaveLoadSubsystem.cpp` — `GetMostRecentSaveSlot`
  result cached (`bMostRecentCacheValid`/`CachedMostRecentSlot`, members already
  in header); invalidated on save/auto-save/delete. Drive-by: the save-success
  `UE_LOG` had a stray `)` (`...%s)")),` → `...%s)"),`), which would not compile —
  fixed line-targeted (the bytes defeated exact-match twice; `cat -A` clean).
- **H3 / B6-14 (HUD resolution scaling, 403 reps):** new `GameUIScale` member
  (`QuestNativeHUD.h`), computed in `DrawHUD` as `Clamp(ClipY/1080, 0.70, 1.35)`
  — the menu HUD's `UIScale` formula verbatim. Every gameplay-HUD draw fn takes
  `const float S = GameUIScale` (or `UIS` where `S` is taken: guidance rescue
  loop, inventory stats loop) and all px literals scale: weapon plate, squad
  panel, objective card, compass, damage, hitmarker, minimap (+call-site
  R/Margin), border, defend banner, prompts ×6 sections, pings, guidance
  ribbon/chevrons/rescue beacons, reticle spreads/pips, mortar ring thickness/
  badge/card, alert banner, radio, 3 vignettes, deployment veil, pause menu +
  toast, inventory shell + all 6 tabs. Deliberately unscaled: world-space cm
  (trace endpoints, blast/dispersion radii, prompt distance gates, `/100.f`
  m-conversions, anim rates/phases), fullscreen rects, helper internals
  (chisel/silhouette/circle/draw-text take computed px). Verified: braces
  378/378, SDEF 20 + UISDEF 2, zero unscaled font scales in the file.
- **H4 / B7-21 (menu Relic Collection, 15 reps / 5 files):** new `RelicCollection`
  menu state + grid button ID 12 (`ButtonRelicCollection`, all 3 presets; Quit
  stays 11) + `DrawRelicCollectionScreen` (achievements-template layout: inspect
  card + list + Back-99; `UIScale`-scaled; per-note art from the director's
  `FallenNotesImageList` with placeholder fallback; empty-state line) +
  `BackgroundRelicsTexture` (autoresolves `UI_FallenNotes_Background`) +
  `ActiveRelicInspectIdx` + subsystem getter `GetFallenNoteByIndex` (decl+impl).
  Includes added: inventory subsystem, setup actor, EngineUtils. All 5 files
  brace-balanced; ref counts exact (RelicCollection 1/2/8, getter 1/1/2).
  Compile risks: new screen fn uses only in-class/verified APIs;
  `TObjectPtr::Get()` explicit; enum append is additive (recompile UMG refs).
- **B7-19 (verified HUD-side, no change):** E-key arbitration already exists —
  `DrawBattlefieldInteractionPrompts` computes `bReviveAvailableCache` and world
  interaction consumes via `WasWorldEConsumedThisFrame()` (1-frame-stale by
  design, per the header comment). Checklist carries an actor-side grep.

## §13 — UI TEXTURE PACK (32 SHIPPED IN ZIP V3, REST QUEUED)
- Author PIL generator run via /tmp copy with OUTPUT_DIR redirected (repo script pristine): 27 procedurals (5 frames, 4 buttons, 3 loading-bar, hexagon, 2 fist, 7 relics, 5 traits) at exact manifest sizes.
- AI photorealistic art, 8 shipped: Menu/Loading/Medals/Progression/Armory backgrounds (1920x1080) + PocketQuran/PocketRadio/CombatWallet items (1024x1024). Post: center-crop to aspect + LANCZOS + mild unsharp; AI versions overwrite PIL relics for the 3 items.
- QC rejects queued for redo: CombatWallet (US ID card content, wrong nation), FallenNotes bg (Latin gibberish, needs Persian-style script).
- Queued on image-quota reset: FirstAidPouch, Canteen, DogTag, 4 avatars, 4 difficulty cards, 3 theater maps, 5 weapon previews, §2 x6 (PlayerProgression, Leadership, Marksmanship, Endurance, Engineering, Watermark), 5 gun silhouettes (white-on-black + keyed).
- Placement SquadAI/Content/Textures/*.png auto-imports to /Game/Textures/* per ini; in-editor audit: SquadAI.AuditMissingUIAssets.

## §14 — ERA-AUTHENTICITY REDO (IRAN-IRAG 1980-88, IRANIAN SIDE)
- User verdict: first AI set had European/WWI/US vibes. REMOVED: menu v1, trench v1 (WWI French), medals v1 (US), progression-desk v1, armory v1, wallet v1 (US contents). KEPT: Quran, radio (authentic).
- Redone with strict direction (steel helmets, keffiyehs, plain headbands, G3s, canvas webbing, palms, turquoise dome, red tulip, girih star, Persian script, red crescent, zero readable Latin): menu, trench, medals, wallet (closed, no contents), fallen-notes (Persian script), watermark veil, pouch, canteen, dogtag, Rostami avatar.
- Code-load map: 57 unique /Game/Textures paths incl. 2 manifest-missing: UI_Progression_Tactics + Menu_Background_NightOperations (both queued).
- Image quota: 10 generations per cycle (confirmed). 29 remain: 3 avatars, 5 weapons, 3 maps, 4 difficulty, playerprog, 5 axes, armory, progression, nightops, 5 silhouettes.

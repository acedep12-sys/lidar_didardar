# In-Engine Verification Checklist — all batches

Nothing in this workspace was compile-tested (no engine here). After merging into your
local project: compile first, then work this list top to bottom. Checkboxes marked
`[LOG]` are confirmed in the Output Log; the rest are observed in-game.

UI/menu/save half of the list already lives in `docs/TEXTURE_AUDIT.md` §4 — run it
after §3 below.

## 0. Compile & merge sanity

- [ ] Module compiles clean under UE 5.7 (fix any `GFrameCounter` include error with
      `HAL/PlatformTime.h` if your PCH is lean).
- [ ] PIE starts with zero red errors in the first 10 s (warnings OK).
- [ ] `[LOG]` `[SQUADAI_ASSET_AUDIT] AUDIT SUMMARY` prints once at startup with the
      expected Found/Missing counts for your `Content/Textures`.

## 1. Gameplay core (your 4 reported bugs)

**1a. Shahid Rostami never dies/downs; allies downable but never die**
- [ ] Cheat or CME: deal 500 damage to Shahid Rostami → HP floors at 35, stays standing, keeps fighting.
- [ ] Deal 500 damage to an ally → ally goes downed (not dead), bleedout bar reads "stable".
- [ ] Deal 500 damage to an enemy → full death handling (ragdoll/despawn, kill credit).
- [ ] One-shot the leader with a barrel at point blank → survives (same-frame pack clamp).

**1b. Revive no longer loses followers / teleport errors**
- [ ] Down an ally → hold E to revive → ally stands, visible, weapon restored, no
      `AttachToComponent … Teleport flag` error in log.
- [ ] Revived ally takes damage again correctly (pack max restored, no instant re-down).

**1c. Health bar alive on first life; no phantom damage after revive**
- [ ] Fresh spawn → take a hit → HUD health bar drops immediately (no stuck-full bar).
- [ ] Right after spawn/revive → enemy hits during grace window deal no damage (no
      phantom directional indicator); fresh enemy waves are still killable (no grace for them).

**1d. Enemies engage instead of circling**
- [ ] Start a firefight with 3+ enemies → they take cover / advance / fire; nobody
      circles a single point or bee-lines across the map.
- [ ] Two allies ordered to the same area → they occupy different cover points (no
      reservation stealing / avoidance jostle loop).

**Adjacent (B7/B6)**
- [ ] Player shots damage/kill enemies with proper flinch, hit feedback, kill events.
- [ ] Mortar call-in: single strike path, cooldown enforced, radio chatter plays.
- [ ] Distant combat FX never permanently stop spawning mid-session (FX budgets reset).
- [ ] Killing the last enemy in a slow-mo-eligible fight triggers slow-mo + `NotifyEnemyEliminated`.

## 2. Ordnance (O1–O5)

- [ ] Throw a frag (G): inventory drops by exactly 1; HUD supply readout matches.
- [ ] Throw smoke (H): same, single decrement.
- [ ] Use a med-kit at full HP: not consumed, nothing happens. Use while hurt: consumed, HP restored, HUD bar updates.
- [ ] Refill at crate/station as player: frag/smoke refill; ally refills don't rewrite player counts.
- [ ] HUD weapon plate shows the supply line (frag × N / smoke × N / kits × N), plate taller than before.

## 3. Cheats + TakeCover (this batch, B7-5–B7-9)

- [ ] `F1`: god mode ON → walk into enemy fire + a barrel blast → HP never moves, no
      flinch/death; `F1` again → damage works normally.
- [ ] `Shift+F1`: infinite ammo ON → mag/reserve stay full while firing (HUD counters
      look normal); toggle OFF → ammo depletes again. (Console: `ToggleInfiniteAmmo`.)
- [ ] `F6`: AI gizmos appear — red threat lines, green cover spheres, cyan move-goal
      spheres; `F6` again → all gone.
- [ ] Console `ToggleDebugLogs` → verbose AI/combat/quest logs start flowing (real
      `ShouldLog*` gates); toggle again → back to standard.
- [ ] `F7` on an active objective → objective completes for real: timers clear,
      spawners deactivate, chain advances (not just the progress bar filling).
- [ ] Watch AI arrive at cover: smooth yaw turn onto the cover normal (~0.5 s), no
      snap; no tilt (pitch stays level).

## 4. Missions (S5 batch)

- [ ] Die during an active chain mission → mission FAILS (log + `OnChainFailed`), then
      the mission restarts fresh; with `bRestartChainOnFailure`, the whole chain restarts.
- [ ] Defend objective: survive the duration (or clear the linked spawner's waves) → success;
      leave the zone past the limit → failure.
- [ ] Clear objective with pack enemies in the zone → counts them; zone must hit zero.
- [ ] Fail a director mission → ticker advances to the next mission (no stall); quest log
      shows the entry with correct title/order/state/duration.
- [ ] Clear mission driven only by template spawners → waves run, clear completes on wipe.
- [ ] Big wave start → no hitch spike (pool prewarmed; check `GetAvailableCount` in debugger).
- [ ] Sandstorm Haboob → AI visibly acquires targets later/closer; Clear weather restores.
- [ ] Mission end → decorator emitters vanish (no orphaned loops); dust zones with no
      HeterogeneousVolume log a warning and spawn nothing.

## 5. AI / cover (S4 batch)

- [ ] PIE spawn → AI perceives and acts immediately (no 1 s idle); StateTree starts at possess.
- [ ] Set `bAllowDirectFallbackFire=false` in tuning → fallback never fires (switch works).
- [ ] First contact in a new area → cover still found (full-chunk scans); `[LOG]` Verbose
      `trace budget exceeded` appears throttled, not spammed.
- [ ] Bake Cover Points on a generator volume → count logs correctly; AI uses the area's cover.
- [ ] Play in negative-coordinate map regions → cover queries behave (no cross-chunk corruption).

## 6. UI / menu / save-load

Run `docs/TEXTURE_AUDIT.md` §4 (10 items: medallions, topo columns, fist tint,
segmented bars, 3D panels, font scale, E-arbitration, menu-travel error, save/load
round-trip). Plus:
- [ ] `[LOG]` Save → travel → `[SquadAISaveLoad] Post-travel apply complete on '…'` appears
      (or the TIMEOUT error if the map name is wrong — never silence).
- [ ] Save mid-chain (mission 2 of 4) → load → mission 2 is Active, mission 1 shows
      Completed, no XP popups for skipped missions, mission-1 spawners stay quiet.
- [ ] Save after finishing the whole chain → load → chain parked completed, nothing re-activates.
- [ ] Pause → Save → Continue from main menu → the pause save is listed and loads.
- [ ] Settings: volumes/language/FOV/quality/vsync all survive a restart and audibly/
      visibly apply (music/SFX/voice scale; FOV changes the camera).
- [ ] Any resolution/aspect (720p, 1080p, 1440p, 21:9) → HUD plates/cards/prompts/
      veil/pause/inventory scale smoothly (no clipping at 0.70, no overlap at 1.35).
- [ ] Down an ally → red rescue prompt + bleed bar + guidance beacon; hold E → green
      revive fill completes the revive (E-arbitration: no double-consume with crates).
- [ ] Mortar warning → ground ring + countdown badge; mortar aim → blast/dispersion
      circles + arrow + fire-order card, all tracking the aim point.
- [ ] Main menu → Relic Collection (button 12) → collected-notes list + inspect card;
      empty profile shows the "not yet" line; Back returns to Main.
- [ ] `WasInputKeyJustPressed(EKeys::E)` grep: no gameplay actor polls E directly
      (HUD arbitration owns it; inventory Q/E weapon-switch is exempt).

## 5. Log greps (copy-paste into Output Log filter)

- `Post-travel apply` — save/load batch alive.
- `Travel to menu` — menu-travel verify alive (only on failure).
- `SQUADAI_ASSET_AUDIT` — texture audit alive.
- `TakeCover` (Verbose) — enable verbose logs first (§3 F-key for `ToggleDebugLogs`
  is console-only; hotkeys F1–F10 cover the rest).

## §7 — TEXTURE PACK (ZIP V3)
- [x] 27 PIL procedurals generated at manifest sizes (§1 frames/buttons/bars, §4 frame+bar, §6 traits, §7 unarmed, §8 placeholders)
- [x] 8 AI photorealistic finals (5 key-art bgs + quran/radio/wallet)
- [ ] REDO wallet (closed, no readable contents) + fallen-notes bg (Persian-style script)
- [ ] REMAINING 27 AI images on quota reset (items x3, avatars x4, difficulty x4, maps x3, weapons x5, §2 x6, silhouettes x5)
- [ ] Final in-editor audit via SquadAI.AuditMissingUIAssets after import

# Step 8 — Compile-Risk Verification + Next-Systems Plan

Covers: `SquadAI.Build.cs`, `SquadAI.cpp`, `SquadAI.h` (the 3 module-root files) +
whole-codebase static verification (230 files: 111 `.cpp` / 119 `.h`) + the
consolidated fix queue + the deferred new-systems plan.

> Method note: there is no UE 5.7 toolchain in this workspace, so "compile" here
> means the deepest static verification possible without `UnrealBuildTool`:
> patched `validate_codebase.py` (brace/paren balance), targeted AST-lite scans
> (duplicate `case`, missing includes, case mismatches, UHT structure,
> `WITH_EDITOR` guard pairing, `TObjectPtr`-without-`UPROPERTY`, module-dep
> coverage). Anything needing real engine headers is listed in §3 as a
> first-local-compile watchlist instead of a verdict.

---

## 1. Module root: Build.cs / SquadAI.cpp / SquadAI.h

### SquadAI.Build.cs — dependencies (all correct, nothing missing)

| Scope | Modules |
|---|---|
| Public runtime | Core, CoreUObject, Engine, InputCore |
| Private runtime | AIModule, NavigationSystem, GameplayTasks, StateTreeModule, GameplayStateTreeModule, Niagara, AssetRegistry, GameplayTags, GameplayAbilities, SmartObjectsModule, SignificanceManager, EnhancedInput, UMG, Slate, SlateCore |
| Editor-only (`Target.bBuildEditor`) | UnrealEd, AssetTools, ToolMenus |
| PCH | `PCHUsageMode.UseExplicitOrSharedPCHs` |

Cross-check vs. the actual `#include` roots used across the codebase: **every
engine include root resolves to a declared module** — `Blueprint/UserWidget.h`→UMG,
`Rendering/DrawElements.h` + `Fonts/*` + `Brushes/*`→Slate/SlateCore,
`BehaviorTree/BlackboardComponent.h` + `Perception/*` + `EnvironmentQuery/*`→AIModule,
`Navigation*`→NavigationSystem, `StateTree*`→StateTreeModule,
`Components/StateTreeAIComponent.h`→GameplayStateTreeModule, `Niagara*`→Niagara,
`AssetRegistry/*`→AssetRegistry, `GameplayTag*`→GameplayTags,
`AbilitySystemBlueprintLibrary.h`→GameplayAbilities, `InputCoreTypes.h`→InputCore,
`Kismet2/*` + `AssetToolsModule.h`→editor block (all 4 occurrences verified inside
`#if WITH_EDITOR`). No absolute-path or backslash includes anywhere. The `.inc`
include (`SoldierCharacter_PresentationHelpers.inc`) exists on disk.

Style rule #40 (new): **every engine `#include` root must map to a `Build.cs`
module; editor-only headers (`Kismet2`, `AssetTools`, `UnrealEd`) live inside
`#if WITH_EDITOR` in the `.cpp`, never in a header.**

Unused-but-harmless deps: `SmartObjectsModule`, `SignificanceManager`,
`GameplayAbilities` have ~zero includes from module code — keep (future systems,
see §5); they only cost link time.

### SquadAI.cpp — module startup

`IMPLEMENT_PRIMARY_GAME_MODULE(FSquadAI, SquadAI)` + `StartupModule()` installs a
**global 2-team attitude solver** via `FGenericTeamId::SetAttitudeSolver`:
same `uint8` team → Friendly (`NoTeam`(255) vs `NoTeam` → Neutral), else Hostile.
**Caveat for the plan:** this *overwrites* any project-level attitude solver —
if the game later needs >2 teams or asymmetric attitudes, this solver must be
replaced, not extended.

### SquadAI.h — minimal, correct (`FSquadAI : IModuleInterface`, Startup/Shutdown only).

---

## 2. Verification results — PASS (9 green checks)

| # | Check | Result |
|---|---|---|
| V-1 | Brace/paren balance, 230 files (patched validator) | ✅ 0 issues |
| V-2 | All files UTF-8, no BOM weirdness | ✅ |
| V-3 | `#pragma once` first line of every header | ✅ 119/119 |
| V-4 | No dangling refs to deleted files (`PerceptionMemory`, `TerrainCoverHelper`) | ✅ 0 refs |
| V-5 | Duplicate `case` labels (fixed scanner: full enum labels, per-switch reset) | ✅ exactly 1 — the known OBS-1, nothing else |
| V-6 | Every project-local `#include "..."` resolves on case-sensitive disk | ✅ 0 broken, 0 case mismatches |
| V-7 | UHT structure: every `UCLASS/USTRUCT/UENUM/UINTERFACE` header ends with its own `.generated.h`; `GENERATED_BODY` ↔ `GENERATED_UCLASS_BODY` consistent | ✅ 0 missing, 0 mismatches |
| V-8 | Engine include roots ⊆ Build.cs modules (see §1 table) | ✅ |
| V-9 | `WITH_EDITOR` pairing (11 `.cpp` + 5 headers use it): guarded declarations match guarded definitions; editor-only API calls guarded (`SetActorLabel`, `CompileBlueprint`, PostEdit bodies…) | ✅ everywhere **except** `SquadAIAutoSetupManager.cpp` (§4, C-2/C-3) |

---

## 3. First-local-compile watchlist (LOW — needs engine headers to confirm)

Believed-correct API uses that only a real UBT compile can prove. If any fail,
the fix is local (rename/re-signature), never architectural:

1. `USCS_Node::SetParent` (factory SCS parenting) — believed to exist in 5.7.
2. `UDecalComponent::SetLifeSpan` (FX manager pooled decals).
3. `FProperty::ExportTextItem_Direct(Value, Pinned, Pinned, nullptr, 0)` 5-arg form.
4. `APlayerController::WasInputKeyJustPressed / IsInputKeyDown` (command + ping).
5. `bEnableUpdateRateOptimizations` (SoldierCharacter) — deprecated in 5.x, expect a warning, not an error.
6. `SoldierCharacter.h:435` inline `EquippedWeaponMesh->IsVisible()` dereferences a forward-declared `UMeshComponent` — compiles via transitive `Character.h`→`SkeletalMeshComponent`→`MeshComponent` includes and/or the shared PCH; recommend adding a direct `#include "Components/MeshComponent.h"` for IWYU hygiene.
7. Trivia: `SquadAIAutoSetupManager.cpp` includes `Components/SquadAITPWCSVisualsComponent.h` twice (top-level + `WITH_EDITOR` block) — harmless via `#pragma once`, delete one line during fixes.

---

## 4. New compile defects found in Step 8 (all must-fix, editor vs packaged noted)

### C-1 — HIGH — 12× bare `TObjectPtr` cache members (UHT-rule violation + GC hole)
**File:** `Public/Components/SquadAIWeaponVisualPreset.h:118-129`
(`LoadedMuzzleFlash`, `LoadedTracerTrail`, `LoadedFireMontage`,
`LoadedShotSound`, `LoadedDryFireSound`, `LoadedReloadSound`,
`LoadedImpactSound`, `LoadedReloadMontage`, `LoadedWeaponMesh`,
`LoadedMuzzleSocketName`… — the whole `Loaded*` block has **no `UPROPERTY()`**.)
Two independent failures: (a) project rule #9 / UHT convention —
`TObjectPtr` members are only legal as `UPROPERTY`s, UHT is expected to reject
the header; (b) GC-invisible — the soft-loaded muzzle/trail/montage/sound/mesh
assets are collectible, so `PlayShotVisuals` silently goes dead after a GC pass
until the next load call. **Fix (certain): add `UPROPERTY(Transient)` above each
of the 12 members.** No other bare-`TObjectPtr` members exist anywhere else in
the module (scan-verified).

### C-2 — HIGH — packaged-build-only compile error: editor-guarded include, unguarded use
**File:** `Private/Actors/SquadAIAutoSetupManager.cpp` — `BeginPlay()` (line ~104)
calls `USquadAIFXManagerSubsystem::Get(this)` and assigns `TObjectPtr<UNiagaraSystem>`
defaults, but both `#include "Performance/SquadAIFXManagerSubsystem.h"` and
`#include "NiagaraSystem.h"` sit **inside the `#if WITH_EDITOR` block** (lines 29-37).
Editor builds compile; **packaged-game builds fail** (`USquadAIFXManagerSubsystem`
undeclared). **Fix (certain): move those two includes to top level** — both are
runtime-safe (FX manager is a runtime world subsystem, Niagara is a runtime module).

### C-3 — HIGH — packaged-build-only compile error: unguarded `PostEditChangeProperty` definition
**File:** `Private/Actors/SquadAIAutoSetupManager.cpp:141` — the definition is
unguarded while the header declaration is `#if WITH_EDITOR`-guarded
(`Public/Actors/SquadAIAutoSetupManager.h:23-25`), and worse, the `#else` branch
(line 219) calls `Super::PostEditChangeProperty(...)`, which **does not exist**
in non-editor builds (editor-only on `UObject`). **Fix (certain): wrap the whole
definition in `#if WITH_EDITOR … #endif` and delete the `#else` branch.**
(All other `PostEditChangeProperty` definitions — SplinePath, DustScatterer,
AudioManager — are correctly guarded; verified.)

---

## 5. Consolidated fix queue (all steps — for the later fix prompts)

Fix in this order (compile-blockers → packaged-blockers → gameplay-correctness → polish):

| Order | ID | Severity | Location | One-line fix |
|---|---|---|---|---|
| 1 | OBS-1 (§Step7) | 🔴 editor+packaged compile error | `SquadAIAudioSubsystem.cpp:555` | delete duplicate `case Command_Hold` (dup of :549) |
| 2 | C-3 (§4) | 🔴 packaged compile error | `SquadAIAutoSetupManager.cpp:141-221` | guard whole `PostEditChangeProperty` def with `#if WITH_EDITOR`, drop `#else` |
| 3 | C-2 (§4) | 🔴 packaged compile error | `SquadAIAutoSetupManager.cpp:29-37` + `BeginPlay` | move FXManager + Niagara includes to top level |
| 4 | C-1 (§4) | 🟠 UHT/GC | `SquadAIWeaponVisualPreset.h:118-129` | `UPROPERTY(Transient)` × 12 |
| 5 | OBS-3 (§Step7) | 🟠 gameplay | `SoldierAIController` stim → `UAISense_Hearing` | route aggro through `UAIPerceptionSystem::OnPerceptionUpdated` delegates |
| 6 | OBS-7 (§Step7) | 🟠 gameplay | `SMC_PickupOnUse` | check free inventory slot BEFORE destroying ground pickup |
| 7 | OBS-12 (§Step7) | 🟠 gameplay | `ACombatEncounterVolume` | reuse zone cache instead of re-querying per spawn |
| 8 | OBS-2/4/5/6/8/9/10/11 + §3 items | 🟡 polish | various | per-STEP-doc notes (watchlist #6 include, trivia #7, etc.) |

---

## 6. Next-systems plan (DEFERRED — user: no new systems until fixes are prompted)

Proposals only, ordered by dependency. Each future system prompt should cite its row.

| Prio | Proposed system | Why (gap found during read-through) | Depends on / touches |
|---|---|---|---|
| P-1 | Packaged-build CI check (cook + package smoke test) | C-2/C-3 prove editor-green ≠ shippable; cheapest insurance | fix queue order 1-4 first |
| P-2 | Multi-team attitude solver | `SquadAI.cpp` global 2-team solver blocks >2 factions / asymmetric attitudes | — (replaces startup code) |
| P-3 | Replication pass (MP-ready) | zero `GetLifetimeReplicatedProps` / RPCs anywhere — fully single-player | P-2 if teams replicate; combat + quest + inventory |
| P-4 | SmartObject cover/interaction layer | `SmartObjectsModule` dep already declared, zero usage; BT/EQS cover could migrate | cover system (§Step5), EQS tests |
| P-5 | Significance-driven AI LOD | `SignificanceManager` dep declared, ~zero usage; perf subsystem hand-rolls distance tiers | perf subsystem, `AISignificanceManager` |
| P-6 | GameplayAbility migration (grenades, fire-support, stims) | `GameplayAbilities` dep declared, one include; cooldowns/effects hand-rolled per component | tactical + grenade + ping subsystems |
| P-7 | Vehicle system (technical/transport + mounted weapons) | mounted MG is static-only; no vehicle pathing/combat integration | AI controllers, weapon component, cover |
| P-8 | Melee + stealth/detection-meter UI | no melee; detection exists in logic but has no HUD meter (ping indicators are objective-only) | player bridge, HUD widgets |
| P-9 | Day/night + weather cycle director | sandstorm director is one-shot; no time-of-day lighting control | environment actors, tuning |
| P-10 | Weapon attachment/customization | preset-driven visuals only; no attach/detach, no accuracy/Ergo stats per part | weapon preset (C-1!), weapon component |

**Explicitly out of scope until the user asks:** any of P-1…P-10, any balance
rebalancing, any asset/texture work (texture uses live in `docs/IMAGES.md`).

---

## 7. Code-style rules added in Step 8

- **Rule #40:** engine `#include` root ⊆ `Build.cs` module deps; editor-only headers inside `#if WITH_EDITOR` in `.cpp` only.
- **Rule #41:** every `WITH_EDITOR`-guarded declaration must have a same-guarded definition (and vice versa) — pair them or packaged builds break.
- **Rule #42:** `TObjectPtr` member ⇒ `UPROPERTY()` above it, no exceptions (`Transient` for runtime caches).
- **Rule #43:** global engine state set in `StartupModule` (attitude solver, console vars) must be documented in the module `.cpp` header comment with its replacement path.

# Step 6 — UI, HUD, Save/Load, Localization

Scope: **11,329 lines** — `HUD/` (12 files) + `SaveSystem/` (4) + `Localization/` (2) +
`LoadingScreenSubsystem` pair. All files read in full.

| File | Lines | What it is |
|---|---|---|
| `Public/HUD/QuestNativeHUD.h` | 372 | Gameplay AHUD: full Canvas HUD API |
| `Private/HUD/QuestNativeHUD.cpp` | 3323 | Gameplay AHUD impl — biggest file in module |
| `Public/HUD/SquadAIMainMenuHUD.h` | 495 | Main-menu AHUD: 11 screens, procedural Canvas menu |
| `Private/HUD/SquadAIMainMenuHUD.cpp` | 3075 | Main-menu impl |
| `Public/HUD/FarsiTextHelper.h` | ~65 | Persian shaping/Digits/BiDi API (+ `FFarsiTextHelper` typedef alias) |
| `Private/HUD/FarsiTextHelper.cpp` | 390 | 41-glyph presentation-form shaper, BiDi reorder |
| `Public/HUD/QuestHUDWidget.h` + cpp | ~90 + ~120 | UMG master container (legacy/suppressed) |
| `Public/HUD/QuestChainHUDWidget.h` + cpp | small | UMG chain tracker (legacy) |
| `Public/HUD/QuestMissionWidget.h` + cpp | small | UMG mission card, 0.5 s poll (legacy) |
| `Public/HUD/QuestCompletionWidget.h` + cpp | small | UMG completion toast (legacy) |
| `Public/HUD/QuestCompassWidget.h` + cpp | small | UMG compass, markers stubbed (legacy) |
| `Public/HUD/MissionBriefingWidget.h` + cpp | small | UMG briefing card (legacy) |
| `Public/HUD/QuestMinimapWidget.h` + cpp | small | UMG NativePaint quads minimap (legacy) |
| `Public/HUD/SquadAILoadingScreenWidget.h` + cpp | small | UMG loading widget |
| `Public/HUD/SquadAIMainMenuWidget.h` + cpp | small | UMG menu widget (kills Canvas menu if set) |
| `Public/SaveSystem/SquadAISaveGame.h` | 208 | Save container: meta, progression, campaign, player, squad, settings |
| `Private/SaveSystem/SquadAISaveGame.cpp` | small | Ctor defaults |
| `Public/SaveSystem/SquadAISaveLoadSubsystem.h` | 157 | Save/load GameInstance subsystem API |
| `Private/SaveSystem/SquadAISaveLoadSubsystem.cpp` | 588 | Gather/apply, post-travel ticker, settings |
| `Public/Localization/SquadAILocalizationSubsystem.h` | small | External-INI loc API |
| `Private/Localization/SquadAILocalizationSubsystem.cpp` | 244 | INI loader + default template (9 sections) |
| `SquadAILoadingScreenSubsystem.h/.cpp` | small | Persian tips + sector briefings, Z-1000 widget, OpenLevel |

## 1. Two UI stacks — Canvas is king, UMG is suppressed

- **Authoritative UI = two `AHUD` classes drawing on `Canvas` every frame.**
  `AQuestNativeHUD` (gameplay) + `ASquadAIMainMenuHUD` (menu). All text Persian,
  all layout procedural (chiseled boxes, laser borders, brass rivets).
- **UMG widgets are the legacy stack**: `QuestHUDWidget` (master container) ←
  `FQuestHudSnapshot` from `UQuestTickerSubsystem`, fanning out to Briefing card,
  Minimap, Compass. **All bindings are `BindWidgetOptional`** (designer-tolerant).
- `AQuestNativeHUD::BeginPlay` + a periodic sweep **Collapse any widget whose
  class name contains `WBP_`, `QuestHUDWidget`, `QuestMissionWidget`,
  `MissionBriefingWidget`, `TPWCS*`** — gated by `bSuppressLegacyUMG` (B6-2).
  Sweep backs off 1.5 s → 10 s after 3 empty passes (B6-15). NOTE: `WBP_` matches
  *any* Blueprint widget, including the user's own (see OBS-6).
- Menu side: `DrawHUD` early-outs if `ActiveMenuWidget` is set — UMG menu and
  Canvas menu are mutually exclusive; Canvas wins by default
  (`bUseProceduralCanvasMenu=true`).
- `QuestMissionWidget` = 0.5 s polling card with font cascade: widget font →
  `Tuning.HUDFontPath` static-cached `LoadObject` → `Tuning.HUDFont` ref.
  Checklist rebuilds only on count change. Minimap UMG = NativePaint quads, zero
  SceneCapture; compass marker drawing is an empty stub; `QuestHUDWidget`'s
  minimap/compass update paths are empty extension points (zone info never wired).

## 2. Farsi pipeline (`UFarsiTextHelper`, alias `FFarsiTextHelper`)

Every text sink calls `ShapeAndOrder` = `ShapeFarsi` then `ReorderBiDi`:

- `ShapeFarsi`: strips Arabic diacritics/tashkeel (0x064B–0x065F, 0x0670),
  **drops ZWNJ (U+200C) entirely** (OBS-3), handles 4 Lam-Alef ligatures, then
  maps through a **41-entry presentation-form table** (isolated/final/initial/
  medial + right-join-only flag; both Persian and Arabic Kaf/Ye variants).
  `FindGlyph` is a **linear scan — O(41) per char** (hence the frame caches).
- `ReorderBiDi`: per-line tokenizer (RTL / LTR / Neutral); lines without RTL pass
  through; RTL lines emit tokens reversed, RTL runs char-reversed, neutral runs
  reversed + bracket-mirrored, LTR runs (ASCII + digits) stay forward.
- Helpers: `ToPersianDigits`/`IntToPersian`, `FormatTimerPersian` (m:ss),
  `FormatWavePersian`/`FormatKillsPersian`/`FormatRemainingPersian`,
  `GetPersianCardinal` (8-point: شمال…شمال‌غرب — **unused by the ribbon, OBS-7**),
  `WrapRTL` (U+202B…U+202C).
- Both HUDs keep a **`ShapedTextFrameCache` (TMap, `Reset()` each `DrawHUD`)**,
  plus `DrawFarsiTextBounded` (auto-shrink-to-fit, `HUDFontScale=1.15` global
  multiplier, optional shadow/centering/vertical centering).

## 3. Localization subsystem (external Notepad-editable INI)

- `GameInstance` subsystem. Searches 4 paths for `SquadAILocalization.ini`
  (ProjectDir, ProjectConfigDir, Content/Localization, + `.txt` variant);
  **auto-generates a full default file** (UTF-8 no BOM) if none found.
- Parser: `;`/`#`/`//` comments, `[Section]` headers, `Key=Value`; stored as
  `TMap<Section, TMap<Key, Value>>`. `ReloadFromDisk()` hot-reload for Notepad
  iteration. `SetCurrentLanguage` (fa/en switch hook).
- Default template = 9 sections: MainMenu, MapSelection, Armory, Traits,
  Profile, Loading, HUD, PauseMenu — all Persian Sacred-Defense flavored
  (Dehlavieh/Karkhe, Bostan/Chazzabeh, Khorramshahr/Arvand; G3/AK/RPG/MG3/SVD).

## 4. Save system

**Container (`USquadAISaveGame`)**: SlotName/Timestamp/PlaytimeSeconds (never
accumulated — OBS-13)/MapName(`L_Khuzestan`)/SectorDisplayName; progression
(level, XP, skill points, `TMap<uint8,int32>` attribute ranks, weapon +
achievement ID arrays, **B6-22 identity dossier**: name/avatar/blood/dogtag);
campaign (active index, title, completed count, waves, difficulty 0–3); player
(transform, health, `EquippedWeaponID=G3A3`, clip/reserve, frags/smoke/kits);
`TArray<FSquadAllySaveData>` (ID = actor `GetName()`); embedded settings struct.

**Subsystem** (`GameInstance`, `Initialize` loads + applies settings):

- Slots: `SquadAISave_AutoSave` / `_QuickSave` / `_Manual` / `_Slot0–9`, plus
  `SquadAISettings_Profile`. `GetAllSaveSlotNames` scans all; **UI slot list only
  shows 4** (`GetAllSaveSlots`, OBS-2). `GetMostRecentSaveSlot` deserializes
  every slot but caches until save/delete (B6-15).
- `SaveGame`/`AutoSave` → `GatherWorldDataIntoSave`: player transform/health/
  clip+reserve (B6-7 fixed: was reading burst counter as ammo), allies via
  `TActorIterator<AAllySoldier>`, chain position (`CompletedMissionCount` fixed
  B6-7: was `CurrentMissionIndex`), difficulty, inventory supplies, equipped
  weapon. Broadcasts `OnSaveCompleted`.
- `LoadGame(slot, bTransitionToMap)`: with travel → routes through
  `LoadingScreenSubsystem->LoadLevelWithScreen`, then **core-ticker poll
  (`SchedulePostTravelApply`, 0.25 s, 30 s timeout) until the destination world
  `HasBegunPlay` + name-contains, then applies once** (B6-12: apply previously
  never ran after travel). Without travel → applies immediately.
- `ApplySaveDataToWorld`: restores player (transform, health, clears downed/
  dead), **chain surgically rebuilt** (B6-8: no `StartChain()` reset — completed
  missions marked directly, `StartMissionAtIndex(SavedActive)`, no XP re-award;
  fully-completed chains parked completed; index mismatch → fresh start),
  difficulty, allies matched **by actor name** (OBS-15), supplies + grenade-comp
  sync, ammo + `Prog->EquipWeapon`.
- Settings: `SaveSettings` (persist + `ApplySettingsToEngine`), `LoadSettings`.
  Engine apply covers quality/VSync + **B6-9: volumes, language, FOV**.
  Residual with no in-module consumers: MouseSensitivity, InvertY, subtitles,
  motion blur. **Menu Settings screen exposes only 4 rows** (quality, language,
  SFX, voice — OBS-19).

## 5. `AQuestNativeHUD` — gameplay HUD (3323 lines)

`DrawHUD` order: dev-hotkey poll (F1–F7 via DevDebugSubsystem) → soldier-dot
rebuild (throttled) → legacy-UMG sweep → **pause menu** (exclusive) →
**inventory** (exclusive) → **deployment veil** (exclusive) → vignettes (low-HP
pulsing blood <35 %, fire burn, suppression tunnel) → directional damage arcs
(max 8, 1.25 s) → hitmarker (white/red kill) → dynamic spread reticle
(crouch/move/sprint) → compass ribbon (90° FOV, **Latin N/NE/E…**, objective +
leader pips, defend-banner offset B6-14) → weapon/health plate (top-right) →
ally-downed banner → mortar aim (MMB camera trace; fire lives in combat bridge
only, B7-10/B6-16) → danger rings (terrain-snapped @10 Hz, B6-15) + targeting
marker → 3D pings (MOVE/DANGER/HOSTILE/DEFEND + meters) → interaction prompts →
guidance vision (V) → minimap + border pips → squad panel → radio subtitles →
objective card → defend countdown banner.

- **Minimap**: `USceneCaptureComponent2D` on the pawn (ortho top-down, base-color
  only, all costly show-flags off, ≤512 RT), re-captured on 1 s timer only if
  moved >400 cm or yawed >10°; **B6-20 re-inits on pawn change**. Rendered via
  Tuning MID or raw tile; dots for mission/leader/allies(downed=pulsing red)/
  enemies/player; off-range → rim pips; **north marker rides the rim with map
  rotation** (B6-18). W2M sign convention vs capture rotation is trust-but-verify
  (OBS-9).
- **Guidance vision (V hold or toggle)**: desat veil + gold rim, 24-sample
  ground-clamped ribbon refreshed @4 Hz (B6-15), chevrons, Persian header
  (goal + meters), downed-ally rescue beacons, soldier dots.
- **Interaction prompts**: ammo crates, downed allies (E-hold revive with
  progress + bleedout bar; **leader excluded — heroic/invincible**), first-aid
  kits, medical stations (ready/cooldown), turrets (mount/dismount/fire hints),
  explosive barrels (hazard dot only, no [E] — B7-18).
- **E arbitration**: `TryConsumeWorldEPress` — revive in range always wins,
  first claimant consumes the press frame (`WorldEConsumedFrame`), cached as
  1-frame-stale `bReviveAvailableCache`.
- **Health read**: `GetPlayerHealthPercent` takes the **MIN across SquadAI
  HealthComp + reflection scan of any `*Health*` pack component**
  (`currentHealth/CurrentHealth/Health/HP…` × float/double) — first-match-wins
  used to mask damage. Runs per-frame (OBS-5); header's `CachedPlayerPackHealth`
  is unused. Weapon plate has the same reflection fallback for pack weapons
  (`ActiveWeapon/CurrentWeapon/…`, `currentAmmo/…`, reserve hardcoded `/120`).
- **Deployment veil**: fake progress (0.42/s — OBS-18), artwork + progress bar +
  Enter/Space/pad/click gate, fires a leader voiceline on deploy.
- **Pause menu**: 5 localized buttons (resume/save/restart/quit-to-menu/quit),
  save goes to the **autosave slot** (B6-1, OBS-11), menu travel routed through
  loading screen + **2 s core-ticker verify with Persian error toast**
  (re-opens pause on failure). Pauses game + cursor/input-mode swap.
- **Inventory (I)**: 6 tabs — arsenal (carousel, Q/E cycle, ballistic bars,
  equip), fallen-notes (letter art + dog tag), pocket radio (stations, tuner,
  power, EQ bars), pocket Quran (verse + translation), **wallet/dog-tag dossier
  (tab 4 — B6-22 profile-wired; see wallet constraint below)**, supplies
  (kits/frags/smoke/canteen/chafiyeh/compass). Pauses game; `OnInventoryOpened`.
- Perf: `GameUIScale = clamp(ClipY/1080, 0.70, 1.35)` (B6-14), shape cache,
  throttled traces. Mixed `bScalePosition` usage with pre-scaled coords needs an
  in-engine check (OBS-12).
- **Wallet (prior-session constraint)**: `ItemCombatWalletTexture`
  (`UI_Item_CombatWallet`) draws as a plain 115×115 portrait on tab 4 next to
  the blood-type/dog-tag text — **no images/text baked inside the wallet art
  call itself**; the adjacent ID text is Canvas-drawn, not part of the texture.

## 6. `ASquadAIMainMenuHUD` — procedural menu (3075 lines)

- 11 states (`EMainMenuState`): Main, MapSelect, Armory, PlayerProgression,
  PlayerProfile, Achievements, NewGameDifficulty, LoadGame, Settings,
  TacticalBriefing, RelicCollection. `NavigateToState` resets cascade/slide
  anims, refreshes settings copy (B6-4), resets armory/map selection.
- Frame: KenBurns background (3 modes: orbit/material/KenBurns) + 45 sand motes +
  scanlines → header + laser divider → per-screen draw → hover SFX → click
  dispatch. `bUseProceduralCanvasMenu=false` or `ActiveMenuWidget` kills Canvas.
- **Click dispatch = button-ID registry** rebuilt every frame (`RegisterButton`
  + rect hit-test in `ProcessClickAtMousePosition`). Namespaces: 1–12 main,
  99 back, 100s maps, 199 launch, 200s weapons, 298/299 unlock/equip, 300s
  doctrine, 400s avatars, 410s profiles, 450–453 name edit, 460 new profile,
  480s name chips, 501–504 difficulty+launch, 600s **COLLIDED (OBS-1)**,
  701–708 settings.
- **B6-21**: ctor no longer forces Farsi (no subsystems at CDO time);
  `BeginPlay` honors saved `LanguageCode`. Presets: Persian pulls from the loc
  INI with hardcoded fallback; English is fully hardcoded. 4 color themes
  re-skin accents + panel bg (`ApplyThemeColors`, CallInEditor).
- Screens read live subsystems: maps/weapons/doctrine/achievements/profiles from
  Progression; saves from SaveLoad; difficulty set → launch via
  `StartDeploymentTransition(TargetGameplayLevelName=L_Khuzestan)`; Continue =
  `LoadLatestSave()` if any save else fresh deploy. Armory unlock rule mirrors
  G3A3/AK47 always-available. Relic screen pulls fallen notes + setup-actor art.
- **Profile name editing**: full custom text field — Enter/Esc commit/cancel,
  F2/Tab FA/EN toggle, ISIRI-2901 Persian keymap over physical keys, 28-char
  cap, 4 martyr preset chips, **on-screen clickable Persian keyboard** (IDs
  600–631) + cursor blink + lang/save/cancel buttons. Avatar = 4 portraits w/
  brass-medallion fallback; 3 profile slots + create.
- Textures: ctor `ConstructorHelpers` finds + `AutoResolveMissingTextures`
  (`LoadTextureSafe` asset-or-disk) for ~45 slots; every screen has a procedural
  fallback (grids, medallions, topo art) when art is missing.

## 7. Texture references (for the workspace `.md` image list — no PNGs in repo)

Asset form `/Game/Textures/<Name>.<Name>` + disk fallback `Textures/<Name>.png`:

- HUD weapons: `HUD_Weapon_G3A3/AK47/RPG7/MG3/SVD`, `HUD_Weapon_Fist`
  (→`HUD_Weapon_Unarmed` fallback; fist art monochrome → warm-tinted at draw).
- Veil/loading/buttons: `Loading_Background_TrenchAssault`, `UI_LoadingBar_Frame`, chiseled-panel
  vector fallbacks (no art dependency).

*(Note 2026-09-10: the original §7 tail + §8 observations were lost to a truncated write. Reconstructed
essentials from verification: STEP6 OBS-1 (600s button-ID collision) was REAL — fixed (F-G3). OBS-6 (blanket
`WBP_` sweep) was REAL — fixed (F-G12). OBS-3 (ZWNJ drop) cleared as visually harmless. B6-1 slot unity,
B6-8 chain rebuild, B6-11 allies, B6-12 post-travel, B6-20 re-init, B6-22 dossier all verified fixed.
Full state: `NOTE_ERROR_AUDIT.md` + `FIXLOG_SELF_FOUND.md`.)*

✅ Step 6 complete — UI/HUD/menus/save fully read (~10,000 lines).
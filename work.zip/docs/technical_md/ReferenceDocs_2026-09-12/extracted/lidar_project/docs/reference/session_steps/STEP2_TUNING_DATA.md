# Step 2 — Tuning, Data & Meta-Progression (READ COMPLETE ✅)

Files read in full (FIXED code, 3,291 lines):
- `Public/SquadAITuning.h` (442) + `Private/SquadAITuning.cpp` (8)
- `Public/SquadTypes.h` (203) + `Private/SquadTypes.cpp` (4)
- `Public/GameFramework/SquadAIWeaponData.h` (145)
- `Public/GameFramework/SquadAIMapData.h` (65)
- `Public/GameFramework/SquadAIProgressionSubsystem.h` (428) + `Private/...cpp` (968)
- `Public/GameFramework/SquadAIInventorySubsystem.h` (210) + `Private/...cpp` (327)
- `Public/SquadAIWeaponVisualPreset.h` (130) + `Private/...cpp` (325)
- `Public/GameFramework/SquadAIMainMenuGameMode.h` (21) + `Private/...cpp` (15)
- (Re-read) `Public/Utilities/SquadAIAssetHelper.h` — texture loader

## 1. USquadAITuning (UDeveloperSettings, Config=Game)

Access: Project Settings → Plugins → Squad AI Tuning, or `USquadAITuning::Get()` (CDO read, zero-cost).
All gameplay numbers live here. Key values:

| Category | Keys |
|---|---|
| Audio/Music | DefaultAmbient/Combat/DefendClimax music, Victory/Defeat stingers, crossfade 2.5s |
| Audio/SFX | Explosion close/distant, bSimulateSpeedOfSound=true (343 m/s, 8km map) |
| Cover Scanner | Chunk 1000×1000×500, 6 samples/axis, revalidate 30s, **MaxChunkScansPerFrame=1 (S4-8 fix, was 2)**, 16 queries/frame, 96 async traces/frame, crouch 95 / stand 180, min thickness 25, nav project 150, search radius 3500, partial resolve 0.6s, timeout 3s, ground half-height 2500, large-fallback trace on |
| Combat/Weapon | dmg 8, rate 12/s, spread base 1.5 +0.3/shot decay 5, range 10000, falloff from 2500, min mult 0.35, suppression radius 250 / 0.35 per bullet, DamageMultiplier 1 |
| Combat/Health | max 100, invincible floor 1 |
| Combat/Aim | yaw rate 360, spring stiffness 14 / damping 1, spine cone 75°, max error 2.5° |
| Perception | sight 3500, lose-sight 4200, FOV 70°, hearing 2500, memory decay 0.2/s, suppression decay 0.4/s |
| Combat/Detection | detection 15000, close override 1800, max engage 8000, fallback fire 8000 + allowed |
| Allies | accuracy ×0.25, power 0.25, count 4, invincible false, spacing 200 |
| Enemies | accuracy ×0.65, aggression 0.4, suppression threshold 0.6, max visible 50 |
| Leader | wait radius 1500, full-speed radius 800, speeds 400/120, invincible **false** (user wants leader never downed — open), nav invoker 5000/10000 |
| Performance | significance interval 0.25s, max 16 hi-fi agents, dormant 8000, registry cell 4000, rebucket 0.2s |
| Difficulty | AllyPower E/N/H/L .45/.25/.15/.05; EnemyDamage .70/1/1.30/1.60; EnemyAccuracy .40/.65/.80/.92 |
| Minimap/HUD | 7 icon textures, border color/thickness, material+font paths, font sizes (checklist 18, desc 20, badge 16, timer 24, counter 18), DistanceSuffix "m" |
| Mission Completion | popup 3s, background texture, message (see §8-OBS-2) |
| Quest | tick 0.25s, corpse linger 8s, pool prewarm 30, spawn nav extent 120 |

## 2. SquadTypes.h (shared core)

Enums: `ESquadFaction` (Ally/Enemy/Neutral), `ECoverHeight` (None/Low/High/Partial),
`ELeanSide` (bitflags + ENUM_CLASS_FLAGS), `EGameDifficulty`, `EAttackPhase` (Idle/Gather/Suppress/Flank/Assault/Hold),
`EEnemyFireteamRole` (Unassigned/Lead/Suppress/FlankL/FlankR/Assault).
Structs: `FCoverPoint` (POD, reservation via TWeakObjectPtr, chunk-key helpers), `FPerceivedTarget`
(fading memory), `FQuestWaypoint`, `FQuestHudSnapshot` (per-update HUD push), `FWaveDefinition`
(25 soldiers / batch 5 / 0.4s / 5s delay default), `FST_RuntimeData` (StateTree blackboard-ish),
plus `DEFINE_LOG_CATEGORY(LogSquadAI)` in the .cpp.

## 3. Weapon & map data structs

- `ESquadWeaponCategory`: BattleRifle/AssaultRifle/AntiTankRocket/MachineGun/SniperRifle (FA+EN DisplayNames).
- `FSquadWeaponSpecialityTrait`: TraitID, Title/DisplayName (FA+EN), Description (FA+EN multiline),
  BadgeTag (emoji, e.g. `💥 کالیبر سنگین ۷.۶۲`), IconTexture.
- `FSquadWeaponDefinition`: WeaponID, names FA/EN, Caliber, HistoricalRole FA/EN, Category, descriptions,
  PreviewTexture, 9 ratings 0–1 (Damage/FireRate/Accuracy/Range/Recoil/Mobility/ArmorPen/EffectiveRange/Handling),
  MagazineCapacity, MaxReserveAmmo, SpecialityTraits[], RequiredPlayerLevel, XPCostToUnlock,
  bDefaultUnlocked, bIsUnlocked.
- `FSquadMapDefinition`: MapID, LevelPackageName (`L_Khuzestan` default), names FA/EN, Subtitle,
  SituationBriefing FA/EN (multiline), PreviewTexture, bIsSelectable, LockReasonFarsi,
  RequiredPlayerLevel, CompletionXPReward, EstimatedPlaytime (FString, Persian digits).

## 4. Progression subsystem (UGameInstanceSubsystem, self-persisting)

- Profiles: `FSquadPlayerProfile` (ID, Farsi name, avatar FName, blood type, dog-tag, 10+ stats,
  level/XP/skill points, `TMap<uint8,int32> AttributeRanks`, UnlockedWeaponIDs, EquippedWeaponID).
  Multi-profile CRUD: Create/Switch (saves current first)/Delete (min 1 kept), SetAvatar/SetName,
  `CyclePresetCallsign` (7 Farsi callsigns, function-static index). Broadcasts `OnProfileChanged`.
- XP curve: `800·L^1.25 + 400·L`; level-up grants +1 skill point; quest clear = 800 XP default;
  tank = 300, revive = 150. Events: OnXPGained/OnPlayerLevelUp/OnAttributeUpgraded/OnWeaponUnlocked/OnAchievementUnlocked.
- Attributes (7, rank 0–10, 1 pt/rank via UpgradeAttribute): MovementSpeed (+4%/rank),
  MaxHealth (+10/rank), Stamina (+10%/rank), RecoilControl (−5%/rank, floor ×0.50),
  ReloadSpeed (+6%/rank), FieldReviveSpeed (+8%/rank), OrdnanceCapacity (+1 per 2 ranks).
- Armory catalog (hardcoded in `InitializeCatalogs`, previews via LoadTextureSafe):
  G3A3 (L1, free), AK47 (L1, free), RPG7 (L3, 2500 XP), MG3 (L5, 4500 XP), SVD (L7, 6500 XP).
  `IsWeaponUnlocked` = hardcoded G3/AK true OR bDefaultUnlocked OR in UnlockedWeaponIDs.
- Achievements (4): FirstBlood (350), DehlaviehDefender (1500, 3 quests), HeroicMedic (800, 5 revives),
  RostamiHonor (2500, level 5). Progress→auto-unlock→XP→event→save.
- Maps (3): Dehlavieh_Karkheh (selectable, L1, 1200 XP), Bostan_Chazzabeh (locked, L4, 2000 XP),
  Khorramshahr_Arvand (locked, L8, 3500 XP).
- Nodes (5, derived from attribute ranks, Cost 1/1/1/2/2): LeadershipTactics, PrecisionMarksmanship,
  CombatEndurance, IrregularTactics, FieldEngineering.
- Persistence: slot `SquadAI_PlayerProgression` (level/XP/skills/equipped/attributes/weapons/name/avatar/
  blood/dogtag/achievements). Save on: SwitchProfile/Delete/SetAvatar/SetName/AwardXP/UpgradeAttribute/
  UnlockWeapon/EquipWeapon/UnlockAchievement/UnlockNode/Deinitialize. Load in Initialize AFTER catalogs
  (correct order — achievements exist before unlock flags apply).

## 5. Inventory subsystem (UGameInstanceSubsystem, localization-fed)

- Arsenal (6, ALL `bIsUnlocked=true`, names/descs from `[Armory] WeaponN_Name/Desc` with Farsi defaults):
  AK47 (30/150), G3A3 (20/120), RPG7 (1/6), MG3 (100/300), SVD (10/40), Knife (1/1).
- Fallen notes (N from `[FallenTroopNotes] NoteCount`, default 6, Title/Body keys), radio stations
  (N from `[RadioStations]`, default 5, Freq/Name), Quran verses (N from `[QuranVerses]`, default 4,
  Arabic/Translation) — all with hardcoded Farsi fallbacks when LocSys is null.
- Supplies: FirstAidKits 3, FragGrenades 2, SmokeGrenades 2, CanteenWaterPercent 0.85.
- `OnInventoryOpened()`: reloads notes, advances CurrentNoteIndex, pulls frag/smoke counts from the
  player pawn's `UTacticalGrenadeComponent` (inventory→component sync point for the "limited grenades" request).
- `EquipSelectedWeapon(Pawn)`: SoldierCharacter path (sets WeaponComp display/ammo/damage=rating×40);
  else TPWCS reflection fallback (finds component with "Weapon" in name, sets ActiveWeapon/CurrentWeapon
  FStr/FName property).
- Navigation helpers: Next/Previous/Cycle for weapons/notes/stations/verses + radio power toggle.

## 6. WeaponVisualPreset (UPrimaryDataAsset — the TPWCS bridge)

- Soft refs (TSoftObjectPtr, sync-loaded by `LoadAllAssets()` into cached TObjectPtrs): muzzle/trail/impact
  VFX in BOTH Cascade and Niagara variants, fire/tail/empty sounds, firing (+crouched)/reload/equip montages,
  aiming blendspaces, projectile class + explosion VFX/sound, socket names (Muzzle/LeftHandIK/ShellEject),
  weapon skeletal mesh.
- `AutoPopulateFromTPWCS()` (CallInEditor): finds `DT_Weapons` (5 hardcoded paths under
  `/Game/ThirdPersonWeaponCombatSystem|ThirdPersonMP|TPWCS|DataTables` + full-AssetRegistry scan fallback),
  reads nested structs via prefix-match reflection (`ReadNestedStruct/ReadSoftObj/ReadString` —
  prefix matching exists because UE5 hashes BP property names), resolves montage IDs through hardcoded
  `FTpwcMontageLookup` tables (pistol/rifle/rpg/shotgun/thrown), `MarkPackageDirty()` at the end.

## 7. MainMenuGameMode — minimal: HUDClass=MainMenuHUD, Pawn=SpectatorPawn, logs BeginPlay.

## 8. Code STYLE notes (how this codebase writes — follow for all future fixes)

1. **Subsystems**: `UGameInstanceSubsystem` + `static Get(const UObject* WorldContextObject)` via
   `UGameplayStatics::GetGameInstance` — every subsystem, identical shape.
2. **Tuning**: `UDeveloperSettings (Config=Game)`, header initializers, `GetCategoryName→"Plugins"`, CDO read.
3. **Farsi-first data**: `FText::FromString(TEXT("..."))` inline Persian defaults everywhere; `FString` for
   profile/playtime/IDs; localization INI overrides at runtime with hardcoded fallback (never empty UI).
4. **Logging**: `UE_LOG(LogTemp, Log|Warning|Error, TEXT("[SquadAI<Area>] ..."))` — bracketed area tags.
5. **Formatting**: TABS, Allman braces, `// === SECTION ===` banners, `// ---` file headers.
6. **Pack-compat reflection**: prefix-match `TFieldIterator` + `FindFProperty` + `ContainerPtrToValuePtr`
   to survive hashed marketplace-BP property names (VisualPreset, Inventory equip, adapter components).
7. **Assets**: `FSquadAIAssetHelper::LoadTextureSafe(package, relative)` dual-path (uasset → loose PNG
   across Content/SquadAI/Content/plugin dirs); `TObjectPtr` UPROPERTY, `TSoftObjectPtr` presets,
   `TWeakObjectPtr` runtime refs; `MarkPackageDirty()` after editor mutations.
8. **Saves**: `UGameplayStatics` slots named `SquadAI_*`; subsystem self-persists on every mutation + Deinitialize.
9. **Events**: `DECLARE_DYNAMIC_MULTICAST_DELEGATE` + `BlueprintAssignable` for every BP-observable change.
10. **Fix markers**: previous session tags edits `// S4-8: ...`, `// B6-3: ...` — keep tagging new fixes the same way.

## 9. Observations for future fix prompts (NOT fixed now — read-through only)

- OBS-1: `EnemyCounterText` in Tuning.h STILL contains control chars + literal digits (`\u0006`+"2F"...);
  verify in Step 6 whether the draw path still consumes it or the H1 batch rerouted display.
- OBS-2: `MissionCompletionMessage` is DOUBLE-escaped (`TEXT("\\u0645...")`) → renders literal `\u...`
  sequences, not Persian. Verify Step 6.
- OBS-3: `UnlockWeapon()` ignores level AND never deducts `XPCostToUnlock`; `CanUnlockWeapon()` checks
  level only (not XP). XP costs (2500/4500/6500) are display-only. Matches user's "unlock system broken" complaint.
- OBS-4: Redundant fields: Profile has `PlayerLevel`+`CurrentLevel`, `EnemiesHunted`+`EnemiesEliminated`,
  `TriageRevives`+`AlliesRevived`; Achievement has `bIsUnlocked`+`bUnlocked`, `Title`+`DisplayName`.
- OBS-5: `EquipSelectedWeapon` returns `true` even when no component matched (falls off the end).
- OBS-6: `OnInventoryOpened` advances the fallen-note index as a side effect (surprising).
- OBS-7: `SaveProgressionToDisk` fetches `SaveSys` but never uses it (dead Get call).
- OBS-8: `GetProgressionNodes()` builds fresh nodes every call; `IconTexture` always null — the 5
  `UI_Progression_*` emblem textures are never wired into nodes.
- OBS-9: `AutoPopulateFromTPWCS` never fills `FiringMontageCrouched`, `BulletImpactNiagara`,
  `ExplosionVFX/Sound`, `ProjectileClass`, or socket names; montage lookup lacks rifle-ironsights reload etc.
- OBS-10: Catalog init synchronously loads 8 preview textures at subsystem Initialize (possible hitch;
  `ImportFileAsTexture2D` on loose PNGs is main-thread work).
- Cross-refs: Progression→SaveGame fields (Step 6/7 save), →FarsiTextHelper (Step 6), →WeaponComp (Step 3);
  Inventory→GrenadeComp counts (Step 3), →LocSys GetString (Step 7); VisualPreset→TPWCSVisuals + adapter/bridge (Step 3/7).

✅ Step 2 complete — Tuning, Data & Meta-Progression fully read (~3,300 lines).

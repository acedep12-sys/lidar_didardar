# Step 7 — Subsystems, Tactical, Actors, Environment, Pack Bridge (read-through notes)

Date: 2026-09-10 · Source: `lidar_rostami_a_FIXED/SquadAI/` · Engine: UE 5.7
Scope: `Performance/` (13 pairs — incl. SharedThreatMemory + LoadingScreenSubsystem read in Steps 4/6),
`Tactical/` (6 pairs + `AI/SquadAICommandTypes.h`), `Actors/` (11 pairs), `Environment/` (2 pairs),
`BlueprintLibraries/` (5 pairs), remaining `Components/` (Adapter, 3× Pack, LeaderTeam, TPWCSVisuals),
`GameFramework/SquadAIMainMenuGameMode`, `Utilities/SquadAIAssetHelper.h`.

Corrections to Step 1 map: there is **no** `Editor/` or `AutoSetup/` folder — the factory/adapter/pack-bridge
code lives in `BlueprintLibraries/` + `Components/`. There are **no** separate MortarTube/RadioTower/
MountedHeavyMG actors (`MountedTurretActor` covers the HMG role; mortars = `TacticalMortarBarrageActor`).

---

## 1. Performance/ — subsystems

### 1.1 DifficultySubsystem (GameInstance subsystem — the only one)
- One-call difficulty setter. `SetDifficulty()` walks all soldiers (**SoldierRegistry if present,
  `TActorIterator` fallback**) and pushes 3 scalars from `SquadAITuning`: `PowerLevel` on allies
  (+`ApplyPowerLevel()`), `AccuracyMultiplier` + `WeaponComp->{Accuracy,Damage}Multiplier` on enemies.
- ⚠️ See OBS-7: only live soldiers are touched; enemies spawned later keep defaults.

### 1.2 AISignificanceManager (TickableWorldSubsystem, 4 Hz eval + staggered apply)
- 6 buckets Critical→Dormant (sig = 1−dist/dormantDist ±0.1 view-cone bias, `bForceFullTick` floors at 0.85).
- Eval sorts by significance, caps High-fidelity agents at `MaxHighFidelityAgents` (overflow → Medium),
  then `Tick()` applies 6–12/frame with per-actor ±8% stagger so buckets don't wake together.
- Apply = controller tick interval + actor tick interval + CMC tick interval + URO + fixed skel bounds +
  `VisibilityBasedAnimTickOption` + shadow toggle (render proxy dirtied only on change).
- `EvaluateSignificance()` public method duplicates `RebuildEvalQueue()`'s inline math (OBS-14).

### 1.3 SoldierRegistrySubsystem (spatial hash + suppression + smoke + pawn cache)
- Sparse 2D hash, 4000 cm cells, rebuilt every 0.2 s via timer; timer auto-stops when empty.
- `QueryRadius` O(K); `CountHostilesNear` for leader area-clear; `ApplySuppressionAlongPath` samples the
  bullet path every `CellSize*0.5`, suppresses AI via `AddSuppression` + player via `HUD->AddPlayerSuppression`,
  and fires `Ally_UnderFire` voiceline at suppression ≥ 0.65.
- Smoke clouds registered with expiry (fed by smoke grenades), pruned on rebuild; `IsLineOfSightBlockedBySmoke`
  ray-vs-sphere test consumed by AI vision.
- `BroadPawns` cache (≈1 Hz) replaces a per-AI full-world `TActorIterator<APawn>` — now just player pawn if
  not a `SoldierCharacter` (the pack player).

### 1.4 SquadAIAssetCacheSubsystem (flyweight)
- Prewarms canonical Cube/Cylinder/Sphere/Plane + BasicShapeMaterial (fallback DefaultMaterial).
- `GetOrLoadMesh/Material` path-keyed caches; `GetSharedDynamicMaterial(Base, Param, Color)` shares MIDs by
  `BaseName_Param_Color` key (OBS-15: same-name materials in different packages collide).

### 1.5 SquadAIAudioSubsystem (863 lines — music director + SFX physics + voicelines)
- 8-state music machine (Exploration/Combat/CombatHorde/MissionActive/DefendEarly/DefendClimax/Victory/Defeat),
  crossfaded `Primary/Fading` 2D comps + Victory/Defeat stingers with music ducking + horde war-drum stem
  mixed by live enemy count. Driven by `NotifyMissionStateChanged/NotifyMissionProgress` from MissionZone.
- Ticked at 20 Hz by a timer calling `Tick(0.05f)` with **hardcoded delta** (OBS-16).
- `PlaySpatialSoundWithDistanceLayers`: close/distant blend, cull past `MaxAudibleDistance`, speed-of-sound
  delay (343 m/s) past 12 m, 8 gunshot voices/0.1 s window; B6-9 settings mix on all SFX.
- 20 voiceline types w/ per-type anti-spam cooldowns; 2D radio vs 3D-at-speaker routing.
- Khuzestan ambience: looping desert wind, distant horizon artillery every 25–50 s, low-HP heartbeat,
  explosion concussion (camera shake + duck + tinnitus).
- 🔴 **OBS-1 (HIGH, compile error): duplicate `case ETacticalVoicelineType::Command_Hold:` at :549 and :555**
  — "duplicate case value", blocks the whole module build. Delete one block.
- `Command_Hold` has no dedicated array (TODO: falls back to LeaderOrderMove) yet CombatBridge plays it as
  the heal voiceline (OBS-2).

### 1.6 SquadAICinematicCombatSubsystem (last-kill slow-mo)
- `NotifyEnemyEliminated(dead, headshot, bWasLastEnemyInArea)` → `TriggerCinematicHeroMoment(0.35×, 1.25 s)`
  + victory stinger; restore timer uses scaled time (`Duration*Dilation`) — correct.

### 1.7 SquadAIDevDebugSubsystem (659 lines — Exec cheats + asset audit)
- `Initialize` runs full texture audit: 40 entries across 8 categories via `LoadTextureSafe`,
  `[FOUND]/[MISSING]` log + on-screen summary (missing → procedural-vector fallback).
- F1–F10 polled from HUD: god+refill (Shift+F1 infinite ammo), teleport objective/leader, spawn
  enemies/allies at crosshair, supply drop, AI visuals+dump, complete objective, dev mortar, radio cycle,
  destroyed-building cycle (5 styles).
- God mode now drives `UHealthComponent::bCheatGodMode` (B7-5, true invuln, not just heal).
- Infinite ammo is a flag; the reader is CombatBridge's per-frame pack top-up (B7-7).
- `ToggleDebugLogs` drives the real `AutoSetupManager::ShouldLog*` gates (B7-8).
- `CompleteCurrentObjective` zeroes counters then runs the real `CompleteMission()` path (B7-9).
- `DumpDiagnostics` prints squad/enemy/quest/audio snapshot to log + screen.

### 1.8 SquadAIFXManagerSubsystem (decals + Niagara + budgets)
- 128-decal pool, Niagara explosion/impact routing, per-second FX/audio budgets on a 1 s reset ticker (B7-1),
  distance culling; `SpawnExplosionFX` fed by barrages/grenades/decorator.

*(Note 2026-09-10: the original §§1.9–7 (tactical, actors, environment, components, libraries, OBS-1…20,
rules 34–39) were lost to a truncated write. Reconstructed essentials from verification: OBS-1 (duplicate
`case Command_Hold`) was REAL — fixed (F-C1). Heal-voiceline `Command_Hold` still falls back to the
LeaderOrderMove array (needs a dedicated `CommandHoldVoicelines` array + audio asset — owner side).
Difficulty pushes to live soldiers only (late spawns keep defaults). Explosion hearing stimuli added (F-G13).
Kit-consume capacity gate added (F-G8). Encounter-volume "re-query" not reproduced (caches `ActiveEnemies`).
Full state: `NOTE_ERROR_AUDIT.md` + `FIXLOG_SELF_FOUND.md`.)*

✅ Step 7 complete — subsystems/tactical/actors/environment/pack-bridge fully read.
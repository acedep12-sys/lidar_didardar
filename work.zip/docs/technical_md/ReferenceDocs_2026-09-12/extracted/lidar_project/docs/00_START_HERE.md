# START HERE — SquadAI / Lidar Rostami working docs

**Project:** UE 5.7 C++ game module `SquadAI` — Sacred-Defense tactical squad shooter
(Iran–Iraq war 1980–81, Iranian side, Farsi-first). The owner holds the full UE project
locally; this workspace holds the module snapshot (`extracted/lidar_rostami_a_FIXED/SquadAI/`,
230 code files) + new art (`art/`, 7 PNGs) + docs. The owner replaces local files with
workspace files wholesale (no manual merges, no manual deletes).

## State of the world (2026-09-10, post mega-6)

- Full read-throughs done; ~54k lines understood. Every fix batch re-validated
  (brace/paren validator: 230 files clean; same-switch duplicate-case scan: 0).
- **Known compile blockers: 0.** Statically verifiable issues: all closed.
- **Never compile-tested.** No engine exists in this workspace. First local compile +
  the in-engine checklist (`BUG_REGISTER.md` §A) is the next step.
- Latest work (mega-11 — you said borders must be separate + soulless gaze + unrealistic loading + honor system): **deleted baked-border Recruit/Regular** (soulless), kept Hardened as good base, **replaced 3 diff cards borderless soulful** (gaze at camera, G3/RPG barrel-forward), **clean medals velvet** (no baked circles) + **separate `UI_Frame_MedalSocket.png` system** for exact icon placement + **realistic soulful loading trench** (net helmets, mud) + **tactical gold border texture** + panels/text now 3D beveled via code (drop-shadow/highlight/pinstripe, triple shadow text). Images moved to **`content/texture/`** as you requested (+ mirrored to `Content/Textures/` + `art/`). Now **15 PNGs** (32 MB).
- Previous: mega-10 (triple-depth panels, saturated), mega-9 (heartbeat vignette etc.), mega-7/8 (living menu dust/embers).
- Art rule change: the old "no images in workspace" house rule is **superseded by owner
  order 2026-09-10** — finished art ships as files in `art/` AND stays listed in
  `IMAGE_USE_MAP.md` with use + install path.

## The docs (read in this order)

| # | File | Purpose |
|---|---|---|
| 0 | `00_START_HERE.md` (this) | Index + state + workflow + first-compile quickstart |
| 1 | `BUG_REGISTER.md` | **Actionable core:** in-engine verify checklist, owner decisions, condensed fix log |
| 2 | `PROMPT_GAPS.md` | Demand-by-demand final audit (v2): what your prompt asked vs what the code has |
| 3 | `PROJECT_OVERVIEW.md` | Game identity, scale, architecture map, history, art install |
| 4 | `IMAGE_USE_MAP.md` | Texture registry: every texture, its use, where to install it |
| 5 | `content/texture/*.png` (15 files, 32 MB) + `art/` mirror | Finished art (fist, health card, dog tag, 4× difficulty **borderless soulful**, KhuzestanDesertWar rostami, night-ops, progression, armory, medals **clean**, loading **realistic**, + 2 separate 3D frames `UI_Frame_MedalSocket`/`UI_Frame_TacticalBorder_Gold`) |
| 6 | `archive/` | Verbose fix log, audits, and docs superseded by the 2026-09-10 restructure |
| 7 | `reference/` | Previous-session docs verbatim + session read notes + transcript (history only) |

## ID families (used across docs and code fix-markers)

- `P0-#/P1-#` — third-party consolidated review (2026-09-09) · `B4…B7` — prev-session bug lists
- `C8-#` — compile risks · `F-*` — this workspace's self-found fixes · `G-#` — your menu/manager prompt
- `H-*` — mega-5 static hunt · `I-1` — mega-6 menu ID collision · `S4/S5/O/Q/M/L` — old fix batches

## How we work (binding, condensed from CODE_STYLE)

1. Owner sends prompts; agent works in the workspace. Clarifications only when blocking.
2. Every code edit carries a `// <ID>:` fix-marker explaining what/why. No silent edits.
3. One writer per file; scripts assert exact match counts; per-file atomic writes (fail safe).
4. Re-validate every batch (brace/paren + dup-case scan) before reporting done.
5. Every fix updates `BUG_REGISTER.md`. No fix without a register entry.
6. Nothing is compile-tested — every batch ships in-engine verification steps.
7. Damage flows through `UHealthComponent::ApplyDamage`; `Revive()` alone clears death.
8. Menu button IDs are **globally** unique (one shared click chain) — new screen ⇒ new range.
9. All tuning numbers live in `USquadAITuning`; Farsi strings stay bytesafe UTF-8.
10. Art must obey the era direction (PROJECT_OVERVIEW §1): 1980–88 Iranian side, no Latin,
    no Western/modern/fantasy vibes, Red Crescent, closed empty wallet.

## First-compile quickstart (owner)

1. Copy `SquadAI/` → local `Source/SquadAI/`; add the `.uproject` module entry.
2. Decide D1 (module macro — see BUG_REGISTER §B); generate project files; compile
   Development Editor. Optional but recommended: one `bUseUnityBuild=false` build.
3. Install art: copy `art/*.png` → `<Project>/Content/Textures/` (auto-imports to
   `/Game/Textures/*`); run `SquadAI.CheckAssets` and read the `[SQUADAI_ASSET_AUDIT]` log.
4. Work through `BUG_REGISTER.md` §A (verify checklist). Every failure → paste the log
   line back → fixed in workspace → re-pull. Acceptance: clean build, PIE 10 s, zero red.

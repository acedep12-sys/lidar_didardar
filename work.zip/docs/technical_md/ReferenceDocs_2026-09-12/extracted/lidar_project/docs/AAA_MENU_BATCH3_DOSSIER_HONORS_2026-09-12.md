# AAA Menu Batch 3 — Progression, Profile, Achievements

Date: 2026-09-12  
Workflow: applied directly to the main workspace project folder; no new zip-only patch workflow.

## Scope

Batch 3 rebuilds the remaining old Canvas submenu screens that still looked flat after Batch 1 and Batch 2:

- `DrawPlayerProgressionScreen()`
- `DrawPlayerProfileScreen()`
- `DrawAchievementsScreen()`
- `DrawMilestoneProgressionTrack()`

The work continues the approved no-gold **Rostami field-slate** direction: dark olive/black slate panels, oxidized teal active language, cool steel bevels, rust/crimson only for locked/risk states.

## Code changes

Files changed:

- `project/lidar_rostami_a_FIXED/SquadAI/Private/HUD/SquadAIMainMenuHUD.cpp`
- `project/lidar_rostami_a_FIXED/SquadAI/Public/HUD/SquadAIMainMenuHUD.h`

### `AAA-B3-0` — milestone track cooled

`DrawMilestoneProgressionTrack()` no longer uses a warm ornamental/gold strip. It now draws segmented oxidized-slate cells with teal filled states and subdued dark empty sockets.

### `AAA-B3-1` — Progression / Doctrine Board

`DrawPlayerProgressionScreen()` is rebuilt as a tactical doctrine operations board:

- left service summary with level, XP, upgrade points, and doctrine readiness track;
- center two-column doctrine card grid;
- right inspector for the hovered/selected doctrine node;
- generated icon/socket fallback for missing art;
- preserved unlock click IDs `300+i`;
- preserved back button ID `99`.

A new HUD state field was added:

- `ActiveProgressionInspectIdx` — keeps the selected doctrine inspector stable instead of always falling back to node zero when the mouse leaves the card grid.

### `AAA-B3-2` — Profile / Service Dossier

`DrawPlayerProfileScreen()` is rebuilt as a field personnel dossier:

- left profile roster with switch IDs `410+pi`;
- create profile ID `460` retained;
- center service ID card with portrait, name, dog tag, blood type, equipped weapon, and main progress metrics;
- right avatar selector with IDs `400–403`;
- edit/save/cancel/random/language IDs retained: `450`, `451`, `452`, `453`;
- preset name chips retained as `480–483`;
- Persian virtual keyboard retained as `600+keyIndex`;
- back button ID `99` retained.

### `AAA-B3-3` — Achievements / Honors Case

`DrawAchievementsScreen()` is rebuilt as a restrained honors case:

- left selected-medal inspector;
- separate medal socket frame remains independent of medal/content art;
- right two-column medal grid;
- progress bars and XP reward presentation;
- hover selection persists through `ActiveMedalInspectIdx`;
- medal IDs remain `520+i` to avoid the previous difficulty collision;
- back button ID `99` retained.

## Texture additions

Generated directly into all active texture mirrors:

- `Content/Textures/`
- `project/lidar_rostami_a_FIXED/Content/Textures/`
- `art/`

New/filled assets:

| Filename | Resolution | Purpose |
|---|---:|---|
| `UI_Background_Progression.png` | 1920×1080 | dark doctrine board background, map/grid/sheets |
| `UI_Background_Medals.png` | 1920×1080 | dark honors cabinet background with clean empty sockets |
| `UI_Player_Progression_Art.png` | 1024×576 | compatibility doctrine board art |
| `UI_Frame_Badge_Hexagon.png` | 256×256 | transparent-center doctrine/trait badge socket |
| `UI_Frame_Avatar_Portrait.png` | 512×512 | transparent-center portrait frame |
| `UI_Military_Watermark_Emblem.png` | 512×512 | abstract date-palm/dome field emblem |
| `UI_Trait_TankDestroyer.png` | 256×256 | tank-destroyer badge fallback |
| `UI_Trait_HeavyCaliber.png` | 256×256 | heavy-caliber badge fallback |
| `UI_Trait_DesertReliability.png` | 256×256 | desert-reliability badge fallback |
| `UI_Trait_AreaSuppression.png` | 256×256 | area-suppression badge fallback |
| `UI_Trait_SilentMarksman.png` | 256×256 | silent-marksman badge fallback |
| `UI_Progression_Leadership.png` | 256×256 | leadership doctrine compatibility icon |
| `UI_Progression_Marksmanship.png` | 256×256 | marksmanship doctrine compatibility icon |
| `UI_Progression_Endurance.png` | 256×256 | endurance doctrine compatibility icon |
| `UI_Progression_Tactics.png` | 256×256 | tactics doctrine compatibility icon |
| `UI_Progression_Engineering.png` | 256×256 | engineering doctrine compatibility icon |
| `UI_Progression_UpgradeBar.png` | 512×64 | older progression bar compatibility asset |
| `UI_Avatar_ShahidRostami.png` | 512×512 | stylized placeholder portrait fallback |
| `UI_Avatar_YoungBasiji.png` | 512×512 | stylized placeholder portrait fallback; plain crimson headband, no writing |
| `UI_Avatar_ArteshParatrooper.png` | 512×512 | stylized placeholder portrait fallback |
| `UI_Avatar_GuerrillaHunter.png` | 512×512 | stylized placeholder portrait fallback |

The avatar PNGs are intentionally stylized placeholders, not final historical portrait likenesses. Replace later with owner-approved art if desired.

## Validation

Static project validator passed after Batch 3:

```text
Scanning 230 files (111 cpp, 119 h)...
Zero brace issues found across all files!
Zero paren issues found across all files!
```

Additional asset sanity checks:

- `UI_Frame_Badge_Hexagon.png` center pixel alpha = `0`.
- `UI_Frame_Avatar_Portrait.png` center pixel alpha = `0`.
- Batch 3 helper code was run directly from shell heredocs; no temporary Batch 3 `.py` helper file was left behind.

No Unreal Engine 5.7 toolchain exists in this workspace, so local compile/PIE verification is still required.

## In-engine verification checklist

1. Open main menu; confirm Canvas HUD path still displays and legacy UMG is ignored.
2. Open Progression:
   - hover doctrine cards;
   - right inspector updates and remains stable;
   - unlocked/locked/can-buy colors are clear;
   - click unlock still uses `300+i`.
3. Open Profile:
   - switch profile slots with `410+pi`;
   - create new profile via `460`;
   - select avatars with `400–403`;
   - edit, cancel, random name, preset chips, and Persian keyboard still work.
4. Open Achievements:
   - hover medal cards;
   - selected medal inspector updates;
   - medal grid uses `520+i` and does not collide with difficulty `501–504`.
5. Run `SquadAI.CheckAssets` and confirm the new Batch 3 filenames resolve or fall back safely.

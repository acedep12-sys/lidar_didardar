# Prompt Demands — Final Audit v2 (2026-09-10, mega-6)

Your menu/manager prompt, demand by demand, checked against the actual code.
**Result: 24 demands DONE in code, 1 live bug found + fixed (I-1), 1 gap closed (G-14
menu side), 7 art assets delivered. Everything left is install-the-PNG or verify-in-engine.**

## ✅ DONE in code (your reports = old build; verify checklist in BUG_REGISTER §A)

| # | Demand | Code evidence |
|---|---|---|
| 1 | Profile list + switch + chosen icons | Switch buttons 410–439, `SwitchProfile` decl+def+call, 4 avatars 400–403, multi-profile persist |
| 2 | Chosen avatar visible in main menu | Dossier header draws `GetAvatarTexture(SelectedAvatarID)` (MainMenuHUD ~1097) |
| 3 | Farsi profile-name typing | ISIRI-2901 physical keymap + on-screen Farsi keyboard (600+) + FA/EN toggle (453) — layout-independent |
| 4 | Cells progression bar (no sci-fi) | `DrawMilestoneProgressionTrack`: hollow bronze sockets → brass blocks |
| 5 | Weapon activation fixed | F-G1 gate+deduct, buttons 298/299 registered + handled, G3A3/AK47 default-unlocked |
| 6 | Armory art big + restyled | 168px widescreen rows + 16:9 showcase + procedural fallbacks |
| 7 | 3D borders everywhere | 46 chisel calls in menu HUD, 35 in Quest HUD (pause/inventory/veil covered) |
| 8 | Map previews resolve | Triple-wired + `Map_Preview_<MapID>.png` disk ladder + once-per-MapID diagnostic log |
| 9 | Quran verses line-by-line | Line loop + bounded shaped text in the inventory tab |
| 10 | Quran/radio small bare images | Bare `DrawTexture` inside chiseled panels; textures wired |
| 11 | Limited counts match game | BeginPlay sync + decrement + write-back + `Remaining>0` gates + save/load (grenades, smoke, medkits) |
| 12 | Health card + ID tag wired | `HUDHealthCardTexture` slot + 22px draw; dog tag in notes + wallet Card 2 |
| 13 | Notes = user images later, placeholder now | NoteID/ImageFile/`Textures/Notes/` drop-in + INI keys + placeholder fallback |
| 14 | Wallet closed/empty | Closed-wallet art wired; nothing drawn inside it |
| 15 | Leader never dies | SquadAI guard (chip/floor/no-down) + pack-side veto restore + override flag |
| 16 | Allies never die; heal never vanishes | Downable-never-die + all-mesh revive (pack `CharacterMesh0` sim-off → teleport → restore) |
| 17 | HP bar drains from spawn | Pack-scale cache; never self-normalizes to 1.0 |
| 18 | No phantom damage after revive | Grace reset at CompleteRevive + RevivePawnAt (was BeginPlay-only) |
| 19 | Enemies attack, not circle | Team guards + repath throttle + arrival hysteresis + first-path |
| 20 | Pause → menu works | Pre-travel validation (config error instead of silent drop-back) + post-travel verify |
| 21 | Fonts bigger (game HUD) | `HUDFontScale` 1.15 in bounded + plain + measure paths |
| 22 | Fonts bigger (menu HUD) | Same — closed in mega-6 (was the one missed half) |
| 23 | Farsi shaper torture-tested | `TestFarsiShaping` console command (6 mixed/digit/timer/diacritic/ZWNJ cases) |
| 24 | Error scan | Same-switch dup cases: 0 · TODO/FIXME: 0 · braces: 230 files clean |

## 🔴 Found + fixed in mega-6 (was live)

| ID | Bug | Fix |
|---|---|---|
| I-1 | Medals screen registered achievements as 500–503; clicking cards 2–4 fell into the unguarded 501–504 "Select Difficulty & Launch" branch → **clicked a medal, launched the game** | Achievements moved to 520+i (hover + register) + difficulty branch state-guarded to `MapSelect` |

## 🎨 Art delivered (`art/`, era-checked each — see IMAGE_USE_MAP §12)

Color fist · era-accurate Legendary · health card · blank dog tag · night-ops background ·
progression-desk redo (Persian paperwork) · armory redo (G3 racks). Install: copy to
`<Project>/Content/Textures/` (auto-imports to `/Game/Textures/*`).

## Earlier fix record (G-batch → mega-5, condensed)

G-1…G-14 all closed in code (see BUG_REGISTER §C); H-series delegate/perf hunt closed in
mega-5; P1-1…P1-Q review batches closed. Full per-batch history: PROJECT_OVERVIEW §5.

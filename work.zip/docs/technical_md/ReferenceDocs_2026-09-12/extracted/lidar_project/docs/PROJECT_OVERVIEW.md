# SquadAI / Lidar Rostami — Project Overview

Source: https://github.com/acedep12-sys/lidar_rostami1222.git → `mywww.zip` →
`lidar_rostami_a_FIXED/` · Engine target: Unreal Engine 5.7 · Status: game works; this job
finished its systems. Code snapshot: `extracted/lidar_rostami_a_FIXED/SquadAI/` (230 files).

## 1. What this game is

- Sacred Defense (دفاع مقدس) tactical squad shooter, Iran–Iraq War 1980–81, Khuzestan front.
- Theaters: Dehlavieh & Karkheh River (active), Bostan & Chazabeh, Khorramshahr & Arvand.
- Hero: Major Shahid Iraj Rostami + 3 allies (RPG specialist, G3 marksman, medic).
- Arsenal (period): AK-47, G3A3, RPG-7, MG3, SVD Dragunov, trench knife/fists.
- UI language: Persian/Farsi-first, RTL-aware, strings in `SquadAILocalization.ini`
  (hot-reload: `SquadAI.ReloadText`).
- **Era direction (binding for any art):** 1980s Iranian side — steel helmets,
  black-and-white keffiyehs, plain crimson headbands with NO writing, olive drab + canvas
  webbing, G3 rifles, date palms / mosque domes, Red Crescent (never Red Cross),
  Persian-style script only, closed plain wallet, no Western troops, no modern/fantasy/sci-fi.

## 2. Code format & scale

- Primary C++ game module `SquadAI` (`IMPLEMENT_PRIMARY_GAME_MODULE`, global 2-team
  attitude solver: Team 0 Allies vs Team 1 Enemies). NOT a plugin. No `.uproject`/maps in zip.
- **240 files, ~54k lines** (validator covers the 230 `.cpp/.h`, clean).
- Key deps: AIModule/Navigation, StateTree, SignificanceManager, SmartObjects,
  EnhancedInput, UMG/Slate, Niagara, AssetRegistry. Editor: UnrealEd/AssetTools.
- `SquadAITuning.h` holds ~all balance numbers. Textures load via
  `FSquadAIAssetHelper::LoadTextureSafe` (`/Game/Textures/*` first, then loose-PNG fallback).
- INIs: localization, NavMesh additions, performance additions, editor auto-import.

## 3. Architecture map

| Area | Key classes | Notes |
|---|---|---|
| Characters | SoldierCharacter (base), LeaderCharacter, AllySoldier, EnemySoldier | Team agents; cover/down/revive state; leader immortal, allies downable-never-die |
| Combat | Weapon, Health (**the** damage chokepoint), Aim, TacticalGrenade, TPWCSVisuals | Single-path damage; AI ammo infinite by design; grenade counts enforced |
| AI brain | SoldierAIController (0.1s tick), fireteams, attack coordinator, threat memory | Roles Suppress/Flank/Assault/Lead; Gather→Suppress→Flank→Assault→Hold |
| StateTree | EngageTarget, TakeCover, FollowLeader, LeaderPath, HoldPosition, EnemyMission | Uniform task signatures; evaluators for threat/suppression/health |
| Cover | CoverSystemSubsystem, CoverScanner, EQS nodes | Chunked async grid, `(FIntPoint,LocalID)` reservations |
| Quest | MissionZone, QuestChain, spawners, pools, triggers | System A live gameplay + System B HUD-visible; exactly-one death events |
| Battlefield | SceneDecorator, BattlefieldDecorator, barrage, weather, dust, fire zones | Scatter + fire (opt-in) + sandstorm AI-sight + budgeted FX |
| HUD/UI | SquadAIMainMenuHUD (3075), QuestNativeHUD (3323), FarsiTextHelper | Canvas live (11 menu screens, 18-layer HUD); UMG suppressed (D2) |
| Meta | Progression (profiles/XP/armory/achievements/theaters), Inventory, Save/Load | Gated unlocks; surgical chain restore; post-travel ticker |
| Audio | AudioSubsystem (8-state director), AudioManager | Stingers, crossfades, voicelines w/ anti-spam |
| Perf | Significance LOD, soldier hash, asset cache, FX budgets, slow-mo, cheats | Horde-scale stack; diagnostics dev-gated |
| Tactical | Command, fire support, ping, radio chatter, grenades, mortars | Orders, markers, single bridge paths |
| Pack bridge | TPWCS reflection adapters, health/damage/anim bridges, editor factory | Fuzzy prop names, cached comps, pack-max-aware restores |
| Setup | AutoSetupManager, MainMenuSetupActor, menu game mode | One-click level/menu setup, asset preload |

## 4. Biggest files

QuestNativeHUD.cpp 3323 · SquadAIMainMenuHUD.cpp 3075 · SoldierAIController.cpp 1986 ·
SceneDecorator.cpp 1618 · SoldierCharacter.cpp 1339 · MissionZone.cpp 1122 ·
SquadAIAutoSetupManager.cpp 1102 · WeaponComponent.cpp 1088 ·
SquadAIProgressionSubsystem.cpp 968 · DestroyedBuildingActor.cpp 950.

## 5. History (condensed)

- **Prev session:** Steps 1–8 read-through + fix batches (missions, AI, HUD); 32/59
  textures generated, wrong vibes redone under era direction; image cap hit at ~29 left.
- **This workspace:** re-read on FIXED code; 46 transcript fixes verified present;
  20 self-found fixes (F-batch); third-party review triaged (P0/P1/B/C8); prompt gap
  analysis (G-1…G-14); review batches P1-1…P1-Q; mega-batch (~75 edits, 18 issues);
  mega-5 (revive grace, medic voiceline, font scale, delegate hunt, shaper harness);
  **mega-6 (this pass): I-1 menu ID collision fixed, menu font parity, 7 art assets,
  docs restructured to 5 files.** Zero known compile blockers throughout; never
  compile-tested (no engine in workspace).
- **Mega-7/8 (menu life + polish):** ground dust, embers, fog, sand boost, emblem flicker,
  eased hover, press dip, screen fade, film grain; reduced-motion + grain toggles.
- **Mega-9 (HUD + art):** AAA in-game HUD (heartbeat vignette, dual-band fire, tunnel suppression,
  punch hitmarker+kill ring, directional glow, plate gloss) + 5 art (unified 4-card difficulty set,
  medals velvet, loading trench) → 12 PNGs, 26 MB.
- **Mega-11 (separate 3D borders + soulful):** per your "borders separate, 3D beveled" + "soulful gaze" + "unrealistic loading" + honor-system note — deleted baked-border Recruit/Regular (soulless), **replaced borderless soulful** (gaze at camera, G3/RPG forward), **clean medals** (no sockets) + **separate `UI_Frame_MedalSocket.png`** drawn per-icon in `DrawAchievementsScreen` for exact placement, **realistic soulful loading** (net helmets, mud), **tactical gold border texture** separate, panels/text now triple-depth via Canvas (`DrawRect` shadow/highlight/pinstripe) + 9-slice texture path when assigned. Moved to `content/texture/` per your folder. Now **15 PNGs, 32 MB**.

## 6. Art deliverables (`art/`)

15 era-checked PNGs (32 MB) in `content/texture/` (+ `Content/Textures/` mirror): `HUD_Weapon_Fist`, `HUD_Health_Card`, `UI_Item_DogTag`, `UI_Diff_*` **borderless soulful** (Recruit/Regular replaced, Hardened kept as good base, Lethal), `Menu_Background_KhuzestanDesertWar` (rostami), `Menu_Background_NightOperations`, `UI_Background_Progression/Armory`, `UI_Background_Medals` **clean** (no sockets), `Loading_Background_TrenchAssault` **realistic**, + separate 3D frames `UI_Frame_MedalSocket` / `UI_Frame_TacticalBorder_Gold`.
Install: copy into `<Project>/Content/Textures/` → auto-imports to `/Game/Textures/*`.
Full registry (use + path + remaining TODOs): `IMAGE_USE_MAP.md`.

## 7. Open questions for owner

1. What does "finish the game" mean concretely — which NEW systems first? (Candidates:
   new quest theaters, turret/vehicle play, co-op?, new enemy types/weapons?)
2. D1 (module macro) + D2 (UMG fate) — see BUG_REGISTER §B.

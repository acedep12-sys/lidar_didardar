# SquadAI — Texture Use Map + art deliverables (updated 2026-09-10, mega-10 AAA)

Finished art now ships BOTH as files (`art/*.png`, 13 PNGs) and in this registry list
(owner order 2026-09-10 superseded the old no-images rule). Everything else below is the
authoritative list of every texture the code uses, what it is for, and where to install it.

- **Install:** copy PNGs → `<Project>/Content/Textures/` (auto-imports to `/Game/Textures/*`
  via `DefaultEditorPerProjectUserSettings.ini` directory monitoring). Loose-PNG fallback also
  checks `SquadAI/Content/Textures/`, project root, and plugin dirs (`LoadTextureSafe`).
- **Total: 60 unique PNGs** — 57 manifest + 3 code-only (`Menu_Background_NightOperations`,
  `HUD_Weapon_Fist`, `HUD_Health_Card`).
- **Delivered in `art/`:** fist, health card, dog tag, 4 difficulty cards (AAA cinematic set with baked tactical borders, correct weapon orientation), main-menu KhuzestanDesertWar (AAA rostami commander), night-ops, progression, armory, medals (spotlit velvet), loading (flare night) — each ✅ below; era-checked, zero Latin, correct G3/RPG orientation, high-contrast saturated AAA grading.
- **Era direction (binding):** 1980–88 Iranian side — steel helmets/keffiyehs/plain headbands/
  G3s/canvas webbing/palms/turquoise dome/red tulip/Persian script/red crescent; zero readable
  Latin, zero Western/WWI/US vibes; wallet closed with zero contents.

## 1. Frames, buttons, bars (procedural — generator script)

| Filename | Resolution | Used by | Use |
|---|---|---|---|
| UI_Frame_TacticalBorder_Gold.png | 1536×1024 | MainMenuHUD, MenuSetupActor | ✅ in `content/texture/` — **separate 3D beveled** gold border (PBR brass, not baked into cards) — drawn via `DrawChiseledTacticalPanel` 9-slice or `FrameTacticalGoldTexture` |
| UI_Frame_TacticalBorder_Crimson.png | 1536×1024 | MainMenuHUD, MenuSetupActor | Crimson alert border for active-combat status cards |
| UI_Frame_Badge_Hexagon.png | 1024×1024 | MainMenuHUD, MenuSetupActor | Hex socket frame for trait icons / medals (3D beveled, separate asset) |
| UI_Frame_MedalSocket.png | 512×512 | MainMenuHUD | ✅ in `content/texture/` — **separate 3D beveled** circular medal socket (brass rim, dark recess) — new honors system, not baked |
| UI_Frame_Avatar_Portrait.png | 1024×1536 | MainMenuHUD, MenuSetupActor | Dossier ID frame for soldier avatars |
| UI_Frame_Tactical_PauseCard.png | 1024×1024 | MainMenuHUD, QuestNativeHUD, MenuSetupActor | Modal pause-menu frame |
| UI_Frame_MapTheater.png | 1536×1024 | MainMenuHUD, MenuSetupActor | Map/theater card border |
| UI_Button_Tactical_Normal.png | 512×128 | MainMenuHUD, QuestNativeHUD | Default tactical button plate |
| UI_Button_Tactical_Hover.png | 512×128 | MainMenuHUD, QuestNativeHUD | Hover/active button state |
| UI_LoadingBar_Frame.png | 512×64 | MainMenuHUD, QuestNativeHUD | Progress bar housing |
| UI_LoadingBar_Fill.png | 512×64 | MainMenuHUD, QuestNativeHUD | Amber segmented progress fill |
| UI_Progression_UpgradeBar.png | 512×128 | MainMenuHUD, MenuSetupActor | Segmented doctrine-upgrade meter |
| UI_Military_Watermark_Emblem.png | 1024×1024 | MainMenuHUD, MenuSetupActor | Faint heraldic veil behind menu panels (girih-star redo) |

## 2. Key-art backgrounds & screens (AI)

| Filename | Resolution | Used by | Use |
|---|---|---|---|
| Menu_Background_KhuzestanDesertWar.png | 1920×1080 | MainMenuHUD, MenuSetupActor | ✅ in `art/` — **AAA rostami** commander pointing, dust storm, burning armor, volumetric golden hour (your ref, high-contrast) |
| Menu_Background_NightOperations.png | 1920×1080 | MenuSetupActor | ✅ in `art/` — night trench raid under parachute flares |
| Loading_Background_TrenchAssault.png | 1920×1080 | QuestNativeHUD, MenuSetupActor, LoadingScreenSubsystem | ✅ in `content/texture/` — **REPLACED** realistic flare trench (soil/mud, net helmets, soulful faces, not soulless CGI) |
| UI_Background_Medals.png | 1920×1080 | MainMenuHUD, MenuSetupActor | ✅ in `content/texture/` — **REPLACED clean** deep emerald velvet + embroidered tulip, **no baked sockets** — separate `UI_Frame_MedalSocket.png` system for exact icon placement (see §12) |
| UI_Background_Progression.png | 1920×1080 | MainMenuHUD, MenuSetupActor | ✅ REDONE in `art/` — field desk, Persian paperwork (was Latin scribble) |
| UI_Background_Armory.png | 1920×1080 | MainMenuHUD, MenuSetupActor | ✅ REDONE in `art/` — G3 rifle racks (was AK racks) |
| UI_Player_Progression_Art.png | 1920×1080 | MainMenuHUD, MenuSetupActor | Progression relics banner (chafiyeh, dog tag, compass) |

## 3. Doctrine emblems (AI)

| Filename | Resolution | Used by | Use |
|---|---|---|---|
| UI_Progression_Leadership.png | 1024×1024 | MainMenuHUD | Leadership doctrine card |
| UI_Progression_Marksmanship.png | 1024×1024 | MainMenuHUD | Marksmanship doctrine card |
| UI_Progression_Endurance.png | 1024×1024 | MainMenuHUD | Endurance/first-aid doctrine card |
| UI_Progression_Tactics.png | 1024×1024 | MainMenuHUD | Irregular-tactics doctrine card |
| UI_Progression_Engineering.png | 1024×1024 | MainMenuHUD | Engineering doctrine card |

## 4. Difficulty cards (AI, vertical 9:16)

| Filename | Resolution | Used by | Use |
|---|---|---|---|
| UI_Diff_Recruit.png | 768×1344 | MainMenuHUD, MenuSetupActor | ✅ in `content/texture/` — **borderless**, soulful gaze at camera, G3 barrel-forward, sunrise (no baked border — border drawn 3D via code) |
| UI_Diff_Regular.png | 768×1344 | MainMenuHUD, MenuSetupActor | ✅ in `content/texture/` — **borderless**, soulful gaze, G3A3 barrel-forward, sandbag advance |
| UI_Diff_Hardened.png | 768×1344 | MainMenuHUD, MenuSetupActor | ✅ in `content/texture/` — **borderless**, soulful weary eyes, RPG warhead-forward (better than previous soulless per feedback) |
| UI_Diff_Lethal.png | 768×1344 | MainMenuHUD, MenuSetupActor | ✅ in `content/texture/` — legendary soldier, borderless |

## 5. Theater & map previews (AI)

| Filename | Resolution | Used by | Use |
|---|---|---|---|
| Map_Preview_Dehlavieh_Karkheh.png | 1920×1080 | MainMenuHUD, MenuSetupActor, ProgressionSubsystem | Active theater card (trenches, berms, armor) |
| Map_Preview_Bostan_Chazzabeh.png | 1920×1080 | MainMenuHUD, MenuSetupActor, ProgressionSubsystem | Marshes theater card (dunes, waterways) |
| Map_Preview_Khorramshahr_Arvand.png | 1920×1080 | MainMenuHUD, MenuSetupActor, ProgressionSubsystem | Urban-defense theater card (palms, streets) |

Owner-made; if any shows "empty iron", the Output Log names the missing file (G-9 diagnostic).

## 6. Period weapon previews (AI)

| Filename | Resolution | Used by | Use |
|---|---|---|---|
| Weapon_Preview_G3A3.png | 1536×1024 | MainMenuHUD, MenuSetupActor, ProgressionSubsystem | Armory card: G3A3 on trench sandbags |
| Weapon_Preview_AK47.png | 1536×1024 | MainMenuHUD, MenuSetupActor, ProgressionSubsystem | Armory card: AK-47 on ammo crate |
| Weapon_Preview_RPG7.png | 1536×1024 | MainMenuHUD, MenuSetupActor, ProgressionSubsystem | Armory card: RPG-7 + PG-7V in trench |
| Weapon_Preview_MG3.png | 1536×1024 | MainMenuHUD, MenuSetupActor, ProgressionSubsystem | Armory card: MG3 on bipod in bunker |
| Weapon_Preview_SVD.png | 1536×1024 | MainMenuHUD, MenuSetupActor, ProgressionSubsystem | Armory card: SVD + PSO-1 in hide |

Owner-made (do NOT recreate); UI restyled around them (168px rows + widescreen showcase).

## 7. Soldier avatars (AI)

| Filename | Resolution | Used by | Use |
|---|---|---|---|
| UI_Avatar_ShahidRostami.png | 1024×1024 | MainMenuHUD, MenuSetupActor | Hero commander portrait (helmet, keffiyeh) ✅ redone |
| UI_Avatar_YoungBasiji.png | 1024×1024 | MainMenuHUD, MenuSetupActor | Young Basij volunteer (crimson headband) |
| UI_Avatar_ArteshParatrooper.png | 1024×1024 | MainMenuHUD, MenuSetupActor | 55th Airborne paratrooper (maroon beret) |
| UI_Avatar_GuerrillaHunter.png | 1024×1024 | MainMenuHUD, MenuSetupActor | IRGC irregular / tank hunter (RPG) |

Owner-made (do NOT recreate).

## 8. Trait badges (procedural — generator script)

| Filename | Resolution | Used by | Use |
|---|---|---|---|
| UI_Trait_TankDestroyer.png | 512×512 | MainMenuHUD, MenuSetupActor | RPG piercing armor plate |
| UI_Trait_HeavyCaliber.png | 512×512 | MainMenuHUD, MenuSetupActor | 7.62mm cartridge + shockwaves |
| UI_Trait_DesertReliability.png | 512×512 | MainMenuHUD, MenuSetupActor | Sandstorm vortex + bolt carrier |
| UI_Trait_AreaSuppression.png | 512×512 | MainMenuHUD, MenuSetupActor | MG muzzle + tracer barrage |
| UI_Trait_SilentMarksman.png | 512×512 | MainMenuHUD, MenuSetupActor | PSO-1 reticle + turret ring |

## 9. In-game HUD weapon silhouettes (procedural — generator script, except fist/card)

| Filename | Resolution | Used by | Use |
|---|---|---|---|
| HUD_Weapon_G3A3.png | 512×256 | QuestNativeHUD | Top-right status plate icon |
| HUD_Weapon_AK47.png | 512×256 | QuestNativeHUD | Top-right status plate icon |
| HUD_Weapon_RPG7.png | 512×256 | QuestNativeHUD | Top-right status plate icon |
| HUD_Weapon_MG3.png | 512×256 | QuestNativeHUD | Top-right status plate icon |
| HUD_Weapon_SVD.png | 512×256 | QuestNativeHUD | Top-right status plate icon |
| HUD_Weapon_Unarmed.png | 512×256 | QuestNativeHUD | Knife/unarmed plate icon |
| HUD_Weapon_Fist.png | 512×256 | QuestNativeHUD | ✅ in `art/` — full-color fist (replaces mono stock; code warm-tint now just grades it — if too orange in-engine, remove the tint line at QuestNativeHUD ~1861) |
| HUD_Health_Card.png | 256×256 | QuestNativeHUD | ✅ in `art/` — red-crescent health card badge (drawn 22×20) |

## 10. Inventory & memorial items (AI)

| Filename | Resolution | Used by | Use |
|---|---|---|---|
| UI_Item_PocketQuran.png | 1024×1024 | QuestNativeHUD, MenuSetupActor | Pocket Quran (gilded green leather) ✅ authentic, kept |
| UI_Item_PocketRadio.png | 1024×1024 | QuestNativeHUD, MenuSetupActor | 1980s transistor radio ✅ authentic, kept |
| UI_Item_CombatWallet.png | 1024×1024 | QuestNativeHUD, MenuSetupActor | CLOSED plain leather wallet, zero contents ✅ redone |
| UI_Item_FirstAidPouch.png | 1024×1024 | QuestNativeHUD, MenuSetupActor | Canvas pouch, RED CRESCENT ✅ redone |
| UI_Item_Canteen.png | 1024×1024 | QuestNativeHUD, MenuSetupActor | Aluminum canteen, canvas cover ✅ redone |
| UI_Item_DogTag.png | 1024×1024 | QuestNativeHUD, MenuSetupActor | ✅ REDONE in `art/` — blank brushed-steel tag, zero legible marks (replaces stale local copy) |
| UI_FallenNotes_Background.png | 1024×1024 | QuestNativeHUD, MainMenuHUD, MenuSetupActor | Fallen-notes parchment, Persian script ✅ redone |

## 11. Console / diagnostics

- `SquadAI.CheckAssets` / `CheckAssets` / `AuditTextures` / `AuditGameAssets` → log tag
  `[SQUADAI_ASSET_AUDIT]` shows found vs missing textures in the Output Log.
- Missing-file behavior: `LoadTextureSafe` returns nullptr; every draw site has a procedural
  fallback — the game never visibly breaks on missing art.

## 12. Art status (mega-11 — 15 PNGs, 32 MB — borderless + separate 3D frames + soulful gaze + fixed orientation)

| Asset | Status |
|---|---|
| Full-color fist (beautiful, NOT modern) | ✅ DELIVERED `art/HUD_Weapon_Fist.png` → install as `Textures/HUD_Weapon_Fist.png` |
| Difficulty AAA borderless soulful set (saturated, high-contrast, **no baked borders**, correct G3/RPG forward, gaze at camera) | ✅ **REPLACED borderless** `content/texture/UI_Diff_Recruit.png` + `Regular.png` + `Hardened.png` (Lethal kept borderless) — previous baked-border versions deleted per your "separate 3D beveled" order; Hardened you rated best kept as base for others |
| Main-menu key art AAA (rostami) | ✅ `content/texture/Menu_Background_KhuzestanDesertWar.png` (your rostami ref, 2.2 MB, volumetric dust, golden hour) → `Textures/Menu_Background_KhuzestanDesertWar.png` |
| Separate 3D beveled frames (not baked) | ✅ `content/texture/UI_Frame_TacticalBorder_Gold.png` (1.7 MB PBR) + `UI_Frame_MedalSocket.png` (2.0 MB) — drawn via `DrawChiseledTacticalPanel` 9-slice: drop shadow + highlight + pinstripe + bevel (Unreal Canvas `DrawRect`/`DrawLine` + `LoadTextureSafe` 9-slice) |
| Health card (pretty version) | ✅ DELIVERED `art/HUD_Health_Card.png` → install as `Textures/HUD_Health_Card.png` |
| ID tag (proper metal, no legible marks) | ✅ DELIVERED `art/UI_Item_DogTag.png` → install as `Textures/UI_Item_DogTag.png` |
| Night-ops menu background | ✅ DELIVERED `art/Menu_Background_NightOperations.png` → install as `Textures/Menu_Background_NightOperations.png` |
| Progression background redo (Persian) | ✅ DELIVERED `art/UI_Background_Progression.png` → install as `Textures/UI_Background_Progression.png` |
| Armory background redo (G3 racks) | ✅ DELIVERED `art/UI_Background_Armory.png` → install as `Textures/UI_Background_Armory.png` |
| Medals clean (no baked sockets) | ✅ **REPLACED** `content/texture/UI_Background_Medals.png` — deep emerald + tulip only; **new separate system**: code draws `UI_Frame_MedalSocket.png` (or procedural fallback) around each achievement icon for exact placement (see `DrawAchievementsScreen` MEGA-11) |
| Loading realistic soulful | ✅ **REPLACED** `content/texture/Loading_Background_TrenchAssault.png` — muddy trench, net helmets, soulful faces, warm flare vs cool night, not soulless CGI |
| Map previews / weapons / avatars | Owner-made — install only (never recreate without asking) |
| Notes art | Per-note drop-in: `Textures/Notes/<NoteN or ImageFile>.png`, or set `NoteN_Image` in INI |


## 13. Patch 2026-09-12 — AAA main menu foundation assets

Delivered as real PNG files in `Content/Textures/` and mirrored to `art/`:

| Filename | Resolution | Purpose |
|---|---:|---|
| `UI_Frame_TacticalBorder_Gold.png` | 1536×1024 | Transparent-center 9-slice brass/cobalt/turquoise Persian micro-border for normal panels |
| `UI_Frame_TacticalBorder_Crimson.png` | 1536×1024 | Transparent-center 9-slice crimson alert frame for danger/active combat panels |
| `UI_Frame_MedalSocket.png` | 1024×1024 | Circular transparent-center Khatam/Girih medal socket |
| `UI_Button_Tactical_Normal.png` | 512×128 | Dark tactical button plate |
| `UI_Button_Tactical_Hover.png` | 512×128 | Warm highlighted tactical button plate |
| `UI_LoadingBar_Frame.png` | 512×64 | Loading/progress frame |
| `UI_LoadingBar_Fill.png` | 512×64 | Segmented amber loading fill |
| `HUD_Health_Card.png` | 256×256 | Red Crescent health-card icon |
| `HUD_Weapon_Fist.png` | 512×256 | Warm full-color fist icon |

Code integration: `ASquadAIMainMenuHUD::DrawNineSliceFrame` + `DrawChiseledTacticalPanel` overlay (`AAA-MM-4`).

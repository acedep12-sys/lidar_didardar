# Install — AAA Main Menu UI Patch 2026-09-12

This package implements the owner request:

1. **Ignore UMG** for the main menu.
2. **Restructure/recreate the main menu** into a more AAA command-deck style.

## Copy paths

From this package:

- `Source/SquadAI/` → your local Unreal project: `<YourProject>/Source/SquadAI/`
- `Content/Textures/*.png` → your local Unreal project: `<YourProject>/Content/Textures/`

Then regenerate Visual Studio project files if needed and build the editor target.

## Verify in UE 5.7

1. Launch the main menu map.
2. Confirm no legacy UMG menu appears.
3. Confirm the main menu uses the new structure:
   - left Operations Command Deck,
   - right Commander Dossier / Tactical Intel Card,
   - bottom utility rail.
4. Run console command `SquadAI.CheckAssets` and search for `[SQUADAI_ASSET_AUDIT]`.
5. Click every main screen button to confirm the old actions still route correctly.

## Edited code markers

Search for:

- `AAA-MM-1` — ignore/remove legacy UMG main menu at Canvas draw time.
- `AAA-MM-2` — rebuilt cinematic header strip.
- `AAA-MM-3` — rebuilt telemetry pill.
- `AAA-MM-4` — transparent-center 9-slice frame support.
- `AAA-MM-5` — rebuilt main menu screen layout.

## Static validation

The workspace validator passed after edits:

```text
Scanning 230 files (111 cpp, 119 h)...
Zero brace issues found across all files!
Zero paren issues found across all files!
```

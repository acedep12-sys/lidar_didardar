# Pass 3 — Player / squad combat, health, revive, inventory, and respawn

Last updated: 2026-09-21  
Repository commit inspected: `1578dfb276d153cfac960d41275273339a0484a9`  
Source studied: `extracted/source-full/Source/SquadAI/`  
Code changes made: **none**

## 1. Scope and confidence boundary

This pass traced the native combat loop from firing and environment damage through health, pack-health mirroring, downed/revive behavior, consumables, grenade ownership, player death, mission retry, and enemy recycling.

The host TPWCS Blueprint implementation is not present. Conclusions about native C++ control flow are definite. Any conclusion involving what `HI_TakeDamage`, `BPC_Health*`, or the host weapon Blueprint does internally is an integration risk rather than a proven runtime result.

## 2. Executive model

There are not just two combat paths. The current module has several partially overlapping paths:

1. **Native AI weapon path** — `UWeaponComponent::PerformHitscan` finds a native `UHealthComponent` and calls `ApplyExternalDamage` directly.
2. **Player bridge path** — `USquadAIPlayerCombatBridge` polls firing state and performs its own camera trace every 0.1 seconds; native soldiers receive direct `UHealthComponent::ApplyDamage`, while pure pack actors have reflected health properties written directly.
3. **Standard Unreal damage path** — radial damage and some generic hits call `AActor::TakeDamage`; `ASoldierCharacter::TakeDamage` routes once into native health.
4. **Explicit pack-forwarding path** — Blueprints can call `USquadAIPackBridgeLibrary::ForwardPackDamageToSquadAI`, which invokes `NotifyPackDamage` and the native health chokepoint.
5. **Pack-health polling path** — pack health is sampled every 0.15 seconds for heroes or 0.5 seconds for other pack-presented soldiers; downward deltas are replayed into native health.
6. **Direct environment paths** — fire and scripted barrages directly modify native health or reflected pack health.

`UHealthComponent::ApplyDamage` is the intended native policy authority. It owns faction filtering, grace periods, leader immortality, downed/death transitions, health events, and native HUD damage notification. However, direct writes to pack health and several reflected integrations bypass some or all of these policies.

## 3. Native-damage duplication audit

### Conclusion

**The current C++ paths do not inherently apply one ordinary Unreal damage event twice to an `ASoldierCharacter`'s native `UHealthComponent`.**

The reason is important:

- `ASoldierCharacter::TakeDamage` does **not** call `Super::TakeDamage`.
- It calls `HealthComp->ApplyDamage` itself and returns.
- Because the base implementation is skipped, Unreal's normal `ReceiveAnyDamage`, point/radial receive events, `OnTakeAnyDamage`, `OnTakePointDamage`, and `OnTakeRadialDamage` broadcasts are also skipped.
- Although `BeginPlay` binds `ASoldierCharacter::OnAnyDamageReceived` to `OnTakeAnyDamage`, no native module code broadcasts that actor delegate for soldiers. That handler is therefore normally inert for standard damage routed through this override.
- `UHealthComponent::ApplyExternalDamage` broadcasts its own `OnExternalDamageReceived`, not the actor's `OnTakeAnyDamage`, so it also does not re-enter `OnAnyDamageReceived`.

Thus the unresolved suspicion from the initial trace is resolved: the ordinary native soldier loses health once, not twice.

### The opposite problem

Skipping `Super::TakeDamage` suppresses Unreal/Blueprint damage contracts. Blueprint `AnyDamage`, point-damage, radial-damage reactions, and external listeners on the actor will not run for `ASoldierCharacter`. The bound native `OnAnyDamageReceived` comment says it catches all damage, but under the current override it does not.

This matters especially because that inert handler contains the claimed same-frame pack-health clamp for leaders and allies. Pack-side one-shot protection is therefore dependent on either an external manual delegate broadcast or the later 0.15-second polling clamp.

### Host-player duplication remains host-dependent

`UWeaponComponent::ApplyTPWCSPlayerDamage` deliberately touches both native and pack layers:

- native soldier: one `TakeDamage` call, then pack `HI_TakeDamage` or a reflected pack-health fallback;
- non-soldier pawn with native `UHealthComponent`: direct native health, one actor `TakeDamage`, then pack damage;
- pack bridge baseline is re-synchronized afterward to prevent the next poll from replaying the same pack delta.

For a non-soldier host pawn, whether its `TakeDamage` implementation already routes into TPWCS is unknowable without the host source/Blueprints. If it does, the additional explicit `HI_TakeDamage` call can still double the **pack-side** damage.

The helper also manually calls `HUD->NotifyDamageReceived` after native health has already done so, so native player pawns can receive duplicate directional-hit/vignette notifications even though their native HP is not doubled.

## 4. Incoming damage and policy behavior

| Source | Native soldier route | Pack actor route | Important consequences |
|---|---|---|---|
| Native AI rifle | Direct `ApplyExternalDamage` | player special helper | Single native hit, but direct native route does not emit `UAISense_Damage` |
| Player bridge rifle | Direct `ApplyDamage` | direct reflected property write | Independent fixed-rate damage model; bypasses actor hit metadata and pack damage events |
| Grenade / mortar / barrel | Unreal radial damage -> `TakeDamage` | host-dependent Unreal damage handling | Native hit is single; attribution/friendly-fire depends on causer/instigator identity |
| Fire zone | Direct native `ApplyDamage` | direct reflected property write | Bypasses pack damage events/interface |
| Path barrage | Direct native `ApplyDamage` | standard damage plus reflected subtraction | Non-native pack pawn can potentially be damaged once by its standard handler and again by the explicit property subtraction |
| TPWCS pack health loss | Poll delta -> native `ApplyDamage(Damage, nullptr)` | pack is already changed | Source attribution is lost; native friendly-fire/player-credit/grace rules cannot identify the shooter |
| Explicit Blueprint bridge | `NotifyPackDamage` -> `ApplyExternalDamage` | n/a | Preserves native policy and emits AI damage sense |

### Attribution loss in pack polling

The polling bridge passes `nullptr` as damage causer. This has several effects:

- same-faction rejection cannot run;
- player attribution cannot run;
- directional player-hit indicators cannot identify a source;
- enemy spawn grace treats the damage as non-player damage and rejects it;
- the poll still updates `LastPackHealth`, so rejected pack damage is not replayed later.

A particularly fragile case is a player shot that reduces a pack-presented native enemy's pack HP during its 14-second arrival grace. Native health rejects the causeless mirrored delta as non-player damage, while pack health remains reduced. The two authorities can diverge permanently or the pack can run its own death sequence while native health still says alive.

### Grace mismatch in the special player helper

For a native player carrying both native and pack health, `TakeDamage` can reject native damage during spawn grace, but `ApplyTPWCSPlayerDamage` still invokes the pack damage function and re-baselines the pack bridge. Native grace therefore does not guarantee pack-side grace.

### Friendly fire

Direct native rifle paths generally preserve faction filtering because the causer resolves to an `ASoldierCharacter`.

Grenades spawned by a native soldier carry an instigator, and the health resolver can follow that instigator back to the soldier. Grenades thrown by the actual host player pawn do not count as friendly if that pawn is not an `ASoldierCharacter`, so native allies can still be damaged by host-player grenades.

Mortar barrage actors are spawned without an owner or instigator. Their radial damage is effectively unattributed environmental damage: fresh enemies reject it during arrival grace, while allies can be damaged after their initial grace expires. This may be intended artillery friendly fire, but it is inconsistent with the module's general no-friendly-fire policy.

## 5. Native AI weapon loop

`UWeaponComponent` is an AI-oriented hitscan weapon with:

- burst sequencing and cooldown;
- spread, falloff, damage multipliers, suppression, barrel heat, and limited material penetration;
- logical AI muzzle support and a muzzle-visibility gate;
- a SoldierRegistry ray pass to hit native soldiers even when their mesh/capsule does not block `ECC_Visibility`;
- a broad local-player ray-proximity fallback when the host pawn is not trace-blocking.

Notable behavior:

- `CurrentClipAmmo` and `ReserveAmmo` are display/loadout fields; `FireAtTarget` does not consume them or reload. AI fire is effectively unlimited.
- Registry soldier hits use a 95 cm body-point radius; the player fallback uses 150 cm. These are forgiving proxy hit volumes, not exact mesh/capsule hits.
- Native target damage uses `ApplyExternalDamage` directly and does not call `ASoldierCharacter::TakeDamage`, so it skips hit-bone capture, hit-react montage selection, and `UAISense_Damage` reporting from that override.
- Suppression is still applied along the bullet path, which can make AI react despite the missing damage stimulus.
- Native damage does not generally subtract the attached pack component's current health. Native health is authoritative for native soldiers, and death later sets reflected pack death flags, but pack health bars/state can remain numerically stale.

## 6. Player combat bridge

The combat bridge is auto-attached by the diagnostic subsystem and owns much more than a damage adapter: mortar input, guidance vision, grenade keys, quick medkit keys, pause/inventory keys, infinite-ammo top-up, and the player's custom firing trace.

### Firing model

Every tick it polls either:

1. reflected `BPC_WeaponCharacter.bIsShooting?` / `bIsShooting`, or
2. raw left mouse as fallback.

While firing, it performs one camera trace every `TraceInterval` (default 0.1 s) and applies `DamagePerHit` / `PackDamagePerHit` (default 25) on every successful trace.

Consequences:

- bridge DPS defaults to 250 per second, independent of the selected weapon's fire rate, damage, recoil, pellet count, projectile timing, ammo, or reload state;
- a held left mouse can keep the fallback active even if the pack weapon is empty or the input is being used by another interaction;
- host weapon damage and bridge damage may coexist, so runtime double damage is possible at the **system** level even though native `TakeDamage` itself is not duplicated;
- mounted-turret fire and the same pawn's bridge trace can both run from left mouse, producing two independent weapon hits;
- damage is always from the camera center rather than from the actual fired projectile trajectory.

### Native soldier targets

The bridge calls `HealthComp->ApplyDamage` directly.

This correctly gets leader/downed/death policy, but it does not:

- emit `UAISense_Damage` despite the source comment claiming stimulus parity;
- pass a point-damage event or bone to `TakeDamage`;
- record headshots.

A bridge kill therefore gives the native enemy kill XP through `HandleDeath`, but its headshot flag is false/stale and headshot progression is not credited.

### Pure pack targets

`DamagePackEnemy` and `ApplyDamageViaReflection` subtract `double` or `float` properties directly and manually report an AI damage stimulus. At zero they manually ragdoll a character mesh.

They do not invoke the pack damage interface, pack health/death delegates, pack UI contracts, pack death flags, or a pack-specific despawn flow. Wave-spawner polling does eventually grant Clear-mission death credit and schedule pool release, but:

- kill XP and kill counters are only recorded by native `ASoldierCharacter::HandleDeath`, so pure pack kills do not receive that progression credit;
- no pack headshot credit is possible;
- the pack may continue to consider the actor alive unless it independently watches the reflected property;
- fresh pack enemies at zero HP are intentionally counted alive until 14 seconds after actor creation, delaying wave progress/death recycling for early kills.

## 7. Leader, ally downed state, and revive

### Leader

Leader immortality is enforced at multiple layers:

- early veto in `ASoldierCharacter::TakeDamage`;
- veto in `UHealthComponent::ApplyDamage`;
- pack polling restoration/clamp;
- same-frame clamp code in `OnAnyDamageReceived`;
- final veto in `HandleDeath`.

The native side is strongly protected. The weakest point is an immediate TPWCS pack death sequence that occurs before the 0.15-second poll; the supposed same-frame actor-delegate safeguard is normally bypassed because `TakeDamage` does not call its base implementation.

### Ally downed state

Allies are not permanently killed by native health:

- reaching zero calls `EnterDownedState`;
- logical death remains false, so `IsAlive()` and `CanBeRevived()` remain true;
- movement and combat stop;
- capsule pawn/vehicle responses are ignored;
- the skeletal mesh enters ragdoll;
- the ally stays registered and appears as wounded in the native HUD.

`AAllySoldier::Tick` reduces `BleedoutTimeRemaining` at only 0.1 units per real second and clamps it to a minimum of 15. It never expires, never kills, and never despawns the ally. The HUD nevertheless labels and draws it as a bleedout bar. Starting at 45, it takes five minutes to reach 15 and then stays there forever. This is a presentation timer, not a real bleedout mechanic.

### Revive callers

There are two continuous-progress callers:

- native HUD: player holds E within 220 cm;
- `FSTTask_FollowLeader`: any follower within 2,500 cm prioritizes a downed ally, moves within 180 cm, then contributes progress.

A ground first-aid actor can also call `CompleteRevive` immediately, though in ordinary play it only operates on the overlapping player pawn, not a squadmate.

### Revive weaknesses

- `CurrentReviveProgress` never decays or resets when the player releases E, leaves range, or a reviving AI disengages. Partial progress accumulates across attempts.
- Multiple AI followers, plus the player, can call `ApplyReviveProgress` in the same frame; contributions stack and can make revival much faster than `RequiredReviveTime`.
- The HUD checks distance and screen projection, not line of sight or obstruction.
- `USquadAIProgressionSubsystem::GetReviveSpeedMultiplier` has no callers, so the Field Revive Speed upgrade has no effect.
- `RecordTriageRevive` also has no callers, so revive XP, HeroicMedic progress, and triage statistics are never awarded by `CompleteRevive`.
- `AlliesRevived` is displayed by the profile UI but has no writer in the module.

`CompleteRevive` itself is comprehensive: it revives native and pack health, clears pack death flags, cancels lifespan, restores capsule/mesh physics and visibility, reinitializes animation, restarts StateTree, restores speed, resets spawn grace, and re-registers systems.

### Initial ally health mismatch

`UHealthComponent::BeginPlay` fills current health from the then-current max (normally 100). `AAllySoldier::BeginPlay` later sets `MaxHealth = 150` but does not increase current health. Without a Blueprint/CDO override that already sets 150, allies begin at approximately 100/150 (66.7%).

## 8. Consumables and inventory ownership

### Three health-use paths

1. **Quick kit (4 or 5)** in the player bridge: consumes one inventory kit only when native or reflected pack health was actually below max; native health uses `Heal`, pack health is directly set to max.
2. **Ground `AFirstAidKitActor`**: can heal/revive immediately and can also add one kit to inventory when stock is below five.
3. **`AMedicalStationActor`**: restores current health directly and starts a cooldown.

Integration weaknesses:

- default full healing in `AFirstAidKitActor` directly assigns native `CurrentHealth`, bypassing `OnHealthChanged`;
- the medical station also directly assigns native health and can set positive HP while `bIsDead` remains true;
- reflected pack healing writes properties directly and does not call a pack heal/reinitialize interface, clear all death flags, or guarantee pack widgets/events update;
- the ground-kit pack branch marks the kit as needed unconditionally once a `BPC_Health` component is found, so a host pack player can consume a ground kit even at full HP with full kit stock;
- a ground kit can both immediately heal the player and bank another inventory kit, which should be confirmed against intended design;
- the medical station consumes its cooldown and broadcasts restoration even if no supported health property was actually changed.

### Dual grenade authorities

Grenade counts live in both:

- `USquadAIInventorySubsystem` (persistent GameInstance owner), and
- `UTacticalGrenadeComponent` (pawn-local owner).

Normal component throws decrement local counts and synchronize the subsystem. Save-load also explicitly synchronizes both.

The combat bridge fallback is unsafe: whenever a grenade component is missing **or `CanThrowGrenade` is false**, it directly spawns a grenade and decrements only the subsystem. Thus a rapid second key press during component cooldown bypasses cooldown and leaves local/subsystem counts inconsistent.

Opening inventory later copies local component counts back into the subsystem. This can restore the grenade consumed by the fallback, effectively duplicating ordnance. The fallback also bypasses the component's throw events, cooldown timestamp, tactical voice line, and local inventory-change event.

The native HUD reads grenade counts from a native soldier's component; for a non-soldier host player it falls back to hardcoded `2 / 2`, not the GameInstance inventory counts.

### Weapon inventory

Native inventory selection edits `UWeaponComponent` display/ammo/damage fields. Host TPWCS selection merely writes a reflected `ActiveWeapon`/`CurrentWeapon` string or name; it does not invoke a known equip function, so success means “property found and written,” not necessarily “pack weapon actually equipped.”

## 9. Grenades, mortar, and environment

### Fragmentation grenade

A frag uses Unreal radial damage with falloff, emits hearing stimulus, applies physics impulse and suppression, and then destroys itself.

For native soldiers it reaches the single `TakeDamage` route. For pure pack actors it depends on the host's standard damage integration; unlike rifle fire, there is no TPWCS interface/reflection fallback. If the host pack ignores standard Unreal damage, frag grenades will not damage pure pack enemies.

### Smoke

Smoke registers a timed cloud in `USoldierRegistrySubsystem`; AI sight logic can query it. The actor hides and remains alive until the smoke duration expires.

### Mortar

The player bridge calls a WorldSubsystem which spawns an unattributed barrage actor. Shells use standard radial damage. There is no player/instigator attribution for kill policy, XP, or friendly-fire filtering. Native fresh enemies are also protected from it by the non-player arrival-grace rule.

### Scripted fire/barrage

Fire zones directly subtract native or reflected pack health once per second. Path barrages directly handle native soldiers but, for non-native actors, call standard `ApplyDamage` and then explicitly subtract reflected pack health. If the host actor's standard damage path already changes that same pack health, the barrage can double-damage the pack pawn.

## 10. Player death and mission retry

Player death handling is owned by the currently active `AMissionZone`, not by a gameplay GameMode.

### Native player

An active mission binds to native `HealthComp->OnDeath`. A 2026-10-05 source audit found and patched an Ally-faction edge case: before the patch, a player-controlled `ASoldierCharacter` with `bCanBeDowned=true` could enter downed state without broadcasting `OnDeath`, while `HandleDeath()` handled Ally before player control. The mission had no native poll fallback in that branch. Current source excludes possessed Soldiers from downed-on-lethal routing, handles player control before the ally-downing branch, retries binding when the pawn appears late, and schedules recovery if binding discovers an already-dead/downed pawn. Runtime still depends on the actual possessed class/faction; `ALeaderCharacter` remains intentionally immortal.

For a non-leader native player, `HandleDeath()` stops combat/movement without corpse destruction and the mission revives/repositions the existing pawn. Respawn now clears full Soldier downed/ragdoll state through `CompleteRevive()`, restores every skeletal mesh and player input, reapplies spawn grace, and resets health/ammo.

### Host pack player

The mission polls every 0.15 seconds for a component whose **instance name** contains `BPC_Health` and an exact lowercase `currentHealth` float/double property. If the pack destroys/replaces the pawn, renames the component/property, or uses an integer, native death detection can fail.

The 2026-10-05 source correction makes mission `RestorePackHealth` support common float/double/integer health fields and clear pack death flags on the pawn/components, including the literal TPWCS `bIsDead?` property. It still uses reflected writes and does not call `HI_ReinitializeHealth`; if the host Blueprint requires its own health-reinitialization event to restore presentation, PIE must confirm whether another reset is needed.

### Retry semantics

Default flow (`bFailMissionOnPlayerDeath = true`, chain `bRestartChainOnFailure = false`):

1. immediately revive/reposition player;
2. fail current mission;
3. broadcast `OnChainFailed`;
4. reset mission and spawners;
5. reactivate the same mission after one second.

There is no native game-over screen or forced level restart. Any such presentation must be a Blueprint listener.

The default failure route revives only the player, not the squad. Downed allies remain downed across the mission retry. In contrast, the legacy `bFailMissionOnPlayerDeath = false` path calls `RestartCurrentAttempt`, which invokes `RespawnSquad`; the 2026-10-05 correction now uses `CompleteRevive()` for any downed Soldier placed by that respawn helper.

Outside an active MissionZone there is no module-level player-death recovery owner.

## 11. Enemy death and pool lifecycle

Native enemy death correctly handles kill progression, cinematic notification, controller/StateTree stop, ragdoll, pack death flags, and a 10-second actor lifespan. The wave spawner separately schedules pool release after `CorpseLingerSeconds` (default 8 seconds).

The pool's reset contract is incomplete and is one of the highest static risks found in this pass:

1. `UEnemyPoolSubsystem::WakeEnemy` does not call `SetLifeSpan(0)`. A native enemy released at 8 seconds still has the 10-second death lifespan and can be destroyed roughly two seconds after being reacquired.
2. Sleep/wake resets native `UHealthComponent`, but does not reset reflected pack current/max health, `bIsDead?`/death flags, `LastPackHealth`, or pack presentation.
3. A pure pack enemy killed by direct property write is released with pack HP still zero, then can be reacquired still dead. The spawner masks it as alive only during the actor-age grace window.
4. `ResetSpawner` destroys active pawns, including pooled pawns, instead of releasing them. Pool entries then hold invalid weak pointers.
5. `GetAvailableCount` counts `bAvailable` without checking pawn validity, so invalid entries can prevent prewarm top-up. `Acquire` skips them, causing permanent fallback to direct spawning.

The intended zero-allocation pool therefore degrades after deaths/retries and can destroy a recycled live enemy mid-wave.

## 12. Priority findings before modification

### Critical / high

1. **Pool lifecycle is not reusable safely** — pending lifespan, pack-death state, invalid-entry counting, and reset destruction break the prewarmed pool contract.
2. **Player bridge is a second weapon authority** — fixed 0.1-second camera hits are disconnected from actual shot/ammo cadence and can coexist with host or turret damage.
3. **Pack polling loses attribution** — player/friendly/grace policy can reject or misclassify mirrored damage while still accepting the changed pack baseline.
4. **Pack death/heal/respawn still uses direct property writes** — mission recovery now clears common death flags including `bIsDead?`, but does not dispatch host events or `HI_ReinitializeHealth`; verify host presentation in PIE.
5. **Grenade fallback bypasses cooldown and desynchronizes inventory**, allowing ordnance restoration when inventory is opened.

### Medium

6. `ASoldierCharacter::TakeDamage` suppresses Unreal/Blueprint damage delegates by not calling `Super`.
7. Native direct weapon/player-bridge damage skips `UAISense_Damage`; comments claiming stimulus parity are inaccurate.
8. Pure pack kills receive mission clear credit but no native kill/headshot progression.
9. Revive progression accumulates, stacks across revivers, and ignores the revive-speed upgrade; revive progression/XP counters are disconnected.
10. Allies normally begin at 100/150 health.
11. Default mission-failure retry revives only the player, not downed squadmates.

### Lower / design confirmation

12. Ally “bleedout” never expires, while the HUD presents it as a countdown bar.
13. Ground first-aid kits can both heal and bank a kit.
14. Non-soldier host HUD grenade display defaults to hardcoded 2/2.
15. AI `UWeaponComponent` ammo fields do not constrain firing.

## 13. Recommended verification order in the real project

Before changing code, verify these in PIE with logs/video:

1. Shoot one native enemy once with the host weapon and record native HP, pack HP, actor AnyDamage events, and resulting DPS.
2. Hold fire with an empty magazine and determine whether the player bridge still damages enemies.
3. Mount the turret and test whether the bridge and turret both deal damage per left-click hold.
4. Damage a pack-presented enemy during its first 14 seconds and compare native/pack HP.
5. Kill and recycle one pooled native enemy; reacquire it before 10 seconds and watch for mid-wave destruction.
6. Recycle a pure pack enemy and inspect pack HP/death flags on the second life.
7. Die as the TPWCS player during an active mission and inspect `bIsDead?`, mesh visibility, possession, movement, and pack HUD after respawn.
8. Throw two grenades rapidly inside cooldown, open inventory, and compare component/subsystem/HUD counts.
9. Partially revive, release E, walk away, return, and test whether progress persisted.
10. Revive with two AI allies nearby and measure stacking; check XP/achievement/profile counters.
11. Test frag and mortar damage against native allies, native enemies, and pure pack enemies.

## 14. Pass conclusion

The intended native combat architecture is understandable and mostly centralized: native health policy is in `UHealthComponent`, native death in `ASoldierCharacter`, and mission retry in `AMissionZone`. The main complexity comes from duplicated **authorities**, not duplicated calls to one native health function: host pack health, native health, the automatic player trace, host weapon behavior, and direct reflected property writes can all be active at once.

No source changes should be made until the real-project verification determines which host weapon/health paths actually fire. The safest future direction is to select one authoritative damage event per shot, carry source/instigator/bone metadata through it, mirror presentation state only after the authoritative result, and make pool wake/reset restore every native and pack-side lifecycle field symmetrically.

# S19 — Batch 1: build fixes, lint, tutorial feel, grenade lesson, menu

*Applies to `source/SquadAI` (UE 5.7.4). Tag: `S19-`.*
**No compiler was available in this session — everything here is a static
edit, verified with `tools/squadai_lint.py` (0 errors) and a brace/ paren
balance check on every file touched.**

---

## 0. First, the important discovery

The previous session's report (`S18E_ERRORS_FIXES_RECOMMENDATIONS.md`) claims
its fixes were **"fixed"** and even gives `findstr` counts to verify them.
**None of them were ever written to the files.** Before this batch:

```
grep -rl "S18-COMPILEFIX"  ->  0 files
grep -rl "S18-FIX3"        ->  0 files
grep -rl "S18-FIX4"        ->  0 files
```

and both reported compile errors were still sitting verbatim in
`QuestNativeHUD.cpp` at lines 3616 and 3804. So treat that report as a
description of intent, not of the code you have. Everything below was applied
fresh against the real files.

---

## 1. The two compile errors

| File | Error | Fix |
|---|---|---|
| `Private/HUD/QuestNativeHUD.cpp:3616` | C2664 — `FString::Printf` format was `bEnglish ? TEXT("%d m") : TEXT("%d متر")`. UE 5.7 type-checks `Printf` formats at compile time, so the format must be **one literal**. | `FString::Printf(TEXT("%d %s"), Metres, bEnglish ? TEXT("m") : TEXT("متر"))` |
| `Private/HUD/QuestNativeHUD.cpp:3804` | C2039 — `AlertBannerText.ToString()`. `AlertBannerText` is an `FString` (declared `QuestNativeHUD.h:442`); `FString` has no `ToString()`. | `AddFeedEntry(AlertBannerText, …)` — `AddFeedEntry` already takes `const FString&`. |

---

## 2. `tools/squadai_lint.py` — new

The earlier report told you to run a lint script **that was never shipped**.
Written from scratch (stdlib only, Python 3.7+).

```bat
"<UE>\Engine\Binaries\ThirdParty\Python3\Win64\python.exe" tools\squadai_lint.py Source\SquadAI
```

Five checks:

| Check | Catches |
|---|---|
| `printf` | non-literal `Printf`/`UE_LOG` formats (the C2664 you just hit); specifier-count mismatch; **`%s` given an `FString` without `*`** (undefined behaviour through varargs) |
| `tostring` | `X.ToString()` where `X` is declared as `FString` (the C2039 you just hit) |
| `braces` | unbalanced braces/parens per file |
| `includes` | duplicate `#include` of the same header |
| `encoding` | mixed line endings, stray non-ASCII in code |

**Baseline on your tree: 0 errors, 16 warnings.** The warnings are the
pre-existing ones (one duplicate include, three `%s` args that are genuinely
`const TCHAR*`, and 11 "declared as both FString and FText in this module —
check by hand"). It is deliberately tuned to over-report rather than miss.

It skips two false-positive classes that cost real time to nail down:
`UE_LOG(..., Format, ...)` inside a `#define` (the literal arrives at the call
site), and bracket characters inside string literals such as
`TEXT("Unlock Weapon (")`.

Mutation-tested: re-introducing your two original errors makes it report
exactly those two lines.

---

## 3. Space key advancing the lesson also made the character jump

**Cause.** The HUD polled `PC->WasInputKeyJustPressed(EKeys::SpaceBar)` inside
`DrawHUD`. `DrawHUD` runs *after* the input stack, so the character's Jump
binding had already fired. `SetIgnoreMoveInput(true)` — what the tutorial used
to "lock" you — only blocks the **movement axes**; Jump and Fire are *action*
bindings and stayed live.

**Fix** (`S19-INPUT`). While a modal card is up, the **pawn's input components
are detached from the controller's input stack**, so the key physically cannot
reach Jump or Fire. Key polling still works (it reads `PlayerController`
state directly), so "press Space to continue" still responds.

New knobs on `USquadAITutorialSubsystem`:

| Property | Default | Meaning |
|---|---|---|
| `bBlockPawnInputDuringCards` | `true` | detach the pawn while a card is up. Turning it off keeps mouse-look alive. |
| `bAllowSpaceToAdvance` | `true` | if the block is off, set this false too and use Enter only. |

Button labels now print the key that is actually accepted
(`Continue  [Space]` / `Continue  [Enter]`).
Release is guaranteed on skip, on finish, on `Deinitialize()`, and in
`EndPlay` — the pawn can never be left detached.

---

## 4. Grenade lesson: unlimited ammo + landing preview

### 4a. Ammo (`S19-TUT`)
`UTacticalGrenadeComponent::bUnlimitedGrenades` (new). The tutorial turns it
on when `Task_Grenade` starts and off the moment it ends, on skip, on finish
and on teardown. The throw cooldown still applies, so it cannot be spammed.

### 4b. Where it will land (`S19-TUT`)
New on `UTacticalGrenadeComponent`:

```cpp
FVector GetThrowOrigin(const FVector& Direction) const;
FVector GetThrowVelocity(const FVector& Direction) const;
FVector GetCurrentThrowDirection() const;
bool PredictThrowPath(const FVector& Direction, TArray<FVector>& OutPath,
                      FVector& OutImpact, bool& bOutImpacted) const;
```

These mirror `ThrowGrenadeInDirection()` **exactly** — same chest-height
origin, same `+50 cm` offset, same `+0.28 Z` launch bias, same world gravity —
so the drawn arc is the arc you get, not an approximation.

`AQuestNativeHUD::DrawGrenadeThrowPreview()` draws it on the canvas:

* a **dotted ballistic arc** from the hand, warm green near the hand fading to
  amber at the far end;
* a **pulsing ring on the ground** at the impact point plus an inner ring and
  a short vertical post, so the point reads even on flat sand;
* the **throw distance in metres** under the ring;
* a short fade in/out so it does not pop.

Canvas-only: no meshes, no Niagara, no materials, and it works in **every**
build (unlike `DrawDebug*`).

Showing it is controlled by:

| Where | Property | Default |
|---|---|---|
| `UTacticalGrenadeComponent` | `bShowThrowPreview` | `false` |
| `USquadAITutorialSubsystem` | `bShowGrenadeArcDuringLesson` | `true` |
| `USquadAITutorialSubsystem` | `bShowGrenadeArcForWholeTutorial` | `false` |
| `AQuestNativeHUD` | `bDrawGrenadeThrowPreview` | `true` |

Colours, dot stride, ring radius and the distance readout are all exposed on
the HUD.

---

## 5. Cans and barrel had no material at all

They were bare `/Engine/BasicShapes/Cylinder` meshes with no material
assigned, so they rendered with the default engine grey — flat, untextured,
and almost invisible against sand.

`S19-MAT`: both props now auto-resolve the trench material pack at
`/Game/SquadAI/TrenchMaterials/`:

| Prop | Material |
|---|---|
| cans | `M_TrenchAmmoCan` |
| barrel | `M_TrenchDrum` |

Both are produced by `scripts/SquadAI_ImportTrenchMaterials.py`. If the pack
isn't imported yet the props keep the old look **and log exactly what to run**.
Designer overrides (`CanMaterialOverride`, `BarrelMaterialOverride` on
`ATutorialRangeActor`) always win. Lookups are cached, including misses, so
`DoesPackageExist()` is not hit on every spawn.

Also fixed while in there: the can knock-down impulse was `18000` cm/s —
**180 m/s**, which fired cans into orbit before you could see them fall.
Now `800` cm/s (8 m/s), a believable tumble off the berm.

---

## 6. Menu video loop, fog speed, and the stutter

### 6a. The freeze before the clip restarts (`S19-VID`)
Native looping lets the decoder run to **end-of-stream**, then `Seek(0)`; that
seek flushes the decoder and the flush is the pause you see.
`UpdateBackgroundVideoLoop()` now **rewinds before the end while the decoder
is still running**, so end-of-stream is never reached:

| CVar | Default |
|---|---|
| `SquadAI.MenuVideo.SeamlessLoop` | `1` |
| `SquadAI.MenuVideo.LoopLead` | `0.45` s (rewind this far before the end) |
| `SquadAI.MenuVideo.LoopStart` | `0.0` s |
| `SquadAI.MenuVideo.LoopEndTrim` | `0.0` s (drop a fade-to-black tail) |

If the clip's last second matters, raise `LoopLead` only as far as you can
tolerate — the trade is "skip a bit of tail" vs "risk the flush". The existing
stall watchdog is untouched and still there as a backstop.

### 6b. Fog too slow (`S19-FOGSPEED`)
One knob: **`SquadAI.MenuFogSpeed`**, default **1.4** (authored 8.15 s → ~5.8 s).
It scales the *fog clock*, not the individual phases, so blast / whiteout /
logo / clear keep the proportion they were authored in.
Live-tunable: `SquadAI.MenuFogSpeed 2.0`. Clamped to 0.1–8 so a typo can't
make it a flash or a hang. Helper: `ASquadAIMainMenuHUD::GetFogSpeedScale()`.

### 6c. The stutter when the fog goes down (`S19-STUTTER`)
On the exact frame the clear began, the code called
`IntroVideoPlayer->Close()` — a **synchronous** decoder + media-texture
teardown on the game thread. That was the hitch.

Now it *pauses* (cheap) at the hand-off and releases the player when the wipe
completes and the menu is fully on screen (`ReleaseIntroVideo()`), plus on
`EndPlay` as a safety net.

---

## 7. `scripts/RUN_IN_TRENCH_PROJECT.py` — the material/mesh bringer

`RUN_IN_SQUADAI_PROJECT.py` assigns two families that the export never
carried across, so they silently never appeared:

* `SM_Mil_Trench_Equipment_Obstacle_Wood_01` — the wooden X-frame / knife rest
  the wire stands on (`custom_wire_obstacle_mesh`). Every frame was unfounded
  and floating.
* `SM_Wire_01_A / _B / _C` — the hand-built concertina coils
  (`custom_wire_coil_mesh`, `_mesh2`).

Both are now in `ROOTS`. The script also finishes with a **checklist** of all
18 assets the apply step will look for and names anything missing, instead of
failing quietly — that silence is how this went unnoticed for two batches.
Header instructions corrected to *Tools → Execute Python Script…* (or
`py "<path>"`).

---

## 8. Files changed

**C++ (8):**
`Private/HUD/QuestNativeHUD.cpp` · `Public/HUD/QuestNativeHUD.h` ·
`Private/HUD/SquadAIMainMenuHUD.cpp` · `Public/HUD/SquadAIMainMenuHUD.h` ·
`Private/Tutorial/SquadAITutorialSubsystem.cpp` · `Public/Tutorial/SquadAITutorialSubsystem.h` ·
`Private/Tutorial/TutorialRangeActor.cpp` · `Public/Tutorial/TutorialRangeActor.h` ·
`Private/Components/TacticalGrenadeComponent.cpp` · `Public/Components/TacticalGrenadeComponent.h`

**Script (1):** `scripts/RUN_IN_TRENCH_PROJECT.py`
**New:** `tools/squadai_lint.py`

---

## 9. Do this before your next build

1. `python tools\squadai_lint.py Source\SquadAI` — expect **0 errors, 16 warnings**.
2. Optional but recommended (R1 from the old report): stop UBT halting at the
   first error so you get the whole list in one pass —
   `<Project>\Saved\UnrealBuildTool\BuildConfiguration.xml`:
   ```xml
   <Configuration xmlns="https://www.unrealengine.com/BuildConfiguration">
     <ParallelExecutor>
       <bStopCompilationAfterErrors>false</bStopCompilationAfterErrors>
     </ParallelExecutor>
   </Configuration>
   ```
3. Build. If anything new appears, the most likely spot is
   `Private/HUD/SquadAIMainMenuHUD.cpp` (largest edit) or
   `Private/HUD/QuestNativeHUD.cpp`.
4. In the trench project re-run `RUN_IN_TRENCH_PROJECT.py` (new meshes), then
   in the game project `RUN_IN_SQUADAI_PROJECT.py`, then save the level.
5. Run `scripts/SquadAI_ImportTrenchMaterials.py` if
   `/Game/SquadAI/TrenchMaterials` is empty — the cans and barrel need
   `M_TrenchAmmoCan` and `M_TrenchDrum`.

---

# Batch 2 — tutorial UI: COD layout, no overlaps, bevelled panels

## 10. Why it looked wrong, specifically

I mapped every panel `DrawHUD` places, then compared it with where the
tutorial overlay was drawing. Three hard collisions:

| Tutorial element | Old position | Collided with |
|---|---|---|
| Lesson card | `(28, SH-186)` bottom-**left** | **squad status panel** — drawn at `(30, SH-240)`, i.e. the same corner |
| Checklist | `(SW-325, 170)` top-**right**, 9 rows | **combat feed** (right edge, starts `Y=150`) and the weapon status plate |
| Skip button | `(SW-174, SH-52)` bottom-**right** | **minimap** (centre `SW-125, SH-125`, radius 100) |

Plus two layout bugs that made it drift:

* the **illustration floated loose above the card**, clamped only to
  `Y >= 16`, so at low resolutions it wandered into the middle of the screen;
* the **highlight leader line** recomputed the card's position from a
  hard-coded `28 px` / `150 px` instead of the card's actual rect, so it
  pointed at empty screen whenever the card moved or the resolution changed;
* the **key chip** used the same hard-coded `150 px`, so it detached too.

## 11. New layout

Everything now sits in the one band no HUD panel occupies — the centre.

| Element | New position |
|---|---|
| Lesson card | centred, `Y = 60%` of screen height |
| Illustration | **bonded into a left column of the card** (a manual page, not loose art) |
| Step progress | a row of **diamond pips** under the card, matching the objective-waypoint language, with `n / N` beneath |
| Key hints | **raised keycap glyphs** inside the card (no separate chip) |
| Skip | **top-right**, `Y=16` — above the feed (`Y=150`), beside the compass |
| Full checklist | behind `bShowTutorialChecklist` (default **off**), moved to the **left-centre** band when on |

The card geometry (`CardX/Y/W/H`) is now declared once, before the highlight
callout, and both the callout and the card read from it. Move the card and the
leader line follows.

## 12. `DrawTacticalPlate3D` — the "3D" look

New primitive replacing the flat `DrawRect` + one hard shadow:

* **three-layer graded drop shadow** (one hard offset rect is what made panels
  look pasted on)
* **smooth 10-step vertical gradient** body
* **real emboss** — light on the top/left inner edges, dark on bottom/right
* **mitred chamfered border**
* **accent bar** down the leading edge with a soft colour bleed

Used by the lesson card, the pips strip, the key chip and the cinematic
bottom banner.

## 13. `DrawKeycapGlyph` / `DrawKeycapGlyphRow`

Raised keycap glyphs with a skirt, a top sheen, a bottom shade and a rim —
the prompt style COD/BF use. Width follows the label, so `SPACE` is wide and
`G` is square. `DrawKeycapGlyphRow` parses a hint string and renders bracketed
tokens (`[SPACE]`) or short tokens (`W`, `A`, `RMB`) as caps, plain words as
text. Named `...Glyph` to avoid colliding with the older `DrawKeycap`, which
has a different signature and is still used by the cinematic banner.

## 14. Files changed in batch 2

`Private/HUD/QuestNativeHUD.cpp` · `Public/HUD/QuestNativeHUD.h`

Lint after batch 2: **0 errors, 16 warnings** (unchanged from batch 1).
Brace/paren balance verified on both files.

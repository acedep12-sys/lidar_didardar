# S18c — weapon grip retarget + leader path fix

## 1. Weapon on the V3 clone (`S18-GRIP`)
Files: `Private/Environment/CharacterCloneStation.cpp`, `Public/Environment/CharacterCloneStation.h`

**Cause.** Both clone paths copied the mannequin socket's
`RelativeLocation/Rotation/Scale` **verbatim** onto the V3 hand bone. The UE5
mannequin `hand_r` and a V3 / Character-Creator right hand use different bone
axis orientations and are authored at different bone sizes, so the copied
transform lands rotated and oversized — exactly the screenshot.

**Fix.** New `RetargetSocketTransform()`:
- builds ref-pose **component-space** transforms for both hand bones,
- computes `Delta = inverse(CloneBone.Rot) * TemplateBone.Rot`,
- `NewLoc = Delta.RotateVector(SocketLoc) * SizeRatio`, `NewRot = Delta * SocketRot`,
- `SizeRatio` = clone forearm length / template forearm length (clamped 0.2–5),
- `NewScale = SocketScale * SizeRatio * WeaponScaleMultiplier`.

Applied in **both** `CreateReadyClone()` (skeleton socket) and
`CreateReadyMesh()` (baked mesh socket). Each logs
`[CloneStation] S18-GRIP ... loc/rot/scale (why)` so you can see the delta.

New properties on the station:
| Property | Default | Use |
|---|---|---|
| `bRetargetGripSocket` | true | off = old verbatim behaviour |
| `bAutoScaleWeaponToGrip` | true | size-match rifle to the hand |
| `WeaponScaleMultiplier` | 1.0 | manual nudge if still slightly off |

Re-run the station after compiling (the old clone keeps the bad socket).

## 2. Leader stalls / paces short of the quest zone (`S18-LEAD`)
Files: `Private/AI/SoldierAIController.cpp`, `Public/AI/SoldierAIController.h`,
`Private/AI/StateTreeTasks/STTask_LeaderPath.cpp`, its header.

**Cause.** The follow goal came from `FindInputKeyClosestToWorldLocation`, which
snaps to the nearest spline point. On bends or corridor drift it jumps
**backwards**, so the lookahead goal lands behind the leader: he walks back,
re-snaps, walks forward — the pacing. Handoff to the real quest goal also
required reaching `SplineLength - 850`, which he often never did.

**Fix.**
- Monotonic progress cached per controller (`LeaderSplineProgress`), backwards
  snaps rejected unless the pawn is genuinely >25 m from the remembered point
  (teleport/respawn); resets on guide change or a 20 s gap.
- Early **handoff**: as soon as the mission goal is nearer than the lookahead
  point, or the spline runs out, steer straight at the goal (`/HANDOFF`).
- Hazard-skip results that would move him backwards are clamped (`/MONO`).
- **Stall watchdog** in `STTask_LeaderPath`: sampled every 1.5 s; <150 cm of
  travel while free to march ⇒ ignore the spline and drive directly at the
  MissionZone / `QuestRegistry.CurrentActiveGoal` for 6 s.

---

## S18c verification pass — three more root causes found and fixed

### 3. Runtime weapon attach had the SAME verbatim copy (`S18-GRIP`)
`ASoldierCharacter::ApplyEquippedWeaponAttachment()` (S17-GRIP2) emulates the
socket at runtime when the skeleton lacks it, and it built
`EmulatedSocketTransform` straight from the template socket. **This is the path
your in-game screenshot actually went through** — fixing only the clone station
would not have changed what you saw if the clone's socket was missing or the
runtime emulation kicked in. Now retargeted through the shared helper.

New header `Public/Characters/SquadAIGripRetarget.h` holds the math; the clone
station and the character both use it, so they can never diverge.
New character properties (Soldier|Weapon Visual|Attach): `bRetargetGripToOwnSkeleton`,
`bAutoScaleWeaponToGrip`, `WeaponGripScaleMultiplier`.

### 4. Quest move command bypassed the spline entirely (`S18-LEAD`)
`UQuestObjective_AutoZone::OnStart()` pushes a `QuestGoal` move command to every
ally. `GetEffectiveMoveGoal()`'s `ActiveMoveCommand` branch returned the **raw
zone centre with no corridor guidance** — so the leader beelined, the partial
path died short of the zone, and he paced there. Leaders now always run through
`ApplySplineAndFireToGoal()` (corridor + monotonic progress + handoff).

### 5. Off-navmesh goal + per-tick re-pathing (`S18-LEAD`)
- The goal is now snapped with `ProjectToNav()` before `AIMoveTo` — a zone pivot
  a few metres off the navmesh produced an endless partial path.
- **Arrival hold:** within 220 cm of the goal he stops and holds for 2 s instead
  of fighting the path follower.
- **Repath backoff:** at most one new move every 0.5 s. Previously a failing
  path restarted every tick, which looks exactly like pacing in place.

---

## Second verification pass — the two biggest leader causes

### 6. TWO systems were driving the leader at once (`S18-LEAD`)
`ASoldierAIController::RunDirectMissionPathing()` (controller tick,
`MoveToLocation`, 180 acceptance, 1.5 s re-issue) and `FSTTask_LeaderPath`
(StateTree, `UAITask_MoveTo`, 250 acceptance, its own combat/player gates) were
**both** issuing move requests every tick. Each new request aborts the other's
path, and their stop conditions differ — that is the walk → stop → drift back
loop, and it also explains why it only showed up near the zone.

Fix: the task calls `NotifyLeaderPathTaskActive()` each tick;
`RunDirectMissionPathing()` returns early while that heartbeat is <0.5 s old.
If the StateTree asset has no LeaderPath task, the heartbeat goes stale and the
controller resumes exactly as before — no behaviour lost.

### 7. The leader was caught by the enemy "hold and fight" freeze (`S18-LEAD`)
In `RunDirectCombatFallback()`, `bAllyFollower` excluded the leader, so the
leader hit the `Dist <= 2200 ⇒ StopMovement()` branch — every tick, for any
visible hostile within 22 m. Near the quest zone there is always one. He now
counts as team-0 movement-owned (aiming and firing unchanged);
`STTask_LeaderPath` still halts him for hostiles inside 15 m and runs cover.

### 8. Arrival-hold scoping bug in my own first pass
The 220 cm hold compared against `GoalLoc`, which is normally the *moving*
corridor lookahead point — that would have stuttered the march. It now tests
distance to the real MissionZone / `CurrentActiveGoal` only.

### 9. Progress reset on objective change
Monotonic progress also resets when the mission goal itself moves >10 m, so the
next objective can legitimately send him back down the corridor.

Checked and found clean: `CurrentActiveGoal` is written once per objective start;
waypoint advance / `AcceptanceRadius` logic; the 600 cm ally-arrival completion
check (consistent with the 220 cm hold); no other weapon-attach site exists
(`SquadAIPackBridgeLibrary` only sets the socket *name*).

---

## Third verification pass

### 10. Two different "wait for the player" radii fought each other (`S18-LEAD`)
`ALeaderCharacter::UpdatePacing()` sets **`MaxWalkSpeed = 0`** as soon as the
player is beyond `WaitForPlayerRadius` (**1500 cm** by default, or the tuning
asset's value). Both movement owners, however, only stopped *issuing* moves at a
hardcoded **3500 cm**. Between 15 m and 35 m the leader was therefore being
pathed at zero walk speed: he stood on the spot twitching against the path
follower, drifting with avoidance, never advancing — the pacing you see, and it
"stops once in a while" exactly as the player's distance crosses 15 m.

Both the StateTree task and `RunDirectMissionPathing()` now read the leader's
own `WaitForPlayerRadius`, so he either walks or deliberately waits — never
both. The stall watchdog is also disarmed while he is legitimately waiting, so
waiting can't trigger a direct-goal burst.

**Tuning note:** if you want him to lead further ahead of you, raise
`WaitForPlayerRadius` on the leader (or `LeaderWaitForPlayerRadius` in the
tuning asset) — it is now the single knob that controls it.

Also re-checked and clean: `PathSpeedScale` (clamped to ≥0.45 by the leader),
`TrenchWalkSpeedScale`, the downed/dead/teleport `StopMovement()` sites, and
`STTask_FollowLeader` (allies only).

---

## Fourth verification pass — weapon side

### 11. A THIRD verbatim-copy site (`S18-GRIP`)
`ASoldierCharacter::CreateGripSocketOnSkeleton()` — the "create grip socket"
editor button — also copied the mannequin socket transform unchanged, so using
that button would bake the twisted grip straight into your skeleton asset. Now
retargeted like the other two.

### 12. The runtime hand-bone resolver did not know your rig
`ASoldierCharacter::ResolveGripBone()` only tested 6 UE/Mixamo names
(`hand_r`, `RightHand`, …) — no `CC_Base_R_Hand`, no scored scan. On a V3 / CC4
/ DAZ skeleton it returned None, socket emulation was skipped entirely, and the
weapon fell back to the mesh root: **that is the original "rifle on the floor"**.
The scored resolver (fixed names + name scan, left-hand and finger/twist/IK
bones excluded) now lives in `SquadAIGripRetarget.h` and is used by the runtime
attach, the editor button and the clone station — the three lists can no longer
drift apart.

### 13. `bOverrideWeaponAttachScale` cancelled the size match
It called `SetRelativeScale3D(WeaponAttachScale)` *after* the socket transform,
overwriting the retargeted scale. The rig ratio is now folded into that override
instead of being thrown away.

### 14. The grip was never re-applied after a mesh swap or a revive
`ApplyEquippedWeaponAttachment()` only ran from `SetEquippedWeaponMesh()`. Pack
Blueprints that swap the body mesh (your V3 swap) or spawn the weapon after
BeginPlay left the old attachment in place, and `CompleteRevive()` re-attaches
the skeletal mesh without re-applying the grip. Added: a 0.1 s re-apply after
BeginPlay and one at the end of the revive path.

### Knobs recap (per character, Soldier|Weapon Visual|Attach)
`bRetargetGripToOwnSkeleton` · `bAutoScaleWeaponToGrip` · `WeaponGripScaleMultiplier`
and on the clone station: `bRetargetGripSocket` · `bAutoScaleWeaponToGrip` ·
`WeaponScaleMultiplier`. If the rifle is still slightly off after this build,
send me the `[WeaponAttach] S18-GRIP` log line — it prints the detected bone,
the axis delta and the size ratio, which tells us exactly which stage is wrong.

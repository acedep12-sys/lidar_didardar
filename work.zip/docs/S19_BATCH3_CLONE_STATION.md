# S19 — Batch 3: the clone station actually fixes the grip now

**Scope:** `CharacterCloneStation` + the shared grip-retarget math.
**Not touched:** anything that changes lighting (no light actors, no post-process, no fog, no sky/exposure). This batch is pure asset/transform/code work.

---

## 1. What was actually wrong

"Swap the V3 mesh in and the rifle ends up under the character's feet." Four separate defects stacked up. Any one of them alone produces a bad grip; together they also made the tool unable to repair itself.

### 1.1 The socket was baked onto the **skeleton** — and skeletons are shared

`CreateReadyClone()` wrote the grip socket into `CloneMesh->GetSkeleton()->Sockets`. A skeleton asset is normally shared by several meshes. Two consequences:

* every other character using that skeleton silently gained a hand-tuned rifle socket;
* **once a socket existed, the tool logged `"already exists — nothing to create"` and returned.**

That second point is the killer. A socket baked with wrong math could **never** be corrected by re-running the button — the tool was idempotent in the worst possible way. This is why a visibly broken grip survived repeated attempts to fix it.

### 1.2 The retarget math composed the bone chain **backwards**

`SquadAIGrip::RefBoneComponentSpace()` accumulated from the bone **up** to the root and multiplied child-first:

```cpp
while (Idx != INDEX_NONE)
{
    T = T * Pose[Idx];      // child * ... * root
    Idx = Ref.GetParentIndex(Idx);
}
```

Component space must compose from the root **down** to the bone (`CS[b] = CS[parent(b)] * Local[b]`). Composing the other way yields the root's frame, not the bone's, so the rotation delta between the two rigs' hands came out wrong — the socket landed rotated away from the hand.

Measured on the test rigs (see §4): correct hand position `(49, 34, 132)`, backwards composition gave `(12, 65, 132)`.

### 1.3 The size ratio was measured on the wrong bone

`BoneSegmentLength()` measured a bone by the translation length of its **last child**:

```cpp
int32 LastChild = ...;                                     // grip bones are leaves
int32 MeasureIdx = (LastChild != INDEX_NONE) ? LastChild : BoneIndex;
```

Every grip bone (hand / wrist) is a leaf or near-leaf, so this measured a thumb stub instead of the hand, and when there was no child at all it returned 0 → the ratio silently degenerated to `1.0` (weapon the wrong size), or to something absurd when a thumb was present.

Measured: correct ratio **1.200** (hand segment 12 cm / 10 cm), old helper gave **3.000** (thumb 9 cm / thumb 3 cm) — a 2.5× oversized weapon.

### 1.4 The weapon-attach gate was never opened  ⚠ **most likely the real culprit**

```cpp
// ASoldierCharacter::ApplyEquippedWeaponAttachment()
if (!EquippedWeaponMesh || !GetMesh() || !bAutoAttachEquippedWeaponToMesh || bUsePackPresentationMode)
{
    return;   // <- returns BEFORE any socket logic runs
}
```

`bAutoAttachEquippedWeaponToMesh` defaults to **`false`** in `SoldierCharacter.h`. A mannequin Blueprint that came out of this project has it set true, which is why the mannequin holds the weapon correctly. A V3 Blueprint authored outside the project leaves it **false** — so `ApplyEquippedWeaponAttachment()` returns on its very first line, the weapon is **never attached to anything**, and it just sits where it was spawned: at the actor origin, i.e. **between the character's feet**.

The station duplicated the Blueprint but never copied that flag. No amount of socket fixing can help while that gate is shut.

---

## 2. What changed

### `Public/Characters/SquadAIGripRetarget.h` (shared by the editor station *and* the runtime attach)

| Change | Why |
|---|---|
| `RefBoneComponentSpace()` rewritten to compose **root → bone** | §1.2 |
| `BoneSegmentLength()` now returns the bone's **own** local translation length (the parent→bone segment). No composition, leaf-safe. | §1.3 |
| New `SegmentLengthAtLevel()`, `PathLengthFromRoot()`, `ComputeSizeRatio()` | Ratio is taken from the **same chain level on both rigs** (own segment → parent's → grandparent's, first level where both exceed 1 cm), with a root-path-length fallback. Never divides by zero; clamped to 0.2–5.0. |
| `OutScale = SocketScale * Ratio * ExtraScale` | Was `BaseScale * Ratio * max(0.01, Extra)`, which threw away the socket's own authored scale. |
| New `SocketComponentSpace()` | Lets callers *verify* where the socket ended up. A grip socket at Z≈0 is the bug we are hunting. |
| `ResolveRightHandBone()` — bone-name list extended (CC4 / V3 style), scan threshold kept at ≥ 6 | Unchanged behaviour, now covered by tests. |

### `Public/Environment/CharacterCloneStation.h`

New knobs, all defaulting to the fixed behaviour:

* **`bDuplicateMeshForClone`** (default **true**) — the clone gets its own **duplicate** of the mesh and the grip socket is baked as a **mesh-level** socket. Mesh-level sockets resolve *before* skeleton sockets, so this also beats any stale skeleton socket left by an earlier attempt. Your V3 mesh and its skeleton are never modified.
* **`bOverwriteExistingClones`** (default **true**) — re-running **replaces** the previous output instead of spawning `BP_x_Ready_2`, `_3`, `_4`…
* **`bForceWeaponAttachOnClone`** (default **true**) — copies the reference character's `bAutoAttachEquippedWeaponToMesh` / `bUsePackPresentationMode`, or forces them to `true` / `false` when no reference is set. Logs loudly when it had to flip them. §1.4
* **`bVerifyGripSocket`** (default **true**) — measures the baked socket and shouts if it is at/below the feet.

### `Private/Environment/CharacterCloneStation.cpp`

* New shared helpers in the editor namespace: `ComputeGripTransform()`, `BakeSocketsIntoMesh()`, `BakeSocketIntoSkeleton()`, `VerifyGripSocket()`, `DeleteExistingAsset()`, `ResolveOutputName()`, `LogHandBoneCandidates()`.
* Step 4 now also copies `bRetargetGripToOwnSkeleton`, `bAutoScaleWeaponToGrip`, `WeaponGripScaleMultiplier` from the reference (they drive the runtime grip and were being left at C++ defaults).
* Step 5 rewritten: duplicate → bake mesh-level sockets → point the clone at the fixed mesh → verify. Falls back to the skeleton path (still **replacing**, never skipping) if `bDuplicateMeshForClone` is off or duplication fails.
* `CreateReadyMesh()` refactored onto the same helpers, so **the two buttons can no longer disagree** about where the grip belongs.
* Every socket is baked under the main name **plus every `AdditionalSocketNames` alias**, so whichever name a consumer looks up, it exists and is correct.

---

## 3. How to use it (in the editor)

1. Place a **Character Clone Station** actor in any map.
2. **SourceCharacter** = your V3 character Blueprint (the one whose rifle sits at the feet).
3. **ReferenceCharacter** = the mannequin soldier BP that holds the weapon correctly. *Set this.* It supplies the socket name and the hand-tuned attach offsets.
4. **V3Mesh** — only if SourceCharacter is the mannequin BP and you want the V3 body swapped in.
5. Press **CREATE READY CLONE**.
6. Read the log (`[CloneStation]`):
   * `Weapon-attach gate was CLOSED on the source …` → that was your bug, it is now fixed on the clone. §1.4
   * `grip transform: loc=… rot=… scale=… (…)` → the reason string tells you whether it retargeted, copied verbatim, or fell back to attach offsets.
   * `VERIFY OK: socket 'RifleSocket' is 128.4 cm above the origin, on bone 'RightHand'.` → **this is the line that means it worked.**
   * `VERIFY FAILED: socket sits at Z=0.0 — that is the mesh ROOT…` → the grip bone was mis-resolved; the log names the bone it landed on.
7. Place the new Blueprint from `/Game/SquadAI/Clones` in your mission and play.

**Re-running is safe and is now the way to iterate.** Tweak `WeaponScaleMultiplier` (0.05–20) and press the button again — the same asset is rebuilt in place, with the new math. You no longer need to hand-delete sockets to try again.

If the rifle is still slightly off:

* too big / too small → `WeaponScaleMultiplier`
* rotated wrong → set `bRetargetGripSocket = false` once to compare; the retarget is on by default and is correct for rigs with different bone axes
* in the wrong place entirely → the log's `Hand/arm-ish bones found: [...]` line tells you what the resolver saw; send that list.

---

## 4. Proof it works

`tools/grip_test/` compiles the **real** `SquadAIGripRetarget.h` against minimal UE-like stubs — no Unreal required:

```sh
cd tools/grip_test && ./run.sh
```

Two rigs are built: a UE mannequin (bones along +X, all rotations identity) and a V3-style rig with **different bone names and a different axis convention** (arm chain carries a −90° yaw, so children travel along −Y in their own local space). Both reach the same physical hand through different frames.

**16 passed, 0 failed.** The load-bearing results:

| Check | Old code | New code |
|---|---|---|
| V3 hand component-space position | `(12, 65, 132)` | `(49, 34, 132)` ✅ |
| Size ratio (hand 12 cm vs 10 cm) | 3.000 (measured thumbs) | 1.200 ✅ |
| Socket distance from the hand bone | **18.5 cm** | **7.4 cm** ✅ |
| Socket height above origin | — | **128.4 cm** (at the hand, not at the feet) ✅ |
| Orientation error across the axis change | — | **0.000°** ✅ |

A rig with a **zero-length** hand bone falls back up the chain (ratio 2.259 from the forearm) instead of silently yielding `1.0`. The scored scan picks `Character_Right_Wrist_Joint` (score 7) over a thumb and over the **left** wrist.

---

## 5. Files changed

| File | Nature |
|---|---|
| `source/SquadAI/Public/Characters/SquadAIGripRetarget.h` | retarget math corrected + verification helper |
| `source/SquadAI/Public/Environment/CharacterCloneStation.h` | 4 new knobs |
| `source/SquadAI/Private/Environment/CharacterCloneStation.cpp` | shared bake helpers, non-destructive & idempotent output, gate fix, verification |
| `tools/grip_test/` | **new** — standalone regression test for the math |

Lint unchanged from baseline: **0 errors, 16 warnings** (`python3 tools/squadai_lint.py source/SquadAI`).

---

## 6. Still queued

* `TrenchDetailSplineActor` prop imperfections at the trench edges (duckboards, revetment panels, wire, stakes).
* Trench "material bringer" script from the trench project.
* `SETUP.md` setup guide.

None of the above touches lighting.
